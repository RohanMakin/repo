import boto3
from botocore.exceptions import ClientError
from airflow.operators.dummy import DummyOperator 
from airflow import DAG
from airflow.operators.python import PythonOperator
from airflow.providers.postgres.hooks.postgres import PostgresHook
from datetime import datetime, timedelta
import logging

dag = DAG(
    'Archival_framework',
    start_date=datetime(2025, 2, 4),
    schedule_interval=None,
    catchup=False,
    max_active_tasks=3,
)

start_task = DummyOperator(
    task_id='start_task',
    dag=dag
)

end_task = DummyOperator(
    task_id='end_task',
    dag=dag
)

def fetch_and_push_table_metadata():
    dynamo_client = boto3.client('dynamodb', region_name='us-west-2')
    table_name = 'managed_airflow_to_archive_records_at_redshift'

    try:
        # Retrieve all table records from DynamoDB
        response = dynamo_client.scan(TableName=table_name)
        Archival_data = response.get('Items', [])

        if not Archival_data:
            logging.error("No data found in DynamoDB table.")
            return []  # Return an empty list if no data is found

        formatted_data = []
        for data in Archival_data:
            tables = data['PK']['S']
            schemas = data['schema']['S']
            archive_table = data['SK']['S']
            condition_column = data['condition_column']['S']
            retention_days = data['retention_days']['S']  

            # Check if 'other_filter' exists in the data and provide a default value if not
            other_filter = data.get('other_filter', {}).get('S', '')

            formatted_data.append({
                "tables": tables,
                "schema": schemas,
                "archive_table": archive_table,
                "condition_column": condition_column,
                "days": retention_days,
                "other_filter": other_filter
            })

        logging.info(f"Fetched metadata: {formatted_data}")
        return formatted_data
    except ClientError as e:
        logging.error(f"Error fetching metadata from DynamoDB: {e.response['Error']['Message']}")
        return []  # Return an empty list in case of error

# Function to Archival data from Redshift
def Archival_redshift_data(tables, schema, archive_table, condition_column, retention_days, other_filter):
    # Establish Redshift connection using Airflow's Postgres Hook
    redshift_hook = PostgresHook(postgres_conn_id='redshift_dp_prod_db', database='dp_prod_db')  # Specify the Redshift database
    
    Archival_query = f"""
        
        begin;

        insert into {schema}.{archive_table}
        select * from {schema}.{tables} where {condition_column} <= dateadd(day,-{retention_days},SYSDATE) {other_filter};

        delete from {schema}.{tables} where {condition_column} <= dateadd(day,-{retention_days},SYSDATE) {other_filter};

        commit;
        end;
            
    """

    logging.info(f"Archival Query: {Archival_query}")  
    print(f"Archival Query: {Archival_query}")  

    # Execute the Archival query
    try:
        redshift_hook.run(Archival_query)
        return f"Data Archival successfully from {schema}.{tables}"
    except Exception as e:
        return f"Error Archival data: {str(e)}"


# Fetch the table metadata
table_metadata = fetch_and_push_table_metadata()

# Log the fetched metadata
logging.info(f"Fetched table metadata: {table_metadata}")

# Ensure table_metadata is a list of dictionaries
if isinstance(table_metadata, list):
    for data in table_metadata:
        tables = data['tables']
        schema = data['schema']
        archive_table = data['archive_table']
        condition_column = data['condition_column']
        retention_days = data['days']
        other_filter = data['other_filter']

        Archival_task = PythonOperator(
            task_id=f"Archival_redshift_{tables}",
            python_callable=Archival_redshift_data,
            op_args=[tables, schema, archive_table, condition_column, retention_days, other_filter],
            provide_context=True,
            dag=dag
        )

        # Set task dependencies
        start_task >> Archival_task >> end_task
else:
    logging.error("table_metadata is not a valid list of dictionaries. Check the data fetching logic.")