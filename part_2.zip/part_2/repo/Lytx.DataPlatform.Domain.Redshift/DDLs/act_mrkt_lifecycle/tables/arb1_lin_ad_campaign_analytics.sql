-- liquibase formatted sql --default-schema-name act_mrkt_lifecycle

-- changeset imported_obj_act_mrkt_lifecycle.arb1_lin_ad_campaign_analytics:81219114-1 
CREATE TABLE act_mrkt_lifecycle.arb1_lin_ad_campaign_analytics (
    _airbyte_raw_id character varying(65535) ENCODE lzo,
    _airbyte_extracted_at timestamp with time zone ENCODE az64,
    _airbyte_meta character varying(65535) ENCODE lzo,
    _airbyte_generation_id bigint ENCODE az64,
    likes double precision ENCODE raw,
    pivot character varying(65535) ENCODE lzo,
    clicks double precision ENCODE raw,
    shares double precision ENCODE raw,
    comments double precision ENCODE raw,
    end_date date ENCODE az64,
    costinusd double precision ENCODE raw,
    start_date date ENCODE az64,
    impressions double precision ENCODE raw,
    pivotvalues character varying(65535) ENCODE lzo,
    sponsoredcampaign character varying(65535) ENCODE lzo,
    costinlocalcurrency double precision ENCODE raw,
    string_of_pivot_values character varying(65535) ENCODE lzo
)
DISTSTYLE AUTO
SORTKEY ( _airbyte_extracted_at );