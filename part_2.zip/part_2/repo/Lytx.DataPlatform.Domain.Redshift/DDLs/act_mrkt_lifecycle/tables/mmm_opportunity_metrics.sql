-- liquibase formatted sql --default-schema-name act_mrkt_lifecycle

-- changeset imported_obj_act_mrkt_lifecycle.mmm_opportunity_metrics:36607458-1 
CREATE TABLE act_mrkt_lifecycle.mmm_opportunity_metrics (
    date_field character varying(16) ENCODE lzo,
    date date ENCODE az64,
    act_market_segment__c_group character varying(285) ENCODE lzo,
    act_market_segment__c character varying(285) ENCODE lzo,
    metric_group character varying(18) ENCODE lzo,
    metric_outcome character varying(24) ENCODE lzo,
    metric character varying(28) ENCODE lzo,
    value bigint ENCODE az64,
    interaction_before_milestone bigint ENCODE az64,
    bookedforecasted_subs double precision ENCODE raw,
    bookedforecasted_arr double precision ENCODE raw
)
DISTSTYLE AUTO;