-- liquibase formatted sql --default-schema-name act_mrkt_lifecycle

-- changeset imported_obj_act_mrkt_lifecycle.arb1_bng_campaign_performance_report_daily:62002936-1 
CREATE TABLE act_mrkt_lifecycle.arb1_bng_campaign_performance_report_daily (
    _airbyte_raw_id character varying(65535) ENCODE lzo,
    _airbyte_extracted_at timestamp with time zone ENCODE az64,
    _airbyte_meta character varying(65535) ENCODE lzo,
    _airbyte_generation_id bigint ENCODE az64,
    spend double precision ENCODE raw,
    clicks bigint ENCODE az64,
    network character varying(65535) ENCODE lzo,
    deviceos character varying(65535) ENCODE lzo,
    accountid bigint ENCODE az64 distkey,
    campaignid bigint ENCODE az64,
    devicetype character varying(65535) ENCODE lzo,
    timeperiod date ENCODE az64,
    topvsother character varying(65535) ENCODE lzo,
    accountname character varying(65535) ENCODE lzo,
    impressions bigint ENCODE az64,
    bidmatchtype character varying(65535) ENCODE lzo,
    campaignname character varying(65535) ENCODE lzo,
    currencycode character varying(65535) ENCODE lzo,
    addistribution character varying(65535) ENCODE lzo,
    deliveredmatchtype character varying(65535) ENCODE lzo
)
DISTSTYLE AUTO
SORTKEY ( _airbyte_extracted_at );