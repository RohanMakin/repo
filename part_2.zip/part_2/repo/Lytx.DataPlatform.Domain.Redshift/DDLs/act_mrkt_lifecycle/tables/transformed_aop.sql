-- liquibase formatted sql --default-schema-name act_mrkt_lifecycle

-- changeset imported_obj_act_mrkt_lifecycle.transformed_aop:78598289-1 
CREATE TABLE act_mrkt_lifecycle.transformed_aop (
    month date ENCODE az64,
    time_period character varying(256) ENCODE lzo,
    business_unit character varying(256) ENCODE lzo,
    bookings real ENCODE raw,
    arr real ENCODE raw,
    rarpu real ENCODE raw,
    arpu real ENCODE raw,
    acv real ENCODE raw,
    target_arr real ENCODE raw
)
DISTSTYLE AUTO;