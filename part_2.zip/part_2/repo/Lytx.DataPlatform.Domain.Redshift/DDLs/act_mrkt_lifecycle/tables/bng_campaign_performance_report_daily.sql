-- liquibase formatted sql --default-schema-name act_mrkt_lifecycle

-- changeset imported_obj_act_mrkt_lifecycle.bng_campaign_performance_report_daily:53760722-1 
CREATE TABLE act_mrkt_lifecycle.bng_campaign_performance_report_daily (
    _airbyte_raw_id character varying(64) ENCODE lzo,
    _airbyte_extracted_at timestamp with time zone ENCODE az64,
    _airbyte_meta character varying(64) ENCODE lzo,
    _airbyte_generation_id integer ENCODE az64,
    spend real ENCODE raw,
    clicks integer ENCODE az64,
    network character varying(64) ENCODE lzo,
    deviceos character varying(16) ENCODE lzo,
    accountid integer ENCODE az64,
    campaignid integer ENCODE az64,
    devicetype character varying(16) ENCODE lzo,
    timeperiod date ENCODE az64,
    topvsother character varying(64) ENCODE lzo,
    accountname character varying(16) ENCODE lzo,
    impressions integer ENCODE az64,
    bidmatchtype character varying(8) ENCODE lzo,
    campaignname character varying(64) ENCODE lzo,
    currencycode character varying(4) ENCODE lzo,
    addistribution character varying(8) ENCODE lzo,
    deliveredmatchtype character varying(8) ENCODE lzo
)
DISTSTYLE AUTO;