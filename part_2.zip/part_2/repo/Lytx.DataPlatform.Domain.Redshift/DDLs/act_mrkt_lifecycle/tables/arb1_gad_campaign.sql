-- liquibase formatted sql --default-schema-name act_mrkt_lifecycle

-- changeset imported_obj_act_mrkt_lifecycle.arb1_gad_campaign:94336819-1 
CREATE TABLE act_mrkt_lifecycle.arb1_gad_campaign (
    _airbyte_raw_id character varying(65535) ENCODE lzo,
    _airbyte_extracted_at timestamp with time zone ENCODE az64,
    _airbyte_meta character varying(65535) ENCODE lzo,
    _airbyte_generation_id bigint ENCODE az64,
    campaign.id bigint ENCODE az64,
    campaign.name character varying(65535) ENCODE lzo,
    segments.date date ENCODE az64,
    segments.hour bigint ENCODE az64,
    campaign.status character varying(65535) ENCODE lzo,
    campaign.end_date character varying(65535) ENCODE lzo,
    campaign.start_date character varying(65535) ENCODE lzo,
    segments.ad_network_type character varying(65535) ENCODE lzo,
    campaign.advertising_channel_type character varying(65535) ENCODE lzo,
    campaign.advertising_channel_sub_type character varying(65535) ENCODE lzo
)
DISTSTYLE AUTO
SORTKEY ( _airbyte_extracted_at );