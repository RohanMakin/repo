-- liquibase formatted sql --default-schema-name act_mrkt_lifecycle

-- changeset imported_obj_act_mrkt_lifecycle.example_table:93971090-1 
CREATE TABLE act_mrkt_lifecycle.example_table (
    id integer ENCODE az64
)
DISTSTYLE AUTO;