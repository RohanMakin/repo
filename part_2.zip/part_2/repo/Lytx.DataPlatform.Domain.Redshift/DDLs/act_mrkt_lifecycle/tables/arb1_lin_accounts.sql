-- liquibase formatted sql --default-schema-name act_mrkt_lifecycle

-- changeset imported_obj_act_mrkt_lifecycle.arb1_lin_accounts:88890724-1 
CREATE TABLE act_mrkt_lifecycle.arb1_lin_accounts (
    _airbyte_raw_id character varying(65535) ENCODE lzo,
    _airbyte_extracted_at timestamp with time zone ENCODE az64,
    _airbyte_meta character varying(65535) ENCODE lzo,
    _airbyte_generation_id bigint ENCODE az64,
    id bigint ENCODE az64,
    name character varying(65535) ENCODE lzo,
    test boolean ENCODE raw,
    type character varying(65535) ENCODE lzo,
    status character varying(65535) ENCODE lzo,
    created timestamp with time zone ENCODE az64,
    version character varying(65535) ENCODE lzo,
    currency character varying(65535) ENCODE lzo,
    lastmodified timestamp with time zone ENCODE az64,
    servingstatuses character varying(65535) ENCODE lzo
)
DISTSTYLE AUTO;