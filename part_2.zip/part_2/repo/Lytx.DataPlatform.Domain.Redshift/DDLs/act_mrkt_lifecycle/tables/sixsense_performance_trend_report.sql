-- liquibase formatted sql --default-schema-name act_mrkt_lifecycle

-- changeset imported_obj_act_mrkt_lifecycle.sixsense_performance_trend_report:48848292-1 
CREATE TABLE act_mrkt_lifecycle.sixsense_performance_trend_report (
    dt date ENCODE az64,
    campaign_name character varying(255) ENCODE lzo,
    spend numeric(10,2) ENCODE az64,
    impressions integer ENCODE az64,
    clicks integer ENCODE az64,
    accounts_reached integer ENCODE az64,
    accounts_engaged integer ENCODE az64
)
DISTSTYLE AUTO;