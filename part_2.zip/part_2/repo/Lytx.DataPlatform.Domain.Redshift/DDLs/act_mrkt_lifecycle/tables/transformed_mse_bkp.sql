-- liquibase formatted sql --default-schema-name act_mrkt_lifecycle

-- changeset imported_obj_act_mrkt_lifecycle.transformed_mse_bkp:24246567-1 
CREATE TABLE act_mrkt_lifecycle.transformed_mse_bkp (
    campaign_id character varying(100) ENCODE lzo,
    type character varying(256) ENCODE lzo,
    campaign_name character varying(256) ENCODE lzo,
    channel character varying(256) ENCODE lzo,
    sub_channel character varying(256) ENCODE lzo,
    campaign_start_date date ENCODE az64,
    campaign_end_date date ENCODE az64,
    status character varying(256) ENCODE lzo,
    total_cost double precision ENCODE raw,
    cost_currency character varying(256) ENCODE lzo,
    market_segment character varying(256) ENCODE lzo
)
DISTSTYLE AUTO;