-- liquibase formatted sql --default-schema-name act_mrkt_lifecycle

-- changeset imported_obj_act_mrkt_lifecycle.arb1_gad_account_performance_report:60709408-1 
CREATE TABLE act_mrkt_lifecycle.arb1_gad_account_performance_report (
    _airbyte_raw_id character varying(65535) ENCODE lzo,
    _airbyte_extracted_at timestamp with time zone ENCODE az64,
    _airbyte_meta character varying(65535) ENCODE lzo,
    _airbyte_generation_id bigint ENCODE az64,
    customer.id bigint ENCODE az64 distkey,
    segments.date date ENCODE az64,
    segments.device character varying(65535) ENCODE lzo,
    customer.currency_code character varying(65535) ENCODE lzo,
    segments.ad_network_type character varying(65535) ENCODE lzo,
    customer.descriptive_name character varying(65535) ENCODE lzo
)
DISTSTYLE AUTO;