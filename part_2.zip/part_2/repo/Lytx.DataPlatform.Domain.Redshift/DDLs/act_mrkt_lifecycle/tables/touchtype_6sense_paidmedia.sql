-- liquibase formatted sql --default-schema-name act_mrkt_lifecycle

-- changeset imported_obj_act_mrkt_lifecycle.touchtype_6sense_paidmedia:31506975-1 
CREATE TABLE act_mrkt_lifecycle.touchtype_6sense_paidmedia (
    marketing_touch_type_data_source character varying(19) ENCODE lzo,
    crm_account_id character varying(32) ENCODE lzo,
    marketing_touchpoint_date date ENCODE az64,
    marketing_touch_type character varying(23) ENCODE lzo,
    marketing_touch_type_count bigint ENCODE az64,
    spend double precision ENCODE raw,
    interactiontype_sixsense_paidmedia_impressions_count bigint ENCODE az64,
    interactiontype_sixsense_paidmedia_clicks_count bigint ENCODE az64,
    influence_channel character varying(27) ENCODE lzo,
    influence_web_source character varying(6) ENCODE lzo,
    influence_web_medium character varying(10) ENCODE lzo,
    influence_campaign_name character varying(128) ENCODE lzo,
    influence_utm_campaign character varying(150) ENCODE lzo,
    influence_utm_content character varying(200) ENCODE lzo,
    influence_utm_term character varying(255) ENCODE lzo,
    influence_ad_name character varying(130) ENCODE lzo,
    influence_creative_name character varying(9) ENCODE lzo,
    influence_landing_page character varying(500) ENCODE lzo,
    influence_referrer character varying(9) ENCODE lzo,
    webvisit_page character varying(9) ENCODE lzo,
    webvisit_referrer character varying(9) ENCODE lzo
)
DISTSTYLE AUTO;