-- liquibase formatted sql --default-schema-name act_mrkt_lifecycle

-- changeset imported_obj_act_mrkt_lifecycle.mmm_ad_platform_spends:90558390-1 
CREATE TABLE act_mrkt_lifecycle.mmm_ad_platform_spends (
    platform character varying(12) ENCODE lzo,
    dt timestamp without time zone ENCODE az64,
    account_id bigint ENCODE az64,
    account_name character varying(65535) ENCODE lzo,
    campaign_id bigint ENCODE az64,
    campaign_name character varying(65535) ENCODE lzo,
    market_segment character varying(18) ENCODE lzo,
    campaign_type character varying(21) ENCODE lzo,
    country_code character varying(65535) ENCODE lzo,
    currency character varying(65535) ENCODE lzo,
    ad_network character varying(65535) ENCODE lzo,
    channel_type character varying(65535) ENCODE lzo,
    clicks double precision ENCODE raw,
    impressions double precision ENCODE raw,
    spend double precision ENCODE raw
)
DISTSTYLE AUTO;