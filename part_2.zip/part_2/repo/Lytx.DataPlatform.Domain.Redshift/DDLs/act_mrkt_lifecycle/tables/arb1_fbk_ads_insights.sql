-- liquibase formatted sql --default-schema-name act_mrkt_lifecycle

-- changeset imported_obj_act_mrkt_lifecycle.arb1_fbk_ads_insights:88906676-1 
CREATE TABLE act_mrkt_lifecycle.arb1_fbk_ads_insights (
    _airbyte_raw_id character varying(65535) ENCODE lzo,
    _airbyte_extracted_at timestamp with time zone ENCODE az64,
    _airbyte_meta character varying(65535) ENCODE lzo,
    _airbyte_generation_id bigint ENCODE az64,
    ad_id character varying(65535) ENCODE lzo,
    spend double precision ENCODE raw,
    clicks bigint ENCODE az64,
    ad_name character varying(65535) ENCODE lzo,
    adset_id character varying(65535) ENCODE lzo,
    account_id character varying(65535) ENCODE lzo,
    adset_name character varying(65535) ENCODE lzo,
    date_start date ENCODE az64,
    campaign_id character varying(65535) ENCODE lzo,
    impressions bigint ENCODE az64,
    account_name character varying(65535) ENCODE lzo,
    campaign_name character varying(65535) ENCODE lzo,
    account_currency character varying(65535) ENCODE lzo
)
DISTSTYLE AUTO
SORTKEY ( _airbyte_extracted_at );