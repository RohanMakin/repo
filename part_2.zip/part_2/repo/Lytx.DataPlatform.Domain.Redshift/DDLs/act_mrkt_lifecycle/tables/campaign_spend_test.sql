-- liquibase formatted sql --default-schema-name act_mrkt_lifecycle

-- changeset imported_obj_act_mrkt_lifecycle.campaign_spend_test:20926704-1 
CREATE TABLE act_mrkt_lifecycle.campaign_spend_test (
    campaign_name character varying(285) ENCODE lzo,
    monthly_cost double precision ENCODE raw,
    campaign_month date ENCODE az64
)
DISTSTYLE AUTO;