-- liquibase formatted sql --default-schema-name act_mrkt_lifecycle

-- changeset imported_obj_act_mrkt_lifecycle.transformed_goals:19173415-1 
CREATE TABLE act_mrkt_lifecycle.transformed_goals (
    goal_period character varying(256) ENCODE lzo,
    goal_stage character varying(256) ENCODE lzo,
    goal_market_segment character varying(256) ENCODE lzo,
    goal_fleet_type character varying(256) ENCODE lzo,
    goal_division character varying(256) ENCODE lzo,
    goal integer ENCODE az64
)
DISTSTYLE AUTO;