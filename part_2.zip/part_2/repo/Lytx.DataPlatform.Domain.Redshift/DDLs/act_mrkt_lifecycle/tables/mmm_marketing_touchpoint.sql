-- liquibase formatted sql --default-schema-name act_mrkt_lifecycle

-- changeset imported_obj_act_mrkt_lifecycle.mmm_marketing_touchpoint:54738043-1 
CREATE TABLE act_mrkt_lifecycle.mmm_marketing_touchpoint (
    date_field character varying(25) ENCODE lzo,
    date date ENCODE az64,
    channel character varying(112) ENCODE lzo,
    campaign_market_segment_group character varying(18) ENCODE lzo,
    campaign_type character varying(21) ENCODE lzo,
    campaign_name character varying(208) ENCODE lzo,
    metric_group character varying(12) ENCODE lzo,
    metric_outcome character varying(24) ENCODE lzo,
    metric character varying(12) ENCODE lzo,
    value bigint ENCODE az64
)
DISTSTYLE AUTO;