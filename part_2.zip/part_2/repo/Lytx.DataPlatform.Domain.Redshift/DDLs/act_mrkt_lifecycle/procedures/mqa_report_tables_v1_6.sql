-- liquibase formatted sql --default-schema-name act_mrkt_lifecycle

-- changeset imported_obj_act_mrkt_lifecycle.mqa_report_tables_v1_6:295845676-1

CREATE OR REPLACE PROCEDURE act_mrkt_lifecycle.mqa_report_tables_v1_6(OUT "result" character varying(256))
 LANGUAGE plpgsql
AS $$
DECLARE
  min_val int;
BEGIN
-- Step 01a: ACCOUNT MARKETING LIFECYCLE TABLE TEMP TABLE

 drop table if exists AMLH_TEMP;
 
 CREATE TEMPORARY TABLE AMLH_TEMP AS

SELECT
    *
FROM
    (
        SELECT
            -- Account Info
            act.ID AS ACT_ID,
            -- Account Info
            act.IS_DELETED AS ACT_IS_DELETED,
            act.NAME AS ACT_NAME,
            usr.NAME AS ACT_OWNER,
            usr_role.NAME AS ACT_OWNER_ROLE,
            usro.NAME AS ACT_OPENER,
            act.CREATED_DATE AS ACT_CREATED_DATE,
            act.RECORD_TYPE_ID AS ACT_RECORD_TYPE_ID,
            rcd.NAME AS ACT_RECORD_TYPE_ID_NAME,
            act.MARKETING_LIFECYCLE_AT_SUSPECT__C AS ACT_MARKETING_LIFECYCLE_AT_SUSPECT__C,
            act.BUYING_STAGE_AT_SUSPECT__C AS ACT_BUYING_STAGE_AT_SUSPECT__C,
            act.MARKETING_LIFECYCLE__C AS ACT_MARKETING_LIFECYCLE__C,
            act.BUSINESS_UNIT_2020__C AS ACT_BUSINESS_UNIT_2020__C,
            act.BUSINESS_UNIT_DIVISION__C AS ACT_BUSINESS_UNIT_DIVISION__C,
           -- act.BILLING_MODEL__C as ACT_BILLING_MODEL__C,
            act.MARKET__C AS ACT_MARKET__C,
            act.FLEET_SIZE__C AS ACT_FLEET_SIZE__C,
            act.MARKET_SEGMENT__C AS ACT_MARKET_SEGMENT__C,
            act.INDUSTRY AS ACT_INDUSTRY,
            act.INDUSTRY_DB__C AS ACT_INDUSTRY_DB__C,
            act.INDUSTRY_SECTOR__C AS ACT_INDUSTRY_SECTOR__C,
            act.TERRITORY__C AS ACT_TERRITORY__C,
            act.GEOGRAPHIC_REGION__C AS ACT_GEOGRAPHIC_REGION__C,
            act.STATE_DB__C AS ACT_STATE_DB__C,
            act.ACCOUNT_PROFILE_FIT6SENSE__C AS ACT_ACCOUNT_PROFILE_FIT6SENSE__C,
            act.ACCOUNT_PROFILE_SCORE6SENSE__C AS ACT_ACCOUNT_PROFILE_SCORE6SENSE__C,
            act.INTERNAL_TEST_ACCOUNT__C AS ACT_INTERNAL_TEST_ACCOUNT__C,
            act.ROUTING_REASON__C AS ACT_ROUTING_REASON__C,
            act.MIGRATION_RETURN_TO_MARKETING_REASON__C AS ACT_MIGRATION_RETURN_TO_MARKETING_REASON__C,
            act.STATUS__C AS ACT_STATUS__C,
			act.BUYER_TYPE__C as ACT_BUYER_TYPE__C,
			act.BILLING_MODEL__C AS ACT_BILLING_MODEL__C,
			act.REGION__C AS ACT_REGION__C,
			act.BILLING_STATE AS ACT_BILLING_STATE,
            CASE
                WHEN act.STATUS__C IN (
                    'Data Review',
                    'Initial Trial',
                    'Initial Trial Pending',
                    'Prospect',
                    'Suspect'
                ) THEN 'Active with Sales'
                WHEN act.STATUS__C IN (
                    'Client',
                    'Pending Client',
                    'Pending Client - Contract Signed'
                ) THEN 'Client'
                WHEN act.STATUS__C IN (
                    'Prospect Nuture',
                    'Recycle',
                    'Suspect Nurture',
                    'Suspect Nuture'
                ) THEN 'Marketing Engagement'
                WHEN act.STATUS__C IN (
                    'Active',
                    'Inactive',
                    'Industry Org',
                    'Non-Contractual',
                    'Other'
                ) THEN 'Other/NA'
                WHEN act.STATUS__C IN (
                    'Pending Forward Consent',
                    'Referred to Partner'
                ) THEN 'Referred to Partner'
                WHEN act.STATUS__C IN (
                    'SERVICE SUSPENDED',
                    'SERVICE TERMINATED',
                    'Terminated'
                ) THEN 'Service Terminated'
                WHEN act.STATUS__C IN (
                    'DOA',
                    'Duplicate',
                    'Duplicate - 6Sense',
                    'Out of Business',
                    'Unqualified'
                ) THEN 'Unqualified'
            END AS ACT_STATUS_GROUP,
            act.UNQUALIFIED_REASON__C AS ACT_UNQUALIFIED_REASON__C,
            -- Account Journey Pathx
            act_journey.AMLH_NAME,
            act_journey.ACCOUNT__C AS AMLH_ACCOUNT__C,
            act_journey.RECYCLE_COUNTER__C AS AMLH_RECYCLE_COUNTER__C,
            act_journey.CREATED_DATE AS AMLH_CREATED_DATE,
            act_journey.ACTIVE_MARKETING_LIFECYCLE_RECORD__C AS AMLH_ACTIVE_MARKETING_LIFECYCLE_RECORD__C,
            act_journey.MARKETING_LIFECYCLE_AT_SUSPECT__C AS AMLH_MARKETING_LIFECYCLE_AT_SUSPECT__C,
            act_journey.BUYING_STAGE_AT_SUSPECT__C AS AMLH_BUYING_STAGE_AT_SUSPECT__C,
            act_journey.ROUTING_REASON__C AS AMLH_ROUTING_REASON__C,
            act_journey.UNQUALIFIED_REASON__C AS AMLH_UNQUALIFIED_REASON__C,
            act_journey.OPPORTUNITY__C AS AMLH_OPPORTUNITY__C,
            act_journey.ACT_JOURNEY_PATH AS AMLH_ACT_JOURNEY_PATH,
            act_journey.ACT_JOURNEY_PATH_CNT AS AMLH_ACT_JOURNEY_PATH_CNT,
            act_journey.ACT_JOURNEY_PATH_ID AS AMLH_ACT_JOURNEY_PATH_ID,
            act_journey.ACCOUNT_JOURNEY_PATH_LIFECYCLE_NONLINEAR_FLAG AS AMLH_ACCOUNT_JOURNEY_PATH_LIFECYCLE_NONLINEAR_FLAG,
            act_journey.ACCOUNT_JOURNEY_PATH_LIFECYCLE_NONLINEAR_FLAG_REASON AS AMLH_ACCOUNT_JOURNEY_PATH_LIFECYCLE_NONLINEAR_FLAG_REASON,
            -- Lifecycle Stages
            
            act.COLD_ACCOUNT_DATE_STAMP__C as ACT_COLD_ACCOUNT_DATE_STAMP__C,
            CAST(act.COLD_ACCOUNT_DATE_STAMP__C as DATE) AS ACT_COLD_ACCOUNT_DATE_STAMP__C_CAST,
            amlh_raw.COLD_ACCOUNT_DATE_STAMP__C AS AMLH_COLD_ACCOUNT_DATE_STAMP__C,
            CAST(amlh_raw.COLD_ACCOUNT_DATE_STAMP__C as DATE) AS AMLH_COLD_ACCOUNT_DATE_STAMP__C_CAST,
            
            cast(date_trunc('week',amlh_raw.COLD_ACCOUNT_DATE_STAMP__C) + '6 days'::interval as date) as AMLH_COLD_ACCOUNT_DATE_EOW,
			last_day(amlh_raw.COLD_ACCOUNT_DATE_STAMP__C) as AMLH_COLD_ACCOUNT_DATE_EOM,
			cast(dateadd(day, -1, dateadd(QTR,1,DATE_TRUNC('QTR', amlh_raw.COLD_ACCOUNT_DATE_STAMP__C)))as date) as AMLH_COLD_ACCOUNT_DATE_EOQ,
			cast(dateadd(day, -1, dateadd(year, 1, DATE_TRUNC('year', amlh_raw.COLD_ACCOUNT_DATE_STAMP__C)))as date) as AMLH_COLD_ACCOUNT_DATE_EOY,
		
            act.MEA_DATE_STAMP__C as ACT_MEA_DATE_STAMP__C,
            CAST(act.MEA_DATE_STAMP__C as DATE) AS ACT_MEA_DATE_STAMP__C_CAST,
            amlh_raw.MEA_DATE_STAMP__C AS AMLH_MEA_DATE_STAMP__C,
            CAST(amlh_raw.MEA_DATE_STAMP__C as DATE) AS AMLH_MEA_DATE_STAMP__C_CAST,
            
            cast(date_trunc('week',amlh_raw.MEA_DATE_STAMP__C) + '6 days'::interval as date) as AMLH_MEA_DATE_EOW,
			last_day(amlh_raw.MEA_DATE_STAMP__C) as AMLH_MEA_DATE_EOM,
			cast(dateadd(day, -1, dateadd(QTR,1,DATE_TRUNC('QTR', amlh_raw.MEA_DATE_STAMP__C)))as date) as AMLH_MEA_DATE_EOQ,
			cast(dateadd(day, -1, dateadd(year, 1, DATE_TRUNC('year', amlh_raw.MEA_DATE_STAMP__C)))as date) as AMLH_MEA_DATE_EOY,
            

            act.MQA_DATE_STAMP__C as ACT_MQA_DATE_STAMP__C,
            CAST(act.MQA_DATE_STAMP__C as DATE) AS ACT_MQA_DATE_STAMP__C_CAST,
            amlh_raw.MQA_DATE_STAMP__C AS AMLH_MQA_DATE_STAMP__C,
            CAST(amlh_raw.MQA_DATE_STAMP__C as DATE) AS AMLH_MQA_DATE_STAMP__C_CAST,

            cast(date_trunc('week',amlh_raw.MQA_DATE_STAMP__C) + '6 days'::interval as date) as AMLH_MQA_DATE_EOW,
			last_day(amlh_raw.MQA_DATE_STAMP__C) as AMLH_MQA_DATE_EOM,
			cast(dateadd(day, -1, dateadd(QTR,1,DATE_TRUNC('QTR', amlh_raw.MQA_DATE_STAMP__C)))as date) as AMLH_MQA_DATE_EOQ,
			cast(dateadd(day, -1, dateadd(year, 1, DATE_TRUNC('year', amlh_raw.MQA_DATE_STAMP__C)))as date) as AMLH_MQA_DATE_EOY,
            
            
            act.SUSPECT_DATE_STAMP__C as ACT_SUSPECT_DATE_STAMP__C,
            CAST(act.SUSPECT_DATE_STAMP__C as DATE) AS ACT_SUSPECT_DATE_STAMP__C_CAST,
            amlh_raw.SUSPECT_DATE_STAMP__C AS AMLH_SUSPECT_DATE_STAMP__C,
            CAST(amlh_raw.SUSPECT_DATE_STAMP__C as DATE) AS AMLH_SUSPECT_DATE_STAMP__C_CAST,
            
            cast(date_trunc('week',amlh_raw.SUSPECT_DATE_STAMP__C) + '6 days'::interval as date) as AMLH_SUSPECT_DATE_EOW,
			last_day(amlh_raw.SUSPECT_DATE_STAMP__C) as AMLH_SUSPECT_DATE_EOM,
			cast(dateadd(day, -1, dateadd(QTR,1,DATE_TRUNC('QTR', amlh_raw.SUSPECT_DATE_STAMP__C)))as date) as AMLH_SUSPECT_DATE_EOQ,
			cast(dateadd(day, -1, dateadd(year, 1, DATE_TRUNC('year', amlh_raw.SUSPECT_DATE_STAMP__C)))as date) as AMLH_SUSPECT_DATE_EOY,                     
  			
			
            act.SUSPECT_WORKING_DATE_STAMP__C as ACT_SUSPECT_WORKING_DATE_STAMP__C,
            CAST(act.SUSPECT_WORKING_DATE_STAMP__C as DATE) AS ACT_SUSPECT_WORKING_DATE_STAMP__C_CAST,
            amlh_raw.SUSPECT_WORKING_DATE_STAMP__C AS AMLH_SUSPECT_WORKING_DATE_STAMP__C,
            CAST(amlh_raw.SUSPECT_WORKING_DATE_STAMP__C as DATE) AS AMLH_SUSPECT_WORKING_DATE_STAMP__C_CAST,          
            
            
            cast(date_trunc('week',amlh_raw.SUSPECT_WORKING_DATE_STAMP__C) + '6 days'::interval as date) as AMLH_SUSPECT_WORKING_DATE_EOW,
			last_day(amlh_raw.SUSPECT_WORKING_DATE_STAMP__C) as AMLH_SUSPECT_WORKING_DATE_EOM,
			cast(dateadd(day, -1, dateadd(QTR,1,DATE_TRUNC('QTR', amlh_raw.SUSPECT_WORKING_DATE_STAMP__C)))as date) as AMLH_SUSPECT_WORKING_DATE_EOQ,
			cast(dateadd(day, -1, dateadd(year, 1, DATE_TRUNC('year', amlh_raw.SUSPECT_WORKING_DATE_STAMP__C)))as date) as AMLH_SUSPECT_WORKING_DATE_EOY,              
            
            
            act.PROSPECT_DATE_STAMP__C as ACT_PROSPECT_DATE_STAMP__C,
            CAST(act.PROSPECT_DATE_STAMP__C as DATE) AS ACT_PROSPECT_DATE_STAMP__C_CAST,
            amlh_raw.PROSPECT_DATE_STAMP__C AS AMLH_PROSPECT_DATE_STAMP__C,
            CAST(amlh_raw.PROSPECT_DATE_STAMP__C as DATE) AS AMLH_PROSPECT_DATE_STAMP__C_CAST,

            cast(date_trunc('week',amlh_raw.PROSPECT_DATE_STAMP__C) + '6 days'::interval as date) as AMLH_PROSPECT_DATE_EOW,
			last_day(amlh_raw.PROSPECT_DATE_STAMP__C) as AMLH_PROSPECT_DATE_EOM,
			cast(dateadd(day, -1, dateadd(QTR,1,DATE_TRUNC('QTR', amlh_raw.PROSPECT_DATE_STAMP__C)))as date) as AMLH_PROSPECT_DATE_EOQ,
			cast(dateadd(day, -1, dateadd(year, 1, DATE_TRUNC('year', amlh_raw.PROSPECT_DATE_STAMP__C)))as date) as AMLH_PROSPECT_DATE_EYW,             						
            
            act.CUSTOMER_DATE_STAMP__C as ACT_CUSTOMER_DATE_STAMP__C,
            CAST(act.CUSTOMER_DATE_STAMP__C as DATE) AS ACT_CUSTOMER_DATE_STAMP__C_CAST,
            amlh_raw.CUSTOMER_DATE_STAMP__C AS AMLH_CUSTOMER_DATE_STAMP__C,
            CAST(amlh_raw.CUSTOMER_DATE_STAMP__C as DATE) AS AMLH_CUSTOMER_DATE_STAMP__C_CAST,
  
            cast(date_trunc('week',amlh_raw.CUSTOMER_DATE_STAMP__C) + '6 days'::interval as date) as AMLH_CUSTOMER_DATE_EOW,
			last_day(amlh_raw.CUSTOMER_DATE_STAMP__C) as AMLH_CUSTOMER_DATE_EOM,
			cast(dateadd(day, -1, dateadd(QTR,1,DATE_TRUNC('QTR', amlh_raw.CUSTOMER_DATE_STAMP__C)))as date) as AMLH_CUSTOMER_DATE_EOQ,
			cast(dateadd(day, -1, dateadd(year, 1, DATE_TRUNC('year', amlh_raw.CUSTOMER_DATE_STAMP__C)))as date) as AMLH_CUSTOMER_DATE_EOY,            
            
            act.RECYCLED_DATE_STAMP__C as ACT_RECYCLED_DATE_STAMP__C,
            CAST(act.RECYCLED_DATE_STAMP__C as DATE) AS ACT_RECYCLED_DATE_STAMP__C_CAST,
            amlh_raw.RECYCLE_DATE_STAMP__C AS AMLH_RECYCLED_DATE_STAMP__C,
            CAST(amlh_raw.RECYCLE_DATE_STAMP__C as DATE) AS AMLH_RECYCLED_DATE_STAMP__C_CAST,
  
            cast(date_trunc('week',amlh_raw.RECYCLE_DATE_STAMP__C) + '6 days'::interval as date) as AMLH_RECYCLED_DATE_EOW,
			last_day(amlh_raw.RECYCLE_DATE_STAMP__C) as AMLH_RECYCLED_DATE_EOM,
			cast(dateadd(day, -1, dateadd(QTR,1,DATE_TRUNC('QTR', amlh_raw.RECYCLE_DATE_STAMP__C)))as date) as AMLH_RECYCLED_DATE_EOQ,
			cast(dateadd(day, -1, dateadd(year, 1, DATE_TRUNC('year', amlh_raw.RECYCLE_DATE_STAMP__C)))as date) as AMLH_RECYCLED_DATE_EOY,              
            
            act.UNQUALIFIED_DATE_STAMP__C as ACT_UNQUALIFIED_DATE_STAMP__C,
            CAST(act.UNQUALIFIED_DATE_STAMP__C as DATE) AS ACT_UNQUALIFIED_DATE_STAMP__C_CAST,
            amlh_raw.UNQUALIFIED_DATE_STAMP__C AS AMLH_UNQUALIFIED_DATE_STAMP__C,
            CAST(amlh_raw.UNQUALIFIED_DATE_STAMP__C as DATE) AS AMLH_UNQUALIFIED_DATE_STAMP__C_CAST,
            
            cast(date_trunc('week',amlh_raw.UNQUALIFIED_DATE_STAMP__C) + '6 days'::interval as date) as AMLH_UNQUALIFIED_DATE_EOW,
			last_day(amlh_raw.UNQUALIFIED_DATE_STAMP__C) as AMLH_UNQUALIFIED_DATE_EOM,
			cast(dateadd(day, -1, dateadd(QTR,1,DATE_TRUNC('QTR', amlh_raw.UNQUALIFIED_DATE_STAMP__C)))as date) as AMLH_UNQUALIFIED_DATE_EOQ,
			cast(dateadd(day, -1, dateadd(year, 1, DATE_TRUNC('year', amlh_raw.UNQUALIFIED_DATE_STAMP__C)))as date) as AMLH_UNQUALIFIED_DATE_EOY,                         
            
            amlh_raw.RECYCLE_EXP_DATE__C AS AMLH_RECYCLE_EXP_DATE__C,
            CAST(amlh_raw.RECYCLE_EXP_DATE__C as DATE) AS AMLH_RECYCLE_EXP_DATE__C_CAST,
            
            cast(date_trunc('week',amlh_raw.RECYCLE_EXP_DATE__C) + '6 days'::interval as date) as AMLH_RECYCLE_EXP_DATE__C_EOW,
			last_day(amlh_raw.RECYCLE_EXP_DATE__C) as AMLH_RECYCLE_EXP_DATE__C_EOM,
			cast(dateadd(day, -1, dateadd(QTR,1,DATE_TRUNC('QTR', amlh_raw.RECYCLE_EXP_DATE__C)))as date) as AMLH_RECYCLE_EXP_DATE__C_EOQ,
			cast(dateadd(day, -1, dateadd(year, 1, DATE_TRUNC('year', amlh_raw.RECYCLE_EXP_DATE__C)))as date) as AMLH_RECYCLE_EXP_DATE__C_EOY,             
            

            -- Lifecycle Stage Flags
            (
                CASE
                    WHEN amlh_raw.RECYCLE_DATE_STAMP__C IS NOT NULL THEN 'Recycled'
                    ELSE 'New'
                END
            ) AS AMLH_RECYCLED_VS_NEW_FLAG,
            CASE
                WHEN amlh_raw.MARKETING_LIFECYCLE_AT_SUSPECT__C IS NOT NULL THEN 1
                ELSE 0
            END AS AMLH_FLAG_HAS_MARKETING_LIFECYCLE_AT_SUSPECT__C,
            (
                CASE
                    WHEN amlh_raw.COLD_ACCOUNT_DATE_STAMP__C IS NOT NULL THEN 1
                    ELSE 0
                END
            ) AS AMLH_ACCOUNT_LIFECYCLE_COLD_FLAG,
            (
                CASE
                    WHEN amlh_raw.MEA_DATE_STAMP__C IS NOT NULL THEN 1
                    ELSE 0
                END
            ) AS AMLH_ACCOUNT_LIFECYCLE_MEA_FLAG,
            (
                CASE
                    WHEN amlh_raw.MQA_DATE_STAMP__C IS NOT NULL THEN 1
                    ELSE 0
                END
            ) AS AMLH_ACCOUNT_LIFECYCLE_MQA_FLAG,
            (
                CASE
                    WHEN amlh_raw.SUSPECT_DATE_STAMP__C IS NOT NULL THEN 1
                    ELSE 0
                END
            ) AS AMLH_ACCOUNT_LIFECYCLE_SUSPECT_FLAG,
            (
                CASE
                    WHEN amlh_raw.SUSPECT_WORKING_DATE_STAMP__C IS NOT NULL THEN 1
                    ELSE 0
                END
            ) AS AMLH_ACCOUNT_LIFECYCLE_SUSPECT_WORKING_FLAG,
            (
                CASE
                    WHEN amlh_raw.PROSPECT_DATE_STAMP__C IS NOT NULL THEN 1
                    ELSE 0
                END
            ) AS AMLH_ACCOUNT_LIFECYCLE_PROSPECT_FLAG,
            (
                CASE
                    WHEN amlh_raw.CUSTOMER_DATE_STAMP__C IS NOT NULL THEN 1
                    ELSE 0
                END             
            
            ) AS AMLH_ACCOUNT_LIFECYCLE_CUSTOMER_FLAG,
            (
                CASE
                    WHEN amlh_raw.RECYCLE_DATE_STAMP__C IS NOT NULL THEN 1
                    ELSE 0
                END
            ) AS AMLH_ACCOUNT_LIFECYCLE_RECYCLED_FLAG,
            (
                CASE
                    WHEN amlh_raw.UNQUALIFIED_DATE_STAMP__C IS NOT NULL THEN 1
                    ELSE 0
                END
            ) AS AMLH_ACCOUNT_LIFECYCLE_UNQUALIFIED_FLAG,
            (
                CASE
                    WHEN DATEDIFF(MINUTE, amlh_raw.SUSPECT_DATE_STAMP__C, amlh_raw.MQA_DATE_STAMP__C) between 0 and 2 THEN 1
                    ELSE 0
                END 
            ) AS AMLH_ACCOUNT_LIFECYCLE_SUSPECT_MQA_TIMESTAMP_FLAG,
            CASE
                WHEN amlh_raw.MARKETING_LIFECYCLE_AT_SUSPECT__C IS NULL THEN 'Not Eligible: No Lifecycle'
                WHEN (
                    CASE
                        WHEN amlh_raw.MARKETING_LIFECYCLE_AT_SUSPECT__C IS NULL THEN NULL
                        WHEN amlh_raw.MARKETING_LIFECYCLE_AT_SUSPECT__C = 'Cold Account' THEN amlh_raw.COLD_ACCOUNT_DATE_STAMP__C
                        WHEN amlh_raw.MARKETING_LIFECYCLE_AT_SUSPECT__C = 'MEA' THEN amlh_raw.MEA_DATE_STAMP__C
                        WHEN amlh_raw.MARKETING_LIFECYCLE_AT_SUSPECT__C = 'MQA' THEN amlh_raw.MQA_DATE_STAMP__C
                        WHEN amlh_raw.MARKETING_LIFECYCLE_AT_SUSPECT__C = 'Suspect Working' THEN amlh_raw.SUSPECT_WORKING_DATE_STAMP__C
                        WHEN amlh_raw.MARKETING_LIFECYCLE_AT_SUSPECT__C = 'Recycled' THEN amlh_raw.RECYCLE_DATE_STAMP__C
                        WHEN amlh_raw.MARKETING_LIFECYCLE_AT_SUSPECT__C = 'Unqualified' THEN amlh_raw.UNQUALIFIED_DATE_STAMP__C
                    END
                ) -- AS COMPARE_DATE,
                > amlh_raw.SUSPECT_DATE_STAMP__C THEN 'Not Eligible: Lifecycle > Suspect Date'
                WHEN (
                    amlh_raw.MARKETING_LIFECYCLE_AT_SUSPECT__C IS NOT NULL
                    AND amlh_raw.SUSPECT_DATE_STAMP__C IS NULL
                ) THEN 'Eligible: No Suspect Date'
                WHEN (
                    amlh_raw.MARKETING_LIFECYCLE_AT_SUSPECT__C IS NOT NULL
                    AND amlh_raw.SUSPECT_DATE_STAMP__C IS NOT NULL
                ) THEN 'Eligible: Has  Suspect Date'
                ELSE 'Other'
            END AS AMLH_FLAG_TO_CHECK,
            -- Parent Account Info
            (
                CASE
                    WHEN (act.PARENT_ID IS NULL) THEN 0
                    ELSE 1
                END
            ) AS ACT_HAS_PARENT_ACT_FLAG,
            (
                CASE
                    WHEN (act.PARENT_ID = '000000000000000AAA') THEN 1
                    ELSE 0
                END
            ) AS ACT_PARENT_ACT_FLAG,
            act.PARENT_ID AS ACT_PARENT_ID,
            parent_act.PARENT_ACT_IS_DELETED,
            parent_act.PARENT_ACT_NAME,
            parent_act.PARENT_ACT_CREATED_DATE,
            parent_act.PARENT_ACT_RECORD_TYPE_ID,
            parent_act.PARENT_ACT_RECORD_TYPE_ID_NAME,
            parent_act.PARENT_ACT_MARKETING_LIFECYCLE_AT_SUSPECT__C,
            parent_act.PARENT_ACT_MARKETING_LIFECYCLE__C,
            parent_act.PARENT_ACT_BUSINESS_UNIT_2020__C,
            parent_act.PARENT_ACT_BUSINESS_UNIT_DIVISION__C,
            parent_act.PARENT_ACT_MARKET__C,
            parent_act.PARENT_ACT_FLEET_SIZE__C,
            parent_act.PARENT_ACT_MARKET_SEGMENT__C,
            parent_act.PARENT_ACT_INDUSTRY,
            parent_act.PARENT_ACT_INDUSTRY_DB__C,
            parent_act.PARENT_ACT_INDUSTRY_SECTOR__C,
            parent_act.PARENT_ACT_TERRITORY__C,
            parent_act.PARENT_ACT_STATE_DB__C,
            parent_act.PARENT_ACT_ACCOUNT_PROFILE_FIT6SENSE__C,
            parent_act.PARENT_ACT_ACCOUNT_PROFILE_SCORE6SENSE__C
        FROM
            DP_PROD_DB.SALESFORCE.ACCOUNT AS act
            LEFT JOIN DP_PROD_DB.SALESFORCE.USER usr 
				ON act.owner_id = usr.ID
                AND usr.NAME NOT IN ('Scott Rose', 'Rick Walters', 'Micah Rea', 'Compliance', 'ELD Compliance Manager')
            -- ACT OWNER USER ROLE
            LEFT JOIN DP_PROD_DB.SALESFORCE.USER_ROLE usr_role 
				ON usr.USER_ROLE_ID = usr_role.ID
			LEFT JOIN DP_PROD_DB.SALESFORCE.USER usro
				ON act.OPENER__C = usro.ID 
                AND usro.NAME NOT IN ('Scott Rose', 'Rick Walters', 'Micah Rea', 'Compliance', 'ELD Compliance Manager')              
            -- Record Type
            INNER JOIN DP_PROD_DB.SALESFORCE.RECORD_TYPE as rcd ON act.RECORD_TYPE_ID = rcd.ID
            AND (
                rcd.ID = '012300000005VEYAA2'
                OR rcd.ID = '0126R000001UknZQAS'
            )
            -- Parent Account
            LEFT JOIN (
                -- Parent Account Information
                SELECT
                    DISTINCT act.ID,
                    parent_act.PARENT_ID,
                    parent_act.IS_DELETED as PARENT_ACT_IS_DELETED,
                    parent_act.NAME as PARENT_ACT_NAME,
                    parent_act.CREATED_DATE as PARENT_ACT_CREATED_DATE,
                    parent_act.RECORD_TYPE_ID as PARENT_ACT_RECORD_TYPE_ID,
                    rcd.NAME as PARENT_ACT_RECORD_TYPE_ID_NAME,
                    parent_act.MARKETING_LIFECYCLE_AT_SUSPECT__C as PARENT_ACT_MARKETING_LIFECYCLE_AT_SUSPECT__C,
                    parent_act.MARKETING_LIFECYCLE__C as PARENT_ACT_MARKETING_LIFECYCLE__C,
                    parent_act.BUSINESS_UNIT_2020__C as PARENT_ACT_BUSINESS_UNIT_2020__C,
                    parent_act.BUSINESS_UNIT_DIVISION__C as PARENT_ACT_BUSINESS_UNIT_DIVISION__C,
                    parent_act.MARKET__C as PARENT_ACT_MARKET__C,
                    parent_act.FLEET_SIZE__C as PARENT_ACT_FLEET_SIZE__C,
                    parent_act.MARKET_SEGMENT__C as PARENT_ACT_MARKET_SEGMENT__C,
                    parent_act.INDUSTRY as PARENT_ACT_INDUSTRY,
                    parent_act.INDUSTRY_DB__C as PARENT_ACT_INDUSTRY_DB__C,
                    parent_act.INDUSTRY_SECTOR__C as PARENT_ACT_INDUSTRY_SECTOR__C,
                    parent_act.TERRITORY__C as PARENT_ACT_TERRITORY__C,
                    parent_act.STATE_DB__C as PARENT_ACT_STATE_DB__C,
                    parent_act.ACCOUNT_PROFILE_FIT6SENSE__C as PARENT_ACT_ACCOUNT_PROFILE_FIT6SENSE__C,
                    parent_act.ACCOUNT_PROFILE_SCORE6SENSE__C as PARENT_ACT_ACCOUNT_PROFILE_SCORE6SENSE__C
                FROM
                    DP_PROD_DB.SALESFORCE.ACCOUNT AS act
                    LEFT JOIN DP_PROD_DB.SALESFORCE.ACCOUNT as parent_act ON act.PARENT_ID = parent_act.ID
                    LEFT JOIN DP_PROD_DB.SALESFORCE.RECORD_TYPE as rcd ON parent_act.RECORD_TYPE_ID = rcd.ID
            ) as parent_act ON act.ID = parent_act.ID
            RIGHT OUTER JOIN (               

				SELECT
                    act_journey_prep.ACCOUNT__C,
                    act_journey_prep.RECYCLE_COUNTER__C,
                    act_journey_prep.CREATED_DATE,
                    act_journey_prep.ACTIVE_MARKETING_LIFECYCLE_RECORD__C,
                    act_journey_prep.MARKETING_LIFECYCLE_AT_SUSPECT__C,
                    act_journey_prep.BUYING_STAGE_AT_SUSPECT__C,
                    act_journey_prep.ROUTING_REASON__C,
                    act_journey_prep.UNQUALIFIED_REASON__C,
                    act_journey_prep.OPPORTUNITY__C,
                    act_journey_prep.ACCOUNT_JOURNEY_PATH_LIFECYCLE_NONLINEAR_FLAG_REASON,
                    act_journey_prep.ACCOUNT_JOURNEY_PATH_LIFECYCLE_NONLINEAR_FLAG,
                    act_journey_prep.ACT_JOURNEY_PATH_CNT,
                    act_journey_prep.NAME AS AMLH_NAME,                    
                        'COLD ' ||
                        cast(cold AS char(4)) ||
                        ' --> '||                        
                        'MEA '||
                        cast(mea as char(4)) ||
                        ' --> ' ||
                        'MQA ' ||
                        cast(mqa AS char(4)) ||
                        ' --> ' ||
                        'SUS ' ||
                        cast(suspect AS char(4)) ||
                        ' --> '||
                        'S_W ' ||
                        cast(suspect_working AS char(4)) ||
                        ' --> ' ||
                        'PROS ' ||
                        cast(prospect AS char(4)) ||
                        ' --> ' ||
                        'CUST ' ||
                        cast(customer AS char(4)) ||
                        ' --> ' ||
                        'REC ' ||
                        cast(recycled AS char(4)) ||
                        ' --> ' ||
                        'UNQ ' ||
                        cast(unqualified AS char(4))
                     AS act_journey_path,
                        cast(cold AS char(4)) ||
                        ' --> ' ||                        
                        cast(mea as char(4)) ||
                        ' --> ' ||
                        cast(mqa AS char(4)) ||
                        ' --> ' ||
                        cast(suspect AS char(4)) ||
                        ' --> '||
                        cast(suspect_working AS char(4)) ||
                        ' --> ' ||
                        cast(prospect AS char(4)) ||
                        ' --> ' ||
                        cast(customer AS char(4)) ||
                        ' --> ' ||
                        cast(recycled AS char(4)) ||
                        ' --> ' ||
                        cast(unqualified AS char(4))
                     AS act_journey_path_id                
                     

                FROM
                    (                       
                        
SELECT
                            x.ACCOUNT__C,
                            x.RECYCLE_COUNTER__C,
                            x.CREATED_DATE,
                            x.ACTIVE_MARKETING_LIFECYCLE_RECORD__C,
                            x.MARKETING_LIFECYCLE_AT_SUSPECT__C,
                            x.BUYING_STAGE_AT_SUSPECT__C,
                            x.ROUTING_REASON__C,
                            x.UNQUALIFIED_REASON__C,
                            x.OPPORTUNITY__C,
                            x.NAME,
                            x.account_journey_path_lifecycle_nonlinear_flag_reason,
                            x.account_journey_path_lifecycle_nonlinear_flag,
                            coalesce(x.cold_order, 0) as cold,
                            coalesce(x.mea_order, 0) as mea,
                            coalesce(x.mqa_order, 0) as mqa,
                            coalesce(x.suspect_order, 0) as suspect,
                            coalesce(x.suspect_working_order, 0) as suspect_working,
                            coalesce(x.prospect_order, 0) as prospect,
                            coalesce(x.customer_order, 0) as customer,
                            coalesce(x.recycled_order, 0) as recycled,
                            coalesce(x.unqualified_order, 0) as unqualified,
                            x.journey_length AS ACT_JOURNEY_PATH_CNT
                        from
                        (

                               SELECT
                                    DISTINCT 
                                    ACCOUNT__C,
                                    RECYCLE_COUNTER__C,
                                    CREATED_DATE,
                                    ACTIVE_MARKETING_LIFECYCLE_RECORD__C,
                                    MARKETING_LIFECYCLE_AT_SUSPECT__C,
                                    BUYING_STAGE_AT_SUSPECT__C,
                                    ROUTING_REASON__C,
                                    UNQUALIFIED_REASON__C,
                                    OPPORTUNITY__C,
                                    Name,
                                    CASE
                                        WHEN cold_order IS NULL
                                        OR mea_order = 1
                                        OR mqa_order = 1
                                        OR suspect_order = 1
                                        OR suspect_working_order = 1
                                        OR prospect_order = 1 
                                        OR customer_order = 1
                                        OR recycled_order = 1
                                        OR unqualified_order = 1
                                        OR prospect_order = cold_order + 1
                                        OR (
                                            recycled_order = cold_order + 1
                                            AND journey_length <> 2
                                        )
                                        OR (
                                            unqualified_order = cold_order + 1
                                            AND journey_length <> 2
                                        ) 
                                        OR (
                                            customer_order = cold_order + 1
                                            AND journey_length <> 2
                                        )
                                        OR suspect_order = recycled_order + 1
                                        OR suspect_order = unqualified_order + 1 
                                        OR customer_order = unqualified_order + 1
                                        OR unqualified_order = customer_order + 1
                                        OR (
                                            suspect_order > prospect_order
                                        )
                                        OR (
                                            recycled_order < journey_length
                                        )
                                        OR (
                                            unqualified_order < journey_length
                                        )
                                        OR (
                                            customer_order < journey_length
                                                        )
                                        OR (
                                            mea_order > mqa_order
                                        )
                                        OR (
                                            suspect_order IS NULL
                                            AND prospect_order IS NOT NULL
                                        )
                                        OR (
                                            mqa_order IS NOT NULL
                                            AND mea_order IS NULL
                                        )
                                        THEN 'Non-Linear'
                                        ELSE 'Linear'
                                    END AS ACCOUNT_JOURNEY_PATH_LIFECYCLE_NONLINEAR_FLAG,
                                    cold_order,
                                    mea_order,
                                    mqa_order,
                                    suspect_order,
                                    suspect_working_order,
                                    prospect_order,
                                    customer_order,
                                    recycled_order,
                                    unqualified_order,
                                    journey_length,
                                    CASE
                                        WHEN cold_order IS NULL THEN 'cold_order IS NULL'
                                        WHEN mea_order = 1 THEN 'mea_order = 1'
                                        WHEN mqa_order = 1 THEN 'mqa_order = 1'
                                        WHEN suspect_order = 1 THEN 'suspect_order = 1'
                                        WHEN suspect_working_order = 1 THEN 'suspect_working_order = 1'
                                        WHEN prospect_order = 1 THEN 'prospect_order = 1' 
                                        WHEN customer_order = 1 THEN 'customer_order = 1'
                                        WHEN recycled_order = 1 THEN 'recycled_order = 1'
                                        WHEN unqualified_order = 1 THEN 'unqualified_order = 1'
                                        WHEN prospect_order = cold_order + 1 THEN 'prospect_order = cold_order + 1'
                                        WHEN (recycled_order = cold_order + 1 AND journey_length <> 2) THEN 'cold, recycle, more'
                                        WHEN (unqualified_order = cold_order + 1 AND journey_length <> 2) THEN 'cold, unqualifed, more'
                                        WHEN (customer_order = cold_order + 1 AND journey_length <> 2) THEN 'cold, customer, more'
                                        WHEN suspect_order = recycled_order + 1 THEN 'suspect_order = recycled_order + 1'
                                        WHEN suspect_order = unqualified_order + 1 THEN 'suspect_order = unqualified_order + 1'
                                        WHEN customer_order = unqualified_order + 1 THEN 'customer_order = unqualified_order + 1'
                                        WHEN unqualified_order = customer_order + 1 THEN 'unqualified_order = customer_order + 1'
                                        WHEN recycled_order < journey_length THEN 'recycled_order < journey_length '
                                        WHEN unqualified_order < journey_length THEN 'unqualified_order < journey_length' 
                                        WHEN customer_order < journey_length THEN 'customer_order < journey_length'
                                        WHEN mea_order > mqa_order THEN 'mea_order > mqa_order'
                                        WHEN (
                                            suspect_order IS NULL
                                            AND prospect_order IS NOT NULL
                                        ) THEN 'suspect_order IS NULL & prospect_order IS NOT NULL'
                                        WHEN (
                                            mqa_order IS NOT NULL
                                            AND mea_order IS NULL
                                        ) THEN 'mqa_order IS NOT NULL & mea_order IS NULL'
                                        ELSE 'Linear'
                                    END AS ACCOUNT_JOURNEY_PATH_LIFECYCLE_NONLINEAR_FLAG_REASON
                                FROM
                                    (                                       


                                        SELECT
                                            *,
                                            CASE
                                                WHEN cold_place = 0 THEN NULL
                                                ELSE cold_place
                                            END AS cold_order,
                                            CASE
                                                WHEN mea_place = 0 THEN NULL
                                                ELSE mea_place
                                            END AS mea_order,
                                            CASE
                                                WHEN mqa_place = 0 THEN NULL
                                                ELSE mqa_place
                                            END AS mqa_order,
                                            CASE
                                                WHEN suspect_place = 0 THEN NULL
                                                ELSE suspect_place
                                            END AS suspect_order,
                                            CASE
                                                WHEN suspect_working_place = 0 THEN NULL
                                                ELSE suspect_working_place
                                            END AS suspect_working_order,
                                            CASE
                                                WHEN prospect_place = 0 THEN NULL
                                                ELSE prospect_place
                                            END AS prospect_order,
                                            CASE
                                                WHEN customer_place = 0 THEN NULL
                                                ELSE customer_place
                                            END AS customer_order,
                                            CASE
                                                WHEN recycled_place = 0 THEN NULL
                                                ELSE recycled_place
                                            END AS recycled_order,
                                            CASE
                                                WHEN unqualified_place = 0 THEN NULL
                                                ELSE unqualified_place
                                            END AS unqualified_order
                                        FROM

                                        (
                                        SELECT 
                                                    DISTINCT 
                                                    ACCOUNT__C,
                                                    RECYCLE_COUNTER__C,
                                                    CREATED_DATE,
                                                    ACTIVE_MARKETING_LIFECYCLE_RECORD__C,
                                                    MARKETING_LIFECYCLE_AT_SUSPECT__C,
                                                    BUYING_STAGE_AT_SUSPECT__C,
                                                    ROUTING_REASON__C,
                                                    UNQUALIFIED_REASON__C,
                                                    OPPORTUNITY__C,
                                                    Name,
                                                    --created_date,
                                                    COLD_ACCOUNT_DATE_STAMP__CAST AS cold_place,
                                                    MEA_DATE_STAMP__CAST AS mea_place,
                                                    MQA_DATE_STAMP__CAST AS mqa_place,
                                                    SUSPECT_DATE_STAMP__CAST AS suspect_place,
                                                    SUSPECT_WORKING_DATE_STAMP__CAST AS suspect_working_place,
                                                    PROSPECT_DATE_STAMP__CAST AS prospect_place,
                                                    CUSTOMER_DATE_STAMP__CAST AS customer_place,
                                                    RECYCLED_DATE_STAMP__CAST AS recycled_place,
                                                    UNQUALIFIED_DATE_STAMP__CAST AS unqualified_place,
                                                    CASE
                                                        WHEN cold_place > mea_place
                                                        AND cold_place > mqa_place
                                                        AND cold_place > suspect_place
                                                        AND cold_place > suspect_working_place
                                                        AND cold_place > prospect_place 
                                                        AND cold_place > customer_place
                                                        AND cold_place > recycled_place
                                                        AND cold_place > unqualified_place THEN cold_place
                                                        WHEN mea_place > cold_place
                                                        AND mea_place > mqa_place
                                                        AND mea_place > suspect_place
                                                        AND mea_place > suspect_working_place
                                                        AND mea_place > prospect_place 
                                                        AND mea_place > customer_place
                                                        AND mea_place > recycled_place
                                                        AND mea_place > unqualified_place THEN mea_place
                                                        WHEN mqa_place > cold_place
                                                        AND mqa_place > mea_place
                                                        AND mqa_place > suspect_place
                                                        AND mqa_place > suspect_working_place
                                                        AND mqa_place > prospect_place 
                                                        AND mqa_place > customer_place
                                                        AND mqa_place > recycled_place
                                                        AND mqa_place > unqualified_place THEN mqa_place
                                                        WHEN suspect_place > cold_place
                                                        AND suspect_place > mea_place
                                                        AND suspect_place > mqa_place
                                                        AND suspect_place > suspect_working_place
                                                        AND suspect_place > prospect_place 
                                                        AND suspect_place > customer_place
                                                        AND suspect_place > recycled_place
                                                        AND suspect_place > unqualified_place THEN suspect_place
                                                        WHEN suspect_working_place > cold_place
                                                        AND suspect_working_place > mea_place
                                                        AND suspect_working_place > mqa_place
                                                        AND suspect_working_place > suspect_place
                                                        AND suspect_working_place > prospect_place 
                                                        AND suspect_working_place > customer_place
                                                        AND suspect_working_place > recycled_place
                                                        AND suspect_working_place > unqualified_place THEN suspect_working_place
                                                        WHEN prospect_place > cold_place
                                                        AND prospect_place > mea_place
                                                        AND prospect_place > mqa_place
                                                        AND prospect_place > suspect_place
                                                        AND prospect_place > suspect_working_place 
                                                        AND prospect_place > customer_place
                                                        AND prospect_place > recycled_place
                                                        AND prospect_place > unqualified_place THEN prospect_place
                                                        WHEN customer_place > cold_place
                                                        AND customer_place > mea_place
                                                        AND customer_place > mqa_place
                                                        AND customer_place > suspect_place
                                                        AND customer_place > suspect_working_place
                                                        AND customer_place > suspect_place
                                                        AND customer_place > recycled_place
                                                        AND customer_place > unqualified_place THEN customer_place
                                                        WHEN recycled_place > cold_place
                                                        AND recycled_place > mea_place
                                                        AND recycled_place > mqa_place
                                                        AND recycled_place > suspect_place
                                                        AND recycled_place > suspect_working_place
                                                        AND recycled_place > prospect_place 
                                                        AND recycled_place > customer_place
                                                        AND recycled_place > unqualified_place THEN recycled_place
                                                        WHEN unqualified_place > cold_place
                                                        AND unqualified_place > mea_place
                                                        AND unqualified_place > mqa_place
                                                        AND unqualified_place > suspect_place
                                                        AND unqualified_place > suspect_working_place
                                                        AND unqualified_place > prospect_place 
                                                        AND unqualified_place > customer_place
                                                        AND unqualified_place > recycled_place THEN unqualified_place
                                                    END AS journey_length

FROM
(


                                                        SELECT
                                                            DISTINCT 
                                                            ACCOUNT__C,
                                                            RECYCLE_COUNTER__C,
                                                            CREATED_DATE,
                                                            ACTIVE_MARKETING_LIFECYCLE_RECORD__C,
                                                            MARKETING_LIFECYCLE_AT_SUSPECT__C,
                                                            BUYING_STAGE_AT_SUSPECT__C,
                                                            ROUTING_REASON__C,
                                                            UNQUALIFIED_REASON__C,
                                                            OPPORTUNITY__C,
                                                            Name,
                                                            --created_date,
                                                            lifecycle_date_stamp,
                                                            date_order
                                                            FROM
(
SELECT DISTINCT account__c,
                recycle_counter__c,
                created_date,
                active_marketing_lifecycle_record__c,
                marketing_lifecycle_at_suspect__c,
                buying_stage_at_suspect__c,
                routing_reason__c,
                unqualified_reason__c,
                opportunity__c,
                Name,
                --created_date,
                lifecycle_date_stamp,
                date_value ,
                CASE
                                WHEN TRUNC(date_value) >= '2222-01-01' THEN 0
                                ELSE date_order
                END AS date_order
FROM            (
                                SELECT DISTINCT account__c,
                                                recycle_counter__c,
                                                created_date,
                                                active_marketing_lifecycle_record__c,
                                                marketing_lifecycle_at_suspect__c,
                                                buying_stage_at_suspect__c,
                                                routing_reason__c,
                                                unqualified_reason__c,
                                                opportunity__c,
                                                Name,
                                                --created_date,
                                                lifecycle_date_stamp,
                                                date_value,
                                                Row_number() OVER ( partition BY account__c, recycle_counter__c, created_date, active_marketing_lifecycle_record__c --NAME
                                                ORDER BY date_value ) AS date_order
                                FROM            (
                                                                SELECT DISTINCT account__c,
                                                                                COALESCE(recycle_counter__c, 0) AS recycle_counter__c,
                                                                                created_date,
                                                                                active_marketing_lifecycle_record__c,
                                                                                marketing_lifecycle_at_suspect__c,
                                                                                buying_stage_at_suspect__c,
                                                                                routing_reason__c,
                                                                                unqualified_reason__c,
                                                                                opportunity__c,
                                                                                Name,
                                                                                --created_date,
                                                                                CASE
                                                                                                WHEN (
                                                                                                                                Cast(cold_account_date_stamp__cas AS DATE) = Cast(mea_date_stamp__cast AS DATE) ) THEN Dateadd(day, -1, cold_account_date_stamp__cas)
                                                                                                ELSE cold_account_date_stamp__cas
                                                                                END AS cold_account_date_stamp__cast,
                                                                                mea_date_stamp__cast,
                                                                                mqa_date_stamp__cast,
                                                                                CASE
                                                                                                WHEN (
                                                                                                                                Datediff( minute, suspect_date_stamp__cas, mqa_date_stamp__cast ) BETWEEN 0 AND             2 ) THEN Dateadd(minutes, 2, suspect_date_stamp__cas)
                                                                                                ELSE suspect_date_stamp__cas
                                                                                END AS suspect_date_stamp__cast,
                                                                                suspect_working_date_stamp__cast,
                                                                                prospect_date_stamp__cast,
                                                                                customer_date_stamp__cast,
                                                                                recycled_date_stamp__cast,
                                                                                unqualified_date_stamp__cast
                                                                FROM            (
                                                                                                SELECT DISTINCT account__c,
                                                                                                                COALESCE(recycle_counter__c, 0) AS recycle_counter__c,
                                                                                                                created_date,
                                                                                                                active_marketing_lifecycle_record__c,
                                                                                                                marketing_lifecycle_at_suspect__c,
                                                                                                                buying_stage_at_suspect__c,
                                                                                                                routing_reason__c,
                                                                                                                unqualified_reason__c,
                                                                                                                opportunity__c,
                                                                                                                Name,
                                                                                                                --created_date,
                                                                                                                COALESCE( cold_account_date_stamp__c, '2222-01-01 11:22:33.444' )    AS cold_account_date_stamp__cas,
                                                                                                                COALESCE( mea_date_stamp__c, '2222-01-01 11:22:33.444' )             AS mea_date_stamp__cast,
                                                                                                                COALESCE( mqa_date_stamp__c, '2222-01-01 11:22:33.444' )             AS mqa_date_stamp__cast,
                                                                                                                COALESCE( suspect_date_stamp__c, '2222-01-01 11:22:33.444' )         AS suspect_date_stamp__cas,
                                                                                                                COALESCE( suspect_working_date_stamp__c, '2222-01-01 11:22:33.444' ) AS suspect_working_date_stamp__cast,
                                                                                                                COALESCE( prospect_date_stamp__c, '2222-01-01 11:22:33.444' )        AS prospect_date_stamp__cast,
                                                                                                                COALESCE( customer_date_stamp__c, '2222-01-01 11:22:33.444' )        AS customer_date_stamp__cast,
                                                                                                                COALESCE( recycle_date_stamp__c, '2222-01-01 11:22:33.444' )         AS recycled_date_stamp__cast,
                                                                                                                COALESCE( unqualified_date_stamp__c, '2222-01-01 11:22:33.444' )     AS unqualified_date_stamp__cast
                                                                                                FROM
                                                                                                                --DP_PROD_DB.SALESFORCE.ACCOUNT_MARKETING_LIFECYCLE_HISTORY__C
                                                                                                                (
                                                                                                                       SELECT amlh_clean.*
                                                                                                                       FROM   (
                                                                                                                                              SELECT DISTINCT amlh.*
                                                                                                                                              FROM            dp_prod_db.salesforce.account_marketing_lifecycle_history__c AS amlh
                                                                                                                                              INNER JOIN
                                                                                                                                                              (
                                                                                                                                                                         SELECT     amlh_raw.account__c,
                                                                                                                                                                                    COALESCE(amlh_raw.recycle_counter__c, 0)                       AS recycle_counter__c,
                                                                                                                                                                                    Max(amlh_raw.created_date)                                   AS max_created_date,
                                                                                                                                                                                    Sum(1)                                                       AS cnt
                                                                                                                                                                         FROM       dp_prod_db.salesforce.account_marketing_lifecycle_history__c AS amlh_raw
                                                                                                                                                                         INNER JOIN dp_prod_db.salesforce.account                                AS act
                                                                                                                                                                         ON         amlh_raw.account__c = act.id -- Record Type
                                                                                                                                                                         INNER JOIN dp_prod_db.salesforce.record_type AS rcd
                                                                                                                                                                         ON         act.record_type_id = rcd.id
                                                                                                                                                                         AND        (
                                                                                                                                                                                               rcd.id = '012300000005VEYAA2'
                                                                                                                                                                                    OR         rcd.id = '0126R000001UknZQAS' )
                                                                                                                                                                         WHERE      amlh_raw.is_deleted = false
                                                                                                                                                                         AND        act.is_deleted = false
                                                                                                                                                                         AND        act.internal_test_account__c = false
                                                                                                                                                                         GROUP BY   1,
                                                                                                                                                                                    2 --HAVING SUM(1) > 1
                                                                                                                                                                         ORDER BY   1,
                                                                                                                                                                                    2 ) AS amlh_qa_acts
                                                                                                                                              ON              amlh.account__c = amlh_qa_acts.account__c
                                                                                                                                              AND             COALESCE(amlh.recycle_counter__c, 0) = amlh_qa_acts.recycle_counter__c
                                                                                                                                              AND             amlh.created_date = amlh_qa_acts.max_created_date
                                                                                                                                              WHERE           amlh.is_deleted = false
                                                                                                                                              ORDER BY        amlh.account__c,
                                                                                                                                                              COALESCE(amlh.recycle_counter__c, 0) ) AS amlh_clean ) --WHERE ACCOUNT__C = '0018000000y0AwLAAU'
                                                                                                ORDER BY        account__c,
                                                                                                                COALESCE(recycle_counter__c, 0) ) AS amlh_clean
                                                                                --WHERE ACCOUNT__C = '0018000000y0AwLAAU'
                                                                ORDER BY        account__c,
                                                                                COALESCE(recycle_counter__c, 0) ) UNPIVOT ( date_value for lifecycle_date_stamp IN ( cold_account_date_stamp__cast,
                                                                                                                                                                  mea_date_stamp__cast,
                                                                                                                                                                  mqa_date_stamp__cast,
                                                                                                                                                                  suspect_date_stamp__cast,
                                                                                                                                                                  suspect_working_date_stamp__cast,
                                                                                                                                                                  prospect_date_stamp__cast,
                                                                                                                                                                  customer_date_stamp__cast,
                                                                                                                                                                  recycled_date_stamp__cast,
                                                                                                                                                                  unqualified_date_stamp__cast ) ) )
)


                                                            --end prepare for pivot
)
                                                    PIVOT (
                                                        MAX(date_order) FOR lifecycle_date_stamp IN (
                                                            --this isn't really a "max", I need an agg fx to pivot so it's the max of a single value
                                                            'cold_account_date_stamp__cast',
                                                            'customer_date_stamp__cast',
                                                            'mea_date_stamp__cast',
                                                            'mqa_date_stamp__cast',
                                                            'suspect_date_stamp__cast',
                                                            'suspect_working_date_stamp__cast',
                                                            'prospect_date_stamp__cast',
                                                            'recycled_date_stamp__cast',
                                                            'unqualified_date_stamp__cast'
                                                        )
                                                    )
                                                    )
 
)
) as x
) as act_journey_prep
            ) as act_journey ON act.ID = act_journey.ACCOUNT__C
            INNER JOIN DP_PROD_DB.SALESFORCE.ACCOUNT_MARKETING_LIFECYCLE_HISTORY__C AS amlh_raw on act_journey.ACCOUNT__C = amlh_raw.ACCOUNT__C
            and act_journey.RECYCLE_COUNTER__C = coalesce(amlh_raw.RECYCLE_COUNTER__C, 0)
            and act_journey.CREATED_DATE = amlh_raw.CREATED_DATE
        order by
            act.ID
);

	-- Step 01b: ACCOUNT MARKETING LIFECYCLE TABLE

	    DROP TABLE IF EXISTS DP_PROD_DB.ACT_MRKT_LIFECYCLE.AMLH;

	    CREATE TABLE DP_PROD_DB.ACT_MRKT_LIFECYCLE.AMLH AS

	SELECT
	    *,
	    -- AMLH_MUTUALLY_EXCLUSIVE_PRE_SUSPECT_DESIGNATION_DATE FILTERS
	    
	            cast(date_trunc('week',AMLH_MUTUALLY_EXCLUSIVE_PRE_SUSPECT_DESIGNATION_DATE) + '6 days'::interval as date) as AMLH_MUTUALLY_EXCLUSIVE_PRE_SUSPECT_DESIGNATION_DATE_EOW,
				last_day(AMLH_MUTUALLY_EXCLUSIVE_PRE_SUSPECT_DESIGNATION_DATE) as AMLH_MUTUALLY_EXCLUSIVE_PRE_SUSPECT_DESIGNATION_DATE_EOM,
				cast(dateadd(day, -1, dateadd(QTR,1,DATE_TRUNC('QTR', AMLH_MUTUALLY_EXCLUSIVE_PRE_SUSPECT_DESIGNATION_DATE)))as date) as AMLH_MUTUALLY_EXCLUSIVE_PRE_SUSPECT_DESIGNATION_DATE_EOQ,
				cast(dateadd(day, -1, dateadd(year, 1, DATE_TRUNC('year', AMLH_MUTUALLY_EXCLUSIVE_PRE_SUSPECT_DESIGNATION_DATE)))as date) as AMLH_MUTUALLY_EXCLUSIVE_PRE_SUSPECT_DESIGNATION_DATE_EOY
	    
	FROM
	    (
	        SELECT
	            amlh_temp.*,
	            -- MUTUALLY_EXCLUSIVE_PRE_SUSPECT_DESIGNATION
	            CASE
	                WHEN SUBSTRING(AMLH_ACT_JOURNEY_PATH_ID, 1, 1) <> 0 -- cold exists
	                AND SUBSTRING(AMLH_ACT_JOURNEY_PATH_ID, 19, 1) = 0 -- not routed
	                AND SUBSTRING(AMLH_ACT_JOURNEY_PATH_ID, 1, 1) > SUBSTRING(AMLH_ACT_JOURNEY_PATH_ID, 7, 1) -- cold only or cold after mea
	                AND SUBSTRING(AMLH_ACT_JOURNEY_PATH_ID, 1, 1) > SUBSTRING(AMLH_ACT_JOURNEY_PATH_ID, 13, 1) -- cold only or cold after mqa
	                THEN 'Pre-Suspect Cold - Not Routed' 
	                WHEN SUBSTRING(AMLH_ACT_JOURNEY_PATH_ID, 1, 1) <> 0 -- cold exists
	                AND SUBSTRING(AMLH_ACT_JOURNEY_PATH_ID, 19, 1) <> 0 --suspect exists
	                AND SUBSTRING(AMLH_ACT_JOURNEY_PATH_ID, 1, 1) < SUBSTRING(AMLH_ACT_JOURNEY_PATH_ID, 19, 1) --cold is before suspect
	                AND (
	                    SUBSTRING(AMLH_ACT_JOURNEY_PATH_ID, 1, 1) > SUBSTRING(AMLH_ACT_JOURNEY_PATH_ID, 7, 1) -- cold only or cold after mea
	                    OR SUBSTRING(AMLH_ACT_JOURNEY_PATH_ID, 7, 1) > SUBSTRING(AMLH_ACT_JOURNEY_PATH_ID, 19, 1) -- or mea is after suspect
	                ) 
	                AND (
	                    SUBSTRING(AMLH_ACT_JOURNEY_PATH_ID, 1, 1) > SUBSTRING(AMLH_ACT_JOURNEY_PATH_ID, 13, 1) --cold only or cold after mqa
	                    OR SUBSTRING(AMLH_ACT_JOURNEY_PATH_ID, 13, 1) > SUBSTRING(AMLH_ACT_JOURNEY_PATH_ID, 19, 1) --or mqa is after suspect
	                ) 
	                THEN 'Pre-Suspect Cold - Routed'
	                WHEN SUBSTRING(AMLH_ACT_JOURNEY_PATH_ID, 7, 1) <> 0 --mea exists
	                AND SUBSTRING(AMLH_ACT_JOURNEY_PATH_ID, 19, 1) = 0 -- not routed
	                AND SUBSTRING(AMLH_ACT_JOURNEY_PATH_ID, 7, 1) > SUBSTRING(AMLH_ACT_JOURNEY_PATH_ID, 1, 1) --mea is after cold
	                AND SUBSTRING(AMLH_ACT_JOURNEY_PATH_ID, 7, 1) > SUBSTRING(AMLH_ACT_JOURNEY_PATH_ID, 13, 1) --  mqa is zero or before mea             
	                THEN 'Pre-Suspect MEA - Not Routed' 
	                WHEN SUBSTRING(AMLH_ACT_JOURNEY_PATH_ID, 7, 1) <> 0 --mea exists
	                AND SUBSTRING(AMLH_ACT_JOURNEY_PATH_ID, 19, 1) <> 0 -- suspect exists
	                AND SUBSTRING(AMLH_ACT_JOURNEY_PATH_ID, 7, 1) < SUBSTRING(AMLH_ACT_JOURNEY_PATH_ID, 19, 1) --mea is before suspect
	                AND (
	                    SUBSTRING(AMLH_ACT_JOURNEY_PATH_ID, 7, 1) > SUBSTRING(AMLH_ACT_JOURNEY_PATH_ID, 1, 1) -- cold is before mea
	                    OR SUBSTRING(AMLH_ACT_JOURNEY_PATH_ID, 1, 1) > SUBSTRING(AMLH_ACT_JOURNEY_PATH_ID, 19, 1) --or cold is after suspect
	                ) 
	                AND (
	                    SUBSTRING(AMLH_ACT_JOURNEY_PATH_ID, 7, 1) > SUBSTRING(AMLH_ACT_JOURNEY_PATH_ID, 13, 1) --mqa is before mea or mqa is zero
	                    OR (
	                    SUBSTRING(AMLH_ACT_JOURNEY_PATH_ID, 13, 1) > SUBSTRING(AMLH_ACT_JOURNEY_PATH_ID, 19, 1) --or mqa is after suspect
	                    AND DATEDIFF(minute, AMLH_SUSPECT_DATE_STAMP__C, AMLH_MQA_DATE_STAMP__C) > 15
	                    --AND diff between mqa and supect is greater than 15 mins
	                    )
	                )
	                THEN 'Pre-Suspect MEA - Routed' 
	                WHEN SUBSTRING(AMLH_ACT_JOURNEY_PATH_ID, 13, 1) <> 0 --mqa exists
	                AND SUBSTRING(AMLH_ACT_JOURNEY_PATH_ID, 19, 1) = 0 -- suspect does not exist
	                AND SUBSTRING(AMLH_ACT_JOURNEY_PATH_ID, 13, 1) > SUBSTRING(AMLH_ACT_JOURNEY_PATH_ID, 1, 1) --mqa is greater than cold
	                AND SUBSTRING(AMLH_ACT_JOURNEY_PATH_ID, 13, 1) > SUBSTRING(AMLH_ACT_JOURNEY_PATH_ID, 7, 1) --mqa is greater than mea
	                THEN 'Pre-Suspect MQA - Not Routed' 
	                WHEN SUBSTRING(AMLH_ACT_JOURNEY_PATH_ID, 13, 1) <> 0 --mqa exists
	                AND SUBSTRING(AMLH_ACT_JOURNEY_PATH_ID, 19, 1) <> 0 -- suspect exists
	                AND (
	                SUBSTRING(AMLH_ACT_JOURNEY_PATH_ID, 13, 1) < SUBSTRING(AMLH_ACT_JOURNEY_PATH_ID, 19, 1) --mqa is before suspect
	                OR  (
	                    SUBSTRING(AMLH_ACT_JOURNEY_PATH_ID, 13, 1) > SUBSTRING(AMLH_ACT_JOURNEY_PATH_ID, 19, 1) --or mqa is after suspect
	                    AND DATEDIFF(minute, AMLH_SUSPECT_DATE_STAMP__C, AMLH_MQA_DATE_STAMP__C) <= 15 
	                    --AND diff between mqa and supect is less than or equal to 15 mins
	                        )
	                    )
	                AND (
	                    SUBSTRING(AMLH_ACT_JOURNEY_PATH_ID, 13, 1) > SUBSTRING(AMLH_ACT_JOURNEY_PATH_ID, 1, 1) -- mqa is after than cold
	                    OR SUBSTRING(AMLH_ACT_JOURNEY_PATH_ID, 1, 1) > SUBSTRING(AMLH_ACT_JOURNEY_PATH_ID, 19, 1) --or cold is after suspect
	                ) 
	                AND (
	                    SUBSTRING(AMLH_ACT_JOURNEY_PATH_ID, 13, 1) > SUBSTRING(AMLH_ACT_JOURNEY_PATH_ID, 7, 1) --mqa is after mea
	                    OR SUBSTRING(AMLH_ACT_JOURNEY_PATH_ID, 7, 1) > SUBSTRING(AMLH_ACT_JOURNEY_PATH_ID, 19, 1) --or mea is after suspect
	                ) 
	                THEN 'Pre-Suspect MQA - Routed'
	                ELSE 'Other'
	            END AS AMLH_MUTUALLY_EXCLUSIVE_PRE_SUSPECT_DESIGNATION,
	            -- MUTUALLY_EXCLUSIVE_PRE_SUSPECT_DESIGNATION_DATE
	            CASE
	                WHEN SUBSTRING(AMLH_ACT_JOURNEY_PATH_ID, 1, 1) <> 0 -- cold exists
	                AND SUBSTRING(AMLH_ACT_JOURNEY_PATH_ID, 19, 1) = 0 -- not routed
	                AND SUBSTRING(AMLH_ACT_JOURNEY_PATH_ID, 1, 1) > SUBSTRING(AMLH_ACT_JOURNEY_PATH_ID, 7, 1) -- cold is greater than mea
	                AND SUBSTRING(AMLH_ACT_JOURNEY_PATH_ID, 1, 1) > SUBSTRING(AMLH_ACT_JOURNEY_PATH_ID, 13, 1) -- cold is greater than mqa
	                THEN CAST(AMLH_COLD_ACCOUNT_DATE_STAMP__C AS DATE)
	                WHEN 
	                    SUBSTRING(AMLH_ACT_JOURNEY_PATH_ID, 1, 1) <> 0 -- cold exists
	                    AND SUBSTRING(AMLH_ACT_JOURNEY_PATH_ID, 19, 1) <> 0 --suspect exists
	                    AND SUBSTRING(AMLH_ACT_JOURNEY_PATH_ID, 1, 1) < SUBSTRING(AMLH_ACT_JOURNEY_PATH_ID, 19, 1) --cold is before suspect
	                    AND (SUBSTRING(AMLH_ACT_JOURNEY_PATH_ID, 1, 1) > SUBSTRING(AMLH_ACT_JOURNEY_PATH_ID, 7, 1) --cold only or after mea 
	                        OR SUBSTRING(AMLH_ACT_JOURNEY_PATH_ID, 7, 1) > SUBSTRING(AMLH_ACT_JOURNEY_PATH_ID, 19, 1)) -- or mea is after suspect
	                    AND (SUBSTRING(AMLH_ACT_JOURNEY_PATH_ID, 1, 1) > SUBSTRING(AMLH_ACT_JOURNEY_PATH_ID, 13, 1)  --cold is after mqa
	                        OR SUBSTRING(AMLH_ACT_JOURNEY_PATH_ID, 13, 1) > SUBSTRING(AMLH_ACT_JOURNEY_PATH_ID, 19, 1) ) --or mqa is after suspect
	                    THEN CAST(AMLH_COLD_ACCOUNT_DATE_STAMP__C AS DATE)
	            WHEN SUBSTRING(AMLH_ACT_JOURNEY_PATH_ID, 7, 1) <> 0 --mea exists
	                AND SUBSTRING(AMLH_ACT_JOURNEY_PATH_ID, 19, 1) = 0 --no suspect
	                AND SUBSTRING(AMLH_ACT_JOURNEY_PATH_ID, 7, 1) > SUBSTRING(AMLH_ACT_JOURNEY_PATH_ID, 1, 1) --mea is greater than cold
	                AND SUBSTRING(AMLH_ACT_JOURNEY_PATH_ID, 7, 1) > SUBSTRING(AMLH_ACT_JOURNEY_PATH_ID, 13, 1) --mea is greater than mqa               
	                THEN CAST(AMLH_MEA_DATE_STAMP__C AS DATE)
	                
	                WHEN SUBSTRING(AMLH_ACT_JOURNEY_PATH_ID, 7, 1) <> 0 --mea exists
	                AND SUBSTRING(AMLH_ACT_JOURNEY_PATH_ID, 19, 1) <> 0 -- suspect exists
	                AND SUBSTRING(AMLH_ACT_JOURNEY_PATH_ID, 7, 1) < SUBSTRING(AMLH_ACT_JOURNEY_PATH_ID, 19, 1) --mea is before suspect
	                AND (
	                    SUBSTRING(AMLH_ACT_JOURNEY_PATH_ID, 7, 1) > SUBSTRING(AMLH_ACT_JOURNEY_PATH_ID, 1, 1) -- cold is before mea
	                    OR SUBSTRING(AMLH_ACT_JOURNEY_PATH_ID, 1, 1) > SUBSTRING(AMLH_ACT_JOURNEY_PATH_ID, 19, 1) --or cold is after suspect
	                ) 
	                AND (
	                    SUBSTRING(AMLH_ACT_JOURNEY_PATH_ID, 7, 1) > SUBSTRING(AMLH_ACT_JOURNEY_PATH_ID, 13, 1) --mqa is before mea or mqa is zero
	                    OR (
	                    SUBSTRING(AMLH_ACT_JOURNEY_PATH_ID, 13, 1) > SUBSTRING(AMLH_ACT_JOURNEY_PATH_ID, 19, 1) --or mqa is after suspect
	                    AND DATEDIFF(minute, AMLH_SUSPECT_DATE_STAMP__C, AMLH_MQA_DATE_STAMP__C) > 15
	                    --AND diff between mqa and supect is greater than 15 mins
	                    )
	                )            
	                THEN CAST(AMLH_MEA_DATE_STAMP__C AS DATE)
	                
	            WHEN SUBSTRING(AMLH_ACT_JOURNEY_PATH_ID, 13, 1) <> 0 --mqa exists
	                AND SUBSTRING(AMLH_ACT_JOURNEY_PATH_ID, 19, 1) = 0   -- not routed
	                AND SUBSTRING(AMLH_ACT_JOURNEY_PATH_ID, 13, 1) > SUBSTRING(AMLH_ACT_JOURNEY_PATH_ID, 1, 1) --mqa is greater than cold
	                AND SUBSTRING(AMLH_ACT_JOURNEY_PATH_ID, 13, 1) > SUBSTRING(AMLH_ACT_JOURNEY_PATH_ID, 7, 1) --mqa is greater than mea             
	                THEN CAST(AMLH_MQA_DATE_STAMP__C AS DATE)
	                
	            WHEN SUBSTRING(AMLH_ACT_JOURNEY_PATH_ID, 13, 1) <> 0 --mqa exists
	                AND SUBSTRING(AMLH_ACT_JOURNEY_PATH_ID, 19, 1) <> 0 -- suspect exists
	                AND (
	                SUBSTRING(AMLH_ACT_JOURNEY_PATH_ID, 13, 1) < SUBSTRING(AMLH_ACT_JOURNEY_PATH_ID, 19, 1) --mqa is before suspect
	                OR  (
	                    SUBSTRING(AMLH_ACT_JOURNEY_PATH_ID, 13, 1) > SUBSTRING(AMLH_ACT_JOURNEY_PATH_ID, 19, 1) --or mqa is after suspect
	                    AND DATEDIFF(minute, AMLH_SUSPECT_DATE_STAMP__C, AMLH_MQA_DATE_STAMP__C) <= 15 
	                    --AND diff between mqa and supect is less than or equal to 15 mins
	                        )
	                    )
	                AND (
	                    SUBSTRING(AMLH_ACT_JOURNEY_PATH_ID, 13, 1) > SUBSTRING(AMLH_ACT_JOURNEY_PATH_ID, 1, 1) -- mqa is after than cold
	                    OR SUBSTRING(AMLH_ACT_JOURNEY_PATH_ID, 1, 1) > SUBSTRING(AMLH_ACT_JOURNEY_PATH_ID, 19, 1) --or cold is after suspect
	                ) 
	                AND (
	                    SUBSTRING(AMLH_ACT_JOURNEY_PATH_ID, 13, 1) > SUBSTRING(AMLH_ACT_JOURNEY_PATH_ID, 7, 1) --mqa is after mea
	                    OR SUBSTRING(AMLH_ACT_JOURNEY_PATH_ID, 7, 1) > SUBSTRING(AMLH_ACT_JOURNEY_PATH_ID, 19, 1) --or mea is after suspect
	                )               
	                THEN CAST(AMLH_MQA_DATE_STAMP__C AS DATE)
	                ELSE NULL
	            END AS AMLH_MUTUALLY_EXCLUSIVE_PRE_SUSPECT_DESIGNATION_DATE,

	                -- DELTAS VIA THEJOINS 
	                amlh_temp_delta.AMLH_DELTA_DAYS_COLD_MEA,
	                amlh_temp_delta.AMLH_DELTA_DAYS_COLD_MQA,
	                amlh_temp_delta.AMLH_DELTA_DAYS_COLD_SUSPECT,
	                amlh_temp_delta.AMLH_DELTA_DAYS_COLD_PROSPECT,
	                amlh_temp_delta.AMLH_DELTA_DAYS_MEA_MQA,
	                amlh_temp_delta.AMLH_DELTA_DAYS_MEA_SUSPECT,
	                amlh_temp_delta.AMLH_DELTA_DAYS_MEA_PROSPECT,
	                amlh_temp_delta.AMLH_DELTA_DAYS_MQA_SUSPECT,
	                amlh_temp_delta.AMLH_DELTA_DAYS_MQA_PROSPECT,
	                amlh_temp_delta.AMLH_DELTA_DAYS_SUSPECT_PROSPECT
	                
	        from AMLH_TEMP as amlh_temp
	           -- AMLH_TEMP_V1_6 as amlh_temp
	            -- Delta in Days
	            LEFT JOIN 
	            (SELECT  
	                -- ID's for join
	                amlh_temp.AMLH_ACCOUNT__C,
	                amlh_temp.AMLH_NAME,
	                -- Journey Path
	                amlh_temp.AMLH_ACT_JOURNEY_PATH,
	            
	                -- AMLH LIFECYCLE STAGES 
	                amlh_temp.AMLH_COLD_ACCOUNT_DATE_STAMP__C_CAST,
	                amlh_temp.AMLH_MEA_DATE_STAMP__C_CAST,
	                amlh_temp.AMLH_MQA_DATE_STAMP__C_CAST,
	                amlh_temp.AMLH_SUSPECT_DATE_STAMP__C_CAST,
	                amlh_temp.AMLH_PROSPECT_DATE_STAMP__C_CAST,
	            
	                -- DELTAS VIA THEJOINS BELOW 
	                amlh_temp_cold_mea.AMLH_DELTA_DAYS_COLD_MEA,
	                amlh_temp_cold_mqa.AMLH_DELTA_DAYS_COLD_MQA,
	                amlh_temp_cold_suspect.AMLH_DELTA_DAYS_COLD_SUSPECT,
	                amlh_temp_cold_prospect.AMLH_DELTA_DAYS_COLD_PROSPECT,
	                amlh_temp_mea_mqa.AMLH_DELTA_DAYS_MEA_MQA,
	                amlh_temp_mea_suspect.AMLH_DELTA_DAYS_MEA_SUSPECT,
	                amlh_temp_mea_prospect.AMLH_DELTA_DAYS_MEA_PROSPECT,
	                amlh_temp_mqa_suspect.AMLH_DELTA_DAYS_MQA_SUSPECT,
	                amlh_temp_mqa_prospect.AMLH_DELTA_DAYS_MQA_PROSPECT,
	                amlh_temp_suspect_prospect.AMLH_DELTA_DAYS_SUSPECT_PROSPECT
	                
	            FROM AMLH_TEMP as amlh_temp
	            -- Delta in Days
	            LEFT JOIN
	            (
	            -- Delta: Cold to MEA
	            SELECT
	                AMLH_ACCOUNT__C,
	                AMLH_NAME,
	                AMLH_COLD_ACCOUNT_DATE_STAMP__C_CAST,
	                AMLH_MEA_DATE_STAMP__C_CAST,
	                DATEDIFF(day,AMLH_COLD_ACCOUNT_DATE_STAMP__C_CAST,AMLH_MEA_DATE_STAMP__C_CAST) AS AMLH_DELTA_DAYS_COLD_MEA
	            FROM AMLH_TEMP
	            --AMLH_TEMP_V1_6 
	            WHERE (AMLH_COLD_ACCOUNT_DATE_STAMP__C_CAST IS NOT NULL AND AMLH_MEA_DATE_STAMP__C_CAST IS NOT NULL)  
	            ) as amlh_temp_cold_mea
	            ON amlh_temp.AMLH_ACCOUNT__C = amlh_temp_cold_mea.AMLH_ACCOUNT__C
	            AND amlh_temp.AMLH_NAME = amlh_temp_cold_mea.AMLH_NAME
	            
	            LEFT JOIN
	            (
	            -- Delta: Cold to MQA
	            SELECT
	                AMLH_ACCOUNT__C,
	                AMLH_NAME,
	                AMLH_COLD_ACCOUNT_DATE_STAMP__C_CAST,
	                AMLH_MQA_DATE_STAMP__C_CAST,
	                DATEDIFF(day,AMLH_COLD_ACCOUNT_DATE_STAMP__C_CAST,AMLH_MQA_DATE_STAMP__C_CAST) AS AMLH_DELTA_DAYS_COLD_MQA
	            FROM AMLH_TEMP
	            --AMLH_TEMP_V1_6 
	            WHERE (AMLH_COLD_ACCOUNT_DATE_STAMP__C_CAST IS NOT NULL AND AMLH_MQA_DATE_STAMP__C_CAST IS NOT NULL)  
	            ) as amlh_temp_cold_mqa
	            ON amlh_temp.AMLH_ACCOUNT__C = amlh_temp_cold_mqa.AMLH_ACCOUNT__C
	            AND amlh_temp.AMLH_NAME = amlh_temp_cold_mqa.AMLH_NAME
	            
	            LEFT JOIN
	            (
	            -- Delta: Cold to Suspect
	            SELECT
	                AMLH_ACCOUNT__C,
	                AMLH_NAME,
	                AMLH_COLD_ACCOUNT_DATE_STAMP__C_CAST,
	                AMLH_SUSPECT_DATE_STAMP__C_CAST,
	                DATEDIFF(day,AMLH_COLD_ACCOUNT_DATE_STAMP__C_CAST,AMLH_SUSPECT_DATE_STAMP__C_CAST) AS AMLH_DELTA_DAYS_COLD_SUSPECT
	            FROM AMLH_TEMP
	            --AMLH_TEMP_V1_6 
	            WHERE (AMLH_COLD_ACCOUNT_DATE_STAMP__C_CAST IS NOT NULL AND AMLH_SUSPECT_DATE_STAMP__C_CAST IS NOT NULL)  
	            ) as amlh_temp_cold_suspect
	            ON amlh_temp.AMLH_ACCOUNT__C = amlh_temp_cold_suspect.AMLH_ACCOUNT__C
	            AND amlh_temp.AMLH_NAME = amlh_temp_cold_suspect.AMLH_NAME
	            
	            LEFT JOIN
	            (
	            -- Delta: Cold to Prospect
	            SELECT
	                AMLH_ACCOUNT__C,
	                AMLH_NAME,
	                AMLH_COLD_ACCOUNT_DATE_STAMP__C_CAST,
	                AMLH_PROSPECT_DATE_STAMP__C_CAST,
	                DATEDIFF(day,AMLH_COLD_ACCOUNT_DATE_STAMP__C_CAST,AMLH_PROSPECT_DATE_STAMP__C_CAST) AS AMLH_DELTA_DAYS_COLD_PROSPECT
	            FROM AMLH_TEMP
	            --AMLH_TEMP_V1_6 
	            WHERE (AMLH_COLD_ACCOUNT_DATE_STAMP__C_CAST IS NOT NULL AND AMLH_PROSPECT_DATE_STAMP__C_CAST IS NOT NULL)
	            ) as amlh_temp_cold_prospect
	            ON amlh_temp.AMLH_ACCOUNT__C = amlh_temp_cold_prospect.AMLH_ACCOUNT__C
	            AND amlh_temp.AMLH_NAME = amlh_temp_cold_prospect.AMLH_NAME
	            
	            LEFT JOIN
	            (
	            -- Delta: MEA to MQA
	            SELECT
	                AMLH_ACCOUNT__C,
	                AMLH_NAME,
	                AMLH_MEA_DATE_STAMP__C_CAST,
	                AMLH_MQA_DATE_STAMP__C_CAST,
	                DATEDIFF(day,AMLH_MEA_DATE_STAMP__C_CAST,AMLH_MQA_DATE_STAMP__C_CAST) AS AMLH_DELTA_DAYS_MEA_MQA
	            FROM AMLH_TEMP
	            --AMLH_TEMP_V1_6 
	            WHERE (AMLH_MEA_DATE_STAMP__C_CAST IS NOT NULL AND AMLH_MQA_DATE_STAMP__C_CAST IS NOT NULL)  
	            ) as amlh_temp_mea_mqa
	            ON amlh_temp.AMLH_ACCOUNT__C = amlh_temp_mea_mqa.AMLH_ACCOUNT__C
	            AND amlh_temp.AMLH_NAME = amlh_temp_mea_mqa.AMLH_NAME
	            
	            LEFT JOIN
	            (
	            -- Delta: MEA to Suspect
	            SELECT
	                AMLH_ACCOUNT__C,
	                AMLH_NAME,
	                AMLH_MEA_DATE_STAMP__C_CAST,
	                AMLH_SUSPECT_DATE_STAMP__C_CAST,
	                DATEDIFF(day,AMLH_MEA_DATE_STAMP__C_CAST,AMLH_SUSPECT_DATE_STAMP__C_CAST) AS AMLH_DELTA_DAYS_MEA_SUSPECT
	            FROM AMLH_TEMP
	            --AMLH_TEMP_V1_6 
	            WHERE (AMLH_MEA_DATE_STAMP__C_CAST IS NOT NULL AND AMLH_SUSPECT_DATE_STAMP__C_CAST IS NOT NULL)  
	            ) as amlh_temp_mea_suspect
	            ON amlh_temp.AMLH_ACCOUNT__C = amlh_temp_mea_suspect.AMLH_ACCOUNT__C
	            AND amlh_temp.AMLH_NAME = amlh_temp_mea_suspect.AMLH_NAME
	            
	            LEFT JOIN
	            (
	            -- Delta: MEA to Prospect
	            SELECT
	                AMLH_ACCOUNT__C,
	                AMLH_NAME,
	                AMLH_MEA_DATE_STAMP__C_CAST,
	                AMLH_PROSPECT_DATE_STAMP__C_CAST,
	                DATEDIFF(day,AMLH_MEA_DATE_STAMP__C_CAST,AMLH_PROSPECT_DATE_STAMP__C_CAST) AS AMLH_DELTA_DAYS_MEA_PROSPECT
	            FROM AMLH_TEMP 
	            --AMLH_TEMP_V1_6 
	            WHERE (AMLH_MEA_DATE_STAMP__C_CAST IS NOT NULL AND AMLH_PROSPECT_DATE_STAMP__C_CAST IS NOT NULL)
	            ) as amlh_temp_mea_prospect
	            ON amlh_temp.AMLH_ACCOUNT__C = amlh_temp_mea_prospect.AMLH_ACCOUNT__C
	            AND amlh_temp.AMLH_NAME = amlh_temp_mea_prospect.AMLH_NAME
	            
	            LEFT JOIN
	            (
	            -- Delta: MQA to Suspect
	            SELECT
	                AMLH_ACCOUNT__C,
	                AMLH_NAME,
	                AMLH_MQA_DATE_STAMP__C_CAST,
	                AMLH_SUSPECT_DATE_STAMP__C_CAST,
	                DATEDIFF(day,AMLH_MQA_DATE_STAMP__C_CAST,AMLH_SUSPECT_DATE_STAMP__C_CAST) AS AMLH_DELTA_DAYS_MQA_SUSPECT
	            FROM AMLH_TEMP 
	            --AMLH_TEMP_V1_6 
	            WHERE (AMLH_MQA_DATE_STAMP__C_CAST IS NOT NULL AND AMLH_SUSPECT_DATE_STAMP__C_CAST IS NOT NULL)  
	            ) as amlh_temp_mqa_suspect
	            ON amlh_temp.AMLH_ACCOUNT__C = amlh_temp_mqa_suspect.AMLH_ACCOUNT__C
	            AND amlh_temp.AMLH_NAME = amlh_temp_mqa_suspect.AMLH_NAME
	            
	            LEFT JOIN
	            (
	            -- Delta: MQA to Prospect
	            SELECT
	                AMLH_ACCOUNT__C,
	                AMLH_NAME,
	                AMLH_MQA_DATE_STAMP__C_CAST,
	                AMLH_PROSPECT_DATE_STAMP__C_CAST,
	                DATEDIFF(day,AMLH_MQA_DATE_STAMP__C_CAST,AMLH_PROSPECT_DATE_STAMP__C_CAST) AS AMLH_DELTA_DAYS_MQA_PROSPECT
	            FROM AMLH_TEMP 
	            --AMLH_TEMP_V1_6 
	            WHERE (AMLH_MQA_DATE_STAMP__C_CAST IS NOT NULL AND AMLH_PROSPECT_DATE_STAMP__C_CAST IS NOT NULL)
	            ) as amlh_temp_mqa_prospect
	            ON amlh_temp.AMLH_ACCOUNT__C = amlh_temp_mqa_prospect.AMLH_ACCOUNT__C
	            AND amlh_temp.AMLH_NAME = amlh_temp_mqa_prospect.AMLH_NAME
	            
	            LEFT JOIN
	            (
	            -- Delta: SUSPECT to Prospect
	            SELECT
	                AMLH_ACCOUNT__C,
	                AMLH_NAME,
	                AMLH_SUSPECT_DATE_STAMP__C_CAST,
	                AMLH_PROSPECT_DATE_STAMP__C_CAST,
	                DATEDIFF(day,AMLH_SUSPECT_DATE_STAMP__C_CAST,AMLH_PROSPECT_DATE_STAMP__C_CAST) AS AMLH_DELTA_DAYS_SUSPECT_PROSPECT
	            FROM AMLH_TEMP 
	            --AMLH_TEMP_V1_6 
	            WHERE (AMLH_SUSPECT_DATE_STAMP__C_CAST IS NOT NULL AND AMLH_PROSPECT_DATE_STAMP__C_CAST IS NOT NULL)
	            ) as amlh_temp_suspect_prospect
	            ON amlh_temp.AMLH_ACCOUNT__C = amlh_temp_suspect_prospect.AMLH_ACCOUNT__C
	            AND amlh_temp.AMLH_NAME = amlh_temp_suspect_prospect.AMLH_NAME
	            
	            WHERE amlh_temp.AMLH_ACCOUNT_JOURNEY_PATH_LIFECYCLE_NONLINEAR_FLAG = 'Linear'
	            ) as amlh_temp_delta
	            ON amlh_temp.AMLH_ACCOUNT__C = amlh_temp_delta.AMLH_ACCOUNT__C
	            AND amlh_temp.AMLH_NAME = amlh_temp_delta.AMLH_NAME
	    );
	    
	-- Step 02: ACCOUNT MARKETING LIFECYCLE TABLE WITH OPP DATA 
	 DROP TABLE IF EXISTS DP_PROD_DB.ACT_MRKT_LIFECYCLE.AMLH_OPPS;
	    CREATE TABLE DP_PROD_DB.ACT_MRKT_LIFECYCLE.AMLH_OPPS as
	 
	SELECT
	    *
	FROM
	    (
	        select 
	            -- Account Marketing Lifecycle Table
	            amlh.*,
	--            --act.buying_stage_at_suspect__c AS ACT_BUYING_STAGE_AT_SUSPECT__C,
	--            -- OPP INFO
	            opp.ID AS OPP_ID,
	            opp.NAME AS OPP_NAME,
	            CAST(opp.CREATED_DATE as DATE) AS OPP_CREATED_DATE,            
	            cast(date_trunc('week',opp.created_date) + '6 days'::interval as date) as OPP_CREATED_DATE__C_EOW,
				last_day(opp.created_date) as OPP_CREATED_DATE__C_EOM,
				cast(dateadd(day, -1, dateadd(QTR,1,DATE_TRUNC('QTR', opp.created_date)))as date) as OPP_CREATED_DATE__C_EOQ,
				cast(dateadd(day, -1, dateadd(year, 1, DATE_TRUNC('year', opp.created_date)))as date) as OPP_CREATED_DATE__C_EOY,                    
	            opp.CLOSE_DATE AS OPP_CLOSE_DATE,
	            opp.LEAD_SOURCE AS OPP_LEAD_SOURCE,
	            opp.STAGE_NAME AS OPP_STAGE_NAME,
	            opp.SUB_STAGE__C AS OPP_SUB_STAGE__C,
	            opp.COMPETITIVE_INFLUENCE__C AS OPP_COMPETITIVE_INFLUENCE__C,
	            opp.PRIMARY_COMPETITOR__C AS OPP_PRIMARY_COMPETITOR__C,
	            opp.LOSS_STALL_REASON__C AS OPP_LOSS_STALL_REASON__C,
	            opp.LOSS_STALL_REASON_DETAIL__C AS OPP_LOSS_STALL_REASON_DETAIL__C,
	            opp.LOST_REASON__C AS OPP_LOST_REASON__C,
	          --  opp.UNQUALIFIED_REASON__C AS OPP_UNQUALIFIED_REASON__C,
	            opp.LEADING_PRODUCT__C AS OPP_LEADING_PRODUCT__C,
	            opp.PRODUCT_INTEREST__C AS OPP_PRODUCT_INTEREST__C,
	            opp.PUSH_COUNT AS OPP_PUSH_COUNT,
	            CASE WHEN (opp.ID IS NULL 
	                OR opp.STAGE_NAME IS NULL
	                OR opp.STAGE_NAME IN
	            (
	            'Awaiting Auto-Renewal',
	            'Cancelled',
	            'Churn',
	            'Closed - Auto Renewal',
	            'Closed - Migrated',
	            'Closed - Reduced',
	            'Closed - Terminated',
	            'Closed - Transfer',
	            'Closed / Duplicate',
	            'Closed / Invalid',
	            'Closed Auto-Renewed',
	            'Closed Booked - Cancelled',
	            'Paved - Invoice'
	            )
	            )
	            THEN 'No Opp' 
	                WHEN opp.STAGE_NAME IN
	                (
	                'Closed - Booked',
	                'Closed - Booked (SO)',
	                'Closed - Parent',
	                'Closed - Ready to Book',
	                'Closed Won',
	                'On Hold',
	                'Pending Additional Signature',
	                'Pending Approval',
	                'Pending Client Signature'
	                )
	                THEN 'Closed - Booked' 
	                WHEN opp.STAGE_NAME IN
	                (
	                'Closed Lost',
	                'Closed Return to CDM',
	                'Closed Stalled',
	                'Closed/Unqualified',
	                'Stalled / At Risk'
	                )
	                    THEN 'Closed - Not Booked' 
	                ELSE 'Open' END AS OPP_STAGE_NAME_CATEGORY,
	            opp.TYPE AS OPP_TYPE,
	            opp.COMMITTED_TERM__C AS OPP_COMMITTED_TERM__C,
	            opp.PROBABILITY AS OPP_PROBABILITY,
	            opp.IS_CLOSED AS OPP_IS_CLOSED,
	            opp.IS_WON AS OPP_IS_WON,
	            -- OPP FINANCIAL METRICS
	            opp.CURRENCY_ISO_CODE as OPP_CURRENCY_ISO_CODE,
	            opp.CONVERSION_RATE AS OPP_CONVERSION_RATE,
	            opp.ACV3__C AS OPP_ACV3__C,
	            opp.FORECASTED_ACV__C as OPP_FORECASTED_ACV__C,
	            opp.FORECASTED_ARR__C as OPP_FORECASTED_ARR__C,
				opp.SALES_REPORTING_ARR__C AS OPP_SALES_REPORTING_ARR__C,
	            opp.TOTAL_BOOKING_AMOUNT2__C as OPP_TOTAL_BOOKING_AMOUNT2__C,
	            (opp.ACV3__C * opp.CONVERSION_RATE) AS OPP_ACV3__C_CONVERTED,(
	                opp.TOTAL_BOOKING_AMOUNT2__C * opp.CONVERSION_RATE
	            ) as OPP_TOTAL_BOOKING_AMOUNT2__C_CONVERTED,
	            opp.SUBS_QTY__C as OPP_SUBS_QTY__C,
	            opp.BOOKED_SUBS_QTY3__C as OPP_BOOKED_SUBS_QTY3__C,
	            opp.FORECASTED_SUBS_QTY__C AS OPP_FORECASTED_SUBS_QTY__C,
	            CASE WHEN opp.ID IS NULL THEN NULL WHEN opp.STAGE_NAME = 'Closed - Booked (SO)' THEN COALESCE(BOOKED_SUBS_QTY3__C,FORECASTED_SUBS_QTY__C) ELSE FORECASTED_SUBS_QTY__C END AS OPP_BOOKEDFORECASTED_SUBS_QTY3__C,
	            
	            opp.SALES_REPORTING_ACV__C AS OPP_SALES_REPORTING_ACV__C,
	            opp.SALES_REPORTING_TOTAL_BOOKING_AMOUNT__C AS OPP_SALES_REPORTING_TOTAL_BOOKING_AMOUNT__C,
	            (
	                opp.SALES_REPORTING_ACV__C * opp.CONVERSION_RATE
	            ) AS OPP_SALES_REPORTING_ACV__C_CONVERTED,(
	                opp.SALES_REPORTING_TOTAL_BOOKING_AMOUNT__C * opp.CONVERSION_RATE
	            ) AS OPP_SALES_REPORTING_TOTAL_BOOKING_AMOUNT__C_CONVERTED,
	            opp.SALES_REPORTING_BOOKED_SUBS_QTY__C AS OPP_SALES_REPORTING_BOOKED_SUBS_QTY__C,
	            -- OPP OWNER INFO
	            opp.OWNER_NAME AS OPP_OWNER_NAME,
	            opp.OWNER_USERROLE_NAME AS OPP_OWNER_USERROLE_NAME,
	            -- OPP STAGE DATE
	            CAST(opp_stage_dates.stage0 as date) AS OPP_STAGE_0_DATE,
	            CAST(opp_stage_dates.stage1 as date) AS OPP_STAGE_1_DATE,
	            CAST(opp_stage_dates.stage2 as date) AS OPP_STAGE_2_DATE,
	            CAST(opp_stage_dates.stage3 as date) AS OPP_STAGE_3_DATE,
	            CAST(opp_stage_dates.stage4 as date) AS OPP_STAGE_4_DATE,
	            CAST(opp_stage_dates.stage5 as date) AS OPP_STAGE_5_DATE,
	            CAST(opp_stage_dates.stage6 as date) AS OPP_STAGE_6_DATE,
	            CAST(opp_stage_dates.stage7 as date) AS OPP_STAGE_7_DATE,
	            CAST(opp_stage_dates.win as date) AS OPP_WIN_DATE,

	            -- OPP STAGE VELOCITY

				OPP_STAGE_DELTA_DAYS_STAGE_0_STAGE_1,
				OPP_STAGE_DELTA_DAYS_STAGE_1_STAGE_2,
				OPP_STAGE_DELTA_DAYS_STAGE_2_STAGE_3,
				OPP_STAGE_DELTA_DAYS_STAGE_3_STAGE_4,
				OPP_STAGE_DELTA_DAYS_STAGE_4_STAGE_5,
				OPP_STAGE_DELTA_DAYS_STAGE_5_STAGE_6,
				OPP_STAGE_DELTA_DAYS_STAGE_6_STAGE_7,
				OPP_STAGE_DELTA_DAYS_STAGE_7_WIN
	    
	        FROM
	            DP_PROD_DB.SALESFORCE.ACCOUNT AS act          
	            -- ACT Record Type
	            INNER JOIN DP_PROD_DB.SALESFORCE.RECORD_TYPE as rcd_act ON act.RECORD_TYPE_ID = rcd_act.ID
	            AND (
	                rcd_act."ID" = '012300000005VEYAA2'
	                OR rcd_act."ID" = '0126R000001UknZQAS'
	            ) -- Act Mrkt Lifecycle History
	            INNER JOIN DP_PROD_DB.ACT_MRKT_LIFECYCLE.AMLH AS amlh on act.ID = amlh.ACT_ID -- OPP
	            LEFT JOIN (SELECT 
	            opp.*,curr.CONVERSION_RATE, usr.NAME AS OWNER_NAME, usr_role.NAME AS OWNER_USERROLE_NAME 
	            FROM DP_PROD_DB.SALESFORCE.OPPORTUNITY as opp
	            -- OPP RECORD TYPE
	            INNER JOIN DP_PROD_DB.SALESFORCE.RECORD_TYPE as rcd_opp ON opp.RECORD_TYPE_ID = rcd_opp.ID
	            AND (
	                rcd_opp.ID = '012800000005wl4AAA'
	                OR rcd_opp.ID = '0121E000000MBF6QAO'
	            )
	            -- OPP OWNER
	            LEFT JOIN DP_PROD_DB.SALESFORCE.USER usr ON opp.owner_id = usr.ID
	            AND opp.owner_id <> '0056R00000C6W2MQAV'
	            -- OPP USER ROLE
	            LEFT JOIN DP_PROD_DB.SALESFORCE.USER_ROLE usr_role ON usr.USER_ROLE_ID = usr_role.ID
	            -- OPP CURRENCY
	            INNER JOIN DP_PROD_DB.SALESFORCE.CURRENCY_TYPE curr ON opp.CURRENCY_ISO_CODE = curr.ISO_CODE
	            AND curr.IS_ACTIVE = TRUE
	            WHERE usr_role.NAME NOT IN ('Scott Rose', 'Rick Walters', 'Micah Rea', 'Compliance', 'ELD Compliance Manager')
	            
	            ) as opp ON amlh.ACT_ID = opp.ACCOUNT_ID
	            AND amlh.AMLH_OPPORTUNITY__C = opp.ID
	            and opp.PARENT_OPPORTUNITY__C IS NULL
	            /*-- touchtype_analytics_table as source 
	            LEFT JOIN DP_PROD_DB.ACT_MRKT_LIFECYCLE.TOUCHTYPE_ANALYTICS as infl_data
	            ON act.ID = infl_data.CRM_ACCOUNT_ID
	            */
	            LEFT JOIN 
	            (
	            
	            select --works from here 2
	                DISTINCT 
	                opp.id AS opportunity_id,
	                opp.created_date as stage0,
	                CASE WHEN stage1 IS NOT NULL then stage1
	                WHEN stage1 IS NULL AND stage2 IS NOT NULL THEN stage2
	                WHEN stage1 IS NULL AND stage2 IS NULL AND stage3 IS NOT NULL THEN stage3
	                WHEN stage1 IS NULL AND stage2 IS NULL AND stage3 IS NULL and stage4 IS NOT NULL THEN stage4 
	                WHEN stage1 IS NULL AND stage2 IS NULL AND stage3 IS NULL and stage4 IS NULL and stage5 IS NOT NULL then stage5
	                WHEN stage1 IS NULL AND stage2 IS NULL AND stage3 IS NULL and stage4 IS NULL and stage5 IS NULL AND stage6 IS NOT NULL THEN stage6
	                WHEN stage1 IS NULL AND stage2 IS NULL AND stage3 IS NULL and stage4 IS NULL and stage5 IS NULL AND stage6 IS NULL and stage7 is not null THEN stage7
	                WHEN stage1 IS NULL AND stage2 IS NULL AND stage3 IS NULL and stage4 IS NULL and stage5 IS NULL AND stage6 IS NULL and stage7 is null and win is not null then win 
	                END AS stage1,
	                CASE WHEN stage2 IS NOT NULL then stage2
	                WHEN stage2 IS NULL AND stage3 IS NOT NULL THEN stage3
	                WHEN stage2 IS NULL AND stage3 IS NULL and stage4 IS NOT NULL THEN stage4 
	                WHEN stage2 IS NULL AND stage3 IS NULL and stage4 IS NULL and stage5 IS NOT NULL then stage5
	                WHEN stage2 IS NULL AND stage3 IS NULL and stage4 IS NULL and stage5 IS NULL AND stage6 IS NOT NULL THEN stage6
	                WHEN stage2 IS NULL AND stage3 IS NULL and stage4 IS NULL and stage5 IS NULL AND stage6 IS NULL and stage7 is not null THEN stage7
	                WHEN stage2 IS NULL AND stage3 IS NULL and stage4 IS NULL and stage5 IS NULL AND stage6 IS NULL and stage7 is null and win is not null then win 
	                END AS stage2,                
	                CASE WHEN stage3 IS NOT NULL then stage3
	                WHEN stage3 IS NULL and stage4 IS NOT NULL THEN stage4 
	                WHEN stage3 IS NULL and stage4 IS NULL and stage5 IS NOT NULL then stage5
	                WHEN stage3 IS NULL and stage4 IS NULL and stage5 IS NULL AND stage6 IS NOT NULL THEN stage6
	                WHEN stage3 IS NULL and stage4 IS NULL and stage5 IS NULL AND stage6 IS NULL and stage7 is not null THEN stage7
	                WHEN stage3 IS NULL and stage4 IS NULL and stage5 IS NULL AND stage6 IS NULL and stage7 is null and win is not null then win 
	                END AS stage3,  
	                CASE WHEN stage4 IS NOT NULL then stage4
	                WHEN stage4 IS NULL and stage5 IS NOT NULL then stage5
	                WHEN stage4 IS NULL and stage5 IS NULL AND stage6 IS NOT NULL THEN stage6
	                WHEN stage4 IS NULL and stage5 IS NULL AND stage6 IS NULL and stage7 is not null THEN stage7
	                WHEN stage4 IS NULL and stage5 IS NULL AND stage6 IS NULL and stage7 is null and win is not null then win
	                END AS stage4,
	                CASE WHEN stage5 IS NOT NULL then stage5
	                WHEN stage5 IS NULL AND stage6 IS NOT NULL THEN stage6
	                WHEN stage5 IS NULL AND stage6 IS NULL and stage7 is not null THEN stage7
	                WHEN stage5 IS NULL AND stage6 IS NULL and stage7 is null and win is not null then win
	                END AS stage5,                  
	                CASE WHEN stage6 IS NOT NULL then stage6
	                WHEN stage6 IS NULL and stage7 is not null THEN stage7
	                WHEN stage6 IS NULL and stage7 is null and win is not null then win
	                END AS stage6,   
	                CASE WHEN stage7 IS NOT NULL then stage7
	                WHEN stage7 is null and win is not null then win
	                END AS stage7,
					win
	            FROM
	                dp_prod_db.salesforce.opportunity opp
	                LEFT JOIN (
	                            select distinct 
	                            	opportunity_id, 
	                            	case when identify < '10-08-2024' then identify
	                            		else nurture end as stage0,
	                            	case when "analyze" < '10-08-2024' then "analyze"
	                            		else "qualify" end as stage1,                            	
	                            	case when present < '10-08-2024' then present
	                            		else discover end as stage2,
	                            	case when prove < '10-08-2024' then prove
	                            		else propose end as stage3,
	                            	case when finalize < '10-08-2024' then finalize
	                            		else validate end as stage4,
	                            	negotiate as stage5,    
	                            	case when present >= '10-08-2024' then present
	                            		else null end as stage6,                            	
	                            	case when prove >= '10-08-2024' then prove
	                            		else null end as stage7,
	                            	win  

	                            FROM
	                                (
	                                      select distinct
	                                         opportunity_id,
	                                         created_date,
	                                         new_value

	                                    FROM
	                                        dp_prod_db.salesforce.opportunity_field_history
	                                    WHERE
	                                        field = 'StageName'
	                                        
	                                        and 
	                                          new_value  in                         
											(
	                                        'Identify',
	                                        'Analyze',
	                                        'Present',
	                                        'Prove',
	                                        'Finalize',
	                                        'Nurture',
	                                        'Qualify',
	                                        'Discover',
	                                        'Propose',
	                                        'Validate',
	                                        'Negotiate'
	                                    )                                    
	                                        
	                                        
	                                        union all
	                                        
	                                        
	                                        
	                                        
	                                       select distinct
	                                         opportunity_id,
	                                        max(created_date) as created_date,
	                                        'Win' as new_value

	                                    FROM
	                                        dp_prod_db.salesforce.opportunity_field_history
	                                    WHERE
	                                        field = 'StageName'
	                                        
	                                        and 
	                                          new_value in                         
	                                                        (
							                'Closed - Booked',
							                'Closed - Booked (SO)',
							                'Closed - Parent',
							                'Closed - Ready to Book',
							                'Closed Won',
							                'On Hold',
							                'Pending Additional Signature',
							                'Pending Approval',
							                'Pending Client Signature')
							                group by opportunity_id
	                                        
	                                ) PIVOT (
	                                    MIN(CREATEd_DATE) FOR new_value IN (
	                                        'Identify',
	                                        'Analyze',
	                                        'Present',
	                                        'Prove',
	                                        'Finalize',
	                                        'Nurture',
	                                        'Qualify',
	                                        'Discover',
	                                        'Propose',
	                                        'Validate',
	                                        'Negotiate',
	                                        'Win'
	                                    )
	                                ) 
	                        ) AS n2 
	                        ON opp.id = n2.opportunity_id
	                        ) as opp_stage_dates
	                        ON amlh.AMLH_OPPORTUNITY__C = opp_stage_dates.OPPORTUNITY_ID

	                LEFT JOIN 
	                (
	                SELECT
	                    opp_velocity.id AS OPPORTUNITY_ID,
	                    DATEDIFF(day,OPP_STAGE_0_DATE,OPP_STAGE_1_DATE) AS OPP_STAGE_DELTA_DAYS_STAGE_0_STAGE_1,
	                    DATEDIFF(day,OPP_STAGE_1_DATE,OPP_STAGE_2_DATE) AS OPP_STAGE_DELTA_DAYS_STAGE_1_STAGE_2,
	                    DATEDIFF(day,OPP_STAGE_2_DATE,OPP_STAGE_3_DATE) AS OPP_STAGE_DELTA_DAYS_STAGE_2_STAGE_3,
	                    DATEDIFF(day,OPP_STAGE_3_DATE,OPP_STAGE_4_DATE) AS OPP_STAGE_DELTA_DAYS_STAGE_3_STAGE_4,
	                    DATEDIFF(day,OPP_STAGE_4_DATE,OPP_STAGE_5_DATE) AS OPP_STAGE_DELTA_DAYS_STAGE_4_STAGE_5,                    
	                    DATEDIFF(day,OPP_STAGE_5_DATE,OPP_STAGE_6_DATE) AS OPP_STAGE_DELTA_DAYS_STAGE_5_STAGE_6,
	                    DATEDIFF(day,OPP_STAGE_6_DATE,OPP_STAGE_7_DATE) AS OPP_STAGE_DELTA_DAYS_STAGE_6_STAGE_7,
	                	DATEDIFF(day,OPP_STAGE_7_DATE,OPP_WIN_DATE) AS OPP_STAGE_DELTA_DAYS_STAGE_7_WIN
	                FROM
	                (
	                SELECT
	                    opp.id,
	                    COALESCE(CAST(n2.stage0 as date), CAST(opp.created_date AS date)) AS OPP_STAGE_0_DATE,
	                    CAST(n2.stage1 as date) AS OPP_STAGE_1_DATE,
	                    CAST(n2.stage2 as date) AS OPP_STAGE_2_DATE,
	                    CAST(n2.stage3 as date) AS OPP_STAGE_3_DATE, 
	                    CAST(n2.stage4 as date) AS OPP_STAGE_4_DATE,
	                    CAST(n2.stage5 as date) AS OPP_STAGE_5_DATE,
	                    CAST(n2.stage6 as date) AS OPP_STAGE_6_DATE, 
	                    CAST(n2.stage7 as date) AS OPP_STAGE_7_DATE,
	                    CAST(n2.win as date) AS OPP_WIN_DATE                    
	                FROM
	                    dp_prod_db.salesforce.opportunity opp
	                    LEFT JOIN (
	                            select distinct 
	                            	opportunity_id, 
	                            	case when identify < '10-08-2024' then identify
	                            		else nurture end as stage0,
	                            	case when "analyze" < '10-08-2024' then "analyze"
	                            		else "qualify" end as stage1,                            	
	                            	case when present < '10-08-2024' then present
	                            		else discover end as stage2,
	                            	case when prove < '10-08-2024' then prove
	                            		else propose end as stage3,
	                            	case when finalize < '10-08-2024' then finalize
	                            		else validate end as stage4,
	                            	negotiate as stage5,    
	                            	case when present >= '10-08-2024' then present
	                            		else null end as stage6,                            	
	                            	case when prove >= '10-08-2024' then prove
	                            		else null end as stage7,
	                            	win  

	                            FROM
	                                (
	                                      SELECT
	                                         opportunity_id,
	                                         created_date,
	                                         new_value

	                                    FROM
	                                        dp_prod_db.salesforce.opportunity_field_history
	                                    WHERE
	                                        field = 'StageName'
	                                        
	                                        and 
	                                          new_value  in                         
											(
	                                        'Identify',
	                                        'Analyze',
	                                        'Present',
	                                        'Prove',
	                                        'Finalize',
	                                        'Nurture',
	                                        'Qualify',
	                                        'Discover',
	                                        'Propose',
	                                        'Validate',
	                                        'Negotiate'
	                                    )                                    
	                                        
	                                        
	                                        union all
	                                        
	                                        
	                                        
	                                        
	                                       SELECT
	                                         opportunity_id,
	                                        max(created_date) as created_date,
	                                        'Win' as new_value

	                                    FROM
	                                        dp_prod_db.salesforce.opportunity_field_history
	                                    WHERE
	                                        field = 'StageName'
	                                        
	                                        and 
	                                          new_value in                         
	                                                        (
							                'Closed - Booked',
							                'Closed - Booked (SO)',
							                'Closed - Parent',
							                'Closed - Ready to Book',
							                'Closed Won',
							                'On Hold',
							                'Pending Additional Signature',
							                'Pending Approval',
							                'Pending Client Signature')
							                group by opportunity_id
	                                        
	                                ) PIVOT (
	                                    MIN(CREATED_DATE) FOR new_value IN (
	                                        'Identify',
	                                        'Analyze',
	                                        'Present',
	                                        'Prove',
	                                        'Finalize',
	                                        'Nurture',
	                                        'Qualify',
	                                        'Discover',
	                                        'Propose',
	                                        'Validate',
	                                        'Negotiate',
	                                        'Win'
	                                    )
	                                ) 
	                    ) AS n2 ON opp.id = n2.opportunity_id
	                    )  as opp_velocity
	                ) as opp_stage_velocity
	                ON amlh.AMLH_OPPORTUNITY__C = opp_stage_velocity.OPPORTUNITY_ID


	        WHERE
	            act.INTERNAL_TEST_ACCOUNT__C = FALSE
	            AND act.IS_DELETED = FALSE
	            --AND act.ID = '0011E00001lPaVSQA0'
	            --AND opp.ID = '0066R00000q8Hw4QAE'
	        ORDER BY
	            AMLH_ACCOUNT__C,
	            AMLH_RECYCLE_COUNTER__C ASC,
	            AMLH_ACTIVE_MARKETING_LIFECYCLE_RECORD__C DESC,
	            AMLH_CREATED_DATE
	    );   
	   
	 -- Step 03a: Touchtype 6Sense Paid Media Performance Files
	 DROP TABLE IF EXISTS DP_PROD_DB.ACT_MRKT_LIFECYCLE.TOUCHTYPE_6SENSE_PAIDMEDIA;
	    CREATE TABLE DP_PROD_DB.ACT_MRKT_LIFECYCLE.TOUCHTYPE_6SENSE_PAIDMEDIA as

	 SELECT
	    *
	FROM
	    (
	        SELECT
	            -- 6Sense Paid Media Vendor File
	            '6Sense - Paid Media' AS MARKETING_TOUCH_TYPE_DATA_SOURCE,
	            abm_pd.CRM_ACCOUNT_ID,
		        CAST(abm_pd.DATE as DATE) AS MARKETING_TOUCHPOINT_DATE,
	            -- Deriving the Touch Type
	            CASE
	                WHEN (
	                    abm_pd.IMPRESSIONS > 0
	                    AND abm_pd.CLICKS > 0
	                ) THEN 'Impression and Ad Click'
	                WHEN (
	                    abm_pd.IMPRESSIONS > 0
	                    AND abm_pd.CLICKS = 0
	                ) THEN 'Impression'
	                WHEN (
	                    abm_pd.IMPRESSIONS = 0
	                    AND abm_pd.CLICKS > 0
	                ) THEN 'Ad Click'
	            END AS MARKETING_TOUCH_TYPE,
	            -- Deriving the Touch Type Count
	            CASE
	                WHEN (
	                    abm_pd.IMPRESSIONS > 0
	                    AND abm_pd.CLICKS > 0
	                ) THEN (abm_pd.IMPRESSIONS + abm_pd.CLICKS)
	                WHEN (
	                    abm_pd.IMPRESSIONS > 0
	                    AND abm_pd.CLICKS = 0
	                ) THEN abm_pd.IMPRESSIONS
	                WHEN (
	                    abm_pd.IMPRESSIONS = 0
	                    AND abm_pd.CLICKS > 0
	                ) THEN abm_pd.CLICKS
	            END AS MARKETING_TOUCH_TYPE_COUNT,
	            abm_pd.IMPRESSIONS AS INTERACTIONTYPE_SIXSENSE_PAIDMEDIA_IMPRESSIONS_COUNT,
	            abm_pd.CLICKS AS INTERACTIONTYPE_SIXSENSE_PAIDMEDIA_CLICKS_COUNT,
	            -- Designating the Acquisition Channel to align with the Bizible Channel Mapping
	            CASE
	                WHEN AD_VENDOR = '6Sense - Media' THEN 'Display.6Sense'
	                WHEN AD_VENDOR = '6Sense - External' THEN 'Display.6Sense.External'
	                WHEN AD_VENDOR = '6Sense - LinkedIn' THEN 'Paid Social.6Sense.LinkedIn'
	            END AS INFLUENCE_CHANNEL,
	            -- Designating the Acquisition Web Source
	            '6sense' AS INFLUENCE_WEB_SOURCE,
	            -- Designating the Acquisition Web Medium
	            CASE
	                WHEN AD_VENDOR = '6Sense - Media' THEN 'display'
	                WHEN AD_VENDOR = '6Sense - External' THEN 'display'
	                WHEN AD_VENDOR = '6Sense - LinkedIn' THEN 'paidsocial'
	            END AS INFLUENCE_WEB_MEDIUM,
	            -- Designating the Acquisition Campaign
	            abm_pd.CAMPAIGN_NAME AS INFLUENCE_CAMPAIGN_NAME,
	            -- Assigning (not set) value to the following fields. Hopefully we can map fields into the below
	            '(not set)' AS INFLUENCE_CREATIVE_NAME,
	            '(not set)' AS INFLUENCE_LANDING_PAGE,
	            '(not set)' AS INFLUENCE_REFERRER,
	            -- This is more applicable for the 6Sense Web Visit file where you can go from page 1 to page 2 and the webvisit page would be the page you are on
	            '(not set)' AS WEBVISIT_PAGE,
	            '(not set)' AS WEBVISIT_REFERRER
	        FROM
	            (
	                SELECT
	                    CRM_ACCOUNT_ID,
	                    AD_VENDOR,
	                    CAMPAIGN_ID,
	                    CAMPAIGN_NAME,
	                    DATE,
	                    SUM(COALESCE(IMPRESSIONS,0)) AS IMPRESSIONS,
	                    SUM(COALESCE(CLICKS,0)) AS CLICKS,
	                    SUM(COALESCE(NEWLY_ENGAGED,0)) AS NEWLY_ENGAGED,
	                    SUM(COALESCE(INCREASED_ENGAGEMENT,0)) AS INCREASED_ENGAGEMENT,
	                    SUM(COALESCE(SPEND,0)) AS SPEND
	                FROM
	                    (
	                        SELECT
	                            RECORD_CREATION_TS,
	                            CRM_ACCOUNT_ID,
	                            CRM_ACCOUNT_NAME,
	                            CRM_ACCOUNT_COUNTRY,
	                            CRM_ACCOUNT_DOMAIN,
	                            "6SENSE_MID",
	                            "6SENSE_ACCOUNT_NAME",
	                            "6SENSE_ACCOUNT_COUNTRY",
	                            "6SENSE_ACCOUNT_DOMAIN",
	                            AD_ID,
	                            AD_NAME,
	                            AD_GROUP,
	                            '6Sense - Media' AS AD_VENDOR,
	                            "6SENSE_CAMPAIGN_ID" AS CAMPAIGN_ID,
	                            "6SENSE_CAMPAIGN_NAME" AS CAMPAIGN_NAME,
	                            DATE,
	                            IMPRESSIONS,
	                            CLICKS,
	                            NEWLY_ENGAGED,
	                            INCREASED_ENGAGEMENT,
	                            SPEND
	                        FROM
	                            DP_PROD_DB.SIX_SENSE.SIX_SENSE_MEDIA
	                        UNION
	                        SELECT
	                            RECORD_CREATION_TS,
	                            CRM_ACCOUNT_ID,
	                            CRM_ACCOUNT_NAME,
	                            CRM_ACCOUNT_COUNTRY,
	                            CRM_ACCOUNT_DOMAIN,
	                            "6SENSE_MID",
	                            "6SENSE_ACCOUNT_NAME",
	                            "6SENSE_ACCOUNT_COUNTRY",
	                            "6SENSE_ACCOUNT_DOMAIN",
	                            AD_ID,
	                            AD_NAME,
	                            AD_GROUP,
	                            '6Sense - LinkedIn' AS AD_VENDOR,
	                            LINKEDIN_CAMPAIGN_ID AS CAMPAIGN_ID,
	                            LINKEDIN_CAMPAIGN_NAME AS CAMPAIGN_NAME,
	                            DATE,
	                            IMPRESSIONS,
	                            CLICKS,
	                            NEWLY_ENGAGED,
	                            INCREASED_ENGAGEMENT,
	                            SPEND
	                        FROM
	                            DP_PROD_DB.SIX_SENSE.LINKEDIN_MEDIA
	                        UNION
	                        SELECT
	                            RECORD_CREATION_TS,
	                            CRM_ACCOUNT_ID,
	                            CRM_ACCOUNT_NAME,
	                            CRM_ACCOUNT_COUNTRY,
	                            CRM_ACCOUNT_DOMAIN,
	                            "6SENSE_MID",
	                            "6SENSE_ACCOUNT_NAME",
	                            "6SENSE_ACCOUNT_COUNTRY",
	                            "6SENSE_ACCOUNT_DOMAIN",
	                            "6SENSE_AD_ID" AS AD_ID,
	                            "6SENSE_AD_NAME" AS AD_NAME,
	                            AD_GROUP,
	                            '6Sense - External' AS AD_VENDOR,
	                            "6SENSE_CAMPAIGN_ID" AS CAMPAIGN_ID,
	                            "6SENSE_CAMPAIGN_NAME" AS CAMPAIGN_NAME,
	                            DATE,
	                            IMPRESSIONS,
	                            CLICKS,
	                            NEWLY_ENGAGED,
	                            INCREASED_ENGAGEMENT,
	                            NULL AS SPEND
	                        FROM
	                            DP_PROD_DB.SIX_SENSE.EXTERNAL_MEDIA
	                    ) AS x
	                GROUP BY
	                    CRM_ACCOUNT_ID,
	                    AD_VENDOR,
	                    CAMPAIGN_ID,
	                    CAMPAIGN_NAME,
	                    DATE,
	                    LAST_DAY(cast("DATE" as DATE)),
	                    cast(dateadd(day, -1, dateadd(QTR,1,DATE_TRUNC('QTR', cast("DATE" as DATE)))) as date)
	                HAVING
	                    (
	                        SUM(COALESCE(IMPRESSIONS,0)) + SUM(COALESCE(CLICKS,0))
	                    ) > 0
	                ORDER BY
	                    LAST_DAY(cast("DATE" as DATE)) DESC
	            ) as abm_pd
	    );

	    -- Step 03b: Touchtype 6Sense Web Visit Activity Files
	 DROP TABLE IF EXISTS DP_PROD_DB.ACT_MRKT_LIFECYCLE.TOUCHTYPE_6SENSE_WEBVISIT; 
	    CREATE TABLE DP_PROD_DB.ACT_MRKT_LIFECYCLE.TOUCHTYPE_6SENSE_WEBVISIT as

	SELECT
	    *
	FROM
	    (
	        SELECT
	            -- 6Sense Web Visit Vendor File
	            '6Sense - Web Visit' AS MARKETING_TOUCH_TYPE_DATA_SOURCE,
	            -- Dimensions
	            webvisit.CRM_ACCOUNT_ID,
	            CAST(webvisit.DATE_VISITED as DATE) AS MARKETING_TOUCHPOINT_DATE,
	            -- Deriving the Touch Type
	            CASE
	                WHEN (
	                    COALESCE(webvisit.Total_a_pageload,0) > 0
	                    AND (
	                        (
	                            COALESCE(Total_play,0) + COALESCE(Total_click,0) + COALESCE(Total_submit,0) > 0
	                        )
	                    )
	                ) THEN 'Web Visit and Interaction'
	                WHEN (
	                    COALESCE(webvisit.Total_a_pageload,0) = 0
	                    AND (
	                        (
	                            COALESCE(Total_play,0) + COALESCE(Total_click,0) + COALESCE(Total_submit,0) > 0
	                        )
	                    )
	                ) THEN 'Interaction'
	                WHEN (
	                    COALESCE(webvisit.Total_a_pageload,0) > 0
	                    AND (
	                        (
	                            COALESCE(Total_play,0) + COALESCE(Total_click,0) + COALESCE(Total_submit,0) = 0
	                        )
	                    )
	                ) THEN 'Web Visit'
	                WHEN (COALESCE(webvisit.Total_a_pageload,0)) > 0 THEN 'Web Visit'
	                WHEN (COALESCE(webvisit.Total_unclassified,0)) > 0 THEN 'Unclassified'
	            END AS MARKETING_TOUCH_TYPE,
	            -- Deriving the Touch Type Count
	            CASE
	                WHEN (
	                    COALESCE(webvisit.Total_a_pageload,0) > 0
	                    AND (
	                        (
	                            COALESCE(Total_play,0) + COALESCE(Total_click,0) + COALESCE(Total_submit,0)
	                        ) > 0
	                    )
	                ) THEN (
	                    COALESCE(webvisit.Total_a_pageload,0) + (
	                        COALESCE(Total_play,0) + COALESCE(Total_click,0) + COALESCE(Total_submit,0)
	                    )
	                )
	                WHEN (
	                    COALESCE(webvisit.Total_a_pageload,0) = 0
	                    AND (
	                        (
	                            COALESCE(Total_play,0) + COALESCE(Total_click,0) + COALESCE(Total_submit,0)
	                        ) > 0
	                    )
	                ) THEN (
	                    COALESCE(Total_play,0) + COALESCE(Total_click,0) + COALESCE(Total_submit,0)
	                )
	                WHEN (
	                    COALESCE(webvisit.Total_a_pageload,0) > 0
	                    AND (
	                        (
	                            COALESCE(Total_play,0) + COALESCE(Total_click,0) + COALESCE(Total_submit,0)
	                        ) = 0
	                    )
	                ) THEN webvisit.Total_a_pageload
	                WHEN (COALESCE(webvisit.Total_a_pageload,0)) > 0 THEN webvisit.Total_a_pageload
	                WHEN (COALESCE(webvisit.Total_unclassified,0)) > 0 THEN webvisit.Total_unclassified
	            END AS MARKETING_TOUCH_TYPE_COUNT,
	            -- Metrics from 6Sense WebVisit File
	            COALESCE(webvisit.Total_interaction,0) INTERACTIONTYPE_SIXSENSE_WEBVISIT_TOTAL_INTERACTIONS_COUNT,
	            COALESCE(webvisit.Total_a_pageload,0) AS INTERACTIONTYPE_SIXSENSE_WEBVISIT_PAGELOAD_COUNT,
	            COALESCE(webvisit.Total_play,0) AS INTERACTIONTYPE_SIXSENSE_WEBVISIT_PLAY_COUNT,
	            COALESCE(webvisit.Total_click,0) AS INTERACTIONTYPE_SIXSENSE_WEBVISIT_CLICK_COUNT,
	            COALESCE(webvisit.Total_submit,0) AS INTERACTIONTYPE_SIXSENSE_WEBVISIT_SUBMIT_COUNT,
	            COALESCE(webvisit.Total_unclassified,0) AS INTERACTIONTYPE_SIXSENSE_WEBVISIT_UNCLASSIFIED_COUNT,
	            --webvisit.UTM_SOURCE,
	            --webvisit.UTM_MEDIUM,
	            -- Izzi logic to call the highest rank utm_source by date visited if utm_source and utm_medium is null while the referrer domain containing lytx.com
	            CASE
	                WHEN (
	                    webvisit.UTM_SOURCE IS NULL
	                    AND webvisit.UTM_MEDIUM IS NULL
	                )
	                AND (
	                    LOWER(webvisit.REFERRER_DOMAIN) LIKE '%lytx.com%'
	                    or webvisit.REFERRER_DOMAIN is null
	                ) THEN coalesce(webvisit.UTM_SOURCE, rnkcoalesce.UTM_SOURCE)
	                ELSE webvisit.UTM_SOURCE
	            end as INFLUENCE_WEB_SOURCE,
	            -- Izzi logic to call the highest rank utm_medium by date visited if utm_source and utm_medium is null while the referrer domain containing lytx.com
	            CASE
	                WHEN (
	                    webvisit.UTM_SOURCE IS NULL
	                    AND webvisit.UTM_MEDIUM IS NULL
	                )
	                AND (
	                    LOWER(webvisit.REFERRER_DOMAIN) LIKE '%lytx.com%'
	                    or webvisit.REFERRER_DOMAIN is null
	                ) THEN coalesce(webvisit.UTM_MEDIUM, rnkcoalesce.UTM_MEDIUM)
	                ELSE webvisit.UTM_MEDIUM
	            end as INFLUENCE_WEB_MEDIUM,
	            -- Top Level Channel and Subchannel Strategy
	            CASE
	                -- Using Izzi logic to define upfront Other.Misc
	                WHEN (
	                    webvisit.UTM_SOURCE IS NULL
	                    and webvisit.UTM_MEDIUM IS NULL
	                    AND REFERRER_DOMAIN IS NULL
	                ) THEN 'Other.NotDefined'
	                WHEN (
	                    webvisit.UTM_SOURCE IS NULL
	                    and webvisit.UTM_MEDIUM IS NULL
	                )
	                AND REFERRER_DOMAIN LIKE '%app.asana.com%' THEN 'Other.Misc'
	                WHEN (
	                    webvisit.UTM_SOURCE IS NULL
	                    and webvisit.UTM_MEDIUM IS NULL
	                )
	                AND REFERRER_DOMAIN LIKE '%app.drift.com%' THEN 'Other.Misc'
	                WHEN (
	                    webvisit.UTM_SOURCE IS NULL
	                    and webvisit.UTM_MEDIUM IS NULL
	                )
	                AND REFERRER_DOMAIN LIKE '%app.mutinyhq.com%' THEN 'Other.Misc'
	                WHEN (
	                    webvisit.UTM_SOURCE IS NULL
	                    and webvisit.UTM_MEDIUM IS NULL
	                )
	                AND REFERRER_DOMAIN LIKE '%app.reactful.com%' THEN 'Other.Misc'
	                WHEN (
	                    webvisit.UTM_SOURCE IS NULL
	                    and webvisit.UTM_MEDIUM IS NULL
	                )
	                AND REFERRER_DOMAIN LIKE '%app.uberflip%' THEN 'Other.Misc'
	                WHEN (
	                    webvisit.UTM_SOURCE IS NULL
	                    and webvisit.UTM_MEDIUM IS NULL
	                )
	                AND REFERRER_DOMAIN LIKE '%app.%' THEN 'Other.Misc'
	                WHEN (
	                    webvisit.UTM_SOURCE IS NULL
	                    and webvisit.UTM_MEDIUM IS NULL
	                )
	                AND REFERRER_DOMAIN LIKE '%abm.6sense.com%' THEN 'Other.Misc'
	                WHEN (
	                    webvisit.UTM_SOURCE IS NULL
	                    and webvisit.UTM_MEDIUM IS NULL
	                )
	                AND REFERRER_DOMAIN LIKE '%clicktools.com%' THEN 'Other.Misc'
	                WHEN (
	                    webvisit.UTM_SOURCE IS NULL
	                    and webvisit.UTM_MEDIUM IS NULL
	                )
	                AND REFERRER_DOMAIN LIKE '%teams.microsoft.com%' THEN 'Other.Misc'
	                WHEN (
	                    webvisit.UTM_SOURCE IS NULL
	                    and webvisit.UTM_MEDIUM IS NULL
	                )
	                AND REFERRER_DOMAIN LIKE '%teams.microsoft.com%' THEN 'Other.Misc'
	                WHEN (
	                    webvisit.UTM_SOURCE IS NULL
	                    and webvisit.UTM_MEDIUM IS NULL
	                )
	                AND REFERRER_DOMAIN LIKE '%lightning.force.com%' THEN 'Other.Misc'
	                WHEN (
	                    webvisit.UTM_SOURCE IS NULL
	                    and webvisit.UTM_MEDIUM IS NULL
	                )
	                AND REFERRER_DOMAIN LIKE '%lightning.force.com%' THEN 'Other.Misc'
	                -- Organic Search
	                WHEN (
	                    webvisit.UTM_SOURCE IS NULL
	                    and webvisit.UTM_MEDIUM IS NULL
	                )
	                AND REFERRER_DOMAIN LIKE '%google%' THEN 'Organic Search.Google'
	                WHEN (
	                    webvisit.UTM_SOURCE IS NULL
	                    and webvisit.UTM_MEDIUM IS NULL
	                )
	                AND REFERRER_DOMAIN LIKE '%bing%' THEN 'Organic Search.Bing'
	                WHEN (
	                    webvisit.UTM_SOURCE IS NULL
	                    and webvisit.UTM_MEDIUM IS NULL
	                )
	                AND REFERRER_DOMAIN LIKE '%yahoo%' THEN 'Organic Search.Yahoo'
	                WHEN (
	                    webvisit.UTM_SOURCE IS NULL
	                    and webvisit.UTM_MEDIUM IS NULL
	                )
	                AND REFERRER_DOMAIN LIKE '%duckduckgo%' THEN 'Organic Search.DuckDuckGo'
	                -- Organic Social
	                WHEN (
	                    webvisit.UTM_SOURCE IS NULL
	                    and webvisit.UTM_MEDIUM IS NULL
	                )
	                AND REFERRER_DOMAIN LIKE '%linkedin%' THEN 'Organic Social.LinkedIn'
	                WHEN (
	                    webvisit.UTM_SOURCE IS NULL
	                    and webvisit.UTM_MEDIUM IS NULL
	                )
	                AND REFERRER_DOMAIN LIKE '%facebook%' THEN 'Organic Social.Facebook'
	                WHEN (
	                    webvisit.UTM_SOURCE IS NULL
	                    and webvisit.UTM_MEDIUM IS NULL
	                )
	                AND REFERRER_DOMAIN LIKE '%twitter%' THEN 'Organic Social.Twitter' -- The following is using the adjusted UTM_Soure and UTM_Medium to declare the Top Level Channel and SubChannel
	                -- organic search
	                WHEN INFLUENCE_WEB_SOURCE = 'google'
	                and INFLUENCE_WEB_MEDIUM = 'organic search' THEN 'Organic Search.Google'
	                WHEN INFLUENCE_WEB_SOURCE = 'bing'
	                and INFLUENCE_WEB_MEDIUM = 'organic search' THEN 'Organic Search.Bing'
	                WHEN INFLUENCE_WEB_SOURCE = 'yahoo'
	                and INFLUENCE_WEB_MEDIUM = 'organic search' THEN 'Organic Search.Yahoo'
	                WHEN INFLUENCE_WEB_SOURCE = 'duckduckgo'
	                and INFLUENCE_WEB_MEDIUM = 'organic search' THEN 'Organic Search.DuckDuckGo'
	                -- organic social
	                WHEN INFLUENCE_WEB_SOURCE = 'linkedin'
	                and INFLUENCE_WEB_MEDIUM = 'organic social' THEN 'Organic Social.LinkedIn'
	                WHEN INFLUENCE_WEB_SOURCE = 'facebook'
	                and INFLUENCE_WEB_MEDIUM = 'organic social' THEN 'Organic Social.Facebook'
	                WHEN INFLUENCE_WEB_SOURCE = 'twitter'
	                and INFLUENCE_WEB_MEDIUM = 'organic social' THEN 'Organic Social.Twitter' -- 6Sense
	                WHEN INFLUENCE_WEB_SOURCE = '6sense'
	                and INFLUENCE_WEB_MEDIUM IN ('cpc', 'display', 'ppc') THEN 'Display.6Sense'
	                WHEN INFLUENCE_WEB_SOURCE = '6sense' THEN 'Display.6Sense.External'
	                -- Google
	                WHEN INFLUENCE_WEB_SOURCE = 'google'
	                and INFLUENCE_WEB_MEDIUM IN ('cpc', 'ppc', 'cpcignore', 'pc') THEN 'Paid Search.Google'
	                WHEN INFLUENCE_WEB_SOURCE = 'google'
	                and INFLUENCE_WEB_MEDIUM IN ('display', 'banner') THEN 'Display.Google'
	                WHEN INFLUENCE_WEB_SOURCE = 'google'
	                and INFLUENCE_WEB_MEDIUM IS NULL THEN 'Organic Search.Google'
	                WHEN INFLUENCE_WEB_SOURCE IN ('adwords', 'marketingplatformgooglecom') THEN 'Paid Search.Google'
	                -- YouTube
	                WHEN INFLUENCE_WEB_SOURCE = 'youtube'
	                and INFLUENCE_WEB_MEDIUM IN ('cpc') THEN 'Paid Search' || '.' || COALESCE(INFLUENCE_WEB_SOURCE,'')
	                WHEN INFLUENCE_WEB_SOURCE = 'youtube'
	                and INFLUENCE_WEB_MEDIUM IN ('paidsocial') THEN 'Paid Social' || '.' || COALESCE(INFLUENCE_WEB_SOURCE,'')
	                WHEN INFLUENCE_WEB_SOURCE = 'youtube'
	                and INFLUENCE_WEB_MEDIUM IN ('social', 'referral') THEN 'Organic Social.Youtube'
	                WHEN INFLUENCE_WEB_SOURCE = 'youtube' THEN 'Organic Social.Youtube'
	                -- Bing
	                WHEN INFLUENCE_WEB_SOURCE = 'bing'
	                and INFLUENCE_WEB_MEDIUM IN ('cpc', 'ppc', 'cpcignore', 'pc') THEN 'Paid Search.Bing'
	                WHEN INFLUENCE_WEB_SOURCE = 'bing'
	                and INFLUENCE_WEB_MEDIUM IN ('display', 'banner') THEN 'Display.Bing'
	                WHEN INFLUENCE_WEB_SOURCE = 'bing'
	                and INFLUENCE_WEB_MEDIUM IS NULL THEN 'Organic Search.Bing'
	                -- Yahoo
	                WHEN INFLUENCE_WEB_SOURCE = 'yahoo'
	                and INFLUENCE_WEB_MEDIUM IS NULL THEN 'Organic Search.Yahoo'
	                -- Capterra
	                WHEN INFLUENCE_WEB_SOURCE = 'capterra'
	                and INFLUENCE_WEB_MEDIUM IN ('cpc', 'ppc') THEN 'Paid Search' || '.' || COALESCE(INFLUENCE_WEB_SOURCE,'')
	                -- Facebook
	                WHEN INFLUENCE_WEB_SOURCE = 'facebook'
	                and INFLUENCE_WEB_MEDIUM IN ('paidsocial', 'cpc') THEN 'Paid Social.Facebook'
	                WHEN INFLUENCE_WEB_SOURCE = 'facebook'
	                and INFLUENCE_WEB_MEDIUM IN ('social', 'referral') THEN 'Organic Social.Facebook'
	                WHEN INFLUENCE_WEB_SOURCE = 'facebook'
	                or INFLUENCE_WEB_MEDIUM = 'facebook' THEN 'Organic Social.Facebook'
	                -- Twitter
	                WHEN INFLUENCE_WEB_SOURCE = 'twitter'
	                and INFLUENCE_WEB_MEDIUM IN ('paidsocial', 'cpc') THEN 'Paid Social.Twitter'
	                WHEN INFLUENCE_WEB_SOURCE = 'twitter'
	                and INFLUENCE_WEB_MEDIUM IN ('social', 'referral') THEN 'Organic Social.Twitter'
	                WHEN INFLUENCE_WEB_SOURCE = 'twitter'
	                or INFLUENCE_WEB_MEDIUM = 'twitter' THEN 'Organic Social.Twitter'
	                -- Linkedin
	                WHEN INFLUENCE_WEB_SOURCE = 'linkedin'
	                and INFLUENCE_WEB_MEDIUM IN ('paidsocial', 'cpc') THEN 'Paid Social.LinkedIn'
	                WHEN INFLUENCE_WEB_SOURCE = 'linkedin'
	                and INFLUENCE_WEB_MEDIUM IN ('social', 'referral') THEN 'Organic Social.LinkedIn'
	                WHEN INFLUENCE_WEB_SOURCE = 'linkedin'
	                or INFLUENCE_WEB_MEDIUM = 'linkedin' THEN 'Organic Social.LinkedIn'
	                -- Else Not Defined
	                ELSE 'Other.NotDefined'
	            END AS INFLUENCE_CHANNEL,
	            '(not set)' AS INFLUENCE_CAMPAIGN_NAME,
	            '(not set)' AS INFLUENCE_CREATIVE_NAME,
	            '(not set)' AS INFLUENCE_LANDING_PAGE,
	            '(not set)' AS INFLUENCE_REFERRER,
	            webvisit.URL AS WEBVISIT_PAGE,
	            webvisit.REFERRER_DOMAIN AS WEBVISIT_REFERRER
	        FROM
	            -- This is the Master WebVisit DataSet as the Base Join Table
	            (
	                SELECT
	                    CRM_ACCOUNT_ID,
	                    DATE_VISITED,
	                    UTM_SOURCE,
	                    UTM_MEDIUM,
	                    URL,
	                    REFERRER_DOMAIN,
	                    SUM(COALESCE(Total_unclassified,0)) AS Total_unclassified,
	                    SUM(COALESCE(Total_a_pageload,0)) AS Total_a_pageload,
	                    SUM(COALESCE(Total_play,0)) AS Total_play,
	                    SUM(COALESCE(Total_click,0)) AS Total_click,
	                    SUM(COALESCE(Total_submit,0)) AS Total_submit,
	                    -- Excluding the Unclassified as part of the Total Interaction
	                    SUM(COALESCE(Total_a_pageload,0)) + SUM(COALESCE(Total_play,0)) + SUM(COALESCE(Total_click,0)) + SUM(COALESCE(Total_submit,0)) AS Total_interaction
	                FROM
	                    (
	                        select 
	                            pvt.RECORD_CREATION_TS,
	                            pvt.CRM_ACCOUNT_ID,
	                            pvt.CRM_ACCOUNT_NAME,
	                            pvt.CRM_ACCOUNT_COUNTRY,
	                            pvt.CRM_ACCOUNT_DOMAIN,
	                            pvt."6SENSE_MID",
	                            pvt."6SENSE_ACCOUNT_NAME",
	                            pvt."6SENSE_ACCOUNT_COUNTRY",
	                            pvt."6SENSE_ACCOUNT_DOMAIN",                            
	                            pvt.DATE_VISITED,
	                            pvt.URL,
	                            pvt.REFERRER_DOMAIN,
	                            pvt.UTM_SOURCE,
	                            pvt.UTM_MEDIUM,
	                            pvt."unclassified" as Total_unclassified,
	                            pvt."a_pageload" as Total_a_pageload,
	                            pvt."play" as Total_play,
	                            pvt."click" as Total_click,
	                            pvt."submit" as Total_submit
	                        FROM
	                            (
	                                select
	                                    *
	                                from
	                                    (
	                                        SELECT
	                                            *
	                                        FROM
	                                            DP_PROD_DB.SIX_SENSE.WEB_VISIT
	                                            --WHERE CRM_ACCOUNT_ID = '001300000048ENLAA2' AND DATE_VISITED = '2023-10-26'
	                                    ) PIVOT(
	                                        SUM(TOTAL) FOR EVENT IN (
	                                            'unclassified',
	                                            'a_pageload',
	                                            'play',
	                                            'click',
	                                            'submit'
	                                        )
	                                    ) as p
	                                ORDER BY
	                                    DATE_VISITED DESC,
	                                    URL
	                            ) as pvt
	                    ) AS X
	                GROUP BY
	                    CRM_ACCOUNT_ID,
	                    DATE_VISITED,
	                    UTM_SOURCE,
	                    UTM_MEDIUM,
	                    URL,
	                    REFERRER_DOMAIN
	            ) as webvisit
	            LEFT JOIN -- CODE THAT WILL BE USED TO DO A COALESCE TO FILL IN THE BLANK VALUES
	            -- This contains the specialized logic that will use the most frequent source/medium combination for that day when the UTM_Source and UTM_MEdium when is null
	            (
	                SELECT
	                    CRM_ACCOUNT_ID,
	                    DATE_VISITED,
	                    UTM_SOURCE,
	                    UTM_MEDIUM,
	                    RANK_BY_DAY
	                FROM
	                    (
	                        select
	                            CRM_ACCOUNT_ID,
	                            DATE_VISITED,
	                            UTM_SOURCE,
	                            UTM_MEDIUM,
	                            SUM(Total_interaction) AS Total_interaction,
	                            ROW_NUMBER() OVER (
	                                PARTITION BY CRM_ACCOUNT_ID,
	                                DATE_VISITED
	                                ORDER BY
	                                    CRM_ACCOUNT_ID,
	                                    DATE_VISITED,
	                                    SUM(Total_interaction) DESC,
	                                    UTM_SOURCE ASC,
	                                    UTM_MEDIUM ASC
	                            ) AS RANK_BY_DAY,
	                            SUM(Total_a_pageload) AS Total_a_pageload,
	                            SUM(Total_play) AS Total_play,
	                            SUM(Total_click) AS Total_click,
	                            SUM(Total_submit) AS Total_submit,
	                            SUM(Total_unclassified) AS Total_unclassified
	                        FROM
	                            (
	                                SELECT
	                                    CRM_ACCOUNT_ID,
	                                    DATE_VISITED,
	                                    UTM_SOURCE,
	                                    UTM_MEDIUM,
	                                    URL,
	                                    REFERRER_DOMAIN,
	                                    SUM(COALESCE(Total_unclassified,0)) AS Total_unclassified,
	                                    SUM(COALESCE(Total_a_pageload,0)) AS Total_a_pageload,
	                                    SUM(COALESCE(Total_play,0)) AS Total_play,
	                                    SUM(COALESCE(Total_click,0)) AS Total_click,
	                                    SUM(COALESCE(Total_submit,0)) AS Total_submit,
	                                    SUM(COALESCE(Total_a_pageload,0)) + SUM(COALESCE(Total_play,0)) + SUM(COALESCE(Total_click,0)) + SUM(COALESCE(Total_submit,0)) AS Total_interaction
	                                FROM
	                                    (
	                                        SELECT
	                                            pvt.RECORD_CREATION_TS,
	                                            pvt.CRM_ACCOUNT_ID,
	                                            pvt.CRM_ACCOUNT_NAME,
	                                            pvt.CRM_ACCOUNT_COUNTRY,
	                                            pvt.CRM_ACCOUNT_DOMAIN,
	                                            pvt."6SENSE_MID",
	                                            pvt."6SENSE_ACCOUNT_NAME",
	                                            pvt."6SENSE_ACCOUNT_COUNTRY",
	                                            pvt."6SENSE_ACCOUNT_DOMAIN",
	                                            pvt.DATE_VISITED,
	                                            pvt.URL,
	                                            pvt.REFERRER_DOMAIN,
	                                            --pvt.UTM_SOURCE,
	                                            CASE
	                                                WHEN pvt.UTM_SOURCE IS NOT NULL THEN pvt.UTM_SOURCE -- Organic Search
	                                                WHEN (
	                                                    pvt.UTM_SOURCE IS NULL
	                                                    and pvt.UTM_MEDIUM IS NULL
	                                                )
	                                                AND pvt.REFERRER_DOMAIN LIKE '%google%' THEN 'google'
	                                                WHEN (
	                                                    pvt.UTM_SOURCE IS NULL
	                                                    and pvt.UTM_MEDIUM IS NULL
	                                                )
	                                                AND pvt.REFERRER_DOMAIN LIKE '%bing%' THEN 'bing'
	                                                WHEN (
	                                                    pvt.UTM_SOURCE IS NULL
	                                                    and pvt.UTM_MEDIUM IS NULL
	                                                )
	                                                AND pvt.REFERRER_DOMAIN LIKE '%yahoo%' THEN 'yahoo'
	                                                -- Organic Social
	                                                WHEN (
	                                                    pvt.UTM_SOURCE IS NULL
	                                                    and pvt.UTM_MEDIUM IS NULL
	                                                )
	                                                AND pvt.REFERRER_DOMAIN LIKE '%duckduckgo%' THEN 'duckduckgo'
	                                                WHEN (
	                                                    pvt.UTM_SOURCE IS NULL
	                                                    and pvt.UTM_MEDIUM IS NULL
	                                                )
	                                                AND pvt.REFERRER_DOMAIN LIKE '%linkedin%' THEN 'linkedin'
	                                                WHEN (
	                                                    pvt.UTM_SOURCE IS NULL
	                                                    and pvt.UTM_MEDIUM IS NULL
	                                                )
	                                                AND pvt.REFERRER_DOMAIN LIKE '%facebook%' THEN 'facebook'
	                                                WHEN (
	                                                    pvt.UTM_SOURCE IS NULL
	                                                    and pvt.UTM_MEDIUM IS NULL
	                                                )
	                                                AND pvt.REFERRER_DOMAIN LIKE '%twitter%' THEN 'twitter'
	                                                ELSE pvt.UTM_SOURCE
	                                            END AS UTM_SOURCE,
	                                            --pvt.UTM_MEDIUM,
	                                            CASE
	                                                WHEN pvt.UTM_MEDIUM IS NOT NULL THEN pvt.UTM_MEDIUM -- Organic Search
	                                                WHEN (
	                                                    pvt.UTM_MEDIUM IS NULL
	                                                    and pvt.UTM_MEDIUM IS NULL
	                                                )
	                                                AND pvt.REFERRER_DOMAIN LIKE '%google%' THEN 'organic search'
	                                                WHEN (
	                                                    pvt.UTM_MEDIUM IS NULL
	                                                    and pvt.UTM_MEDIUM IS NULL
	                                                )
	                                                AND pvt.REFERRER_DOMAIN LIKE '%bing%' THEN 'organic search'
	                                                WHEN (
	                                                    pvt.UTM_MEDIUM IS NULL
	                                                    and pvt.UTM_MEDIUM IS NULL
	                                                )
	                                                AND pvt.REFERRER_DOMAIN LIKE '%yahoo%' THEN 'organic search'
	                                                WHEN (
	                                                    pvt.UTM_MEDIUM IS NULL
	                                                    and pvt.UTM_MEDIUM IS NULL
	                                                )
	                                                AND pvt.REFERRER_DOMAIN LIKE '%duckduckgo%' THEN 'organic search'
	                                                -- Organic Social
	                                                WHEN (
	                                                    pvt.UTM_MEDIUM IS NULL
	                                                    and pvt.UTM_MEDIUM IS NULL
	                                                )
	                                                AND pvt.REFERRER_DOMAIN LIKE '%linkedin%' THEN 'organic social'
	                                                WHEN (
	                                                    pvt.UTM_MEDIUM IS NULL
	                                                    and pvt.UTM_MEDIUM IS NULL
	                                                )
	                                                AND pvt.REFERRER_DOMAIN LIKE '%facebook%' THEN 'organic social'
	                                                WHEN (
	                                                    pvt.UTM_MEDIUM IS NULL
	                                                    and pvt.UTM_MEDIUM IS NULL
	                                                )
	                                                AND pvt.REFERRER_DOMAIN LIKE '%twitter%' THEN 'organic social'
	                                                ELSE pvt.UTM_MEDIUM
	                                            END AS UTM_MEDIUM,
	                                            pvt."unclassified" as Total_unclassified,
	                                            pvt."a_pageload" as Total_a_pageload,
	                                            pvt."play" as Total_play,
	                                            pvt."click" as Total_click,
	                                            pvt."submit" as Total_submit
	                                        FROM
	                                            (
	                                                select
	                                                    *
	                                                from
	                                                    (
	                                                        SELECT
	                                                            *
	                                                        FROM
	                                                            DP_PROD_DB.SIX_SENSE.WEB_VISIT
	                                                            --WHERE CRM_ACCOUNT_ID = '0016R00003EnYlPQAV' AND DATE_VISITED = '2023-04-28'
	                                                    ) PIVOT(
	                                                        SUM(TOTAL) FOR EVENT IN (
	                                                            'unclassified',
	                                                            'a_pageload',
	                                                            'play',
	                                                            'click',
	                                                            'submit'
	                                                        )
	                                                    ) as p
	                                                ORDER BY
	                                                    DATE_VISITED DESC,
	                                                    URL
	                                            ) as pvt
	                                    ) AS X
	                                GROUP BY
	                                    CRM_ACCOUNT_ID,
	                                    DATE_VISITED,
	                                    UTM_SOURCE,
	                                    UTM_MEDIUM,
	                                    URL,
	                                    REFERRER_DOMAIN
	                            )
	                        WHERE
	                            (
	                                UTM_SOURCE IS NOT NULL
	                                AND UTM_MEDIUM IS NOT NULL
	                            ) --AND CRM_ACCOUNT_ID = '0016R00003EnYlPQAV' AND DATE_VISITED = '2023-02-14'
	                        GROUP BY
	                            CRM_ACCOUNT_ID,
	                            DATE_VISITED,
	                            UTM_SOURCE,
	                            UTM_MEDIUM
	                        ORDER BY
	                            CRM_ACCOUNT_ID,
	                            DATE_VISITED,
	                            Total_interaction DESC
	                    ) AS rnk
	                where
	                    rnk.RANK_BY_DAY = 1
	            ) AS rnkcoalesce on webvisit.CRM_ACCOUNT_ID = rnkcoalesce.CRM_ACCOUNT_ID
	            and webvisit.DATE_VISITED = rnkcoalesce.DATE_VISITED --WHERE webvisit.CRM_ACCOUNT_ID = '0016R00003EnYlPQAV' --AND webvisit.DATE_VISITED = '2023-02-14'
	        ORDER BY
	            webvisit.CRM_ACCOUNT_ID,
	            webvisit.DATE_VISITED,
	            INFLUENCE_WEB_SOURCE,
	            INFLUENCE_WEB_MEDIUM
	    );
	   
	-- Step 03c: Touchtype Bizible TouchPoints File
	 DROP TABLE IF EXISTS DP_PROD_DB.ACT_MRKT_LIFECYCLE.TOUCHTYPE_BIZIBLE_TOUCHPOINTS ;
	    CREATE TABLE DP_PROD_DB.ACT_MRKT_LIFECYCLE.TOUCHTYPE_BIZIBLE_TOUCHPOINTS as
	    
	 SELECT
	    *
	FROM
	    (
	        SELECT
	            'Bizible' AS MARKETING_TOUCH_TYPE_DATA_SOURCE,
	            biz_touchpoints.ACCOUNT_ID AS CRM_ACCOUNT_ID,
	            CAST(biz_touchpoints.TOUCHPOINT_DATE as DATE) AS MARKETING_TOUCHPOINT_DATE,
	            biz_touchpoints.MARKETING_TOUCH_TYPE,
	            biz_touchpoints.MARKETING_TOUCH_TYPE_COUNT,
	            CASE
	                WHEN biz_touchpoints.MARKETING_TOUCH_TYPE = 'Web Visit' THEN MARKETING_TOUCH_TYPE_COUNT
	                ELSE 0
	            END AS INTERACTIONTYPE_BIZIBLE_TOUCHPOINT_WEBVISIT_COUNT,
	            CASE
	                WHEN biz_touchpoints.MARKETING_TOUCH_TYPE = 'Web Chat' THEN MARKETING_TOUCH_TYPE_COUNT
	                ELSE 0
	            END AS INTERACTIONTYPE_BIZIBLE_TOUCHPOINT_WEBCHAT_COUNT,
	            CASE
	                WHEN biz_touchpoints.MARKETING_TOUCH_TYPE = 'Web Form' THEN MARKETING_TOUCH_TYPE_COUNT
	                ELSE 0
	            END AS INTERACTIONTYPE_BIZIBLE_TOUCHPOINT_WEBFORM_COUNT,
	            CASE
	                WHEN biz_touchpoints.MARKETING_TOUCH_TYPE = 'CRM' THEN MARKETING_TOUCH_TYPE_COUNT
	                ELSE 0
	            END AS INTERACTIONTYPE_BIZIBLE_TOUCHPOINT_CRM_COUNT,
	            CASE
	                WHEN biz_touchpoints.MARKETING_TOUCH_TYPE = 'Connect with DM' THEN MARKETING_TOUCH_TYPE_COUNT
	                ELSE 0
	            END AS INTERACTIONTYPE_BIZIBLE_TOUCHPOINT_CONNECTWITHDM_COUNT,
	            CASE
	                WHEN biz_touchpoints.MARKETING_TOUCH_TYPE = 'Call - Spoke With' THEN MARKETING_TOUCH_TYPE_COUNT
	                ELSE 0
	            END AS INTERACTIONTYPE_BIZIBLE_TOUCHPOINT_CALLSPOKEWITH_COUNT,
	            CASE
	                WHEN biz_touchpoints.MARKETING_TOUCH_TYPE = 'Call - Gatekeeper' THEN MARKETING_TOUCH_TYPE_COUNT
	                ELSE 0
	            END AS INTERACTIONTYPE_BIZIBLE_TOUCHPOINT_CALLGATEKEEPER_COUNT,
	            CASE
	                WHEN biz_touchpoints.MARKETING_TOUCH_TYPE = 'NO_LEAD_TOUCHPOINTS' THEN MARKETING_TOUCH_TYPE_COUNT
	                ELSE 0
	            END AS INTERACTIONTYPE_BIZIBLE_TOUCHPOINT_NOLEADTOUCHPOINTS_COUNT,
	            CASE
	                WHEN biz_touchpoints.MARKETING_TOUCH_TYPE IS NULL THEN MARKETING_TOUCH_TYPE_COUNT
	                ELSE 0
	            END AS INTERACTIONTYPE_BIZIBLE_TOUCHPOINT_UNCLASSIFIED_COUNT,
	            CASE
	                -- CRM Actvity
	                --WHEN biz_touchpoints.WEB_SOURCE = 'CRM Activity' THEN CONCAT_WS('.',biz_touchpoints."WEB_SOURCE",biz_touchpoints."MEDIUM")
	                WHEN biz_touchpoints.WEB_SOURCE = 'CRM Activity' THEN 'Sales Engagement' || '.' || COALESCE(biz_touchpoints.MEDIUM,'')
	                -- Web Referral
	                WHEN biz_touchpoints.CHANNEL IN ('Other')
	                AND biz_touchpoints.MEDIUM = 'referral' THEN 'Web Referral'
	                ELSE biz_touchpoints.CHANNEL
	            END AS INFLUENCE_CHANNEL,
	            biz_touchpoints.WEB_SOURCE AS INFLUENCE_WEB_SOURCE,
	            biz_touchpoints.MEDIUM AS INFLUENCE_WEB_MEDIUM,
	            biz_touchpoints.CAMPAIGN_NAME AS INFLUENCE_CAMPAIGN_NAME,
	            biz_touchpoints.CREATIVE_NAME AS INFLUENCE_CREATIVE_NAME,
	            biz_touchpoints.LANDING_PAGE AS INFLUENCE_LANDING_PAGE,
	            biz_touchpoints.REFERRER_PAGE AS INFLUENCE_REFERRER,
	            biz_touchpoints.LANDING_PAGE AS WEBVISIT_PAGE,
	            biz_touchpoints.REFERRER_PAGE AS WEBVISIT_REFERRER
	        FROM
	            (
	                SELECT
	                    ACCOUNT_ID,
	                    TOUCHPOINT_DATE,
	                    MARKETING_TOUCH_TYPE,
	                    COUNT(ROW_KEY) AS MARKETING_TOUCH_TYPE_COUNT,
	                    WEB_SOURCE,
	                    CHANNEL,
	                    MEDIUM,
	                    CAMPAIGN_NAME,
	                    CREATIVE_NAME,
	                    LANDING_PAGE,
	                    REFERRER_PAGE
	                from dp_prod_db.bizible.biz_touchpoints 
	                WHERE
	                    ACCOUNT_ID IS NOT NULL
	                GROUP BY
	                    ACCOUNT_ID,
	                    TOUCHPOINT_DATE,
	                    MARKETING_TOUCH_TYPE,
	                    WEB_SOURCE,
	                    CHANNEL,
	                    MEDIUM,
	                    CAMPAIGN_NAME,
	                    CREATIVE_NAME,
	                    LANDING_PAGE,
	                    REFERRER_PAGE
	            ) AS biz_touchpoints
	    );  
	 

	-- Step 04: Touchtype Analytics Table comprehensive of 6Sense Paid Media + 6Sense Web Visit + Bizible
	DROP TABLE IF EXISTS DP_PROD_DB.ACT_MRKT_LIFECYCLE.TOUCHTYPE_ANALYTICS;

	CREATE TABLE DP_PROD_DB.ACT_MRKT_LIFECYCLE.TOUCHTYPE_ANALYTICS AS
	SELECT
	    *
	FROM
	    (
	        (
	            -- Step 04a: 6Sense Paid Media File
	            SELECT
	                MARKETING_TOUCH_TYPE_DATA_SOURCE,
	                CRM_ACCOUNT_ID,
	                MARKETING_TOUCHPOINT_DATE,
	                MARKETING_TOUCH_TYPE,
	                MARKETING_TOUCH_TYPE_COUNT,
	                -- SIXSENSE PAID MEDIA IMPRESSIONS
	                INTERACTIONTYPE_SIXSENSE_PAIDMEDIA_IMPRESSIONS_COUNT,
	                INTERACTIONTYPE_SIXSENSE_PAIDMEDIA_CLICKS_COUNT,
	                -- SIXSENSE WEB VISIT ACTIVITY
	                NULL AS INTERACTIONTYPE_SIXSENSE_WEBVISIT_TOTAL_INTERACTIONS_COUNT,
	                NULL AS INTERACTIONTYPE_SIXSENSE_WEBVISIT_PAGELOAD_COUNT,
	                NULL AS INTERACTIONTYPE_SIXSENSE_WEBVISIT_PLAY_COUNT,
	                NULL AS INTERACTIONTYPE_SIXSENSE_WEBVISIT_CLICK_COUNT,
	                NULL AS INTERACTIONTYPE_SIXSENSE_WEBVISIT_SUBMIT_COUNT,
	                NULL AS INTERACTIONTYPE_SIXSENSE_WEBVISIT_UNCLASSIFIED_COUNT,
	                -- BIZIBLE TOUCHPOINT
	                NULL AS INTERACTIONTYPE_BIZIBLE_TOUCHPOINT_WEBVISIT_COUNT,
	                NULL AS INTERACTIONTYPE_BIZIBLE_TOUCHPOINT_WEBCHAT_COUNT,
	                NULL AS INTERACTIONTYPE_BIZIBLE_TOUCHPOINT_WEBFORM_COUNT,
	                NULL AS INTERACTIONTYPE_BIZIBLE_TOUCHPOINT_CRM_COUNT,
	                NULL AS INTERACTIONTYPE_BIZIBLE_TOUCHPOINT_CONNECTWITHDM_COUNT,
	                NULL AS INTERACTIONTYPE_BIZIBLE_TOUCHPOINT_CALLSPOKEWITH_COUNT,
	                NULL AS INTERACTIONTYPE_BIZIBLE_TOUCHPOINT_CALLGATEKEEPER_COUNT,
	                NULL AS INTERACTIONTYPE_BIZIBLE_TOUCHPOINT_NOLEADTOUCHPOINTS_COUNT,
	                NULL AS INTERACTIONTYPE_BIZIBLE_TOUCHPOINT_UNCLASSIFIED_COUNT,
	                INFLUENCE_CHANNEL,
	                INFLUENCE_WEB_SOURCE,
	                INFLUENCE_WEB_MEDIUM,
	                INFLUENCE_CAMPAIGN_NAME,
	                INFLUENCE_CREATIVE_NAME,
	                INFLUENCE_LANDING_PAGE,
	                INFLUENCE_REFERRER,
	                WEBVISIT_PAGE,
	                WEBVISIT_REFERRER
	            FROM
	                DP_PROD_DB.ACT_MRKT_LIFECYCLE.TOUCHTYPE_6SENSE_PAIDMEDIA
	            UNION
	                -- Step 04b: 6Sense Web Visit File
	            SELECT
	                MARKETING_TOUCH_TYPE_DATA_SOURCE,
	                CRM_ACCOUNT_ID,
	                MARKETING_TOUCHPOINT_DATE,
	                MARKETING_TOUCH_TYPE,
	                MARKETING_TOUCH_TYPE_COUNT,
	                -- SIXSENSE PAID MEDIA IMPRESSIONS
	                NULL AS INTERACTIONTYPE_SIXSENSE_PAIDMEDIA_IMPRESSIONS_COUNT,
	                NULL AS INTERACTIONTYPE_SIXSENSE_PAIDMEDIA_CLICKS_COUNT,
	                -- SIXSENSE WEB VISIT ACTIVITY
	                INTERACTIONTYPE_SIXSENSE_WEBVISIT_TOTAL_INTERACTIONS_COUNT,
	                INTERACTIONTYPE_SIXSENSE_WEBVISIT_PAGELOAD_COUNT,
	                INTERACTIONTYPE_SIXSENSE_WEBVISIT_PLAY_COUNT,
	                INTERACTIONTYPE_SIXSENSE_WEBVISIT_CLICK_COUNT,
	                INTERACTIONTYPE_SIXSENSE_WEBVISIT_SUBMIT_COUNT,
	                INTERACTIONTYPE_SIXSENSE_WEBVISIT_UNCLASSIFIED_COUNT,
	                -- BIZIBLE TOUCHPOINT
	                NULL AS INTERACTIONTYPE_BIZIBLE_TOUCHPOINT_WEBVISIT_COUNT,
	                NULL AS INTERACTIONTYPE_BIZIBLE_TOUCHPOINT_WEBCHAT_COUNT,
	                NULL AS INTERACTIONTYPE_BIZIBLE_TOUCHPOINT_WEBFORM_COUNT,
	                NULL AS INTERACTIONTYPE_BIZIBLE_TOUCHPOINT_CRM_COUNT,
	                NULL AS INTERACTIONTYPE_BIZIBLE_TOUCHPOINT_CONNECTWITHDM_COUNT,
	                NULL AS INTERACTIONTYPE_BIZIBLE_TOUCHPOINT_CALLSPOKEWITH_COUNT,
	                NULL AS INTERACTIONTYPE_BIZIBLE_TOUCHPOINT_CALLGATEKEEPER_COUNT,
	                NULL AS INTERACTIONTYPE_BIZIBLE_TOUCHPOINT_NOLEADTOUCHPOINTS_COUNT,
	                NULL AS INTERACTIONTYPE_BIZIBLE_TOUCHPOINT_UNCLASSIFIED_COUNT,
	                INFLUENCE_CHANNEL,
	                INFLUENCE_WEB_SOURCE,
	                INFLUENCE_WEB_MEDIUM,
	                INFLUENCE_CAMPAIGN_NAME,
	                INFLUENCE_CREATIVE_NAME,
	                INFLUENCE_LANDING_PAGE,
	                INFLUENCE_REFERRER,
	                WEBVISIT_PAGE,
	                WEBVISIT_REFERRER
	            FROM
	                DP_PROD_DB.ACT_MRKT_LIFECYCLE.TOUCHTYPE_6SENSE_WEBVISIT
	            UNION
	                -- Step 04c: Bizible TouchPoints File
	            SELECT
	                MARKETING_TOUCH_TYPE_DATA_SOURCE,
	                CRM_ACCOUNT_ID,
	                MARKETING_TOUCHPOINT_DATE,
	                MARKETING_TOUCH_TYPE,
	                MARKETING_TOUCH_TYPE_COUNT,
	                -- SIXSENSE PAID MEDIA IMPRESSIONS
	                NULL AS INTERACTIONTYPE_SIXSENSE_PAIDMEDIA_IMPRESSIONS_COUNT,
	                NULL AS INTERACTIONTYPE_SIXSENSE_PAIDMEDIA_CLICKS_COUNT,
	                -- SIXSENSE WEB VISIT ACTIVITY
	                NULL AS INTERACTIONTYPE_SIXSENSE_WEBVISIT_TOTAL_INTERACTIONS_COUNT,
	                NULL AS INTERACTIONTYPE_SIXSENSE_WEBVISIT_PAGELOAD_COUNT,
	                NULL AS INTERACTIONTYPE_SIXSENSE_WEBVISIT_PLAY_COUNT,
	                NULL AS INTERACTIONTYPE_SIXSENSE_WEBVISIT_CLICK_COUNT,
	                NULL AS INTERACTIONTYPE_SIXSENSE_WEBVISIT_SUBMIT_COUNT,
	                NULL AS INTERACTIONTYPE_SIXSENSE_WEBVISIT_UNCLASSIFIED_COUNT,
	                -- BIZIBLE TOUCHPOINT
	                INTERACTIONTYPE_BIZIBLE_TOUCHPOINT_WEBVISIT_COUNT,
	                INTERACTIONTYPE_BIZIBLE_TOUCHPOINT_WEBCHAT_COUNT,
	                INTERACTIONTYPE_BIZIBLE_TOUCHPOINT_WEBFORM_COUNT,
	                INTERACTIONTYPE_BIZIBLE_TOUCHPOINT_CRM_COUNT,
	                INTERACTIONTYPE_BIZIBLE_TOUCHPOINT_CONNECTWITHDM_COUNT,
	                INTERACTIONTYPE_BIZIBLE_TOUCHPOINT_CALLSPOKEWITH_COUNT,
	                INTERACTIONTYPE_BIZIBLE_TOUCHPOINT_CALLGATEKEEPER_COUNT,
	                INTERACTIONTYPE_BIZIBLE_TOUCHPOINT_NOLEADTOUCHPOINTS_COUNT,
	                INTERACTIONTYPE_BIZIBLE_TOUCHPOINT_UNCLASSIFIED_COUNT,
	                INFLUENCE_CHANNEL,
	                INFLUENCE_WEB_SOURCE,
	                INFLUENCE_WEB_MEDIUM,
	                INFLUENCE_CAMPAIGN_NAME,
	                INFLUENCE_CREATIVE_NAME,
	                INFLUENCE_LANDING_PAGE,
	                INFLUENCE_REFERRER,
	                WEBVISIT_PAGE,
	                WEBVISIT_REFERRER
	            FROM
	                DP_PROD_DB.ACT_MRKT_LIFECYCLE.TOUCHTYPE_BIZIBLE_TOUCHPOINTS
	        )
	    );
	    
	-- Step 05a: Account Marketing Lifecycle History with Opp and Influence Data
	 DROP TABLE IF EXISTS DP_PROD_DB.ACT_MRKT_LIFECYCLE.AMLH_INFL_OPP;
	    CREATE TABLE DP_PROD_DB.ACT_MRKT_LIFECYCLE.AMLH_INFL_OPP AS
	SELECT
	    *
	FROM
	    (
	        SELECT
	            -- Account Marketing Lifecycle History with Opp Data
	            amlh_opp.*,
	            -- Influence Data
	            infl_data.MARKETING_TOUCHPOINT_DATE,
	            row_number() OVER (
	                PARTITION BY amlh_opp.OPP_ID,
	                amlh_opp.ACT_ID
	                ORDER BY
	                    infl_data.MARKETING_TOUCHPOINT_DATE ASC
	            ) AS MARKETING_TOUCHPOINT_ORDER,
	            CASE
	                WHEN infl_data.CRM_ACCOUNT_ID IS NULL THEN 'Salesforce'
	                ELSE infl_data.MARKETING_TOUCH_TYPE_DATA_SOURCE
	            END AS MARKETING_TOUCH_TYPE_DATA_SOURCE,
	            CASE
	                WHEN infl_data.CRM_ACCOUNT_ID IS NULL THEN 0
	                ELSE 1
	            END AS FLAG_MARKETING_TOUCH_TYPE_DATA_SOURCE,
	            CASE
	                WHEN infl_data.CRM_ACCOUNT_ID IS NULL THEN 'Salesforce Opportunity'
	                ELSE infl_data.MARKETING_TOUCH_TYPE
	            END AS MARKETING_TOUCH_TYPE,
	            infl_data.MARKETING_TOUCH_TYPE_COUNT,
	            CASE
	                WHEN infl_data.MARKETING_TOUCHPOINT_DATE <= amlh_opp.OPP_CREATED_DATE THEN 1
	                ELSE 0
	            END AS MARKETING_TOUCHPOINT_BEFORE_OPP_CREATED,
	            CASE
	                WHEN infl_data.MARKETING_TOUCHPOINT_DATE <= amlh_opp.OPP_CLOSE_DATE THEN 1
	                ELSE 0
	            END AS MARKETING_TOUCHPOINT_BEFORE_OPP_CLOSE,
	            CASE
	                WHEN infl_data.MARKETING_TOUCHPOINT_DATE <= amlh_opp.AMLH_COLD_ACCOUNT_DATE_STAMP__C THEN 1
	                ELSE 0
	            END AS MARKETING_TOUCHPOINT_BEFORE_ACT_COLD,
	            CASE
	                WHEN infl_data.MARKETING_TOUCHPOINT_DATE <= amlh_opp.AMLH_MEA_DATE_STAMP__C THEN 1
	                ELSE 0
	            END AS MARKETING_TOUCHPOINT_BEFORE_ACT_MEA,
	            CASE
	                WHEN infl_data.MARKETING_TOUCHPOINT_DATE <= amlh_opp.AMLH_MQA_DATE_STAMP__C THEN 1
	                ELSE 0
	            END AS MARKETING_TOUCHPOINT_BEFORE_ACT_MQA,
	            CASE
	                WHEN infl_data.MARKETING_TOUCHPOINT_DATE <= amlh_opp.AMLH_SUSPECT_DATE_STAMP__C THEN 1
	                ELSE 0
	            END AS MARKETING_TOUCHPOINT_BEFORE_ACT_SUSPECT,
	            CASE
	                WHEN infl_data.MARKETING_TOUCHPOINT_DATE <= amlh_opp.AMLH_SUSPECT_WORKING_DATE_STAMP__C THEN 1
	                ELSE 0
	            END AS MARKETING_TOUCHPOINT_BEFORE_ACT_SUSPECTWORKING,
	            CASE
	                WHEN infl_data.MARKETING_TOUCHPOINT_DATE <= amlh_opp.AMLH_PROSPECT_DATE_STAMP__C THEN 1
	                ELSE 0
	            END AS MARKETING_TOUCHPOINT_BEFORE_ACT_PROSPECT,
	            --CASE WHEN infl_data.MARKETING_TOUCHPOINT_DATE <= amlh_opp.AMLH_CUSTOMER_DATE_STAMP__C THEN 1 ELSE 0 END AS MARKETING_TOUCHPOINT_BEFORE_ACT_CUSTOMER,
	            CASE
	                WHEN infl_data.MARKETING_TOUCHPOINT_DATE <= amlh_opp.AMLH_RECYCLED_DATE_STAMP__C THEN 1
	                ELSE 0
	            END AS MARKETING_TOUCHPOINT_BEFORE_ACT_RECYCLED,
	            CASE
	                WHEN infl_data.MARKETING_TOUCHPOINT_DATE <= amlh_opp.AMLH_UNQUALIFIED_DATE_STAMP__C THEN 1
	                ELSE 0
	            END AS MARKETING_TOUCHPOINT_BEFORE_ACT_UNQUALIFIED,
	            CASE
	                WHEN infl_data.CRM_ACCOUNT_ID IS NULL THEN 'Salesforce.Opportunity'
	                ELSE infl_data.INFLUENCE_CHANNEL
	            END AS INFLUENCE_CHANNEL,
	            CASE
	                WHEN infl_data.CRM_ACCOUNT_ID IS NULL THEN 'Salesforce'
	                ELSE SPLIT_PART(infl_data.INFLUENCE_CHANNEL, '.', 1)
	            END AS INFLUENCE_CHANNEL_TOPLEVEL,
	            CASE
	                WHEN infl_data.CRM_ACCOUNT_ID IS NULL THEN 'salesforce'
	                ELSE infl_data.INFLUENCE_WEB_SOURCE
	            END AS INFLUENCE_WEB_SOURCE,
	            CASE
	                WHEN infl_data.CRM_ACCOUNT_ID IS NULL THEN 'opportunity'
	                ELSE infl_data.INFLUENCE_WEB_MEDIUM
	            END AS INFLUENCE_WEB_MEDIUM,
	            infl_data.INFLUENCE_CAMPAIGN_NAME,
	            infl_data.INFLUENCE_CREATIVE_NAME,
	            infl_data.INFLUENCE_LANDING_PAGE,
	            infl_data.INFLUENCE_REFERRER,
	            infl_data.WEBVISIT_PAGE,
	            infl_data.WEBVISIT_REFERRER,
	            infl_data.INTERACTIONTYPE_SIXSENSE_PAIDMEDIA_IMPRESSIONS_COUNT,
	            infl_data.INTERACTIONTYPE_SIXSENSE_PAIDMEDIA_CLICKS_COUNT,
	            infl_data.INTERACTIONTYPE_SIXSENSE_WEBVISIT_TOTAL_INTERACTIONS_COUNT,
	            infl_data.INTERACTIONTYPE_SIXSENSE_WEBVISIT_PAGELOAD_COUNT,
	            infl_data.INTERACTIONTYPE_SIXSENSE_WEBVISIT_PLAY_COUNT,
	            infl_data.INTERACTIONTYPE_SIXSENSE_WEBVISIT_CLICK_COUNT,
	            infl_data.INTERACTIONTYPE_SIXSENSE_WEBVISIT_SUBMIT_COUNT,
	            infl_data.INTERACTIONTYPE_SIXSENSE_WEBVISIT_UNCLASSIFIED_COUNT,
	            infl_data.INTERACTIONTYPE_BIZIBLE_TOUCHPOINT_WEBVISIT_COUNT,
	            infl_data.INTERACTIONTYPE_BIZIBLE_TOUCHPOINT_WEBCHAT_COUNT,
	            infl_data.INTERACTIONTYPE_BIZIBLE_TOUCHPOINT_WEBFORM_COUNT,
	            infl_data.INTERACTIONTYPE_BIZIBLE_TOUCHPOINT_CRM_COUNT,
	            infl_data.INTERACTIONTYPE_BIZIBLE_TOUCHPOINT_CONNECTWITHDM_COUNT,
	            infl_data.INTERACTIONTYPE_BIZIBLE_TOUCHPOINT_CALLSPOKEWITH_COUNT,
	            infl_data.INTERACTIONTYPE_BIZIBLE_TOUCHPOINT_CALLGATEKEEPER_COUNT,
	            infl_data.INTERACTIONTYPE_BIZIBLE_TOUCHPOINT_NOLEADTOUCHPOINTS_COUNT,
	            infl_data.INTERACTIONTYPE_BIZIBLE_TOUCHPOINT_UNCLASSIFIED_COUNT,
	            -- Influence based on Bizible or 6Sense or Salesforce
	            CASE
	                WHEN (
	                    (
	                        CASE
	                            WHEN infl_data.MARKETING_TOUCHPOINT_DATE <= amlh_opp.OPP_CREATED_DATE THEN 1
	                            ELSE 0
	                        END
	                    ) = 1
	                    AND infl_data.MARKETING_TOUCH_TYPE_DATA_SOURCE IN (
	                        '6Sense - Paid Media',
	                        '6Sense - Web Visit',
	                        'Bizible'
	                    )
	                ) THEN 1
	                WHEN (
	                    (
	                        CASE
	                            WHEN infl_data.MARKETING_TOUCHPOINT_DATE <= amlh_opp.OPP_CREATED_DATE THEN 1
	                            ELSE 0
	                        END
	                    ) = 0
	                    AND infl_data.MARKETING_TOUCH_TYPE_DATA_SOURCE IN (
	                        '6Sense - Paid Media',
	                        '6Sense - Web Visit',
	                        'Bizible'
	                    )
	                ) THEN 2
	                ELSE 0
	            END AS FLAG_OPPCRT_INFL_TOUCHPOINT_BY_DATASOURCE_BIZIBLEORSIXSENSEORSALESFORCE,
	            CASE
	                WHEN (
	                    (
	                        CASE
	                            WHEN infl_data.MARKETING_TOUCHPOINT_DATE <= amlh_opp.OPP_CLOSE_DATE THEN 1
	                            ELSE 0
	                        END
	                    ) = 1
	                    AND infl_data.MARKETING_TOUCH_TYPE_DATA_SOURCE IN (
	                        '6Sense - Paid Media',
	                        '6Sense - Web Visit',
	                        'Bizible'
	                    )
	                ) THEN 1
	                WHEN (
	                    (
	                        CASE
	                            WHEN infl_data.MARKETING_TOUCHPOINT_DATE <= amlh_opp.OPP_CLOSE_DATE THEN 1
	                            ELSE 0
	                        END
	                    ) = 0
	                    AND infl_data.MARKETING_TOUCH_TYPE_DATA_SOURCE IN (
	                        '6Sense - Paid Media',
	                        '6Sense - Web Visit',
	                        'Bizible'
	                    )
	                ) THEN 2
	                ELSE 0
	            END AS FLAG_OPPCLS_INFL_TOUCHPOINT_BY_DATASOURCE_BIZIBLEORSIXSENSEORSALESFORCE,
	            CASE
	                WHEN (
	                    (
	                        CASE
	                            WHEN infl_data.MARKETING_TOUCHPOINT_DATE <= amlh_opp.AMLH_COLD_ACCOUNT_DATE_STAMP__C THEN 1
	                            ELSE 0
	                        END
	                    ) = 1
	                    AND infl_data.MARKETING_TOUCH_TYPE_DATA_SOURCE IN (
	                        '6Sense - Paid Media',
	                        '6Sense - Web Visit',
	                        'Bizible'
	                    )
	                ) THEN 1
	                WHEN (
	                    (
	                        CASE
	                            WHEN infl_data.MARKETING_TOUCHPOINT_DATE <= amlh_opp.AMLH_COLD_ACCOUNT_DATE_STAMP__C THEN 1
	                            ELSE 0
	                        END
	                    ) = 0
	                    AND infl_data.MARKETING_TOUCH_TYPE_DATA_SOURCE IN (
	                        '6Sense - Paid Media',
	                        '6Sense - Web Visit',
	                        'Bizible'
	                    )
	                ) THEN 2
	                ELSE 0
	            END AS FLAG_ACTCOLD_INFL_TOUCHPOINT_BY_DATASOURCE_BIZIBLEORSIXSENSEORSALESFORCE,
	            CASE
	                WHEN (
	                    (
	                        CASE
	                            WHEN infl_data.MARKETING_TOUCHPOINT_DATE <= amlh_opp.AMLH_MEA_DATE_STAMP__C THEN 1
	                            ELSE 0
	                        END
	                    ) = 1
	                    AND infl_data.MARKETING_TOUCH_TYPE_DATA_SOURCE IN (
	                        '6Sense - Paid Media',
	                        '6Sense - Web Visit',
	                        'Bizible'
	                    )
	                ) THEN 1
	                WHEN (
	                    (
	                        CASE
	                            WHEN infl_data.MARKETING_TOUCHPOINT_DATE <= amlh_opp.AMLH_MEA_DATE_STAMP__C THEN 1
	                            ELSE 0
	                        END
	                    ) = 0
	                    AND infl_data.MARKETING_TOUCH_TYPE_DATA_SOURCE IN (
	                        '6Sense - Paid Media',
	                        '6Sense - Web Visit',
	                        'Bizible'
	                    )
	                ) THEN 2
	                ELSE 0
	            END AS ACTMEA_INFL_TOUCHPOINT_BY_DATASOURCE_BIZIBLEORSIXSENSEORSALESFORCE,
	            CASE
	                WHEN (
	                    (
	                        CASE
	                            WHEN infl_data.MARKETING_TOUCHPOINT_DATE <= amlh_opp.AMLH_MQA_DATE_STAMP__C THEN 1
	                            ELSE 0
	                        END
	                    ) = 1
	                    AND infl_data.MARKETING_TOUCH_TYPE_DATA_SOURCE IN (
	                        '6Sense - Paid Media',
	                        '6Sense - Web Visit',
	                        'Bizible'
	                    )
	                ) THEN 1
	                WHEN (
	                    (
	                        CASE
	                            WHEN infl_data.MARKETING_TOUCHPOINT_DATE <= amlh_opp.AMLH_MQA_DATE_STAMP__C THEN 1
	                            ELSE 0
	                        END
	                    ) = 0
	                    AND infl_data.MARKETING_TOUCH_TYPE_DATA_SOURCE IN (
	                        '6Sense - Paid Media',
	                        '6Sense - Web Visit',
	                        'Bizible'
	                    )
	                ) THEN 2
	                ELSE 0
	            END AS ACTMQA_INFL_TOUCHPOINT_BY_DATASOURCE_BIZIBLEORSIXSENSEORSALESFORCE,
	            CASE
	                WHEN (
	                    (
	                        CASE
	                            WHEN infl_data.MARKETING_TOUCHPOINT_DATE <= amlh_opp.AMLH_SUSPECT_DATE_STAMP__C THEN 1
	                            ELSE 0
	                        END
	                    ) = 1
	                    AND infl_data.MARKETING_TOUCH_TYPE_DATA_SOURCE IN (
	                        '6Sense - Paid Media',
	                        '6Sense - Web Visit',
	                        'Bizible'
	                    )
	                ) THEN 1
	                WHEN (
	                    (
	                        CASE
	                            WHEN infl_data.MARKETING_TOUCHPOINT_DATE <= amlh_opp.AMLH_SUSPECT_DATE_STAMP__C THEN 1
	                            ELSE 0
	                        END
	                    ) = 0
	                    AND infl_data.MARKETING_TOUCH_TYPE_DATA_SOURCE IN (
	                        '6Sense - Paid Media',
	                        '6Sense - Web Visit',
	                        'Bizible'
	                    )
	                ) THEN 2
	                ELSE 0
	            END AS ACTSUSPECT_INFL_TOUCHPOINT_BY_DATASOURCE_BIZIBLEORSIXSENSEORSALESFORCE,
	            CASE
	                WHEN (
	                    (
	                        CASE
	                            WHEN infl_data.MARKETING_TOUCHPOINT_DATE <= amlh_opp.AMLH_PROSPECT_DATE_STAMP__C THEN 1
	                            ELSE 0
	                        END
	                    ) = 1
	                    AND infl_data.MARKETING_TOUCH_TYPE_DATA_SOURCE IN (
	                        '6Sense - Paid Media',
	                        '6Sense - Web Visit',
	                        'Bizible'
	                    )
	                ) THEN 1
	                WHEN (
	                    (
	                        CASE
	                            WHEN infl_data.MARKETING_TOUCHPOINT_DATE <= amlh_opp.AMLH_PROSPECT_DATE_STAMP__C THEN 1
	                            ELSE 0
	                        END
	                    ) = 0
	                    AND infl_data.MARKETING_TOUCH_TYPE_DATA_SOURCE IN (
	                        '6Sense - Paid Media',
	                        '6Sense - Web Visit',
	                        'Bizible'
	                    )
	                ) THEN 2
	                ELSE 0
	            END AS ACTPROSPECT_INFL_TOUCHPOINT_BY_DATASOURCE_BIZIBLEORSIXSENSEORSALESFORCE,
	            -- Influence based on Bizible or 6Sense
	            CASE
	                WHEN infl_data.MARKETING_TOUCHPOINT_DATE <= amlh_opp.OPP_CREATED_DATE
	                AND infl_data.MARKETING_TOUCH_TYPE_DATA_SOURCE IN (
	                    '6Sense - Paid Media',
	                    '6Sense - Web Visit',
	                    'Bizible'
	                ) THEN 1
	                ELSE 0
	            END AS FLAG_OPPCRT_INFL_TOUCHPOINT_BY_DATASOURCE_BIZIBLEORSIXSENSE,
	            CASE
	                WHEN infl_data.MARKETING_TOUCHPOINT_DATE <= amlh_opp.OPP_CLOSE_DATE
	                AND infl_data.MARKETING_TOUCH_TYPE_DATA_SOURCE IN (
	                    '6Sense - Paid Media',
	                    '6Sense - Web Visit',
	                    'Bizible'
	                ) THEN 1
	                else 0
	            END AS FLAG_OPPCLS_INFL_TOUCHPOINT_BY_DATASOURCE_BIZIBLEORSIXSENSE,
	            CASE
	                WHEN infl_data.MARKETING_TOUCHPOINT_DATE <= amlh_opp.AMLH_COLD_ACCOUNT_DATE_STAMP__C
	                AND infl_data.MARKETING_TOUCH_TYPE_DATA_SOURCE IN (
	                    '6Sense - Paid Media',
	                    '6Sense - Web Visit',
	                    'Bizible'
	                ) THEN 1
	                else 0
	            END AS FLAG_ACTCOLD_INFL_TOUCHPOINT_BY_DATASOURCE_BIZIBLEORSIXSENSE,
	            CASE
	                WHEN infl_data.MARKETING_TOUCHPOINT_DATE <= amlh_opp.AMLH_MEA_DATE_STAMP__C
	                AND infl_data.MARKETING_TOUCH_TYPE_DATA_SOURCE IN (
	                    '6Sense - Paid Media',
	                    '6Sense - Web Visit',
	                    'Bizible'
	                ) THEN 1
	                else 0
	            END AS FLAG_ACTMEA_INFL_TOUCHPOINT_BY_DATASOURCE_BIZIBLEORSIXSENSE,
	            CASE
	                WHEN infl_data.MARKETING_TOUCHPOINT_DATE <= amlh_opp.AMLH_MQA_DATE_STAMP__C
	                AND infl_data.MARKETING_TOUCH_TYPE_DATA_SOURCE IN (
	                    '6Sense - Paid Media',
	                    '6Sense - Web Visit',
	                    'Bizible'
	                ) THEN 1
	                else 0
	            END AS FLAG_ACTMQA_INFL_TOUCHPOINT_BY_DATASOURCE_BIZIBLEORSIXSENSE,
	            CASE
	                WHEN infl_data.MARKETING_TOUCHPOINT_DATE <= amlh_opp.AMLH_SUSPECT_DATE_STAMP__C
	                AND infl_data.MARKETING_TOUCH_TYPE_DATA_SOURCE IN (
	                    '6Sense - Paid Media',
	                    '6Sense - Web Visit',
	                    'Bizible'
	                ) THEN 1
	                else 0
	            END AS FLAG_ACTSUSPECT_INFL_TOUCHPOINT_BY_DATASOURCE_BIZIBLEORSIXSENSE,
	            CASE
	                WHEN infl_data.MARKETING_TOUCHPOINT_DATE <= amlh_opp.AMLH_PROSPECT_DATE_STAMP__C
	                AND infl_data.MARKETING_TOUCH_TYPE_DATA_SOURCE IN (
	                    '6Sense - Paid Media',
	                    '6Sense - Web Visit',
	                    'Bizible'
	                ) THEN 1
	                else 0
	            END AS FLAG_ACTPROSPECT_INFL_TOUCHPOINT_BY_DATASOURCE_BIZIBLEORSIXSENSE,
	            -- Influence based on 6Sense Paid Media
	            CASE
	                WHEN infl_data.MARKETING_TOUCHPOINT_DATE <= amlh_opp.OPP_CREATED_DATE
	                AND infl_data.MARKETING_TOUCH_TYPE_DATA_SOURCE = '6Sense - Paid Media' THEN 1
	                else 0
	            END AS FLAG_OPPCRT_INFL_TOUCHPOINT_BY_DATASOURCE_SIXSENSE_PAIDMEDIA,
	            CASE
	                WHEN infl_data.MARKETING_TOUCHPOINT_DATE <= amlh_opp.OPP_CLOSE_DATE
	                AND infl_data.MARKETING_TOUCH_TYPE_DATA_SOURCE = '6Sense - Paid Media' THEN 1
	                else 0
	            END AS FLAG_OPPCLS_INFL_TOUCHPOINT_BY_DATASOURCE_SIXSENSE_PAIDMEDIA,
	            CASE
	                WHEN infl_data.MARKETING_TOUCHPOINT_DATE <= amlh_opp.AMLH_COLD_ACCOUNT_DATE_STAMP__C
	                AND infl_data.MARKETING_TOUCH_TYPE_DATA_SOURCE = '6Sense - Paid Media' THEN 1
	                else 0
	            END AS FLAG_ACTCOLD_INFL_TOUCHPOINT_BY_DATASOURCE_SIXSENSE_PAIDMEDIA,
	            CASE
	                WHEN infl_data.MARKETING_TOUCHPOINT_DATE <= amlh_opp.AMLH_MEA_DATE_STAMP__C
	                AND infl_data.MARKETING_TOUCH_TYPE_DATA_SOURCE = '6Sense - Paid Media' THEN 1
	                else 0
	            END AS FLAG_ACTMEA_INFL_TOUCHPOINT_BY_DATASOURCE_SIXSENSE_PAIDMEDIA,
	            CASE
	                WHEN infl_data.MARKETING_TOUCHPOINT_DATE <= amlh_opp.AMLH_MQA_DATE_STAMP__C
	                AND infl_data.MARKETING_TOUCH_TYPE_DATA_SOURCE = '6Sense - Paid Media' THEN 1
	                else 0
	            END AS FLAG_ACTMQA_INFL_TOUCHPOINT_BY_DATASOURCE_SIXSENSE_PAIDMEDIA,
	            CASE
	                WHEN infl_data.MARKETING_TOUCHPOINT_DATE <= amlh_opp.AMLH_SUSPECT_DATE_STAMP__C
	                AND infl_data.MARKETING_TOUCH_TYPE_DATA_SOURCE = '6Sense - Paid Media' THEN 1
	                else 0
	            END AS FLAG_ACTSUSPECT_INFL_TOUCHPOINT_BY_DATASOURCE_SIXSENSE_PAIDMEDIA,
	            CASE
	                WHEN infl_data.MARKETING_TOUCHPOINT_DATE <= amlh_opp.AMLH_PROSPECT_DATE_STAMP__C
	                AND infl_data.MARKETING_TOUCH_TYPE_DATA_SOURCE = '6Sense - Paid Media' THEN 1
	                else 0
	            END AS FLAG_ACTPROSPECT_INFL_TOUCHPOINT_BY_DATASOURCE_SIXSENSE_PAIDMEDIA,
	            -- Influence based on 6Sense Web Visit
	            CASE
	                WHEN infl_data.MARKETING_TOUCHPOINT_DATE <= amlh_opp.OPP_CREATED_DATE
	                AND infl_data.MARKETING_TOUCH_TYPE_DATA_SOURCE = '6Sense - Web Visit' THEN 1
	                else 0
	            END AS FLAG_OPPCRT_INFL_TOUCHPOINT_BY_DATASOURCE_SIXSENSE_WEBVISIT,
	            CASE
	                WHEN infl_data.MARKETING_TOUCHPOINT_DATE <= amlh_opp.OPP_CLOSE_DATE
	                AND infl_data.MARKETING_TOUCH_TYPE_DATA_SOURCE = '6Sense - Web Visit' THEN 1
	                else 0
	            END AS FLAG_OPPCLS_INFL_TOUCHPOINT_BY_DATASOURCE_SIXSENSE_WEBVISIT,
	            CASE
	                WHEN infl_data.MARKETING_TOUCHPOINT_DATE <= amlh_opp.AMLH_COLD_ACCOUNT_DATE_STAMP__C
	                AND infl_data.MARKETING_TOUCH_TYPE_DATA_SOURCE = '6Sense - Web Visit' THEN 1
	                else 0
	            END AS FLAG_ACTCOLD_INFL_TOUCHPOINT_BY_DATASOURCE_SIXSENSE_WEBVISIT,
	            CASE
	                WHEN infl_data.MARKETING_TOUCHPOINT_DATE <= amlh_opp.AMLH_MEA_DATE_STAMP__C
	                AND infl_data.MARKETING_TOUCH_TYPE_DATA_SOURCE = '6Sense - Web Visit' THEN 1
	                else 0
	            END AS FLAG_ACTMEA_INFL_TOUCHPOINT_BY_DATASOURCE_SIXSENSE_WEBVISIT,
	            CASE
	                WHEN infl_data.MARKETING_TOUCHPOINT_DATE <= amlh_opp.AMLH_MQA_DATE_STAMP__C
	                AND infl_data.MARKETING_TOUCH_TYPE_DATA_SOURCE = '6Sense - Web Visit' THEN 1
	                else 0
	            END AS FLAG_ACTMQA_INFL_TOUCHPOINT_BY_DATASOURCE_SIXSENSE_WEBVISIT,
	            CASE
	                WHEN infl_data.MARKETING_TOUCHPOINT_DATE <= amlh_opp.AMLH_SUSPECT_DATE_STAMP__C
	                AND infl_data.MARKETING_TOUCH_TYPE_DATA_SOURCE = '6Sense - Web Visit' THEN 1
	                else 0
	            END AS FLAG_ACTSUSPECT_INFL_TOUCHPOINT_BY_DATASOURCE_SIXSENSE_WEBVISIT,
	            CASE
	                WHEN infl_data.MARKETING_TOUCHPOINT_DATE <= amlh_opp.AMLH_PROSPECT_DATE_STAMP__C
	                AND infl_data.MARKETING_TOUCH_TYPE_DATA_SOURCE = '6Sense - Web Visit' THEN 1
	                else 0
	            END AS FLAG_ACTPROSPECT_INFL_TOUCHPOINT_BY_DATASOURCE_SIXSENSE_WEBVISIT,
	            -- Influence based on Bizible
	            CASE
	                WHEN infl_data.MARKETING_TOUCHPOINT_DATE <= amlh_opp.OPP_CREATED_DATE
	                AND infl_data.MARKETING_TOUCH_TYPE_DATA_SOURCE = 'Bizible' THEN 1
	                else 0
	            END AS FLAG_OPPCRT_INFL_TOUCHPOINT_BY_DATASOURCE_BIZIBLE,
	            CASE
	                WHEN infl_data.MARKETING_TOUCHPOINT_DATE <= amlh_opp.OPP_CLOSE_DATE
	                AND infl_data.MARKETING_TOUCH_TYPE_DATA_SOURCE = 'Bizible' THEN 1
	                else 0
	            END AS FLAG_OPPCLS_INFL_TOUCHPOINT_BY_DATASOURCE_BIZIBLE,
	            CASE
	                WHEN infl_data.MARKETING_TOUCHPOINT_DATE <= amlh_opp.AMLH_COLD_ACCOUNT_DATE_STAMP__C
	                AND infl_data.MARKETING_TOUCH_TYPE_DATA_SOURCE = 'Bizible' THEN 1
	                else 0
	            END AS FLAG_ACTCOLD_INFL_TOUCHPOINT_BY_DATASOURCE_BIZIBLE,
	            CASE
	                WHEN infl_data.MARKETING_TOUCHPOINT_DATE <= amlh_opp.AMLH_MEA_DATE_STAMP__C
	                AND infl_data.MARKETING_TOUCH_TYPE_DATA_SOURCE = 'Bizible' THEN 1
	                else 0
	            END AS FLAG_ACTMEA_INFL_TOUCHPOINT_BY_DATASOURCE_BIZIBLE,
	            CASE
	                WHEN infl_data.MARKETING_TOUCHPOINT_DATE <= amlh_opp.AMLH_MQA_DATE_STAMP__C
	                AND infl_data.MARKETING_TOUCH_TYPE_DATA_SOURCE = 'Bizible' THEN 1
	                else 0
	            END AS FLAG_ACTMQA_INFL_TOUCHPOINT_BY_DATASOURCE_BIZIBLE,
	            CASE
	                WHEN infl_data.MARKETING_TOUCHPOINT_DATE <= amlh_opp.AMLH_SUSPECT_DATE_STAMP__C
	                AND infl_data.MARKETING_TOUCH_TYPE_DATA_SOURCE = 'Bizible' THEN 1
	                else 0
	            END AS FLAG_ACTSUSPECT_INFL_TOUCHPOINT_BY_DATASOURCE_BIZIBLE,
	            CASE
	                WHEN infl_data.MARKETING_TOUCHPOINT_DATE <= amlh_opp.AMLH_PROSPECT_DATE_STAMP__C
	                AND infl_data.MARKETING_TOUCH_TYPE_DATA_SOURCE = 'Bizible' THEN 1
	                else 0
	            END AS FLAG_ACTPROSPECT_INFL_TOUCHPOINT_BY_DATASOURCE_BIZIBLE,
	            -- COUNT ONLY IF INFLUENCE
	            -- Influenced before Opp Created
	            CASE
	                WHEN infl_data.MARKETING_TOUCHPOINT_DATE <= amlh_opp.OPP_CREATED_DATE
	                AND infl_data.INTERACTIONTYPE_SIXSENSE_PAIDMEDIA_IMPRESSIONS_COUNT > 0 THEN 1
	                ELSE 0
	            END AS FLAG_OPPCRT_INFL_TOUCHPOINT_BY_INTERACTIONTYPE_SIXSENSE_PAIDMEDIA_IMPRESSION,
	            CASE
	                WHEN infl_data.MARKETING_TOUCHPOINT_DATE <= amlh_opp.OPP_CREATED_DATE
	                AND infl_data.INTERACTIONTYPE_SIXSENSE_PAIDMEDIA_CLICKS_COUNT > 0 THEN 1
	                ELSE 0
	            END AS FLAG_OPPCRT_INFL_TOUCHPOINT_BY_INTERACTIONTYPE_SIXSENSE_PAIDMEDIA_CLICK,
	            CASE
	                WHEN infl_data.MARKETING_TOUCHPOINT_DATE <= amlh_opp.OPP_CREATED_DATE
	                AND infl_data.INTERACTIONTYPE_SIXSENSE_WEBVISIT_TOTAL_INTERACTIONS_COUNT > 0 THEN 1
	                ELSE 0
	            END AS FLAG_OPPCRT_INFL_TOUCHPOINT_BY_INTERACTIONTYPE_SIXSENSE_WEBVISIT_TOTAL_INTERACTIONS,
	            CASE
	                WHEN infl_data.MARKETING_TOUCHPOINT_DATE <= amlh_opp.OPP_CREATED_DATE
	                AND infl_data.INTERACTIONTYPE_SIXSENSE_WEBVISIT_PAGELOAD_COUNT > 0 THEN 1
	                ELSE 0
	            END AS FLAG_OPPCRT_INFL_TOUCHPOINT_BY_INTERACTIONTYPE_SIXSENSE_WEBVISIT_PAGELOAD,
	            CASE
	                WHEN infl_data.MARKETING_TOUCHPOINT_DATE <= amlh_opp.OPP_CREATED_DATE
	                AND infl_data.INTERACTIONTYPE_SIXSENSE_WEBVISIT_PLAY_COUNT > 0 THEN 1
	                ELSE 0
	            END AS FLAG_OPPCRT_INFL_TOUCHPOINT_BY_INTERACTIONTYPE_SIXSENSE_WEBVISIT_PLAY,
	            CASE
	                WHEN infl_data.MARKETING_TOUCHPOINT_DATE <= amlh_opp.OPP_CREATED_DATE
	                AND infl_data.INTERACTIONTYPE_SIXSENSE_WEBVISIT_CLICK_COUNT > 0 THEN 1
	                ELSE 0
	            END AS FLAG_OPPCRT_INFL_TOUCHPOINT_BY_INTERACTIONTYPE_SIXSENSE_WEBVISIT_CLICK,
	            CASE
	                WHEN infl_data.MARKETING_TOUCHPOINT_DATE <= amlh_opp.OPP_CREATED_DATE
	                AND infl_data.INTERACTIONTYPE_SIXSENSE_WEBVISIT_SUBMIT_COUNT > 0 THEN 1
	                ELSE 0
	            END AS FLAG_OPPCRT_INFL_TOUCHPOINT_BY_INTERACTIONTYPE_SIXSENSE_WEBVISIT_SUBMIT,
	            CASE
	                WHEN infl_data.MARKETING_TOUCHPOINT_DATE <= amlh_opp.OPP_CREATED_DATE
	                AND infl_data.INTERACTIONTYPE_SIXSENSE_WEBVISIT_UNCLASSIFIED_COUNT > 0 THEN 1
	                ELSE 0
	            END AS FLAG_OPPCRT_INFL_TOUCHPOINT_BY_INTERACTIONTYPE_SIXSENSE_WEBVISIT_UNCLASSIFIED,
	            CASE
	                WHEN infl_data.MARKETING_TOUCHPOINT_DATE <= amlh_opp.OPP_CREATED_DATE
	                AND infl_data.INTERACTIONTYPE_BIZIBLE_TOUCHPOINT_WEBVISIT_COUNT > 0 THEN 1
	                ELSE 0
	            END AS FLAG_OPPCRT_INFL_TOUCHPOINT_BY_INTERACTIONTYPE_BIZIBLE_TOUCHPOINT_WEBVISIT,
	            CASE
	                WHEN infl_data.MARKETING_TOUCHPOINT_DATE <= amlh_opp.OPP_CREATED_DATE
	                AND infl_data.INTERACTIONTYPE_BIZIBLE_TOUCHPOINT_WEBCHAT_COUNT > 0 THEN 1
	                ELSE 0
	            END AS FLAG_OPPCRT_INFL_TOUCHPOINT_BY_INTERACTIONTYPE_BIZIBLE_TOUCHPOINT_WEBCHAT,
	            CASE
	                WHEN infl_data.MARKETING_TOUCHPOINT_DATE <= amlh_opp.OPP_CREATED_DATE
	                AND infl_data.INTERACTIONTYPE_BIZIBLE_TOUCHPOINT_WEBFORM_COUNT > 0 THEN 1
	                ELSE 0
	            END AS FLAG_OPPCRT_INFL_TOUCHPOINT_BY_INTERACTIONTYPE_BIZIBLE_TOUCHPOINT_WEBFORM,
	            CASE
	                WHEN infl_data.MARKETING_TOUCHPOINT_DATE <= amlh_opp.OPP_CREATED_DATE
	                AND infl_data.INTERACTIONTYPE_BIZIBLE_TOUCHPOINT_CRM_COUNT > 0 THEN 1
	                ELSE 0
	            END AS FLAG_OPPCRT_INFL_TOUCHPOINT_BY_INTERACTIONTYPE_BIZIBLE_TOUCHPOINT_CRM,
	            CASE
	                WHEN infl_data.MARKETING_TOUCHPOINT_DATE <= amlh_opp.OPP_CREATED_DATE
	                AND infl_data.INTERACTIONTYPE_BIZIBLE_TOUCHPOINT_CONNECTWITHDM_COUNT > 0 THEN 1
	                ELSE 0
	            END AS FLAG_OPPCRT_INFL_TOUCHPOINT_BY_INTERACTIONTYPE_BIZIBLE_TOUCHPOINT_CONNECTWITHDM,
	            CASE
	                WHEN infl_data.MARKETING_TOUCHPOINT_DATE <= amlh_opp.OPP_CREATED_DATE
	                AND infl_data.INTERACTIONTYPE_BIZIBLE_TOUCHPOINT_CALLSPOKEWITH_COUNT > 0 THEN 1
	                ELSE 0
	            END AS FLAG_OPPCRT_INFL_TOUCHPOINT_BY_INTERACTIONTYPE_BIZIBLE_TOUCHPOINT_CALLSPOKEIWTH,
	            CASE
	                WHEN infl_data.MARKETING_TOUCHPOINT_DATE <= amlh_opp.OPP_CREATED_DATE
	                AND infl_data.INTERACTIONTYPE_BIZIBLE_TOUCHPOINT_CALLGATEKEEPER_COUNT > 0 THEN 1
	                ELSE 0
	            END AS FLAG_OPPCRT_INFL_TOUCHPOINT_BY_INTERACTIONTYPE_BIZIBLE_TOUCHPOINT_GATEKEEPER,
	            CASE
	                WHEN infl_data.MARKETING_TOUCHPOINT_DATE <= amlh_opp.OPP_CREATED_DATE
	                AND infl_data.INTERACTIONTYPE_BIZIBLE_TOUCHPOINT_NOLEADTOUCHPOINTS_COUNT > 0 THEN 1
	                ELSE 0
	            END AS FLAG_OPPCRT_INFL_TOUCHPOINT_BY_INTERACTIONTYPE_BIZIBLE_TOUCHPOINT_NOLEADTOUCHPOINT,
	            CASE
	                WHEN infl_data.MARKETING_TOUCHPOINT_DATE <= amlh_opp.OPP_CREATED_DATE
	                AND infl_data.INTERACTIONTYPE_BIZIBLE_TOUCHPOINT_UNCLASSIFIED_COUNT > 0 THEN 1
	                ELSE 0
	            END AS FLAG_OPPCRT_INFL_TOUCHPOINT_BY_INTERACTIONTYPE_BIZIBLE_TOUCHPOINT_UNCLASSIFIED,
	            -- Influenced before Opp Close Date
	            CASE
	                WHEN infl_data.MARKETING_TOUCHPOINT_DATE <= amlh_opp.OPP_CLOSE_DATE
	                AND infl_data.INTERACTIONTYPE_SIXSENSE_PAIDMEDIA_IMPRESSIONS_COUNT > 0 THEN 1
	                ELSE 0
	            END AS FLAG_OPPCLS_INFL_TOUCHPOINT_BY_INTERACTIONTYPE_SIXSENSE_PAIDMEDIA_IMPRESSION,
	            CASE
	                WHEN infl_data.MARKETING_TOUCHPOINT_DATE <= amlh_opp.OPP_CLOSE_DATE
	                AND infl_data.INTERACTIONTYPE_SIXSENSE_PAIDMEDIA_CLICKS_COUNT > 0 THEN 1
	                ELSE 0
	            END AS FLAG_OPPCLS_INFL_TOUCHPOINT_BY_INTERACTIONTYPE_SIXSENSE_PAIDMEDIA_CLICK,
	            CASE
	                WHEN infl_data.MARKETING_TOUCHPOINT_DATE <= amlh_opp.OPP_CLOSE_DATE
	                AND infl_data.INTERACTIONTYPE_SIXSENSE_WEBVISIT_TOTAL_INTERACTIONS_COUNT > 0 THEN 1
	                ELSE 0
	            END AS FLAG_OPPCLS_INFL_TOUCHPOINT_BY_INTERACTIONTYPE_SIXSENSE_WEBVISIT_TOTAL_INTERACTIONS,
	            CASE
	                WHEN infl_data.MARKETING_TOUCHPOINT_DATE <= amlh_opp.OPP_CLOSE_DATE
	                AND infl_data.INTERACTIONTYPE_SIXSENSE_WEBVISIT_PAGELOAD_COUNT > 0 THEN 1
	                ELSE 0
	            END AS FLAG_OPPCLS_INFL_TOUCHPOINT_BY_INTERACTIONTYPE_SIXSENSE_WEBVISIT_PAGELOAD,
	            CASE
	                WHEN infl_data.MARKETING_TOUCHPOINT_DATE <= amlh_opp.OPP_CLOSE_DATE
	                AND infl_data.INTERACTIONTYPE_SIXSENSE_WEBVISIT_PLAY_COUNT > 0 THEN 1
	                ELSE 0
	            END AS FLAG_OPPCLS_INFL_TOUCHPOINT_BY_INTERACTIONTYPE_SIXSENSE_WEBVISIT_PLAY,
	            CASE
	                WHEN infl_data.MARKETING_TOUCHPOINT_DATE <= amlh_opp.OPP_CLOSE_DATE
	                AND infl_data.INTERACTIONTYPE_SIXSENSE_WEBVISIT_CLICK_COUNT > 0 THEN 1
	                ELSE 0
	            END AS FLAG_OPPCLS_INFL_TOUCHPOINT_BY_INTERACTIONTYPE_SIXSENSE_WEBVISIT_CLICK,
	            CASE
	                WHEN infl_data.MARKETING_TOUCHPOINT_DATE <= amlh_opp.OPP_CLOSE_DATE
	                AND infl_data.INTERACTIONTYPE_SIXSENSE_WEBVISIT_SUBMIT_COUNT > 0 THEN 1
	                ELSE 0
	            END AS FLAG_OPPCLS_INFL_TOUCHPOINT_BY_INTERACTIONTYPE_SIXSENSE_WEBVISIT_SUBMIT,
	            CASE
	                WHEN infl_data.MARKETING_TOUCHPOINT_DATE <= amlh_opp.OPP_CLOSE_DATE
	                AND infl_data.INTERACTIONTYPE_SIXSENSE_WEBVISIT_UNCLASSIFIED_COUNT > 0 THEN 1
	                ELSE 0
	            END AS FLAG_OPPCLS_INFL_TOUCHPOINT_BY_INTERACTIONTYPE_SIXSENSE_WEBVISIT_UNCLASSIFIED,
	            CASE
	                WHEN infl_data.MARKETING_TOUCHPOINT_DATE <= amlh_opp.OPP_CLOSE_DATE
	                AND infl_data.INTERACTIONTYPE_BIZIBLE_TOUCHPOINT_WEBVISIT_COUNT > 0 THEN 1
	                ELSE 0
	            END AS FLAG_OPPCLS_INFL_TOUCHPOINT_BY_INTERACTIONTYPE_BIZIBLE_TOUCHPOINT_WEBVISIT,
	            CASE
	                WHEN infl_data.MARKETING_TOUCHPOINT_DATE <= amlh_opp.OPP_CLOSE_DATE
	                AND infl_data.INTERACTIONTYPE_BIZIBLE_TOUCHPOINT_WEBCHAT_COUNT > 0 THEN 1
	                ELSE 0
	            END AS FLAG_OPPCLS_INFL_TOUCHPOINT_BY_INTERACTIONTYPE_BIZIBLE_TOUCHPOINT_WEBCHAT,
	            CASE
	                WHEN infl_data.MARKETING_TOUCHPOINT_DATE <= amlh_opp.OPP_CLOSE_DATE
	                AND infl_data.INTERACTIONTYPE_BIZIBLE_TOUCHPOINT_WEBFORM_COUNT > 0 THEN 1
	                ELSE 0
	            END AS FLAG_OPPCLS_INFL_TOUCHPOINT_BY_INTERACTIONTYPE_BIZIBLE_TOUCHPOINT_WEBFORM,
	            CASE
	                WHEN infl_data.MARKETING_TOUCHPOINT_DATE <= amlh_opp.OPP_CLOSE_DATE
	                AND infl_data.INTERACTIONTYPE_BIZIBLE_TOUCHPOINT_CRM_COUNT > 0 THEN 1
	                ELSE 0
	            END AS FLAG_OPPCLS_INFL_TOUCHPOINT_BY_INTERACTIONTYPE_BIZIBLE_TOUCHPOINT_CRM,
	            CASE
	                WHEN infl_data.MARKETING_TOUCHPOINT_DATE <= amlh_opp.OPP_CLOSE_DATE
	                AND infl_data.INTERACTIONTYPE_BIZIBLE_TOUCHPOINT_CONNECTWITHDM_COUNT > 0 THEN 1
	                ELSE 0
	            END AS FLAG_OPPCLS_INFL_TOUCHPOINT_BY_INTERACTIONTYPE_BIZIBLE_TOUCHPOINT_CONNECTWITHDM,
	            CASE
	                WHEN infl_data.MARKETING_TOUCHPOINT_DATE <= amlh_opp.OPP_CLOSE_DATE
	                AND infl_data.INTERACTIONTYPE_BIZIBLE_TOUCHPOINT_CALLSPOKEWITH_COUNT > 0 THEN 1
	                ELSE 0
	            END AS FLAG_OPPCLS_INFL_TOUCHPOINT_BY_INTERACTIONTYPE_BIZIBLE_TOUCHPOINT_CALLSPOKEIWTH,
	            CASE
	                WHEN infl_data.MARKETING_TOUCHPOINT_DATE <= amlh_opp.OPP_CLOSE_DATE
	                AND infl_data.INTERACTIONTYPE_BIZIBLE_TOUCHPOINT_CALLGATEKEEPER_COUNT > 0 THEN 1
	                ELSE 0
	            END AS FLAG_OPPCLS_INFL_TOUCHPOINT_BY_INTERACTIONTYPE_BIZIBLE_TOUCHPOINT_GATEKEEPER,
	            CASE
	                WHEN infl_data.MARKETING_TOUCHPOINT_DATE <= amlh_opp.OPP_CLOSE_DATE
	                AND infl_data.INTERACTIONTYPE_BIZIBLE_TOUCHPOINT_NOLEADTOUCHPOINTS_COUNT > 0 THEN 1
	                ELSE 0
	            END AS FLAG_OPPCLS_INFL_TOUCHPOINT_BY_INTERACTIONTYPE_BIZIBLE_TOUCHPOINT_NOLEADTOUCHPOINT,
	            CASE
	                WHEN infl_data.MARKETING_TOUCHPOINT_DATE <= amlh_opp.OPP_CLOSE_DATE
	                AND infl_data.INTERACTIONTYPE_BIZIBLE_TOUCHPOINT_UNCLASSIFIED_COUNT > 0 THEN 1
	                ELSE 0
	            END AS FLAG_OPPCLS_INFL_TOUCHPOINT_BY_INTERACTIONTYPE_BIZIBLE_TOUCHPOINT_UNCLASSIFIED,
	            -- Influenced before Act Cold
	            CASE
	                WHEN infl_data.MARKETING_TOUCHPOINT_DATE <= amlh_opp.AMLH_COLD_ACCOUNT_DATE_STAMP__C
	                AND infl_data.INTERACTIONTYPE_SIXSENSE_PAIDMEDIA_IMPRESSIONS_COUNT > 0 THEN 1
	                ELSE 0
	            END AS FLAG_ACTCOLD_INFL_TOUCHPOINT_BY_INTERACTIONTYPE_SIXSENSE_PAIDMEDIA_IMPRESSION,
	            CASE
	                WHEN infl_data.MARKETING_TOUCHPOINT_DATE <= amlh_opp.AMLH_COLD_ACCOUNT_DATE_STAMP__C
	                AND infl_data.INTERACTIONTYPE_SIXSENSE_PAIDMEDIA_CLICKS_COUNT > 0 THEN 1
	                ELSE 0
	            END AS FLAG_ACTCOLD_INFL_TOUCHPOINT_BY_INTERACTIONTYPE_SIXSENSE_PAIDMEDIA_CLICK,
	            CASE
	                WHEN infl_data.MARKETING_TOUCHPOINT_DATE <= amlh_opp.AMLH_COLD_ACCOUNT_DATE_STAMP__C
	                AND infl_data.INTERACTIONTYPE_SIXSENSE_WEBVISIT_TOTAL_INTERACTIONS_COUNT > 0 THEN 1
	                ELSE 0
	            END AS FLAG_ACTCOLD_INFL_TOUCHPOINT_BY_INTERACTIONTYPE_SIXSENSE_WEBVISIT_TOTAL_INTERACTIONS,
	            CASE
	                WHEN infl_data.MARKETING_TOUCHPOINT_DATE <= amlh_opp.AMLH_COLD_ACCOUNT_DATE_STAMP__C
	                AND infl_data.INTERACTIONTYPE_SIXSENSE_WEBVISIT_PAGELOAD_COUNT > 0 THEN 1
	                ELSE 0
	            END AS FLAG_ACTCOLD_INFL_TOUCHPOINT_BY_INTERACTIONTYPE_SIXSENSE_WEBVISIT_PAGELOAD,
	            CASE
	                WHEN infl_data.MARKETING_TOUCHPOINT_DATE <= amlh_opp.AMLH_COLD_ACCOUNT_DATE_STAMP__C
	                AND infl_data.INTERACTIONTYPE_SIXSENSE_WEBVISIT_PLAY_COUNT > 0 THEN 1
	                ELSE 0
	            END AS FLAG_ACTCOLD_INFL_TOUCHPOINT_BY_INTERACTIONTYPE_SIXSENSE_WEBVISIT_PLAY,
	            CASE
	                WHEN infl_data.MARKETING_TOUCHPOINT_DATE <= amlh_opp.AMLH_COLD_ACCOUNT_DATE_STAMP__C
	                AND infl_data.INTERACTIONTYPE_SIXSENSE_WEBVISIT_CLICK_COUNT > 0 THEN 1
	                ELSE 0
	            END AS FLAG_ACTCOLD_INFL_TOUCHPOINT_BY_INTERACTIONTYPE_SIXSENSE_WEBVISIT_CLICK,
	            CASE
	                WHEN infl_data.MARKETING_TOUCHPOINT_DATE <= amlh_opp.AMLH_COLD_ACCOUNT_DATE_STAMP__C
	                AND infl_data.INTERACTIONTYPE_SIXSENSE_WEBVISIT_SUBMIT_COUNT > 0 THEN 1
	                ELSE 0
	            END AS FLAG_ACTCOLD_INFL_TOUCHPOINT_BY_INTERACTIONTYPE_SIXSENSE_WEBVISIT_SUBMIT,
	            CASE
	                WHEN infl_data.MARKETING_TOUCHPOINT_DATE <= amlh_opp.AMLH_COLD_ACCOUNT_DATE_STAMP__C
	                AND infl_data.INTERACTIONTYPE_SIXSENSE_WEBVISIT_UNCLASSIFIED_COUNT > 0 THEN 1
	                ELSE 0
	            END AS FLAG_ACTCOLD_INFL_TOUCHPOINT_BY_INTERACTIONTYPE_SIXSENSE_WEBVISIT_UNCLASSIFIED,
	            CASE
	                WHEN infl_data.MARKETING_TOUCHPOINT_DATE <= amlh_opp.AMLH_COLD_ACCOUNT_DATE_STAMP__C
	                AND infl_data.INTERACTIONTYPE_BIZIBLE_TOUCHPOINT_WEBVISIT_COUNT > 0 THEN 1
	                ELSE 0
	            END AS FLAG_ACTCOLD_INFL_TOUCHPOINT_BY_INTERACTIONTYPE_BIZIBLE_TOUCHPOINT_WEBVISIT,
	            CASE
	                WHEN infl_data.MARKETING_TOUCHPOINT_DATE <= amlh_opp.AMLH_COLD_ACCOUNT_DATE_STAMP__C
	                AND infl_data.INTERACTIONTYPE_BIZIBLE_TOUCHPOINT_WEBCHAT_COUNT > 0 THEN 1
	                ELSE 0
	            END AS FLAG_ACTCOLD_INFL_TOUCHPOINT_BY_INTERACTIONTYPE_BIZIBLE_TOUCHPOINT_WEBCHAT,
	            CASE
	                WHEN infl_data.MARKETING_TOUCHPOINT_DATE <= amlh_opp.AMLH_COLD_ACCOUNT_DATE_STAMP__C
	                AND infl_data.INTERACTIONTYPE_BIZIBLE_TOUCHPOINT_WEBFORM_COUNT > 0 THEN 1
	                ELSE 0
	            END AS FLAG_ACTCOLD_INFL_TOUCHPOINT_BY_INTERACTIONTYPE_BIZIBLE_TOUCHPOINT_WEBFORM,
	            CASE
	                WHEN infl_data.MARKETING_TOUCHPOINT_DATE <= amlh_opp.AMLH_COLD_ACCOUNT_DATE_STAMP__C
	                AND infl_data.INTERACTIONTYPE_BIZIBLE_TOUCHPOINT_CRM_COUNT > 0 THEN 1
	                ELSE 0
	            END AS FLAG_ACTCOLD_INFL_TOUCHPOINT_BY_INTERACTIONTYPE_BIZIBLE_TOUCHPOINT_CRM,
	            CASE
	                WHEN infl_data.MARKETING_TOUCHPOINT_DATE <= amlh_opp.AMLH_COLD_ACCOUNT_DATE_STAMP__C
	                AND infl_data.INTERACTIONTYPE_BIZIBLE_TOUCHPOINT_CONNECTWITHDM_COUNT > 0 THEN 1
	                ELSE 0
	            END AS FLAG_ACTCOLD_INFL_TOUCHPOINT_BY_INTERACTIONTYPE_BIZIBLE_TOUCHPOINT_CONNECTWITHDM,
	            CASE
	                WHEN infl_data.MARKETING_TOUCHPOINT_DATE <= amlh_opp.AMLH_COLD_ACCOUNT_DATE_STAMP__C
	                AND infl_data.INTERACTIONTYPE_BIZIBLE_TOUCHPOINT_CALLSPOKEWITH_COUNT > 0 THEN 1
	                ELSE 0
	            END AS FLAG_ACTCOLD_INFL_TOUCHPOINT_BY_INTERACTIONTYPE_BIZIBLE_TOUCHPOINT_CALLSPOKEIWTH,
	            CASE
	                WHEN infl_data.MARKETING_TOUCHPOINT_DATE <= amlh_opp.AMLH_COLD_ACCOUNT_DATE_STAMP__C
	                AND infl_data.INTERACTIONTYPE_BIZIBLE_TOUCHPOINT_CALLGATEKEEPER_COUNT > 0 THEN 1
	                ELSE 0
	            END AS FLAG_ACTCOLD_INFL_TOUCHPOINT_BY_INTERACTIONTYPE_BIZIBLE_TOUCHPOINT_GATEKEEPER,
	            CASE
	                WHEN infl_data.MARKETING_TOUCHPOINT_DATE <= amlh_opp.AMLH_COLD_ACCOUNT_DATE_STAMP__C
	                AND infl_data.INTERACTIONTYPE_BIZIBLE_TOUCHPOINT_NOLEADTOUCHPOINTS_COUNT > 0 THEN 1
	                ELSE 0
	            END AS FLAG_ACTCOLD_INFL_TOUCHPOINT_BY_INTERACTIONTYPE_BIZIBLE_TOUCHPOINT_NOLEADTOUCHPOINT,
	            CASE
	                WHEN infl_data.MARKETING_TOUCHPOINT_DATE <= amlh_opp.AMLH_COLD_ACCOUNT_DATE_STAMP__C
	                AND infl_data.INTERACTIONTYPE_BIZIBLE_TOUCHPOINT_UNCLASSIFIED_COUNT > 0 THEN 1
	                ELSE 0
	            END AS FLAG_ACTCOLD_INFL_TOUCHPOINT_BY_INTERACTIONTYPE_BIZIBLE_TOUCHPOINT_UNCLASSIFIED,
	            -- Influenced before Act MEA
	            CASE
	                WHEN infl_data.MARKETING_TOUCHPOINT_DATE <= amlh_opp.AMLH_MEA_DATE_STAMP__C
	                AND infl_data.INTERACTIONTYPE_SIXSENSE_PAIDMEDIA_IMPRESSIONS_COUNT > 0 THEN 1
	                ELSE 0
	            END AS FLAG_ACTMEA_INFL_TOUCHPOINT_BY_INTERACTIONTYPE_SIXSENSE_PAIDMEDIA_IMPRESSION,
	            CASE
	                WHEN infl_data.MARKETING_TOUCHPOINT_DATE <= amlh_opp.AMLH_MEA_DATE_STAMP__C
	                AND infl_data.INTERACTIONTYPE_SIXSENSE_PAIDMEDIA_CLICKS_COUNT > 0 THEN 1
	                ELSE 0
	            END AS FLAG_ACTMEA_INFL_TOUCHPOINT_BY_INTERACTIONTYPE_SIXSENSE_PAIDMEDIA_CLICK,
	            CASE
	                WHEN infl_data.MARKETING_TOUCHPOINT_DATE <= amlh_opp.AMLH_MEA_DATE_STAMP__C
	                AND infl_data.INTERACTIONTYPE_SIXSENSE_WEBVISIT_TOTAL_INTERACTIONS_COUNT > 0 THEN 1
	                ELSE 0
	            END AS FLAG_ACTMEA_INFL_TOUCHPOINT_BY_INTERACTIONTYPE_SIXSENSE_WEBVISIT_TOTAL_INTERACTIONS,
	            CASE
	                WHEN infl_data.MARKETING_TOUCHPOINT_DATE <= amlh_opp.AMLH_MEA_DATE_STAMP__C
	                AND infl_data.INTERACTIONTYPE_SIXSENSE_WEBVISIT_PAGELOAD_COUNT > 0 THEN 1
	                ELSE 0
	            END AS FLAG_ACTMEA_INFL_TOUCHPOINT_BY_INTERACTIONTYPE_SIXSENSE_WEBVISIT_PAGELOAD,
	            CASE
	                WHEN infl_data.MARKETING_TOUCHPOINT_DATE <= amlh_opp.AMLH_MEA_DATE_STAMP__C
	                AND infl_data.INTERACTIONTYPE_SIXSENSE_WEBVISIT_PLAY_COUNT > 0 THEN 1
	                ELSE 0
	            END AS FLAG_ACTMEA_INFL_TOUCHPOINT_BY_INTERACTIONTYPE_SIXSENSE_WEBVISIT_PLAY,
	            CASE
	                WHEN infl_data.MARKETING_TOUCHPOINT_DATE <= amlh_opp.AMLH_MEA_DATE_STAMP__C
	                AND infl_data.INTERACTIONTYPE_SIXSENSE_WEBVISIT_CLICK_COUNT > 0 THEN 1
	                ELSE 0
	            END AS FLAG_ACTMEA_INFL_TOUCHPOINT_BY_INTERACTIONTYPE_SIXSENSE_WEBVISIT_CLICK,
	            CASE
	                WHEN infl_data.MARKETING_TOUCHPOINT_DATE <= amlh_opp.AMLH_MEA_DATE_STAMP__C
	                AND infl_data.INTERACTIONTYPE_SIXSENSE_WEBVISIT_SUBMIT_COUNT > 0 THEN 1
	                ELSE 0
	            END AS FLAG_ACTMEA_INFL_TOUCHPOINT_BY_INTERACTIONTYPE_SIXSENSE_WEBVISIT_SUBMIT,
	            CASE
	                WHEN infl_data.MARKETING_TOUCHPOINT_DATE <= amlh_opp.AMLH_MEA_DATE_STAMP__C
	                AND infl_data.INTERACTIONTYPE_SIXSENSE_WEBVISIT_UNCLASSIFIED_COUNT > 0 THEN 1
	                ELSE 0
	            END AS FLAG_ACTMEA_INFL_TOUCHPOINT_BY_INTERACTIONTYPE_SIXSENSE_WEBVISIT_UNCLASSIFIED,
	            CASE
	                WHEN infl_data.MARKETING_TOUCHPOINT_DATE <= amlh_opp.AMLH_MEA_DATE_STAMP__C
	                AND infl_data.INTERACTIONTYPE_BIZIBLE_TOUCHPOINT_WEBVISIT_COUNT > 0 THEN 1
	                ELSE 0
	            END AS FLAG_ACTMEA_INFL_TOUCHPOINT_BY_INTERACTIONTYPE_BIZIBLE_TOUCHPOINT_WEBVISIT,
	            CASE
	                WHEN infl_data.MARKETING_TOUCHPOINT_DATE <= amlh_opp.AMLH_MEA_DATE_STAMP__C
	                AND infl_data.INTERACTIONTYPE_BIZIBLE_TOUCHPOINT_WEBCHAT_COUNT > 0 THEN 1
	                ELSE 0
	            END AS FLAG_ACTMEA_INFL_TOUCHPOINT_BY_INTERACTIONTYPE_BIZIBLE_TOUCHPOINT_WEBCHAT,
	            CASE
	                WHEN infl_data.MARKETING_TOUCHPOINT_DATE <= amlh_opp.AMLH_MEA_DATE_STAMP__C
	                AND infl_data.INTERACTIONTYPE_BIZIBLE_TOUCHPOINT_WEBFORM_COUNT > 0 THEN 1
	                ELSE 0
	            END AS FLAG_ACTMEA_INFL_TOUCHPOINT_BY_INTERACTIONTYPE_BIZIBLE_TOUCHPOINT_WEBFORM,
	            CASE
	                WHEN infl_data.MARKETING_TOUCHPOINT_DATE <= amlh_opp.AMLH_MEA_DATE_STAMP__C
	                AND infl_data.INTERACTIONTYPE_BIZIBLE_TOUCHPOINT_CRM_COUNT > 0 THEN 1
	                ELSE 0
	            END AS FLAG_ACTMEA_INFL_TOUCHPOINT_BY_INTERACTIONTYPE_BIZIBLE_TOUCHPOINT_CRM,
	            CASE
	                WHEN infl_data.MARKETING_TOUCHPOINT_DATE <= amlh_opp.AMLH_MEA_DATE_STAMP__C
	                AND infl_data.INTERACTIONTYPE_BIZIBLE_TOUCHPOINT_CONNECTWITHDM_COUNT > 0 THEN 1
	                ELSE 0
	            END AS FLAG_ACTMEA_INFL_TOUCHPOINT_BY_INTERACTIONTYPE_BIZIBLE_TOUCHPOINT_CONNECTWITHDM,
	            CASE
	                WHEN infl_data.MARKETING_TOUCHPOINT_DATE <= amlh_opp.AMLH_MEA_DATE_STAMP__C
	                AND infl_data.INTERACTIONTYPE_BIZIBLE_TOUCHPOINT_CALLSPOKEWITH_COUNT > 0 THEN 1
	                ELSE 0
	            END AS FLAG_ACTMEA_INFL_TOUCHPOINT_BY_INTERACTIONTYPE_BIZIBLE_TOUCHPOINT_CALLSPOKEIWTH,
	            CASE
	                WHEN infl_data.MARKETING_TOUCHPOINT_DATE <= amlh_opp.AMLH_MEA_DATE_STAMP__C
	                AND infl_data.INTERACTIONTYPE_BIZIBLE_TOUCHPOINT_CALLGATEKEEPER_COUNT > 0 THEN 1
	                ELSE 0
	            END AS FLAG_ACTMEA_INFL_TOUCHPOINT_BY_INTERACTIONTYPE_BIZIBLE_TOUCHPOINT_GATEKEEPER,
	            CASE
	                WHEN infl_data.MARKETING_TOUCHPOINT_DATE <= amlh_opp.AMLH_MEA_DATE_STAMP__C
	                AND infl_data.INTERACTIONTYPE_BIZIBLE_TOUCHPOINT_NOLEADTOUCHPOINTS_COUNT > 0 THEN 1
	                ELSE 0
	            END AS FLAG_ACTMEA_INFL_TOUCHPOINT_BY_INTERACTIONTYPE_BIZIBLE_TOUCHPOINT_NOLEADTOUCHPOINT,
	            CASE
	                WHEN infl_data.MARKETING_TOUCHPOINT_DATE <= amlh_opp.AMLH_MEA_DATE_STAMP__C
	                AND infl_data.INTERACTIONTYPE_BIZIBLE_TOUCHPOINT_UNCLASSIFIED_COUNT > 0 THEN 1
	                ELSE 0
	            END AS FLAG_ACTMEA_INFL_TOUCHPOINT_BY_INTERACTIONTYPE_BIZIBLE_TOUCHPOINT_UNCLASSIFIED,
	            -- Influenced before Act MQA
	            CASE
	                WHEN infl_data.MARKETING_TOUCHPOINT_DATE <= amlh_opp.AMLH_MQA_DATE_STAMP__C
	                AND infl_data.INTERACTIONTYPE_SIXSENSE_PAIDMEDIA_IMPRESSIONS_COUNT > 0 THEN 1
	                ELSE 0
	            END AS FLAG_ACTMQA_INFL_TOUCHPOINT_BY_INTERACTIONTYPE_SIXSENSE_PAIDMEDIA_IMPRESSION,
	            CASE
	                WHEN infl_data.MARKETING_TOUCHPOINT_DATE <= amlh_opp.AMLH_MQA_DATE_STAMP__C
	                AND infl_data.INTERACTIONTYPE_SIXSENSE_PAIDMEDIA_CLICKS_COUNT > 0 THEN 1
	                ELSE 0
	            END AS FLAG_ACTMQA_INFL_TOUCHPOINT_BY_INTERACTIONTYPE_SIXSENSE_PAIDMEDIA_CLICK,
	            CASE
	                WHEN infl_data.MARKETING_TOUCHPOINT_DATE <= amlh_opp.AMLH_MQA_DATE_STAMP__C
	                AND infl_data.INTERACTIONTYPE_SIXSENSE_WEBVISIT_TOTAL_INTERACTIONS_COUNT > 0 THEN 1
	                ELSE 0
	            END AS FLAG_ACTMQA_INFL_TOUCHPOINT_BY_INTERACTIONTYPE_SIXSENSE_WEBVISIT_TOTAL_INTERACTIONS,
	            CASE
	                WHEN infl_data.MARKETING_TOUCHPOINT_DATE <= amlh_opp.AMLH_MQA_DATE_STAMP__C
	                AND infl_data.INTERACTIONTYPE_SIXSENSE_WEBVISIT_PAGELOAD_COUNT > 0 THEN 1
	                ELSE 0
	            END AS FLAG_ACTMQA_INFL_TOUCHPOINT_BY_INTERACTIONTYPE_SIXSENSE_WEBVISIT_PAGELOAD,
	            CASE
	                WHEN infl_data.MARKETING_TOUCHPOINT_DATE <= amlh_opp.AMLH_MQA_DATE_STAMP__C
	                AND infl_data.INTERACTIONTYPE_SIXSENSE_WEBVISIT_PLAY_COUNT > 0 THEN 1
	                ELSE 0
	            END AS FLAG_ACTMQA_INFL_TOUCHPOINT_BY_INTERACTIONTYPE_SIXSENSE_WEBVISIT_PLAY,
	            CASE
	                WHEN infl_data.MARKETING_TOUCHPOINT_DATE <= amlh_opp.AMLH_MQA_DATE_STAMP__C
	                AND infl_data.INTERACTIONTYPE_SIXSENSE_WEBVISIT_CLICK_COUNT > 0 THEN 1
	                ELSE 0
	            END AS FLAG_ACTMQA_INFL_TOUCHPOINT_BY_INTERACTIONTYPE_SIXSENSE_WEBVISIT_CLICK,
	            CASE
	                WHEN infl_data.MARKETING_TOUCHPOINT_DATE <= amlh_opp.AMLH_MQA_DATE_STAMP__C
	                AND infl_data.INTERACTIONTYPE_SIXSENSE_WEBVISIT_SUBMIT_COUNT > 0 THEN 1
	                ELSE 0
	            END AS FLAG_ACTMQA_INFL_TOUCHPOINT_BY_INTERACTIONTYPE_SIXSENSE_WEBVISIT_SUBMIT,
	            CASE
	                WHEN infl_data.MARKETING_TOUCHPOINT_DATE <= amlh_opp.AMLH_MQA_DATE_STAMP__C
	                AND infl_data.INTERACTIONTYPE_SIXSENSE_WEBVISIT_UNCLASSIFIED_COUNT > 0 THEN 1
	                ELSE 0
	            END AS FLAG_ACTMQA_INFL_TOUCHPOINT_BY_INTERACTIONTYPE_SIXSENSE_WEBVISIT_UNCLASSIFIED,
	            CASE
	                WHEN infl_data.MARKETING_TOUCHPOINT_DATE <= amlh_opp.AMLH_MQA_DATE_STAMP__C
	                AND infl_data.INTERACTIONTYPE_BIZIBLE_TOUCHPOINT_WEBVISIT_COUNT > 0 THEN 1
	                ELSE 0
	            END AS FLAG_ACTMQA_INFL_TOUCHPOINT_BY_INTERACTIONTYPE_BIZIBLE_TOUCHPOINT_WEBVISIT,
	            CASE
	                WHEN infl_data.MARKETING_TOUCHPOINT_DATE <= amlh_opp.AMLH_MQA_DATE_STAMP__C
	                AND infl_data.INTERACTIONTYPE_BIZIBLE_TOUCHPOINT_WEBCHAT_COUNT > 0 THEN 1
	                ELSE 0
	            END AS FLAG_ACTMQA_INFL_TOUCHPOINT_BY_INTERACTIONTYPE_BIZIBLE_TOUCHPOINT_WEBCHAT,
	            CASE
	                WHEN infl_data.MARKETING_TOUCHPOINT_DATE <= amlh_opp.AMLH_MQA_DATE_STAMP__C
	                AND infl_data.INTERACTIONTYPE_BIZIBLE_TOUCHPOINT_WEBFORM_COUNT > 0 THEN 1
	                ELSE 0
	            END AS FLAG_ACTMQA_INFL_TOUCHPOINT_BY_INTERACTIONTYPE_BIZIBLE_TOUCHPOINT_WEBFORM,
	            CASE
	                WHEN infl_data.MARKETING_TOUCHPOINT_DATE <= amlh_opp.AMLH_MQA_DATE_STAMP__C
	                AND infl_data.INTERACTIONTYPE_BIZIBLE_TOUCHPOINT_CRM_COUNT > 0 THEN 1
	                ELSE 0
	            END AS FLAG_ACTMQA_INFL_TOUCHPOINT_BY_INTERACTIONTYPE_BIZIBLE_TOUCHPOINT_CRM,
	            CASE
	                WHEN infl_data.MARKETING_TOUCHPOINT_DATE <= amlh_opp.AMLH_MQA_DATE_STAMP__C
	                AND infl_data.INTERACTIONTYPE_BIZIBLE_TOUCHPOINT_CONNECTWITHDM_COUNT > 0 THEN 1
	                ELSE 0
	            END AS FLAG_ACTMQA_INFL_TOUCHPOINT_BY_INTERACTIONTYPE_BIZIBLE_TOUCHPOINT_CONNECTWITHDM,
	            CASE
	                WHEN infl_data.MARKETING_TOUCHPOINT_DATE <= amlh_opp.AMLH_MQA_DATE_STAMP__C
	                AND infl_data.INTERACTIONTYPE_BIZIBLE_TOUCHPOINT_CALLSPOKEWITH_COUNT > 0 THEN 1
	                ELSE 0
	            END AS FLAG_ACTMQA_INFL_TOUCHPOINT_BY_INTERACTIONTYPE_BIZIBLE_TOUCHPOINT_CALLSPOKEIWTH,
	            CASE
	                WHEN infl_data.MARKETING_TOUCHPOINT_DATE <= amlh_opp.AMLH_MQA_DATE_STAMP__C
	                AND infl_data.INTERACTIONTYPE_BIZIBLE_TOUCHPOINT_CALLGATEKEEPER_COUNT > 0 THEN 1
	                ELSE 0
	            END AS FLAG_ACTMQA_INFL_TOUCHPOINT_BY_INTERACTIONTYPE_BIZIBLE_TOUCHPOINT_GATEKEEPER,
	            CASE
	                WHEN infl_data.MARKETING_TOUCHPOINT_DATE <= amlh_opp.AMLH_MQA_DATE_STAMP__C
	                AND infl_data.INTERACTIONTYPE_BIZIBLE_TOUCHPOINT_NOLEADTOUCHPOINTS_COUNT > 0 THEN 1
	                ELSE 0
	            END AS FLAG_ACTMQA_INFL_TOUCHPOINT_BY_INTERACTIONTYPE_BIZIBLE_TOUCHPOINT_NOLEADTOUCHPOINT,
	            CASE
	                WHEN infl_data.MARKETING_TOUCHPOINT_DATE <= amlh_opp.AMLH_MQA_DATE_STAMP__C
	                AND infl_data.INTERACTIONTYPE_BIZIBLE_TOUCHPOINT_UNCLASSIFIED_COUNT > 0 THEN 1
	                ELSE 0
	            END AS FLAG_ACTMQA_INFL_TOUCHPOINT_BY_INTERACTIONTYPE_BIZIBLE_TOUCHPOINT_UNCLASSIFIED,
	            -- Influenced before Act Suspect
	            CASE
	                WHEN infl_data.MARKETING_TOUCHPOINT_DATE <= amlh_opp.AMLH_SUSPECT_DATE_STAMP__C
	                AND infl_data.INTERACTIONTYPE_SIXSENSE_PAIDMEDIA_IMPRESSIONS_COUNT > 0 THEN 1
	                ELSE 0
	            END AS FLAG_ACTSUSPECT_INFL_TOUCHPOINT_BY_INTERACTIONTYPE_SIXSENSE_PAIDMEDIA_IMPRESSION,
	            CASE
	                WHEN infl_data.MARKETING_TOUCHPOINT_DATE <= amlh_opp.AMLH_SUSPECT_DATE_STAMP__C
	                AND infl_data.INTERACTIONTYPE_SIXSENSE_PAIDMEDIA_CLICKS_COUNT > 0 THEN 1
	                ELSE 0
	            END AS FLAG_ACTSUSPECT_INFL_TOUCHPOINT_BY_INTERACTIONTYPE_SIXSENSE_PAIDMEDIA_CLICK,
	            CASE
	                WHEN infl_data.MARKETING_TOUCHPOINT_DATE <= amlh_opp.AMLH_SUSPECT_DATE_STAMP__C
	                AND infl_data.INTERACTIONTYPE_SIXSENSE_WEBVISIT_TOTAL_INTERACTIONS_COUNT > 0 THEN 1
	                ELSE 0
	            END AS FLAG_ACTSUSPECT_INFL_TOUCHPOINT_BY_INTERACTIONTYPE_SIXSENSE_WEBVISIT_TOTAL_INTERACTIONS,
	            CASE
	                WHEN infl_data.MARKETING_TOUCHPOINT_DATE <= amlh_opp.AMLH_SUSPECT_DATE_STAMP__C
	                AND infl_data.INTERACTIONTYPE_SIXSENSE_WEBVISIT_PAGELOAD_COUNT > 0 THEN 1
	                ELSE 0
	            END AS FLAG_ACTSUSPECT_INFL_TOUCHPOINT_BY_INTERACTIONTYPE_SIXSENSE_WEBVISIT_PAGELOAD,
	            CASE
	                WHEN infl_data.MARKETING_TOUCHPOINT_DATE <= amlh_opp.AMLH_SUSPECT_DATE_STAMP__C
	                AND infl_data.INTERACTIONTYPE_SIXSENSE_WEBVISIT_PLAY_COUNT > 0 THEN 1
	                ELSE 0
	            END AS FLAG_ACTSUSPECT_INFL_TOUCHPOINT_BY_INTERACTIONTYPE_SIXSENSE_WEBVISIT_PLAY,
	            CASE
	                WHEN infl_data.MARKETING_TOUCHPOINT_DATE <= amlh_opp.AMLH_SUSPECT_DATE_STAMP__C
	                AND infl_data.INTERACTIONTYPE_SIXSENSE_WEBVISIT_CLICK_COUNT > 0 THEN 1
	                ELSE 0
	            END AS FLAG_ACTSUSPECT_INFL_TOUCHPOINT_BY_INTERACTIONTYPE_SIXSENSE_WEBVISIT_CLICK,
	            CASE
	                WHEN infl_data.MARKETING_TOUCHPOINT_DATE <= amlh_opp.AMLH_SUSPECT_DATE_STAMP__C
	                AND infl_data.INTERACTIONTYPE_SIXSENSE_WEBVISIT_SUBMIT_COUNT > 0 THEN 1
	                ELSE 0
	            END AS FLAG_ACTSUSPECT_INFL_TOUCHPOINT_BY_INTERACTIONTYPE_SIXSENSE_WEBVISIT_SUBMIT,
	            CASE
	                WHEN infl_data.MARKETING_TOUCHPOINT_DATE <= amlh_opp.AMLH_SUSPECT_DATE_STAMP__C
	                AND infl_data.INTERACTIONTYPE_SIXSENSE_WEBVISIT_UNCLASSIFIED_COUNT > 0 THEN 1
	                ELSE 0
	            END AS FLAG_ACTSUSPECT_INFL_TOUCHPOINT_BY_INTERACTIONTYPE_SIXSENSE_WEBVISIT_UNCLASSIFIED,
	            CASE
	                WHEN infl_data.MARKETING_TOUCHPOINT_DATE <= amlh_opp.AMLH_SUSPECT_DATE_STAMP__C
	                AND infl_data.INTERACTIONTYPE_BIZIBLE_TOUCHPOINT_WEBVISIT_COUNT > 0 THEN 1
	                ELSE 0
	            END AS FLAG_ACTSUSPECT_INFL_TOUCHPOINT_BY_INTERACTIONTYPE_BIZIBLE_TOUCHPOINT_WEBVISIT,
	            CASE
	                WHEN infl_data.MARKETING_TOUCHPOINT_DATE <= amlh_opp.AMLH_SUSPECT_DATE_STAMP__C
	                AND infl_data.INTERACTIONTYPE_BIZIBLE_TOUCHPOINT_WEBCHAT_COUNT > 0 THEN 1
	                ELSE 0
	            END AS FLAG_ACTSUSPECT_INFL_TOUCHPOINT_BY_INTERACTIONTYPE_BIZIBLE_TOUCHPOINT_WEBCHAT,
	            CASE
	                WHEN infl_data.MARKETING_TOUCHPOINT_DATE <= amlh_opp.AMLH_SUSPECT_DATE_STAMP__C
	                AND infl_data.INTERACTIONTYPE_BIZIBLE_TOUCHPOINT_WEBFORM_COUNT > 0 THEN 1
	                ELSE 0
	            END AS FLAG_ACTSUSPECT_INFL_TOUCHPOINT_BY_INTERACTIONTYPE_BIZIBLE_TOUCHPOINT_WEBFORM,
	            CASE
	                WHEN infl_data.MARKETING_TOUCHPOINT_DATE <= amlh_opp.AMLH_SUSPECT_DATE_STAMP__C
	                AND infl_data.INTERACTIONTYPE_BIZIBLE_TOUCHPOINT_CRM_COUNT > 0 THEN 1
	                ELSE 0
	            END AS FLAG_ACTSUSPECT_INFL_TOUCHPOINT_BY_INTERACTIONTYPE_BIZIBLE_TOUCHPOINT_CRM,
	            CASE
	                WHEN infl_data.MARKETING_TOUCHPOINT_DATE <= amlh_opp.AMLH_SUSPECT_DATE_STAMP__C
	                AND infl_data.INTERACTIONTYPE_BIZIBLE_TOUCHPOINT_CONNECTWITHDM_COUNT > 0 THEN 1
	                ELSE 0
	            END AS FLAG_ACTSUSPECT_INFL_TOUCHPOINT_BY_INTERACTIONTYPE_BIZIBLE_TOUCHPOINT_CONNECTWITHDM,
	            CASE
	                WHEN infl_data.MARKETING_TOUCHPOINT_DATE <= amlh_opp.AMLH_SUSPECT_DATE_STAMP__C
	                AND infl_data.INTERACTIONTYPE_BIZIBLE_TOUCHPOINT_CALLSPOKEWITH_COUNT > 0 THEN 1
	                ELSE 0
	            END AS FLAG_ACTSUSPECT_INFL_TOUCHPOINT_BY_INTERACTIONTYPE_BIZIBLE_TOUCHPOINT_CALLSPOKEIWTH,
	            CASE
	                WHEN infl_data.MARKETING_TOUCHPOINT_DATE <= amlh_opp.AMLH_SUSPECT_DATE_STAMP__C
	                AND infl_data.INTERACTIONTYPE_BIZIBLE_TOUCHPOINT_CALLGATEKEEPER_COUNT > 0 THEN 1
	                ELSE 0
	            END AS FLAG_ACTSUSPECT_INFL_TOUCHPOINT_BY_INTERACTIONTYPE_BIZIBLE_TOUCHPOINT_GATEKEEPER,
	            CASE
	                WHEN infl_data.MARKETING_TOUCHPOINT_DATE <= amlh_opp.AMLH_SUSPECT_DATE_STAMP__C
	                AND infl_data.INTERACTIONTYPE_BIZIBLE_TOUCHPOINT_NOLEADTOUCHPOINTS_COUNT > 0 THEN 1
	                ELSE 0
	            END AS FLAG_ACTSUSPECT_INFL_TOUCHPOINT_BY_INTERACTIONTYPE_BIZIBLE_TOUCHPOINT_NOLEADTOUCHPOINT,
	            CASE
	                WHEN infl_data.MARKETING_TOUCHPOINT_DATE <= amlh_opp.AMLH_SUSPECT_DATE_STAMP__C
	                AND infl_data.INTERACTIONTYPE_BIZIBLE_TOUCHPOINT_UNCLASSIFIED_COUNT > 0 THEN 1
	                ELSE 0
	            END AS FLAG_ACTSUSPECT_INFL_TOUCHPOINT_BY_INTERACTIONTYPE_BIZIBLE_TOUCHPOINT_UNCLASSIFIED,
	            -- Influenced before Act Prospect
	            CASE
	                WHEN infl_data.MARKETING_TOUCHPOINT_DATE <= amlh_opp.AMLH_PROSPECT_DATE_STAMP__C
	                AND infl_data.INTERACTIONTYPE_SIXSENSE_PAIDMEDIA_IMPRESSIONS_COUNT > 0 THEN 1
	                ELSE 0
	            END AS FLAG_ACTPROSPECT_INFL_TOUCHPOINT_BY_INTERACTIONTYPE_SIXSENSE_PAIDMEDIA_IMPRESSION,
	            CASE
	                WHEN infl_data.MARKETING_TOUCHPOINT_DATE <= amlh_opp.AMLH_PROSPECT_DATE_STAMP__C
	                AND infl_data.INTERACTIONTYPE_SIXSENSE_PAIDMEDIA_CLICKS_COUNT > 0 THEN 1
	                ELSE 0
	            END AS FLAG_ACTPROSPECT_INFL_TOUCHPOINT_BY_INTERACTIONTYPE_SIXSENSE_PAIDMEDIA_CLICK,
	            CASE
	                WHEN infl_data.MARKETING_TOUCHPOINT_DATE <= amlh_opp.AMLH_PROSPECT_DATE_STAMP__C
	                AND infl_data.INTERACTIONTYPE_SIXSENSE_WEBVISIT_TOTAL_INTERACTIONS_COUNT > 0 THEN 1
	                ELSE 0
	            END AS FLAG_ACTPROSPECT_INFL_TOUCHPOINT_BY_INTERACTIONTYPE_SIXSENSE_WEBVISIT_TOTAL_INTERACTIONS,
	            CASE
	                WHEN infl_data.MARKETING_TOUCHPOINT_DATE <= amlh_opp.AMLH_PROSPECT_DATE_STAMP__C
	                AND infl_data.INTERACTIONTYPE_SIXSENSE_WEBVISIT_PAGELOAD_COUNT > 0 THEN 1
	                ELSE 0
	            END AS FLAG_ACTPROSPECT_INFL_TOUCHPOINT_BY_INTERACTIONTYPE_SIXSENSE_WEBVISIT_PAGELOAD,
	            CASE
	                WHEN infl_data.MARKETING_TOUCHPOINT_DATE <= amlh_opp.AMLH_PROSPECT_DATE_STAMP__C
	                AND infl_data.INTERACTIONTYPE_SIXSENSE_WEBVISIT_PLAY_COUNT > 0 THEN 1
	                ELSE 0
	            END AS FLAG_ACTPROSPECT_INFL_TOUCHPOINT_BY_INTERACTIONTYPE_SIXSENSE_WEBVISIT_PLAY,
	            CASE
	                WHEN infl_data.MARKETING_TOUCHPOINT_DATE <= amlh_opp.AMLH_PROSPECT_DATE_STAMP__C
	                AND infl_data.INTERACTIONTYPE_SIXSENSE_WEBVISIT_CLICK_COUNT > 0 THEN 1
	                ELSE 0
	            END AS FLAG_ACTPROSPECT_INFL_TOUCHPOINT_BY_INTERACTIONTYPE_SIXSENSE_WEBVISIT_CLICK,
	            CASE
	                WHEN infl_data.MARKETING_TOUCHPOINT_DATE <= amlh_opp.AMLH_PROSPECT_DATE_STAMP__C
	                AND infl_data.INTERACTIONTYPE_SIXSENSE_WEBVISIT_SUBMIT_COUNT > 0 THEN 1
	                ELSE 0
	            END AS FLAG_ACTPROSPECT_INFL_TOUCHPOINT_BY_INTERACTIONTYPE_SIXSENSE_WEBVISIT_SUBMIT,
	            CASE
	                WHEN infl_data.MARKETING_TOUCHPOINT_DATE <= amlh_opp.AMLH_PROSPECT_DATE_STAMP__C
	                AND infl_data.INTERACTIONTYPE_SIXSENSE_WEBVISIT_UNCLASSIFIED_COUNT > 0 THEN 1
	                ELSE 0
	            END AS FLAG_ACTPROSPECT_INFL_TOUCHPOINT_BY_INTERACTIONTYPE_SIXSENSE_WEBVISIT_UNCLASSIFIED,
	            CASE
	                WHEN infl_data.MARKETING_TOUCHPOINT_DATE <= amlh_opp.AMLH_PROSPECT_DATE_STAMP__C
	                AND infl_data.INTERACTIONTYPE_BIZIBLE_TOUCHPOINT_WEBVISIT_COUNT > 0 THEN 1
	                ELSE 0
	            END AS FLAG_ACTPROSPECT_INFL_TOUCHPOINT_BY_INTERACTIONTYPE_BIZIBLE_TOUCHPOINT_WEBVISIT,
	            CASE
	                WHEN infl_data.MARKETING_TOUCHPOINT_DATE <= amlh_opp.AMLH_PROSPECT_DATE_STAMP__C
	                AND infl_data.INTERACTIONTYPE_BIZIBLE_TOUCHPOINT_WEBCHAT_COUNT > 0 THEN 1
	                ELSE 0
	            END AS FLAG_ACTPROSPECT_INFL_TOUCHPOINT_BY_INTERACTIONTYPE_BIZIBLE_TOUCHPOINT_WEBCHAT,
	            CASE
	                WHEN infl_data.MARKETING_TOUCHPOINT_DATE <= amlh_opp.AMLH_PROSPECT_DATE_STAMP__C
	                AND infl_data.INTERACTIONTYPE_BIZIBLE_TOUCHPOINT_WEBFORM_COUNT > 0 THEN 1
	                ELSE 0
	            END AS FLAG_ACTPROSPECT_INFL_TOUCHPOINT_BY_INTERACTIONTYPE_BIZIBLE_TOUCHPOINT_WEBFORM,
	            CASE
	                WHEN infl_data.MARKETING_TOUCHPOINT_DATE <= amlh_opp.AMLH_PROSPECT_DATE_STAMP__C
	                AND infl_data.INTERACTIONTYPE_BIZIBLE_TOUCHPOINT_CRM_COUNT > 0 THEN 1
	                ELSE 0
	            END AS FLAG_ACTPROSPECT_INFL_TOUCHPOINT_BY_INTERACTIONTYPE_BIZIBLE_TOUCHPOINT_CRM,
	            CASE
	                WHEN infl_data.MARKETING_TOUCHPOINT_DATE <= amlh_opp.AMLH_PROSPECT_DATE_STAMP__C
	                AND infl_data.INTERACTIONTYPE_BIZIBLE_TOUCHPOINT_CONNECTWITHDM_COUNT > 0 THEN 1
	                ELSE 0
	            END AS FLAG_ACTPROSPECT_INFL_TOUCHPOINT_BY_INTERACTIONTYPE_BIZIBLE_TOUCHPOINT_CONNECTWITHDM,
	            CASE
	                WHEN infl_data.MARKETING_TOUCHPOINT_DATE <= amlh_opp.AMLH_PROSPECT_DATE_STAMP__C
	                AND infl_data.INTERACTIONTYPE_BIZIBLE_TOUCHPOINT_CALLSPOKEWITH_COUNT > 0 THEN 1
	                ELSE 0
	            END AS FLAG_ACTPROSPECT_INFL_TOUCHPOINT_BY_INTERACTIONTYPE_BIZIBLE_TOUCHPOINT_CALLSPOKEIWTH,
	            CASE
	                WHEN infl_data.MARKETING_TOUCHPOINT_DATE <= amlh_opp.AMLH_PROSPECT_DATE_STAMP__C
	                AND infl_data.INTERACTIONTYPE_BIZIBLE_TOUCHPOINT_CALLGATEKEEPER_COUNT > 0 THEN 1
	                ELSE 0
	            END AS FLAG_ACTPROSPECT_INFL_TOUCHPOINT_BY_INTERACTIONTYPE_BIZIBLE_TOUCHPOINT_GATEKEEPER,
	            CASE
	                WHEN infl_data.MARKETING_TOUCHPOINT_DATE <= amlh_opp.AMLH_PROSPECT_DATE_STAMP__C
	                AND infl_data.INTERACTIONTYPE_BIZIBLE_TOUCHPOINT_NOLEADTOUCHPOINTS_COUNT > 0 THEN 1
	                ELSE 0
	            END AS FLAG_ACTPROSPECT_INFL_TOUCHPOINT_BY_INTERACTIONTYPE_BIZIBLE_TOUCHPOINT_NOLEADTOUCHPOINT,
	            CASE
	                WHEN infl_data.MARKETING_TOUCHPOINT_DATE <= amlh_opp.AMLH_PROSPECT_DATE_STAMP__C
	                AND infl_data.INTERACTIONTYPE_BIZIBLE_TOUCHPOINT_UNCLASSIFIED_COUNT > 0 THEN 1
	                ELSE 0
	            END AS FLAG_ACTPROSPECT_INFL_TOUCHPOINT_BY_INTERACTIONTYPE_BIZIBLE_TOUCHPOINT_UNCLASSIFIED,
	            -- SUM COUNTS INFLUENCE
	            -- Influenced Before Opp Created
	            CASE
	                WHEN infl_data.MARKETING_TOUCHPOINT_DATE <= amlh_opp.OPP_CREATED_DATE
	                AND infl_data.INTERACTIONTYPE_SIXSENSE_PAIDMEDIA_IMPRESSIONS_COUNT > 0 THEN infl_data.INTERACTIONTYPE_SIXSENSE_PAIDMEDIA_IMPRESSIONS_COUNT
	                ELSE 0
	            END AS INTERACTIONTYPE_SIXSENSE_PAIDMEDIA_IMPRESSIONS_COUNT_INFLUENCE_OPPCRT,
	            CASE
	                WHEN infl_data.MARKETING_TOUCHPOINT_DATE <= amlh_opp.OPP_CREATED_DATE
	                AND infl_data.INTERACTIONTYPE_SIXSENSE_PAIDMEDIA_CLICKS_COUNT > 0 THEN infl_data.INTERACTIONTYPE_SIXSENSE_PAIDMEDIA_CLICKS_COUNT
	                ELSE 0
	            END AS INTERACTIONTYPE_SIXSENSE_PAIDMEDIA_CLICKS_COUNT_INFLUENCE_OPPCRT,
	            CASE
	                WHEN infl_data.MARKETING_TOUCHPOINT_DATE <= amlh_opp.OPP_CREATED_DATE
	                AND infl_data.INTERACTIONTYPE_SIXSENSE_WEBVISIT_TOTAL_INTERACTIONS_COUNT > 0 THEN infl_data.INTERACTIONTYPE_SIXSENSE_WEBVISIT_TOTAL_INTERACTIONS_COUNT
	                ELSE 0
	            END AS INTERACTIONTYPE_SIXSENSE_WEBVISIT_TOTAL_INTERACTIONS_COUNT_INFLUENCE_OPPCRT,
	            CASE
	                WHEN infl_data.MARKETING_TOUCHPOINT_DATE <= amlh_opp.OPP_CREATED_DATE
	                AND infl_data.INTERACTIONTYPE_SIXSENSE_WEBVISIT_PAGELOAD_COUNT > 0 THEN infl_data.INTERACTIONTYPE_SIXSENSE_WEBVISIT_PAGELOAD_COUNT
	                ELSE 0
	            END AS INTERACTIONTYPE_SIXSENSE_WEBVISIT_PAGELOAD_COUNT_INFLUENCE_OPPCRT,
	            CASE
	                WHEN infl_data.MARKETING_TOUCHPOINT_DATE <= amlh_opp.OPP_CREATED_DATE
	                AND infl_data.INTERACTIONTYPE_SIXSENSE_WEBVISIT_PLAY_COUNT > 0 THEN infl_data.INTERACTIONTYPE_SIXSENSE_WEBVISIT_PLAY_COUNT
	                ELSE 0
	            END AS INTERACTIONTYPE_SIXSENSE_WEBVISIT_PLAY_COUNT_INFLUENCE_OPPCRT,
	            CASE
	                WHEN infl_data.MARKETING_TOUCHPOINT_DATE <= amlh_opp.OPP_CREATED_DATE
	                AND infl_data.INTERACTIONTYPE_SIXSENSE_WEBVISIT_CLICK_COUNT > 0 THEN infl_data.INTERACTIONTYPE_SIXSENSE_WEBVISIT_CLICK_COUNT
	                ELSE 0
	            END AS INTERACTIONTYPE_SIXSENSE_WEBVISIT_CLICK_COUNT_INFLUENCE_OPPCRT,
	            CASE
	                WHEN infl_data.MARKETING_TOUCHPOINT_DATE <= amlh_opp.OPP_CREATED_DATE
	                AND infl_data.INTERACTIONTYPE_SIXSENSE_WEBVISIT_SUBMIT_COUNT > 0 THEN infl_data.INTERACTIONTYPE_SIXSENSE_WEBVISIT_SUBMIT_COUNT
	                ELSE 0
	            END AS INTERACTIONTYPE_SIXSENSE_WEBVISIT_SUBMIT_COUNT_INFLUENCE_OPPCRT,
	            CASE
	                WHEN infl_data.MARKETING_TOUCHPOINT_DATE <= amlh_opp.OPP_CREATED_DATE
	                AND infl_data.INTERACTIONTYPE_SIXSENSE_WEBVISIT_UNCLASSIFIED_COUNT > 0 THEN infl_data.INTERACTIONTYPE_SIXSENSE_WEBVISIT_UNCLASSIFIED_COUNT
	                ELSE 0
	            END AS INTERACTIONTYPE_SIXSENSE_WEBVISIT_UNCLASSIFIED_COUNT_INFLUENCE_OPPCRT,
	            CASE
	                WHEN infl_data.MARKETING_TOUCHPOINT_DATE <= amlh_opp.OPP_CREATED_DATE
	                AND infl_data.INTERACTIONTYPE_BIZIBLE_TOUCHPOINT_WEBVISIT_COUNT > 0 THEN infl_data.INTERACTIONTYPE_BIZIBLE_TOUCHPOINT_WEBVISIT_COUNT
	                ELSE 0
	            END AS INTERACTIONTYPE_BIZIBLE_TOUCHPOINT_WEBVISIT_COUNT_INFLUENCE_OPPCRT,
	            CASE
	                WHEN infl_data.MARKETING_TOUCHPOINT_DATE <= amlh_opp.OPP_CREATED_DATE
	                AND infl_data.INTERACTIONTYPE_BIZIBLE_TOUCHPOINT_WEBCHAT_COUNT > 0 THEN infl_data.INTERACTIONTYPE_BIZIBLE_TOUCHPOINT_WEBCHAT_COUNT
	                ELSE 0
	            END AS INTERACTIONTYPE_BIZIBLE_TOUCHPOINT_WEBCHAT_COUNT_INFLUENCE_OPPCRT,
	            CASE
	                WHEN infl_data.MARKETING_TOUCHPOINT_DATE <= amlh_opp.OPP_CREATED_DATE
	                AND infl_data.INTERACTIONTYPE_BIZIBLE_TOUCHPOINT_WEBFORM_COUNT > 0 THEN infl_data.INTERACTIONTYPE_BIZIBLE_TOUCHPOINT_WEBFORM_COUNT
	                ELSE 0
	            END AS INTERACTIONTYPE_BIZIBLE_TOUCHPOINT_WEBFORM_COUNT_INFLUENCE_OPPCRT,
	            CASE
	                WHEN infl_data.MARKETING_TOUCHPOINT_DATE <= amlh_opp.OPP_CREATED_DATE
	                AND infl_data.INTERACTIONTYPE_BIZIBLE_TOUCHPOINT_CRM_COUNT > 0 THEN infl_data.INTERACTIONTYPE_BIZIBLE_TOUCHPOINT_CRM_COUNT
	                ELSE 0
	            END AS INTERACTIONTYPE_BIZIBLE_TOUCHPOINT_CRM_COUNT_INFLUENCE_OPPCRT,
	            CASE
	                WHEN infl_data.MARKETING_TOUCHPOINT_DATE <= amlh_opp.OPP_CREATED_DATE
	                AND infl_data.INTERACTIONTYPE_BIZIBLE_TOUCHPOINT_CONNECTWITHDM_COUNT > 0 THEN infl_data.INTERACTIONTYPE_BIZIBLE_TOUCHPOINT_CONNECTWITHDM_COUNT
	                ELSE 0
	            END AS INTERACTIONTYPE_BIZIBLE_TOUCHPOINT_CONNECTWITHDM_COUNT_INFLUENCE_OPPCRT,
	            CASE
	                WHEN infl_data.MARKETING_TOUCHPOINT_DATE <= amlh_opp.OPP_CREATED_DATE
	                AND infl_data.INTERACTIONTYPE_BIZIBLE_TOUCHPOINT_CALLSPOKEWITH_COUNT > 0 THEN infl_data.INTERACTIONTYPE_BIZIBLE_TOUCHPOINT_CALLSPOKEWITH_COUNT
	                ELSE 0
	            END AS INTERACTIONTYPE_BIZIBLE_TOUCHPOINT_CALLSPOKEWITH_COUNT_INFLUENCE_OPPCRT,
	            CASE
	                WHEN infl_data.MARKETING_TOUCHPOINT_DATE <= amlh_opp.OPP_CREATED_DATE
	                AND infl_data.INTERACTIONTYPE_BIZIBLE_TOUCHPOINT_CALLGATEKEEPER_COUNT > 0 THEN infl_data.INTERACTIONTYPE_BIZIBLE_TOUCHPOINT_CALLGATEKEEPER_COUNT
	                ELSE 0
	            END AS INTERACTIONTYPE_BIZIBLE_TOUCHPOINT_CALLGATEKEEPER_COUNT_INFLUENCE_OPPCRT,
	            CASE
	                WHEN infl_data.MARKETING_TOUCHPOINT_DATE <= amlh_opp.OPP_CREATED_DATE
	                AND infl_data.INTERACTIONTYPE_BIZIBLE_TOUCHPOINT_NOLEADTOUCHPOINTS_COUNT > 0 THEN infl_data.INTERACTIONTYPE_BIZIBLE_TOUCHPOINT_NOLEADTOUCHPOINTS_COUNT
	                ELSE 0
	            END AS INTERACTIONTYPE_BIZIBLE_TOUCHPOINT_NOLEADTOUCHPOINTS_COUNT_INFLUENCE_OPPCRT,
	            CASE
	                WHEN infl_data.MARKETING_TOUCHPOINT_DATE <= amlh_opp.OPP_CREATED_DATE
	                AND infl_data.INTERACTIONTYPE_BIZIBLE_TOUCHPOINT_UNCLASSIFIED_COUNT > 0 THEN infl_data.INTERACTIONTYPE_BIZIBLE_TOUCHPOINT_UNCLASSIFIED_COUNT
	                ELSE 0
	            END AS INTERACTIONTYPE_BIZIBLE_TOUCHPOINT_UNCLASSIFIED_COUNT_INFLUENCE_OPPCRT,
	            -- SUM COUNTS INFLUENCE
	            -- Influenced Before Opp Closed
	            CASE
	                WHEN infl_data.MARKETING_TOUCHPOINT_DATE <= amlh_opp.OPP_CLOSE_DATE
	                AND infl_data.INTERACTIONTYPE_SIXSENSE_PAIDMEDIA_IMPRESSIONS_COUNT > 0 THEN infl_data.INTERACTIONTYPE_SIXSENSE_PAIDMEDIA_IMPRESSIONS_COUNT
	                ELSE 0
	            END AS INTERACTIONTYPE_SIXSENSE_PAIDMEDIA_IMPRESSIONS_COUNT_INFLUENCE_OPPCLS,
	            CASE
	                WHEN infl_data.MARKETING_TOUCHPOINT_DATE <= amlh_opp.OPP_CLOSE_DATE
	                AND infl_data.INTERACTIONTYPE_SIXSENSE_PAIDMEDIA_CLICKS_COUNT > 0 THEN infl_data.INTERACTIONTYPE_SIXSENSE_PAIDMEDIA_CLICKS_COUNT
	                ELSE 0
	            END AS INTERACTIONTYPE_SIXSENSE_PAIDMEDIA_CLICKS_COUNT_INFLUENCE_OPPCLS,
	            CASE
	                WHEN infl_data.MARKETING_TOUCHPOINT_DATE <= amlh_opp.OPP_CLOSE_DATE
	                AND infl_data.INTERACTIONTYPE_SIXSENSE_WEBVISIT_TOTAL_INTERACTIONS_COUNT > 0 THEN infl_data.INTERACTIONTYPE_SIXSENSE_WEBVISIT_TOTAL_INTERACTIONS_COUNT
	                ELSE 0
	            END AS INTERACTIONTYPE_SIXSENSE_WEBVISIT_TOTAL_INTERACTIONS_COUNT_INFLUENCE_OPPCLS,
	            CASE
	                WHEN infl_data.MARKETING_TOUCHPOINT_DATE <= amlh_opp.OPP_CLOSE_DATE
	                AND infl_data.INTERACTIONTYPE_SIXSENSE_WEBVISIT_PAGELOAD_COUNT > 0 THEN infl_data.INTERACTIONTYPE_SIXSENSE_WEBVISIT_PAGELOAD_COUNT
	                ELSE 0
	            END AS INTERACTIONTYPE_SIXSENSE_WEBVISIT_PAGELOAD_COUNT_INFLUENCE_OPPCLS,
	            CASE
	                WHEN infl_data.MARKETING_TOUCHPOINT_DATE <= amlh_opp.OPP_CLOSE_DATE
	                AND infl_data.INTERACTIONTYPE_SIXSENSE_WEBVISIT_PLAY_COUNT > 0 THEN infl_data.INTERACTIONTYPE_SIXSENSE_WEBVISIT_PLAY_COUNT
	                ELSE 0
	            END AS INTERACTIONTYPE_SIXSENSE_WEBVISIT_PLAY_COUNT_INFLUENCE_OPPCLS,
	            CASE
	                WHEN infl_data.MARKETING_TOUCHPOINT_DATE <= amlh_opp.OPP_CLOSE_DATE
	                AND infl_data.INTERACTIONTYPE_SIXSENSE_WEBVISIT_CLICK_COUNT > 0 THEN infl_data.INTERACTIONTYPE_SIXSENSE_WEBVISIT_CLICK_COUNT
	                ELSE 0
	            END AS INTERACTIONTYPE_SIXSENSE_WEBVISIT_CLICK_COUNT_INFLUENCE_OPPCLS,
	            CASE
	                WHEN infl_data.MARKETING_TOUCHPOINT_DATE <= amlh_opp.OPP_CLOSE_DATE
	                AND infl_data.INTERACTIONTYPE_SIXSENSE_WEBVISIT_SUBMIT_COUNT > 0 THEN infl_data.INTERACTIONTYPE_SIXSENSE_WEBVISIT_SUBMIT_COUNT
	                ELSE 0
	            END AS INTERACTIONTYPE_SIXSENSE_WEBVISIT_SUBMIT_COUNT_INFLUENCE_OPPCLS,
	            CASE
	                WHEN infl_data.MARKETING_TOUCHPOINT_DATE <= amlh_opp.OPP_CLOSE_DATE
	                AND infl_data.INTERACTIONTYPE_SIXSENSE_WEBVISIT_UNCLASSIFIED_COUNT > 0 THEN infl_data.INTERACTIONTYPE_SIXSENSE_WEBVISIT_UNCLASSIFIED_COUNT
	                ELSE 0
	            END AS INTERACTIONTYPE_SIXSENSE_WEBVISIT_UNCLASSIFIED_COUNT_INFLUENCE_OPPCLS,
	            CASE
	                WHEN infl_data.MARKETING_TOUCHPOINT_DATE <= amlh_opp.OPP_CLOSE_DATE
	                AND infl_data.INTERACTIONTYPE_BIZIBLE_TOUCHPOINT_WEBVISIT_COUNT > 0 THEN infl_data.INTERACTIONTYPE_BIZIBLE_TOUCHPOINT_WEBVISIT_COUNT
	                ELSE 0
	            END AS INTERACTIONTYPE_BIZIBLE_TOUCHPOINT_WEBVISIT_COUNT_INFLUENCE_OPPCLS,
	            CASE
	                WHEN infl_data.MARKETING_TOUCHPOINT_DATE <= amlh_opp.OPP_CLOSE_DATE
	                AND infl_data.INTERACTIONTYPE_BIZIBLE_TOUCHPOINT_WEBCHAT_COUNT > 0 THEN infl_data.INTERACTIONTYPE_BIZIBLE_TOUCHPOINT_WEBCHAT_COUNT
	                ELSE 0
	            END AS INTERACTIONTYPE_BIZIBLE_TOUCHPOINT_WEBCHAT_COUNT_INFLUENCE_OPPCLS,
	            CASE
	                WHEN infl_data.MARKETING_TOUCHPOINT_DATE <= amlh_opp.OPP_CLOSE_DATE
	                AND infl_data.INTERACTIONTYPE_BIZIBLE_TOUCHPOINT_WEBFORM_COUNT > 0 THEN infl_data.INTERACTIONTYPE_BIZIBLE_TOUCHPOINT_WEBFORM_COUNT
	                ELSE 0
	            END AS INTERACTIONTYPE_BIZIBLE_TOUCHPOINT_WEBFORM_COUNT_INFLUENCE_OPPCLS,
	            CASE
	                WHEN infl_data.MARKETING_TOUCHPOINT_DATE <= amlh_opp.OPP_CLOSE_DATE
	                AND infl_data.INTERACTIONTYPE_BIZIBLE_TOUCHPOINT_CRM_COUNT > 0 THEN infl_data.INTERACTIONTYPE_BIZIBLE_TOUCHPOINT_CRM_COUNT
	                ELSE 0
	            END AS INTERACTIONTYPE_BIZIBLE_TOUCHPOINT_CRM_COUNT_INFLUENCE_OPPCLS,
	            CASE
	                WHEN infl_data.MARKETING_TOUCHPOINT_DATE <= amlh_opp.OPP_CLOSE_DATE
	                AND infl_data.INTERACTIONTYPE_BIZIBLE_TOUCHPOINT_CONNECTWITHDM_COUNT > 0 THEN infl_data.INTERACTIONTYPE_BIZIBLE_TOUCHPOINT_CONNECTWITHDM_COUNT
	                ELSE 0
	            END AS INTERACTIONTYPE_BIZIBLE_TOUCHPOINT_CONNECTWITHDM_COUNT_INFLUENCE_OPPCLS,
	            CASE
	                WHEN infl_data.MARKETING_TOUCHPOINT_DATE <= amlh_opp.OPP_CLOSE_DATE
	                AND infl_data.INTERACTIONTYPE_BIZIBLE_TOUCHPOINT_CALLSPOKEWITH_COUNT > 0 THEN infl_data.INTERACTIONTYPE_BIZIBLE_TOUCHPOINT_CALLSPOKEWITH_COUNT
	                ELSE 0
	            END AS INTERACTIONTYPE_BIZIBLE_TOUCHPOINT_CALLSPOKEWITH_COUNT_INFLUENCE_OPPCLS,
	            CASE
	                WHEN infl_data.MARKETING_TOUCHPOINT_DATE <= amlh_opp.OPP_CLOSE_DATE
	                AND infl_data.INTERACTIONTYPE_BIZIBLE_TOUCHPOINT_CALLGATEKEEPER_COUNT > 0 THEN infl_data.INTERACTIONTYPE_BIZIBLE_TOUCHPOINT_CALLGATEKEEPER_COUNT
	                ELSE 0
	            END AS INTERACTIONTYPE_BIZIBLE_TOUCHPOINT_CALLGATEKEEPER_COUNT_INFLUENCE_OPPCLS,
	            CASE
	                WHEN infl_data.MARKETING_TOUCHPOINT_DATE <= amlh_opp.OPP_CLOSE_DATE
	                AND infl_data.INTERACTIONTYPE_BIZIBLE_TOUCHPOINT_NOLEADTOUCHPOINTS_COUNT > 0 THEN infl_data.INTERACTIONTYPE_BIZIBLE_TOUCHPOINT_NOLEADTOUCHPOINTS_COUNT
	                ELSE 0
	            END AS INTERACTIONTYPE_BIZIBLE_TOUCHPOINT_NOLEADTOUCHPOINTS_COUNT_INFLUENCE_OPPCLS,
	            CASE
	                WHEN infl_data.MARKETING_TOUCHPOINT_DATE <= amlh_opp.OPP_CLOSE_DATE
	                AND infl_data.INTERACTIONTYPE_BIZIBLE_TOUCHPOINT_UNCLASSIFIED_COUNT > 0 THEN infl_data.INTERACTIONTYPE_BIZIBLE_TOUCHPOINT_UNCLASSIFIED_COUNT
	                ELSE 0
	            END AS INTERACTIONTYPE_BIZIBLE_TOUCHPOINT_UNCLASSIFIED_COUNT_INFLUENCE_OPPCLS,
	            -- SUM COUNTS INFLUENCE
	            -- Influenced Before Account Cold
	            CASE
	                WHEN infl_data.MARKETING_TOUCHPOINT_DATE <= amlh_opp.AMLH_COLD_ACCOUNT_DATE_STAMP__C
	                AND infl_data.INTERACTIONTYPE_SIXSENSE_PAIDMEDIA_IMPRESSIONS_COUNT > 0 THEN infl_data.INTERACTIONTYPE_SIXSENSE_PAIDMEDIA_IMPRESSIONS_COUNT
	                ELSE 0
	            END AS INTERACTIONTYPE_SIXSENSE_PAIDMEDIA_IMPRESSIONS_COUNT_INFLUENCE_ACTCOLD,
	            CASE
	                WHEN infl_data.MARKETING_TOUCHPOINT_DATE <= amlh_opp.AMLH_COLD_ACCOUNT_DATE_STAMP__C
	                AND infl_data.INTERACTIONTYPE_SIXSENSE_PAIDMEDIA_CLICKS_COUNT > 0 THEN infl_data.INTERACTIONTYPE_SIXSENSE_PAIDMEDIA_CLICKS_COUNT
	                ELSE 0
	            END AS INTERACTIONTYPE_SIXSENSE_PAIDMEDIA_CLICKS_COUNT_INFLUENCE_ACTCOLD,
	            CASE
	                WHEN infl_data.MARKETING_TOUCHPOINT_DATE <= amlh_opp.AMLH_COLD_ACCOUNT_DATE_STAMP__C
	                AND infl_data.INTERACTIONTYPE_SIXSENSE_WEBVISIT_TOTAL_INTERACTIONS_COUNT > 0 THEN infl_data.INTERACTIONTYPE_SIXSENSE_WEBVISIT_TOTAL_INTERACTIONS_COUNT
	                ELSE 0
	            END AS INTERACTIONTYPE_SIXSENSE_WEBVISIT_TOTAL_INTERACTIONS_COUNT_INFLUENCE_ACTCOLD,
	            CASE
	                WHEN infl_data.MARKETING_TOUCHPOINT_DATE <= amlh_opp.AMLH_COLD_ACCOUNT_DATE_STAMP__C
	                AND infl_data.INTERACTIONTYPE_SIXSENSE_WEBVISIT_PAGELOAD_COUNT > 0 THEN infl_data.INTERACTIONTYPE_SIXSENSE_WEBVISIT_PAGELOAD_COUNT
	                ELSE 0
	            END AS INTERACTIONTYPE_SIXSENSE_WEBVISIT_PAGELOAD_COUNT_INFLUENCE_ACTCOLD,
	            CASE
	                WHEN infl_data.MARKETING_TOUCHPOINT_DATE <= amlh_opp.AMLH_COLD_ACCOUNT_DATE_STAMP__C
	                AND infl_data.INTERACTIONTYPE_SIXSENSE_WEBVISIT_PLAY_COUNT > 0 THEN infl_data.INTERACTIONTYPE_SIXSENSE_WEBVISIT_PLAY_COUNT
	                ELSE 0
	            END AS INTERACTIONTYPE_SIXSENSE_WEBVISIT_PLAY_COUNT_INFLUENCE_ACTCOLD,
	            CASE
	                WHEN infl_data.MARKETING_TOUCHPOINT_DATE <= amlh_opp.AMLH_COLD_ACCOUNT_DATE_STAMP__C
	                AND infl_data.INTERACTIONTYPE_SIXSENSE_WEBVISIT_CLICK_COUNT > 0 THEN infl_data.INTERACTIONTYPE_SIXSENSE_WEBVISIT_CLICK_COUNT
	                ELSE 0
	            END AS INTERACTIONTYPE_SIXSENSE_WEBVISIT_CLICK_COUNT_INFLUENCE_ACTCOLD,
	            CASE
	                WHEN infl_data.MARKETING_TOUCHPOINT_DATE <= amlh_opp.AMLH_COLD_ACCOUNT_DATE_STAMP__C
	                AND infl_data.INTERACTIONTYPE_SIXSENSE_WEBVISIT_SUBMIT_COUNT > 0 THEN infl_data.INTERACTIONTYPE_SIXSENSE_WEBVISIT_SUBMIT_COUNT
	                ELSE 0
	            END AS INTERACTIONTYPE_SIXSENSE_WEBVISIT_SUBMIT_COUNT_INFLUENCE_ACTCOLD,
	            CASE
	                WHEN infl_data.MARKETING_TOUCHPOINT_DATE <= amlh_opp.AMLH_COLD_ACCOUNT_DATE_STAMP__C
	                AND infl_data.INTERACTIONTYPE_SIXSENSE_WEBVISIT_UNCLASSIFIED_COUNT > 0 THEN infl_data.INTERACTIONTYPE_SIXSENSE_WEBVISIT_UNCLASSIFIED_COUNT
	                ELSE 0
	            END AS INTERACTIONTYPE_SIXSENSE_WEBVISIT_UNCLASSIFIED_COUNT_INFLUENCE_ACTCOLD,
	            CASE
	                WHEN infl_data.MARKETING_TOUCHPOINT_DATE <= amlh_opp.AMLH_COLD_ACCOUNT_DATE_STAMP__C
	                AND infl_data.INTERACTIONTYPE_BIZIBLE_TOUCHPOINT_WEBVISIT_COUNT > 0 THEN infl_data.INTERACTIONTYPE_BIZIBLE_TOUCHPOINT_WEBVISIT_COUNT
	                ELSE 0
	            END AS INTERACTIONTYPE_BIZIBLE_TOUCHPOINT_WEBVISIT_COUNT_INFLUENCE_ACTCOLD,
	            CASE
	                WHEN infl_data.MARKETING_TOUCHPOINT_DATE <= amlh_opp.AMLH_COLD_ACCOUNT_DATE_STAMP__C
	                AND infl_data.INTERACTIONTYPE_BIZIBLE_TOUCHPOINT_WEBCHAT_COUNT > 0 THEN infl_data.INTERACTIONTYPE_BIZIBLE_TOUCHPOINT_WEBCHAT_COUNT
	                ELSE 0
	            END AS INTERACTIONTYPE_BIZIBLE_TOUCHPOINT_WEBCHAT_COUNT_INFLUENCE_ACTCOLD,
	            CASE
	                WHEN infl_data.MARKETING_TOUCHPOINT_DATE <= amlh_opp.AMLH_COLD_ACCOUNT_DATE_STAMP__C
	                AND infl_data.INTERACTIONTYPE_BIZIBLE_TOUCHPOINT_WEBFORM_COUNT > 0 THEN infl_data.INTERACTIONTYPE_BIZIBLE_TOUCHPOINT_WEBFORM_COUNT
	                ELSE 0
	            END AS INTERACTIONTYPE_BIZIBLE_TOUCHPOINT_WEBFORM_COUNT_INFLUENCE_ACTCOLD,
	            CASE
	                WHEN infl_data.MARKETING_TOUCHPOINT_DATE <= amlh_opp.AMLH_COLD_ACCOUNT_DATE_STAMP__C
	                AND infl_data.INTERACTIONTYPE_BIZIBLE_TOUCHPOINT_CRM_COUNT > 0 THEN infl_data.INTERACTIONTYPE_BIZIBLE_TOUCHPOINT_CRM_COUNT
	                ELSE 0
	            END AS INTERACTIONTYPE_BIZIBLE_TOUCHPOINT_CRM_COUNT_INFLUENCE_ACTCOLD,
	            CASE
	                WHEN infl_data.MARKETING_TOUCHPOINT_DATE <= amlh_opp.AMLH_COLD_ACCOUNT_DATE_STAMP__C
	                AND infl_data.INTERACTIONTYPE_BIZIBLE_TOUCHPOINT_CONNECTWITHDM_COUNT > 0 THEN infl_data.INTERACTIONTYPE_BIZIBLE_TOUCHPOINT_CONNECTWITHDM_COUNT
	                ELSE 0
	            END AS INTERACTIONTYPE_BIZIBLE_TOUCHPOINT_CONNECTWITHDM_COUNT_INFLUENCE_ACTCOLD,
	            CASE
	                WHEN infl_data.MARKETING_TOUCHPOINT_DATE <= amlh_opp.AMLH_COLD_ACCOUNT_DATE_STAMP__C
	                AND infl_data.INTERACTIONTYPE_BIZIBLE_TOUCHPOINT_CALLSPOKEWITH_COUNT > 0 THEN infl_data.INTERACTIONTYPE_BIZIBLE_TOUCHPOINT_CALLSPOKEWITH_COUNT
	                ELSE 0
	            END AS INTERACTIONTYPE_BIZIBLE_TOUCHPOINT_CALLSPOKEWITH_COUNT_INFLUENCE_ACTCOLD,
	            CASE
	                WHEN infl_data.MARKETING_TOUCHPOINT_DATE <= amlh_opp.AMLH_COLD_ACCOUNT_DATE_STAMP__C
	                AND infl_data.INTERACTIONTYPE_BIZIBLE_TOUCHPOINT_CALLGATEKEEPER_COUNT > 0 THEN infl_data.INTERACTIONTYPE_BIZIBLE_TOUCHPOINT_CALLGATEKEEPER_COUNT
	                ELSE 0
	            END AS INTERACTIONTYPE_BIZIBLE_TOUCHPOINT_CALLGATEKEEPER_COUNT_INFLUENCE_ACTCOLD,
	            CASE
	                WHEN infl_data.MARKETING_TOUCHPOINT_DATE <= amlh_opp.AMLH_COLD_ACCOUNT_DATE_STAMP__C
	                AND infl_data.INTERACTIONTYPE_BIZIBLE_TOUCHPOINT_NOLEADTOUCHPOINTS_COUNT > 0 THEN infl_data.INTERACTIONTYPE_BIZIBLE_TOUCHPOINT_NOLEADTOUCHPOINTS_COUNT
	                ELSE 0
	            END AS INTERACTIONTYPE_BIZIBLE_TOUCHPOINT_NOLEADTOUCHPOINTS_COUNT_INFLUENCE_ACTCOLD,
	            CASE
	                WHEN infl_data.MARKETING_TOUCHPOINT_DATE <= amlh_opp.AMLH_COLD_ACCOUNT_DATE_STAMP__C
	                AND infl_data.INTERACTIONTYPE_BIZIBLE_TOUCHPOINT_UNCLASSIFIED_COUNT > 0 THEN infl_data.INTERACTIONTYPE_BIZIBLE_TOUCHPOINT_UNCLASSIFIED_COUNT
	                ELSE 0
	            END AS INTERACTIONTYPE_BIZIBLE_TOUCHPOINT_UNCLASSIFIED_COUNT_INFLUENCE_ACTCOLD,
	            -- SUM COUNTS INFLUENCE
	            -- Influenced Before Account MEA
	            CASE
	                WHEN infl_data.MARKETING_TOUCHPOINT_DATE <= amlh_opp.AMLH_MEA_DATE_STAMP__C
	                AND infl_data.INTERACTIONTYPE_SIXSENSE_PAIDMEDIA_IMPRESSIONS_COUNT > 0 THEN infl_data.INTERACTIONTYPE_SIXSENSE_PAIDMEDIA_IMPRESSIONS_COUNT
	                ELSE 0
	            END AS INTERACTIONTYPE_SIXSENSE_PAIDMEDIA_IMPRESSIONS_COUNT_INFLUENCE_ACTMEA,
	            CASE
	                WHEN infl_data.MARKETING_TOUCHPOINT_DATE <= amlh_opp.AMLH_MEA_DATE_STAMP__C
	                AND infl_data.INTERACTIONTYPE_SIXSENSE_PAIDMEDIA_CLICKS_COUNT > 0 THEN infl_data.INTERACTIONTYPE_SIXSENSE_PAIDMEDIA_CLICKS_COUNT
	                ELSE 0
	            END AS INTERACTIONTYPE_SIXSENSE_PAIDMEDIA_CLICKS_COUNT_INFLUENCE_ACTMEA,
	            CASE
	                WHEN infl_data.MARKETING_TOUCHPOINT_DATE <= amlh_opp.AMLH_MEA_DATE_STAMP__C
	                AND infl_data.INTERACTIONTYPE_SIXSENSE_WEBVISIT_TOTAL_INTERACTIONS_COUNT > 0 THEN infl_data.INTERACTIONTYPE_SIXSENSE_WEBVISIT_TOTAL_INTERACTIONS_COUNT
	                ELSE 0
	            END AS INTERACTIONTYPE_SIXSENSE_WEBVISIT_TOTAL_INTERACTIONS_COUNT_INFLUENCE_ACTMEA,
	            CASE
	                WHEN infl_data.MARKETING_TOUCHPOINT_DATE <= amlh_opp.AMLH_MEA_DATE_STAMP__C
	                AND infl_data.INTERACTIONTYPE_SIXSENSE_WEBVISIT_PAGELOAD_COUNT > 0 THEN infl_data.INTERACTIONTYPE_SIXSENSE_WEBVISIT_PAGELOAD_COUNT
	                ELSE 0
	            END AS INTERACTIONTYPE_SIXSENSE_WEBVISIT_PAGELOAD_COUNT_INFLUENCE_ACTMEA,
	            CASE
	                WHEN infl_data.MARKETING_TOUCHPOINT_DATE <= amlh_opp.AMLH_MEA_DATE_STAMP__C
	                AND infl_data.INTERACTIONTYPE_SIXSENSE_WEBVISIT_PLAY_COUNT > 0 THEN infl_data.INTERACTIONTYPE_SIXSENSE_WEBVISIT_PLAY_COUNT
	                ELSE 0
	            END AS INTERACTIONTYPE_SIXSENSE_WEBVISIT_PLAY_COUNT_INFLUENCE_ACTMEA,
	            CASE
	                WHEN infl_data.MARKETING_TOUCHPOINT_DATE <= amlh_opp.AMLH_MEA_DATE_STAMP__C
	                AND infl_data.INTERACTIONTYPE_SIXSENSE_WEBVISIT_CLICK_COUNT > 0 THEN infl_data.INTERACTIONTYPE_SIXSENSE_WEBVISIT_CLICK_COUNT
	                ELSE 0
	            END AS INTERACTIONTYPE_SIXSENSE_WEBVISIT_CLICK_COUNT_INFLUENCE_ACTMEA,
	            CASE
	                WHEN infl_data.MARKETING_TOUCHPOINT_DATE <= amlh_opp.AMLH_MEA_DATE_STAMP__C
	                AND infl_data.INTERACTIONTYPE_SIXSENSE_WEBVISIT_SUBMIT_COUNT > 0 THEN infl_data.INTERACTIONTYPE_SIXSENSE_WEBVISIT_SUBMIT_COUNT
	                ELSE 0
	            END AS INTERACTIONTYPE_SIXSENSE_WEBVISIT_SUBMIT_COUNT_INFLUENCE_ACTMEA,
	            CASE
	                WHEN infl_data.MARKETING_TOUCHPOINT_DATE <= amlh_opp.AMLH_MEA_DATE_STAMP__C
	                AND infl_data.INTERACTIONTYPE_SIXSENSE_WEBVISIT_UNCLASSIFIED_COUNT > 0 THEN infl_data.INTERACTIONTYPE_SIXSENSE_WEBVISIT_UNCLASSIFIED_COUNT
	                ELSE 0
	            END AS INTERACTIONTYPE_SIXSENSE_WEBVISIT_UNCLASSIFIED_COUNT_INFLUENCE_ACTMEA,
	            CASE
	                WHEN infl_data.MARKETING_TOUCHPOINT_DATE <= amlh_opp.AMLH_MEA_DATE_STAMP__C
	                AND infl_data.INTERACTIONTYPE_BIZIBLE_TOUCHPOINT_WEBVISIT_COUNT > 0 THEN infl_data.INTERACTIONTYPE_BIZIBLE_TOUCHPOINT_WEBVISIT_COUNT
	                ELSE 0
	            END AS INTERACTIONTYPE_BIZIBLE_TOUCHPOINT_WEBVISIT_COUNT_INFLUENCE_ACTMEA,
	            CASE
	                WHEN infl_data.MARKETING_TOUCHPOINT_DATE <= amlh_opp.AMLH_MEA_DATE_STAMP__C
	                AND infl_data.INTERACTIONTYPE_BIZIBLE_TOUCHPOINT_WEBCHAT_COUNT > 0 THEN infl_data.INTERACTIONTYPE_BIZIBLE_TOUCHPOINT_WEBCHAT_COUNT
	                ELSE 0
	            END AS INTERACTIONTYPE_BIZIBLE_TOUCHPOINT_WEBCHAT_COUNT_INFLUENCE_ACTMEA,
	            CASE
	                WHEN infl_data.MARKETING_TOUCHPOINT_DATE <= amlh_opp.AMLH_MEA_DATE_STAMP__C
	                AND infl_data.INTERACTIONTYPE_BIZIBLE_TOUCHPOINT_WEBFORM_COUNT > 0 THEN infl_data.INTERACTIONTYPE_BIZIBLE_TOUCHPOINT_WEBFORM_COUNT
	                ELSE 0
	            END AS INTERACTIONTYPE_BIZIBLE_TOUCHPOINT_WEBFORM_COUNT_INFLUENCE_ACTMEA,
	            CASE
	                WHEN infl_data.MARKETING_TOUCHPOINT_DATE <= amlh_opp.AMLH_MEA_DATE_STAMP__C
	                AND infl_data.INTERACTIONTYPE_BIZIBLE_TOUCHPOINT_CRM_COUNT > 0 THEN infl_data.INTERACTIONTYPE_BIZIBLE_TOUCHPOINT_CRM_COUNT
	                ELSE 0
	            END AS INTERACTIONTYPE_BIZIBLE_TOUCHPOINT_CRM_COUNT_INFLUENCE_ACTMEA,
	            CASE
	                WHEN infl_data.MARKETING_TOUCHPOINT_DATE <= amlh_opp.AMLH_MEA_DATE_STAMP__C
	                AND infl_data.INTERACTIONTYPE_BIZIBLE_TOUCHPOINT_CONNECTWITHDM_COUNT > 0 THEN infl_data.INTERACTIONTYPE_BIZIBLE_TOUCHPOINT_CONNECTWITHDM_COUNT
	                ELSE 0
	            END AS INTERACTIONTYPE_BIZIBLE_TOUCHPOINT_CONNECTWITHDM_COUNT_INFLUENCE_ACTMEA,
	            CASE
	                WHEN infl_data.MARKETING_TOUCHPOINT_DATE <= amlh_opp.AMLH_MEA_DATE_STAMP__C
	                AND infl_data.INTERACTIONTYPE_BIZIBLE_TOUCHPOINT_CALLSPOKEWITH_COUNT > 0 THEN infl_data.INTERACTIONTYPE_BIZIBLE_TOUCHPOINT_CALLSPOKEWITH_COUNT
	                ELSE 0
	            END AS INTERACTIONTYPE_BIZIBLE_TOUCHPOINT_CALLSPOKEWITH_COUNT_INFLUENCE_ACTMEA,
	            CASE
	                WHEN infl_data.MARKETING_TOUCHPOINT_DATE <= amlh_opp.AMLH_MEA_DATE_STAMP__C
	                AND infl_data.INTERACTIONTYPE_BIZIBLE_TOUCHPOINT_CALLGATEKEEPER_COUNT > 0 THEN infl_data.INTERACTIONTYPE_BIZIBLE_TOUCHPOINT_CALLGATEKEEPER_COUNT
	                ELSE 0
	            END AS INTERACTIONTYPE_BIZIBLE_TOUCHPOINT_CALLGATEKEEPER_COUNT_INFLUENCE_ACTMEA,
	            CASE
	                WHEN infl_data.MARKETING_TOUCHPOINT_DATE <= amlh_opp.AMLH_MEA_DATE_STAMP__C
	                AND infl_data.INTERACTIONTYPE_BIZIBLE_TOUCHPOINT_NOLEADTOUCHPOINTS_COUNT > 0 THEN infl_data.INTERACTIONTYPE_BIZIBLE_TOUCHPOINT_NOLEADTOUCHPOINTS_COUNT
	                ELSE 0
	            END AS INTERACTIONTYPE_BIZIBLE_TOUCHPOINT_NOLEADTOUCHPOINTS_COUNT_INFLUENCE_ACTMEA,
	            CASE
	                WHEN infl_data.MARKETING_TOUCHPOINT_DATE <= amlh_opp.AMLH_MEA_DATE_STAMP__C
	                AND infl_data.INTERACTIONTYPE_BIZIBLE_TOUCHPOINT_UNCLASSIFIED_COUNT > 0 THEN infl_data.INTERACTIONTYPE_BIZIBLE_TOUCHPOINT_UNCLASSIFIED_COUNT
	                ELSE 0
	            END AS INTERACTIONTYPE_BIZIBLE_TOUCHPOINT_UNCLASSIFIED_COUNT_INFLUENCE_ACTMEA,
	            -- SUM COUNTS INFLUENCE
	            -- Influenced Before Account MQA
	            CASE
	                WHEN infl_data.MARKETING_TOUCHPOINT_DATE <= amlh_opp.AMLH_MQA_DATE_STAMP__C
	                AND infl_data.INTERACTIONTYPE_SIXSENSE_PAIDMEDIA_IMPRESSIONS_COUNT > 0 THEN infl_data.INTERACTIONTYPE_SIXSENSE_PAIDMEDIA_IMPRESSIONS_COUNT
	                ELSE 0
	            END AS INTERACTIONTYPE_SIXSENSE_PAIDMEDIA_IMPRESSIONS_COUNT_INFLUENCE_ACTMQA,
	            CASE
	                WHEN infl_data.MARKETING_TOUCHPOINT_DATE <= amlh_opp.AMLH_MQA_DATE_STAMP__C
	                AND infl_data.INTERACTIONTYPE_SIXSENSE_PAIDMEDIA_CLICKS_COUNT > 0 THEN infl_data.INTERACTIONTYPE_SIXSENSE_PAIDMEDIA_CLICKS_COUNT
	                ELSE 0
	            END AS INTERACTIONTYPE_SIXSENSE_PAIDMEDIA_CLICKS_COUNT_INFLUENCE_ACTMQA,
	            CASE
	                WHEN infl_data.MARKETING_TOUCHPOINT_DATE <= amlh_opp.AMLH_MQA_DATE_STAMP__C
	                AND infl_data.INTERACTIONTYPE_SIXSENSE_WEBVISIT_TOTAL_INTERACTIONS_COUNT > 0 THEN infl_data.INTERACTIONTYPE_SIXSENSE_WEBVISIT_TOTAL_INTERACTIONS_COUNT
	                ELSE 0
	            END AS INTERACTIONTYPE_SIXSENSE_WEBVISIT_TOTAL_INTERACTIONS_COUNT_INFLUENCE_ACTMQA,
	            CASE
	                WHEN infl_data.MARKETING_TOUCHPOINT_DATE <= amlh_opp.AMLH_MQA_DATE_STAMP__C
	                AND infl_data.INTERACTIONTYPE_SIXSENSE_WEBVISIT_PAGELOAD_COUNT > 0 THEN infl_data.INTERACTIONTYPE_SIXSENSE_WEBVISIT_PAGELOAD_COUNT
	                ELSE 0
	            END AS INTERACTIONTYPE_SIXSENSE_WEBVISIT_PAGELOAD_COUNT_INFLUENCE_ACTMQA,
	            CASE
	                WHEN infl_data.MARKETING_TOUCHPOINT_DATE <= amlh_opp.AMLH_MQA_DATE_STAMP__C
	                AND infl_data.INTERACTIONTYPE_SIXSENSE_WEBVISIT_PLAY_COUNT > 0 THEN infl_data.INTERACTIONTYPE_SIXSENSE_WEBVISIT_PLAY_COUNT
	                ELSE 0
	            END AS INTERACTIONTYPE_SIXSENSE_WEBVISIT_PLAY_COUNT_INFLUENCE_ACTMQA,
	            CASE
	                WHEN infl_data.MARKETING_TOUCHPOINT_DATE <= amlh_opp.AMLH_MQA_DATE_STAMP__C
	                AND infl_data.INTERACTIONTYPE_SIXSENSE_WEBVISIT_CLICK_COUNT > 0 THEN infl_data.INTERACTIONTYPE_SIXSENSE_WEBVISIT_CLICK_COUNT
	                ELSE 0
	            END AS INTERACTIONTYPE_SIXSENSE_WEBVISIT_CLICK_COUNT_INFLUENCE_ACTMQA,
	            CASE
	                WHEN infl_data.MARKETING_TOUCHPOINT_DATE <= amlh_opp.AMLH_MQA_DATE_STAMP__C
	                AND infl_data.INTERACTIONTYPE_SIXSENSE_WEBVISIT_SUBMIT_COUNT > 0 THEN infl_data.INTERACTIONTYPE_SIXSENSE_WEBVISIT_SUBMIT_COUNT
	                ELSE 0
	            END AS INTERACTIONTYPE_SIXSENSE_WEBVISIT_SUBMIT_COUNT_INFLUENCE_ACTMQA,
	            CASE
	                WHEN infl_data.MARKETING_TOUCHPOINT_DATE <= amlh_opp.AMLH_MQA_DATE_STAMP__C
	                AND infl_data.INTERACTIONTYPE_SIXSENSE_WEBVISIT_UNCLASSIFIED_COUNT > 0 THEN infl_data.INTERACTIONTYPE_SIXSENSE_WEBVISIT_UNCLASSIFIED_COUNT
	                ELSE 0
	            END AS INTERACTIONTYPE_SIXSENSE_WEBVISIT_UNCLASSIFIED_COUNT_INFLUENCE_ACTMQA,
	            CASE
	                WHEN infl_data.MARKETING_TOUCHPOINT_DATE <= amlh_opp.AMLH_MQA_DATE_STAMP__C
	                AND infl_data.INTERACTIONTYPE_BIZIBLE_TOUCHPOINT_WEBVISIT_COUNT > 0 THEN infl_data.INTERACTIONTYPE_BIZIBLE_TOUCHPOINT_WEBVISIT_COUNT
	                ELSE 0
	            END AS INTERACTIONTYPE_BIZIBLE_TOUCHPOINT_WEBVISIT_COUNT_INFLUENCE_ACTMQA,
	            CASE
	                WHEN infl_data.MARKETING_TOUCHPOINT_DATE <= amlh_opp.AMLH_MQA_DATE_STAMP__C
	                AND infl_data.INTERACTIONTYPE_BIZIBLE_TOUCHPOINT_WEBCHAT_COUNT > 0 THEN infl_data.INTERACTIONTYPE_BIZIBLE_TOUCHPOINT_WEBCHAT_COUNT
	                ELSE 0
	            END AS INTERACTIONTYPE_BIZIBLE_TOUCHPOINT_WEBCHAT_COUNT_INFLUENCE_ACTMQA,
	            CASE
	                WHEN infl_data.MARKETING_TOUCHPOINT_DATE <= amlh_opp.AMLH_MQA_DATE_STAMP__C
	                AND infl_data.INTERACTIONTYPE_BIZIBLE_TOUCHPOINT_WEBFORM_COUNT > 0 THEN infl_data.INTERACTIONTYPE_BIZIBLE_TOUCHPOINT_WEBFORM_COUNT
	                ELSE 0
	            END AS INTERACTIONTYPE_BIZIBLE_TOUCHPOINT_WEBFORM_COUNT_INFLUENCE_ACTMQA,
	            CASE
	                WHEN infl_data.MARKETING_TOUCHPOINT_DATE <= amlh_opp.AMLH_MQA_DATE_STAMP__C
	                AND infl_data.INTERACTIONTYPE_BIZIBLE_TOUCHPOINT_CRM_COUNT > 0 THEN infl_data.INTERACTIONTYPE_BIZIBLE_TOUCHPOINT_CRM_COUNT
	                ELSE 0
	            END AS INTERACTIONTYPE_BIZIBLE_TOUCHPOINT_CRM_COUNT_INFLUENCE_ACTMQA,
	            CASE
	                WHEN infl_data.MARKETING_TOUCHPOINT_DATE <= amlh_opp.AMLH_MQA_DATE_STAMP__C
	                AND infl_data.INTERACTIONTYPE_BIZIBLE_TOUCHPOINT_CONNECTWITHDM_COUNT > 0 THEN infl_data.INTERACTIONTYPE_BIZIBLE_TOUCHPOINT_CONNECTWITHDM_COUNT
	                ELSE 0
	            END AS INTERACTIONTYPE_BIZIBLE_TOUCHPOINT_CONNECTWITHDM_COUNT_INFLUENCE_ACTMQA,
	            CASE
	                WHEN infl_data.MARKETING_TOUCHPOINT_DATE <= amlh_opp.AMLH_MQA_DATE_STAMP__C
	                AND infl_data.INTERACTIONTYPE_BIZIBLE_TOUCHPOINT_CALLSPOKEWITH_COUNT > 0 THEN infl_data.INTERACTIONTYPE_BIZIBLE_TOUCHPOINT_CALLSPOKEWITH_COUNT
	                ELSE 0
	            END AS INTERACTIONTYPE_BIZIBLE_TOUCHPOINT_CALLSPOKEWITH_COUNT_INFLUENCE_ACTMQA,
	            CASE
	                WHEN infl_data.MARKETING_TOUCHPOINT_DATE <= amlh_opp.AMLH_MQA_DATE_STAMP__C
	                AND infl_data.INTERACTIONTYPE_BIZIBLE_TOUCHPOINT_CALLGATEKEEPER_COUNT > 0 THEN infl_data.INTERACTIONTYPE_BIZIBLE_TOUCHPOINT_CALLGATEKEEPER_COUNT
	                ELSE 0
	            END AS INTERACTIONTYPE_BIZIBLE_TOUCHPOINT_CALLGATEKEEPER_COUNT_INFLUENCE_ACTMQA,
	            CASE
	                WHEN infl_data.MARKETING_TOUCHPOINT_DATE <= amlh_opp.AMLH_MQA_DATE_STAMP__C
	                AND infl_data.INTERACTIONTYPE_BIZIBLE_TOUCHPOINT_NOLEADTOUCHPOINTS_COUNT > 0 THEN infl_data.INTERACTIONTYPE_BIZIBLE_TOUCHPOINT_NOLEADTOUCHPOINTS_COUNT
	                ELSE 0
	            END AS INTERACTIONTYPE_BIZIBLE_TOUCHPOINT_NOLEADTOUCHPOINTS_COUNT_INFLUENCE_ACTMQA,
	            CASE
	                WHEN infl_data.MARKETING_TOUCHPOINT_DATE <= amlh_opp.AMLH_MQA_DATE_STAMP__C
	                AND infl_data.INTERACTIONTYPE_BIZIBLE_TOUCHPOINT_UNCLASSIFIED_COUNT > 0 THEN infl_data.INTERACTIONTYPE_BIZIBLE_TOUCHPOINT_UNCLASSIFIED_COUNT
	                ELSE 0
	            END AS INTERACTIONTYPE_BIZIBLE_TOUCHPOINT_UNCLASSIFIED_COUNT_INFLUENCE_ACTMQA,
	            -- SUM COUNTS INFLUENCE
	            -- Influenced Before Account Suspect
	            CASE
	                WHEN infl_data.MARKETING_TOUCHPOINT_DATE <= amlh_opp.AMLH_SUSPECT_DATE_STAMP__C
	                AND infl_data.INTERACTIONTYPE_SIXSENSE_PAIDMEDIA_IMPRESSIONS_COUNT > 0 THEN infl_data.INTERACTIONTYPE_SIXSENSE_PAIDMEDIA_IMPRESSIONS_COUNT
	                ELSE 0
	            END AS INTERACTIONTYPE_SIXSENSE_PAIDMEDIA_IMPRESSIONS_COUNT_INFLUENCE_ACTSUSPECT,
	            CASE
	                WHEN infl_data.MARKETING_TOUCHPOINT_DATE <= amlh_opp.AMLH_SUSPECT_DATE_STAMP__C
	                AND infl_data.INTERACTIONTYPE_SIXSENSE_PAIDMEDIA_CLICKS_COUNT > 0 THEN infl_data.INTERACTIONTYPE_SIXSENSE_PAIDMEDIA_CLICKS_COUNT
	                ELSE 0
	            END AS INTERACTIONTYPE_SIXSENSE_PAIDMEDIA_CLICKS_COUNT_INFLUENCE_ACTSUSPECT,
	            CASE
	                WHEN infl_data.MARKETING_TOUCHPOINT_DATE <= amlh_opp.AMLH_SUSPECT_DATE_STAMP__C
	                AND infl_data.INTERACTIONTYPE_SIXSENSE_WEBVISIT_TOTAL_INTERACTIONS_COUNT > 0 THEN infl_data.INTERACTIONTYPE_SIXSENSE_WEBVISIT_TOTAL_INTERACTIONS_COUNT
	                ELSE 0
	            END AS INTERACTIONTYPE_SIXSENSE_WEBVISIT_TOTAL_INTERACTIONS_COUNT_INFLUENCE_ACTSUSPECT,
	            CASE
	                WHEN infl_data.MARKETING_TOUCHPOINT_DATE <= amlh_opp.AMLH_SUSPECT_DATE_STAMP__C
	                AND infl_data.INTERACTIONTYPE_SIXSENSE_WEBVISIT_PAGELOAD_COUNT > 0 THEN infl_data.INTERACTIONTYPE_SIXSENSE_WEBVISIT_PAGELOAD_COUNT
	                ELSE 0
	            END AS INTERACTIONTYPE_SIXSENSE_WEBVISIT_PAGELOAD_COUNT_INFLUENCE_ACTSUSPECT,
	            CASE
	                WHEN infl_data.MARKETING_TOUCHPOINT_DATE <= amlh_opp.AMLH_SUSPECT_DATE_STAMP__C
	                AND infl_data.INTERACTIONTYPE_SIXSENSE_WEBVISIT_PLAY_COUNT > 0 THEN infl_data.INTERACTIONTYPE_SIXSENSE_WEBVISIT_PLAY_COUNT
	                ELSE 0
	            END AS INTERACTIONTYPE_SIXSENSE_WEBVISIT_PLAY_COUNT_INFLUENCE_ACTSUSPECT,
	            CASE
	                WHEN infl_data.MARKETING_TOUCHPOINT_DATE <= amlh_opp.AMLH_SUSPECT_DATE_STAMP__C
	                AND infl_data.INTERACTIONTYPE_SIXSENSE_WEBVISIT_CLICK_COUNT > 0 THEN infl_data.INTERACTIONTYPE_SIXSENSE_WEBVISIT_CLICK_COUNT
	                ELSE 0
	            END AS INTERACTIONTYPE_SIXSENSE_WEBVISIT_CLICK_COUNT_INFLUENCE_ACTSUSPECT,
	            CASE
	                WHEN infl_data.MARKETING_TOUCHPOINT_DATE <= amlh_opp.AMLH_SUSPECT_DATE_STAMP__C
	                AND infl_data.INTERACTIONTYPE_SIXSENSE_WEBVISIT_SUBMIT_COUNT > 0 THEN infl_data.INTERACTIONTYPE_SIXSENSE_WEBVISIT_SUBMIT_COUNT
	                ELSE 0
	            END AS INTERACTIONTYPE_SIXSENSE_WEBVISIT_SUBMIT_COUNT_INFLUENCE_ACTSUSPECT,
	            CASE
	                WHEN infl_data.MARKETING_TOUCHPOINT_DATE <= amlh_opp.AMLH_SUSPECT_DATE_STAMP__C
	                AND infl_data.INTERACTIONTYPE_SIXSENSE_WEBVISIT_UNCLASSIFIED_COUNT > 0 THEN infl_data.INTERACTIONTYPE_SIXSENSE_WEBVISIT_UNCLASSIFIED_COUNT
	                ELSE 0
	            END AS INTERACTIONTYPE_SIXSENSE_WEBVISIT_UNCLASSIFIED_COUNT_INFLUENCE_ACTSUSPECT,
	            CASE
	                WHEN infl_data.MARKETING_TOUCHPOINT_DATE <= amlh_opp.AMLH_SUSPECT_DATE_STAMP__C
	                AND infl_data.INTERACTIONTYPE_BIZIBLE_TOUCHPOINT_WEBVISIT_COUNT > 0 THEN infl_data.INTERACTIONTYPE_BIZIBLE_TOUCHPOINT_WEBVISIT_COUNT
	                ELSE 0
	            END AS INTERACTIONTYPE_BIZIBLE_TOUCHPOINT_WEBVISIT_COUNT_INFLUENCE_ACTSUSPECT,
	            CASE
	                WHEN infl_data.MARKETING_TOUCHPOINT_DATE <= amlh_opp.AMLH_SUSPECT_DATE_STAMP__C
	                AND infl_data.INTERACTIONTYPE_BIZIBLE_TOUCHPOINT_WEBCHAT_COUNT > 0 THEN infl_data.INTERACTIONTYPE_BIZIBLE_TOUCHPOINT_WEBCHAT_COUNT
	                ELSE 0
	            END AS INTERACTIONTYPE_BIZIBLE_TOUCHPOINT_WEBCHAT_COUNT_INFLUENCE_ACTSUSPECT,
	            CASE
	                WHEN infl_data.MARKETING_TOUCHPOINT_DATE <= amlh_opp.AMLH_SUSPECT_DATE_STAMP__C
	                AND infl_data.INTERACTIONTYPE_BIZIBLE_TOUCHPOINT_WEBFORM_COUNT > 0 THEN infl_data.INTERACTIONTYPE_BIZIBLE_TOUCHPOINT_WEBFORM_COUNT
	                ELSE 0
	            END AS INTERACTIONTYPE_BIZIBLE_TOUCHPOINT_WEBFORM_COUNT_INFLUENCE_ACTSUSPECT,
	            CASE
	                WHEN infl_data.MARKETING_TOUCHPOINT_DATE <= amlh_opp.AMLH_SUSPECT_DATE_STAMP__C
	                AND infl_data.INTERACTIONTYPE_BIZIBLE_TOUCHPOINT_CRM_COUNT > 0 THEN infl_data.INTERACTIONTYPE_BIZIBLE_TOUCHPOINT_CRM_COUNT
	                ELSE 0
	            END AS INTERACTIONTYPE_BIZIBLE_TOUCHPOINT_CRM_COUNT_INFLUENCE_ACTSUSPECT,
	            CASE
	                WHEN infl_data.MARKETING_TOUCHPOINT_DATE <= amlh_opp.AMLH_SUSPECT_DATE_STAMP__C
	                AND infl_data.INTERACTIONTYPE_BIZIBLE_TOUCHPOINT_CONNECTWITHDM_COUNT > 0 THEN infl_data.INTERACTIONTYPE_BIZIBLE_TOUCHPOINT_CONNECTWITHDM_COUNT
	                ELSE 0
	            END AS INTERACTIONTYPE_BIZIBLE_TOUCHPOINT_CONNECTWITHDM_COUNT_INFLUENCE_ACTSUSPECT,
	            CASE
	                WHEN infl_data.MARKETING_TOUCHPOINT_DATE <= amlh_opp.AMLH_SUSPECT_DATE_STAMP__C
	                AND infl_data.INTERACTIONTYPE_BIZIBLE_TOUCHPOINT_CALLSPOKEWITH_COUNT > 0 THEN infl_data.INTERACTIONTYPE_BIZIBLE_TOUCHPOINT_CALLSPOKEWITH_COUNT
	                ELSE 0
	            END AS INTERACTIONTYPE_BIZIBLE_TOUCHPOINT_CALLSPOKEWITH_COUNT_INFLUENCE_ACTSUSPECT,
	            CASE
	                WHEN infl_data.MARKETING_TOUCHPOINT_DATE <= amlh_opp.AMLH_SUSPECT_DATE_STAMP__C
	                AND infl_data.INTERACTIONTYPE_BIZIBLE_TOUCHPOINT_CALLGATEKEEPER_COUNT > 0 THEN infl_data.INTERACTIONTYPE_BIZIBLE_TOUCHPOINT_CALLGATEKEEPER_COUNT
	                ELSE 0
	            END AS INTERACTIONTYPE_BIZIBLE_TOUCHPOINT_CALLGATEKEEPER_COUNT_INFLUENCE_ACTSUSPECT,
	            CASE
	                WHEN infl_data.MARKETING_TOUCHPOINT_DATE <= amlh_opp.AMLH_SUSPECT_DATE_STAMP__C
	                AND infl_data.INTERACTIONTYPE_BIZIBLE_TOUCHPOINT_NOLEADTOUCHPOINTS_COUNT > 0 THEN infl_data.INTERACTIONTYPE_BIZIBLE_TOUCHPOINT_NOLEADTOUCHPOINTS_COUNT
	                ELSE 0
	            END AS INTERACTIONTYPE_BIZIBLE_TOUCHPOINT_NOLEADTOUCHPOINTS_COUNT_INFLUENCE_ACTSUSPECT,
	            CASE
	                WHEN infl_data.MARKETING_TOUCHPOINT_DATE <= amlh_opp.AMLH_SUSPECT_DATE_STAMP__C
	                AND infl_data.INTERACTIONTYPE_BIZIBLE_TOUCHPOINT_UNCLASSIFIED_COUNT > 0 THEN infl_data.INTERACTIONTYPE_BIZIBLE_TOUCHPOINT_UNCLASSIFIED_COUNT
	                ELSE 0
	            END AS INTERACTIONTYPE_BIZIBLE_TOUCHPOINT_UNCLASSIFIED_COUNT_INFLUENCE_ACTSUSPECT,
	            -- SUM COUNTS INFLUENCE
	            -- Influenced Before Account Prospect
	            CASE
	                WHEN infl_data.MARKETING_TOUCHPOINT_DATE <= amlh_opp.AMLH_PROSPECT_DATE_STAMP__C
	                AND infl_data.INTERACTIONTYPE_SIXSENSE_PAIDMEDIA_IMPRESSIONS_COUNT > 0 THEN infl_data.INTERACTIONTYPE_SIXSENSE_PAIDMEDIA_IMPRESSIONS_COUNT
	                ELSE 0
	            END AS INTERACTIONTYPE_SIXSENSE_PAIDMEDIA_IMPRESSIONS_COUNT_INFLUENCE_ACTPROSPECT,
	            CASE
	                WHEN infl_data.MARKETING_TOUCHPOINT_DATE <= amlh_opp.AMLH_PROSPECT_DATE_STAMP__C
	                AND infl_data.INTERACTIONTYPE_SIXSENSE_PAIDMEDIA_CLICKS_COUNT > 0 THEN infl_data.INTERACTIONTYPE_SIXSENSE_PAIDMEDIA_CLICKS_COUNT
	                ELSE 0
	            END AS INTERACTIONTYPE_SIXSENSE_PAIDMEDIA_CLICKS_COUNT_INFLUENCE_ACTPROSPECT,
	            CASE
	                WHEN infl_data.MARKETING_TOUCHPOINT_DATE <= amlh_opp.AMLH_PROSPECT_DATE_STAMP__C
	                AND infl_data.INTERACTIONTYPE_SIXSENSE_WEBVISIT_TOTAL_INTERACTIONS_COUNT > 0 THEN infl_data.INTERACTIONTYPE_SIXSENSE_WEBVISIT_TOTAL_INTERACTIONS_COUNT
	                ELSE 0
	            END AS INTERACTIONTYPE_SIXSENSE_WEBVISIT_TOTAL_INTERACTIONS_COUNT_INFLUENCE_ACTPROSPECT,
	            CASE
	                WHEN infl_data.MARKETING_TOUCHPOINT_DATE <= amlh_opp.AMLH_PROSPECT_DATE_STAMP__C
	                AND infl_data.INTERACTIONTYPE_SIXSENSE_WEBVISIT_PAGELOAD_COUNT > 0 THEN infl_data.INTERACTIONTYPE_SIXSENSE_WEBVISIT_PAGELOAD_COUNT
	                ELSE 0
	            END AS INTERACTIONTYPE_SIXSENSE_WEBVISIT_PAGELOAD_COUNT_INFLUENCE_ACTPROSPECT,
	            CASE
	                WHEN infl_data.MARKETING_TOUCHPOINT_DATE <= amlh_opp.AMLH_PROSPECT_DATE_STAMP__C
	                AND infl_data.INTERACTIONTYPE_SIXSENSE_WEBVISIT_PLAY_COUNT > 0 THEN infl_data.INTERACTIONTYPE_SIXSENSE_WEBVISIT_PLAY_COUNT
	                ELSE 0
	            END AS INTERACTIONTYPE_SIXSENSE_WEBVISIT_PLAY_COUNT_INFLUENCE_ACTPROSPECT,
	            CASE
	                WHEN infl_data.MARKETING_TOUCHPOINT_DATE <= amlh_opp.AMLH_PROSPECT_DATE_STAMP__C
	                AND infl_data.INTERACTIONTYPE_SIXSENSE_WEBVISIT_CLICK_COUNT > 0 THEN infl_data.INTERACTIONTYPE_SIXSENSE_WEBVISIT_CLICK_COUNT
	                ELSE 0
	            END AS INTERACTIONTYPE_SIXSENSE_WEBVISIT_CLICK_COUNT_INFLUENCE_ACTPROSPECT,
	            CASE
	                WHEN infl_data.MARKETING_TOUCHPOINT_DATE <= amlh_opp.AMLH_PROSPECT_DATE_STAMP__C
	                AND infl_data.INTERACTIONTYPE_SIXSENSE_WEBVISIT_SUBMIT_COUNT > 0 THEN infl_data.INTERACTIONTYPE_SIXSENSE_WEBVISIT_SUBMIT_COUNT
	                ELSE 0
	            END AS INTERACTIONTYPE_SIXSENSE_WEBVISIT_SUBMIT_COUNT_INFLUENCE_ACTPROSPECT,
	            CASE
	                WHEN infl_data.MARKETING_TOUCHPOINT_DATE <= amlh_opp.AMLH_PROSPECT_DATE_STAMP__C
	                AND infl_data.INTERACTIONTYPE_SIXSENSE_WEBVISIT_UNCLASSIFIED_COUNT > 0 THEN infl_data.INTERACTIONTYPE_SIXSENSE_WEBVISIT_UNCLASSIFIED_COUNT
	                ELSE 0
	            END AS INTERACTIONTYPE_SIXSENSE_WEBVISIT_UNCLASSIFIED_COUNT_INFLUENCE_ACTPROSPECT,
	            CASE
	                WHEN infl_data.MARKETING_TOUCHPOINT_DATE <= amlh_opp.AMLH_PROSPECT_DATE_STAMP__C
	                AND infl_data.INTERACTIONTYPE_BIZIBLE_TOUCHPOINT_WEBVISIT_COUNT > 0 THEN infl_data.INTERACTIONTYPE_BIZIBLE_TOUCHPOINT_WEBVISIT_COUNT
	                ELSE 0
	            END AS INTERACTIONTYPE_BIZIBLE_TOUCHPOINT_WEBVISIT_COUNT_INFLUENCE_ACTPROSPECT,
	            CASE
	                WHEN infl_data.MARKETING_TOUCHPOINT_DATE <= amlh_opp.AMLH_PROSPECT_DATE_STAMP__C
	                AND infl_data.INTERACTIONTYPE_BIZIBLE_TOUCHPOINT_WEBCHAT_COUNT > 0 THEN infl_data.INTERACTIONTYPE_BIZIBLE_TOUCHPOINT_WEBCHAT_COUNT
	                ELSE 0
	            END AS INTERACTIONTYPE_BIZIBLE_TOUCHPOINT_WEBCHAT_COUNT_INFLUENCE_ACTPROSPECT,
	            CASE
	                WHEN infl_data.MARKETING_TOUCHPOINT_DATE <= amlh_opp.AMLH_PROSPECT_DATE_STAMP__C
	                AND infl_data.INTERACTIONTYPE_BIZIBLE_TOUCHPOINT_WEBFORM_COUNT > 0 THEN infl_data.INTERACTIONTYPE_BIZIBLE_TOUCHPOINT_WEBFORM_COUNT
	                ELSE 0
	            END AS INTERACTIONTYPE_BIZIBLE_TOUCHPOINT_WEBFORM_COUNT_INFLUENCE_ACTPROSPECT,
	            CASE
	                WHEN infl_data.MARKETING_TOUCHPOINT_DATE <= amlh_opp.AMLH_PROSPECT_DATE_STAMP__C
	                AND infl_data.INTERACTIONTYPE_BIZIBLE_TOUCHPOINT_CRM_COUNT > 0 THEN infl_data.INTERACTIONTYPE_BIZIBLE_TOUCHPOINT_CRM_COUNT
	                ELSE 0
	            END AS INTERACTIONTYPE_BIZIBLE_TOUCHPOINT_CRM_COUNT_INFLUENCE_ACTPROSPECT,
	            CASE
	                WHEN infl_data.MARKETING_TOUCHPOINT_DATE <= amlh_opp.AMLH_PROSPECT_DATE_STAMP__C
	                AND infl_data.INTERACTIONTYPE_BIZIBLE_TOUCHPOINT_CONNECTWITHDM_COUNT > 0 THEN infl_data.INTERACTIONTYPE_BIZIBLE_TOUCHPOINT_CONNECTWITHDM_COUNT
	                ELSE 0
	            END AS INTERACTIONTYPE_BIZIBLE_TOUCHPOINT_CONNECTWITHDM_COUNT_INFLUENCE_ACTPROSPECT,
	            CASE
	                WHEN infl_data.MARKETING_TOUCHPOINT_DATE <= amlh_opp.AMLH_PROSPECT_DATE_STAMP__C
	                AND infl_data.INTERACTIONTYPE_BIZIBLE_TOUCHPOINT_CALLSPOKEWITH_COUNT > 0 THEN infl_data.INTERACTIONTYPE_BIZIBLE_TOUCHPOINT_CALLSPOKEWITH_COUNT
	                ELSE 0
	            END AS INTERACTIONTYPE_BIZIBLE_TOUCHPOINT_CALLSPOKEWITH_COUNT_INFLUENCE_ACTPROSPECT,
	            CASE
	                WHEN infl_data.MARKETING_TOUCHPOINT_DATE <= amlh_opp.AMLH_PROSPECT_DATE_STAMP__C
	                AND infl_data.INTERACTIONTYPE_BIZIBLE_TOUCHPOINT_CALLGATEKEEPER_COUNT > 0 THEN infl_data.INTERACTIONTYPE_BIZIBLE_TOUCHPOINT_CALLGATEKEEPER_COUNT
	                ELSE 0
	            END AS INTERACTIONTYPE_BIZIBLE_TOUCHPOINT_CALLGATEKEEPER_COUNT_INFLUENCE_ACTPROSPECT,
	            CASE
	                WHEN infl_data.MARKETING_TOUCHPOINT_DATE <= amlh_opp.AMLH_PROSPECT_DATE_STAMP__C
	                AND infl_data.INTERACTIONTYPE_BIZIBLE_TOUCHPOINT_NOLEADTOUCHPOINTS_COUNT > 0 THEN infl_data.INTERACTIONTYPE_BIZIBLE_TOUCHPOINT_NOLEADTOUCHPOINTS_COUNT
	                ELSE 0
	            END AS INTERACTIONTYPE_BIZIBLE_TOUCHPOINT_NOLEADTOUCHPOINTS_COUNT_INFLUENCE_ACTPROSPECT,
	            CASE
	                WHEN infl_data.MARKETING_TOUCHPOINT_DATE <= amlh_opp.AMLH_PROSPECT_DATE_STAMP__C
	                AND infl_data.INTERACTIONTYPE_BIZIBLE_TOUCHPOINT_UNCLASSIFIED_COUNT > 0 THEN infl_data.INTERACTIONTYPE_BIZIBLE_TOUCHPOINT_UNCLASSIFIED_COUNT
	                ELSE 0
	            END AS INTERACTIONTYPE_BIZIBLE_TOUCHPOINT_UNCLASSIFIED_COUNT_INFLUENCE_ACTPROSPECT,
	            -- Influence Before Opp Created Date
	            CASE
	                WHEN infl_data.MARKETING_TOUCHPOINT_DATE <= amlh_opp.OPP_CREATED_DATE
	                AND SPLIT_PART(infl_data.INFLUENCE_CHANNEL, '.', 1) = 'Channel Referral' THEN 1
	                else 0
	            END AS FLAG_OPPCRT_INFL_TOUCHPOINT_BY_ACQTOPLEVELCHANNEL_CHANNELREFERRAL,
	            CASE
	                WHEN infl_data.MARKETING_TOUCHPOINT_DATE <= amlh_opp.OPP_CREATED_DATE
	                AND SPLIT_PART(infl_data.INFLUENCE_CHANNEL, '.', 1) = 'Content Syndication' THEN 1
	                else 0
	            END AS FLAG_OPPCRT_INFL_TOUCHPOINT_BY_ACQTOPLEVELCHANNEL_CONTENTSYNDICATION,
	            CASE
	                WHEN infl_data.MARKETING_TOUCHPOINT_DATE <= amlh_opp.OPP_CREATED_DATE
	                AND SPLIT_PART(infl_data.INFLUENCE_CHANNEL, '.', 1) = 'Sales Engagement' THEN 1
	                else 0
	            END AS FLAG_OPPCRT_INFL_TOUCHPOINT_BY_ACQTOPLEVELCHANNEL_SALESENGAGEMENT,
	            CASE
	                WHEN infl_data.MARKETING_TOUCHPOINT_DATE <= amlh_opp.OPP_CREATED_DATE
	                AND SPLIT_PART(infl_data.INFLUENCE_CHANNEL, '.', 1) = 'Direct' THEN 1
	                else 0
	            END AS FLAG_OPPCRT_INFL_TOUCHPOINT_BY_ACQTOPLEVELCHANNEL_DIRECT,
	            CASE
	                WHEN infl_data.MARKETING_TOUCHPOINT_DATE <= amlh_opp.OPP_CREATED_DATE
	                AND SPLIT_PART(infl_data.INFLUENCE_CHANNEL, '.', 1) = 'Direct Mail' THEN 1
	                else 0
	            END AS FLAG_OPPCRT_INFL_TOUCHPOINT_BY_ACQTOPLEVELCHANNEL_DIRECTMAIL,
	            CASE
	                WHEN infl_data.MARKETING_TOUCHPOINT_DATE <= amlh_opp.OPP_CREATED_DATE
	                AND SPLIT_PART(infl_data.INFLUENCE_CHANNEL, '.', 1) = 'Display' THEN 1
	                else 0
	            END AS FLAG_OPPCRT_INFL_TOUCHPOINT_BY_ACQTOPLEVELCHANNEL_DISPLAY,
	            CASE
	                WHEN infl_data.MARKETING_TOUCHPOINT_DATE <= amlh_opp.OPP_CREATED_DATE
	                AND SPLIT_PART(infl_data.INFLUENCE_CHANNEL, '.', 1) = 'Email' THEN 1
	                else 0
	            END AS FLAG_OPPCRT_INFL_TOUCHPOINT_BY_ACQTOPLEVELCHANNEL_EMAIL,
	            CASE
	                WHEN infl_data.MARKETING_TOUCHPOINT_DATE <= amlh_opp.OPP_CREATED_DATE
	                AND SPLIT_PART(infl_data.INFLUENCE_CHANNEL, '.', 1) = 'Lead Referral' THEN 1
	                else 0
	            END AS FLAG_OPPCRT_INFL_TOUCHPOINT_BY_ACQTOPLEVELCHANNEL_LEADREFERRAL,
	            CASE
	                WHEN infl_data.MARKETING_TOUCHPOINT_DATE <= amlh_opp.OPP_CREATED_DATE
	                AND SPLIT_PART(infl_data.INFLUENCE_CHANNEL, '.', 1) = 'Live Event' THEN 1
	                else 0
	            END AS FLAG_OPPCRT_INFL_TOUCHPOINT_BY_ACQTOPLEVELCHANNEL_LIVEEVENT,
	            CASE
	                WHEN infl_data.MARKETING_TOUCHPOINT_DATE <= amlh_opp.OPP_CREATED_DATE
	                AND SPLIT_PART(infl_data.INFLUENCE_CHANNEL, '.', 1) = 'Lytx' THEN 1
	                else 0
	            END AS FLAG_OPPCRT_INFL_TOUCHPOINT_BY_ACQTOPLEVELCHANNEL_LYTX,
	            CASE
	                WHEN infl_data.MARKETING_TOUCHPOINT_DATE <= amlh_opp.OPP_CREATED_DATE
	                AND SPLIT_PART(infl_data.INFLUENCE_CHANNEL, '.', 1) = 'Native' THEN 1
	                else 0
	            END AS FLAG_OPPCRT_INFL_TOUCHPOINT_BY_ACQTOPLEVELCHANNEL_NATIVE,
	            CASE
	                WHEN infl_data.MARKETING_TOUCHPOINT_DATE <= amlh_opp.OPP_CREATED_DATE
	                AND SPLIT_PART(infl_data.INFLUENCE_CHANNEL, '.', 1) = 'Organic Search' THEN 1
	                else 0
	            END AS FLAG_OPPCRT_INFL_TOUCHPOINT_BY_ACQTOPLEVELCHANNEL_ORGANICSEARCH,
	            CASE
	                WHEN infl_data.MARKETING_TOUCHPOINT_DATE <= amlh_opp.OPP_CREATED_DATE
	                AND SPLIT_PART(infl_data.INFLUENCE_CHANNEL, '.', 1) = 'Organic Social' THEN 1
	                else 0
	            END AS FLAG_OPPCRT_INFL_TOUCHPOINT_BY_ACQTOPLEVELCHANNEL_ORGANICSOCIAL,
	            CASE
	                WHEN infl_data.MARKETING_TOUCHPOINT_DATE <= amlh_opp.OPP_CREATED_DATE
	                AND SPLIT_PART(infl_data.INFLUENCE_CHANNEL, '.', 1) = 'Other' THEN 1
	                else 0
	            END AS FLAG_OPPCRT_INFL_TOUCHPOINT_BY_ACQTOPLEVELCHANNEL_OTHER,
	            CASE
	                WHEN infl_data.MARKETING_TOUCHPOINT_DATE <= amlh_opp.OPP_CREATED_DATE
	                AND SPLIT_PART(infl_data.INFLUENCE_CHANNEL, '.', 1) = 'Paid Media' THEN 1
	                else 0
	            END AS FLAG_OPPCRT_INFL_TOUCHPOINT_BY_ACQTOPLEVELCHANNEL_PAIDMEDIA,
	            CASE
	                WHEN infl_data.MARKETING_TOUCHPOINT_DATE <= amlh_opp.OPP_CREATED_DATE
	                AND SPLIT_PART(infl_data.INFLUENCE_CHANNEL, '.', 1) = 'Paid Search' THEN 1
	                else 0
	            END AS FLAG_OPPCRT_INFL_TOUCHPOINT_BY_ACQTOPLEVELCHANNEL_PAIDSEARCH,
	            CASE
	                WHEN infl_data.MARKETING_TOUCHPOINT_DATE <= amlh_opp.OPP_CREATED_DATE
	                AND SPLIT_PART(infl_data.INFLUENCE_CHANNEL, '.', 1) = 'Paid Social' THEN 1
	                else 0
	            END AS FLAG_OPPCRT_INFL_TOUCHPOINT_BY_ACQTOPLEVELCHANNEL_PAIDSOCIAL,
	            CASE
	                WHEN infl_data.MARKETING_TOUCHPOINT_DATE <= amlh_opp.OPP_CREATED_DATE
	                AND SPLIT_PART(infl_data.INFLUENCE_CHANNEL, '.', 1) = 'Podcast' THEN 1
	                else 0
	            END AS FLAG_OPPCRT_INFL_TOUCHPOINT_BY_ACQTOPLEVELCHANNEL_PODCAST,
	            CASE
	                WHEN infl_data.MARKETING_TOUCHPOINT_DATE <= amlh_opp.OPP_CREATED_DATE
	                AND SPLIT_PART(infl_data.INFLUENCE_CHANNEL, '.', 1) = 'PPL' THEN 1
	                else 0
	            END AS FLAG_OPPCRT_INFL_TOUCHPOINT_BY_ACQTOPLEVELCHANNEL_PPL,
	            CASE
	                WHEN infl_data.MARKETING_TOUCHPOINT_DATE <= amlh_opp.OPP_CREATED_DATE
	                AND SPLIT_PART(infl_data.INFLUENCE_CHANNEL, '.', 1) = 'Print' THEN 1
	                else 0
	            END AS FLAG_OPPCRT_INFL_TOUCHPOINT_BY_ACQTOPLEVELCHANNEL_PRINT,
	            CASE
	                WHEN infl_data.MARKETING_TOUCHPOINT_DATE <= amlh_opp.OPP_CREATED_DATE
	                AND SPLIT_PART(infl_data.INFLUENCE_CHANNEL, '.', 1) = 'Sponsored Email' THEN 1
	                else 0
	            END AS FLAG_OPPCRT_INFL_TOUCHPOINT_BY_ACQTOPLEVELCHANNEL_SPONSOREDEMAIL,
	            CASE
	                WHEN infl_data.MARKETING_TOUCHPOINT_DATE <= amlh_opp.OPP_CREATED_DATE
	                AND SPLIT_PART(infl_data.INFLUENCE_CHANNEL, '.', 1) = 'Tradeshow' THEN 1
	                else 0
	            END AS FLAG_OPPCRT_INFL_TOUCHPOINT_BY_ACQTOPLEVELCHANNEL_TRADESHOW,
	            CASE
	                WHEN infl_data.MARKETING_TOUCHPOINT_DATE <= amlh_opp.OPP_CREATED_DATE
	                AND SPLIT_PART(infl_data.INFLUENCE_CHANNEL, '.', 1) = 'Web Referral' THEN 1
	                else 0
	            END AS FLAG_OPPCRT_INFL_TOUCHPOINT_BY_ACQTOPLEVELCHANNEL_WEBREFERRAL,
	            CASE
	                WHEN infl_data.MARKETING_TOUCHPOINT_DATE <= amlh_opp.OPP_CREATED_DATE
	                AND SPLIT_PART(infl_data.INFLUENCE_CHANNEL, '.', 1) = 'Webinar' THEN 1
	                else 0
	            END AS FLAG_OPPCRT_INFL_TOUCHPOINT_BY_ACQTOPLEVELCHANNEL_WEBINAR,
	            -- Influence Before Opp Close Date
	            CASE
	                WHEN infl_data.MARKETING_TOUCHPOINT_DATE <= amlh_opp.OPP_CLOSE_DATE
	                AND SPLIT_PART(infl_data.INFLUENCE_CHANNEL, '.', 1) = 'Channel Referral' THEN 1
	                else 0
	            END AS FLAG_OPPCLS_INFL_TOUCHPOINT_BY_ACQTOPLEVELCHANNEL_CHANNELREFERRAL,
	            CASE
	                WHEN infl_data.MARKETING_TOUCHPOINT_DATE <= amlh_opp.OPP_CLOSE_DATE
	                AND SPLIT_PART(infl_data.INFLUENCE_CHANNEL, '.', 1) = 'Content Syndication' THEN 1
	                else 0
	            END AS FLAG_OPPCLS_INFL_TOUCHPOINT_BY_ACQTOPLEVELCHANNEL_CONTENTSYNDICATION,
	            CASE
	                WHEN infl_data.MARKETING_TOUCHPOINT_DATE <= amlh_opp.OPP_CLOSE_DATE
	                AND SPLIT_PART(infl_data.INFLUENCE_CHANNEL, '.', 1) = 'Sales Engagement' THEN 1
	                else 0
	            END AS FLAG_OPPCLS_INFL_TOUCHPOINT_BY_ACQTOPLEVELCHANNEL_SALESENGAGEMENT,
	            CASE
	                WHEN infl_data.MARKETING_TOUCHPOINT_DATE <= amlh_opp.OPP_CLOSE_DATE
	                AND SPLIT_PART(infl_data.INFLUENCE_CHANNEL, '.', 1) = 'Direct' THEN 1
	                else 0
	            END AS FLAG_OPPCLS_INFL_TOUCHPOINT_BY_ACQTOPLEVELCHANNEL_DIRECT,
	            CASE
	                WHEN infl_data.MARKETING_TOUCHPOINT_DATE <= amlh_opp.OPP_CLOSE_DATE
	                AND SPLIT_PART(infl_data.INFLUENCE_CHANNEL, '.', 1) = 'Direct Mail' THEN 1
	                else 0
	            END AS FLAG_OPPCLS_INFL_TOUCHPOINT_BY_ACQTOPLEVELCHANNEL_DIRECTMAIL,
	            CASE
	                WHEN infl_data.MARKETING_TOUCHPOINT_DATE <= amlh_opp.OPP_CLOSE_DATE
	                AND SPLIT_PART(infl_data.INFLUENCE_CHANNEL, '.', 1) = 'Display' THEN 1
	                else 0
	            END AS FLAG_OPPCLS_INFL_TOUCHPOINT_BY_ACQTOPLEVELCHANNEL_DISPLAY,
	            CASE
	                WHEN infl_data.MARKETING_TOUCHPOINT_DATE <= amlh_opp.OPP_CLOSE_DATE
	                AND SPLIT_PART(infl_data.INFLUENCE_CHANNEL, '.', 1) = 'Email' THEN 1
	                else 0
	            END AS FLAG_OPPCLS_INFL_TOUCHPOINT_BY_ACQTOPLEVELCHANNEL_EMAIL,
	            CASE
	                WHEN infl_data.MARKETING_TOUCHPOINT_DATE <= amlh_opp.OPP_CLOSE_DATE
	                AND SPLIT_PART(infl_data.INFLUENCE_CHANNEL, '.', 1) = 'Lead Referral' THEN 1
	                else 0
	            END AS FLAG_OPPCLS_INFL_TOUCHPOINT_BY_ACQTOPLEVELCHANNEL_LEADREFERRAL,
	            CASE
	                WHEN infl_data.MARKETING_TOUCHPOINT_DATE <= amlh_opp.OPP_CLOSE_DATE
	                AND SPLIT_PART(infl_data.INFLUENCE_CHANNEL, '.', 1) = 'Live Event' THEN 1
	                else 0
	            END AS FLAG_OPPCLS_INFL_TOUCHPOINT_BY_ACQTOPLEVELCHANNEL_LIVEEVENT,
	            CASE
	                WHEN infl_data.MARKETING_TOUCHPOINT_DATE <= amlh_opp.OPP_CLOSE_DATE
	                AND SPLIT_PART(infl_data.INFLUENCE_CHANNEL, '.', 1) = 'Lytx' THEN 1
	                else 0
	            END AS FLAG_OPPCLS_INFL_TOUCHPOINT_BY_ACQTOPLEVELCHANNEL_LYTX,
	            CASE
	                WHEN infl_data.MARKETING_TOUCHPOINT_DATE <= amlh_opp.OPP_CLOSE_DATE
	                AND SPLIT_PART(infl_data.INFLUENCE_CHANNEL, '.', 1) = 'Native' THEN 1
	                else 0
	            END AS FLAG_OPPCLS_INFL_TOUCHPOINT_BY_ACQTOPLEVELCHANNEL_NATIVE,
	            CASE
	                WHEN infl_data.MARKETING_TOUCHPOINT_DATE <= amlh_opp.OPP_CLOSE_DATE
	                AND SPLIT_PART(infl_data.INFLUENCE_CHANNEL, '.', 1) = 'Organic Search' THEN 1
	                else 0
	            END AS FLAG_OPPCLS_INFL_TOUCHPOINT_BY_ACQTOPLEVELCHANNEL_ORGANICSEARCH,
	            CASE
	                WHEN infl_data.MARKETING_TOUCHPOINT_DATE <= amlh_opp.OPP_CLOSE_DATE
	                AND SPLIT_PART(infl_data.INFLUENCE_CHANNEL, '.', 1) = 'Organic Social' THEN 1
	                else 0
	            END AS FLAG_OPPCLS_INFL_TOUCHPOINT_BY_ACQTOPLEVELCHANNEL_ORGANICSOCIAL,
	            CASE
	                WHEN infl_data.MARKETING_TOUCHPOINT_DATE <= amlh_opp.OPP_CLOSE_DATE
	                AND SPLIT_PART(infl_data.INFLUENCE_CHANNEL, '.', 1) = 'Other' THEN 1
	                else 0
	            END AS FLAG_OPPCLS_INFL_TOUCHPOINT_BY_ACQTOPLEVELCHANNEL_OTHER,
	            CASE
	                WHEN infl_data.MARKETING_TOUCHPOINT_DATE <= amlh_opp.OPP_CLOSE_DATE
	                AND SPLIT_PART(infl_data.INFLUENCE_CHANNEL, '.', 1) = 'Paid Media' THEN 1
	                else 0
	            END AS FLAG_OPPCLS_INFL_TOUCHPOINT_BY_ACQTOPLEVELCHANNEL_PAIDMEDIA,
	            CASE
	                WHEN infl_data.MARKETING_TOUCHPOINT_DATE <= amlh_opp.OPP_CLOSE_DATE
	                AND SPLIT_PART(infl_data.INFLUENCE_CHANNEL, '.', 1) = 'Paid Search' THEN 1
	                else 0
	            END AS FLAG_OPPCLS_INFL_TOUCHPOINT_BY_ACQTOPLEVELCHANNEL_PAIDSEARCH,
	            CASE
	                WHEN infl_data.MARKETING_TOUCHPOINT_DATE <= amlh_opp.OPP_CLOSE_DATE
	                AND SPLIT_PART(infl_data.INFLUENCE_CHANNEL, '.', 1) = 'Paid Social' THEN 1
	                else 0
	            END AS FLAG_OPPCLS_INFL_TOUCHPOINT_BY_ACQTOPLEVELCHANNEL_PAIDSOCIAL,
	            CASE
	                WHEN infl_data.MARKETING_TOUCHPOINT_DATE <= amlh_opp.OPP_CLOSE_DATE
	                AND SPLIT_PART(infl_data.INFLUENCE_CHANNEL, '.', 1) = 'Podcast' THEN 1
	                else 0
	            END AS FLAG_OPPCLS_INFL_TOUCHPOINT_BY_ACQTOPLEVELCHANNEL_PODCAST,
	            CASE
	                WHEN infl_data.MARKETING_TOUCHPOINT_DATE <= amlh_opp.OPP_CLOSE_DATE
	                AND SPLIT_PART(infl_data.INFLUENCE_CHANNEL, '.', 1) = 'PPL' THEN 1
	                else 0
	            END AS FLAG_OPPCLS_INFL_TOUCHPOINT_BY_ACQTOPLEVELCHANNEL_PPL,
	            CASE
	                WHEN infl_data.MARKETING_TOUCHPOINT_DATE <= amlh_opp.OPP_CLOSE_DATE
	                AND SPLIT_PART(infl_data.INFLUENCE_CHANNEL, '.', 1) = 'Print' THEN 1
	                else 0
	            END AS FLAG_OPPCLS_INFL_TOUCHPOINT_BY_ACQTOPLEVELCHANNEL_PRINT,
	            CASE
	                WHEN infl_data.MARKETING_TOUCHPOINT_DATE <= amlh_opp.OPP_CLOSE_DATE
	                AND SPLIT_PART(infl_data.INFLUENCE_CHANNEL, '.', 1) = 'Sponsored Email' THEN 1
	                else 0
	            END AS FLAG_OPPCLS_INFL_TOUCHPOINT_BY_ACQTOPLEVELCHANNEL_SPONSOREDEMAIL,
	            CASE
	                WHEN infl_data.MARKETING_TOUCHPOINT_DATE <= amlh_opp.OPP_CLOSE_DATE
	                AND SPLIT_PART(infl_data.INFLUENCE_CHANNEL, '.', 1) = 'Tradeshow' THEN 1
	                else 0
	            END AS FLAG_OPPCLS_INFL_TOUCHPOINT_BY_ACQTOPLEVELCHANNEL_TRADESHOW,
	            CASE
	                WHEN infl_data.MARKETING_TOUCHPOINT_DATE <= amlh_opp.OPP_CLOSE_DATE
	                AND SPLIT_PART(infl_data.INFLUENCE_CHANNEL, '.', 1) = 'Web Referral' THEN 1
	                else 0
	            END AS FLAG_OPPCLS_INFL_TOUCHPOINT_BY_ACQTOPLEVELCHANNEL_WEBREFERRAL,
	            CASE
	                WHEN infl_data.MARKETING_TOUCHPOINT_DATE <= amlh_opp.OPP_CLOSE_DATE
	                AND SPLIT_PART(infl_data.INFLUENCE_CHANNEL, '.', 1) = 'Webinar' THEN 1
	                else 0
	            END AS FLAG_OPPCLS_INFL_TOUCHPOINT_BY_ACQTOPLEVELCHANNEL_WEBINAR,
	            -- Influence Before Act Cold
	            CASE
	                WHEN infl_data.MARKETING_TOUCHPOINT_DATE <= amlh_opp.AMLH_COLD_ACCOUNT_DATE_STAMP__C
	                AND SPLIT_PART(infl_data.INFLUENCE_CHANNEL, '.', 1) = 'Channel Referral' THEN 1
	                else 0
	            END AS FLAG_ACTCOLD_INFL_TOUCHPOINT_BY_ACQTOPLEVELCHANNEL_CHANNELREFERRAL,
	            CASE
	                WHEN infl_data.MARKETING_TOUCHPOINT_DATE <= amlh_opp.AMLH_COLD_ACCOUNT_DATE_STAMP__C
	                AND SPLIT_PART(infl_data.INFLUENCE_CHANNEL, '.', 1) = 'Content Syndication' THEN 1
	                else 0
	            END AS FLAG_ACTCOLD_INFL_TOUCHPOINT_BY_ACQTOPLEVELCHANNEL_CONTENTSYNDICATION,
	            CASE
	                WHEN infl_data.MARKETING_TOUCHPOINT_DATE <= amlh_opp.AMLH_COLD_ACCOUNT_DATE_STAMP__C
	                AND SPLIT_PART(infl_data.INFLUENCE_CHANNEL, '.', 1) = 'Sales Engagement' THEN 1
	                else 0
	            END AS FLAG_ACTCOLD_INFL_TOUCHPOINT_BY_ACQTOPLEVELCHANNEL_SALESENGAGEMENT,
	            CASE
	                WHEN infl_data.MARKETING_TOUCHPOINT_DATE <= amlh_opp.AMLH_COLD_ACCOUNT_DATE_STAMP__C
	                AND SPLIT_PART(infl_data.INFLUENCE_CHANNEL, '.', 1) = 'Direct' THEN 1
	                else 0
	            END AS FLAG_ACTCOLD_INFL_TOUCHPOINT_BY_ACQTOPLEVELCHANNEL_DIRECT,
	            CASE
	                WHEN infl_data.MARKETING_TOUCHPOINT_DATE <= amlh_opp.AMLH_COLD_ACCOUNT_DATE_STAMP__C
	                AND SPLIT_PART(infl_data.INFLUENCE_CHANNEL, '.', 1) = 'Direct Mail' THEN 1
	                else 0
	            END AS FLAG_ACTCOLD_INFL_TOUCHPOINT_BY_ACQTOPLEVELCHANNEL_DIRECTMAIL,
	            CASE
	                WHEN infl_data.MARKETING_TOUCHPOINT_DATE <= amlh_opp.AMLH_COLD_ACCOUNT_DATE_STAMP__C
	                AND SPLIT_PART(infl_data.INFLUENCE_CHANNEL, '.', 1) = 'Display' THEN 1
	                else 0
	            END AS FLAG_ACTCOLD_INFL_TOUCHPOINT_BY_ACQTOPLEVELCHANNEL_DISPLAY,
	            CASE
	                WHEN infl_data.MARKETING_TOUCHPOINT_DATE <= amlh_opp.AMLH_COLD_ACCOUNT_DATE_STAMP__C
	                AND SPLIT_PART(infl_data.INFLUENCE_CHANNEL, '.', 1) = 'Email' THEN 1
	                else 0
	            END AS FLAG_ACTCOLD_INFL_TOUCHPOINT_BY_ACQTOPLEVELCHANNEL_EMAIL,
	            CASE
	                WHEN infl_data.MARKETING_TOUCHPOINT_DATE <= amlh_opp.AMLH_COLD_ACCOUNT_DATE_STAMP__C
	                AND SPLIT_PART(infl_data.INFLUENCE_CHANNEL, '.', 1) = 'Lead Referral' THEN 1
	                else 0
	            END AS FLAG_ACTCOLD_INFL_TOUCHPOINT_BY_ACQTOPLEVELCHANNEL_LEADREFERRAL,
	            CASE
	                WHEN infl_data.MARKETING_TOUCHPOINT_DATE <= amlh_opp.AMLH_COLD_ACCOUNT_DATE_STAMP__C
	                AND SPLIT_PART(infl_data.INFLUENCE_CHANNEL, '.', 1) = 'Live Event' THEN 1
	                else 0
	            END AS FLAG_ACTCOLD_INFL_TOUCHPOINT_BY_ACQTOPLEVELCHANNEL_LIVEEVENT,
	            CASE
	                WHEN infl_data.MARKETING_TOUCHPOINT_DATE <= amlh_opp.AMLH_COLD_ACCOUNT_DATE_STAMP__C
	                AND SPLIT_PART(infl_data.INFLUENCE_CHANNEL, '.', 1) = 'Lytx' THEN 1
	                else 0
	            END AS FLAG_ACTCOLD_INFL_TOUCHPOINT_BY_ACQTOPLEVELCHANNEL_LYTX,
	            CASE
	                WHEN infl_data.MARKETING_TOUCHPOINT_DATE <= amlh_opp.AMLH_COLD_ACCOUNT_DATE_STAMP__C
	                AND SPLIT_PART(infl_data.INFLUENCE_CHANNEL, '.', 1) = 'Native' THEN 1
	                else 0
	            END AS FLAG_ACTCOLD_INFL_TOUCHPOINT_BY_ACQTOPLEVELCHANNEL_NATIVE,
	            CASE
	                WHEN infl_data.MARKETING_TOUCHPOINT_DATE <= amlh_opp.AMLH_COLD_ACCOUNT_DATE_STAMP__C
	                AND SPLIT_PART(infl_data.INFLUENCE_CHANNEL, '.', 1) = 'Organic Search' THEN 1
	                else 0
	            END AS FLAG_ACTCOLD_INFL_TOUCHPOINT_BY_ACQTOPLEVELCHANNEL_ORGANICSEARCH,
	            CASE
	                WHEN infl_data.MARKETING_TOUCHPOINT_DATE <= amlh_opp.AMLH_COLD_ACCOUNT_DATE_STAMP__C
	                AND SPLIT_PART(infl_data.INFLUENCE_CHANNEL, '.', 1) = 'Organic Social' THEN 1
	                else 0
	            END AS FLAG_ACTCOLD_INFL_TOUCHPOINT_BY_ACQTOPLEVELCHANNEL_ORGANICSOCIAL,
	            CASE
	                WHEN infl_data.MARKETING_TOUCHPOINT_DATE <= amlh_opp.AMLH_COLD_ACCOUNT_DATE_STAMP__C
	                AND SPLIT_PART(infl_data.INFLUENCE_CHANNEL, '.', 1) = 'Other' THEN 1
	                else 0
	            END AS FLAG_ACTCOLD_INFL_TOUCHPOINT_BY_ACQTOPLEVELCHANNEL_OTHER,
	            CASE
	                WHEN infl_data.MARKETING_TOUCHPOINT_DATE <= amlh_opp.AMLH_COLD_ACCOUNT_DATE_STAMP__C
	                AND SPLIT_PART(infl_data.INFLUENCE_CHANNEL, '.', 1) = 'Paid Media' THEN 1
	                else 0
	            END AS FLAG_ACTCOLD_INFL_TOUCHPOINT_BY_ACQTOPLEVELCHANNEL_PAIDMEDIA,
	            CASE
	                WHEN infl_data.MARKETING_TOUCHPOINT_DATE <= amlh_opp.AMLH_COLD_ACCOUNT_DATE_STAMP__C
	                AND SPLIT_PART(infl_data.INFLUENCE_CHANNEL, '.', 1) = 'Paid Search' THEN 1
	                else 0
	            END AS FLAG_ACTCOLD_INFL_TOUCHPOINT_BY_ACQTOPLEVELCHANNEL_PAIDSEARCH,
	            CASE
	                WHEN infl_data.MARKETING_TOUCHPOINT_DATE <= amlh_opp.AMLH_COLD_ACCOUNT_DATE_STAMP__C
	                AND SPLIT_PART(infl_data.INFLUENCE_CHANNEL, '.', 1) = 'Paid Social' THEN 1
	                else 0
	            END AS FLAG_ACTCOLD_INFL_TOUCHPOINT_BY_ACQTOPLEVELCHANNEL_PAIDSOCIAL,
	            CASE
	                WHEN infl_data.MARKETING_TOUCHPOINT_DATE <= amlh_opp.AMLH_COLD_ACCOUNT_DATE_STAMP__C
	                AND SPLIT_PART(infl_data.INFLUENCE_CHANNEL, '.', 1) = 'Podcast' THEN 1
	                else 0
	            END AS FLAG_ACTCOLD_INFL_TOUCHPOINT_BY_ACQTOPLEVELCHANNEL_PODCAST,
	            CASE
	                WHEN infl_data.MARKETING_TOUCHPOINT_DATE <= amlh_opp.AMLH_COLD_ACCOUNT_DATE_STAMP__C
	                AND SPLIT_PART(infl_data.INFLUENCE_CHANNEL, '.', 1) = 'PPL' THEN 1
	                else 0
	            END AS FLAG_ACTCOLD_INFL_TOUCHPOINT_BY_ACQTOPLEVELCHANNEL_PPL,
	            CASE
	                WHEN infl_data.MARKETING_TOUCHPOINT_DATE <= amlh_opp.AMLH_COLD_ACCOUNT_DATE_STAMP__C
	                AND SPLIT_PART(infl_data.INFLUENCE_CHANNEL, '.', 1) = 'Print' THEN 1
	                else 0
	            END AS FLAG_ACTCOLD_INFL_TOUCHPOINT_BY_ACQTOPLEVELCHANNEL_PRINT,
	            CASE
	                WHEN infl_data.MARKETING_TOUCHPOINT_DATE <= amlh_opp.AMLH_COLD_ACCOUNT_DATE_STAMP__C
	                AND SPLIT_PART(infl_data.INFLUENCE_CHANNEL, '.', 1) = 'Sponsored Email' THEN 1
	                else 0
	            END AS FLAG_ACTCOLD_INFL_TOUCHPOINT_BY_ACQTOPLEVELCHANNEL_SPONSOREDEMAIL,
	            CASE
	                WHEN infl_data.MARKETING_TOUCHPOINT_DATE <= amlh_opp.AMLH_COLD_ACCOUNT_DATE_STAMP__C
	                AND SPLIT_PART(infl_data.INFLUENCE_CHANNEL, '.', 1) = 'Tradeshow' THEN 1
	                else 0
	            END AS FLAG_ACTCOLD_INFL_TOUCHPOINT_BY_ACQTOPLEVELCHANNEL_TRADESHOW,
	            CASE
	                WHEN infl_data.MARKETING_TOUCHPOINT_DATE <= amlh_opp.AMLH_COLD_ACCOUNT_DATE_STAMP__C
	                AND SPLIT_PART(infl_data.INFLUENCE_CHANNEL, '.', 1) = 'Web Referral' THEN 1
	                else 0
	            END AS FLAG_ACTCOLD_INFL_TOUCHPOINT_BY_ACQTOPLEVELCHANNEL_WEBREFERRAL,
	            CASE
	                WHEN infl_data.MARKETING_TOUCHPOINT_DATE <= amlh_opp.AMLH_COLD_ACCOUNT_DATE_STAMP__C
	                AND SPLIT_PART(infl_data.INFLUENCE_CHANNEL, '.', 1) = 'Webinar' THEN 1
	                else 0
	            END AS FLAG_ACTCOLD_INFL_TOUCHPOINT_BY_ACQTOPLEVELCHANNEL_WEBINAR,
	            -- Influence Before Act MEA
	            CASE
	                WHEN infl_data.MARKETING_TOUCHPOINT_DATE <= amlh_opp.AMLH_MEA_DATE_STAMP__C
	                AND SPLIT_PART(infl_data.INFLUENCE_CHANNEL, '.', 1) = 'Channel Referral' THEN 1
	                else 0
	            END AS FLAG_ACTMEA_INFL_TOUCHPOINT_BY_ACQTOPLEVELCHANNEL_CHANNELREFERRAL,
	            CASE
	                WHEN infl_data.MARKETING_TOUCHPOINT_DATE <= amlh_opp.AMLH_MEA_DATE_STAMP__C
	                AND SPLIT_PART(infl_data.INFLUENCE_CHANNEL, '.', 1) = 'Content Syndication' THEN 1
	                else 0
	            END AS FLAG_ACTMEA_INFL_TOUCHPOINT_BY_ACQTOPLEVELCHANNEL_CONTENTSYNDICATION,
	            CASE
	                WHEN infl_data.MARKETING_TOUCHPOINT_DATE <= amlh_opp.AMLH_MEA_DATE_STAMP__C
	                AND SPLIT_PART(infl_data.INFLUENCE_CHANNEL, '.', 1) = 'Sales Engagement' THEN 1
	                else 0
	            END AS FLAG_ACTMEA_INFL_TOUCHPOINT_BY_ACQTOPLEVELCHANNEL_SALESENGAGEMENT,
	            CASE
	                WHEN infl_data.MARKETING_TOUCHPOINT_DATE <= amlh_opp.AMLH_MEA_DATE_STAMP__C
	                AND SPLIT_PART(infl_data.INFLUENCE_CHANNEL, '.', 1) = 'Direct' THEN 1
	                else 0
	            END AS FLAG_ACTMEA_INFL_TOUCHPOINT_BY_ACQTOPLEVELCHANNEL_DIRECT,
	            CASE
	                WHEN infl_data.MARKETING_TOUCHPOINT_DATE <= amlh_opp.AMLH_MEA_DATE_STAMP__C
	                AND SPLIT_PART(infl_data.INFLUENCE_CHANNEL, '.', 1) = 'Direct Mail' THEN 1
	                else 0
	            END AS FLAG_ACTMEA_INFL_TOUCHPOINT_BY_ACQTOPLEVELCHANNEL_DIRECTMAIL,
	            CASE
	                WHEN infl_data.MARKETING_TOUCHPOINT_DATE <= amlh_opp.AMLH_MEA_DATE_STAMP__C
	                AND SPLIT_PART(infl_data.INFLUENCE_CHANNEL, '.', 1) = 'Display' THEN 1
	                else 0
	            END AS FLAG_ACTMEA_INFL_TOUCHPOINT_BY_ACQTOPLEVELCHANNEL_DISPLAY,
	            CASE
	                WHEN infl_data.MARKETING_TOUCHPOINT_DATE <= amlh_opp.AMLH_MEA_DATE_STAMP__C
	                AND SPLIT_PART(infl_data.INFLUENCE_CHANNEL, '.', 1) = 'Email' THEN 1
	                else 0
	            END AS FLAG_ACTMEA_INFL_TOUCHPOINT_BY_ACQTOPLEVELCHANNEL_EMAIL,
	            CASE
	                WHEN infl_data.MARKETING_TOUCHPOINT_DATE <= amlh_opp.AMLH_MEA_DATE_STAMP__C
	                AND SPLIT_PART(infl_data.INFLUENCE_CHANNEL, '.', 1) = 'Lead Referral' THEN 1
	                else 0
	            END AS FLAG_ACTMEA_INFL_TOUCHPOINT_BY_ACQTOPLEVELCHANNEL_LEADREFERRAL,
	            CASE
	                WHEN infl_data.MARKETING_TOUCHPOINT_DATE <= amlh_opp.AMLH_MEA_DATE_STAMP__C
	                AND SPLIT_PART(infl_data.INFLUENCE_CHANNEL, '.', 1) = 'Live Event' THEN 1
	                else 0
	            END AS FLAG_ACTMEA_INFL_TOUCHPOINT_BY_ACQTOPLEVELCHANNEL_LIVEEVENT,
	            CASE
	                WHEN infl_data.MARKETING_TOUCHPOINT_DATE <= amlh_opp.AMLH_MEA_DATE_STAMP__C
	                AND SPLIT_PART(infl_data.INFLUENCE_CHANNEL, '.', 1) = 'Lytx' THEN 1
	                else 0
	            END AS FLAG_ACTMEA_INFL_TOUCHPOINT_BY_ACQTOPLEVELCHANNEL_LYTX,
	            CASE
	                WHEN infl_data.MARKETING_TOUCHPOINT_DATE <= amlh_opp.AMLH_MEA_DATE_STAMP__C
	                AND SPLIT_PART(infl_data.INFLUENCE_CHANNEL, '.', 1) = 'Native' THEN 1
	                else 0
	            END AS FLAG_ACTMEA_INFL_TOUCHPOINT_BY_ACQTOPLEVELCHANNEL_NATIVE,
	            CASE
	                WHEN infl_data.MARKETING_TOUCHPOINT_DATE <= amlh_opp.AMLH_MEA_DATE_STAMP__C
	                AND SPLIT_PART(infl_data.INFLUENCE_CHANNEL, '.', 1) = 'Organic Search' THEN 1
	                else 0
	            END AS FLAG_ACTMEA_INFL_TOUCHPOINT_BY_ACQTOPLEVELCHANNEL_ORGANICSEARCH,
	            CASE
	                WHEN infl_data.MARKETING_TOUCHPOINT_DATE <= amlh_opp.AMLH_MEA_DATE_STAMP__C
	                AND SPLIT_PART(infl_data.INFLUENCE_CHANNEL, '.', 1) = 'Organic Social' THEN 1
	                else 0
	            END AS FLAG_ACTMEA_INFL_TOUCHPOINT_BY_ACQTOPLEVELCHANNEL_ORGANICSOCIAL,
	            CASE
	                WHEN infl_data.MARKETING_TOUCHPOINT_DATE <= amlh_opp.AMLH_MEA_DATE_STAMP__C
	                AND SPLIT_PART(infl_data.INFLUENCE_CHANNEL, '.', 1) = 'Other' THEN 1
	                else 0
	            END AS FLAG_ACTMEA_INFL_TOUCHPOINT_BY_ACQTOPLEVELCHANNEL_OTHER,
	            CASE
	                WHEN infl_data.MARKETING_TOUCHPOINT_DATE <= amlh_opp.AMLH_MEA_DATE_STAMP__C
	                AND SPLIT_PART(infl_data.INFLUENCE_CHANNEL, '.', 1) = 'Paid Media' THEN 1
	                else 0
	            END AS FLAG_ACTMEA_INFL_TOUCHPOINT_BY_ACQTOPLEVELCHANNEL_PAIDMEDIA,
	            CASE
	                WHEN infl_data.MARKETING_TOUCHPOINT_DATE <= amlh_opp.AMLH_MEA_DATE_STAMP__C
	                AND SPLIT_PART(infl_data.INFLUENCE_CHANNEL, '.', 1) = 'Paid Search' THEN 1
	                else 0
	            END AS FLAG_ACTMEA_INFL_TOUCHPOINT_BY_ACQTOPLEVELCHANNEL_PAIDSEARCH,
	            CASE
	                WHEN infl_data.MARKETING_TOUCHPOINT_DATE <= amlh_opp.AMLH_MEA_DATE_STAMP__C
	                AND SPLIT_PART(infl_data.INFLUENCE_CHANNEL, '.', 1) = 'Paid Social' THEN 1
	                else 0
	            END AS FLAG_ACTMEA_INFL_TOUCHPOINT_BY_ACQTOPLEVELCHANNEL_PAIDSOCIAL,
	            CASE
	                WHEN infl_data.MARKETING_TOUCHPOINT_DATE <= amlh_opp.AMLH_MEA_DATE_STAMP__C
	                AND SPLIT_PART(infl_data.INFLUENCE_CHANNEL, '.', 1) = 'Podcast' THEN 1
	                else 0
	            END AS FLAG_ACTMEA_INFL_TOUCHPOINT_BY_ACQTOPLEVELCHANNEL_PODCAST,
	            CASE
	                WHEN infl_data.MARKETING_TOUCHPOINT_DATE <= amlh_opp.AMLH_MEA_DATE_STAMP__C
	                AND SPLIT_PART(infl_data.INFLUENCE_CHANNEL, '.', 1) = 'PPL' THEN 1
	                else 0
	            END AS FLAG_ACTMEA_INFL_TOUCHPOINT_BY_ACQTOPLEVELCHANNEL_PPL,
	            CASE
	                WHEN infl_data.MARKETING_TOUCHPOINT_DATE <= amlh_opp.AMLH_MEA_DATE_STAMP__C
	                AND SPLIT_PART(infl_data.INFLUENCE_CHANNEL, '.', 1) = 'Print' THEN 1
	                else 0
	            END AS FLAG_ACTMEA_INFL_TOUCHPOINT_BY_ACQTOPLEVELCHANNEL_PRINT,
	            CASE
	                WHEN infl_data.MARKETING_TOUCHPOINT_DATE <= amlh_opp.AMLH_MEA_DATE_STAMP__C
	                AND SPLIT_PART(infl_data.INFLUENCE_CHANNEL, '.', 1) = 'Sponsored Email' THEN 1
	                else 0
	            END AS FLAG_ACTMEA_INFL_TOUCHPOINT_BY_ACQTOPLEVELCHANNEL_SPONSOREDEMAIL,
	            CASE
	                WHEN infl_data.MARKETING_TOUCHPOINT_DATE <= amlh_opp.AMLH_MEA_DATE_STAMP__C
	                AND SPLIT_PART(infl_data.INFLUENCE_CHANNEL, '.', 1) = 'Tradeshow' THEN 1
	                else 0
	            END AS FLAG_ACTMEA_INFL_TOUCHPOINT_BY_ACQTOPLEVELCHANNEL_TRADESHOW,
	            CASE
	                WHEN infl_data.MARKETING_TOUCHPOINT_DATE <= amlh_opp.AMLH_MEA_DATE_STAMP__C
	                AND SPLIT_PART(infl_data.INFLUENCE_CHANNEL, '.', 1) = 'Web Referral' THEN 1
	                else 0
	            END AS FLAG_ACTMEA_INFL_TOUCHPOINT_BY_ACQTOPLEVELCHANNEL_WEBREFERRAL,
	            CASE
	                WHEN infl_data.MARKETING_TOUCHPOINT_DATE <= amlh_opp.AMLH_MEA_DATE_STAMP__C
	                AND SPLIT_PART(infl_data.INFLUENCE_CHANNEL, '.', 1) = 'Webinar' THEN 1
	                else 0
	            END AS FLAG_ACTMEA_INFL_TOUCHPOINT_BY_ACQTOPLEVELCHANNEL_WEBINAR,
	            -- Influence Before Act MQA
	            CASE
	                WHEN infl_data.MARKETING_TOUCHPOINT_DATE <= amlh_opp.AMLH_MQA_DATE_STAMP__C
	                AND SPLIT_PART(infl_data.INFLUENCE_CHANNEL, '.', 1) = 'Channel Referral' THEN 1
	                else 0
	            END AS FLAG_ACTMQA_INFL_TOUCHPOINT_BY_ACQTOPLEVELCHANNEL_CHANNELREFERRAL,
	            CASE
	                WHEN infl_data.MARKETING_TOUCHPOINT_DATE <= amlh_opp.AMLH_MQA_DATE_STAMP__C
	                AND SPLIT_PART(infl_data.INFLUENCE_CHANNEL, '.', 1) = 'Content Syndication' THEN 1
	                else 0
	            END AS FLAG_ACTMQA_INFL_TOUCHPOINT_BY_ACQTOPLEVELCHANNEL_CONTENTSYNDICATION,
	            CASE
	                WHEN infl_data.MARKETING_TOUCHPOINT_DATE <= amlh_opp.AMLH_MQA_DATE_STAMP__C
	                AND SPLIT_PART(infl_data.INFLUENCE_CHANNEL, '.', 1) = 'Sales Engagement' THEN 1
	                else 0
	            END AS FLAG_ACTMQA_INFL_TOUCHPOINT_BY_ACQTOPLEVELCHANNEL_SALESENGAGEMENT,
	            CASE
	                WHEN infl_data.MARKETING_TOUCHPOINT_DATE <= amlh_opp.AMLH_MQA_DATE_STAMP__C
	                AND SPLIT_PART(infl_data.INFLUENCE_CHANNEL, '.', 1) = 'Direct' THEN 1
	                else 0
	            END AS FLAG_ACTMQA_INFL_TOUCHPOINT_BY_ACQTOPLEVELCHANNEL_DIRECT,
	            CASE
	                WHEN infl_data.MARKETING_TOUCHPOINT_DATE <= amlh_opp.AMLH_MQA_DATE_STAMP__C
	                AND SPLIT_PART(infl_data.INFLUENCE_CHANNEL, '.', 1) = 'Direct Mail' THEN 1
	                else 0
	            END AS FLAG_ACTMQA_INFL_TOUCHPOINT_BY_ACQTOPLEVELCHANNEL_DIRECTMAIL,
	            CASE
	                WHEN infl_data.MARKETING_TOUCHPOINT_DATE <= amlh_opp.AMLH_MQA_DATE_STAMP__C
	                AND SPLIT_PART(infl_data.INFLUENCE_CHANNEL, '.', 1) = 'Display' THEN 1
	                else 0
	            END AS FLAG_ACTMQA_INFL_TOUCHPOINT_BY_ACQTOPLEVELCHANNEL_DISPLAY,
	            CASE
	                WHEN infl_data.MARKETING_TOUCHPOINT_DATE <= amlh_opp.AMLH_MQA_DATE_STAMP__C
	                AND SPLIT_PART(infl_data.INFLUENCE_CHANNEL, '.', 1) = 'Email' THEN 1
	                else 0
	            END AS FLAG_ACTMQA_INFL_TOUCHPOINT_BY_ACQTOPLEVELCHANNEL_EMAIL,
	            CASE
	                WHEN infl_data.MARKETING_TOUCHPOINT_DATE <= amlh_opp.AMLH_MQA_DATE_STAMP__C
	                AND SPLIT_PART(infl_data.INFLUENCE_CHANNEL, '.', 1) = 'Lead Referral' THEN 1
	                else 0
	            END AS FLAG_ACTMQA_INFL_TOUCHPOINT_BY_ACQTOPLEVELCHANNEL_LEADREFERRAL,
	            CASE
	                WHEN infl_data.MARKETING_TOUCHPOINT_DATE <= amlh_opp.AMLH_MQA_DATE_STAMP__C
	                AND SPLIT_PART(infl_data.INFLUENCE_CHANNEL, '.', 1) = 'Live Event' THEN 1
	                else 0
	            END AS FLAG_ACTMQA_INFL_TOUCHPOINT_BY_ACQTOPLEVELCHANNEL_LIVEEVENT,
	            CASE
	                WHEN infl_data.MARKETING_TOUCHPOINT_DATE <= amlh_opp.AMLH_MQA_DATE_STAMP__C
	                AND SPLIT_PART(infl_data.INFLUENCE_CHANNEL, '.', 1) = 'Lytx' THEN 1
	                else 0
	            END AS FLAG_ACTMQA_INFL_TOUCHPOINT_BY_ACQTOPLEVELCHANNEL_LYTX,
	            CASE
	                WHEN infl_data.MARKETING_TOUCHPOINT_DATE <= amlh_opp.AMLH_MQA_DATE_STAMP__C
	                AND SPLIT_PART(infl_data.INFLUENCE_CHANNEL, '.', 1) = 'Native' THEN 1
	                else 0
	            END AS FLAG_ACTMQA_INFL_TOUCHPOINT_BY_ACQTOPLEVELCHANNEL_NATIVE,
	            CASE
	                WHEN infl_data.MARKETING_TOUCHPOINT_DATE <= amlh_opp.AMLH_MQA_DATE_STAMP__C
	                AND SPLIT_PART(infl_data.INFLUENCE_CHANNEL, '.', 1) = 'Organic Search' THEN 1
	                else 0
	            END AS FLAG_ACTMQA_INFL_TOUCHPOINT_BY_ACQTOPLEVELCHANNEL_ORGANICSEARCH,
	            CASE
	                WHEN infl_data.MARKETING_TOUCHPOINT_DATE <= amlh_opp.AMLH_MQA_DATE_STAMP__C
	                AND SPLIT_PART(infl_data.INFLUENCE_CHANNEL, '.', 1) = 'Organic Social' THEN 1
	                else 0
	            END AS FLAG_ACTMQA_INFL_TOUCHPOINT_BY_ACQTOPLEVELCHANNEL_ORGANICSOCIAL,
	            CASE
	                WHEN infl_data.MARKETING_TOUCHPOINT_DATE <= amlh_opp.AMLH_MQA_DATE_STAMP__C
	                AND SPLIT_PART(infl_data.INFLUENCE_CHANNEL, '.', 1) = 'Other' THEN 1
	                else 0
	            END AS FLAG_ACTMQA_INFL_TOUCHPOINT_BY_ACQTOPLEVELCHANNEL_OTHER,
	            CASE
	                WHEN infl_data.MARKETING_TOUCHPOINT_DATE <= amlh_opp.AMLH_MQA_DATE_STAMP__C
	                AND SPLIT_PART(infl_data.INFLUENCE_CHANNEL, '.', 1) = 'Paid Media' THEN 1
	                else 0
	            END AS FLAG_ACTMQA_INFL_TOUCHPOINT_BY_ACQTOPLEVELCHANNEL_PAIDMEDIA,
	            CASE
	                WHEN infl_data.MARKETING_TOUCHPOINT_DATE <= amlh_opp.AMLH_MQA_DATE_STAMP__C
	                AND SPLIT_PART(infl_data.INFLUENCE_CHANNEL, '.', 1) = 'Paid Search' THEN 1
	                else 0
	            END AS FLAG_ACTMQA_INFL_TOUCHPOINT_BY_ACQTOPLEVELCHANNEL_PAIDSEARCH,
	            CASE
	                WHEN infl_data.MARKETING_TOUCHPOINT_DATE <= amlh_opp.AMLH_MQA_DATE_STAMP__C
	                AND SPLIT_PART(infl_data.INFLUENCE_CHANNEL, '.', 1) = 'Paid Social' THEN 1
	                else 0
	            END AS FLAG_ACTMQA_INFL_TOUCHPOINT_BY_ACQTOPLEVELCHANNEL_PAIDSOCIAL,
	            CASE
	                WHEN infl_data.MARKETING_TOUCHPOINT_DATE <= amlh_opp.AMLH_MQA_DATE_STAMP__C
	                AND SPLIT_PART(infl_data.INFLUENCE_CHANNEL, '.', 1) = 'Podcast' THEN 1
	                else 0
	            END AS FLAG_ACTMQA_INFL_TOUCHPOINT_BY_ACQTOPLEVELCHANNEL_PODCAST,
	            CASE
	                WHEN infl_data.MARKETING_TOUCHPOINT_DATE <= amlh_opp.AMLH_MQA_DATE_STAMP__C
	                AND SPLIT_PART(infl_data.INFLUENCE_CHANNEL, '.', 1) = 'PPL' THEN 1
	                else 0
	            END AS FLAG_ACTMQA_INFL_TOUCHPOINT_BY_ACQTOPLEVELCHANNEL_PPL,
	            CASE
	                WHEN infl_data.MARKETING_TOUCHPOINT_DATE <= amlh_opp.AMLH_MQA_DATE_STAMP__C
	                AND SPLIT_PART(infl_data.INFLUENCE_CHANNEL, '.', 1) = 'Print' THEN 1
	                else 0
	            END AS FLAG_ACTMQA_INFL_TOUCHPOINT_BY_ACQTOPLEVELCHANNEL_PRINT,
	            CASE
	                WHEN infl_data.MARKETING_TOUCHPOINT_DATE <= amlh_opp.AMLH_MQA_DATE_STAMP__C
	                AND SPLIT_PART(infl_data.INFLUENCE_CHANNEL, '.', 1) = 'Sponsored Email' THEN 1
	                else 0
	            END AS FLAG_ACTMQA_INFL_TOUCHPOINT_BY_ACQTOPLEVELCHANNEL_SPONSOREDEMAIL,
	            CASE
	                WHEN infl_data.MARKETING_TOUCHPOINT_DATE <= amlh_opp.AMLH_MQA_DATE_STAMP__C
	                AND SPLIT_PART(infl_data.INFLUENCE_CHANNEL, '.', 1) = 'Tradeshow' THEN 1
	                else 0
	            END AS FLAG_ACTMQA_INFL_TOUCHPOINT_BY_ACQTOPLEVELCHANNEL_TRADESHOW,
	            CASE
	                WHEN infl_data.MARKETING_TOUCHPOINT_DATE <= amlh_opp.AMLH_MQA_DATE_STAMP__C
	                AND SPLIT_PART(infl_data.INFLUENCE_CHANNEL, '.', 1) = 'Web Referral' THEN 1
	                else 0
	            END AS FLAG_ACTMQA_INFL_TOUCHPOINT_BY_ACQTOPLEVELCHANNEL_WEBREFERRAL,
	            CASE
	                WHEN infl_data.MARKETING_TOUCHPOINT_DATE <= amlh_opp.AMLH_MQA_DATE_STAMP__C
	                AND SPLIT_PART(infl_data.INFLUENCE_CHANNEL, '.', 1) = 'Webinar' THEN 1
	                else 0
	            END AS FLAG_ACTMQA_INFL_TOUCHPOINT_BY_ACQTOPLEVELCHANNEL_WEBINAR,
	            -- Influence Before Act SUSPECT
	            CASE
	                WHEN infl_data.MARKETING_TOUCHPOINT_DATE <= amlh_opp.AMLH_SUSPECT_DATE_STAMP__C
	                AND SPLIT_PART(infl_data.INFLUENCE_CHANNEL, '.', 1) = 'Channel Referral' THEN 1
	                else 0
	            END AS FLAG_ACTSUSPECT_INFL_TOUCHPOINT_BY_ACQTOPLEVELCHANNEL_CHANNELREFERRAL,
	            CASE
	                WHEN infl_data.MARKETING_TOUCHPOINT_DATE <= amlh_opp.AMLH_SUSPECT_DATE_STAMP__C
	                AND SPLIT_PART(infl_data.INFLUENCE_CHANNEL, '.', 1) = 'Content Syndication' THEN 1
	                else 0
	            END AS FLAG_ACTSUSPECT_INFL_TOUCHPOINT_BY_ACQTOPLEVELCHANNEL_CONTENTSYNDICATION,
	            CASE
	                WHEN infl_data.MARKETING_TOUCHPOINT_DATE <= amlh_opp.AMLH_SUSPECT_DATE_STAMP__C
	                AND SPLIT_PART(infl_data.INFLUENCE_CHANNEL, '.', 1) = 'Sales Engagement' THEN 1
	                else 0
	            END AS FLAG_ACTSUSPECT_INFL_TOUCHPOINT_BY_ACQTOPLEVELCHANNEL_SALESENGAGEMENT,
	            CASE
	                WHEN infl_data.MARKETING_TOUCHPOINT_DATE <= amlh_opp.AMLH_SUSPECT_DATE_STAMP__C
	                AND SPLIT_PART(infl_data.INFLUENCE_CHANNEL, '.', 1) = 'Direct' THEN 1
	                else 0
	            END AS FLAG_ACTSUSPECT_INFL_TOUCHPOINT_BY_ACQTOPLEVELCHANNEL_DIRECT,
	            CASE
	                WHEN infl_data.MARKETING_TOUCHPOINT_DATE <= amlh_opp.AMLH_SUSPECT_DATE_STAMP__C
	                AND SPLIT_PART(infl_data.INFLUENCE_CHANNEL, '.', 1) = 'Direct Mail' THEN 1
	                else 0
	            END AS FLAG_ACTSUSPECT_INFL_TOUCHPOINT_BY_ACQTOPLEVELCHANNEL_DIRECTMAIL,
	            CASE
	                WHEN infl_data.MARKETING_TOUCHPOINT_DATE <= amlh_opp.AMLH_SUSPECT_DATE_STAMP__C
	                AND SPLIT_PART(infl_data.INFLUENCE_CHANNEL, '.', 1) = 'Display' THEN 1
	                else 0
	            END AS FLAG_ACTSUSPECT_INFL_TOUCHPOINT_BY_ACQTOPLEVELCHANNEL_DISPLAY,
	            CASE
	                WHEN infl_data.MARKETING_TOUCHPOINT_DATE <= amlh_opp.AMLH_SUSPECT_DATE_STAMP__C
	                AND SPLIT_PART(infl_data.INFLUENCE_CHANNEL, '.', 1) = 'Email' THEN 1
	                else 0
	            END AS FLAG_ACTSUSPECT_INFL_TOUCHPOINT_BY_ACQTOPLEVELCHANNEL_EMAIL,
	            CASE
	                WHEN infl_data.MARKETING_TOUCHPOINT_DATE <= amlh_opp.AMLH_SUSPECT_DATE_STAMP__C
	                AND SPLIT_PART(infl_data.INFLUENCE_CHANNEL, '.', 1) = 'Lead Referral' THEN 1
	                else 0
	            END AS FLAG_ACTSUSPECT_INFL_TOUCHPOINT_BY_ACQTOPLEVELCHANNEL_LEADREFERRAL,
	            CASE
	                WHEN infl_data.MARKETING_TOUCHPOINT_DATE <= amlh_opp.AMLH_SUSPECT_DATE_STAMP__C
	                AND SPLIT_PART(infl_data.INFLUENCE_CHANNEL, '.', 1) = 'Live Event' THEN 1
	                else 0
	            END AS FLAG_ACTSUSPECT_INFL_TOUCHPOINT_BY_ACQTOPLEVELCHANNEL_LIVEEVENT,
	            CASE
	                WHEN infl_data.MARKETING_TOUCHPOINT_DATE <= amlh_opp.AMLH_SUSPECT_DATE_STAMP__C
	                AND SPLIT_PART(infl_data.INFLUENCE_CHANNEL, '.', 1) = 'Lytx' THEN 1
	                else 0
	            END AS FLAG_ACTSUSPECT_INFL_TOUCHPOINT_BY_ACQTOPLEVELCHANNEL_LYTX,
	            CASE
	                WHEN infl_data.MARKETING_TOUCHPOINT_DATE <= amlh_opp.AMLH_SUSPECT_DATE_STAMP__C
	                AND SPLIT_PART(infl_data.INFLUENCE_CHANNEL, '.', 1) = 'Native' THEN 1
	                else 0
	            END AS FLAG_ACTSUSPECT_INFL_TOUCHPOINT_BY_ACQTOPLEVELCHANNEL_NATIVE,
	            CASE
	                WHEN infl_data.MARKETING_TOUCHPOINT_DATE <= amlh_opp.AMLH_SUSPECT_DATE_STAMP__C
	                AND SPLIT_PART(infl_data.INFLUENCE_CHANNEL, '.', 1) = 'Organic Search' THEN 1
	                else 0
	            END AS FLAG_ACTSUSPECT_INFL_TOUCHPOINT_BY_ACQTOPLEVELCHANNEL_ORGANICSEARCH,
	            CASE
	                WHEN infl_data.MARKETING_TOUCHPOINT_DATE <= amlh_opp.AMLH_SUSPECT_DATE_STAMP__C
	                AND SPLIT_PART(infl_data.INFLUENCE_CHANNEL, '.', 1) = 'Organic Social' THEN 1
	                else 0
	            END AS FLAG_ACTSUSPECT_INFL_TOUCHPOINT_BY_ACQTOPLEVELCHANNEL_ORGANICSOCIAL,
	            CASE
	                WHEN infl_data.MARKETING_TOUCHPOINT_DATE <= amlh_opp.AMLH_SUSPECT_DATE_STAMP__C
	                AND SPLIT_PART(infl_data.INFLUENCE_CHANNEL, '.', 1) = 'Other' THEN 1
	                else 0
	            END AS FLAG_ACTSUSPECT_INFL_TOUCHPOINT_BY_ACQTOPLEVELCHANNEL_OTHER,
	            CASE
	                WHEN infl_data.MARKETING_TOUCHPOINT_DATE <= amlh_opp.AMLH_SUSPECT_DATE_STAMP__C
	                AND SPLIT_PART(infl_data.INFLUENCE_CHANNEL, '.', 1) = 'Paid Media' THEN 1
	                else 0
	            END AS FLAG_ACTSUSPECT_INFL_TOUCHPOINT_BY_ACQTOPLEVELCHANNEL_PAIDMEDIA,
	            CASE
	                WHEN infl_data.MARKETING_TOUCHPOINT_DATE <= amlh_opp.AMLH_SUSPECT_DATE_STAMP__C
	                AND SPLIT_PART(infl_data.INFLUENCE_CHANNEL, '.', 1) = 'Paid Search' THEN 1
	                else 0
	            END AS FLAG_ACTSUSPECT_INFL_TOUCHPOINT_BY_ACQTOPLEVELCHANNEL_PAIDSEARCH,
	            CASE
	                WHEN infl_data.MARKETING_TOUCHPOINT_DATE <= amlh_opp.AMLH_SUSPECT_DATE_STAMP__C
	                AND SPLIT_PART(infl_data.INFLUENCE_CHANNEL, '.', 1) = 'Paid Social' THEN 1
	                else 0
	            END AS FLAG_ACTSUSPECT_INFL_TOUCHPOINT_BY_ACQTOPLEVELCHANNEL_PAIDSOCIAL,
	            CASE
	                WHEN infl_data.MARKETING_TOUCHPOINT_DATE <= amlh_opp.AMLH_SUSPECT_DATE_STAMP__C
	                AND SPLIT_PART(infl_data.INFLUENCE_CHANNEL, '.', 1) = 'Podcast' THEN 1
	                else 0
	            END AS FLAG_ACTSUSPECT_INFL_TOUCHPOINT_BY_ACQTOPLEVELCHANNEL_PODCAST,
	            CASE
	                WHEN infl_data.MARKETING_TOUCHPOINT_DATE <= amlh_opp.AMLH_SUSPECT_DATE_STAMP__C
	                AND SPLIT_PART(infl_data.INFLUENCE_CHANNEL, '.', 1) = 'PPL' THEN 1
	                else 0
	            END AS FLAG_ACTSUSPECT_INFL_TOUCHPOINT_BY_ACQTOPLEVELCHANNEL_PPL,
	            CASE
	                WHEN infl_data.MARKETING_TOUCHPOINT_DATE <= amlh_opp.AMLH_SUSPECT_DATE_STAMP__C
	                AND SPLIT_PART(infl_data.INFLUENCE_CHANNEL, '.', 1) = 'Print' THEN 1
	                else 0
	            END AS FLAG_ACTSUSPECT_INFL_TOUCHPOINT_BY_ACQTOPLEVELCHANNEL_PRINT,
	            CASE
	                WHEN infl_data.MARKETING_TOUCHPOINT_DATE <= amlh_opp.AMLH_SUSPECT_DATE_STAMP__C
	                AND SPLIT_PART(infl_data.INFLUENCE_CHANNEL, '.', 1) = 'Sponsored Email' THEN 1
	                else 0
	            END AS FLAG_ACTSUSPECT_INFL_TOUCHPOINT_BY_ACQTOPLEVELCHANNEL_SPONSOREDEMAIL,
	            CASE
	                WHEN infl_data.MARKETING_TOUCHPOINT_DATE <= amlh_opp.AMLH_SUSPECT_DATE_STAMP__C
	                AND SPLIT_PART(infl_data.INFLUENCE_CHANNEL, '.', 1) = 'Tradeshow' THEN 1
	                else 0
	            END AS FLAG_ACTSUSPECT_INFL_TOUCHPOINT_BY_ACQTOPLEVELCHANNEL_TRADESHOW,
	            CASE
	                WHEN infl_data.MARKETING_TOUCHPOINT_DATE <= amlh_opp.AMLH_SUSPECT_DATE_STAMP__C
	                AND SPLIT_PART(infl_data.INFLUENCE_CHANNEL, '.', 1) = 'Web Referral' THEN 1
	                else 0
	            END AS FLAG_ACTSUSPECT_INFL_TOUCHPOINT_BY_ACQTOPLEVELCHANNEL_WEBREFERRAL,
	            CASE
	                WHEN infl_data.MARKETING_TOUCHPOINT_DATE <= amlh_opp.AMLH_SUSPECT_DATE_STAMP__C
	                AND SPLIT_PART(infl_data.INFLUENCE_CHANNEL, '.', 1) = 'Webinar' THEN 1
	                else 0
	            END AS FLAG_ACTSUSPECT_INFL_TOUCHPOINT_BY_ACQTOPLEVELCHANNEL_WEBINAR,
	            -- Influence Before Act PROSPECT
	            CASE
	                WHEN infl_data.MARKETING_TOUCHPOINT_DATE <= amlh_opp.AMLH_PROSPECT_DATE_STAMP__C
	                AND SPLIT_PART(infl_data.INFLUENCE_CHANNEL, '.', 1) = 'Channel Referral' THEN 1
	                else 0
	            END AS FLAG_ACTPROSPECT_INFL_TOUCHPOINT_BY_ACQTOPLEVELCHANNEL_CHANNELREFERRAL,
	            CASE
	                WHEN infl_data.MARKETING_TOUCHPOINT_DATE <= amlh_opp.AMLH_PROSPECT_DATE_STAMP__C
	                AND SPLIT_PART(infl_data.INFLUENCE_CHANNEL, '.', 1) = 'Content Syndication' THEN 1
	                else 0
	            END AS FLAG_ACTPROSPECT_INFL_TOUCHPOINT_BY_ACQTOPLEVELCHANNEL_CONTENTSYNDICATION,
	            CASE
	                WHEN infl_data.MARKETING_TOUCHPOINT_DATE <= amlh_opp.AMLH_PROSPECT_DATE_STAMP__C
	                AND SPLIT_PART(infl_data.INFLUENCE_CHANNEL, '.', 1) = 'Sales Engagement' THEN 1
	                else 0
	            END AS FLAG_ACTPROSPECT_INFL_TOUCHPOINT_BY_ACQTOPLEVELCHANNEL_SALESENGAGEMENT,
	            CASE
	                WHEN infl_data.MARKETING_TOUCHPOINT_DATE <= amlh_opp.AMLH_PROSPECT_DATE_STAMP__C
	                AND SPLIT_PART(infl_data.INFLUENCE_CHANNEL, '.', 1) = 'Direct' THEN 1
	                else 0
	            END AS FLAG_ACTPROSPECT_INFL_TOUCHPOINT_BY_ACQTOPLEVELCHANNEL_DIRECT,
	            CASE
	                WHEN infl_data.MARKETING_TOUCHPOINT_DATE <= amlh_opp.AMLH_PROSPECT_DATE_STAMP__C
	                AND SPLIT_PART(infl_data.INFLUENCE_CHANNEL, '.', 1) = 'Direct Mail' THEN 1
	                else 0
	            END AS FLAG_ACTPROSPECT_INFL_TOUCHPOINT_BY_ACQTOPLEVELCHANNEL_DIRECTMAIL,
	            CASE
	                WHEN infl_data.MARKETING_TOUCHPOINT_DATE <= amlh_opp.AMLH_PROSPECT_DATE_STAMP__C
	                AND SPLIT_PART(infl_data.INFLUENCE_CHANNEL, '.', 1) = 'Display' THEN 1
	                else 0
	            END AS FLAG_ACTPROSPECT_INFL_TOUCHPOINT_BY_ACQTOPLEVELCHANNEL_DISPLAY,
	            CASE
	                WHEN infl_data.MARKETING_TOUCHPOINT_DATE <= amlh_opp.AMLH_PROSPECT_DATE_STAMP__C
	                AND SPLIT_PART(infl_data.INFLUENCE_CHANNEL, '.', 1) = 'Email' THEN 1
	                else 0
	            END AS FLAG_ACTPROSPECT_INFL_TOUCHPOINT_BY_ACQTOPLEVELCHANNEL_EMAIL,
	            CASE
	                WHEN infl_data.MARKETING_TOUCHPOINT_DATE <= amlh_opp.AMLH_PROSPECT_DATE_STAMP__C
	                AND SPLIT_PART(infl_data.INFLUENCE_CHANNEL, '.', 1) = 'Lead Referral' THEN 1
	                else 0
	            END AS FLAG_ACTPROSPECT_INFL_TOUCHPOINT_BY_ACQTOPLEVELCHANNEL_LEADREFERRAL,
	            CASE
	                WHEN infl_data.MARKETING_TOUCHPOINT_DATE <= amlh_opp.AMLH_PROSPECT_DATE_STAMP__C
	                AND SPLIT_PART(infl_data.INFLUENCE_CHANNEL, '.', 1) = 'Live Event' THEN 1
	                else 0
	            END AS FLAG_ACTPROSPECT_INFL_TOUCHPOINT_BY_ACQTOPLEVELCHANNEL_LIVEEVENT,
	            CASE
	                WHEN infl_data.MARKETING_TOUCHPOINT_DATE <= amlh_opp.AMLH_PROSPECT_DATE_STAMP__C
	                AND SPLIT_PART(infl_data.INFLUENCE_CHANNEL, '.', 1) = 'Lytx' THEN 1
	                else 0
	            END AS FLAG_ACTPROSPECT_INFL_TOUCHPOINT_BY_ACQTOPLEVELCHANNEL_LYTX,
	            CASE
	                WHEN infl_data.MARKETING_TOUCHPOINT_DATE <= amlh_opp.AMLH_PROSPECT_DATE_STAMP__C
	                AND SPLIT_PART(infl_data.INFLUENCE_CHANNEL, '.', 1) = 'Native' THEN 1
	                else 0
	            END AS FLAG_ACTPROSPECT_INFL_TOUCHPOINT_BY_ACQTOPLEVELCHANNEL_NATIVE,
	            CASE
	                WHEN infl_data.MARKETING_TOUCHPOINT_DATE <= amlh_opp.AMLH_PROSPECT_DATE_STAMP__C
	                AND SPLIT_PART(infl_data.INFLUENCE_CHANNEL, '.', 1) = 'Organic Search' THEN 1
	                else 0
	            END AS FLAG_ACTPROSPECT_INFL_TOUCHPOINT_BY_ACQTOPLEVELCHANNEL_ORGANICSEARCH,
	            CASE
	                WHEN infl_data.MARKETING_TOUCHPOINT_DATE <= amlh_opp.AMLH_PROSPECT_DATE_STAMP__C
	                AND SPLIT_PART(infl_data.INFLUENCE_CHANNEL, '.', 1) = 'Organic Social' THEN 1
	                else 0
	            END AS FLAG_ACTPROSPECT_INFL_TOUCHPOINT_BY_ACQTOPLEVELCHANNEL_ORGANICSOCIAL,
	            CASE
	                WHEN infl_data.MARKETING_TOUCHPOINT_DATE <= amlh_opp.AMLH_PROSPECT_DATE_STAMP__C
	                AND SPLIT_PART(infl_data.INFLUENCE_CHANNEL, '.', 1) = 'Other' THEN 1
	                else 0
	            END AS FLAG_ACTPROSPECT_INFL_TOUCHPOINT_BY_ACQTOPLEVELCHANNEL_OTHER,
	            CASE
	                WHEN infl_data.MARKETING_TOUCHPOINT_DATE <= amlh_opp.AMLH_PROSPECT_DATE_STAMP__C
	                AND SPLIT_PART(infl_data.INFLUENCE_CHANNEL, '.', 1) = 'Paid Media' THEN 1
	                else 0
	            END AS FLAG_ACTPROSPECT_INFL_TOUCHPOINT_BY_ACQTOPLEVELCHANNEL_PAIDMEDIA,
	            CASE
	                WHEN infl_data.MARKETING_TOUCHPOINT_DATE <= amlh_opp.AMLH_PROSPECT_DATE_STAMP__C
	                AND SPLIT_PART(infl_data.INFLUENCE_CHANNEL, '.', 1) = 'Paid Search' THEN 1
	                else 0
	            END AS FLAG_ACTPROSPECT_INFL_TOUCHPOINT_BY_ACQTOPLEVELCHANNEL_PAIDSEARCH,
	            CASE
	                WHEN infl_data.MARKETING_TOUCHPOINT_DATE <= amlh_opp.AMLH_PROSPECT_DATE_STAMP__C
	                AND SPLIT_PART(infl_data.INFLUENCE_CHANNEL, '.', 1) = 'Paid Social' THEN 1
	                else 0
	            END AS FLAG_ACTPROSPECT_INFL_TOUCHPOINT_BY_ACQTOPLEVELCHANNEL_PAIDSOCIAL,
	            CASE
	                WHEN infl_data.MARKETING_TOUCHPOINT_DATE <= amlh_opp.AMLH_PROSPECT_DATE_STAMP__C
	                AND SPLIT_PART(infl_data.INFLUENCE_CHANNEL, '.', 1) = 'Podcast' THEN 1
	                else 0
	            END AS FLAG_ACTPROSPECT_INFL_TOUCHPOINT_BY_ACQTOPLEVELCHANNEL_PODCAST,
	            CASE
	                WHEN infl_data.MARKETING_TOUCHPOINT_DATE <= amlh_opp.AMLH_PROSPECT_DATE_STAMP__C
	                AND SPLIT_PART(infl_data.INFLUENCE_CHANNEL, '.', 1) = 'PPL' THEN 1
	                else 0
	            END AS FLAG_ACTPROSPECT_INFL_TOUCHPOINT_BY_ACQTOPLEVELCHANNEL_PPL,
	            CASE
	                WHEN infl_data.MARKETING_TOUCHPOINT_DATE <= amlh_opp.AMLH_PROSPECT_DATE_STAMP__C
	                AND SPLIT_PART(infl_data.INFLUENCE_CHANNEL, '.', 1) = 'Print' THEN 1
	                else 0
	            END AS FLAG_ACTPROSPECT_INFL_TOUCHPOINT_BY_ACQTOPLEVELCHANNEL_PRINT,
	            CASE
	                WHEN infl_data.MARKETING_TOUCHPOINT_DATE <= amlh_opp.AMLH_PROSPECT_DATE_STAMP__C
	                AND SPLIT_PART(infl_data.INFLUENCE_CHANNEL, '.', 1) = 'Sponsored Email' THEN 1
	                else 0
	            END AS FLAG_ACTPROSPECT_INFL_TOUCHPOINT_BY_ACQTOPLEVELCHANNEL_SPONSOREDEMAIL,
	            CASE
	                WHEN infl_data.MARKETING_TOUCHPOINT_DATE <= amlh_opp.AMLH_PROSPECT_DATE_STAMP__C
	                AND SPLIT_PART(infl_data.INFLUENCE_CHANNEL, '.', 1) = 'Tradeshow' THEN 1
	                else 0
	            END AS FLAG_ACTPROSPECT_INFL_TOUCHPOINT_BY_ACQTOPLEVELCHANNEL_TRADESHOW,
	            CASE
	                WHEN infl_data.MARKETING_TOUCHPOINT_DATE <= amlh_opp.AMLH_PROSPECT_DATE_STAMP__C
	                AND SPLIT_PART(infl_data.INFLUENCE_CHANNEL, '.', 1) = 'Web Referral' THEN 1
	                else 0
	            END AS FLAG_ACTPROSPECT_INFL_TOUCHPOINT_BY_ACQTOPLEVELCHANNEL_WEBREFERRAL,
	            CASE
	                WHEN infl_data.MARKETING_TOUCHPOINT_DATE <= amlh_opp.AMLH_PROSPECT_DATE_STAMP__C
	                AND SPLIT_PART(infl_data.INFLUENCE_CHANNEL, '.', 1) = 'Webinar' THEN 1
	                else 0
	            END AS FLAG_ACTPROSPECT_INFL_TOUCHPOINT_BY_ACQTOPLEVELCHANNEL_WEBINAR,
	            CASE
	                WHEN SPLIT_PART(infl_data.INFLUENCE_CHANNEL, '.', 1) = 'Channel Referral' THEN 1
	                else 0
	            END AS FLAG_HAS_TOUCHPOINT_BY_ACQTOPLEVELCHANNEL_CHANNELREFERRAL,
	            CASE
	                WHEN SPLIT_PART(infl_data.INFLUENCE_CHANNEL, '.', 1) = 'Content Syndication' THEN 1
	                else 0
	            END AS FLAG_HAS_TOUCHPOINT_BY_ACQTOPLEVELCHANNEL_CONTENTSYNDICATION,
	            CASE
	                WHEN SPLIT_PART(infl_data.INFLUENCE_CHANNEL, '.', 1) = 'Sales Engagement' THEN 1
	                else 0
	            END AS FLAG_HAS_TOUCHPOINT_BY_ACQTOPLEVELCHANNEL_SALESENGAGEMENT,
	            CASE
	                WHEN SPLIT_PART(infl_data.INFLUENCE_CHANNEL, '.', 1) = 'Direct' THEN 1
	                else 0
	            END AS FLAG_HAS_TOUCHPOINT_BY_ACQTOPLEVELCHANNEL_DIRECT,
	            CASE
	                WHEN SPLIT_PART(infl_data.INFLUENCE_CHANNEL, '.', 1) = 'Direct Mail' THEN 1
	                else 0
	            END AS FLAG_HAS_TOUCHPOINT_BY_ACQTOPLEVELCHANNEL_DIRECTMAIL,
	            CASE
	                WHEN SPLIT_PART(infl_data.INFLUENCE_CHANNEL, '.', 1) = 'Display' THEN 1
	                else 0
	            END AS FLAG_HAS_TOUCHPOINT_BY_ACQTOPLEVELCHANNEL_DISPLAY,
	            CASE
	                WHEN SPLIT_PART(infl_data.INFLUENCE_CHANNEL, '.', 1) = 'Email' THEN 1
	                else 0
	            END AS FLAG_HAS_TOUCHPOINT_BY_ACQTOPLEVELCHANNEL_EMAIL,
	            CASE
	                WHEN SPLIT_PART(infl_data.INFLUENCE_CHANNEL, '.', 1) = 'Lead Referral' THEN 1
	                else 0
	            END AS FLAG_HAS_TOUCHPOINT_BY_ACQTOPLEVELCHANNEL_LEADREFERRAL,
	            CASE
	                WHEN SPLIT_PART(infl_data.INFLUENCE_CHANNEL, '.', 1) = 'Live Event' THEN 1
	                else 0
	            END AS FLAG_HAS_TOUCHPOINT_BY_ACQTOPLEVELCHANNEL_LIVEEVENT,
	            CASE
	                WHEN SPLIT_PART(infl_data.INFLUENCE_CHANNEL, '.', 1) = 'Lytx' THEN 1
	                else 0
	            END AS FLAG_HAS_TOUCHPOINT_BY_ACQTOPLEVELCHANNEL_LYTX,
	            CASE
	                WHEN SPLIT_PART(infl_data.INFLUENCE_CHANNEL, '.', 1) = 'Native' THEN 1
	                else 0
	            END AS FLAG_HAS_TOUCHPOINT_BY_ACQTOPLEVELCHANNEL_NATIVE,
	            CASE
	                WHEN SPLIT_PART(infl_data.INFLUENCE_CHANNEL, '.', 1) = 'Organic Search' THEN 1
	                else 0
	            END AS FLAG_HAS_TOUCHPOINT_BY_ACQTOPLEVELCHANNEL_ORGANICSEARCH,
	            CASE
	                WHEN SPLIT_PART(infl_data.INFLUENCE_CHANNEL, '.', 1) = 'Organic Social' THEN 1
	                else 0
	            END AS FLAG_HAS_TOUCHPOINT_BY_ACQTOPLEVELCHANNEL_ORGANICSOCIAL,
	            CASE
	                WHEN SPLIT_PART(infl_data.INFLUENCE_CHANNEL, '.', 1) = 'Other' THEN 1
	                else 0
	            END AS FLAG_HAS_TOUCHPOINT_BY_ACQTOPLEVELCHANNEL_OTHER,
	            CASE
	                WHEN SPLIT_PART(infl_data.INFLUENCE_CHANNEL, '.', 1) = 'Paid Media' THEN 1
	                else 0
	            END AS FLAG_HAS_TOUCHPOINT_BY_ACQTOPLEVELCHANNEL_PAIDMEDIA,
	            CASE
	                WHEN SPLIT_PART(infl_data.INFLUENCE_CHANNEL, '.', 1) = 'Paid Search' THEN 1
	                else 0
	            END AS FLAG_HAS_TOUCHPOINT_BY_ACQTOPLEVELCHANNEL_PAIDSEARCH,
	            CASE
	                WHEN SPLIT_PART(infl_data.INFLUENCE_CHANNEL, '.', 1) = 'Paid Social' THEN 1
	                else 0
	            END AS FLAG_HAS_TOUCHPOINT_BY_ACQTOPLEVELCHANNEL_PAIDSOCIAL,
	            CASE
	                WHEN SPLIT_PART(infl_data.INFLUENCE_CHANNEL, '.', 1) = 'Podcast' THEN 1
	                else 0
	            END AS FLAG_HAS_TOUCHPOINT_BY_ACQTOPLEVELCHANNEL_PODCAST,
	            CASE
	                WHEN SPLIT_PART(infl_data.INFLUENCE_CHANNEL, '.', 1) = 'PPL' THEN 1
	                else 0
	            END AS FLAG_HAS_TOUCHPOINT_BY_ACQTOPLEVELCHANNEL_PPL,
	            CASE
	                WHEN SPLIT_PART(infl_data.INFLUENCE_CHANNEL, '.', 1) = 'Print' THEN 1
	                else 0
	            END AS FLAG_HAS_TOUCHPOINT_BY_ACQTOPLEVELCHANNEL_PRINT,
	            CASE
	                WHEN SPLIT_PART(infl_data.INFLUENCE_CHANNEL, '.', 1) = 'Sponsored Email' THEN 1
	                else 0
	            END AS FLAG_HAS_TOUCHPOINT_BY_ACQTOPLEVELCHANNEL_SPONSOREDEMAIL,
	            CASE
	                WHEN SPLIT_PART(infl_data.INFLUENCE_CHANNEL, '.', 1) = 'Tradeshow' THEN 1
	                else 0
	            END AS FLAG_HAS_TOUCHPOINT_BY_ACQTOPLEVELCHANNEL_TRADESHOW,
	            CASE
	                WHEN SPLIT_PART(infl_data.INFLUENCE_CHANNEL, '.', 1) = 'Web Referral' THEN 1
	                else 0
	            END AS FLAG_HAS_TOUCHPOINT_BY_ACQTOPLEVELCHANNEL_WEBREFERRAL,
	            CASE
	                WHEN SPLIT_PART(infl_data.INFLUENCE_CHANNEL, '.', 1) = 'Webinar' THEN 1
	                else 0
	            END AS FLAG_HAS_TOUCHPOINT_BY_ACQTOPLEVELCHANNEL_WEBINAR
	        FROM
	            DP_PROD_DB.ACT_MRKT_LIFECYCLE.AMLH_OPPS as amlh_opp
	            -- touchtype_analytics_table as source
	            LEFT JOIN DP_PROD_DB.ACT_MRKT_LIFECYCLE.TOUCHTYPE_ANALYTICS as infl_data ON amlh_opp.ACT_ID = infl_data.CRM_ACCOUNT_ID
	        ORDER BY
	            amlh_opp.AMLH_ACCOUNT__C,
	            amlh_opp.AMLH_RECYCLE_COUNTER__C ASC,
	            amlh_opp.AMLH_ACTIVE_MARKETING_LIFECYCLE_RECORD__C DESC,
	            amlh_opp.AMLH_CREATED_DATE,
	            infl_data.MARKETING_TOUCHPOINT_DATE
	    );
	   
	-- Step 05b: Account Marketing Lifecycle History with Opp and Influence Data Aggregated
	   
	 DROP TABLE IF EXISTS DP_PROD_DB.ACT_MRKT_LIFECYCLE.amlh_opp_infl_milestones;
	    CREATE TABLE DP_PROD_DB.ACT_MRKT_LIFECYCLE.amlh_opp_infl_milestones as

	SELECT y.* 

	FROM

	(
	SELECT
	x.AMLH_NAME,
	--x.AMLH_ACT_COUNTER_ID,
	x.ACT_ID,
	x.AMLH_RECYCLE_COUNTER__C,
	x.AMLH_MUTUALLY_EXCLUSIVE_PRE_SUSPECT_DESIGNATION,
	x.AMLH_MUTUALLY_EXCLUSIVE_PRE_SUSPECT_DESIGNATION_DATE,
	x.AMLH_SUSPECT_DATE_STAMP__C_CAST,
	x.MARKETING_TOUCHPOINT_BEFORE_MILESTONE,
	x.MARKETING_TOUCHPOINT_BEFORE_ACT,
	x.MARKETING_TOUCHPOINT_BEFORE_ACT_DATE_MILESTONE_FIELD,
	x.MARKETING_TOUCHPOINT_BEFORE_ACT_DATE_MILESTONE,
	LAST_DAY(x.MARKETING_TOUCHPOINT_BEFORE_ACT_DATE_MILESTONE) as MARKETING_TOUCHPOINT_BEFORE_ACT_DATE_MILESTONE_EOM,
	cast(dateadd(day, -1, dateadd(QTR,1,DATE_TRUNC('QTR', x.MARKETING_TOUCHPOINT_BEFORE_ACT_DATE_MILESTONE)))as date) as MARKETING_TOUCHPOINT_BEFORE_ACT_DATE_MILESTONE_EOQ,
	DATE_PART_YEAR(x.MARKETING_TOUCHPOINT_BEFORE_ACT_DATE_MILESTONE) as MARKETING_TOUCHPOINT_BEFORE_ACT_DATE_MILESTONE_YEAR,
	x.ACT_MARKET_SEGMENT__C,
	x.ACT_MARKET__C,
	x.ACT_BUSINESS_UNIT_DIVISION__C,
	x.INFLUENCE_CHANNEL,
	x.INFLUENCE_CHANNEL_TOPLEVEL,
	x.INFLUENCE_WEB_SOURCE,
	x.INFLUENCE_WEB_MEDIUM,
	x.INFLUENCE_CAMPAIGN_NAME,
	x.INFLUENCE_CREATIVE_NAME,
	x.INFLUENCE_LANDING_PAGE,
	x.INFLUENCE_REFERRER,
	x.WEBVISIT_PAGE,
	x.WEBVISIT_REFERRER,
	x.OPP_CREATED_DATE,
	x.OPP_STAGE_NAME_CATEGORY,
	x.OPP_STAGE_NAME,
	x.OPP_IS_CLOSED,
	x.OPP_IS_WON,
	x.OPP_CLOSE_DATE,
	-- Financial Metrics
	x.OPP_CURRENCY_ISO_CODE,
	x.OPP_CONVERSION_RATE,
	x.OPP_ACV3__C,
	x.OPP_TOTAL_BOOKING_AMOUNT2__C,
	x.OPP_TOTAL_BOOKING_AMOUNT2__C_CONVERTED,
	x.OPP_SUBS_QTY__C,
	x.OPP_BOOKED_SUBS_QTY3__C,
	x.OPP_FORECASTED_SUBS_QTY__C,
	x.OPP_BOOKEDFORECASTED_SUBS_QTY3__C,
	x.OPP_SALES_REPORTING_ACV__C,
	x.OPP_FORECASTED_ACV__C,
	x.OPP_FORECASTED_ARR__C,
	x.OPP_SALES_REPORTING_ARR__C,
	x.OPP_SALES_REPORTING_TOTAL_BOOKING_AMOUNT__C,
	x.OPP_SALES_REPORTING_ACV__C_CONVERTED,
	x.OPP_SALES_REPORTING_TOTAL_BOOKING_AMOUNT__C_CONVERTED,
	x.OPP_SALES_REPORTING_BOOKED_SUBS_QTY__C,

	CASE WHEN MARKETING_TOUCHPOINT_BEFORE_ACT = 1 AND
	(
	x.INTERACTIONTYPE_SIXSENSE_PAIDMEDIA_IMPRESSIONS_COUNT_INFLUENCE_ACT +
	x.INTERACTIONTYPE_SIXSENSE_PAIDMEDIA_CLICKS_COUNT_INFLUENCE_ACT +

	x.INTERACTIONTYPE_SIXSENSE_WEBVISIT_PAGELOAD_COUNT_INFLUENCE_ACT+
	x.INTERACTIONTYPE_SIXSENSE_WEBVISIT_PLAY_COUNT_INFLUENCE_ACT +
	x.INTERACTIONTYPE_SIXSENSE_WEBVISIT_CLICK_COUNT_INFLUENCE_ACT +
	x.INTERACTIONTYPE_SIXSENSE_WEBVISIT_SUBMIT_COUNT_INFLUENCE_ACT +

	x.INTERACTIONTYPE_BIZIBLE_TOUCHPOINT_WEBVISIT_COUNT_INFLUENCE_ACT +
	x.INTERACTIONTYPE_BIZIBLE_TOUCHPOINT_WEBCHAT_COUNT_INFLUENCE_ACT +
	x.INTERACTIONTYPE_BIZIBLE_TOUCHPOINT_WEBFORM_COUNT_INFLUENCE_ACT +
	x.INTERACTIONTYPE_BIZIBLE_TOUCHPOINT_CRM_COUNT_INFLUENCE_ACT +
	x.INTERACTIONTYPE_BIZIBLE_TOUCHPOINT_CONNECTWITHDM_COUNT_INFLUENCE_ACT +
	x.INTERACTIONTYPE_BIZIBLE_TOUCHPOINT_CALLSPOKEWITH_COUNT_INFLUENCE_ACT +
	x.INTERACTIONTYPE_BIZIBLE_TOUCHPOINT_CALLGATEKEEPER_COUNT_INFLUENCE_ACT +
	x.INTERACTIONTYPE_BIZIBLE_TOUCHPOINT_NOLEADTOUCHPOINTS_COUNT_INFLUENCE_ACT
	--x.INTERACTIONTYPE_BIZIBLE_TOUCHPOINT_UNCLASSIFIED_COUNT_INFLUENCE_ACT

	) > 0 THEN 1 ELSE 0 END AS INTERACTIONTYPE_INTERACTION_IMPRESSION_BEFORE_MILESTONE_FLAG,

	CASE WHEN 
	(
	x.INTERACTIONTYPE_SIXSENSE_PAIDMEDIA_IMPRESSIONS_COUNT_INFLUENCE_ACT +
	x.INTERACTIONTYPE_SIXSENSE_PAIDMEDIA_CLICKS_COUNT_INFLUENCE_ACT +

	x.INTERACTIONTYPE_SIXSENSE_WEBVISIT_PAGELOAD_COUNT_INFLUENCE_ACT+
	x.INTERACTIONTYPE_SIXSENSE_WEBVISIT_PLAY_COUNT_INFLUENCE_ACT +
	x.INTERACTIONTYPE_SIXSENSE_WEBVISIT_CLICK_COUNT_INFLUENCE_ACT +
	x.INTERACTIONTYPE_SIXSENSE_WEBVISIT_SUBMIT_COUNT_INFLUENCE_ACT +

	x.INTERACTIONTYPE_BIZIBLE_TOUCHPOINT_WEBVISIT_COUNT_INFLUENCE_ACT +
	x.INTERACTIONTYPE_BIZIBLE_TOUCHPOINT_WEBCHAT_COUNT_INFLUENCE_ACT +
	x.INTERACTIONTYPE_BIZIBLE_TOUCHPOINT_WEBFORM_COUNT_INFLUENCE_ACT +
	x.INTERACTIONTYPE_BIZIBLE_TOUCHPOINT_CRM_COUNT_INFLUENCE_ACT +
	x.INTERACTIONTYPE_BIZIBLE_TOUCHPOINT_CONNECTWITHDM_COUNT_INFLUENCE_ACT +
	x.INTERACTIONTYPE_BIZIBLE_TOUCHPOINT_CALLSPOKEWITH_COUNT_INFLUENCE_ACT +
	x.INTERACTIONTYPE_BIZIBLE_TOUCHPOINT_CALLGATEKEEPER_COUNT_INFLUENCE_ACT +
	x.INTERACTIONTYPE_BIZIBLE_TOUCHPOINT_NOLEADTOUCHPOINTS_COUNT_INFLUENCE_ACT
	--x.INTERACTIONTYPE_BIZIBLE_TOUCHPOINT_UNCLASSIFIED_COUNT_INFLUENCE_ACT

	) > 0 THEN 1 ELSE 0 END AS INTERACTIONTYPE_INTERACTION_IMPRESSION_FLAG,

	CASE WHEN MARKETING_TOUCHPOINT_BEFORE_ACT = 1 AND
	(
	--x.INTERACTIONTYPE_SIXSENSE_PAIDMEDIA_IMPRESSIONS_COUNT_INFLUENCE_ACT +
	x.INTERACTIONTYPE_SIXSENSE_PAIDMEDIA_CLICKS_COUNT_INFLUENCE_ACT +

	x.INTERACTIONTYPE_SIXSENSE_WEBVISIT_PAGELOAD_COUNT_INFLUENCE_ACT+
	x.INTERACTIONTYPE_SIXSENSE_WEBVISIT_PLAY_COUNT_INFLUENCE_ACT +
	x.INTERACTIONTYPE_SIXSENSE_WEBVISIT_CLICK_COUNT_INFLUENCE_ACT +
	x.INTERACTIONTYPE_SIXSENSE_WEBVISIT_SUBMIT_COUNT_INFLUENCE_ACT +

	x.INTERACTIONTYPE_BIZIBLE_TOUCHPOINT_WEBVISIT_COUNT_INFLUENCE_ACT +
	x.INTERACTIONTYPE_BIZIBLE_TOUCHPOINT_WEBCHAT_COUNT_INFLUENCE_ACT +
	x.INTERACTIONTYPE_BIZIBLE_TOUCHPOINT_WEBFORM_COUNT_INFLUENCE_ACT +
	x.INTERACTIONTYPE_BIZIBLE_TOUCHPOINT_CRM_COUNT_INFLUENCE_ACT +
	x.INTERACTIONTYPE_BIZIBLE_TOUCHPOINT_CONNECTWITHDM_COUNT_INFLUENCE_ACT +
	x.INTERACTIONTYPE_BIZIBLE_TOUCHPOINT_CALLSPOKEWITH_COUNT_INFLUENCE_ACT +
	x.INTERACTIONTYPE_BIZIBLE_TOUCHPOINT_CALLGATEKEEPER_COUNT_INFLUENCE_ACT +
	x.INTERACTIONTYPE_BIZIBLE_TOUCHPOINT_NOLEADTOUCHPOINTS_COUNT_INFLUENCE_ACT
	--x.INTERACTIONTYPE_BIZIBLE_TOUCHPOINT_UNCLASSIFIED_COUNT_INFLUENCE_ACT

	) > 0 THEN 1 ELSE 0 END AS INTERACTIONTYPE_INTERACTION_ONLY_BEFORE_MILESTONE_FLAG,

	CASE WHEN 
	(
	--x.INTERACTIONTYPE_SIXSENSE_PAIDMEDIA_IMPRESSIONS_COUNT_INFLUENCE_ACT +
	x.INTERACTIONTYPE_SIXSENSE_PAIDMEDIA_CLICKS_COUNT_INFLUENCE_ACT +

	x.INTERACTIONTYPE_SIXSENSE_WEBVISIT_PAGELOAD_COUNT_INFLUENCE_ACT+
	x.INTERACTIONTYPE_SIXSENSE_WEBVISIT_PLAY_COUNT_INFLUENCE_ACT +
	x.INTERACTIONTYPE_SIXSENSE_WEBVISIT_CLICK_COUNT_INFLUENCE_ACT +
	x.INTERACTIONTYPE_SIXSENSE_WEBVISIT_SUBMIT_COUNT_INFLUENCE_ACT +


	x.INTERACTIONTYPE_BIZIBLE_TOUCHPOINT_WEBVISIT_COUNT_INFLUENCE_ACT +
	x.INTERACTIONTYPE_BIZIBLE_TOUCHPOINT_WEBCHAT_COUNT_INFLUENCE_ACT +
	x.INTERACTIONTYPE_BIZIBLE_TOUCHPOINT_WEBFORM_COUNT_INFLUENCE_ACT +
	x.INTERACTIONTYPE_BIZIBLE_TOUCHPOINT_CRM_COUNT_INFLUENCE_ACT +
	x.INTERACTIONTYPE_BIZIBLE_TOUCHPOINT_CONNECTWITHDM_COUNT_INFLUENCE_ACT +
	x.INTERACTIONTYPE_BIZIBLE_TOUCHPOINT_CALLSPOKEWITH_COUNT_INFLUENCE_ACT +
	x.INTERACTIONTYPE_BIZIBLE_TOUCHPOINT_CALLGATEKEEPER_COUNT_INFLUENCE_ACT +
	x.INTERACTIONTYPE_BIZIBLE_TOUCHPOINT_NOLEADTOUCHPOINTS_COUNT_INFLUENCE_ACT
	--x.INTERACTIONTYPE_BIZIBLE_TOUCHPOINT_UNCLASSIFIED_COUNT_INFLUENCE_ACT

	) > 0 THEN 1 ELSE 0 END AS INTERACTIONTYPE_INTERACTION_ONLY_FLAG,

	-- Individual Breakout Sums

	x.INTERACTIONTYPE_SIXSENSE_PAIDMEDIA_IMPRESSIONS_COUNT_INFLUENCE_ACT,
	x.INTERACTIONTYPE_SIXSENSE_PAIDMEDIA_CLICKS_COUNT_INFLUENCE_ACT,

	x.INTERACTIONTYPE_SIXSENSE_WEBVISIT_TOTAL_INTERACTIONS_COUNT_INFLUENCE_ACT,
	x.INTERACTIONTYPE_SIXSENSE_WEBVISIT_PAGELOAD_COUNT_INFLUENCE_ACT,
	x.INTERACTIONTYPE_SIXSENSE_WEBVISIT_PLAY_COUNT_INFLUENCE_ACT,
	x.INTERACTIONTYPE_SIXSENSE_WEBVISIT_CLICK_COUNT_INFLUENCE_ACT,
	x.INTERACTIONTYPE_SIXSENSE_WEBVISIT_SUBMIT_COUNT_INFLUENCE_ACT,
	x.INTERACTIONTYPE_SIXSENSE_WEBVISIT_UNCLASSIFIED_COUNT_INFLUENCE_ACT,

	x.INTERACTIONTYPE_BIZIBLE_TOUCHPOINT_WEBVISIT_COUNT_INFLUENCE_ACT,
	x.INTERACTIONTYPE_BIZIBLE_TOUCHPOINT_WEBCHAT_COUNT_INFLUENCE_ACT,
	x.INTERACTIONTYPE_BIZIBLE_TOUCHPOINT_WEBFORM_COUNT_INFLUENCE_ACT,
	x.INTERACTIONTYPE_BIZIBLE_TOUCHPOINT_CRM_COUNT_INFLUENCE_ACT,
	x.INTERACTIONTYPE_BIZIBLE_TOUCHPOINT_CONNECTWITHDM_COUNT_INFLUENCE_ACT,
	x.INTERACTIONTYPE_BIZIBLE_TOUCHPOINT_CALLSPOKEWITH_COUNT_INFLUENCE_ACT,
	x.INTERACTIONTYPE_BIZIBLE_TOUCHPOINT_CALLGATEKEEPER_COUNT_INFLUENCE_ACT,
	x.INTERACTIONTYPE_BIZIBLE_TOUCHPOINT_NOLEADTOUCHPOINTS_COUNT_INFLUENCE_ACT,
	x.INTERACTIONTYPE_BIZIBLE_TOUCHPOINT_UNCLASSIFIED_COUNT_INFLUENCE_ACT

	FROM

	(
	-- Touchpoints before MQA Routed
	SELECT
	-- ids
	AMLH_NAME, ACT_ID, AMLH_RECYCLE_COUNTER__C,
	AMLH_MUTUALLY_EXCLUSIVE_PRE_SUSPECT_DESIGNATION,
	AMLH_MUTUALLY_EXCLUSIVE_PRE_SUSPECT_DESIGNATION_DATE,
	AMLH_SUSPECT_DATE_STAMP__C_CAST,

	'MQA - Routed' AS MARKETING_TOUCHPOINT_BEFORE_MILESTONE,
	MARKETING_TOUCHPOINT_BEFORE_ACT_SUSPECT AS MARKETING_TOUCHPOINT_BEFORE_ACT,
	'AMLH_SUSPECT_DATE_STAMP__C_CAST' AS MARKETING_TOUCHPOINT_BEFORE_ACT_DATE_MILESTONE_FIELD, 
	AMLH_SUSPECT_DATE_STAMP__C_CAST AS MARKETING_TOUCHPOINT_BEFORE_ACT_DATE_MILESTONE,

	-- attributes
	ACT_MARKET_SEGMENT__C,
	ACT_MARKET__C,
	ACT_BUSINESS_UNIT_DIVISION__C,
	INFLUENCE_CHANNEL,
	INFLUENCE_CHANNEL_TOPLEVEL,
	INFLUENCE_WEB_SOURCE,
	INFLUENCE_WEB_MEDIUM,
	INFLUENCE_CAMPAIGN_NAME,
	INFLUENCE_CREATIVE_NAME,
	INFLUENCE_LANDING_PAGE,
	INFLUENCE_REFERRER,
	WEBVISIT_PAGE,
	WEBVISIT_REFERRER,
	OPP_CREATED_DATE,
	OPP_STAGE_NAME_CATEGORY,
	OPP_STAGE_NAME,
	OPP_IS_CLOSED,
	OPP_IS_WON,
	OPP_CLOSE_DATE,
	-- Financial Metrics
	OPP_CURRENCY_ISO_CODE,
	OPP_CONVERSION_RATE,
	OPP_ACV3__C,
	OPP_TOTAL_BOOKING_AMOUNT2__C,
	OPP_TOTAL_BOOKING_AMOUNT2__C_CONVERTED,
	OPP_SUBS_QTY__C,
	OPP_BOOKED_SUBS_QTY3__C,
	OPP_FORECASTED_SUBS_QTY__C,
	OPP_BOOKEDFORECASTED_SUBS_QTY3__C,
	OPP_FORECASTED_ACV__C,
	OPP_FORECASTED_ARR__C,
	OPP_SALES_REPORTING_ARR__C,
	OPP_SALES_REPORTING_ACV__C,
	OPP_SALES_REPORTING_TOTAL_BOOKING_AMOUNT__C,
	OPP_SALES_REPORTING_ACV__C_CONVERTED,
	OPP_SALES_REPORTING_TOTAL_BOOKING_AMOUNT__C_CONVERTED,
	OPP_SALES_REPORTING_BOOKED_SUBS_QTY__C,

	-- metrics
	SUM(INTERACTIONTYPE_SIXSENSE_PAIDMEDIA_IMPRESSIONS_COUNT_INFLUENCE_ACTMQA) AS INTERACTIONTYPE_SIXSENSE_PAIDMEDIA_IMPRESSIONS_COUNT_INFLUENCE_ACT,
	SUM(INTERACTIONTYPE_SIXSENSE_PAIDMEDIA_CLICKS_COUNT_INFLUENCE_ACTMQA) AS INTERACTIONTYPE_SIXSENSE_PAIDMEDIA_CLICKS_COUNT_INFLUENCE_ACT,
	SUM(INTERACTIONTYPE_SIXSENSE_WEBVISIT_TOTAL_INTERACTIONS_COUNT_INFLUENCE_ACTMQA) AS INTERACTIONTYPE_SIXSENSE_WEBVISIT_TOTAL_INTERACTIONS_COUNT_INFLUENCE_ACT,
	SUM(INTERACTIONTYPE_SIXSENSE_WEBVISIT_PAGELOAD_COUNT_INFLUENCE_ACTMQA) AS INTERACTIONTYPE_SIXSENSE_WEBVISIT_PAGELOAD_COUNT_INFLUENCE_ACT,
	SUM(INTERACTIONTYPE_SIXSENSE_WEBVISIT_PLAY_COUNT_INFLUENCE_ACTMQA) AS INTERACTIONTYPE_SIXSENSE_WEBVISIT_PLAY_COUNT_INFLUENCE_ACT,
	SUM(INTERACTIONTYPE_SIXSENSE_WEBVISIT_CLICK_COUNT_INFLUENCE_ACTMQA) AS INTERACTIONTYPE_SIXSENSE_WEBVISIT_CLICK_COUNT_INFLUENCE_ACT,
	SUM(INTERACTIONTYPE_SIXSENSE_WEBVISIT_SUBMIT_COUNT_INFLUENCE_ACTMQA) AS INTERACTIONTYPE_SIXSENSE_WEBVISIT_SUBMIT_COUNT_INFLUENCE_ACT,
	SUM(INTERACTIONTYPE_SIXSENSE_WEBVISIT_UNCLASSIFIED_COUNT_INFLUENCE_ACTMQA) AS INTERACTIONTYPE_SIXSENSE_WEBVISIT_UNCLASSIFIED_COUNT_INFLUENCE_ACT,
	SUM(INTERACTIONTYPE_BIZIBLE_TOUCHPOINT_WEBVISIT_COUNT_INFLUENCE_ACTMQA) AS INTERACTIONTYPE_BIZIBLE_TOUCHPOINT_WEBVISIT_COUNT_INFLUENCE_ACT,
	SUM(INTERACTIONTYPE_BIZIBLE_TOUCHPOINT_WEBCHAT_COUNT_INFLUENCE_ACTMQA) AS INTERACTIONTYPE_BIZIBLE_TOUCHPOINT_WEBCHAT_COUNT_INFLUENCE_ACT,
	SUM(INTERACTIONTYPE_BIZIBLE_TOUCHPOINT_WEBFORM_COUNT_INFLUENCE_ACTMQA) AS INTERACTIONTYPE_BIZIBLE_TOUCHPOINT_WEBFORM_COUNT_INFLUENCE_ACT,
	SUM(INTERACTIONTYPE_BIZIBLE_TOUCHPOINT_CRM_COUNT_INFLUENCE_ACTMQA) AS INTERACTIONTYPE_BIZIBLE_TOUCHPOINT_CRM_COUNT_INFLUENCE_ACT,
	SUM(INTERACTIONTYPE_BIZIBLE_TOUCHPOINT_CONNECTWITHDM_COUNT_INFLUENCE_ACTMQA) AS INTERACTIONTYPE_BIZIBLE_TOUCHPOINT_CONNECTWITHDM_COUNT_INFLUENCE_ACT,
	SUM(INTERACTIONTYPE_BIZIBLE_TOUCHPOINT_CALLSPOKEWITH_COUNT_INFLUENCE_ACTMQA) AS INTERACTIONTYPE_BIZIBLE_TOUCHPOINT_CALLSPOKEWITH_COUNT_INFLUENCE_ACT,
	SUM(INTERACTIONTYPE_BIZIBLE_TOUCHPOINT_CALLGATEKEEPER_COUNT_INFLUENCE_ACTMQA) AS INTERACTIONTYPE_BIZIBLE_TOUCHPOINT_CALLGATEKEEPER_COUNT_INFLUENCE_ACT,
	SUM(INTERACTIONTYPE_BIZIBLE_TOUCHPOINT_NOLEADTOUCHPOINTS_COUNT_INFLUENCE_ACTMQA) AS INTERACTIONTYPE_BIZIBLE_TOUCHPOINT_NOLEADTOUCHPOINTS_COUNT_INFLUENCE_ACT,
	SUM(INTERACTIONTYPE_BIZIBLE_TOUCHPOINT_UNCLASSIFIED_COUNT_INFLUENCE_ACTMQA) AS INTERACTIONTYPE_BIZIBLE_TOUCHPOINT_UNCLASSIFIED_COUNT_INFLUENCE_ACT

	FROM DP_PROD_DB.ACT_MRKT_LIFECYCLE.AMLH_INFL_OPP

	WHERE AMLH_ACCOUNT_JOURNEY_PATH_LIFECYCLE_NONLINEAR_FLAG = 'Linear' 
	-- Period Filter based on paramater
	AND (AMLH_MUTUALLY_EXCLUSIVE_PRE_SUSPECT_DESIGNATION ='Pre-Suspect MQA - Routed')
	AND (AMLH_SUSPECT_DATE_STAMP__C_CAST BETWEEN '10-01-2023' and '12-31-2025')
	GROUP BY 
	-- ids
	AMLH_NAME, ACT_ID, AMLH_RECYCLE_COUNTER__C,
	AMLH_MUTUALLY_EXCLUSIVE_PRE_SUSPECT_DESIGNATION,
	AMLH_MUTUALLY_EXCLUSIVE_PRE_SUSPECT_DESIGNATION_DATE,
	AMLH_SUSPECT_DATE_STAMP__C_CAST,

	--MARKETING_TOUCHPOINT_BEFORE_ACT_MQA,
	MARKETING_TOUCHPOINT_BEFORE_ACT_SUSPECT,

	-- attributes
	ACT_MARKET_SEGMENT__C,
	ACT_MARKET__C,
	ACT_BUSINESS_UNIT_DIVISION__C,
	INFLUENCE_CHANNEL,
	INFLUENCE_CHANNEL_TOPLEVEL,
	INFLUENCE_WEB_SOURCE,
	INFLUENCE_WEB_MEDIUM,
	INFLUENCE_CAMPAIGN_NAME,
	INFLUENCE_CREATIVE_NAME,
	INFLUENCE_LANDING_PAGE,
	INFLUENCE_REFERRER,
	WEBVISIT_PAGE,
	WEBVISIT_REFERRER,
	OPP_CREATED_DATE,
	OPP_STAGE_NAME_CATEGORY,
	OPP_STAGE_NAME,
	OPP_IS_CLOSED,
	OPP_IS_WON,
	OPP_CLOSE_DATE,
	-- Financial Metrics
	OPP_CURRENCY_ISO_CODE,
	OPP_CONVERSION_RATE,
	OPP_ACV3__C,
	OPP_TOTAL_BOOKING_AMOUNT2__C,
	OPP_TOTAL_BOOKING_AMOUNT2__C_CONVERTED,
	OPP_SUBS_QTY__C,
	OPP_BOOKED_SUBS_QTY3__C,
	OPP_FORECASTED_SUBS_QTY__C,
	OPP_BOOKEDFORECASTED_SUBS_QTY3__C,
	OPP_FORECASTED_ACV__C,
	OPP_FORECASTED_ARR__C,
	OPP_SALES_REPORTING_ARR__C,
	OPP_SALES_REPORTING_ACV__C,
	OPP_SALES_REPORTING_TOTAL_BOOKING_AMOUNT__C,
	OPP_SALES_REPORTING_ACV__C_CONVERTED,
	OPP_SALES_REPORTING_TOTAL_BOOKING_AMOUNT__C_CONVERTED,
	OPP_SALES_REPORTING_BOOKED_SUBS_QTY__C
	-- ORDER BY ACT_ID, AMLH_RECYCLE_COUNTER__C

	UNION ALL

	-- Touchpoints before MEA Routed
	SELECT 
	-- ids
	AMLH_NAME, ACT_ID, AMLH_RECYCLE_COUNTER__C,
	AMLH_MUTUALLY_EXCLUSIVE_PRE_SUSPECT_DESIGNATION,
	AMLH_MUTUALLY_EXCLUSIVE_PRE_SUSPECT_DESIGNATION_DATE,
	AMLH_SUSPECT_DATE_STAMP__C_CAST,

	'MEA - Routed' AS MARKETING_TOUCHPOINT_BEFORE_MILESTONE,
	MARKETING_TOUCHPOINT_BEFORE_ACT_SUSPECT AS MARKETING_TOUCHPOINT_BEFORE_ACT,
	'AMLH_SUSPECT_DATE_STAMP__C_CAST' AS MARKETING_TOUCHPOINT_BEFORE_ACT_DATE_MILESTONE_FIELD, 
	AMLH_SUSPECT_DATE_STAMP__C_CAST AS MARKETING_TOUCHPOINT_BEFORE_ACT_DATE_MILESTONE,

	-- attributes
	ACT_MARKET_SEGMENT__C,
	ACT_MARKET__C,
	ACT_BUSINESS_UNIT_DIVISION__C,
	INFLUENCE_CHANNEL,
	INFLUENCE_CHANNEL_TOPLEVEL,
	INFLUENCE_WEB_SOURCE,
	INFLUENCE_WEB_MEDIUM,
	INFLUENCE_CAMPAIGN_NAME,
	INFLUENCE_CREATIVE_NAME,
	INFLUENCE_LANDING_PAGE,
	INFLUENCE_REFERRER,
	WEBVISIT_PAGE,
	WEBVISIT_REFERRER,
	OPP_CREATED_DATE,
	OPP_STAGE_NAME_CATEGORY,
	OPP_STAGE_NAME,
	OPP_IS_CLOSED,
	OPP_IS_WON,
	OPP_CLOSE_DATE,
	-- Financial Metrics
	OPP_CURRENCY_ISO_CODE,
	OPP_CONVERSION_RATE,
	OPP_ACV3__C,
	OPP_TOTAL_BOOKING_AMOUNT2__C,
	OPP_TOTAL_BOOKING_AMOUNT2__C_CONVERTED,
	OPP_SUBS_QTY__C,
	OPP_BOOKED_SUBS_QTY3__C,
	OPP_FORECASTED_SUBS_QTY__C,
	OPP_BOOKEDFORECASTED_SUBS_QTY3__C,
	OPP_FORECASTED_ACV__C,
	OPP_FORECASTED_ARR__C,
	OPP_SALES_REPORTING_ARR__C,
	OPP_SALES_REPORTING_ACV__C,
	OPP_SALES_REPORTING_TOTAL_BOOKING_AMOUNT__C,
	OPP_SALES_REPORTING_ACV__C_CONVERTED,
	OPP_SALES_REPORTING_TOTAL_BOOKING_AMOUNT__C_CONVERTED,
	OPP_SALES_REPORTING_BOOKED_SUBS_QTY__C,
	-- metrics
	SUM(INTERACTIONTYPE_SIXSENSE_PAIDMEDIA_IMPRESSIONS_COUNT_INFLUENCE_ACTMQA) AS INTERACTIONTYPE_SIXSENSE_PAIDMEDIA_IMPRESSIONS_COUNT_INFLUENCE_ACT,
	SUM(INTERACTIONTYPE_SIXSENSE_PAIDMEDIA_CLICKS_COUNT_INFLUENCE_ACTMQA) AS INTERACTIONTYPE_SIXSENSE_PAIDMEDIA_CLICKS_COUNT_INFLUENCE_ACT,
	SUM(INTERACTIONTYPE_SIXSENSE_WEBVISIT_TOTAL_INTERACTIONS_COUNT_INFLUENCE_ACTMQA) AS INTERACTIONTYPE_SIXSENSE_WEBVISIT_TOTAL_INTERACTIONS_COUNT_INFLUENCE_ACT,
	SUM(INTERACTIONTYPE_SIXSENSE_WEBVISIT_PAGELOAD_COUNT_INFLUENCE_ACTMQA) AS INTERACTIONTYPE_SIXSENSE_WEBVISIT_PAGELOAD_COUNT_INFLUENCE_ACT,
	SUM(INTERACTIONTYPE_SIXSENSE_WEBVISIT_PLAY_COUNT_INFLUENCE_ACTMQA) AS INTERACTIONTYPE_SIXSENSE_WEBVISIT_PLAY_COUNT_INFLUENCE_ACT,
	SUM(INTERACTIONTYPE_SIXSENSE_WEBVISIT_CLICK_COUNT_INFLUENCE_ACTMQA) AS INTERACTIONTYPE_SIXSENSE_WEBVISIT_CLICK_COUNT_INFLUENCE_ACT,
	SUM(INTERACTIONTYPE_SIXSENSE_WEBVISIT_SUBMIT_COUNT_INFLUENCE_ACTMQA) AS INTERACTIONTYPE_SIXSENSE_WEBVISIT_SUBMIT_COUNT_INFLUENCE_ACT,
	SUM(INTERACTIONTYPE_SIXSENSE_WEBVISIT_UNCLASSIFIED_COUNT_INFLUENCE_ACTMQA) AS INTERACTIONTYPE_SIXSENSE_WEBVISIT_UNCLASSIFIED_COUNT_INFLUENCE_ACT,
	SUM(INTERACTIONTYPE_BIZIBLE_TOUCHPOINT_WEBVISIT_COUNT_INFLUENCE_ACTMQA) AS INTERACTIONTYPE_BIZIBLE_TOUCHPOINT_WEBVISIT_COUNT_INFLUENCE_ACT,
	SUM(INTERACTIONTYPE_BIZIBLE_TOUCHPOINT_WEBCHAT_COUNT_INFLUENCE_ACTMQA) AS INTERACTIONTYPE_BIZIBLE_TOUCHPOINT_WEBCHAT_COUNT_INFLUENCE_ACT,
	SUM(INTERACTIONTYPE_BIZIBLE_TOUCHPOINT_WEBFORM_COUNT_INFLUENCE_ACTMQA) AS INTERACTIONTYPE_BIZIBLE_TOUCHPOINT_WEBFORM_COUNT_INFLUENCE_ACT,
	SUM(INTERACTIONTYPE_BIZIBLE_TOUCHPOINT_CRM_COUNT_INFLUENCE_ACTMQA) AS INTERACTIONTYPE_BIZIBLE_TOUCHPOINT_CRM_COUNT_INFLUENCE_ACT,
	SUM(INTERACTIONTYPE_BIZIBLE_TOUCHPOINT_CONNECTWITHDM_COUNT_INFLUENCE_ACTMQA) AS INTERACTIONTYPE_BIZIBLE_TOUCHPOINT_CONNECTWITHDM_COUNT_INFLUENCE_ACT,
	SUM(INTERACTIONTYPE_BIZIBLE_TOUCHPOINT_CALLSPOKEWITH_COUNT_INFLUENCE_ACTMQA) AS INTERACTIONTYPE_BIZIBLE_TOUCHPOINT_CALLSPOKEWITH_COUNT_INFLUENCE_ACT,
	SUM(INTERACTIONTYPE_BIZIBLE_TOUCHPOINT_CALLGATEKEEPER_COUNT_INFLUENCE_ACTMQA) AS INTERACTIONTYPE_BIZIBLE_TOUCHPOINT_CALLGATEKEEPER_COUNT_INFLUENCE_ACT,
	SUM(INTERACTIONTYPE_BIZIBLE_TOUCHPOINT_NOLEADTOUCHPOINTS_COUNT_INFLUENCE_ACTMQA) AS INTERACTIONTYPE_BIZIBLE_TOUCHPOINT_NOLEADTOUCHPOINTS_COUNT_INFLUENCE_ACT,
	SUM(INTERACTIONTYPE_BIZIBLE_TOUCHPOINT_UNCLASSIFIED_COUNT_INFLUENCE_ACTMQA) AS INTERACTIONTYPE_BIZIBLE_TOUCHPOINT_UNCLASSIFIED_COUNT_INFLUENCE_ACT

	FROM DP_PROD_DB.ACT_MRKT_LIFECYCLE.AMLH_INFL_OPP

	WHERE AMLH_ACCOUNT_JOURNEY_PATH_LIFECYCLE_NONLINEAR_FLAG = 'Linear' 
	-- Period Filter based on paramater
	AND (AMLH_MUTUALLY_EXCLUSIVE_PRE_SUSPECT_DESIGNATION ='Pre-Suspect MEA - Routed')
	AND (AMLH_SUSPECT_DATE_STAMP__C_CAST BETWEEN '10-01-2023' and '12-31-2025')
	GROUP BY 
	-- ids
	AMLH_NAME, ACT_ID, AMLH_RECYCLE_COUNTER__C,
	AMLH_MUTUALLY_EXCLUSIVE_PRE_SUSPECT_DESIGNATION,
	AMLH_MUTUALLY_EXCLUSIVE_PRE_SUSPECT_DESIGNATION_DATE,
	AMLH_SUSPECT_DATE_STAMP__C_CAST,

	MARKETING_TOUCHPOINT_BEFORE_ACT_SUSPECT,

	-- attributes
	ACT_MARKET_SEGMENT__C,
	ACT_MARKET__C,
	ACT_BUSINESS_UNIT_DIVISION__C,
	INFLUENCE_CHANNEL,
	INFLUENCE_CHANNEL_TOPLEVEL,
	INFLUENCE_WEB_SOURCE,
	INFLUENCE_WEB_MEDIUM,
	INFLUENCE_CAMPAIGN_NAME,
	INFLUENCE_CREATIVE_NAME,
	INFLUENCE_LANDING_PAGE,
	INFLUENCE_REFERRER,
	WEBVISIT_PAGE,
	WEBVISIT_REFERRER,
	OPP_CREATED_DATE,
	OPP_STAGE_NAME_CATEGORY,
	OPP_STAGE_NAME,
	OPP_IS_CLOSED,
	OPP_IS_WON,
	OPP_CLOSE_DATE,
	-- Financial Metrics
	OPP_CURRENCY_ISO_CODE,
	OPP_CONVERSION_RATE,
	OPP_ACV3__C,
	OPP_TOTAL_BOOKING_AMOUNT2__C,
	OPP_TOTAL_BOOKING_AMOUNT2__C_CONVERTED,
	OPP_SUBS_QTY__C,
	OPP_BOOKED_SUBS_QTY3__C,
	OPP_FORECASTED_SUBS_QTY__C,
	OPP_BOOKEDFORECASTED_SUBS_QTY3__C,
	OPP_FORECASTED_ACV__C,
	OPP_FORECASTED_ARR__C,
	OPP_SALES_REPORTING_ARR__C,
	OPP_SALES_REPORTING_ACV__C,
	OPP_SALES_REPORTING_TOTAL_BOOKING_AMOUNT__C,
	OPP_SALES_REPORTING_ACV__C_CONVERTED,
	OPP_SALES_REPORTING_TOTAL_BOOKING_AMOUNT__C_CONVERTED,
	OPP_SALES_REPORTING_BOOKED_SUBS_QTY__C
	-- ORDER BY ACT_ID, AMLH_RECYCLE_COUNTER__C

	UNION ALL

	-- Touchpoints before Opp Created
	SELECT 
	-- ids
	AMLH_NAME, ACT_ID, AMLH_RECYCLE_COUNTER__C,
	AMLH_MUTUALLY_EXCLUSIVE_PRE_SUSPECT_DESIGNATION,
	AMLH_MUTUALLY_EXCLUSIVE_PRE_SUSPECT_DESIGNATION_DATE,
	AMLH_SUSPECT_DATE_STAMP__C_CAST,

	'Opportunity Created' AS MARKETING_TOUCHPOINT_BEFORE_MILESTONE,
	MARKETING_TOUCHPOINT_BEFORE_OPP_CREATED AS MARKETING_TOUCHPOINT_BEFORE_ACT,
	'OPP_CREATED_DATE' AS MARKETING_TOUCHPOINT_BEFORE_ACT_DATE_MILESTONE_FIELD, 
	OPP_CREATED_DATE AS MARKETING_TOUCHPOINT_BEFORE_ACT_DATE_MILESTONE,

	-- attributes
	ACT_MARKET_SEGMENT__C,
	ACT_MARKET__C,
	ACT_BUSINESS_UNIT_DIVISION__C,
	INFLUENCE_CHANNEL,
	INFLUENCE_CHANNEL_TOPLEVEL,
	INFLUENCE_WEB_SOURCE,
	INFLUENCE_WEB_MEDIUM,
	INFLUENCE_CAMPAIGN_NAME,
	INFLUENCE_CREATIVE_NAME,
	INFLUENCE_LANDING_PAGE,
	INFLUENCE_REFERRER,
	WEBVISIT_PAGE,
	WEBVISIT_REFERRER,
	OPP_CREATED_DATE,
	OPP_STAGE_NAME_CATEGORY,
	OPP_STAGE_NAME,
	OPP_IS_CLOSED,
	OPP_IS_WON,
	OPP_CLOSE_DATE,
	-- Financial Metrics
	OPP_CURRENCY_ISO_CODE,
	OPP_CONVERSION_RATE,
	OPP_ACV3__C,
	OPP_TOTAL_BOOKING_AMOUNT2__C,
	OPP_TOTAL_BOOKING_AMOUNT2__C_CONVERTED,
	OPP_SUBS_QTY__C,
	OPP_BOOKED_SUBS_QTY3__C,
	OPP_FORECASTED_SUBS_QTY__C,
	OPP_BOOKEDFORECASTED_SUBS_QTY3__C,
	OPP_FORECASTED_ACV__C,
	OPP_FORECASTED_ARR__C,
	OPP_SALES_REPORTING_ARR__C,
	OPP_SALES_REPORTING_ACV__C,
	OPP_SALES_REPORTING_TOTAL_BOOKING_AMOUNT__C,
	OPP_SALES_REPORTING_ACV__C_CONVERTED,
	OPP_SALES_REPORTING_TOTAL_BOOKING_AMOUNT__C_CONVERTED,
	OPP_SALES_REPORTING_BOOKED_SUBS_QTY__C,
	-- metrics
	SUM(INTERACTIONTYPE_SIXSENSE_PAIDMEDIA_IMPRESSIONS_COUNT_INFLUENCE_OPPCRT) AS INTERACTIONTYPE_SIXSENSE_PAIDMEDIA_IMPRESSIONS_COUNT_INFLUENCE_ACT,
	SUM(INTERACTIONTYPE_SIXSENSE_PAIDMEDIA_CLICKS_COUNT_INFLUENCE_OPPCRT) AS INTERACTIONTYPE_SIXSENSE_PAIDMEDIA_CLICKS_COUNT_INFLUENCE_ACT,
	SUM(INTERACTIONTYPE_SIXSENSE_WEBVISIT_TOTAL_INTERACTIONS_COUNT_INFLUENCE_OPPCRT) AS INTERACTIONTYPE_SIXSENSE_WEBVISIT_TOTAL_INTERACTIONS_COUNT_INFLUENCE_ACT,
	SUM(INTERACTIONTYPE_SIXSENSE_WEBVISIT_PAGELOAD_COUNT_INFLUENCE_OPPCRT) AS INTERACTIONTYPE_SIXSENSE_WEBVISIT_PAGELOAD_COUNT_INFLUENCE_ACT,
	SUM(INTERACTIONTYPE_SIXSENSE_WEBVISIT_PLAY_COUNT_INFLUENCE_OPPCRT) AS INTERACTIONTYPE_SIXSENSE_WEBVISIT_PLAY_COUNT_INFLUENCE_ACT,
	SUM(INTERACTIONTYPE_SIXSENSE_WEBVISIT_CLICK_COUNT_INFLUENCE_OPPCRT) AS INTERACTIONTYPE_SIXSENSE_WEBVISIT_CLICK_COUNT_INFLUENCE_ACT,
	SUM(INTERACTIONTYPE_SIXSENSE_WEBVISIT_SUBMIT_COUNT_INFLUENCE_OPPCRT) AS INTERACTIONTYPE_SIXSENSE_WEBVISIT_SUBMIT_COUNT_INFLUENCE_ACT,
	SUM(INTERACTIONTYPE_SIXSENSE_WEBVISIT_UNCLASSIFIED_COUNT_INFLUENCE_OPPCRT) AS INTERACTIONTYPE_SIXSENSE_WEBVISIT_UNCLASSIFIED_COUNT_INFLUENCE_ACT,
	SUM(INTERACTIONTYPE_BIZIBLE_TOUCHPOINT_WEBVISIT_COUNT_INFLUENCE_OPPCRT) AS INTERACTIONTYPE_BIZIBLE_TOUCHPOINT_WEBVISIT_COUNT_INFLUENCE_ACT,
	SUM(INTERACTIONTYPE_BIZIBLE_TOUCHPOINT_WEBCHAT_COUNT_INFLUENCE_OPPCRT) AS INTERACTIONTYPE_BIZIBLE_TOUCHPOINT_WEBCHAT_COUNT_INFLUENCE_ACT,
	SUM(INTERACTIONTYPE_BIZIBLE_TOUCHPOINT_WEBFORM_COUNT_INFLUENCE_OPPCRT) AS INTERACTIONTYPE_BIZIBLE_TOUCHPOINT_WEBFORM_COUNT_INFLUENCE_ACT,
	SUM(INTERACTIONTYPE_BIZIBLE_TOUCHPOINT_CRM_COUNT_INFLUENCE_OPPCRT) AS INTERACTIONTYPE_BIZIBLE_TOUCHPOINT_CRM_COUNT_INFLUENCE_ACT,
	SUM(INTERACTIONTYPE_BIZIBLE_TOUCHPOINT_CONNECTWITHDM_COUNT_INFLUENCE_OPPCRT) AS INTERACTIONTYPE_BIZIBLE_TOUCHPOINT_CONNECTWITHDM_COUNT_INFLUENCE_ACT,
	SUM(INTERACTIONTYPE_BIZIBLE_TOUCHPOINT_CALLSPOKEWITH_COUNT_INFLUENCE_OPPCRT) AS INTERACTIONTYPE_BIZIBLE_TOUCHPOINT_CALLSPOKEWITH_COUNT_INFLUENCE_ACT,
	SUM(INTERACTIONTYPE_BIZIBLE_TOUCHPOINT_CALLGATEKEEPER_COUNT_INFLUENCE_OPPCRT) AS INTERACTIONTYPE_BIZIBLE_TOUCHPOINT_CALLGATEKEEPER_COUNT_INFLUENCE_ACT,
	SUM(INTERACTIONTYPE_BIZIBLE_TOUCHPOINT_NOLEADTOUCHPOINTS_COUNT_INFLUENCE_OPPCRT) AS INTERACTIONTYPE_BIZIBLE_TOUCHPOINT_NOLEADTOUCHPOINTS_COUNT_INFLUENCE_ACT,
	SUM(INTERACTIONTYPE_BIZIBLE_TOUCHPOINT_UNCLASSIFIED_COUNT_INFLUENCE_OPPCRT) AS INTERACTIONTYPE_BIZIBLE_TOUCHPOINT_UNCLASSIFIED_COUNT_INFLUENCE_ACT

	FROM DP_PROD_DB.ACT_MRKT_LIFECYCLE.AMLH_INFL_OPP

	WHERE AMLH_ACCOUNT_JOURNEY_PATH_LIFECYCLE_NONLINEAR_FLAG = 'Linear' 
	-- Period Filter based on paramater
	and (OPP_CREATED_DATE BETWEEN '10-01-2023' and '12-31-2025')
	GROUP BY 
	-- ids
	AMLH_NAME, ACT_ID, AMLH_RECYCLE_COUNTER__C,
	AMLH_MUTUALLY_EXCLUSIVE_PRE_SUSPECT_DESIGNATION,
	AMLH_MUTUALLY_EXCLUSIVE_PRE_SUSPECT_DESIGNATION_DATE,
	AMLH_SUSPECT_DATE_STAMP__C_CAST,

	MARKETING_TOUCHPOINT_BEFORE_OPP_CREATED,

	-- attributes
	ACT_MARKET_SEGMENT__C,
	ACT_MARKET__C,
	ACT_BUSINESS_UNIT_DIVISION__C,
	INFLUENCE_CHANNEL,
	INFLUENCE_CHANNEL_TOPLEVEL,
	INFLUENCE_WEB_SOURCE,
	INFLUENCE_WEB_MEDIUM,
	INFLUENCE_CAMPAIGN_NAME,
	INFLUENCE_CREATIVE_NAME,
	INFLUENCE_LANDING_PAGE,
	INFLUENCE_REFERRER,
	WEBVISIT_PAGE,
	WEBVISIT_REFERRER,
	OPP_CREATED_DATE,
	OPP_STAGE_NAME_CATEGORY,
	OPP_STAGE_NAME,
	OPP_IS_CLOSED,
	OPP_IS_WON,
	OPP_CLOSE_DATE,
	-- Financial Metrics
	OPP_CURRENCY_ISO_CODE,
	OPP_CONVERSION_RATE,
	OPP_ACV3__C,
	OPP_TOTAL_BOOKING_AMOUNT2__C,
	OPP_TOTAL_BOOKING_AMOUNT2__C_CONVERTED,
	OPP_SUBS_QTY__C,
	OPP_BOOKED_SUBS_QTY3__C,
	OPP_FORECASTED_SUBS_QTY__C,
	OPP_BOOKEDFORECASTED_SUBS_QTY3__C,
	OPP_FORECASTED_ACV__C,
	OPP_FORECASTED_ARR__C,
	OPP_SALES_REPORTING_ARR__C,
	OPP_SALES_REPORTING_ACV__C,
	OPP_SALES_REPORTING_TOTAL_BOOKING_AMOUNT__C,
	OPP_SALES_REPORTING_ACV__C_CONVERTED,
	OPP_SALES_REPORTING_TOTAL_BOOKING_AMOUNT__C_CONVERTED,
	OPP_SALES_REPORTING_BOOKED_SUBS_QTY__C
	-- ORDER BY ACT_ID, AMLH_RECYCLE_COUNTER__C

	UNION ALL

	-- Touchpoints before Opp Closed Won
	SELECT 
	-- ids
	AMLH_NAME, ACT_ID, AMLH_RECYCLE_COUNTER__C,
	AMLH_MUTUALLY_EXCLUSIVE_PRE_SUSPECT_DESIGNATION,
	AMLH_MUTUALLY_EXCLUSIVE_PRE_SUSPECT_DESIGNATION_DATE,
	AMLH_SUSPECT_DATE_STAMP__C_CAST,

	'Opportunity Closed Won' AS MARKETING_TOUCHPOINT_BEFORE_MILESTONE,
	MARKETING_TOUCHPOINT_BEFORE_OPP_CLOSE AS MARKETING_TOUCHPOINT_BEFORE_ACT,
	'OPP_CLOSE_DATE' AS MARKETING_TOUCHPOINT_BEFORE_ACT_DATE_MILESTONE_FIELD, 
	OPP_CLOSE_DATE AS MARKETING_TOUCHPOINT_BEFORE_ACT_DATE_MILESTONE,

	-- attributes
	ACT_MARKET_SEGMENT__C,
	ACT_MARKET__C,
	ACT_BUSINESS_UNIT_DIVISION__C,
	INFLUENCE_CHANNEL,
	INFLUENCE_CHANNEL_TOPLEVEL,
	INFLUENCE_WEB_SOURCE,
	INFLUENCE_WEB_MEDIUM,
	INFLUENCE_CAMPAIGN_NAME,
	INFLUENCE_CREATIVE_NAME,
	INFLUENCE_LANDING_PAGE,
	INFLUENCE_REFERRER,
	WEBVISIT_PAGE,
	WEBVISIT_REFERRER,
	OPP_CREATED_DATE,
	OPP_STAGE_NAME_CATEGORY,
	OPP_STAGE_NAME,
	OPP_IS_CLOSED,
	OPP_IS_WON,
	OPP_CLOSE_DATE,
	-- Financial Metrics
	OPP_CURRENCY_ISO_CODE,
	OPP_CONVERSION_RATE,
	OPP_ACV3__C,
	OPP_TOTAL_BOOKING_AMOUNT2__C,
	OPP_TOTAL_BOOKING_AMOUNT2__C_CONVERTED,
	OPP_SUBS_QTY__C,
	OPP_BOOKED_SUBS_QTY3__C,
	OPP_FORECASTED_SUBS_QTY__C,
	OPP_BOOKEDFORECASTED_SUBS_QTY3__C,
	OPP_FORECASTED_ACV__C,
	OPP_FORECASTED_ARR__C,
	OPP_SALES_REPORTING_ARR__C,
	OPP_SALES_REPORTING_ACV__C,
	OPP_SALES_REPORTING_TOTAL_BOOKING_AMOUNT__C,
	OPP_SALES_REPORTING_ACV__C_CONVERTED,
	OPP_SALES_REPORTING_TOTAL_BOOKING_AMOUNT__C_CONVERTED,
	OPP_SALES_REPORTING_BOOKED_SUBS_QTY__C,
	-- metrics
	SUM(INTERACTIONTYPE_SIXSENSE_PAIDMEDIA_IMPRESSIONS_COUNT_INFLUENCE_OPPCLS) AS INTERACTIONTYPE_SIXSENSE_PAIDMEDIA_IMPRESSIONS_COUNT_INFLUENCE_ACT,
	SUM(INTERACTIONTYPE_SIXSENSE_PAIDMEDIA_CLICKS_COUNT_INFLUENCE_OPPCLS) AS INTERACTIONTYPE_SIXSENSE_PAIDMEDIA_CLICKS_COUNT_INFLUENCE_ACT,
	SUM(INTERACTIONTYPE_SIXSENSE_WEBVISIT_TOTAL_INTERACTIONS_COUNT_INFLUENCE_OPPCLS) AS INTERACTIONTYPE_SIXSENSE_WEBVISIT_TOTAL_INTERACTIONS_COUNT_INFLUENCE_ACT,
	SUM(INTERACTIONTYPE_SIXSENSE_WEBVISIT_PAGELOAD_COUNT_INFLUENCE_OPPCLS) AS INTERACTIONTYPE_SIXSENSE_WEBVISIT_PAGELOAD_COUNT_INFLUENCE_ACT,
	SUM(INTERACTIONTYPE_SIXSENSE_WEBVISIT_PLAY_COUNT_INFLUENCE_OPPCLS) AS INTERACTIONTYPE_SIXSENSE_WEBVISIT_PLAY_COUNT_INFLUENCE_ACT,
	SUM(INTERACTIONTYPE_SIXSENSE_WEBVISIT_CLICK_COUNT_INFLUENCE_OPPCLS) AS INTERACTIONTYPE_SIXSENSE_WEBVISIT_CLICK_COUNT_INFLUENCE_ACT,
	SUM(INTERACTIONTYPE_SIXSENSE_WEBVISIT_SUBMIT_COUNT_INFLUENCE_OPPCLS) AS INTERACTIONTYPE_SIXSENSE_WEBVISIT_SUBMIT_COUNT_INFLUENCE_ACT,
	SUM(INTERACTIONTYPE_SIXSENSE_WEBVISIT_UNCLASSIFIED_COUNT_INFLUENCE_OPPCLS) AS INTERACTIONTYPE_SIXSENSE_WEBVISIT_UNCLASSIFIED_COUNT_INFLUENCE_ACT,
	SUM(INTERACTIONTYPE_BIZIBLE_TOUCHPOINT_WEBVISIT_COUNT_INFLUENCE_OPPCLS) AS INTERACTIONTYPE_BIZIBLE_TOUCHPOINT_WEBVISIT_COUNT_INFLUENCE_ACT,
	SUM(INTERACTIONTYPE_BIZIBLE_TOUCHPOINT_WEBCHAT_COUNT_INFLUENCE_OPPCLS) AS INTERACTIONTYPE_BIZIBLE_TOUCHPOINT_WEBCHAT_COUNT_INFLUENCE_ACT,
	SUM(INTERACTIONTYPE_BIZIBLE_TOUCHPOINT_WEBFORM_COUNT_INFLUENCE_OPPCLS) AS INTERACTIONTYPE_BIZIBLE_TOUCHPOINT_WEBFORM_COUNT_INFLUENCE_ACT,
	SUM(INTERACTIONTYPE_BIZIBLE_TOUCHPOINT_CRM_COUNT_INFLUENCE_OPPCLS) AS INTERACTIONTYPE_BIZIBLE_TOUCHPOINT_CRM_COUNT_INFLUENCE_ACT,
	SUM(INTERACTIONTYPE_BIZIBLE_TOUCHPOINT_CONNECTWITHDM_COUNT_INFLUENCE_OPPCLS) AS INTERACTIONTYPE_BIZIBLE_TOUCHPOINT_CONNECTWITHDM_COUNT_INFLUENCE_ACT,
	SUM(INTERACTIONTYPE_BIZIBLE_TOUCHPOINT_CALLSPOKEWITH_COUNT_INFLUENCE_OPPCLS) AS INTERACTIONTYPE_BIZIBLE_TOUCHPOINT_CALLSPOKEWITH_COUNT_INFLUENCE_ACT,
	SUM(INTERACTIONTYPE_BIZIBLE_TOUCHPOINT_CALLGATEKEEPER_COUNT_INFLUENCE_OPPCLS) AS INTERACTIONTYPE_BIZIBLE_TOUCHPOINT_CALLGATEKEEPER_COUNT_INFLUENCE_ACT,
	SUM(INTERACTIONTYPE_BIZIBLE_TOUCHPOINT_NOLEADTOUCHPOINTS_COUNT_INFLUENCE_OPPCLS) AS INTERACTIONTYPE_BIZIBLE_TOUCHPOINT_NOLEADTOUCHPOINTS_COUNT_INFLUENCE_ACT,
	SUM(INTERACTIONTYPE_BIZIBLE_TOUCHPOINT_UNCLASSIFIED_COUNT_INFLUENCE_OPPCLS) AS INTERACTIONTYPE_BIZIBLE_TOUCHPOINT_UNCLASSIFIED_COUNT_INFLUENCE_ACT

	FROM DP_PROD_DB.ACT_MRKT_LIFECYCLE.AMLH_INFL_OPP

	WHERE AMLH_ACCOUNT_JOURNEY_PATH_LIFECYCLE_NONLINEAR_FLAG = 'Linear' 
	-- Period Filter based on paramater
	and (OPP_CLOSE_DATE BETWEEN '10-01-2023' and '12-31-2025')
	and OPP_STAGE_NAME_CATEGORY = 'Closed - Booked'
	GROUP BY 
	-- ids
	AMLH_NAME, ACT_ID, AMLH_RECYCLE_COUNTER__C,
	AMLH_MUTUALLY_EXCLUSIVE_PRE_SUSPECT_DESIGNATION,
	AMLH_MUTUALLY_EXCLUSIVE_PRE_SUSPECT_DESIGNATION_DATE ,
	AMLH_SUSPECT_DATE_STAMP__C_CAST,

	MARKETING_TOUCHPOINT_BEFORE_OPP_CLOSE,

	-- attributes
	ACT_MARKET_SEGMENT__C,
	ACT_MARKET__C,
	ACT_BUSINESS_UNIT_DIVISION__C,
	INFLUENCE_CHANNEL,
	INFLUENCE_CHANNEL_TOPLEVEL,
	INFLUENCE_WEB_SOURCE,
	INFLUENCE_WEB_MEDIUM,
	INFLUENCE_CAMPAIGN_NAME,
	INFLUENCE_CREATIVE_NAME,
	INFLUENCE_LANDING_PAGE,
	INFLUENCE_REFERRER,
	WEBVISIT_PAGE,
	WEBVISIT_REFERRER,
	OPP_CREATED_DATE,
	OPP_STAGE_NAME_CATEGORY,
	OPP_STAGE_NAME,
	OPP_IS_CLOSED,
	OPP_IS_WON,
	OPP_CLOSE_DATE,
	-- Financial Metrics
	OPP_CURRENCY_ISO_CODE,
	OPP_CONVERSION_RATE,
	OPP_ACV3__C,
	OPP_TOTAL_BOOKING_AMOUNT2__C,
	OPP_TOTAL_BOOKING_AMOUNT2__C_CONVERTED,
	OPP_SUBS_QTY__C,
	OPP_BOOKED_SUBS_QTY3__C,
	OPP_FORECASTED_SUBS_QTY__C,
	OPP_BOOKEDFORECASTED_SUBS_QTY3__C,
	OPP_FORECASTED_ACV__C,
	OPP_FORECASTED_ARR__C,
	OPP_SALES_REPORTING_ARR__C,
	OPP_SALES_REPORTING_ACV__C,
	OPP_SALES_REPORTING_TOTAL_BOOKING_AMOUNT__C,
	OPP_SALES_REPORTING_ACV__C_CONVERTED,
	OPP_SALES_REPORTING_TOTAL_BOOKING_AMOUNT__C_CONVERTED,
	OPP_SALES_REPORTING_BOOKED_SUBS_QTY__C
	-- ORDER BY ACT_ID, AMLH_RECYCLE_COUNTER__C

	) as x
	) as y
	; 

	-- Step 05c: Account Marketing Lifecycle History with Opp and Influence Data Aggregated
	   

	DROP TABLE IF EXISTS DP_PROD_DB.ACT_MRKT_LIFECYCLE.amlh_opp_infl_milestones_agg;

	CREATE TABLE DP_PROD_DB.ACT_MRKT_LIFECYCLE.amlh_opp_infl_milestones_agg AS 

	SELECT y.*
FROM
(
SELECT
pvt.*,
CASE WHEN TOUCHPOINT_BEFORE = 1 AND TOUCHPOINT_AFTER = 0 THEN 1 ELSE 0 END AS TOUCHPOINT_BEFORE_ONLY,
CASE WHEN TOUCHPOINT_BEFORE = 0 AND TOUCHPOINT_AFTER = 1 THEN 1 ELSE 0 END AS TOUCHPOINT_AFTER_ONLY,
CASE WHEN TOUCHPOINT_BEFORE = 1 AND TOUCHPOINT_AFTER = 1 THEN 1 ELSE 0 END AS TOUCHPOINT_BEFORE_AND_AFTER,
1 AS TOUCHPOINT_TOTAL
FROM
(
SELECT
  amlh_opp_influence_milestones.AMLH_NAME,
  amlh_opp_influence_milestones.ACT_ID,
  amlh_opp_influence_milestones.AMLH_RECYCLE_COUNTER__C,
  amlh_opp_influence_milestones.AMLH_MUTUALLY_EXCLUSIVE_PRE_SUSPECT_DESIGNATION,
  amlh_opp_influence_milestones.AMLH_MUTUALLY_EXCLUSIVE_PRE_SUSPECT_DESIGNATION_DATE,
  amlh_opp_influence_milestones.AMLH_SUSPECT_DATE_STAMP__C_CAST,
  amlh_opp_influence_milestones.MARKETING_TOUCHPOINT_BEFORE_MILESTONE,
  amlh_opp_influence_milestones.MARKETING_TOUCHPOINT_BEFORE_ACT_DATE_MILESTONE,
  amlh_opp_influence_milestones.MARKETING_TOUCHPOINT_BEFORE_ACT_DATE_MILESTONE_EOM,
  amlh_opp_influence_milestones.MARKETING_TOUCHPOINT_BEFORE_ACT_DATE_MILESTONE_EOQ,
  amlh_opp_influence_milestones.MARKETING_TOUCHPOINT_BEFORE_ACT_DATE_MILESTONE_YEAR,
  amlh_opp_influence_milestones.ACT_MARKET_SEGMENT__C,
  amlh_opp_influence_milestones.ACT_MARKET__C,
  amlh_opp_influence_milestones.ACT_BUSINESS_UNIT_DIVISION__C,
  amlh_opp_influence_milestones.INFLUENCE_CHANNEL,
  amlh_opp_influence_milestones.INFLUENCE_CAMPAIGN_NAME,
  amlh_opp_influence_milestones.OPP_CREATED_DATE,
  amlh_opp_influence_milestones.OPP_STAGE_NAME_CATEGORY,
  amlh_opp_influence_milestones.OPP_STAGE_NAME,
  amlh_opp_influence_milestones.OPP_IS_CLOSED,
  amlh_opp_influence_milestones.OPP_IS_WON,
  amlh_opp_influence_milestones.OPP_CLOSE_DATE,
  amlh_opp_influence_milestones.OPP_CURRENCY_ISO_CODE,
  amlh_opp_influence_milestones.OPP_CONVERSION_RATE,
  amlh_opp_influence_milestones.OPP_ACV3__C,
  amlh_opp_influence_milestones.OPP_TOTAL_BOOKING_AMOUNT2__C,
  amlh_opp_influence_milestones.OPP_TOTAL_BOOKING_AMOUNT2__C_CONVERTED,
  amlh_opp_influence_milestones.OPP_SUBS_QTY__C,
  amlh_opp_influence_milestones.OPP_BOOKED_SUBS_QTY3__C,
  amlh_opp_influence_milestones.OPP_FORECASTED_SUBS_QTY__C,
  amlh_opp_influence_milestones.OPP_BOOKEDFORECASTED_SUBS_QTY3__C,
  amlh_opp_influence_milestones.OPP_FORECASTED_ACV__C,
  amlh_opp_influence_milestones.OPP_FORECASTED_ARR__C,
  amlh_opp_influence_milestones.OPP_SALES_REPORTING_ARR__C,
  amlh_opp_influence_milestones.OPP_SALES_REPORTING_ACV__C,
  amlh_opp_influence_milestones.OPP_SALES_REPORTING_TOTAL_BOOKING_AMOUNT__C,
  amlh_opp_influence_milestones.OPP_SALES_REPORTING_ACV__C_CONVERTED,
  amlh_opp_influence_milestones.OPP_SALES_REPORTING_TOTAL_BOOKING_AMOUNT__C_CONVERTED,
  amlh_opp_influence_milestones.OPP_SALES_REPORTING_BOOKED_SUBS_QTY__C,
    COUNT(
    DISTINCT CASE
      WHEN amlh_opp_influence_milestones.MARKETING_TOUCHPOINT_BEFORE_ACT = 1 THEN AMLH_NAME
    END
  ) AS TOUCHPOINT_BEFORE,
  COUNT(
    DISTINCT CASE
      WHEN amlh_opp_influence_milestones.MARKETING_TOUCHPOINT_BEFORE_ACT = 0 THEN AMLH_NAME
    END
  ) AS TOUCHPOINT_AFTER,
    COUNT(
    DISTINCT CASE
      WHEN amlh_opp_influence_milestones.INTERACTIONTYPE_INTERACTION_IMPRESSION_BEFORE_MILESTONE_FLAG = 1 THEN AMLH_NAME
    END
  ) AS INTERACTIONTYPE_INTERACTION_IMPRESSION_BEFORE_MILESTONE_FLAG,
    COUNT(
    DISTINCT CASE
      WHEN amlh_opp_influence_milestones.INTERACTIONTYPE_INTERACTION_ONLY_BEFORE_MILESTONE_FLAG = 1 THEN AMLH_NAME
    END
  ) AS INTERACTIONTYPE_INTERACTION_ONLY_BEFORE_MILESTONE_FLAG
FROM
  DP_PROD_DB.ACT_MRKT_LIFECYCLE.amlh_opp_infl_milestones AS amlh_opp_influence_milestones
-- WHERE amlh_opp_influence_milestones.MARKETING_TOUCHPOINT_BEFORE_MILESTONE = 'MQA' AND INFLUENCE_CAMPAIGN_NAME = 'OA-22-09-Display-6Sense-Trucking-Local-MEA-Fleet-Safety-without-SF'
GROUP BY
  1,
  2,3,4,5,6,
  7,
  8,
  9,10,11,12,13,14,15,16,17,18,19,20,21,22,23,24,25,26,27,28,29,30,31,32,33,34,35,36,37, 38, 39
ORDER BY
  1,
  2,3,4,5,6,
  7,
  8,
  9,10,11,12,13,14,15,16,17,18,19,20,21,22,23,24,25,26,27,28,29,30,31,32,33,34,35,36,37,38, 39
) AS pvt
) as y
  ;
	    
	   
    COMMIT;

EXCEPTION
    WHEN OTHERS THEN
        ROLLBACK;
        result := 'Failure';
END;
$$
