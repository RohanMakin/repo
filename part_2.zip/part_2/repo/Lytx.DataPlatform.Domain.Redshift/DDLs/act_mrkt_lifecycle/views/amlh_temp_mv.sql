-- liquibase formatted sql --default-schema-name act_mrkt_lifecycle

-- changeset imported_obj_act_mrkt_lifecycle.amlh_temp_mv:65623346-1 
CREATE OR REPLACE VIEW act_mrkt_lifecycle.amlh_temp_mv AS /* RQEV2-hhp2DapoAT */
CREATE MATERIALIZED VIEW act_mrkt_lifecycle.AMLH_TEMP_MV DISTSTYLE ALL AS
SELECT
    *
FROM
    (
        SELECT
            -- Account Info
            act.ID AS ACT_ID,
            -- Account Info
            act.IS_DELETED AS ACT_IS_DELETED,
            act.NAME AS ACT_NAME,
            usr.NAME AS ACT_OWNER,
            usr_role.NAME AS ACT_OWNER_ROLE,
            usro.NAME AS ACT_OPENER,
            act.CREATED_DATE AS ACT_CREATED_DATE,
            act.RECORD_TYPE_ID AS ACT_RECORD_TYPE_ID,
            rcd.NAME AS ACT_RECORD_TYPE_ID_NAME,
            act.MARKETING_LIFECYCLE_AT_SUSPECT__C AS ACT_MARKETING_LIFECYCLE_AT_SUSPECT__C,
            act.BUYING_STAGE_AT_SUSPECT__C AS ACT_BUYING_STAGE_AT_SUSPECT__C,
            act.MARKETING_LIFECYCLE__C AS ACT_MARKETING_LIFECYCLE__C,
            act.BUSINESS_UNIT_2020__C AS ACT_BUSINESS_UNIT_2020__C,
            act.BUSINESS_UNIT_DIVISION__C AS ACT_BUSINESS_UNIT_DIVISION__C,
            -- act.BILLING_MODEL__C as ACT_BILLING_MODEL__C,
            act.MARKET__C AS ACT_MARKET__C,
            act.FLEET_SIZE__C AS ACT_FLEET_SIZE__C,
            act.MARKET_SEGMENT__C AS ACT_MARKET_SEGMENT__C,
            act.INDUSTRY AS ACT_INDUSTRY,
            act.INDUSTRY_DB__C AS ACT_INDUSTRY_DB__C,
            act.INDUSTRY_SECTOR__C AS ACT_INDUSTRY_SECTOR__C,
            act.TERRITORY__C AS ACT_TERRITORY__C,
            act.GEOGRAPHIC_REGION__C AS ACT_GEOGRAPHIC_REGION__C,
            act.STATE_DB__C AS ACT_STATE_DB__C,
            act.ACCOUNT_PROFILE_FIT6SENSE__C AS ACT_ACCOUNT_PROFILE_FIT6SENSE__C,
            act.ACCOUNT_PROFILE_SCORE6SENSE__C AS ACT_ACCOUNT_PROFILE_SCORE6SENSE__C,
            act.INTERNAL_TEST_ACCOUNT__C AS ACT_INTERNAL_TEST_ACCOUNT__C,
            act.ROUTING_REASON__C AS ACT_ROUTING_REASON__C,
            act.MIGRATION_RETURN_TO_MARKETING_REASON__C AS ACT_MIGRATION_RETURN_TO_MARKETING_REASON__C,
            act.STATUS__C AS ACT_STATUS__C,
            act.BUYER_TYPE__C as ACT_BUYER_TYPE__C,
            act.BILLING_MODEL__C AS ACT_BILLING_MODEL__C,
            act.REGION__C AS ACT_REGION__C,
            act.BILLING_STATE AS ACT_BILLING_STATE,
            CASE
            WHEN act.STATUS__C IN (
                'Data Review',
                'Initial Trial',
                'Initial Trial Pending',
                'Prospect',
                'Suspect'
            ) THEN 'Active with Sales'
            WHEN act.STATUS__C IN (
                'Client',
                'Pending Client',
                'Pending Client - Contract Signed'
            ) THEN 'Client'
            WHEN act.STATUS__C IN (
                'Prospect Nuture',
                'Recycle',
                'Suspect Nurture',
                'Suspect Nuture'
            ) THEN 'Marketing Engagement'
            WHEN act.STATUS__C IN (
                'Active',
                'Inactive',
                'Industry Org',
                'Non-Contractual',
                'Other'
            ) THEN 'Other/NA'
            WHEN act.STATUS__C IN ('Pending Forward Consent', 'Referred to Partner') THEN 'Referred to Partner'
            WHEN act.STATUS__C IN (
                'SERVICE SUSPENDED',
                'SERVICE TERMINATED',
                'Terminated'
            ) THEN 'Service Terminated'
            WHEN act.STATUS__C IN (
                'DOA',
                'Duplicate',
                'Duplicate - 6Sense',
                'Out of Business',
                'Unqualified'
            ) THEN 'Unqualified' END AS ACT_STATUS_GROUP,
            act.UNQUALIFIED_REASON__C AS ACT_UNQUALIFIED_REASON__C,
            -- Account Journey Pathx
            act_journey.AMLH_NAME,
            act_journey.ACCOUNT__C AS AMLH_ACCOUNT__C,
            act_journey.RECYCLE_COUNTER__C AS AMLH_RECYCLE_COUNTER__C,
            act_journey.CREATED_DATE AS AMLH_CREATED_DATE,
            act_journey.ACTIVE_MARKETING_LIFECYCLE_RECORD__C AS AMLH_ACTIVE_MARKETING_LIFECYCLE_RECORD__C,
            act_journey.MARKETING_LIFECYCLE_AT_SUSPECT__C AS AMLH_MARKETING_LIFECYCLE_AT_SUSPECT__C,
            act_journey.BUYING_STAGE_AT_SUSPECT__C AS AMLH_BUYING_STAGE_AT_SUSPECT__C,
            act_journey.ROUTING_REASON__C AS AMLH_ROUTING_REASON__C,
            act_journey.UNQUALIFIED_REASON__C AS AMLH_UNQUALIFIED_REASON__C,
            act_journey.OPPORTUNITY__C AS AMLH_OPPORTUNITY__C,
            act_journey.ACT_JOURNEY_PATH AS AMLH_ACT_JOURNEY_PATH,
            act_journey.ACT_JOURNEY_PATH_CNT AS AMLH_ACT_JOURNEY_PATH_CNT,
            act_journey.ACT_JOURNEY_PATH_ID AS AMLH_ACT_JOURNEY_PATH_ID,
            act_journey.ACCOUNT_JOURNEY_PATH_LIFECYCLE_NONLINEAR_FLAG AS AMLH_ACCOUNT_JOURNEY_PATH_LIFECYCLE_NONLINEAR_FLAG,
            act_journey.ACCOUNT_JOURNEY_PATH_LIFECYCLE_NONLINEAR_FLAG_REASON AS AMLH_ACCOUNT_JOURNEY_PATH_LIFECYCLE_NONLINEAR_FLAG_REASON,
            -- Lifecycle Stages
            act.COLD_ACCOUNT_DATE_STAMP__C as ACT_COLD_ACCOUNT_DATE_STAMP__C,
            CAST(act.COLD_ACCOUNT_DATE_STAMP__C as DATE) AS ACT_COLD_ACCOUNT_DATE_STAMP__C_CAST,
            amlh_raw.COLD_ACCOUNT_DATE_STAMP__C AS AMLH_COLD_ACCOUNT_DATE_STAMP__C,
            CAST(amlh_raw.COLD_ACCOUNT_DATE_STAMP__C as DATE) AS AMLH_COLD_ACCOUNT_DATE_STAMP__C_CAST,
            cast(
                date_trunc('week', amlh_raw.COLD_ACCOUNT_DATE_STAMP__C) + '6 days':: interval as date
            ) as AMLH_COLD_ACCOUNT_DATE_EOW,
            last_day(amlh_raw.COLD_ACCOUNT_DATE_STAMP__C) as AMLH_COLD_ACCOUNT_DATE_EOM,
            cast(
                dateadd(
                    day,
                    -1,
                    dateadd(
                        QTR,
                        1,
                        DATE_TRUNC('QTR', amlh_raw.COLD_ACCOUNT_DATE_STAMP__C)
                    )
                ) as date
            ) as AMLH_COLD_ACCOUNT_DATE_EOQ,
            cast(
                dateadd(
                    day,
                    -1,
                    dateadd(
                        year,
                        1,
                        DATE_TRUNC('year', amlh_raw.COLD_ACCOUNT_DATE_STAMP__C)
                    )
                ) as date
            ) as AMLH_COLD_ACCOUNT_DATE_EOY,
            act.MEA_DATE_STAMP__C as ACT_MEA_DATE_STAMP__C,
            CAST(act.MEA_DATE_STAMP__C as DATE) AS ACT_MEA_DATE_STAMP__C_CAST,
            amlh_raw.MEA_DATE_STAMP__C AS AMLH_MEA_DATE_STAMP__C,
            CAST(amlh_raw.MEA_DATE_STAMP__C as DATE) AS AMLH_MEA_DATE_STAMP__C_CAST,
            cast(
                date_trunc('week', amlh_raw.MEA_DATE_STAMP__C) + '6 days':: interval as date
            ) as AMLH_MEA_DATE_EOW,
            last_day(amlh_raw.MEA_DATE_STAMP__C) as AMLH_MEA_DATE_EOM,
            cast(
                dateadd(
                    day,
                    -1,
                    dateadd(
                        QTR,
                        1,
                        DATE_TRUNC('QTR', amlh_raw.MEA_DATE_STAMP__C)
                    )
                ) as date
            ) as AMLH_MEA_DATE_EOQ,
            cast(
                dateadd(
                    day,
                    -1,
                    dateadd(
                        year,
                        1,
                        DATE_TRUNC('year', amlh_raw.MEA_DATE_STAMP__C)
                    )
                ) as date
            ) as AMLH_MEA_DATE_EOY,
            act.MQA_DATE_STAMP__C as ACT_MQA_DATE_STAMP__C,
            CAST(act.MQA_DATE_STAMP__C as DATE) AS ACT_MQA_DATE_STAMP__C_CAST,
            amlh_raw.MQA_DATE_STAMP__C AS AMLH_MQA_DATE_STAMP__C,
            CAST(amlh_raw.MQA_DATE_STAMP__C as DATE) AS AMLH_MQA_DATE_STAMP__C_CAST,
            cast(
                date_trunc('week', amlh_raw.MQA_DATE_STAMP__C) + '6 days':: interval as date
            ) as AMLH_MQA_DATE_EOW,
            last_day(amlh_raw.MQA_DATE_STAMP__C) as AMLH_MQA_DATE_EOM,
            cast(
                dateadd(
                    day,
                    -1,
                    dateadd(
                        QTR,
                        1,
                        DATE_TRUNC('QTR', amlh_raw.MQA_DATE_STAMP__C)
                    )
                ) as date
            ) as AMLH_MQA_DATE_EOQ,
            cast(
                dateadd(
                    day,
                    -1,
                    dateadd(
                        year,
                        1,
                        DATE_TRUNC('year', amlh_raw.MQA_DATE_STAMP__C)
                    )
                ) as date
            ) as AMLH_MQA_DATE_EOY,
            act.SUSPECT_DATE_STAMP__C as ACT_SUSPECT_DATE_STAMP__C,
            CAST(act.SUSPECT_DATE_STAMP__C as DATE) AS ACT_SUSPECT_DATE_STAMP__C_CAST,
            amlh_raw.SUSPECT_DATE_STAMP__C AS AMLH_SUSPECT_DATE_STAMP__C,
            CAST(amlh_raw.SUSPECT_DATE_STAMP__C as DATE) AS AMLH_SUSPECT_DATE_STAMP__C_CAST,
            cast(
                date_trunc('week', amlh_raw.SUSPECT_DATE_STAMP__C) + '6 days':: interval as date
            ) as AMLH_SUSPECT_DATE_EOW,
            last_day(amlh_raw.SUSPECT_DATE_STAMP__C) as AMLH_SUSPECT_DATE_EOM,
            cast(
                dateadd(
                    day,
                    -1,
                    dateadd(
                        QTR,
                        1,
                        DATE_TRUNC('QTR', amlh_raw.SUSPECT_DATE_STAMP__C)
                    )
                ) as date
            ) as AMLH_SUSPECT_DATE_EOQ,
            cast(
                dateadd(
                    day,
                    -1,
                    dateadd(
                        year,
                        1,
                        DATE_TRUNC('year', amlh_raw.SUSPECT_DATE_STAMP__C)
                    )
                ) as date
            ) as AMLH_SUSPECT_DATE_EOY,
            act.SUSPECT_WORKING_DATE_STAMP__C as ACT_SUSPECT_WORKING_DATE_STAMP__C,
            CAST(act.SUSPECT_WORKING_DATE_STAMP__C as DATE) AS ACT_SUSPECT_WORKING_DATE_STAMP__C_CAST,
            amlh_raw.SUSPECT_WORKING_DATE_STAMP__C AS AMLH_SUSPECT_WORKING_DATE_STAMP__C,
            CAST(amlh_raw.SUSPECT_WORKING_DATE_STAMP__C as DATE) AS AMLH_SUSPECT_WORKING_DATE_STAMP__C_CAST,
            cast(
                date_trunc('week', amlh_raw.SUSPECT_WORKING_DATE_STAMP__C) + '6 days':: interval as date
            ) as AMLH_SUSPECT_WORKING_DATE_EOW,
            last_day(amlh_raw.SUSPECT_WORKING_DATE_STAMP__C) as AMLH_SUSPECT_WORKING_DATE_EOM,
            cast(
                dateadd(
                    day,
                    -1,
                    dateadd(
                        QTR,
                        1,
                        DATE_TRUNC('QTR', amlh_raw.SUSPECT_WORKING_DATE_STAMP__C)
                    )
                ) as date
            ) as AMLH_SUSPECT_WORKING_DATE_EOQ,
            cast(
                dateadd(
                    day,
                    -1,
                    dateadd(
                        year,
                        1,
                        DATE_TRUNC('year', amlh_raw.SUSPECT_WORKING_DATE_STAMP__C)
                    )
                ) as date
            ) as AMLH_SUSPECT_WORKING_DATE_EOY,
            act.PROSPECT_DATE_STAMP__C as ACT_PROSPECT_DATE_STAMP__C,
            CAST(act.PROSPECT_DATE_STAMP__C as DATE) AS ACT_PROSPECT_DATE_STAMP__C_CAST,
            amlh_raw.PROSPECT_DATE_STAMP__C AS AMLH_PROSPECT_DATE_STAMP__C,
            CAST(amlh_raw.PROSPECT_DATE_STAMP__C as DATE) AS AMLH_PROSPECT_DATE_STAMP__C_CAST,
            cast(
                date_trunc('week', amlh_raw.PROSPECT_DATE_STAMP__C) + '6 days':: interval as date
            ) as AMLH_PROSPECT_DATE_EOW,
            last_day(amlh_raw.PROSPECT_DATE_STAMP__C) as AMLH_PROSPECT_DATE_EOM,
            cast(
                dateadd(
                    day,
                    -1,
                    dateadd(
                        QTR,
                        1,
                        DATE_TRUNC('QTR', amlh_raw.PROSPECT_DATE_STAMP__C)
                    )
                ) as date
            ) as AMLH_PROSPECT_DATE_EOQ,
            cast(
                dateadd(
                    day,
                    -1,
                    dateadd(
                        year,
                        1,
                        DATE_TRUNC('year', amlh_raw.PROSPECT_DATE_STAMP__C)
                    )
                ) as date
            ) as AMLH_PROSPECT_DATE_EYW,
            act.CUSTOMER_DATE_STAMP__C as ACT_CUSTOMER_DATE_STAMP__C,
            CAST(act.CUSTOMER_DATE_STAMP__C as DATE) AS ACT_CUSTOMER_DATE_STAMP__C_CAST,
            amlh_raw.CUSTOMER_DATE_STAMP__C AS AMLH_CUSTOMER_DATE_STAMP__C,
            CAST(amlh_raw.CUSTOMER_DATE_STAMP__C as DATE) AS AMLH_CUSTOMER_DATE_STAMP__C_CAST,
            cast(
                date_trunc('week', amlh_raw.CUSTOMER_DATE_STAMP__C) + '6 days':: interval as date
            ) as AMLH_CUSTOMER_DATE_EOW,
            last_day(amlh_raw.CUSTOMER_DATE_STAMP__C) as AMLH_CUSTOMER_DATE_EOM,
            cast(
                dateadd(
                    day,
                    -1,
                    dateadd(
                        QTR,
                        1,
                        DATE_TRUNC('QTR', amlh_raw.CUSTOMER_DATE_STAMP__C)
                    )
                ) as date
            ) as AMLH_CUSTOMER_DATE_EOQ,
            cast(
                dateadd(
                    day,
                    -1,
                    dateadd(
                        year,
                        1,
                        DATE_TRUNC('year', amlh_raw.CUSTOMER_DATE_STAMP__C)
                    )
                ) as date
            ) as AMLH_CUSTOMER_DATE_EOY,
            act.RECYCLED_DATE_STAMP__C as ACT_RECYCLED_DATE_STAMP__C,
            CAST(act.RECYCLED_DATE_STAMP__C as DATE) AS ACT_RECYCLED_DATE_STAMP__C_CAST,
            amlh_raw.RECYCLE_DATE_STAMP__C AS AMLH_RECYCLED_DATE_STAMP__C,
            CAST(amlh_raw.RECYCLE_DATE_STAMP__C as DATE) AS AMLH_RECYCLED_DATE_STAMP__C_CAST,
            cast(
                date_trunc('week', amlh_raw.RECYCLE_DATE_STAMP__C) + '6 days':: interval as date
            ) as AMLH_RECYCLED_DATE_EOW,
            last_day(amlh_raw.RECYCLE_DATE_STAMP__C) as AMLH_RECYCLED_DATE_EOM,
            cast(
                dateadd(
                    day,
                    -1,
                    dateadd(
                        QTR,
                        1,
                        DATE_TRUNC('QTR', amlh_raw.RECYCLE_DATE_STAMP__C)
                    )
                ) as date
            ) as AMLH_RECYCLED_DATE_EOQ,
            cast(
                dateadd(
                    day,
                    -1,
                    dateadd(
                        year,
                        1,
                        DATE_TRUNC('year', amlh_raw.RECYCLE_DATE_STAMP__C)
                    )
                ) as date
            ) as AMLH_RECYCLED_DATE_EOY,
            act.UNQUALIFIED_DATE_STAMP__C as ACT_UNQUALIFIED_DATE_STAMP__C,
            CAST(act.UNQUALIFIED_DATE_STAMP__C as DATE) AS ACT_UNQUALIFIED_DATE_STAMP__C_CAST,
            amlh_raw.UNQUALIFIED_DATE_STAMP__C AS AMLH_UNQUALIFIED_DATE_STAMP__C,
            CAST(amlh_raw.UNQUALIFIED_DATE_STAMP__C as DATE) AS AMLH_UNQUALIFIED_DATE_STAMP__C_CAST,
            cast(
                date_trunc('week', amlh_raw.UNQUALIFIED_DATE_STAMP__C) + '6 days':: interval as date
            ) as AMLH_UNQUALIFIED_DATE_EOW,
            last_day(amlh_raw.UNQUALIFIED_DATE_STAMP__C) as AMLH_UNQUALIFIED_DATE_EOM,
            cast(
                dateadd(
                    day,
                    -1,
                    dateadd(
                        QTR,
                        1,
                        DATE_TRUNC('QTR', amlh_raw.UNQUALIFIED_DATE_STAMP__C)
                    )
                ) as date
            ) as AMLH_UNQUALIFIED_DATE_EOQ,
            cast(
                dateadd(
                    day,
                    -1,
                    dateadd(
                        year,
                        1,
                        DATE_TRUNC('year', amlh_raw.UNQUALIFIED_DATE_STAMP__C)
                    )
                ) as date
            ) as AMLH_UNQUALIFIED_DATE_EOY,
            amlh_raw.RECYCLE_EXP_DATE__C AS AMLH_RECYCLE_EXP_DATE__C,
            CAST(amlh_raw.RECYCLE_EXP_DATE__C as DATE) AS AMLH_RECYCLE_EXP_DATE__C_CAST,
            cast(
                date_trunc('week', amlh_raw.RECYCLE_EXP_DATE__C) + '6 days':: interval as date
            ) as AMLH_RECYCLE_EXP_DATE__C_EOW,
            last_day(amlh_raw.RECYCLE_EXP_DATE__C) as AMLH_RECYCLE_EXP_DATE__C_EOM,
            cast(
                dateadd(
                    day,
                    -1,
                    dateadd(
                        QTR,
                        1,
                        DATE_TRUNC('QTR', amlh_raw.RECYCLE_EXP_DATE__C)
                    )
                ) as date
            ) as AMLH_RECYCLE_EXP_DATE__C_EOQ,
            cast(
                dateadd(
                    day,
                    -1,
                    dateadd(
                        year,
                        1,
                        DATE_TRUNC('year', amlh_raw.RECYCLE_EXP_DATE__C)
                    )
                ) as date
            ) as AMLH_RECYCLE_EXP_DATE__C_EOY,
            -- Lifecycle Stage Flags
            (
                CASE
                WHEN amlh_raw.RECYCLE_DATE_STAMP__C IS NOT NULL THEN 'Recycled'
                ELSE 'New' END
            ) AS AMLH_RECYCLED_VS_NEW_FLAG,
            CASE
            WHEN amlh_raw.MARKETING_LIFECYCLE_AT_SUSPECT__C IS NOT NULL THEN 1
            ELSE 0 END AS AMLH_FLAG_HAS_MARKETING_LIFECYCLE_AT_SUSPECT__C,
            (
                CASE
                WHEN amlh_raw.COLD_ACCOUNT_DATE_STAMP__C IS NOT NULL THEN 1
                ELSE 0 END
            ) AS AMLH_ACCOUNT_LIFECYCLE_COLD_FLAG,
            (
                CASE
                WHEN amlh_raw.MEA_DATE_STAMP__C IS NOT NULL THEN 1
                ELSE 0 END
            ) AS AMLH_ACCOUNT_LIFECYCLE_MEA_FLAG,
            (
                CASE
                WHEN amlh_raw.MQA_DATE_STAMP__C IS NOT NULL THEN 1
                ELSE 0 END
            ) AS AMLH_ACCOUNT_LIFECYCLE_MQA_FLAG,
            (
                CASE
                WHEN amlh_raw.SUSPECT_DATE_STAMP__C IS NOT NULL THEN 1
                ELSE 0 END
            ) AS AMLH_ACCOUNT_LIFECYCLE_SUSPECT_FLAG,
            (
                CASE
                WHEN amlh_raw.SUSPECT_WORKING_DATE_STAMP__C IS NOT NULL THEN 1
                ELSE 0 END
            ) AS AMLH_ACCOUNT_LIFECYCLE_SUSPECT_WORKING_FLAG,
            (
                CASE
                WHEN amlh_raw.PROSPECT_DATE_STAMP__C IS NOT NULL THEN 1
                ELSE 0 END
            ) AS AMLH_ACCOUNT_LIFECYCLE_PROSPECT_FLAG,
            (
                CASE
                WHEN amlh_raw.CUSTOMER_DATE_STAMP__C IS NOT NULL THEN 1
                ELSE 0 END
            ) AS AMLH_ACCOUNT_LIFECYCLE_CUSTOMER_FLAG,
            (
                CASE
                WHEN amlh_raw.RECYCLE_DATE_STAMP__C IS NOT NULL THEN 1
                ELSE 0 END
            ) AS AMLH_ACCOUNT_LIFECYCLE_RECYCLED_FLAG,
            (
                CASE
                WHEN amlh_raw.UNQUALIFIED_DATE_STAMP__C IS NOT NULL THEN 1
                ELSE 0 END
            ) AS AMLH_ACCOUNT_LIFECYCLE_UNQUALIFIED_FLAG,
            (
                CASE
                WHEN DATEDIFF(
                    MINUTE,
                    amlh_raw.SUSPECT_DATE_STAMP__C,
                    amlh_raw.MQA_DATE_STAMP__C
                ) between 0
                and 2 THEN 1
                ELSE 0 END
            ) AS AMLH_ACCOUNT_LIFECYCLE_SUSPECT_MQA_TIMESTAMP_FLAG,
            CASE
            WHEN amlh_raw.MARKETING_LIFECYCLE_AT_SUSPECT__C IS NULL THEN 'Not Eligible: No Lifecycle'
            WHEN (
                CASE
                WHEN amlh_raw.MARKETING_LIFECYCLE_AT_SUSPECT__C IS NULL THEN NULL
                WHEN amlh_raw.MARKETING_LIFECYCLE_AT_SUSPECT__C = 'Cold Account' THEN amlh_raw.COLD_ACCOUNT_DATE_STAMP__C
                WHEN amlh_raw.MARKETING_LIFECYCLE_AT_SUSPECT__C = 'MEA' THEN amlh_raw.MEA_DATE_STAMP__C
                WHEN amlh_raw.MARKETING_LIFECYCLE_AT_SUSPECT__C = 'MQA' THEN amlh_raw.MQA_DATE_STAMP__C
                WHEN amlh_raw.MARKETING_LIFECYCLE_AT_SUSPECT__C = 'Suspect Working' THEN amlh_raw.SUSPECT_WORKING_DATE_STAMP__C
                WHEN amlh_raw.MARKETING_LIFECYCLE_AT_SUSPECT__C = 'Recycled' THEN amlh_raw.RECYCLE_DATE_STAMP__C
                WHEN amlh_raw.MARKETING_LIFECYCLE_AT_SUSPECT__C = 'Unqualified' THEN amlh_raw.UNQUALIFIED_DATE_STAMP__C END
            ) -- AS COMPARE_DATE,
            > amlh_raw.SUSPECT_DATE_STAMP__C THEN 'Not Eligible: Lifecycle > Suspect Date'
            WHEN (
                amlh_raw.MARKETING_LIFECYCLE_AT_SUSPECT__C IS NOT NULL
                AND amlh_raw.SUSPECT_DATE_STAMP__C IS NULL
            ) THEN 'Eligible: No Suspect Date'
            WHEN (
                amlh_raw.MARKETING_LIFECYCLE_AT_SUSPECT__C IS NOT NULL
                AND amlh_raw.SUSPECT_DATE_STAMP__C IS NOT NULL
            ) THEN 'Eligible: Has  Suspect Date'
            ELSE 'Other' END AS AMLH_FLAG_TO_CHECK,
            -- Parent Account Info
            (
                CASE
                WHEN (act.PARENT_ID IS NULL) THEN 0
                ELSE 1 END
            ) AS ACT_HAS_PARENT_ACT_FLAG,
            (
                CASE
                WHEN (act.PARENT_ID = '000000000000000AAA') THEN 1
                ELSE 0 END
            ) AS ACT_PARENT_ACT_FLAG,
            act.PARENT_ID AS ACT_PARENT_ID,
            parent_act.PARENT_ACT_IS_DELETED,
            parent_act.PARENT_ACT_NAME,
            parent_act.PARENT_ACT_CREATED_DATE,
            parent_act.PARENT_ACT_RECORD_TYPE_ID,
            parent_act.PARENT_ACT_RECORD_TYPE_ID_NAME,
            parent_act.PARENT_ACT_MARKETING_LIFECYCLE_AT_SUSPECT__C,
            parent_act.PARENT_ACT_MARKETING_LIFECYCLE__C,
            parent_act.PARENT_ACT_BUSINESS_UNIT_2020__C,
            parent_act.PARENT_ACT_BUSINESS_UNIT_DIVISION__C,
            parent_act.PARENT_ACT_MARKET__C,
            parent_act.PARENT_ACT_FLEET_SIZE__C,
            parent_act.PARENT_ACT_MARKET_SEGMENT__C,
            parent_act.PARENT_ACT_INDUSTRY,
            parent_act.PARENT_ACT_INDUSTRY_DB__C,
            parent_act.PARENT_ACT_INDUSTRY_SECTOR__C,
            parent_act.PARENT_ACT_TERRITORY__C,
            parent_act.PARENT_ACT_STATE_DB__C,
            parent_act.PARENT_ACT_ACCOUNT_PROFILE_FIT6SENSE__C,
            parent_act.PARENT_ACT_ACCOUNT_PROFILE_SCORE6SENSE__C
        FROM
            DP_PROD_DB.SALESFORCE.ACCOUNT AS act
            LEFT JOIN DP_PROD_DB.SALESFORCE.USER usr ON act.owner_id = usr.ID
            AND usr.NAME NOT IN (
                'Scott Rose',
                'Rick Walters',
                'Micah Rea',
                'Compliance',
                'ELD Compliance Manager'
            ) -- ACT OWNER USER ROLE
            LEFT JOIN DP_PROD_DB.SALESFORCE.USER_ROLE usr_role ON usr.USER_ROLE_ID = usr_role.ID
            LEFT JOIN DP_PROD_DB.SALESFORCE.USER usro ON act.OPENER__C = usro.ID
            AND usro.NAME NOT IN (
                'Scott Rose',
                'Rick Walters',
                'Micah Rea',
                'Compliance',
                'ELD Compliance Manager'
            ) -- Record Type
            INNER JOIN DP_PROD_DB.SALESFORCE.RECORD_TYPE as rcd ON act.RECORD_TYPE_ID = rcd.ID
            AND (
                rcd.ID = '012300000005VEYAA2'
                OR rcd.ID = '0126R000001UknZQAS'
            ) -- Parent Account
            LEFT JOIN (
                -- Parent Account Information
                SELECT
                    DISTINCT act.ID,
                    parent_act.PARENT_ID,
                    parent_act.IS_DELETED as PARENT_ACT_IS_DELETED,
                    parent_act.NAME as PARENT_ACT_NAME,
                    parent_act.CREATED_DATE as PARENT_ACT_CREATED_DATE,
                    parent_act.RECORD_TYPE_ID as PARENT_ACT_RECORD_TYPE_ID,
                    rcd.NAME as PARENT_ACT_RECORD_TYPE_ID_NAME,
                    parent_act.MARKETING_LIFECYCLE_AT_SUSPECT__C as PARENT_ACT_MARKETING_LIFECYCLE_AT_SUSPECT__C,
                    parent_act.MARKETING_LIFECYCLE__C as PARENT_ACT_MARKETING_LIFECYCLE__C,
                    parent_act.BUSINESS_UNIT_2020__C as PARENT_ACT_BUSINESS_UNIT_2020__C,
                    parent_act.BUSINESS_UNIT_DIVISION__C as PARENT_ACT_BUSINESS_UNIT_DIVISION__C,
                    parent_act.MARKET__C as PARENT_ACT_MARKET__C,
                    parent_act.FLEET_SIZE__C as PARENT_ACT_FLEET_SIZE__C,
                    parent_act.MARKET_SEGMENT__C as PARENT_ACT_MARKET_SEGMENT__C,
                    parent_act.INDUSTRY as PARENT_ACT_INDUSTRY,
                    parent_act.INDUSTRY_DB__C as PARENT_ACT_INDUSTRY_DB__C,
                    parent_act.INDUSTRY_SECTOR__C as PARENT_ACT_INDUSTRY_SECTOR__C,
                    parent_act.TERRITORY__C as PARENT_ACT_TERRITORY__C,
                    parent_act.STATE_DB__C as PARENT_ACT_STATE_DB__C,
                    parent_act.ACCOUNT_PROFILE_FIT6SENSE__C as PARENT_ACT_ACCOUNT_PROFILE_FIT6SENSE__C,
                    parent_act.ACCOUNT_PROFILE_SCORE6SENSE__C as PARENT_ACT_ACCOUNT_PROFILE_SCORE6SENSE__C
                FROM
                    DP_PROD_DB.SALESFORCE.ACCOUNT AS act
                    LEFT JOIN DP_PROD_DB.SALESFORCE.ACCOUNT as parent_act ON act.PARENT_ID = parent_act.ID
                    LEFT JOIN DP_PROD_DB.SALESFORCE.RECORD_TYPE as rcd ON parent_act.RECORD_TYPE_ID = rcd.ID
            ) as parent_act ON act.ID = parent_act.ID
            RIGHT OUTER JOIN (
                SELECT
                    act_journey_prep.ACCOUNT__C,
                    act_journey_prep.RECYCLE_COUNTER__C,
                    act_journey_prep.CREATED_DATE,
                    act_journey_prep.ACTIVE_MARKETING_LIFECYCLE_RECORD__C,
                    act_journey_prep.MARKETING_LIFECYCLE_AT_SUSPECT__C,
                    act_journey_prep.BUYING_STAGE_AT_SUSPECT__C,
                    act_journey_prep.ROUTING_REASON__C,
                    act_journey_prep.UNQUALIFIED_REASON__C,
                    act_journey_prep.OPPORTUNITY__C,
                    act_journey_prep.ACCOUNT_JOURNEY_PATH_LIFECYCLE_NONLINEAR_FLAG_REASON,
                    act_journey_prep.ACCOUNT_JOURNEY_PATH_LIFECYCLE_NONLINEAR_FLAG,
                    act_journey_prep.ACT_JOURNEY_PATH_CNT,
                    act_journey_prep.NAME AS AMLH_NAME,
                    'COLD ' || cast(cold AS char(4)) || ' --> ' || 'MEA ' || cast(mea as char(4)) || ' --> ' || 'MQA ' || cast(mqa AS char(4)) || ' --> ' || 'SUS ' || cast(suspect AS char(4)) || ' --> ' || 'S_W ' || cast(suspect_working AS char(4)) || ' --> ' || 'PROS ' || cast(prospect AS char(4)) || ' --> ' || 'CUST ' || cast(customer AS char(4)) || ' --> ' || 'REC ' || cast(recycled AS char(4)) || ' --> ' || 'UNQ ' || cast(unqualified AS char(4)) AS act_journey_path,
                    cast(cold AS char(4)) || ' --> ' || cast(mea as char(4)) || ' --> ' || cast(mqa AS char(4)) || ' --> ' || cast(suspect AS char(4)) || ' --> ' || cast(suspect_working AS char(4)) || ' --> ' || cast(prospect AS char(4)) || ' --> ' || cast(customer AS char(4)) || ' --> ' || cast(recycled AS char(4)) || ' --> ' || cast(unqualified AS char(4)) AS act_journey_path_id
                FROM
                    (
                        SELECT
                            x.ACCOUNT__C,
                            x.RECYCLE_COUNTER__C,
                            x.CREATED_DATE,
                            x.ACTIVE_MARKETING_LIFECYCLE_RECORD__C,
                            x.MARKETING_LIFECYCLE_AT_SUSPECT__C,
                            x.BUYING_STAGE_AT_SUSPECT__C,
                            x.ROUTING_REASON__C,
                            x.UNQUALIFIED_REASON__C,
                            x.OPPORTUNITY__C,
                            x.NAME,
                            x.account_journey_path_lifecycle_nonlinear_flag_reason,
                            x.account_journey_path_lifecycle_nonlinear_flag,
                            coalesce(x.cold_order, 0) as cold,
                            coalesce(x.mea_order, 0) as mea,
                            coalesce(x.mqa_order, 0) as mqa,
                            coalesce(x.suspect_order, 0) as suspect,
                            coalesce(x.suspect_working_order, 0) as suspect_working,
                            coalesce(x.prospect_order, 0) as prospect,
                            coalesce(x.customer_order, 0) as customer,
                            coalesce(x.recycled_order, 0) as recycled,
                            coalesce(x.unqualified_order, 0) as unqualified,
                            x.journey_length AS ACT_JOURNEY_PATH_CNT
                        from
                            (
                                SELECT
                                    DISTINCT ACCOUNT__C,
                                    RECYCLE_COUNTER__C,
                                    CREATED_DATE,
                                    ACTIVE_MARKETING_LIFECYCLE_RECORD__C,
                                    MARKETING_LIFECYCLE_AT_SUSPECT__C,
                                    BUYING_STAGE_AT_SUSPECT__C,
                                    ROUTING_REASON__C,
                                    UNQUALIFIED_REASON__C,
                                    OPPORTUNITY__C,
                                    Name,
                                    CASE
                                    WHEN cold_order IS NULL
                                    OR mea_order = 1
                                    OR mqa_order = 1
                                    OR suspect_order = 1
                                    OR suspect_working_order = 1
                                    OR prospect_order = 1
                                    OR customer_order = 1
                                    OR recycled_order = 1
                                    OR unqualified_order = 1
                                    OR prospect_order = cold_order + 1
                                    OR (
                                        recycled_order = cold_order + 1
                                        AND journey_length <> 2
                                    )
                                    OR (
                                        unqualified_order = cold_order + 1
                                        AND journey_length <> 2
                                    )
                                    OR (
                                        customer_order = cold_order + 1
                                        AND journey_length <> 2
                                    )
                                    OR suspect_order = recycled_order + 1
                                    OR suspect_order = unqualified_order + 1
                                    OR customer_order = unqualified_order + 1
                                    OR unqualified_order = customer_order + 1
                                    OR (suspect_order > prospect_order)
                                    OR (recycled_order < journey_length)
                                    OR (unqualified_order < journey_length)
                                    OR (customer_order < journey_length)
                                    OR (mea_order > mqa_order)
                                    OR (
                                        suspect_order IS NULL
                                        AND prospect_order IS NOT NULL
                                    )
                                    OR (
                                        mqa_order IS NOT NULL
                                        AND mea_order IS NULL
                                    ) THEN 'Non-Linear'
                                    ELSE 'Linear' END AS ACCOUNT_JOURNEY_PATH_LIFECYCLE_NONLINEAR_FLAG,
                                    cold_order,
                                    mea_order,
                                    mqa_order,
                                    suspect_order,
                                    suspect_working_order,
                                    prospect_order,
                                    customer_order,
                                    recycled_order,
                                    unqualified_order,
                                    journey_length,
                                    CASE
                                    WHEN cold_order IS NULL THEN 'cold_order IS NULL'
                                    WHEN mea_order = 1 THEN 'mea_order = 1'
                                    WHEN mqa_order = 1 THEN 'mqa_order = 1'
                                    WHEN suspect_order = 1 THEN 'suspect_order = 1'
                                    WHEN suspect_working_order = 1 THEN 'suspect_working_order = 1'
                                    WHEN prospect_order = 1 THEN 'prospect_order = 1'
                                    WHEN customer_order = 1 THEN 'customer_order = 1'
                                    WHEN recycled_order = 1 THEN 'recycled_order = 1'
                                    WHEN unqualified_order = 1 THEN 'unqualified_order = 1'
                                    WHEN prospect_order = cold_order + 1 THEN 'prospect_order = cold_order + 1'
                                    WHEN (
                                        recycled_order = cold_order + 1
                                        AND journey_length <> 2
                                    ) THEN 'cold, recycle, more'
                                    WHEN (
                                        unqualified_order = cold_order + 1
                                        AND journey_length <> 2
                                    ) THEN 'cold, unqualifed, more'
                                    WHEN (
                                        customer_order = cold_order + 1
                                        AND journey_length <> 2
                                    ) THEN 'cold, customer, more'
                                    WHEN suspect_order = recycled_order + 1 THEN 'suspect_order = recycled_order + 1'
                                    WHEN suspect_order = unqualified_order + 1 THEN 'suspect_order = unqualified_order + 1'
                                    WHEN customer_order = unqualified_order + 1 THEN 'customer_order = unqualified_order + 1'
                                    WHEN unqualified_order = customer_order + 1 THEN 'unqualified_order = customer_order + 1'
                                    WHEN recycled_order < journey_length THEN 'recycled_order < journey_length '
                                    WHEN unqualified_order < journey_length THEN 'unqualified_order < journey_length'
                                    WHEN customer_order < journey_length THEN 'customer_order < journey_length'
                                    WHEN mea_order > mqa_order THEN 'mea_order > mqa_order'
                                    WHEN (
                                        suspect_order IS NULL
                                        AND prospect_order IS NOT NULL
                                    ) THEN 'suspect_order IS NULL & prospect_order IS NOT NULL'
                                    WHEN (
                                        mqa_order IS NOT NULL
                                        AND mea_order IS NULL
                                    ) THEN 'mqa_order IS NOT NULL & mea_order IS NULL'
                                    ELSE 'Linear' END AS ACCOUNT_JOURNEY_PATH_LIFECYCLE_NONLINEAR_FLAG_REASON
                                FROM
                                    (
                                        SELECT
                                            *,
                                            CASE
                                            WHEN cold_place = 0 THEN NULL
                                            ELSE cold_place END AS cold_order,
                                            CASE
                                            WHEN mea_place = 0 THEN NULL
                                            ELSE mea_place END AS mea_order,
                                            CASE
                                            WHEN mqa_place = 0 THEN NULL
                                            ELSE mqa_place END AS mqa_order,
                                            CASE
                                            WHEN suspect_place = 0 THEN NULL
                                            ELSE suspect_place END AS suspect_order,
                                            CASE
                                            WHEN suspect_working_place = 0 THEN NULL
                                            ELSE suspect_working_place END AS suspect_working_order,
                                            CASE
                                            WHEN prospect_place = 0 THEN NULL
                                            ELSE prospect_place END AS prospect_order,
                                            CASE
                                            WHEN customer_place = 0 THEN NULL
                                            ELSE customer_place END AS customer_order,
                                            CASE
                                            WHEN recycled_place = 0 THEN NULL
                                            ELSE recycled_place END AS recycled_order,
                                            CASE
                                            WHEN unqualified_place = 0 THEN NULL
                                            ELSE unqualified_place END AS unqualified_order
                                        FROM
                                            (
                                                SELECT
                                                    DISTINCT ACCOUNT__C,
                                                    RECYCLE_COUNTER__C,
                                                    CREATED_DATE,
                                                    ACTIVE_MARKETING_LIFECYCLE_RECORD__C,
                                                    MARKETING_LIFECYCLE_AT_SUSPECT__C,
                                                    BUYING_STAGE_AT_SUSPECT__C,
                                                    ROUTING_REASON__C,
                                                    UNQUALIFIED_REASON__C,
                                                    OPPORTUNITY__C,
                                                    Name,
                                                    --created_date,
                                                    COLD_ACCOUNT_DATE_STAMP__CAST AS cold_place,
                                                    MEA_DATE_STAMP__CAST AS mea_place,
                                                    MQA_DATE_STAMP__CAST AS mqa_place,
                                                    SUSPECT_DATE_STAMP__CAST AS suspect_place,
                                                    SUSPECT_WORKING_DATE_STAMP__CAST AS suspect_working_place,
                                                    PROSPECT_DATE_STAMP__CAST AS prospect_place,
                                                    CUSTOMER_DATE_STAMP__CAST AS customer_place,
                                                    RECYCLED_DATE_STAMP__CAST AS recycled_place,
                                                    UNQUALIFIED_DATE_STAMP__CAST AS unqualified_place,
                                                    CASE
                                                    WHEN cold_place > mea_place
                                                    AND cold_place > mqa_place
                                                    AND cold_place > suspect_place
                                                    AND cold_place > suspect_working_place
                                                    AND cold_place > prospect_place
                                                    AND cold_place > customer_place
                                                    AND cold_place > recycled_place
                                                    AND cold_place > unqualified_place THEN cold_place
                                                    WHEN mea_place > cold_place
                                                    AND mea_place > mqa_place
                                                    AND mea_place > suspect_place
                                                    AND mea_place > suspect_working_place
                                                    AND mea_place > prospect_place
                                                    AND mea_place > customer_place
                                                    AND mea_place > recycled_place
                                                    AND mea_place > unqualified_place THEN mea_place
                                                    WHEN mqa_place > cold_place
                                                    AND mqa_place > mea_place
                                                    AND mqa_place > suspect_place
                                                    AND mqa_place > suspect_working_place
                                                    AND mqa_place > prospect_place
                                                    AND mqa_place > customer_place
                                                    AND mqa_place > recycled_place
                                                    AND mqa_place > unqualified_place THEN mqa_place
                                                    WHEN suspect_place > cold_place
                                                    AND suspect_place > mea_place
                                                    AND suspect_place > mqa_place
                                                    AND suspect_place > suspect_working_place
                                                    AND suspect_place > prospect_place
                                                    AND suspect_place > customer_place
                                                    AND suspect_place > recycled_place
                                                    AND suspect_place > unqualified_place THEN suspect_place
                                                    WHEN suspect_working_place > cold_place
                                                    AND suspect_working_place > mea_place
                                                    AND suspect_working_place > mqa_place
                                                    AND suspect_working_place > suspect_place
                                                    AND suspect_working_place > prospect_place
                                                    AND suspect_working_place > customer_place
                                                    AND suspect_working_place > recycled_place
                                                    AND suspect_working_place > unqualified_place THEN suspect_working_place
                                                    WHEN prospect_place > cold_place
                                                    AND prospect_place > mea_place
                                                    AND prospect_place > mqa_place
                                                    AND prospect_place > suspect_place
                                                    AND prospect_place > suspect_working_place
                                                    AND prospect_place > customer_place
                                                    AND prospect_place > recycled_place
                                                    AND prospect_place > unqualified_place THEN prospect_place
                                                    WHEN customer_place > cold_place
                                                    AND customer_place > mea_place
                                                    AND customer_place > mqa_place
                                                    AND customer_place > suspect_place
                                                    AND customer_place > suspect_working_place
                                                    AND customer_place > suspect_place
                                                    AND customer_place > recycled_place
                                                    AND customer_place > unqualified_place THEN customer_place
                                                    WHEN recycled_place > cold_place
                                                    AND recycled_place > mea_place
                                                    AND recycled_place > mqa_place
                                                    AND recycled_place > suspect_place
                                                    AND recycled_place > suspect_working_place
                                                    AND recycled_place > prospect_place
                                                    AND recycled_place > customer_place
                                                    AND recycled_place > unqualified_place THEN recycled_place
                                                    WHEN unqualified_place > cold_place
                                                    AND unqualified_place > mea_place
                                                    AND unqualified_place > mqa_place
                                                    AND unqualified_place > suspect_place
                                                    AND unqualified_place > suspect_working_place
                                                    AND unqualified_place > prospect_place
                                                    AND unqualified_place > customer_place
                                                    AND unqualified_place > recycled_place THEN unqualified_place END AS journey_length
                                                FROM
                                                    (
                                                        SELECT
                                                            DISTINCT ACCOUNT__C,
                                                            RECYCLE_COUNTER__C,
                                                            CREATED_DATE,
                                                            ACTIVE_MARKETING_LIFECYCLE_RECORD__C,
                                                            MARKETING_LIFECYCLE_AT_SUSPECT__C,
                                                            BUYING_STAGE_AT_SUSPECT__C,
                                                            ROUTING_REASON__C,
                                                            UNQUALIFIED_REASON__C,
                                                            OPPORTUNITY__C,
                                                            Name,
                                                            --created_date,
                                                            lifecycle_date_stamp,
                                                            date_order
                                                        FROM
                                                            (
                                                                SELECT
                                                                    DISTINCT account__c,
                                                                    recycle_counter__c,
                                                                    created_date,
                                                                    active_marketing_lifecycle_record__c,
                                                                    marketing_lifecycle_at_suspect__c,
                                                                    buying_stage_at_suspect__c,
                                                                    routing_reason__c,
                                                                    unqualified_reason__c,
                                                                    opportunity__c,
                                                                    Name,
                                                                    --created_date,
                                                                    lifecycle_date_stamp,
                                                                    date_value,
                                                                    CASE
                                                                    WHEN TRUNC(date_value) >= '2222-01-01' THEN 0
                                                                    ELSE date_order END AS date_order
                                                                FROM
                                                                    (
                                                                        SELECT
                                                                            DISTINCT account__c,
                                                                            recycle_counter__c,
                                                                            created_date,
                                                                            active_marketing_lifecycle_record__c,
                                                                            marketing_lifecycle_at_suspect__c,
                                                                            buying_stage_at_suspect__c,
                                                                            routing_reason__c,
                                                                            unqualified_reason__c,
                                                                            opportunity__c,
                                                                            Name,
                                                                            --created_date,
                                                                            lifecycle_date_stamp,
                                                                            date_value,
                                                                            Row_number() OVER (
                                                                                partition BY account__c,
                                                                                recycle_counter__c,
                                                                                created_date,
                                                                                active_marketing_lifecycle_record__c --NAME
                                                                                ORDER BY
                                                                                    date_value
                                                                            ) AS date_order
                                                                        FROM
                                                                            (
                                                                                SELECT
                                                                                    DISTINCT account__c,
                                                                                    COALESCE(recycle_counter__c, 0) AS recycle_counter__c,
                                                                                    created_date,
                                                                                    active_marketing_lifecycle_record__c,
                                                                                    marketing_lifecycle_at_suspect__c,
                                                                                    buying_stage_at_suspect__c,
                                                                                    routing_reason__c,
                                                                                    unqualified_reason__c,
                                                                                    opportunity__c,
                                                                                    Name,
                                                                                    --created_date,
                                                                                    CASE
                                                                                    WHEN (
                                                                                        Cast(cold_account_date_stamp__cas AS DATE) = Cast(mea_date_stamp__cast AS DATE)
                                                                                    ) THEN Dateadd(day, -1, cold_account_date_stamp__cas)
                                                                                    ELSE cold_account_date_stamp__cas END AS cold_account_date_stamp__cast,
                                                                                    mea_date_stamp__cast,
                                                                                    mqa_date_stamp__cast,
                                                                                    CASE
                                                                                    WHEN (
                                                                                        Datediff(
                                                                                            minute,
                                                                                            suspect_date_stamp__cas,
                                                                                            mqa_date_stamp__cast
                                                                                        ) BETWEEN 0
                                                                                        AND 2
                                                                                    ) THEN Dateadd(minutes, 2, suspect_date_stamp__cas)
                                                                                    ELSE suspect_date_stamp__cas END AS suspect_date_stamp__cast,
                                                                                    suspect_working_date_stamp__cast,
                                                                                    prospect_date_stamp__cast,
                                                                                    customer_date_stamp__cast,
                                                                                    recycled_date_stamp__cast,
                                                                                    unqualified_date_stamp__cast
                                                                                FROM
                                                                                    (
                                                                                        SELECT
                                                                                            DISTINCT account__c,
                                                                                            COALESCE(recycle_counter__c, 0) AS recycle_counter__c,
                                                                                            created_date,
                                                                                            active_marketing_lifecycle_record__c,
                                                                                            marketing_lifecycle_at_suspect__c,
                                                                                            buying_stage_at_suspect__c,
                                                                                            routing_reason__c,
                                                                                            unqualified_reason__c,
                                                                                            opportunity__c,
                                                                                            Name,
                                                                                            --created_date,
                                                                                            COALESCE(
                                                                                                cold_account_date_stamp__c,
                                                                                                '2222-01-01 11:22:33.444'
                                                                                            ) AS cold_account_date_stamp__cas,
                                                                                            COALESCE(mea_date_stamp__c, '2222-01-01 11:22:33.444') AS mea_date_stamp__cast,
                                                                                            COALESCE(mqa_date_stamp__c, '2222-01-01 11:22:33.444') AS mqa_date_stamp__cast,
                                                                                            COALESCE(suspect_date_stamp__c, '2222-01-01 11:22:33.444') AS suspect_date_stamp__cas,
                                                                                            COALESCE(
                                                                                                suspect_working_date_stamp__c,
                                                                                                '2222-01-01 11:22:33.444'
                                                                                            ) AS suspect_working_date_stamp__cast,
                                                                                            COALESCE(prospect_date_stamp__c, '2222-01-01 11:22:33.444') AS prospect_date_stamp__cast,
                                                                                            COALESCE(customer_date_stamp__c, '2222-01-01 11:22:33.444') AS customer_date_stamp__cast,
                                                                                            COALESCE(recycle_date_stamp__c, '2222-01-01 11:22:33.444') AS recycled_date_stamp__cast,
                                                                                            COALESCE(
                                                                                                unqualified_date_stamp__c,
                                                                                                '2222-01-01 11:22:33.444'
                                                                                            ) AS unqualified_date_stamp__cast
                                                                                        FROM
                                                                                            --DP_PROD_DB.SALESFORCE.account_marketing_lifecycle_history__c
                                                                                            (
                                                                                                SELECT
                                                                                                    amlh_clean.*
                                                                                                FROM
                                                                                                    (
                                                                                                        SELECT
                                                                                                            DISTINCT amlh.*
                                                                                                        FROM
                                                                                                            dp_prod_db.salesforce.account_marketing_lifecycle_history__c AS amlh
                                                                                                            INNER JOIN (
                                                                                                                SELECT
                                                                                                                    amlh_raw.account__c,
                                                                                                                    COALESCE(amlh_raw.recycle_counter__c, 0) AS recycle_counter__c,
                                                                                                                    Max(amlh_raw.created_date) AS max_created_date,
                                                                                                                    Sum(1) AS cnt
                                                                                                                FROM
                                                                                                                    dp_prod_db.salesforce.account_marketing_lifecycle_history__c AS amlh_raw
                                                                                                                    INNER JOIN dp_prod_db.salesforce.account AS act ON amlh_raw.account__c = act.id -- Record Type
                                                                                                                    INNER JOIN dp_prod_db.salesforce.record_type AS rcd ON act.record_type_id = rcd.id
                                                                                                                    AND (
                                                                                                                        rcd.id = '012300000005VEYAA2'
                                                                                                                        OR rcd.id = '0126R000001UknZQAS'
                                                                                                                    )
                                                                                                                WHERE
                                                                                                                    amlh_raw.is_deleted = false
                                                                                                                    AND act.is_deleted = false
                                                                                                                    AND act.internal_test_account__c = false
                                                                                                                GROUP BY
                                                                                                                    1,
                                                                                                                    2 --HAVING SUM(1) > 1
                                                                                                                ORDER BY
                                                                                                                    1,
                                                                                                                    2
                                                                                                            ) AS amlh_qa_acts ON amlh.account__c = amlh_qa_acts.account__c
                                                                                                            AND COALESCE(amlh.recycle_counter__c, 0) = amlh_qa_acts.recycle_counter__c
                                                                                                            AND amlh.created_date = amlh_qa_acts.max_created_date
                                                                                                        WHERE
                                                                                                            amlh.is_deleted = false
                                                                                                        ORDER BY
                                                                                                            amlh.account__c,
                                                                                                            COALESCE(amlh.recycle_counter__c, 0)
                                                                                                    ) AS amlh_clean
                                                                                            ) --WHERE ACCOUNT__C = '0018000000y0AwLAAU'
                                                                                        ORDER BY
                                                                                            account__c,
                                                                                            COALESCE(recycle_counter__c, 0)
                                                                                    ) AS amlh_clean --WHERE ACCOUNT__C = '0018000000y0AwLAAU'
                                                                                ORDER BY
                                                                                    account__c,
                                                                                    COALESCE(recycle_counter__c, 0)
                                                                            ) UNPIVOT (
                                                                                date_value for lifecycle_date_stamp IN (
                                                                                    cold_account_date_stamp__cast,
                                                                                    mea_date_stamp__cast,
                                                                                    mqa_date_stamp__cast,
                                                                                    suspect_date_stamp__cast,
                                                                                    suspect_working_date_stamp__cast,
                                                                                    prospect_date_stamp__cast,
                                                                                    customer_date_stamp__cast,
                                                                                    recycled_date_stamp__cast,
                                                                                    unqualified_date_stamp__cast
                                                                                )
                                                                            )
                                                                    )
                                                            ) --end prepare for pivot
                                                    ) PIVOT (
                                                        MAX(date_order) FOR lifecycle_date_stamp IN (
                                                            --this isn't really a "max", I need an agg fx to pivot so it's the max of a single value
                                                            'cold_account_date_stamp__cast',
                                                            'customer_date_stamp__cast',
                                                            'mea_date_stamp__cast',
                                                            'mqa_date_stamp__cast',
                                                            'suspect_date_stamp__cast',
                                                            'suspect_working_date_stamp__cast',
                                                            'prospect_date_stamp__cast',
                                                            'recycled_date_stamp__cast',
                                                            'unqualified_date_stamp__cast'
                                                        )
                                                    )
                                            )
                                    )
                            ) as x
                    ) as act_journey_prep
            ) as act_journey ON act.ID = act_journey.ACCOUNT__C
            INNER JOIN DP_PROD_DB.SALESFORCE.account_marketing_lifecycle_history__c AS amlh_raw on act_journey.ACCOUNT__C = amlh_raw.ACCOUNT__C
            and act_journey.RECYCLE_COUNTER__C = coalesce(amlh_raw.RECYCLE_COUNTER__C, 0)
            and act_journey.CREATED_DATE = amlh_raw.CREATED_DATE
        order by
            act.ID
    );