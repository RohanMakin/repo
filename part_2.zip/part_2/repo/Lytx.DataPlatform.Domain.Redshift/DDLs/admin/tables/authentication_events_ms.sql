-- liquibase formatted sql --default-schema-name admin

-- changeset imported_obj_admin.authentication_events_ms:45611572-1 
CREATE TABLE admin.authentication_events_ms (
    user_id character varying(50) ENCODE lzo,
    keycloak_user_id character varying(50) ENCODE lzo distkey,
    login_date timestamp without time zone ENCODE az64,
    event_type character varying(100) ENCODE lzo,
    kafka_topic character varying(128) ENCODE lzo,
    kafka_partition integer ENCODE az64,
    kafka_offset bigint ENCODE az64,
    kafka_timestamp bigint ENCODE az64,
    kafka_timestamp_type character varying(32) ENCODE lzo,
    kafka_date_time timestamp without time zone ENCODE az64,
    kafka_key character varying(128) ENCODE lzo,
    etl_process_timestamp bigint ENCODE az64,
    etl_process_utc_ts timestamp without time zone ENCODE az64,
    record_creation_ts timestamp without time zone ENCODE az64,
    record_update_ts timestamp without time zone ENCODE az64
)
DISTSTYLE AUTO;