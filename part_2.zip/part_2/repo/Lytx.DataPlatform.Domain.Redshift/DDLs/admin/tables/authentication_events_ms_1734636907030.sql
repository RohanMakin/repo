-- liquibase formatted sql --default-schema-name admin

-- changeset imported_obj_admin.authentication_events_ms_1734636907030:15265250-1 
CREATE TABLE admin.authentication_events_ms_1734636907030 (
    userid character varying(16383) ENCODE lzo,
    keycloakuserid character varying(16383) ENCODE lzo,
    logindate timestamp with time zone ENCODE az64,
    eventtype character varying(16383) ENCODE lzo,
    kafkatopic character varying(16383) ENCODE lzo,
    kafkapartition integer ENCODE az64,
    kafkaoffset bigint ENCODE az64,
    kafkatimestamp bigint ENCODE az64,
    kafkatimestamptype character varying(16383) ENCODE lzo,
    kafkadatetime timestamp with time zone ENCODE az64,
    kafkakey character varying(16383) ENCODE lzo,
    etlprocesstimestamp bigint ENCODE az64,
    etlprocessutcts timestamp with time zone ENCODE az64
)
DISTSTYLE AUTO;