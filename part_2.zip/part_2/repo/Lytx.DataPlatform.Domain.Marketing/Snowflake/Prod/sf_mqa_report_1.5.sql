-----------------------------------------------------------------------------------------------------------------
-- Snowflake Scripts

USE ROLE  SYSADMIN;
USE DATABASE DP_PROD_DB;
USE WAREHOUSE GL_PROD_VWH_S;
USE SCHEMA SALESFORCE_TEMP;

//create MQA_REPORT procedure 


CREATE OR REPLACE PROCEDURE DP_PROD_DB.SALESFORCE_TEMP.MQA_REPORT_TABLES_v1_5()
RETURNS VARCHAR(16777216)
LANGUAGE JAVASCRIPT
EXECUTE AS OWNER
AS '

var result = "";
var res1="";

var cmd1 = `CREATE or replace TEMPORARY TABLE DP_PROD_DB.SALESFORCE_TEMP.act_lifecycle_temp_01_v1_5 as select * from(
-- Marketing Generated Account Lifecycle - Account Level
SELECT  
-- Account Info
act."ID",

-- Account Info
act."IS_DELETED",
act."NAME",
act."CREATED_DATE",
act."RECORD_TYPE_ID",rcd."NAME" AS "RECORD_TYPE_ID_NAME",
act."MARKETING_LIFECYCLE_AT_SUSPECT__C",
act."MARKETING_LIFECYCLE__C",
act."BUSINESS_UNIT_2020__C",
act."BUSINESS_UNIT_DIVISION__C",
act."MARKET__C",
act."FLEET_SIZE__C",
act."MARKET_SEGMENT__C",
act."INDUSTRY",
act."INDUSTRY_DB__C",
act."INDUSTRY_SECTOR__C",
act."TERRITORY__C",
act."STATE_DB__C",
act."ACCOUNT_PROFILE_FIT6SENSE__C",
act."ACCOUNT_PROFILE_SCORE6SENSE__C",
act."INTERNAL_TEST_ACCOUNT__C",
act."ROUTING_REASON__C",

-- Account Journey Path
act."ACT_JOURNEY_PATH",
act."ACCOUNT_JOURNEY_PATH_COUNT" AS "ACT_JOURNEY_PATH_CNT",
act."ACT_JOURNEY_PATH_ID",

-- Lifecycle Stage Dates
act.COLD_ACCOUNT_DATE_STAMP__C,
act.COLD_ACCOUNT_DATE_STAMP__C_CAST,
act.cold_account_date_eow,
act.cold_account_date_eom,
act.cold_account_date_eoq,
act.cold_account_date_eoy,
act.MEA_DATE_STAMP__C,
act.MEA_DATE_STAMP__C_CAST,
act.mea_date_eow,
act.mea_date_eom,
act.mea_date_eoq,
act.mea_date_eoy,
act.MQA_DATE_STAMP__C,
act.MQA_DATE_STAMP__C_CAST,
act.mqa_date_eow,
act.mqa_date_eom,
act.mqa_date_eoq,
act.mqa_date_eoy,
act.SUSPECT_DATE_STAMP__C,
act.SUSPECT_DATE_STAMP__C_CAST,
act.suspect_date_eow,
act.suspect_date_eom,
act.suspect_date_eoq,
act.suspect_date_eoy,
act.SUSPECT_WORKING_DATE_STAMP__C,
act.SUSPECT_WORKING_DATE_STAMP__C_CAST,
act.suspect_working_date_eow,
act.suspect_working_date_eom,
act.suspect_working_date_eoq,
act.suspect_working_date_eoy,
act.PROSPECT_DATE_STAMP__C,
act.PROSPECT_DATE_STAMP__C_CAST,
act.prospect_date_eow,
act.prospect_date_eom,
act.prospect_date_eoq,
act.prospect_date_eoy,
act.CUSTOMER_DATE_STAMP__C,
act.CUSTOMER_DATE_STAMP__C_CAST,
act.customer_date_eow,
act.customer_date_eom,
act.customer_date_eoq,
act.customer_date_eoy,
act.RECYCLED_DATE_STAMP__C,
act.RECYCLED_DATE_STAMP__C_CAST,
act.recycled_date_eow,
act.recycled_date_eom,
act.recycled_date_eoq,
act.recycled_date_eoy,
act.UNQUALIFIED_DATE_STAMP__C,
act.UNQUALIFIED_DATE_STAMP__C_CAST,
act.unqualified_date_eow,
act.unqualified_date_eom,
act.unqualified_date_eoq,
act.unqualified_date_eoy,
-- Lifecycle Stage Flags
act.recycled_vs_new_flag,
act.flag_has_marketing_lifecycle_at_suspect__c,
act.account_lifecycle_cold_flag,
act.account_lifecycle_mea_flag,
act.account_lifecycle_mqa_flag,
act.account_lifecycle_suspect_flag,
act.account_lifecycle_suspect_working_flag,
act.account_lifecycle_prospect_flag,
act.account_lifecycle_customer_flag,
act.account_lifecycle_recycled_flag,
act.account_lifecycle_unqualified_flag,

-- Account Journey Path - Lifecycle Non-Linear Flag
act.account_journey_path_lifecycle_nonlinear_flag,

-- Account Journey Path - Lifecycle Non-Linear Flag Reason
act.account_journey_path_lifecycle_nonlinear_flag_reason,

act.FLAG_to_check,
-- Unqualified Flags
act."STATUS__C",
act."UNQUALIFIED_REASON__C",

-- RELATIONSHIP FLAGS FOR CONVERSION RATES
-- OPP TO CUSTOMER RELATIONSHIP
act.OPP_CUSTOMER_RELATIONSHIP,

-- SUSPECT TO OPP RELATIONSHIP
act.SUSPECT_OPP_RELATIONSHIP,

-- SUSPECT TO CUSTOMER RELATIONSHIP
act.SUSPECT_CUSTOMER_RELATIONSHIP,

-- MQA TO SUSPECT RELATIONSHIP
act.MQA_SUSPECT_RELATIONSHIP,

-- MQA TO OPP RELATIONSHIP
act.MQA_OPP_RELATIONSHIP,

-- MQA TO CUSTOMER RELATIONSHIP
act.MQA_CUSTOMER_RELATIONSHIP,

-- MEA TO SUSPECT RELATIONSHIP
act.MEA_SUSPECT_RELATIONSHIP,

-- MEA TO OPP RELATIONSHIP
act.MEA_OPP_RELATIONSHIP,

-- MEA TO CUSTOMER RELATIONSHIP
act.MEA_CUSTOMER_RELATIONSHIP,

-- COLD TO SUSPECT RELATIONSHIP
act.COLD_SUSPECT_RELATIONSHIP,

-- COLD TO OPP RELATIONSHIP
act.COLD_OPP_RELATIONSHIP,

-- COLD TO CUSTOMER RELATIONSHIP
act.COLD_CUSTOMER_RELATIONSHIP,

-- Mutually Exclusive Pre Suspect Designation
act.MUTUALLY_EXCLUSIVE_PRE_SUSPECT_DESIGNATION,

-- Mutually Exclusive Pre Suspect Designation DATE
act.MUTUALLY_EXCLUSIVE_PRE_SUSPECT_DESIGNATION_DATE,

-- Mutually Exclusive Pre Opp Designation
act.MUTUALLY_EXCLUSIVE_PRE_OPP_DESIGNATION,

-- Mutually Exclusive Pre Opp Designation Date
act.MUTUALLY_EXCLUSIVE_PRE_OPP_DESIGNATION_DATE,

-- Parent Account Info
(CASE WHEN (act."PARENT_ID" IS NULL) THEN 0 ELSE 1 END) AS "has_parent_act_flag",
(CASE WHEN (act."PARENT_ID" = ''000000000000000AAA'') THEN 1 ELSE 0 END) AS "parent_act_flag",
act."PARENT_ID",
parent_act."parent_act_IS_DELETED",
parent_act."parent_act_NAME",
parent_act."parent_act_CREATED_DATE",
parent_act."parent_act_RECORD_TYPE_ID",parent_act."parent_act_RECORD_TYPE_ID_NAME",
parent_act."parent_act_MARKETING_LIFECYCLE_AT_SUSPECT__C",
parent_act."parent_act_MARKETING_LIFECYCLE__C",
parent_act."parent_act_BUSINESS_UNIT_2020__C",
parent_act."parent_act_BUSINESS_UNIT_DIVISION__C",
parent_act."parent_act_MARKET__C",
parent_act."parent_act_FLEET_SIZE__C",
parent_act."parent_act_MARKET_SEGMENT__C",
parent_act."parent_act_INDUSTRY",
parent_act."parent_act_INDUSTRY_DB__C",
parent_act."parent_act_INDUSTRY_SECTOR__C",
parent_act."parent_act_TERRITORY__C",
parent_act."parent_act_STATE_DB__C",
parent_act."parent_act_ACCOUNT_PROFILE_FIT6SENSE__C",
parent_act."parent_act_ACCOUNT_PROFILE_SCORE6SENSE__C"
FROM "DP_PROD_DB"."SALESFORCE"."ACCOUNT_ENRICHED" AS act
-- Record Type
INNER JOIN "DP_PROD_DB"."SALESFORCE"."RECORD_TYPE" as rcd
ON act."RECORD_TYPE_ID" = rcd."ID"
AND (rcd."ID" = ''012300000005VEYAA2'' OR rcd."ID" = ''0126R000001UknZQAS'')
-- Parent Account
LEFT JOIN
(
-- Parent Account Information
SELECT DISTINCT
act."ID",
parent_act."PARENT_ID",
parent_act."IS_DELETED" as "parent_act_IS_DELETED",
parent_act."NAME" as "parent_act_NAME",
parent_act."CREATED_DATE" as "parent_act_CREATED_DATE",
parent_act."RECORD_TYPE_ID" as "parent_act_RECORD_TYPE_ID",
rcd."NAME" as "parent_act_RECORD_TYPE_ID_NAME",
parent_act."MARKETING_LIFECYCLE_AT_SUSPECT__C" as "parent_act_MARKETING_LIFECYCLE_AT_SUSPECT__C",
parent_act."MARKETING_LIFECYCLE__C" as "parent_act_MARKETING_LIFECYCLE__C",
parent_act."BUSINESS_UNIT_2020__C" as "parent_act_BUSINESS_UNIT_2020__C",
parent_act."BUSINESS_UNIT_DIVISION__C" as "parent_act_BUSINESS_UNIT_DIVISION__C",
parent_act."MARKET__C" as "parent_act_MARKET__C",
parent_act."FLEET_SIZE__C" as "parent_act_FLEET_SIZE__C",
parent_act."MARKET_SEGMENT__C" as "parent_act_MARKET_SEGMENT__C",
parent_act."INDUSTRY" as "parent_act_INDUSTRY",
parent_act."INDUSTRY_DB__C" as "parent_act_INDUSTRY_DB__C",
parent_act."INDUSTRY_SECTOR__C" as "parent_act_INDUSTRY_SECTOR__C",
parent_act."TERRITORY__C" as "parent_act_TERRITORY__C",
parent_act."STATE_DB__C" as "parent_act_STATE_DB__C",
parent_act."ACCOUNT_PROFILE_FIT6SENSE__C" as "parent_act_ACCOUNT_PROFILE_FIT6SENSE__C",
parent_act."ACCOUNT_PROFILE_SCORE6SENSE__C" as "parent_act_ACCOUNT_PROFILE_SCORE6SENSE__C"
FROM "DP_PROD_DB"."SALESFORCE"."ACCOUNT_ENRICHED" AS act
LEFT JOIN "DP_PROD_DB"."SALESFORCE"."ACCOUNT_ENRICHED" as parent_act
ON act."PARENT_ID" = parent_act."ID"
LEFT JOIN "DP_PROD_DB"."SALESFORCE"."RECORD_TYPE" as rcd
ON parent_act."RECORD_TYPE_ID" = rcd."ID"
) as parent_act
ON act."ID" = parent_act."ID"

WHERE
act."INTERNAL_TEST_ACCOUNT__C" = FALSE
AND act."IS_DELETED" = FALSE
ORDER BY "ACCOUNT_JOURNEY_PATH_COUNT" DESC, act."ID"
)`
var sql1 = snowflake.createStatement({sqlText: cmd1});
var cmd2 =`CREATE or replace TABLE DP_PROD_DB.SALESFORCE_TEMP.INFLUENCE_ACCOUNT_OPPORTUNITY_AGGR_v1_5 as select * from(SELECT
aggr.ACT_ID,aggr.ACT_NAME,aggr.ACT_CREATED_DATE,aggr.WEBSITE,aggr.ACT_MARKET__C,aggr.ACT_MARKET_SEGMENT__C,aggr.ACT_BUSINESS_UNIT_DIVISION__C,aggr.ACT_INDUSTRY,aggr.ACT_INDUSTRY_SECTOR__C,aggr.ACT_NAICS_INDUSTRY_CODE__C,aggr.ACT_NAICS_DESCRIPTION__C,aggr.ACT_FLEET_SIZE__C,
aggr.ACT_RECORD_TYPE_ID,aggr.ACT_RECORD_TYPE_ID_NAME,aggr.ACT_MARKETING_LIFECYCLE_AT_SUSPECT__C,aggr.ACT_MARKETING_LIFECYCLE__C, aggr.ACT_BUSINESS_UNIT_2020__C,aggr.ACT_INDUSTRY_DB__C, aggr.ACT_TERRITORY__C,aggr.ACT_STATE_DB__C,aggr.ACT_ACCOUNT_PROFILE_FIT6SENSE__C, aggr.ACT_ACCOUNT_PROFILE_SCORE6SENSE__C, aggr.ACT_INTERNAL_TEST_ACCOUNT__C, aggr."ACT_ROUTING_REASON__C", aggr.ACT_STATUS__C,aggr.ACT_UNQUALIFIED_REASON__C,
aggr.OPP_ID,aggr.OPP_NAME,
aggr.OPP_CREATED_DATE,aggr.OPP_CLOSE_DATE,aggr.OPP_LEAD_SOURCE,aggr.OPP_STAGE_NAME,aggr.OPP_TYPE,aggr.OPP_COMMITTED_TERM__C,aggr.OPP_PROBABILITY,aggr.OPP_IS_CLOSED,aggr.OPP_IS_WON,aggr.OPP_CURRENCY_ISO_CODE,aggr.CONVERSION_RATE,aggr.OPP_ACV3__C,aggr.OPP_TOTAL_BOOKING_AMOUNT2__C,aggr.OPP_ACV3__C_CONVERTED,aggr.OPP_TOTAL_BOOKING_AMOUNT2__C_CONVERTED,aggr.OPP_SUBS_QTY__C,aggr.OPP_BOOKED_SUBS_QTY3__C,aggr.OPP_SALES_REPORTING_ACV__C,aggr.OPP_SALES_REPORTING_TOTAL_BOOKING_AMOUNT__C,aggr.OPP_SALES_REPORTING_ACV__C_CONVERTED,aggr.OPP_SALES_REPORTING_TOTAL_BOOKING_AMOUNT__C_CONVERTED,aggr.OPP_SALES_REPORTING_BOOKED_SUBS_QTY__C,
aggr.USR_USER_ROLE_ID,aggr.USRROLE_ID,aggr.USRROLE_NAME,
MAX(aggr."Marketing_TouchPoint_Before_Opp_Created") AS "Marketing_TouchPoint_Before_Opp_Created",
MAX(aggr."Marketing_TouchPoint_Before_Opp_Close") AS "Marketing_TouchPoint_Before_Opp_Close",
MAX(aggr."Marketing_TouchPoint_Before_Act_Cold") AS "Marketing_TouchPoint_Before_Act_Cold",
MAX(aggr."Marketing_TouchPoint_Before_Act_MEA") AS "Marketing_TouchPoint_Before_Act_MEA",
MAX(aggr."Marketing_TouchPoint_Before_Act_MQA") AS "Marketing_TouchPoint_Before_Act_MQA",
MAX(aggr."Marketing_TouchPoint_Before_Act_Suspect") AS "Marketing_TouchPoint_Before_Act_Suspect",
MAX(aggr."Marketing_TouchPoint_Before_Act_SuspectWorking") AS "Marketing_TouchPoint_Before_Act_SuspectWorking",
MAX(aggr."Marketing_TouchPoint_Before_Act_Prospect") AS "Marketing_TouchPoint_Before_Act_Prospect",
MAX(aggr."Marketing_TouchPoint_Before_Act_Customer") AS "Marketing_TouchPoint_Before_Act_Customer",
MAX(aggr."Marketing_TouchPoint_Before_Act_Recycled") AS "Marketing_TouchPoint_Before_Act_Recycled",
MAX(aggr."Marketing_TouchPoint_Before_Act_Unqualified") AS "Marketing_TouchPoint_Before_Act_Unqualified",

MAX(aggr."Marketing_TouchPoint_Date") AS "Marketing_TouchPoint_Date_MAX",
MAX(aggr."Flag_Marketing_Touch_Type_DATA_SOURCE") AS "Flag_Marketing_Touch_Type_DATA_SOURCE",
CASE
WHEN MAX(aggr."Flag_Influence_TouchPoint_by_DataSource_Bizibleor6Sense") = 1 THEN ''Influenced''
WHEN MAX(aggr."Flag_Marketing_Touch_Type_DATA_SOURCE") = 1 THEN ''Not Influenced - Has Touch''
WHEN MAX(aggr."Flag_Marketing_Touch_Type_DATA_SOURCE") = 0 THEN ''Not Influenced - No Touch''
END AS "Flag_Influence_TouchPoint_by_DataSource_Bizibleor6SenseorSalesforce",
CASE
WHEN MAX(aggr."Flag_CLS_Influence_TouchPoint_by_DataSource_Bizibleor6Sense") = 1 THEN ''Influenced''
WHEN MAX(aggr."Flag_Marketing_Touch_Type_DATA_SOURCE") = 1 THEN ''Not Influenced - Has Touch''
WHEN MAX(aggr."Flag_Marketing_Touch_Type_DATA_SOURCE") = 0 THEN ''Not Influenced - No Touch''
END AS "Flag_CLS_Influence_TouchPoint_by_DataSource_Bizibleor6SenseorSalesforce",
CASE
WHEN MAX(aggr."Flag_ActCold_Influence_TouchPoint_by_DataSource_Bizibleor6Sense") = 1 THEN ''Influenced''
WHEN MAX(aggr."Flag_Marketing_Touch_Type_DATA_SOURCE") = 1 THEN ''Not Influenced - Has Touch''
WHEN MAX(aggr."Flag_Marketing_Touch_Type_DATA_SOURCE") = 0 THEN ''Not Influenced - No Touch''
END AS "Flag_ActCold_Influence_TouchPoint_by_DataSource_Bizibleor6SenseorSalesforce",
CASE
WHEN MAX(aggr."Flag_ActMEA_Influence_TouchPoint_by_DataSource_Bizibleor6Sense") = 1 THEN ''Influenced''
WHEN MAX(aggr."Flag_Marketing_Touch_Type_DATA_SOURCE") = 1 THEN ''Not Influenced - Has Touch''
WHEN MAX(aggr."Flag_Marketing_Touch_Type_DATA_SOURCE") = 0 THEN ''Not Influenced - No Touch''
END AS "Flag_ActMEA_Influence_TouchPoint_by_DataSource_Bizibleor6SenseorSalesforce",
CASE
WHEN MAX(aggr."Flag_ActMQA_Influence_TouchPoint_by_DataSource_Bizibleor6Sense") = 1 THEN ''Influenced''
WHEN MAX(aggr."Flag_Marketing_Touch_Type_DATA_SOURCE") = 1 THEN ''Not Influenced - Has Touch''
WHEN MAX(aggr."Flag_Marketing_Touch_Type_DATA_SOURCE") = 0 THEN ''Not Influenced - No Touch''
END AS "Flag_ActMQA_Influence_TouchPoint_by_DataSource_Bizibleor6SenseorSalesforce",
CASE
WHEN MAX(aggr."Flag_ActSuspect_Influence_TouchPoint_by_DataSource_Bizibleor6Sense") = 1 THEN ''Influenced''
WHEN MAX(aggr."Flag_Marketing_Touch_Type_DATA_SOURCE") = 1 THEN ''Not Influenced - Has Touch''
WHEN MAX(aggr."Flag_Marketing_Touch_Type_DATA_SOURCE") = 0 THEN ''Not Influenced - No Touch''
END AS "Flag_ActSuspect_Influence_TouchPoint_by_DataSource_Bizibleor6SenseorSalesforce",
CASE
WHEN MAX(aggr."Flag_ActProspect_Influence_TouchPoint_by_DataSource_Bizibleor6Sense") = 1 THEN ''Influenced''
WHEN MAX(aggr."Flag_Marketing_Touch_Type_DATA_SOURCE") = 1 THEN ''Not Influenced - Has Touch''
WHEN MAX(aggr."Flag_Marketing_Touch_Type_DATA_SOURCE") = 0 THEN ''Not Influenced - No Touch''
END AS "Flag_ActProspect_Influence_TouchPoint_by_DataSource_Bizibleor6SenseorSalesforce",

MAX(aggr."Flag_Influence_TouchPoint_by_DataSource_Bizibleor6Sense") AS "Flag_Influence_TouchPoint_by_DataSource_Bizibleor6Sense",
MAX(aggr."Flag_CLS_Influence_TouchPoint_by_DataSource_Bizibleor6Sense") AS "Flag_CLS_Influence_TouchPoint_by_DataSource_Bizibleor6Sense",
MAX(aggr."Flag_ActCold_Influence_TouchPoint_by_DataSource_Bizibleor6Sense") AS "Flag_ActCold_Influence_TouchPoint_by_DataSource_Bizibleor6Sense",
MAX(aggr."Flag_ActMEA_Influence_TouchPoint_by_DataSource_Bizibleor6Sense") AS "Flag_ActMEA_Influence_TouchPoint_by_DataSource_Bizibleor6Sensea",
MAX(aggr."Flag_ActMQA_Influence_TouchPoint_by_DataSource_Bizibleor6Sense") AS "Flag_ActMQA_Influence_TouchPoint_by_DataSource_Bizibleor6Sense",
MAX(aggr."Flag_ActSuspect_Influence_TouchPoint_by_DataSource_Bizibleor6Sense") AS "Flag_ActSuspect_Influence_TouchPoint_by_DataSource_Bizibleor6Sense",
MAX(aggr."Flag_ActProspect_Influence_TouchPoint_by_DataSource_Bizibleor6Sense") AS "Flag_ActProspect_Influence_TouchPoint_by_DataSource_Bizibleor6Sense",

MAX(aggr."Flag_Influence_TouchPoint_by_DataSource_6Sense-PaidMedia") AS "Flag_Influence_TouchPoint_by_DataSource_6Sense-PaidMedia",
MAX(aggr."Flag_CLS_Influence_TouchPoint_by_DataSource_6Sense-PaidMedia") AS "Flag_CLS_Influence_TouchPoint_by_DataSource_6Sense-PaidMedia",
MAX(aggr."Flag_ActCold_Influence_TouchPoint_by_DataSource_6Sense-PaidMedia") AS "Flag_ActCold_Influence_TouchPoint_by_DataSource_6Sense-PaidMedia",
MAX(aggr."Flag_ActMEA_Influence_TouchPoint_by_DataSource_6Sense-PaidMedia") AS "Flag_ActMEA_Influence_TouchPoint_by_DataSource_6Sense-PaidMediaa",
MAX(aggr."Flag_ActMQA_Influence_TouchPoint_by_DataSource_6Sense-PaidMedia") AS "Flag_ActMQA_Influence_TouchPoint_by_DataSource_6Sense-PaidMedia",
MAX(aggr."Flag_ActSuspect_Influence_TouchPoint_by_DataSource_6Sense-PaidMedia") AS "Flag_ActSuspect_Influence_TouchPoint_by_DataSource_6Sense-PaidMedia",
MAX(aggr."Flag_ActProspect_Influence_TouchPoint_by_DataSource_6Sense-PaidMedia") AS "Flag_ActProspect_Influence_TouchPoint_by_DataSource_6Sense-PaidMedia",

MAX(aggr."Flag_Influence_TouchPoint_by_DataSource_6Sense-WebVisit") AS "Flag_Influence_TouchPoint_by_DataSource_6Sense-WebVisit",
MAX(aggr."Flag_CLS_Influence_TouchPoint_by_DataSource_6Sense-WebVisit") AS "Flag_CLS_Influence_TouchPoint_by_DataSource_6Sense-WebVisit",
MAX(aggr."Flag_ActCold_Influence_TouchPoint_by_DataSource_6Sense-WebVisit") AS "Flag_ActCold_Influence_TouchPoint_by_DataSource_6Sense-WebVisit",
MAX(aggr."Flag_ActMEA_Influence_TouchPoint_by_DataSource_6Sense-WebVisit") AS "Flag_ActMEA_Influence_TouchPoint_by_DataSource_6Sense-WebVisita",
MAX(aggr."Flag_ActMQA_Influence_TouchPoint_by_DataSource_6Sense-WebVisit") AS "Flag_ActMQA_Influence_TouchPoint_by_DataSource_6Sense-WebVisit",
MAX(aggr."Flag_ActSuspect_Influence_TouchPoint_by_DataSource_6Sense-WebVisit") AS "Flag_ActSuspect_Influence_TouchPoint_by_DataSource_6Sense-WebVisit",
MAX(aggr."Flag_ActProspect_Influence_TouchPoint_by_DataSource_6Sense-WebVisit") AS "Flag_ActProspect_Influence_TouchPoint_by_DataSource_6Sense-WebVisit",

MAX(aggr."Flag_Influence_TouchPoint_by_DataSource_Bizible") AS "Flag_Influence_TouchPoint_by_DataSource_Bizible",
MAX(aggr."Flag_CLS_Influence_TouchPoint_by_DataSource_Bizible") AS "Flag_CLS_Influence_TouchPoint_by_DataSource_Bizible",
MAX(aggr."Flag_ActCold_Influence_TouchPoint_by_DataSource_Bizible") AS "Flag_ActCold_Influence_TouchPoint_by_DataSource_Bizible",
MAX(aggr."Flag_ActMEA_Influence_TouchPoint_by_DataSource_Bizible") AS "Flag_ActMEA_Influence_TouchPoint_by_DataSource_Biziblea",
MAX(aggr."Flag_ActMQA_Influence_TouchPoint_by_DataSource_Bizible") AS "Flag_ActMQA_Influence_TouchPoint_by_DataSource_Bizible",
MAX(aggr."Flag_ActSuspect_Influence_TouchPoint_by_DataSource_Bizible") AS "Flag_ActSuspect_Influence_TouchPoint_by_DataSource_Bizible",
MAX(aggr."Flag_ActProspect_Influence_TouchPoint_by_DataSource_Bizible") AS "Flag_ActProspect_Influence_TouchPoint_by_DataSource_Bizible",

SUM(aggr."InteractionType_6Sense_PaidMedia_Impressions_Count") AS "InteractionType_6Sense_PaidMedia_Impressions_Count_TOTAL",
SUM(aggr."InteractionType_6Sense_PaidMedia_Clicks_Count") AS "InteractionType_6Sense_PaidMedia_Clicks_Count_TOTAL",
SUM(aggr."InteractionType_6Sense_WebVisit_PageLoad_Count") AS "InteractionType_6Sense_WebVisit_PageLoad_Count_TOTAL",
SUM(aggr."InteractionType_6Sense_WebVisit_Play_Count") AS "InteractionType_6Sense_WebVisit_Play_Count_TOTAL",
SUM(aggr."InteractionType_6Sense_WebVisit_Click_Count") AS "InteractionType_6Sense_WebVisit_Click_Count_TOTAL",
SUM(aggr."InteractionType_6Sense_WebVisit_Submit_Count") AS "InteractionType_6Sense_WebVisit_Submit_Count_TOTAL",
SUM(aggr."InteractionType_6Sense_WebVisit_Unclassified_Count") AS "InteractionType_6Sense_WebVisit_Unclassified_Count_TOTAL",
SUM(aggr."InteractionType_Bizible_TouchPoint_WebVisit_Count") AS "InteractionType_Bizible_TouchPoint_WebVisit_Count_TOTAL",
SUM(aggr."InteractionType_Bizible_TouchPoint_WebChat_Count") AS "InteractionType_Bizible_TouchPoint_WebChat_Count_TOTAL",
SUM(aggr."InteractionType_Bizible_TouchPoint_WebForm_Count") AS "InteractionType_Bizible_TouchPoint_WebForm_Count_TOTAL",
SUM(aggr."InteractionType_Bizible_TouchPoint_CRM_Count") AS "InteractionType_Bizible_TouchPoint_CRM_Count_TOTAL",
SUM(aggr."InteractionType_Bizible_TouchPoint_ConnectwithDM_Count") AS "InteractionType_Bizible_TouchPoint_ConnectwithDM_Count_TOTAL",
SUM(aggr."InteractionType_Bizible_TouchPoint_CallSpokeWith_Count") AS "InteractionType_Bizible_TouchPoint_CallSpokeWith_Count_TOTAL",
SUM(aggr."InteractionType_Bizible_TouchPoint_CallGatekeeper_Count") AS "InteractionType_Bizible_TouchPoint_CallGatekeeper_Count_TOTAL",
SUM(aggr."InteractionType_Bizible_TouchPoint_NoLeadTouchPoints_Count") AS "InteractionType_Bizible_TouchPoint_NoLeadTouchPoints_Count_TOTAL",
SUM(aggr."InteractionType_Bizible_TouchPoint_Unclassified_Count") AS "InteractionType_Bizible_TouchPoint_Unclassified_Count_TOTAL",

MAX(aggr."Flag_Influence_TouchPoint_by_InteractionType_6Sense-PaidMedia_Impression") AS "Flag_Influence_TouchPoint_by_InteractionType_6Sense-PaidMedia_Impression",
MAX(aggr."Flag_Influence_TouchPoint_by_InteractionType_6Sense-PaidMedia_Clicks") AS "Flag_Influence_TouchPoint_by_InteractionType_6Sense-PaidMedia_Clicks",
MAX(aggr."Flag_Influence_TouchPoint_by_InteractionType_6Sense-WebVisit_PageLoad") AS "Flag_Influence_TouchPoint_by_InteractionType_6Sense-WebVisit_PageLoad",
MAX(aggr."Flag_Influence_TouchPoint_by_InteractionType_6Sense-WebVisit_Play") AS "Flag_Influence_TouchPoint_by_InteractionType_6Sense-WebVisit_Play",
MAX(aggr."Flag_Influence_TouchPoint_by_InteractionType_6Sense-WebVisit_Click") AS "Flag_Influence_TouchPoint_by_InteractionType_6Sense-WebVisit_Click",
MAX(aggr."Flag_Influence_TouchPoint_by_InteractionType_6Sense-WebVisit_Submit") AS "Flag_Influence_TouchPoint_by_InteractionType_6Sense-WebVisit_Submit",
MAX(aggr."Flag_Influence_TouchPoint_by_InteractionType_6Sense-WebVisit_Unclassified") AS "Flag_Influence_TouchPoint_by_InteractionType_6Sense-WebVisit_Unclassified",
MAX(aggr."Flag_Influence_TouchPoint_by_InteractionType_Bizibile-TouchPoint_WebVisit") AS "Flag_Influence_TouchPoint_by_InteractionType_Bizibile-TouchPoint_WebVisit",
MAX(aggr."Flag_Influence_TouchPoint_by_InteractionType_Bizibile-TouchPoint_WebChat") AS "Flag_Influence_TouchPoint_by_InteractionType_Bizibile-TouchPoint_WebChat",
MAX(aggr."Flag_Influence_TouchPoint_by_InteractionType_Bizibile-TouchPoint_WebForm") AS "Flag_Influence_TouchPoint_by_InteractionType_Bizibile-TouchPoint_WebForm",
MAX(aggr."Flag_Influence_TouchPoint_by_InteractionType_Bizibile-TouchPoint_CRM") AS "Flag_Influence_TouchPoint_by_InteractionType_Bizibile-TouchPoint_CRM",
MAX(aggr."Flag_Influence_TouchPoint_by_InteractionType_Bizibile-TouchPoint_ConnectwithDM") AS "Flag_Influence_TouchPoint_by_InteractionType_Bizibile-TouchPoint_ConnectwithDM",
MAX(aggr."Flag_Influence_TouchPoint_by_InteractionType_Bizibile-TouchPoint_CallSpokeWith") AS "Flag_Influence_TouchPoint_by_InteractionType_Bizibile-TouchPoint_CallSpokeWith",
MAX(aggr."Flag_Influence_TouchPoint_by_InteractionType_Bizibile-TouchPoint_CallGatekeeper") AS "Flag_Influence_TouchPoint_by_InteractionType_Bizibile-TouchPoint_CallGatekeeper",
MAX(aggr."Flag_Influence_TouchPoint_by_InteractionType_Bizibile-TouchPoint_NoLeadTouchPoint") AS "Flag_Influence_TouchPoint_by_InteractionType_Bizibile-TouchPoint_NoLeadTouchPoint",
MAX(aggr."Flag_Influence_TouchPoint_by_InteractionType_Bizibile-TouchPoint_Unclassified") AS "Flag_Influence_TouchPoint_by_InteractionType_Bizibile-TouchPoint_Unclassified",

MAX(aggr."Flag_CLS_Influence_TouchPoint_by_InteractionType_6Sense-PaidMedia_Impression") AS "Flag_CLS_Influence_TouchPoint_by_InteractionType_6Sense-PaidMedia_Impression",
MAX(aggr."Flag_CLS_Influence_TouchPoint_by_InteractionType_6Sense-PaidMedia_Clicks") AS "Flag_CLS_Influence_TouchPoint_by_InteractionType_6Sense-PaidMedia_Clicks",
MAX(aggr."Flag_CLS_Influence_TouchPoint_by_InteractionType_6Sense-WebVisit_PageLoad") AS "Flag_CLS_Influence_TouchPoint_by_InteractionType_6Sense-WebVisit_PageLoad",
MAX(aggr."Flag_CLS_Influence_TouchPoint_by_InteractionType_6Sense-WebVisit_Play") AS "Flag_CLS_Influence_TouchPoint_by_InteractionType_6Sense-WebVisit_Play",
MAX(aggr."Flag_CLS_Influence_TouchPoint_by_InteractionType_6Sense-WebVisit_Click") AS "Flag_CLS_Influence_TouchPoint_by_InteractionType_6Sense-WebVisit_Click",
MAX(aggr."Flag_CLS_Influence_TouchPoint_by_InteractionType_6Sense-WebVisit_Submit") AS "Flag_CLS_Influence_TouchPoint_by_InteractionType_6Sense-WebVisit_Submit",
MAX(aggr."Flag_CLS_Influence_TouchPoint_by_InteractionType_6Sense-WebVisit_Unclassified") AS "Flag_CLS_Influence_TouchPoint_by_InteractionType_6Sense-WebVisit_Unclassified",
MAX(aggr."Flag_CLS_Influence_TouchPoint_by_InteractionType_Bizibile-TouchPoint_WebVisit") AS "Flag_CLS_Influence_TouchPoint_by_InteractionType_Bizibile-TouchPoint_WebVisit",
MAX(aggr."Flag_CLS_Influence_TouchPoint_by_InteractionType_Bizibile-TouchPoint_WebChat") AS "Flag_CLS_Influence_TouchPoint_by_InteractionType_Bizibile-TouchPoint_WebChat",
MAX(aggr."Flag_CLS_Influence_TouchPoint_by_InteractionType_Bizibile-TouchPoint_WebForm") AS "Flag_CLS_Influence_TouchPoint_by_InteractionType_Bizibile-TouchPoint_WebForm",
MAX(aggr."Flag_CLS_Influence_TouchPoint_by_InteractionType_Bizibile-TouchPoint_CRM") AS "Flag_CLS_Influence_TouchPoint_by_InteractionType_Bizibile-TouchPoint_CRM",
MAX(aggr."Flag_CLS_Influence_TouchPoint_by_InteractionType_Bizibile-TouchPoint_ConnectwithDM") AS "Flag_CLS_Influence_TouchPoint_by_InteractionType_Bizibile-TouchPoint_ConnectwithDM",
MAX(aggr."Flag_CLS_Influence_TouchPoint_by_InteractionType_Bizibile-TouchPoint_CallSpokeWith") AS "Flag_CLS_Influence_TouchPoint_by_InteractionType_Bizibile-TouchPoint_CallSpokeWith",
MAX(aggr."Flag_CLS_Influence_TouchPoint_by_InteractionType_Bizibile-TouchPoint_CallGatekeeper") AS "Flag_CLS_Influence_TouchPoint_by_InteractionType_Bizibile-TouchPoint_CallGatekeeper",
MAX(aggr."Flag_CLS_Influence_TouchPoint_by_InteractionType_Bizibile-TouchPoint_NoLeadTouchPoint") AS "Flag_CLS_Influence_TouchPoint_by_InteractionType_Bizibile-TouchPoint_NoLeadTouchPoint",
MAX(aggr."Flag_CLS_Influence_TouchPoint_by_InteractionType_Bizibile-TouchPoint_Unclassified") AS "Flag_CLS_Influence_TouchPoint_by_InteractionType_Bizibile-TouchPoint_Unclassified",


MAX(aggr."Flag_ActCold_Influence_TouchPoint_by_InteractionType_6Sense-PaidMedia_Impression") AS "Flag_ActCold_Influence_TouchPoint_by_InteractionType_6Sense-PaidMedia_Impression",
MAX(aggr."Flag_ActCold_Influence_TouchPoint_by_InteractionType_6Sense-PaidMedia_Clicks") AS "Flag_ActCold_Influence_TouchPoint_by_InteractionType_6Sense-PaidMedia_Clicks",
MAX(aggr."Flag_ActCold_Influence_TouchPoint_by_InteractionType_6Sense-WebVisit_PageLoad") AS "Flag_ActCold_Influence_TouchPoint_by_InteractionType_6Sense-WebVisit_PageLoad",
MAX(aggr."Flag_ActCold_Influence_TouchPoint_by_InteractionType_6Sense-WebVisit_Play") AS "Flag_ActCold_Influence_TouchPoint_by_InteractionType_6Sense-WebVisit_Play",
MAX(aggr."Flag_ActCold_Influence_TouchPoint_by_InteractionType_6Sense-WebVisit_Click") AS "Flag_ActCold_Influence_TouchPoint_by_InteractionType_6Sense-WebVisit_Click",
MAX(aggr."Flag_ActCold_Influence_TouchPoint_by_InteractionType_6Sense-WebVisit_Submit") AS "Flag_ActCold_Influence_TouchPoint_by_InteractionType_6Sense-WebVisit_Submit",
MAX(aggr."Flag_ActCold_Influence_TouchPoint_by_InteractionType_6Sense-WebVisit_Unclassified") AS "Flag_ActCold_Influence_TouchPoint_by_InteractionType_6Sense-WebVisit_Unclassified",
MAX(aggr."Flag_ActCold_Influence_TouchPoint_by_InteractionType_Bizibile-TouchPoint_WebVisit") AS "Flag_ActCold_Influence_TouchPoint_by_InteractionType_Bizibile-TouchPoint_WebVisit",
MAX(aggr."Flag_ActCold_Influence_TouchPoint_by_InteractionType_Bizibile-TouchPoint_WebChat") AS "Flag_ActCold_Influence_TouchPoint_by_InteractionType_Bizibile-TouchPoint_WebChat",
MAX(aggr."Flag_ActCold_Influence_TouchPoint_by_InteractionType_Bizibile-TouchPoint_WebForm") AS "Flag_ActCold_Influence_TouchPoint_by_InteractionType_Bizibile-TouchPoint_WebForm",
MAX(aggr."Flag_ActCold_Influence_TouchPoint_by_InteractionType_Bizibile-TouchPoint_CRM") AS "Flag_ActCold_Influence_TouchPoint_by_InteractionType_Bizibile-TouchPoint_CRM",
MAX(aggr."Flag_ActCold_Influence_TouchPoint_by_InteractionType_Bizibile-TouchPoint_ConnectwithDM") AS "Flag_ActCold_Influence_TouchPoint_by_InteractionType_Bizibile-TouchPoint_ConnectwithDM",
MAX(aggr."Flag_ActCold_Influence_TouchPoint_by_InteractionType_Bizibile-TouchPoint_CallSpokeWith") AS "Flag_ActCold_Influence_TouchPoint_by_InteractionType_Bizibile-TouchPoint_CallSpokeWith",
MAX(aggr."Flag_ActCold_Influence_TouchPoint_by_InteractionType_Bizibile-TouchPoint_CallGatekeeper") AS "Flag_ActCold_Influence_TouchPoint_by_InteractionType_Bizibile-TouchPoint_CallGatekeeper",
MAX(aggr."Flag_ActCold_Influence_TouchPoint_by_InteractionType_Bizibile-TouchPoint_NoLeadTouchPoint") AS "Flag_ActCold_Influence_TouchPoint_by_InteractionType_Bizibile-TouchPoint_NoLeadTouchPoint",
MAX(aggr."Flag_ActCold_Influence_TouchPoint_by_InteractionType_Bizibile-TouchPoint_Unclassified") AS "Flag_ActCold_Influence_TouchPoint_by_InteractionType_Bizibile-TouchPoint_Unclassified",

MAX(aggr."Flag_ActMEA_Influence_TouchPoint_by_InteractionType_6Sense-PaidMedia_Impression") AS "Flag_ActMEA_Influence_TouchPoint_by_InteractionType_6Sense-PaidMedia_Impression",
MAX(aggr."Flag_ActMEA_Influence_TouchPoint_by_InteractionType_6Sense-PaidMedia_Clicks") AS "Flag_ActMEA_Influence_TouchPoint_by_InteractionType_6Sense-PaidMedia_Clicks",
MAX(aggr."Flag_ActMEA_Influence_TouchPoint_by_InteractionType_6Sense-WebVisit_PageLoad") AS "Flag_ActMEA_Influence_TouchPoint_by_InteractionType_6Sense-WebVisit_PageLoad",
MAX(aggr."Flag_ActMEA_Influence_TouchPoint_by_InteractionType_6Sense-WebVisit_Play") AS "Flag_ActMEA_Influence_TouchPoint_by_InteractionType_6Sense-WebVisit_Play",
MAX(aggr."Flag_ActMEA_Influence_TouchPoint_by_InteractionType_6Sense-WebVisit_Click") AS "Flag_ActMEA_Influence_TouchPoint_by_InteractionType_6Sense-WebVisit_Click",
MAX(aggr."Flag_ActMEA_Influence_TouchPoint_by_InteractionType_6Sense-WebVisit_Submit") AS "Flag_ActMEA_Influence_TouchPoint_by_InteractionType_6Sense-WebVisit_Submit",
MAX(aggr."Flag_ActMEA_Influence_TouchPoint_by_InteractionType_6Sense-WebVisit_Unclassified") AS "Flag_ActMEA_Influence_TouchPoint_by_InteractionType_6Sense-WebVisit_Unclassified",
MAX(aggr."Flag_ActMEA_Influence_TouchPoint_by_InteractionType_Bizibile-TouchPoint_WebVisit") AS "Flag_ActMEA_Influence_TouchPoint_by_InteractionType_Bizibile-TouchPoint_WebVisit",
MAX(aggr."Flag_ActMEA_Influence_TouchPoint_by_InteractionType_Bizibile-TouchPoint_WebChat") AS "Flag_ActMEA_Influence_TouchPoint_by_InteractionType_Bizibile-TouchPoint_WebChat",
MAX(aggr."Flag_ActMEA_Influence_TouchPoint_by_InteractionType_Bizibile-TouchPoint_WebForm") AS "Flag_ActMEA_Influence_TouchPoint_by_InteractionType_Bizibile-TouchPoint_WebForm",
MAX(aggr."Flag_ActMEA_Influence_TouchPoint_by_InteractionType_Bizibile-TouchPoint_CRM") AS "Flag_ActMEA_Influence_TouchPoint_by_InteractionType_Bizibile-TouchPoint_CRM",
MAX(aggr."Flag_ActMEA_Influence_TouchPoint_by_InteractionType_Bizibile-TouchPoint_ConnectwithDM") AS "Flag_ActMEA_Influence_TouchPoint_by_InteractionType_Bizibile-TouchPoint_ConnectwithDM",
MAX(aggr."Flag_ActMEA_Influence_TouchPoint_by_InteractionType_Bizibile-TouchPoint_CallSpokeWith") AS "Flag_ActMEA_Influence_TouchPoint_by_InteractionType_Bizibile-TouchPoint_CallSpokeWith",
MAX(aggr."Flag_ActMEA_Influence_TouchPoint_by_InteractionType_Bizibile-TouchPoint_CallGatekeeper") AS "Flag_ActMEA_Influence_TouchPoint_by_InteractionType_Bizibile-TouchPoint_CallGatekeeper",
MAX(aggr."Flag_ActMEA_Influence_TouchPoint_by_InteractionType_Bizibile-TouchPoint_NoLeadTouchPoint") AS "Flag_ActMEA_Influence_TouchPoint_by_InteractionType_Bizibile-TouchPoint_NoLeadTouchPoint",
MAX(aggr."Flag_ActMEA_Influence_TouchPoint_by_InteractionType_Bizibile-TouchPoint_Unclassified") AS "Flag_ActMEA_Influence_TouchPoint_by_InteractionType_Bizibile-TouchPoint_Unclassified",

MAX(aggr."Flag_ActMQA_Influence_TouchPoint_by_InteractionType_6Sense-PaidMedia_Impression") AS "Flag_ActMQA_Influence_TouchPoint_by_InteractionType_6Sense-PaidMedia_Impression",
MAX(aggr."Flag_ActMQA_Influence_TouchPoint_by_InteractionType_6Sense-PaidMedia_Clicks") AS "Flag_ActMQA_Influence_TouchPoint_by_InteractionType_6Sense-PaidMedia_Clicks",
MAX(aggr."Flag_ActMQA_Influence_TouchPoint_by_InteractionType_6Sense-WebVisit_PageLoad") AS "Flag_ActMQA_Influence_TouchPoint_by_InteractionType_6Sense-WebVisit_PageLoad",
MAX(aggr."Flag_ActMQA_Influence_TouchPoint_by_InteractionType_6Sense-WebVisit_Play") AS "Flag_ActMQA_Influence_TouchPoint_by_InteractionType_6Sense-WebVisit_Play",
MAX(aggr."Flag_ActMQA_Influence_TouchPoint_by_InteractionType_6Sense-WebVisit_Click") AS "Flag_ActMQA_Influence_TouchPoint_by_InteractionType_6Sense-WebVisit_Click",
MAX(aggr."Flag_ActMQA_Influence_TouchPoint_by_InteractionType_6Sense-WebVisit_Submit") AS "Flag_ActMQA_Influence_TouchPoint_by_InteractionType_6Sense-WebVisit_Submit",
MAX(aggr."Flag_ActMQA_Influence_TouchPoint_by_InteractionType_6Sense-WebVisit_Unclassified") AS "Flag_ActMQA_Influence_TouchPoint_by_InteractionType_6Sense-WebVisit_Unclassified",
MAX(aggr."Flag_ActMQA_Influence_TouchPoint_by_InteractionType_Bizibile-TouchPoint_WebVisit") AS "Flag_ActMQA_Influence_TouchPoint_by_InteractionType_Bizibile-TouchPoint_WebVisit",
MAX(aggr."Flag_ActMQA_Influence_TouchPoint_by_InteractionType_Bizibile-TouchPoint_WebChat") AS "Flag_ActMQA_Influence_TouchPoint_by_InteractionType_Bizibile-TouchPoint_WebChat",
MAX(aggr."Flag_ActMQA_Influence_TouchPoint_by_InteractionType_Bizibile-TouchPoint_WebForm") AS "Flag_ActMQA_Influence_TouchPoint_by_InteractionType_Bizibile-TouchPoint_WebForm",
MAX(aggr."Flag_ActMQA_Influence_TouchPoint_by_InteractionType_Bizibile-TouchPoint_CRM") AS "Flag_ActMQA_Influence_TouchPoint_by_InteractionType_Bizibile-TouchPoint_CRM",
MAX(aggr."Flag_ActMQA_Influence_TouchPoint_by_InteractionType_Bizibile-TouchPoint_ConnectwithDM") AS "Flag_ActMQA_Influence_TouchPoint_by_InteractionType_Bizibile-TouchPoint_ConnectwithDM",
MAX(aggr."Flag_ActMQA_Influence_TouchPoint_by_InteractionType_Bizibile-TouchPoint_CallSpokeWith") AS "Flag_ActMQA_Influence_TouchPoint_by_InteractionType_Bizibile-TouchPoint_CallSpokeWith",
MAX(aggr."Flag_ActMQA_Influence_TouchPoint_by_InteractionType_Bizibile-TouchPoint_CallGatekeeper") AS "Flag_ActMQA_Influence_TouchPoint_by_InteractionType_Bizibile-TouchPoint_CallGatekeeper",
MAX(aggr."Flag_ActMQA_Influence_TouchPoint_by_InteractionType_Bizibile-TouchPoint_NoLeadTouchPoint") AS "Flag_ActMQA_Influence_TouchPoint_by_InteractionType_Bizibile-TouchPoint_NoLeadTouchPoint",
MAX(aggr."Flag_ActMQA_Influence_TouchPoint_by_InteractionType_Bizibile-TouchPoint_Unclassified") AS "Flag_ActMQA_Influence_TouchPoint_by_InteractionType_Bizibile-TouchPoint_Unclassified",

MAX(aggr."Flag_ActSuspect_Influence_TouchPoint_by_InteractionType_6Sense-PaidMedia_Impression") AS "Flag_ActSuspect_Influence_TouchPoint_by_InteractionType_6Sense-PaidMedia_Impression",
MAX(aggr."Flag_ActSuspect_Influence_TouchPoint_by_InteractionType_6Sense-PaidMedia_Clicks") AS "Flag_ActSuspect_Influence_TouchPoint_by_InteractionType_6Sense-PaidMedia_Clicks",
MAX(aggr."Flag_ActSuspect_Influence_TouchPoint_by_InteractionType_6Sense-WebVisit_PageLoad") AS "Flag_ActSuspect_Influence_TouchPoint_by_InteractionType_6Sense-WebVisit_PageLoad",
MAX(aggr."Flag_ActSuspect_Influence_TouchPoint_by_InteractionType_6Sense-WebVisit_Play") AS "Flag_ActSuspect_Influence_TouchPoint_by_InteractionType_6Sense-WebVisit_Play",
MAX(aggr."Flag_ActSuspect_Influence_TouchPoint_by_InteractionType_6Sense-WebVisit_Click") AS "Flag_ActSuspect_Influence_TouchPoint_by_InteractionType_6Sense-WebVisit_Click",
MAX(aggr."Flag_ActSuspect_Influence_TouchPoint_by_InteractionType_6Sense-WebVisit_Submit") AS "Flag_ActSuspect_Influence_TouchPoint_by_InteractionType_6Sense-WebVisit_Submit",
MAX(aggr."Flag_ActSuspect_Influence_TouchPoint_by_InteractionType_6Sense-WebVisit_Unclassified") AS "Flag_ActSuspect_Influence_TouchPoint_by_InteractionType_6Sense-WebVisit_Unclassified",
MAX(aggr."Flag_ActSuspect_Influence_TouchPoint_by_InteractionType_Bizibile-TouchPoint_WebVisit") AS "Flag_ActSuspect_Influence_TouchPoint_by_InteractionType_Bizibile-TouchPoint_WebVisit",
MAX(aggr."Flag_ActSuspect_Influence_TouchPoint_by_InteractionType_Bizibile-TouchPoint_WebChat") AS "Flag_ActSuspect_Influence_TouchPoint_by_InteractionType_Bizibile-TouchPoint_WebChat",
MAX(aggr."Flag_ActSuspect_Influence_TouchPoint_by_InteractionType_Bizibile-TouchPoint_WebForm") AS "Flag_ActSuspect_Influence_TouchPoint_by_InteractionType_Bizibile-TouchPoint_WebForm",
MAX(aggr."Flag_ActSuspect_Influence_TouchPoint_by_InteractionType_Bizibile-TouchPoint_CRM") AS "Flag_ActSuspect_Influence_TouchPoint_by_InteractionType_Bizibile-TouchPoint_CRM",
MAX(aggr."Flag_ActSuspect_Influence_TouchPoint_by_InteractionType_Bizibile-TouchPoint_ConnectwithDM") AS "Flag_ActSuspect_Influence_TouchPoint_by_InteractionType_Bizibile-TouchPoint_ConnectwithDM",
MAX(aggr."Flag_ActSuspect_Influence_TouchPoint_by_InteractionType_Bizibile-TouchPoint_CallSpokeWith") AS "Flag_ActSuspect_Influence_TouchPoint_by_InteractionType_Bizibile-TouchPoint_CallSpokeWith",
MAX(aggr."Flag_ActSuspect_Influence_TouchPoint_by_InteractionType_Bizibile-TouchPoint_CallGatekeeper") AS "Flag_ActSuspect_Influence_TouchPoint_by_InteractionType_Bizibile-TouchPoint_CallGatekeeper",
MAX(aggr."Flag_ActSuspect_Influence_TouchPoint_by_InteractionType_Bizibile-TouchPoint_NoLeadTouchPoint") AS "Flag_ActSuspect_Influence_TouchPoint_by_InteractionType_Bizibile-TouchPoint_NoLeadTouchPoint",
MAX(aggr."Flag_ActSuspect_Influence_TouchPoint_by_InteractionType_Bizibile-TouchPoint_Unclassified") AS "Flag_ActSuspect_Influence_TouchPoint_by_InteractionType_Bizibile-TouchPoint_Unclassified",

MAX(aggr."Flag_ActProspect_Influence_TouchPoint_by_InteractionType_6Sense-PaidMedia_Impression") AS "Flag_ActProspect_Influence_TouchPoint_by_InteractionType_6Sense-PaidMedia_Impression",
MAX(aggr."Flag_ActProspect_Influence_TouchPoint_by_InteractionType_6Sense-PaidMedia_Clicks") AS "Flag_ActProspect_Influence_TouchPoint_by_InteractionType_6Sense-PaidMedia_Clicks",
MAX(aggr."Flag_ActProspect_Influence_TouchPoint_by_InteractionType_6Sense-WebVisit_PageLoad") AS "Flag_ActProspect_Influence_TouchPoint_by_InteractionType_6Sense-WebVisit_PageLoad",
MAX(aggr."Flag_ActProspect_Influence_TouchPoint_by_InteractionType_6Sense-WebVisit_Play") AS "Flag_ActProspect_Influence_TouchPoint_by_InteractionType_6Sense-WebVisit_Play",
MAX(aggr."Flag_ActProspect_Influence_TouchPoint_by_InteractionType_6Sense-WebVisit_Click") AS "Flag_ActProspect_Influence_TouchPoint_by_InteractionType_6Sense-WebVisit_Click",
MAX(aggr."Flag_ActProspect_Influence_TouchPoint_by_InteractionType_6Sense-WebVisit_Submit") AS "Flag_ActProspect_Influence_TouchPoint_by_InteractionType_6Sense-WebVisit_Submit",
MAX(aggr."Flag_ActProspect_Influence_TouchPoint_by_InteractionType_6Sense-WebVisit_Unclassified") AS "Flag_ActProspect_Influence_TouchPoint_by_InteractionType_6Sense-WebVisit_Unclassified",
MAX(aggr."Flag_ActProspect_Influence_TouchPoint_by_InteractionType_Bizibile-TouchPoint_WebVisit") AS "Flag_ActProspect_Influence_TouchPoint_by_InteractionType_Bizibile-TouchPoint_WebVisit",
MAX(aggr."Flag_ActProspect_Influence_TouchPoint_by_InteractionType_Bizibile-TouchPoint_WebChat") AS "Flag_ActProspect_Influence_TouchPoint_by_InteractionType_Bizibile-TouchPoint_WebChat",
MAX(aggr."Flag_ActProspect_Influence_TouchPoint_by_InteractionType_Bizibile-TouchPoint_WebForm") AS "Flag_ActProspect_Influence_TouchPoint_by_InteractionType_Bizibile-TouchPoint_WebForm",
MAX(aggr."Flag_ActProspect_Influence_TouchPoint_by_InteractionType_Bizibile-TouchPoint_CRM") AS "Flag_ActProspect_Influence_TouchPoint_by_InteractionType_Bizibile-TouchPoint_CRM",
MAX(aggr."Flag_ActProspect_Influence_TouchPoint_by_InteractionType_Bizibile-TouchPoint_ConnectwithDM") AS "Flag_ActProspect_Influence_TouchPoint_by_InteractionType_Bizibile-TouchPoint_ConnectwithDM",
MAX(aggr."Flag_ActProspect_Influence_TouchPoint_by_InteractionType_Bizibile-TouchPoint_CallSpokeWith") AS "Flag_ActProspect_Influence_TouchPoint_by_InteractionType_Bizibile-TouchPoint_CallSpokeWith",
MAX(aggr."Flag_ActProspect_Influence_TouchPoint_by_InteractionType_Bizibile-TouchPoint_CallGatekeeper") AS "Flag_ActProspect_Influence_TouchPoint_by_InteractionType_Bizibile-TouchPoint_CallGatekeeper",
MAX(aggr."Flag_ActProspect_Influence_TouchPoint_by_InteractionType_Bizibile-TouchPoint_NoLeadTouchPoint") AS "Flag_ActProspect_Influence_TouchPoint_by_InteractionType_Bizibile-TouchPoint_NoLeadTouchPoint",
MAX(aggr."Flag_ActProspect_Influence_TouchPoint_by_InteractionType_Bizibile-TouchPoint_Unclassified") AS "Flag_ActProspect_Influence_TouchPoint_by_InteractionType_Bizibile-TouchPoint_Unclassified",

SUM(aggr."InteractionType_6Sense_PaidMedia_Impressions_Count_Influence") AS "InteractionType_6Sense_PaidMedia_Impressions_Count_Influence_TOTAL",
SUM(aggr."InteractionType_6Sense_PaidMedia_Clicks_Count_Influence") AS "InteractionType_6Sense_PaidMedia_Clicks_Count_Influence_TOTAL",
SUM(aggr."InteractionType_6Sense_WebVisit_PageLoad_Count_Influence") AS "InteractionType_6Sense_WebVisit_PageLoad_Count_Influence_TOTAL",
SUM(aggr."InteractionType_6Sense_WebVisit_Play_Count_Influence") AS "InteractionType_6Sense_WebVisit_Play_Count_Influence_TOTAL",
SUM(aggr."InteractionType_6Sense_WebVisit_Click_Count_Influence") AS "InteractionType_6Sense_WebVisit_Click_Count_Influence_TOTAL",
SUM(aggr."InteractionType_6Sense_WebVisit_Submit_Count_Influence") AS "InteractionType_6Sense_WebVisit_Submit_Count_Influence_TOTAL",
SUM(aggr."InteractionType_6Sense_WebVisit_Unclassified_Count_Influence") AS "InteractionType_6Sense_WebVisit_Unclassified_Count_Influence_TOTAL",
SUM(aggr."InteractionType_Bizibile-TouchPoint_WebVisit_Count_Influence") AS "InteractionType_Bizibile-TouchPoint_WebVisit_Count_Influence_TOTAL",
SUM(aggr."InteractionType_Bizibile-TouchPoint_WebChat_Count_Influence") AS "InteractionType_Bizibile-TouchPoint_WebChat_Count_Influence_TOTAL",
SUM(aggr."InteractionType_Bizibile-TouchPoint_WebForm_Count_Influence") AS "InteractionType_Bizibile-TouchPoint_WebForm_Count_Influence_TOTAL",
SUM(aggr."InteractionType_Bizibile-TouchPoint_CRM_Count_Influence") AS "InteractionType_Bizibile-TouchPoint_CRM_Count_Influence_TOTAL",
SUM(aggr."InteractionType_Bizibile-TouchPoint_ConnectwithDM_Count_Influence") AS "InteractionType_Bizibile-TouchPoint_ConnectwithDM_Count_Influence_TOTAL",
SUM(aggr."InteractionType_Bizibile-TouchPoint_CallSpokeWith_Count_Influence") AS "InteractionType_Bizibile-TouchPoint_CallSpokeWith_Count_Influence_TOTAL",
SUM(aggr."InteractionType_Bizibile-TouchPoint_CallGatekeeper_Count_Influence") AS "InteractionType_Bizibile-TouchPoint_CallGatekeeper_Count_Influence_TOTAL",
SUM(aggr."InteractionType_Bizibile-TouchPoint_NoLeadTouchPoint_Count_Influence") AS "InteractionType_Bizibile-TouchPoint_NoLeadTouchPoint_Count_Influence_TOTAL",
SUM(aggr."InteractionType_Bizibile-TouchPoint_Unclassified_Count_Influence") AS "InteractionType_Bizibile-TouchPoint_Unclassified_Count_Influence_TOTAL",

SUM(aggr."InteractionType_6Sense_PaidMedia_Impressions_Count_CLS_Influence") AS "InteractionType_6Sense_PaidMedia_Impressions_Count_CLS_Influence_TOTAL",
SUM(aggr."InteractionType_6Sense_PaidMedia_Clicks_Count_CLS_Influence") AS "InteractionType_6Sense_PaidMedia_Clicks_Count_CLS_Influence_TOTAL",
SUM(aggr."InteractionType_6Sense_WebVisit_PageLoad_Count_CLS_Influence") AS "InteractionType_6Sense_WebVisit_PageLoad_Count_CLS_Influence_TOTAL",
SUM(aggr."InteractionType_6Sense_WebVisit_Play_Count_CLS_Influence") AS "InteractionType_6Sense_WebVisit_Play_Count_CLS_Influence_TOTAL",
SUM(aggr."InteractionType_6Sense_WebVisit_Click_Count_CLS_Influence") AS "InteractionType_6Sense_WebVisit_Click_Count_CLS_Influence_TOTAL",
SUM(aggr."InteractionType_6Sense_WebVisit_Submit_Count_CLS_Influence") AS "InteractionType_6Sense_WebVisit_Submit_Count_CLS_Influence_TOTAL",
SUM(aggr."InteractionType_6Sense_WebVisit_Unclassified_Count_CLS_Influence") AS "InteractionType_6Sense_WebVisit_Unclassified_Count_CLS_Influence_TOTAL",
SUM(aggr."InteractionType_Bizibile-TouchPoint_WebVisit_Count_CLS_Influence") AS "InteractionType_Bizibile-TouchPoint_WebVisit_Count_CLS_Influence_TOTAL",
SUM(aggr."InteractionType_Bizibile-TouchPoint_WebChat_Count_CLS_Influence") AS "InteractionType_Bizibile-TouchPoint_WebChat_Count_CLS_Influence_TOTAL",
SUM(aggr."InteractionType_Bizibile-TouchPoint_WebForm_Count_CLS_Influence") AS "InteractionType_Bizibile-TouchPoint_WebForm_Count_CLS_Influence_TOTAL",
SUM(aggr."InteractionType_Bizibile-TouchPoint_CRM_Count_CLS_Influence") AS "InteractionType_Bizibile-TouchPoint_CRM_Count_CLS_Influence_TOTAL",
SUM(aggr."InteractionType_Bizibile-TouchPoint_ConnectwithDM_Count_CLS_Influence") AS "InteractionType_Bizibile-TouchPoint_ConnectwithDM_Count_CLS_Influence_TOTAL",
SUM(aggr."InteractionType_Bizibile-TouchPoint_CallSpokeWith_Count_CLS_Influence") AS "InteractionType_Bizibile-TouchPoint_CallSpokeWith_Count_CLS_Influence_TOTAL",
SUM(aggr."InteractionType_Bizibile-TouchPoint_CallGatekeeper_Count_CLS_Influence") AS "InteractionType_Bizibile-TouchPoint_CallGatekeeper_Count_CLS_Influence_TOTAL",
SUM(aggr."InteractionType_Bizibile-TouchPoint_NoLeadTouchPoint_Count_CLS_Influence") AS "InteractionType_Bizibile-TouchPoint_NoLeadTouchPoint_Count_CLS_Influence_TOTAL",
SUM(aggr."InteractionType_Bizibile-TouchPoint_Unclassified_Count_CLS_Influence") AS "InteractionType_Bizibile-TouchPoint_Unclassified_Count_CLS_Influence_TOTAL",

SUM(aggr."InteractionType_6Sense_PaidMedia_Impressions_Count_ActCold_Influence") AS "InteractionType_6Sense_PaidMedia_Impressions_Count_ActCold_Influence_TOTAL",
SUM(aggr."InteractionType_6Sense_PaidMedia_Clicks_Count_ActCold_Influence") AS "InteractionType_6Sense_PaidMedia_Clicks_Count_ActCold_Influence_TOTAL",
SUM(aggr."InteractionType_6Sense_WebVisit_PageLoad_Count_ActCold_Influence") AS "InteractionType_6Sense_WebVisit_PageLoad_Count_ActCold_Influence_TOTAL",
SUM(aggr."InteractionType_6Sense_WebVisit_Play_Count_ActCold_Influence") AS "InteractionType_6Sense_WebVisit_Play_Count_ActCold_Influence_TOTAL",
SUM(aggr."InteractionType_6Sense_WebVisit_Click_Count_ActCold_Influence") AS "InteractionType_6Sense_WebVisit_Click_Count_ActCold_Influence_TOTAL",
SUM(aggr."InteractionType_6Sense_WebVisit_Submit_Count_ActCold_Influence") AS "InteractionType_6Sense_WebVisit_Submit_Count_ActCold_Influence_TOTAL",
SUM(aggr."InteractionType_6Sense_WebVisit_Unclassified_Count_ActCold_Influence") AS "InteractionType_6Sense_WebVisit_Unclassified_Count_ActCold_Influence_TOTAL",
SUM(aggr."InteractionType_Bizibile-TouchPoint_WebVisit_Count_ActCold_Influence") AS "InteractionType_Bizibile-TouchPoint_WebVisit_Count_ActCold_Influence_TOTAL",
SUM(aggr."InteractionType_Bizibile-TouchPoint_WebChat_Count_ActCold_Influence") AS "InteractionType_Bizibile-TouchPoint_WebChat_Count_ActCold_Influence_TOTAL",
SUM(aggr."InteractionType_Bizibile-TouchPoint_WebForm_Count_ActCold_Influence") AS "InteractionType_Bizibile-TouchPoint_WebForm_Count_ActCold_Influence_TOTAL",
SUM(aggr."InteractionType_Bizibile-TouchPoint_CRM_Count_ActCold_Influence") AS "InteractionType_Bizibile-TouchPoint_CRM_Count_ActCold_Influence_TOTAL",
SUM(aggr."InteractionType_Bizibile-TouchPoint_ConnectwithDM_Count_ActCold_Influence") AS "InteractionType_Bizibile-TouchPoint_ConnectwithDM_Count_ActCold_Influence_TOTAL",
SUM(aggr."InteractionType_Bizibile-TouchPoint_CallSpokeWith_Count_ActCold_Influence") AS "InteractionType_Bizibile-TouchPoint_CallSpokeWith_Count_ActCold_Influence_TOTAL",
SUM(aggr."InteractionType_Bizibile-TouchPoint_CallGatekeeper_Count_ActCold_Influence") AS "InteractionType_Bizibile-TouchPoint_CallGatekeeper_Count_ActCold_Influence_TOTAL",
SUM(aggr."InteractionType_Bizibile-TouchPoint_NoLeadTouchPoint_Count_ActCold_Influence") AS "InteractionType_Bizibile-TouchPoint_NoLeadTouchPoint_Count_ActCold_Influence_TOTAL",
SUM(aggr."InteractionType_Bizibile-TouchPoint_Unclassified_Count_ActCold_Influence") AS "InteractionType_Bizibile-TouchPoint_Unclassified_Count_ActCold_Influence_TOTAL",

SUM(aggr."InteractionType_6Sense_PaidMedia_Impressions_Count_ActMEA_Influence") AS "InteractionType_6Sense_PaidMedia_Impressions_Count_ActMEA_Influence_TOTAL",
SUM(aggr."InteractionType_6Sense_PaidMedia_Clicks_Count_ActMEA_Influence") AS "InteractionType_6Sense_PaidMedia_Clicks_Count_ActMEA_Influence_TOTAL",
SUM(aggr."InteractionType_6Sense_WebVisit_PageLoad_Count_ActMEA_Influence") AS "InteractionType_6Sense_WebVisit_PageLoad_Count_ActMEA_Influence_TOTAL",
SUM(aggr."InteractionType_6Sense_WebVisit_Play_Count_ActMEA_Influence") AS "InteractionType_6Sense_WebVisit_Play_Count_ActMEA_Influence_TOTAL",
SUM(aggr."InteractionType_6Sense_WebVisit_Click_Count_ActMEA_Influence") AS "InteractionType_6Sense_WebVisit_Click_Count_ActMEA_Influence_TOTAL",
SUM(aggr."InteractionType_6Sense_WebVisit_Submit_Count_ActMEA_Influence") AS "InteractionType_6Sense_WebVisit_Submit_Count_ActMEA_Influence_TOTAL",
SUM(aggr."InteractionType_6Sense_WebVisit_Unclassified_Count_ActMEA_Influence") AS "InteractionType_6Sense_WebVisit_Unclassified_Count_ActMEA_Influence_TOTAL",
SUM(aggr."InteractionType_Bizibile-TouchPoint_WebVisit_Count_ActMEA_Influence") AS "InteractionType_Bizibile-TouchPoint_WebVisit_Count_ActMEA_Influence_TOTAL",
SUM(aggr."InteractionType_Bizibile-TouchPoint_WebChat_Count_ActMEA_Influence") AS "InteractionType_Bizibile-TouchPoint_WebChat_Count_ActMEA_Influence_TOTAL",
SUM(aggr."InteractionType_Bizibile-TouchPoint_WebForm_Count_ActMEA_Influence") AS "InteractionType_Bizibile-TouchPoint_WebForm_Count_ActMEA_Influence_TOTAL",
SUM(aggr."InteractionType_Bizibile-TouchPoint_CRM_Count_ActMEA_Influence") AS "InteractionType_Bizibile-TouchPoint_CRM_Count_ActMEA_Influence_TOTAL",
SUM(aggr."InteractionType_Bizibile-TouchPoint_ConnectwithDM_Count_ActMEA_Influence") AS "InteractionType_Bizibile-TouchPoint_ConnectwithDM_Count_ActMEA_Influence_TOTAL",
SUM(aggr."InteractionType_Bizibile-TouchPoint_CallSpokeWith_Count_ActMEA_Influence") AS "InteractionType_Bizibile-TouchPoint_CallSpokeWith_Count_ActMEA_Influence_TOTAL",
SUM(aggr."InteractionType_Bizibile-TouchPoint_CallGatekeeper_Count_ActMEA_Influence") AS "InteractionType_Bizibile-TouchPoint_CallGatekeeper_Count_ActMEA_Influence_TOTAL",
SUM(aggr."InteractionType_Bizibile-TouchPoint_NoLeadTouchPoint_Count_ActMEA_Influence") AS "InteractionType_Bizibile-TouchPoint_NoLeadTouchPoint_Count_ActMEA_Influence_TOTAL",
SUM(aggr."InteractionType_Bizibile-TouchPoint_Unclassified_Count_ActMEA_Influence") AS "InteractionType_Bizibile-TouchPoint_Unclassified_Count_ActMEA_Influence_TOTAL",

SUM(aggr."InteractionType_6Sense_PaidMedia_Impressions_Count_ActMQA_Influence") AS "InteractionType_6Sense_PaidMedia_Impressions_Count_ActMQA_Influence_TOTAL",
SUM(aggr."InteractionType_6Sense_PaidMedia_Clicks_Count_ActMQA_Influence") AS "InteractionType_6Sense_PaidMedia_Clicks_Count_ActMQA_Influence_TOTAL",
SUM(aggr."InteractionType_6Sense_WebVisit_PageLoad_Count_ActMQA_Influence") AS "InteractionType_6Sense_WebVisit_PageLoad_Count_ActMQA_Influence_TOTAL",
SUM(aggr."InteractionType_6Sense_WebVisit_Play_Count_ActMQA_Influence") AS "InteractionType_6Sense_WebVisit_Play_Count_ActMQA_Influence_TOTAL",
SUM(aggr."InteractionType_6Sense_WebVisit_Click_Count_ActMQA_Influence") AS "InteractionType_6Sense_WebVisit_Click_Count_ActMQA_Influence_TOTAL",
SUM(aggr."InteractionType_6Sense_WebVisit_Submit_Count_ActMQA_Influence") AS "InteractionType_6Sense_WebVisit_Submit_Count_ActMQA_Influence_TOTAL",
SUM(aggr."InteractionType_6Sense_WebVisit_Unclassified_Count_ActMQA_Influence") AS "InteractionType_6Sense_WebVisit_Unclassified_Count_ActMQA_Influence_TOTAL",
SUM(aggr."InteractionType_Bizibile-TouchPoint_WebVisit_Count_ActMQA_Influence") AS "InteractionType_Bizibile-TouchPoint_WebVisit_Count_ActMQA_Influence_TOTAL",
SUM(aggr."InteractionType_Bizibile-TouchPoint_WebChat_Count_ActMQA_Influence") AS "InteractionType_Bizibile-TouchPoint_WebChat_Count_ActMQA_Influence_TOTAL",
SUM(aggr."InteractionType_Bizibile-TouchPoint_WebForm_Count_ActMQA_Influence") AS "InteractionType_Bizibile-TouchPoint_WebForm_Count_ActMQA_Influence_TOTAL",
SUM(aggr."InteractionType_Bizibile-TouchPoint_CRM_Count_ActMQA_Influence") AS "InteractionType_Bizibile-TouchPoint_CRM_Count_ActMQA_Influence_TOTAL",
SUM(aggr."InteractionType_Bizibile-TouchPoint_ConnectwithDM_Count_ActMQA_Influence") AS "InteractionType_Bizibile-TouchPoint_ConnectwithDM_Count_ActMQA_Influence_TOTAL",
SUM(aggr."InteractionType_Bizibile-TouchPoint_CallSpokeWith_Count_ActMQA_Influence") AS "InteractionType_Bizibile-TouchPoint_CallSpokeWith_Count_ActMQA_Influence_TOTAL",
SUM(aggr."InteractionType_Bizibile-TouchPoint_CallGatekeeper_Count_ActMQA_Influence") AS "InteractionType_Bizibile-TouchPoint_CallGatekeeper_Count_ActMQA_Influence_TOTAL",
SUM(aggr."InteractionType_Bizibile-TouchPoint_NoLeadTouchPoint_Count_ActMQA_Influence") AS "InteractionType_Bizibile-TouchPoint_NoLeadTouchPoint_Count_ActMQA_Influence_TOTAL",
SUM(aggr."InteractionType_Bizibile-TouchPoint_Unclassified_Count_ActMQA_Influence") AS "InteractionType_Bizibile-TouchPoint_Unclassified_Count_ActMQA_Influence_TOTAL",

SUM(aggr."InteractionType_6Sense_PaidMedia_Impressions_Count_ActSuspect_Influence") AS "InteractionType_6Sense_PaidMedia_Impressions_Count_ActSuspect_Influence_TOTAL",
SUM(aggr."InteractionType_6Sense_PaidMedia_Clicks_Count_ActSuspect_Influence") AS "InteractionType_6Sense_PaidMedia_Clicks_Count_ActSuspect_Influence_TOTAL",
SUM(aggr."InteractionType_6Sense_WebVisit_PageLoad_Count_ActSuspect_Influence") AS "InteractionType_6Sense_WebVisit_PageLoad_Count_ActSuspect_Influence_TOTAL",
SUM(aggr."InteractionType_6Sense_WebVisit_Play_Count_ActSuspect_Influence") AS "InteractionType_6Sense_WebVisit_Play_Count_ActSuspect_Influence_TOTAL",
SUM(aggr."InteractionType_6Sense_WebVisit_Click_Count_ActSuspect_Influence") AS "InteractionType_6Sense_WebVisit_Click_Count_ActSuspect_Influence_TOTAL",
SUM(aggr."InteractionType_6Sense_WebVisit_Submit_Count_ActSuspect_Influence") AS "InteractionType_6Sense_WebVisit_Submit_Count_ActSuspect_Influence_TOTAL",
SUM(aggr."InteractionType_6Sense_WebVisit_Unclassified_Count_ActSuspect_Influence") AS "InteractionType_6Sense_WebVisit_Unclassified_Count_ActSuspect_Influence_TOTAL",
SUM(aggr."InteractionType_Bizibile-TouchPoint_WebVisit_Count_ActSuspect_Influence") AS "InteractionType_Bizibile-TouchPoint_WebVisit_Count_ActSuspect_Influence_TOTAL",
SUM(aggr."InteractionType_Bizibile-TouchPoint_WebChat_Count_ActSuspect_Influence") AS "InteractionType_Bizibile-TouchPoint_WebChat_Count_ActSuspect_Influence_TOTAL",
SUM(aggr."InteractionType_Bizibile-TouchPoint_WebForm_Count_ActSuspect_Influence") AS "InteractionType_Bizibile-TouchPoint_WebForm_Count_ActSuspect_Influence_TOTAL",
SUM(aggr."InteractionType_Bizibile-TouchPoint_CRM_Count_ActSuspect_Influence") AS "InteractionType_Bizibile-TouchPoint_CRM_Count_ActSuspect_Influence_TOTAL",
SUM(aggr."InteractionType_Bizibile-TouchPoint_ConnectwithDM_Count_ActSuspect_Influence") AS "InteractionType_Bizibile-TouchPoint_ConnectwithDM_Count_ActSuspect_Influence_TOTAL",
SUM(aggr."InteractionType_Bizibile-TouchPoint_CallSpokeWith_Count_ActSuspect_Influence") AS "InteractionType_Bizibile-TouchPoint_CallSpokeWith_Count_ActSuspect_Influence_TOTAL",
SUM(aggr."InteractionType_Bizibile-TouchPoint_CallGatekeeper_Count_ActSuspect_Influence") AS "InteractionType_Bizibile-TouchPoint_CallGatekeeper_Count_ActSuspect_Influence_TOTAL",
SUM(aggr."InteractionType_Bizibile-TouchPoint_NoLeadTouchPoint_Count_ActSuspect_Influence") AS "InteractionType_Bizibile-TouchPoint_NoLeadTouchPoint_Count_ActSuspect_Influence_TOTAL",
SUM(aggr."InteractionType_Bizibile-TouchPoint_Unclassified_Count_ActSuspect_Influence") AS "InteractionType_Bizibile-TouchPoint_Unclassified_Count_ActSuspect_Influence_TOTAL",

SUM(aggr."InteractionType_6Sense_PaidMedia_Impressions_Count_ActProspect_Influence") AS "InteractionType_6Sense_PaidMedia_Impressions_Count_ActProspect_Influence_TOTAL",
SUM(aggr."InteractionType_6Sense_PaidMedia_Clicks_Count_ActProspect_Influence") AS "InteractionType_6Sense_PaidMedia_Clicks_Count_ActProspect_Influence_TOTAL",
SUM(aggr."InteractionType_6Sense_WebVisit_PageLoad_Count_ActProspect_Influence") AS "InteractionType_6Sense_WebVisit_PageLoad_Count_ActProspect_Influence_TOTAL",
SUM(aggr."InteractionType_6Sense_WebVisit_Play_Count_ActProspect_Influence") AS "InteractionType_6Sense_WebVisit_Play_Count_ActProspect_Influence_TOTAL",
SUM(aggr."InteractionType_6Sense_WebVisit_Click_Count_ActProspect_Influence") AS "InteractionType_6Sense_WebVisit_Click_Count_ActProspect_Influence_TOTAL",
SUM(aggr."InteractionType_6Sense_WebVisit_Submit_Count_ActProspect_Influence") AS "InteractionType_6Sense_WebVisit_Submit_Count_ActProspect_Influence_TOTAL",
SUM(aggr."InteractionType_6Sense_WebVisit_Unclassified_Count_ActProspect_Influence") AS "InteractionType_6Sense_WebVisit_Unclassified_Count_ActProspect_Influence_TOTAL",
SUM(aggr."InteractionType_Bizibile-TouchPoint_WebVisit_Count_ActProspect_Influence") AS "InteractionType_Bizibile-TouchPoint_WebVisit_Count_ActProspect_Influence_TOTAL",
SUM(aggr."InteractionType_Bizibile-TouchPoint_WebChat_Count_ActProspect_Influence") AS "InteractionType_Bizibile-TouchPoint_WebChat_Count_ActProspect_Influence_TOTAL",
SUM(aggr."InteractionType_Bizibile-TouchPoint_WebForm_Count_ActProspect_Influence") AS "InteractionType_Bizibile-TouchPoint_WebForm_Count_ActProspect_Influence_TOTAL",
SUM(aggr."InteractionType_Bizibile-TouchPoint_CRM_Count_ActProspect_Influence") AS "InteractionType_Bizibile-TouchPoint_CRM_Count_ActProspect_Influence_TOTAL",
SUM(aggr."InteractionType_Bizibile-TouchPoint_ConnectwithDM_Count_ActProspect_Influence") AS "InteractionType_Bizibile-TouchPoint_ConnectwithDM_Count_ActProspect_Influence_TOTAL",
SUM(aggr."InteractionType_Bizibile-TouchPoint_CallSpokeWith_Count_ActProspect_Influence") AS "InteractionType_Bizibile-TouchPoint_CallSpokeWith_Count_ActProspect_Influence_TOTAL",
SUM(aggr."InteractionType_Bizibile-TouchPoint_CallGatekeeper_Count_ActProspect_Influence") AS "InteractionType_Bizibile-TouchPoint_CallGatekeeper_Count_ActProspect_Influence_TOTAL",
SUM(aggr."InteractionType_Bizibile-TouchPoint_NoLeadTouchPoint_Count_ActProspect_Influence") AS "InteractionType_Bizibile-TouchPoint_NoLeadTouchPoint_Count_ActProspect_Influence_TOTAL",
SUM(aggr."InteractionType_Bizibile-TouchPoint_Unclassified_Count_ActProspect_Influence") AS "InteractionType_Bizibile-TouchPoint_Unclassified_Count_ActProspect_Influence_TOTAL",

MAX(aggr."Flag_Influence_TouchPoint_by_AcquisitionChannelTopLevel_ChannelReferral") AS "Flag_Influence_TouchPoint_by_AcquisitionChannelTopLevel_ChannelReferral",
MAX(aggr."Flag_Influence_TouchPoint_by_AcquisitionChannelTopLevel_ContentSyndication") AS "Flag_Influence_TouchPoint_by_AcquisitionChannelTopLevel_ContentSyndication",
MAX(aggr."Flag_Influence_TouchPoint_by_AcquisitionChannelTopLevel_SalesEngagement") AS "Flag_Influence_TouchPoint_by_AcquisitionChannelTopLevel_SalesEngagement",
MAX(aggr."Flag_Influence_TouchPoint_by_AcquisitionChannelTopLevel_Direct") AS "Flag_Influence_TouchPoint_by_AcquisitionChannelTopLevel_Direct",
MAX(aggr."Flag_Influence_TouchPoint_by_AcquisitionChannelTopLevel_DirectMail") AS "Flag_Influence_TouchPoint_by_AcquisitionChannelTopLevel_DirectMail",
MAX(aggr."Flag_Influence_TouchPoint_by_AcquisitionChannelTopLevel_Display") AS "Flag_Influence_TouchPoint_by_AcquisitionChannelTopLevel_Display",
MAX(aggr."Flag_Influence_TouchPoint_by_AcquisitionChannelTopLevel_Email") AS "Flag_Influence_TouchPoint_by_AcquisitionChannelTopLevel_Email",
MAX(aggr."Flag_Influence_TouchPoint_by_AcquisitionChannelTopLevel_LeadReferral") AS "Flag_Influence_TouchPoint_by_AcquisitionChannelTopLevel_LeadReferral",
MAX(aggr."Flag_Influence_TouchPoint_by_AcquisitionChannelTopLevel_LiveEvent") AS "Flag_Influence_TouchPoint_by_AcquisitionChannelTopLevel_LiveEvent",
MAX(aggr."Flag_Influence_TouchPoint_by_AcquisitionChannelTopLevel_Lytx") AS "Flag_Influence_TouchPoint_by_AcquisitionChannelTopLevel_Lytx",
MAX(aggr."Flag_Influence_TouchPoint_by_AcquisitionChannelTopLevel_Native") AS "Flag_Influence_TouchPoint_by_AcquisitionChannelTopLevel_Native",
MAX(aggr."Flag_Influence_TouchPoint_by_AcquisitionChannelTopLevel_OrganicSearch") AS "Flag_Influence_TouchPoint_by_AcquisitionChannelTopLevel_OrganicSearch",
MAX(aggr."Flag_Influence_TouchPoint_by_AcquisitionChannelTopLevel_OrganicSocial") AS "Flag_Influence_TouchPoint_by_AcquisitionChannelTopLevel_OrganicSocial",
MAX(aggr."Flag_Influence_TouchPoint_by_AcquisitionChannelTopLevel_Other") AS "Flag_Influence_TouchPoint_by_AcquisitionChannelTopLevel_Other",
MAX(aggr."Flag_Influence_TouchPoint_by_AcquisitionChannelTopLevel_PaidMedia") AS "Flag_Influence_TouchPoint_by_AcquisitionChannelTopLevel_PaidMedia",
MAX(aggr."Flag_Influence_TouchPoint_by_AcquisitionChannelTopLevel_PaidSearch") AS "Flag_Influence_TouchPoint_by_AcquisitionChannelTopLevel_PaidSearch",
MAX(aggr."Flag_Influence_TouchPoint_by_AcquisitionChannelTopLevel_PaidSocial") AS "Flag_Influence_TouchPoint_by_AcquisitionChannelTopLevel_PaidSocial",
MAX(aggr."Flag_Influence_TouchPoint_by_AcquisitionChannelTopLevel_Podcast") AS "Flag_Influence_TouchPoint_by_AcquisitionChannelTopLevel_Podcast",
MAX(aggr."Flag_Influence_TouchPoint_by_AcquisitionChannelTopLevel_PPL") AS "Flag_Influence_TouchPoint_by_AcquisitionChannelTopLevel_PPL",
MAX(aggr."Flag_Influence_TouchPoint_by_AcquisitionChannelTopLevel_Print") AS "Flag_Influence_TouchPoint_by_AcquisitionChannelTopLevel_Print",
MAX(aggr."Flag_Influence_TouchPoint_by_AcquisitionChannelTopLevel_SponsoredEmail") AS "Flag_Influence_TouchPoint_by_AcquisitionChannelTopLevel_SponsoredEmail",
MAX(aggr."Flag_Influence_TouchPoint_by_AcquisitionChannelTopLevel_Tradeshow") AS "Flag_Influence_TouchPoint_by_AcquisitionChannelTopLevel_Tradeshow",
MAX(aggr."Flag_Influence_TouchPoint_by_AcquisitionChannelTopLevel_Web Referral") AS "Flag_Influence_TouchPoint_by_AcquisitionChannelTopLevel_Web Referral",
MAX(aggr."Flag_Influence_TouchPoint_by_AcquisitionChannelTopLevel_Webinar") AS "Flag_Influence_TouchPoint_by_AcquisitionChannelTopLevel_Webinar",


MAX(aggr."Flag_CLS_Influence_TouchPoint_by_AcquisitionChannelTopLevel_ChannelReferral") AS "Flag_CLS_Influence_TouchPoint_by_AcquisitionChannelTopLevel_ChannelReferral",
MAX(aggr."Flag_CLS_Influence_TouchPoint_by_AcquisitionChannelTopLevel_ContentSyndication") AS "Flag_CLS_Influence_TouchPoint_by_AcquisitionChannelTopLevel_ContentSyndication",
MAX(aggr."Flag_CLS_Influence_TouchPoint_by_AcquisitionChannelTopLevel_SalesEngagement") AS "Flag_CLS_Influence_TouchPoint_by_AcquisitionChannelTopLevel_SalesEngagement",
MAX(aggr."Flag_CLS_Influence_TouchPoint_by_AcquisitionChannelTopLevel_Direct") AS "Flag_CLS_Influence_TouchPoint_by_AcquisitionChannelTopLevel_Direct",
MAX(aggr."Flag_CLS_Influence_TouchPoint_by_AcquisitionChannelTopLevel_DirectMail") AS "Flag_CLS_Influence_TouchPoint_by_AcquisitionChannelTopLevel_DirectMail",
MAX(aggr."Flag_CLS_Influence_TouchPoint_by_AcquisitionChannelTopLevel_Display") AS "Flag_CLS_Influence_TouchPoint_by_AcquisitionChannelTopLevel_Display",
MAX(aggr."Flag_CLS_Influence_TouchPoint_by_AcquisitionChannelTopLevel_Email") AS "Flag_CLS_Influence_TouchPoint_by_AcquisitionChannelTopLevel_Email",
MAX(aggr."Flag_CLS_Influence_TouchPoint_by_AcquisitionChannelTopLevel_LeadReferral") AS "Flag_CLS_Influence_TouchPoint_by_AcquisitionChannelTopLevel_LeadReferral",
MAX(aggr."Flag_CLS_Influence_TouchPoint_by_AcquisitionChannelTopLevel_LiveEvent") AS "Flag_CLS_Influence_TouchPoint_by_AcquisitionChannelTopLevel_LiveEvent",
MAX(aggr."Flag_CLS_Influence_TouchPoint_by_AcquisitionChannelTopLevel_Lytx") AS "Flag_CLS_Influence_TouchPoint_by_AcquisitionChannelTopLevel_Lytx",
MAX(aggr."Flag_CLS_Influence_TouchPoint_by_AcquisitionChannelTopLevel_Native") AS "Flag_CLS_Influence_TouchPoint_by_AcquisitionChannelTopLevel_Native",
MAX(aggr."Flag_CLS_Influence_TouchPoint_by_AcquisitionChannelTopLevel_OrganicSearch") AS "Flag_CLS_Influence_TouchPoint_by_AcquisitionChannelTopLevel_OrganicSearch",
MAX(aggr."Flag_CLS_Influence_TouchPoint_by_AcquisitionChannelTopLevel_OrganicSocial") AS "Flag_CLS_Influence_TouchPoint_by_AcquisitionChannelTopLevel_OrganicSocial",
MAX(aggr."Flag_CLS_Influence_TouchPoint_by_AcquisitionChannelTopLevel_Other") AS "Flag_CLS_Influence_TouchPoint_by_AcquisitionChannelTopLevel_Other",
MAX(aggr."Flag_CLS_Influence_TouchPoint_by_AcquisitionChannelTopLevel_PaidMedia") AS "Flag_CLS_Influence_TouchPoint_by_AcquisitionChannelTopLevel_PaidMedia",
MAX(aggr."Flag_CLS_Influence_TouchPoint_by_AcquisitionChannelTopLevel_PaidSearch") AS "Flag_CLS_Influence_TouchPoint_by_AcquisitionChannelTopLevel_PaidSearch",
MAX(aggr."Flag_CLS_Influence_TouchPoint_by_AcquisitionChannelTopLevel_PaidSocial") AS "Flag_CLS_Influence_TouchPoint_by_AcquisitionChannelTopLevel_PaidSocial",
MAX(aggr."Flag_CLS_Influence_TouchPoint_by_AcquisitionChannelTopLevel_Podcast") AS "Flag_CLS_Influence_TouchPoint_by_AcquisitionChannelTopLevel_Podcast",
MAX(aggr."Flag_CLS_Influence_TouchPoint_by_AcquisitionChannelTopLevel_PPL") AS "Flag_CLS_Influence_TouchPoint_by_AcquisitionChannelTopLevel_PPL",
MAX(aggr."Flag_CLS_Influence_TouchPoint_by_AcquisitionChannelTopLevel_Print") AS "Flag_CLS_Influence_TouchPoint_by_AcquisitionChannelTopLevel_Print",
MAX(aggr."Flag_CLS_Influence_TouchPoint_by_AcquisitionChannelTopLevel_SponsoredEmail") AS "Flag_CLS_Influence_TouchPoint_by_AcquisitionChannelTopLevel_SponsoredEmail",
MAX(aggr."Flag_CLS_Influence_TouchPoint_by_AcquisitionChannelTopLevel_Tradeshow") AS "Flag_CLS_Influence_TouchPoint_by_AcquisitionChannelTopLevel_Tradeshow",
MAX(aggr."Flag_CLS_Influence_TouchPoint_by_AcquisitionChannelTopLevel_Web Referral") AS "Flag_CLS_Influence_TouchPoint_by_AcquisitionChannelTopLevel_Web Referral",
MAX(aggr."Flag_CLS_Influence_TouchPoint_by_AcquisitionChannelTopLevel_Webinar") AS "Flag_CLS_Influence_TouchPoint_by_AcquisitionChannelTopLevel_Webinar",

MAX(aggr."Flag_ActCold_Influence_TouchPoint_by_AcquisitionChannelTopLevel_ChannelReferral") AS "Flag_ActCold_Influence_TouchPoint_by_AcquisitionChannelTopLevel_ChannelReferral",
MAX(aggr."Flag_ActCold_Influence_TouchPoint_by_AcquisitionChannelTopLevel_ContentSyndication") AS "Flag_ActCold_Influence_TouchPoint_by_AcquisitionChannelTopLevel_ContentSyndication",
MAX(aggr."Flag_ActCold_Influence_TouchPoint_by_AcquisitionChannelTopLevel_SalesEngagement") AS "Flag_ActCold_Influence_TouchPoint_by_AcquisitionChannelTopLevel_SalesEngagement",
MAX(aggr."Flag_ActCold_Influence_TouchPoint_by_AcquisitionChannelTopLevel_Direct") AS "Flag_ActCold_Influence_TouchPoint_by_AcquisitionChannelTopLevel_Direct",
MAX(aggr."Flag_ActCold_Influence_TouchPoint_by_AcquisitionChannelTopLevel_DirectMail") AS "Flag_ActCold_Influence_TouchPoint_by_AcquisitionChannelTopLevel_DirectMail",
MAX(aggr."Flag_ActCold_Influence_TouchPoint_by_AcquisitionChannelTopLevel_Display") AS "Flag_ActCold_Influence_TouchPoint_by_AcquisitionChannelTopLevel_Display",
MAX(aggr."Flag_ActCold_Influence_TouchPoint_by_AcquisitionChannelTopLevel_Email") AS "Flag_ActCold_Influence_TouchPoint_by_AcquisitionChannelTopLevel_Email",
MAX(aggr."Flag_ActCold_Influence_TouchPoint_by_AcquisitionChannelTopLevel_LeadReferral") AS "Flag_ActCold_Influence_TouchPoint_by_AcquisitionChannelTopLevel_LeadReferral",
MAX(aggr."Flag_ActCold_Influence_TouchPoint_by_AcquisitionChannelTopLevel_LiveEvent") AS "Flag_ActCold_Influence_TouchPoint_by_AcquisitionChannelTopLevel_LiveEvent",
MAX(aggr."Flag_ActCold_Influence_TouchPoint_by_AcquisitionChannelTopLevel_Lytx") AS "Flag_ActCold_Influence_TouchPoint_by_AcquisitionChannelTopLevel_Lytx",
MAX(aggr."Flag_ActCold_Influence_TouchPoint_by_AcquisitionChannelTopLevel_Native") AS "Flag_ActCold_Influence_TouchPoint_by_AcquisitionChannelTopLevel_Native",
MAX(aggr."Flag_ActCold_Influence_TouchPoint_by_AcquisitionChannelTopLevel_OrganicSearch") AS "Flag_ActCold_Influence_TouchPoint_by_AcquisitionChannelTopLevel_OrganicSearch",
MAX(aggr."Flag_ActCold_Influence_TouchPoint_by_AcquisitionChannelTopLevel_OrganicSocial") AS "Flag_ActCold_Influence_TouchPoint_by_AcquisitionChannelTopLevel_OrganicSocial",
MAX(aggr."Flag_ActCold_Influence_TouchPoint_by_AcquisitionChannelTopLevel_Other") AS "Flag_ActCold_Influence_TouchPoint_by_AcquisitionChannelTopLevel_Other",
MAX(aggr."Flag_ActCold_Influence_TouchPoint_by_AcquisitionChannelTopLevel_PaidMedia") AS "Flag_ActCold_Influence_TouchPoint_by_AcquisitionChannelTopLevel_PaidMedia",
MAX(aggr."Flag_ActCold_Influence_TouchPoint_by_AcquisitionChannelTopLevel_PaidSearch") AS "Flag_ActCold_Influence_TouchPoint_by_AcquisitionChannelTopLevel_PaidSearch",
MAX(aggr."Flag_ActCold_Influence_TouchPoint_by_AcquisitionChannelTopLevel_PaidSocial") AS "Flag_ActCold_Influence_TouchPoint_by_AcquisitionChannelTopLevel_PaidSocial",
MAX(aggr."Flag_ActCold_Influence_TouchPoint_by_AcquisitionChannelTopLevel_Podcast") AS "Flag_ActCold_Influence_TouchPoint_by_AcquisitionChannelTopLevel_Podcast",
MAX(aggr."Flag_ActCold_Influence_TouchPoint_by_AcquisitionChannelTopLevel_PPL") AS "Flag_ActCold_Influence_TouchPoint_by_AcquisitionChannelTopLevel_PPL",
MAX(aggr."Flag_ActCold_Influence_TouchPoint_by_AcquisitionChannelTopLevel_Print") AS "Flag_ActCold_Influence_TouchPoint_by_AcquisitionChannelTopLevel_Print",
MAX(aggr."Flag_ActCold_Influence_TouchPoint_by_AcquisitionChannelTopLevel_SponsoredEmail") AS "Flag_ActCold_Influence_TouchPoint_by_AcquisitionChannelTopLevel_SponsoredEmail",
MAX(aggr."Flag_ActCold_Influence_TouchPoint_by_AcquisitionChannelTopLevel_Tradeshow") AS "Flag_ActCold_Influence_TouchPoint_by_AcquisitionChannelTopLevel_Tradeshow",
MAX(aggr."Flag_ActCold_Influence_TouchPoint_by_AcquisitionChannelTopLevel_Web Referral") AS "Flag_ActCold_Influence_TouchPoint_by_AcquisitionChannelTopLevel_Web Referral",
MAX(aggr."Flag_ActCold_Influence_TouchPoint_by_AcquisitionChannelTopLevel_Webinar") AS "Flag_ActCold_Influence_TouchPoint_by_AcquisitionChannelTopLevel_Webinar",

MAX(aggr."Flag_ActMEA_Influence_TouchPoint_by_AcquisitionChannelTopLevel_ChannelReferral") AS "Flag_ActMEA_Influence_TouchPoint_by_AcquisitionChannelTopLevel_ChannelReferral",
MAX(aggr."Flag_ActMEA_Influence_TouchPoint_by_AcquisitionChannelTopLevel_ContentSyndication") AS "Flag_ActMEA_Influence_TouchPoint_by_AcquisitionChannelTopLevel_ContentSyndication",
MAX(aggr."Flag_ActMEA_Influence_TouchPoint_by_AcquisitionChannelTopLevel_SalesEngagement") AS "Flag_ActMEA_Influence_TouchPoint_by_AcquisitionChannelTopLevel_SalesEngagement",
MAX(aggr."Flag_ActMEA_Influence_TouchPoint_by_AcquisitionChannelTopLevel_Direct") AS "Flag_ActMEA_Influence_TouchPoint_by_AcquisitionChannelTopLevel_Direct",
MAX(aggr."Flag_ActMEA_Influence_TouchPoint_by_AcquisitionChannelTopLevel_DirectMail") AS "Flag_ActMEA_Influence_TouchPoint_by_AcquisitionChannelTopLevel_DirectMail",
MAX(aggr."Flag_ActMEA_Influence_TouchPoint_by_AcquisitionChannelTopLevel_Display") AS "Flag_ActMEA_Influence_TouchPoint_by_AcquisitionChannelTopLevel_Display",
MAX(aggr."Flag_ActMEA_Influence_TouchPoint_by_AcquisitionChannelTopLevel_Email") AS "Flag_ActMEA_Influence_TouchPoint_by_AcquisitionChannelTopLevel_Email",
MAX(aggr."Flag_ActMEA_Influence_TouchPoint_by_AcquisitionChannelTopLevel_LeadReferral") AS "Flag_ActMEA_Influence_TouchPoint_by_AcquisitionChannelTopLevel_LeadReferral",
MAX(aggr."Flag_ActMEA_Influence_TouchPoint_by_AcquisitionChannelTopLevel_LiveEvent") AS "Flag_ActMEA_Influence_TouchPoint_by_AcquisitionChannelTopLevel_LiveEvent",
MAX(aggr."Flag_ActMEA_Influence_TouchPoint_by_AcquisitionChannelTopLevel_Lytx") AS "Flag_ActMEA_Influence_TouchPoint_by_AcquisitionChannelTopLevel_Lytx",
MAX(aggr."Flag_ActMEA_Influence_TouchPoint_by_AcquisitionChannelTopLevel_Native") AS "Flag_ActMEA_Influence_TouchPoint_by_AcquisitionChannelTopLevel_Native",
MAX(aggr."Flag_ActMEA_Influence_TouchPoint_by_AcquisitionChannelTopLevel_OrganicSearch") AS "Flag_ActMEA_Influence_TouchPoint_by_AcquisitionChannelTopLevel_OrganicSearch",
MAX(aggr."Flag_ActMEA_Influence_TouchPoint_by_AcquisitionChannelTopLevel_OrganicSocial") AS "Flag_ActMEA_Influence_TouchPoint_by_AcquisitionChannelTopLevel_OrganicSocial",
MAX(aggr."Flag_ActMEA_Influence_TouchPoint_by_AcquisitionChannelTopLevel_Other") AS "Flag_ActMEA_Influence_TouchPoint_by_AcquisitionChannelTopLevel_Other",
MAX(aggr."Flag_ActMEA_Influence_TouchPoint_by_AcquisitionChannelTopLevel_PaidMedia") AS "Flag_ActMEA_Influence_TouchPoint_by_AcquisitionChannelTopLevel_PaidMedia",
MAX(aggr."Flag_ActMEA_Influence_TouchPoint_by_AcquisitionChannelTopLevel_PaidSearch") AS "Flag_ActMEA_Influence_TouchPoint_by_AcquisitionChannelTopLevel_PaidSearch",
MAX(aggr."Flag_ActMEA_Influence_TouchPoint_by_AcquisitionChannelTopLevel_PaidSocial") AS "Flag_ActMEA_Influence_TouchPoint_by_AcquisitionChannelTopLevel_PaidSocial",
MAX(aggr."Flag_ActMEA_Influence_TouchPoint_by_AcquisitionChannelTopLevel_Podcast") AS "Flag_ActMEA_Influence_TouchPoint_by_AcquisitionChannelTopLevel_Podcast",
MAX(aggr."Flag_ActMEA_Influence_TouchPoint_by_AcquisitionChannelTopLevel_PPL") AS "Flag_ActMEA_Influence_TouchPoint_by_AcquisitionChannelTopLevel_PPL",
MAX(aggr."Flag_ActMEA_Influence_TouchPoint_by_AcquisitionChannelTopLevel_Print") AS "Flag_ActMEA_Influence_TouchPoint_by_AcquisitionChannelTopLevel_Print",
MAX(aggr."Flag_ActMEA_Influence_TouchPoint_by_AcquisitionChannelTopLevel_SponsoredEmail") AS "Flag_ActMEA_Influence_TouchPoint_by_AcquisitionChannelTopLevel_SponsoredEmail",
MAX(aggr."Flag_ActMEA_Influence_TouchPoint_by_AcquisitionChannelTopLevel_Tradeshow") AS "Flag_ActMEA_Influence_TouchPoint_by_AcquisitionChannelTopLevel_Tradeshow",
MAX(aggr."Flag_ActMEA_Influence_TouchPoint_by_AcquisitionChannelTopLevel_Web Referral") AS "Flag_ActMEA_Influence_TouchPoint_by_AcquisitionChannelTopLevel_Web Referral",
MAX(aggr."Flag_ActMEA_Influence_TouchPoint_by_AcquisitionChannelTopLevel_Webinar") AS "Flag_ActMEA_Influence_TouchPoint_by_AcquisitionChannelTopLevel_Webinar",

MAX(aggr."Flag_ActMQA_Influence_TouchPoint_by_AcquisitionChannelTopLevel_ChannelReferral") AS "Flag_ActMQA_Influence_TouchPoint_by_AcquisitionChannelTopLevel_ChannelReferral",
MAX(aggr."Flag_ActMQA_Influence_TouchPoint_by_AcquisitionChannelTopLevel_ContentSyndication") AS "Flag_ActMQA_Influence_TouchPoint_by_AcquisitionChannelTopLevel_ContentSyndication",
MAX(aggr."Flag_ActMQA_Influence_TouchPoint_by_AcquisitionChannelTopLevel_SalesEngagement") AS "Flag_ActMQA_Influence_TouchPoint_by_AcquisitionChannelTopLevel_SalesEngagement",
MAX(aggr."Flag_ActMQA_Influence_TouchPoint_by_AcquisitionChannelTopLevel_Direct") AS "Flag_ActMQA_Influence_TouchPoint_by_AcquisitionChannelTopLevel_Direct",
MAX(aggr."Flag_ActMQA_Influence_TouchPoint_by_AcquisitionChannelTopLevel_DirectMail") AS "Flag_ActMQA_Influence_TouchPoint_by_AcquisitionChannelTopLevel_DirectMail",
MAX(aggr."Flag_ActMQA_Influence_TouchPoint_by_AcquisitionChannelTopLevel_Display") AS "Flag_ActMQA_Influence_TouchPoint_by_AcquisitionChannelTopLevel_Display",
MAX(aggr."Flag_ActMQA_Influence_TouchPoint_by_AcquisitionChannelTopLevel_Email") AS "Flag_ActMQA_Influence_TouchPoint_by_AcquisitionChannelTopLevel_Email",
MAX(aggr."Flag_ActMQA_Influence_TouchPoint_by_AcquisitionChannelTopLevel_LeadReferral") AS "Flag_ActMQA_Influence_TouchPoint_by_AcquisitionChannelTopLevel_LeadReferral",
MAX(aggr."Flag_ActMQA_Influence_TouchPoint_by_AcquisitionChannelTopLevel_LiveEvent") AS "Flag_ActMQA_Influence_TouchPoint_by_AcquisitionChannelTopLevel_LiveEvent",
MAX(aggr."Flag_ActMQA_Influence_TouchPoint_by_AcquisitionChannelTopLevel_Lytx") AS "Flag_ActMQA_Influence_TouchPoint_by_AcquisitionChannelTopLevel_Lytx",
MAX(aggr."Flag_ActMQA_Influence_TouchPoint_by_AcquisitionChannelTopLevel_Native") AS "Flag_ActMQA_Influence_TouchPoint_by_AcquisitionChannelTopLevel_Native",
MAX(aggr."Flag_ActMQA_Influence_TouchPoint_by_AcquisitionChannelTopLevel_OrganicSearch") AS "Flag_ActMQA_Influence_TouchPoint_by_AcquisitionChannelTopLevel_OrganicSearch",
MAX(aggr."Flag_ActMQA_Influence_TouchPoint_by_AcquisitionChannelTopLevel_OrganicSocial") AS "Flag_ActMQA_Influence_TouchPoint_by_AcquisitionChannelTopLevel_OrganicSocial",
MAX(aggr."Flag_ActMQA_Influence_TouchPoint_by_AcquisitionChannelTopLevel_Other") AS "Flag_ActMQA_Influence_TouchPoint_by_AcquisitionChannelTopLevel_Other",
MAX(aggr."Flag_ActMQA_Influence_TouchPoint_by_AcquisitionChannelTopLevel_PaidMedia") AS "Flag_ActMQA_Influence_TouchPoint_by_AcquisitionChannelTopLevel_PaidMedia",
MAX(aggr."Flag_ActMQA_Influence_TouchPoint_by_AcquisitionChannelTopLevel_PaidSearch") AS "Flag_ActMQA_Influence_TouchPoint_by_AcquisitionChannelTopLevel_PaidSearch",
MAX(aggr."Flag_ActMQA_Influence_TouchPoint_by_AcquisitionChannelTopLevel_PaidSocial") AS "Flag_ActMQA_Influence_TouchPoint_by_AcquisitionChannelTopLevel_PaidSocial",
MAX(aggr."Flag_ActMQA_Influence_TouchPoint_by_AcquisitionChannelTopLevel_Podcast") AS "Flag_ActMQA_Influence_TouchPoint_by_AcquisitionChannelTopLevel_Podcast",
MAX(aggr."Flag_ActMQA_Influence_TouchPoint_by_AcquisitionChannelTopLevel_PPL") AS "Flag_ActMQA_Influence_TouchPoint_by_AcquisitionChannelTopLevel_PPL",
MAX(aggr."Flag_ActMQA_Influence_TouchPoint_by_AcquisitionChannelTopLevel_Print") AS "Flag_ActMQA_Influence_TouchPoint_by_AcquisitionChannelTopLevel_Print",
MAX(aggr."Flag_ActMQA_Influence_TouchPoint_by_AcquisitionChannelTopLevel_SponsoredEmail") AS "Flag_ActMQA_Influence_TouchPoint_by_AcquisitionChannelTopLevel_SponsoredEmail",
MAX(aggr."Flag_ActMQA_Influence_TouchPoint_by_AcquisitionChannelTopLevel_Tradeshow") AS "Flag_ActMQA_Influence_TouchPoint_by_AcquisitionChannelTopLevel_Tradeshow",
MAX(aggr."Flag_ActMQA_Influence_TouchPoint_by_AcquisitionChannelTopLevel_Web Referral") AS "Flag_ActMQA_Influence_TouchPoint_by_AcquisitionChannelTopLevel_Web Referral",
MAX(aggr."Flag_ActMQA_Influence_TouchPoint_by_AcquisitionChannelTopLevel_Webinar") AS "Flag_ActMQA_Influence_TouchPoint_by_AcquisitionChannelTopLevel_Webinar",

MAX(aggr."Flag_ActSuspect_Influence_TouchPoint_by_AcquisitionChannelTopLevel_ChannelReferral") AS "Flag_ActSuspect_Influence_TouchPoint_by_AcquisitionChannelTopLevel_ChannelReferral",
MAX(aggr."Flag_ActSuspect_Influence_TouchPoint_by_AcquisitionChannelTopLevel_ContentSyndication") AS "Flag_ActSuspect_Influence_TouchPoint_by_AcquisitionChannelTopLevel_ContentSyndication",
MAX(aggr."Flag_ActSuspect_Influence_TouchPoint_by_AcquisitionChannelTopLevel_SalesEngagement") AS "Flag_ActSuspect_Influence_TouchPoint_by_AcquisitionChannelTopLevel_SalesEngagement",
MAX(aggr."Flag_ActSuspect_Influence_TouchPoint_by_AcquisitionChannelTopLevel_Direct") AS "Flag_ActSuspect_Influence_TouchPoint_by_AcquisitionChannelTopLevel_Direct",
MAX(aggr."Flag_ActSuspect_Influence_TouchPoint_by_AcquisitionChannelTopLevel_DirectMail") AS "Flag_ActSuspect_Influence_TouchPoint_by_AcquisitionChannelTopLevel_DirectMail",
MAX(aggr."Flag_ActSuspect_Influence_TouchPoint_by_AcquisitionChannelTopLevel_Display") AS "Flag_ActSuspect_Influence_TouchPoint_by_AcquisitionChannelTopLevel_Display",
MAX(aggr."Flag_ActSuspect_Influence_TouchPoint_by_AcquisitionChannelTopLevel_Email") AS "Flag_ActSuspect_Influence_TouchPoint_by_AcquisitionChannelTopLevel_Email",
MAX(aggr."Flag_ActSuspect_Influence_TouchPoint_by_AcquisitionChannelTopLevel_LeadReferral") AS "Flag_ActSuspect_Influence_TouchPoint_by_AcquisitionChannelTopLevel_LeadReferral",
MAX(aggr."Flag_ActSuspect_Influence_TouchPoint_by_AcquisitionChannelTopLevel_LiveEvent") AS "Flag_ActSuspect_Influence_TouchPoint_by_AcquisitionChannelTopLevel_LiveEvent",
MAX(aggr."Flag_ActSuspect_Influence_TouchPoint_by_AcquisitionChannelTopLevel_Lytx") AS "Flag_ActSuspect_Influence_TouchPoint_by_AcquisitionChannelTopLevel_Lytx",
MAX(aggr."Flag_ActSuspect_Influence_TouchPoint_by_AcquisitionChannelTopLevel_Native") AS "Flag_ActSuspect_Influence_TouchPoint_by_AcquisitionChannelTopLevel_Native",
MAX(aggr."Flag_ActSuspect_Influence_TouchPoint_by_AcquisitionChannelTopLevel_OrganicSearch") AS "Flag_ActSuspect_Influence_TouchPoint_by_AcquisitionChannelTopLevel_OrganicSearch",
MAX(aggr."Flag_ActSuspect_Influence_TouchPoint_by_AcquisitionChannelTopLevel_OrganicSocial") AS "Flag_ActSuspect_Influence_TouchPoint_by_AcquisitionChannelTopLevel_OrganicSocial",
MAX(aggr."Flag_ActSuspect_Influence_TouchPoint_by_AcquisitionChannelTopLevel_Other") AS "Flag_ActSuspect_Influence_TouchPoint_by_AcquisitionChannelTopLevel_Other",
MAX(aggr."Flag_ActSuspect_Influence_TouchPoint_by_AcquisitionChannelTopLevel_PaidMedia") AS "Flag_ActSuspect_Influence_TouchPoint_by_AcquisitionChannelTopLevel_PaidMedia",
MAX(aggr."Flag_ActSuspect_Influence_TouchPoint_by_AcquisitionChannelTopLevel_PaidSearch") AS "Flag_ActSuspect_Influence_TouchPoint_by_AcquisitionChannelTopLevel_PaidSearch",
MAX(aggr."Flag_ActSuspect_Influence_TouchPoint_by_AcquisitionChannelTopLevel_PaidSocial") AS "Flag_ActSuspect_Influence_TouchPoint_by_AcquisitionChannelTopLevel_PaidSocial",
MAX(aggr."Flag_ActSuspect_Influence_TouchPoint_by_AcquisitionChannelTopLevel_Podcast") AS "Flag_ActSuspect_Influence_TouchPoint_by_AcquisitionChannelTopLevel_Podcast",
MAX(aggr."Flag_ActSuspect_Influence_TouchPoint_by_AcquisitionChannelTopLevel_PPL") AS "Flag_ActSuspect_Influence_TouchPoint_by_AcquisitionChannelTopLevel_PPL",
MAX(aggr."Flag_ActSuspect_Influence_TouchPoint_by_AcquisitionChannelTopLevel_Print") AS "Flag_ActSuspect_Influence_TouchPoint_by_AcquisitionChannelTopLevel_Print",
MAX(aggr."Flag_ActSuspect_Influence_TouchPoint_by_AcquisitionChannelTopLevel_SponsoredEmail") AS "Flag_ActSuspect_Influence_TouchPoint_by_AcquisitionChannelTopLevel_SponsoredEmail",
MAX(aggr."Flag_ActSuspect_Influence_TouchPoint_by_AcquisitionChannelTopLevel_Tradeshow") AS "Flag_ActSuspect_Influence_TouchPoint_by_AcquisitionChannelTopLevel_Tradeshow",
MAX(aggr."Flag_ActSuspect_Influence_TouchPoint_by_AcquisitionChannelTopLevel_Web Referral") AS "Flag_ActSuspect_Influence_TouchPoint_by_AcquisitionChannelTopLevel_Web Referral",
MAX(aggr."Flag_ActSuspect_Influence_TouchPoint_by_AcquisitionChannelTopLevel_Webinar") AS "Flag_ActSuspect_Influence_TouchPoint_by_AcquisitionChannelTopLevel_Webinar",

MAX(aggr."Flag_ActProspect_Influence_TouchPoint_by_AcquisitionChannelTopLevel_ChannelReferral") AS "Flag_ActProspect_Influence_TouchPoint_by_AcquisitionChannelTopLevel_ChannelReferral",
MAX(aggr."Flag_ActProspect_Influence_TouchPoint_by_AcquisitionChannelTopLevel_ContentSyndication") AS "Flag_ActProspect_Influence_TouchPoint_by_AcquisitionChannelTopLevel_ContentSyndication",
MAX(aggr."Flag_ActProspect_Influence_TouchPoint_by_AcquisitionChannelTopLevel_SalesEngagement") AS "Flag_ActProspect_Influence_TouchPoint_by_AcquisitionChannelTopLevel_SalesEngagement",
MAX(aggr."Flag_ActProspect_Influence_TouchPoint_by_AcquisitionChannelTopLevel_Direct") AS "Flag_ActProspect_Influence_TouchPoint_by_AcquisitionChannelTopLevel_Direct",
MAX(aggr."Flag_ActProspect_Influence_TouchPoint_by_AcquisitionChannelTopLevel_DirectMail") AS "Flag_ActProspect_Influence_TouchPoint_by_AcquisitionChannelTopLevel_DirectMail",
MAX(aggr."Flag_ActProspect_Influence_TouchPoint_by_AcquisitionChannelTopLevel_Display") AS "Flag_ActProspect_Influence_TouchPoint_by_AcquisitionChannelTopLevel_Display",
MAX(aggr."Flag_ActProspect_Influence_TouchPoint_by_AcquisitionChannelTopLevel_Email") AS "Flag_ActProspect_Influence_TouchPoint_by_AcquisitionChannelTopLevel_Email",
MAX(aggr."Flag_ActProspect_Influence_TouchPoint_by_AcquisitionChannelTopLevel_LeadReferral") AS "Flag_ActProspect_Influence_TouchPoint_by_AcquisitionChannelTopLevel_LeadReferral",
MAX(aggr."Flag_ActProspect_Influence_TouchPoint_by_AcquisitionChannelTopLevel_LiveEvent") AS "Flag_ActProspect_Influence_TouchPoint_by_AcquisitionChannelTopLevel_LiveEvent",
MAX(aggr."Flag_ActProspect_Influence_TouchPoint_by_AcquisitionChannelTopLevel_Lytx") AS "Flag_ActProspect_Influence_TouchPoint_by_AcquisitionChannelTopLevel_Lytx",
MAX(aggr."Flag_ActProspect_Influence_TouchPoint_by_AcquisitionChannelTopLevel_Native") AS "Flag_ActProspect_Influence_TouchPoint_by_AcquisitionChannelTopLevel_Native",
MAX(aggr."Flag_ActProspect_Influence_TouchPoint_by_AcquisitionChannelTopLevel_OrganicSearch") AS "Flag_ActProspect_Influence_TouchPoint_by_AcquisitionChannelTopLevel_OrganicSearch",
MAX(aggr."Flag_ActProspect_Influence_TouchPoint_by_AcquisitionChannelTopLevel_OrganicSocial") AS "Flag_ActProspect_Influence_TouchPoint_by_AcquisitionChannelTopLevel_OrganicSocial",
MAX(aggr."Flag_ActProspect_Influence_TouchPoint_by_AcquisitionChannelTopLevel_Other") AS "Flag_ActProspect_Influence_TouchPoint_by_AcquisitionChannelTopLevel_Other",
MAX(aggr."Flag_ActProspect_Influence_TouchPoint_by_AcquisitionChannelTopLevel_PaidMedia") AS "Flag_ActProspect_Influence_TouchPoint_by_AcquisitionChannelTopLevel_PaidMedia",
MAX(aggr."Flag_ActProspect_Influence_TouchPoint_by_AcquisitionChannelTopLevel_PaidSearch") AS "Flag_ActProspect_Influence_TouchPoint_by_AcquisitionChannelTopLevel_PaidSearch",
MAX(aggr."Flag_ActProspect_Influence_TouchPoint_by_AcquisitionChannelTopLevel_PaidSocial") AS "Flag_ActProspect_Influence_TouchPoint_by_AcquisitionChannelTopLevel_PaidSocial",
MAX(aggr."Flag_ActProspect_Influence_TouchPoint_by_AcquisitionChannelTopLevel_Podcast") AS "Flag_ActProspect_Influence_TouchPoint_by_AcquisitionChannelTopLevel_Podcast",
MAX(aggr."Flag_ActProspect_Influence_TouchPoint_by_AcquisitionChannelTopLevel_PPL") AS "Flag_ActProspect_Influence_TouchPoint_by_AcquisitionChannelTopLevel_PPL",
MAX(aggr."Flag_ActProspect_Influence_TouchPoint_by_AcquisitionChannelTopLevel_Print") AS "Flag_ActProspect_Influence_TouchPoint_by_AcquisitionChannelTopLevel_Print",
MAX(aggr."Flag_ActProspect_Influence_TouchPoint_by_AcquisitionChannelTopLevel_SponsoredEmail") AS "Flag_ActProspect_Influence_TouchPoint_by_AcquisitionChannelTopLevel_SponsoredEmail",
MAX(aggr."Flag_ActProspect_Influence_TouchPoint_by_AcquisitionChannelTopLevel_Tradeshow") AS "Flag_ActProspect_Influence_TouchPoint_by_AcquisitionChannelTopLevel_Tradeshow",
MAX(aggr."Flag_ActProspect_Influence_TouchPoint_by_AcquisitionChannelTopLevel_Web Referral") AS "Flag_ActProspect_Influence_TouchPoint_by_AcquisitionChannelTopLevel_Web Referral",
MAX(aggr."Flag_ActProspect_Influence_TouchPoint_by_AcquisitionChannelTopLevel_Webinar") AS "Flag_ActProspect_Influence_TouchPoint_by_AcquisitionChannelTopLevel_Webinar",

MAX(aggr."Flag_Has_TouchPoint_by_AcquisitionChannelTopLevel_ChannelReferral") AS "Flag_Has_TouchPoint_by_AcquisitionChannelTopLevel_ChannelReferral",
MAX(aggr."Flag_Has_TouchPoint_by_AcquisitionChannelTopLevel_ContentSyndication") AS "Flag_Has_TouchPoint_by_AcquisitionChannelTopLevel_ContentSyndication",
MAX(aggr."Flag_Has_TouchPoint_by_AcquisitionChannelTopLevel_SalesEngagement") AS "Flag_Has_TouchPoint_by_AcquisitionChannelTopLevel_SalesEngagement",
MAX(aggr."Flag_Has_TouchPoint_by_AcquisitionChannelTopLevel_Direct") AS "Flag_Has_TouchPoint_by_AcquisitionChannelTopLevel_Direct",
MAX(aggr."Flag_Has_TouchPoint_by_AcquisitionChannelTopLevel_DirectMail") AS "Flag_Has_TouchPoint_by_AcquisitionChannelTopLevel_DirectMail",
MAX(aggr."Flag_Has_TouchPoint_by_AcquisitionChannelTopLevel_Display") AS "Flag_Has_TouchPoint_by_AcquisitionChannelTopLevel_Display",
MAX(aggr."Flag_Has_TouchPoint_by_AcquisitionChannelTopLevel_Email") AS "Flag_Has_TouchPoint_by_AcquisitionChannelTopLevel_Email",
MAX(aggr."Flag_Has_TouchPoint_by_AcquisitionChannelTopLevel_LeadReferral") AS "Flag_Has_TouchPoint_by_AcquisitionChannelTopLevel_LeadReferral",
MAX(aggr."Flag_Has_TouchPoint_by_AcquisitionChannelTopLevel_LiveEvent") AS "Flag_Has_TouchPoint_by_AcquisitionChannelTopLevel_LiveEvent",
MAX(aggr."Flag_Has_TouchPoint_by_AcquisitionChannelTopLevel_Lytx") AS "Flag_Has_TouchPoint_by_AcquisitionChannelTopLevel_Lytx",
MAX(aggr."Flag_Has_TouchPoint_by_AcquisitionChannelTopLevel_Native") AS "Flag_Has_TouchPoint_by_AcquisitionChannelTopLevel_Native",
MAX(aggr."Flag_Has_TouchPoint_by_AcquisitionChannelTopLevel_OrganicSearch") AS "Flag_Has_TouchPoint_by_AcquisitionChannelTopLevel_OrganicSearch",
MAX(aggr."Flag_Has_TouchPoint_by_AcquisitionChannelTopLevel_OrganicSocial") AS "Flag_Has_TouchPoint_by_AcquisitionChannelTopLevel_OrganicSocial",
MAX(aggr."Flag_Has_TouchPoint_by_AcquisitionChannelTopLevel_Other") AS "Flag_Has_TouchPoint_by_AcquisitionChannelTopLevel_Other",
MAX(aggr."Flag_Has_TouchPoint_by_AcquisitionChannelTopLevel_PaidMedia") AS "Flag_Has_TouchPoint_by_AcquisitionChannelTopLevel_PaidMedia",
MAX(aggr."Flag_Has_TouchPoint_by_AcquisitionChannelTopLevel_PaidSearch") AS "Flag_Has_TouchPoint_by_AcquisitionChannelTopLevel_PaidSearch",
MAX(aggr."Flag_Has_TouchPoint_by_AcquisitionChannelTopLevel_PaidSocial") AS "Flag_Has_TouchPoint_by_AcquisitionChannelTopLevel_PaidSocial",
MAX(aggr."Flag_Has_TouchPoint_by_AcquisitionChannelTopLevel_Podcast") AS "Flag_Has_TouchPoint_by_AcquisitionChannelTopLevel_Podcast",
MAX(aggr."Flag_Has_TouchPoint_by_AcquisitionChannelTopLevel_PPL") AS "Flag_Has_TouchPoint_by_AcquisitionChannelTopLevel_PPL",
MAX(aggr."Flag_Has_TouchPoint_by_AcquisitionChannelTopLevel_Print") AS "Flag_Has_TouchPoint_by_AcquisitionChannelTopLevel_Print",
MAX(aggr."Flag_Has_TouchPoint_by_AcquisitionChannelTopLevel_SponsoredEmail") AS "Flag_Has_TouchPoint_by_AcquisitionChannelTopLevel_SponsoredEmail",
MAX(aggr."Flag_Has_TouchPoint_by_AcquisitionChannelTopLevel_Tradeshow") AS "Flag_Has_TouchPoint_by_AcquisitionChannelTopLevel_Tradeshow",
MAX(aggr."Flag_Has_TouchPoint_by_AcquisitionChannelTopLevel_Web Referral") AS "Flag_Has_TouchPoint_by_AcquisitionChannelTopLevel_Web Referral",
MAX(aggr."Flag_Has_TouchPoint_by_AcquisitionChannelTopLevel_Webinar") AS "Flag_Has_TouchPoint_by_AcquisitionChannelTopLevel_Webinar",
-- Account Lifecycle Info
aggr.ACTLFC_act_journey_path,
aggr.ACTLFC_act_journey_path_cnt,
aggr.ACTLFC_act_journey_path_id,
aggr.ACTLFC_OPP_CUSTOMER_RELATIONSHIP,
aggr.ACTLFC_SUSPECT_OPP_RELATIONSHIP,
aggr.ACTLFC_SUSPECT_CUSTOMER_RELATIONSHIP,
aggr.ACTLFC_MQA_SUSPECT_RELATIONSHIP,
aggr.ACTLFC_MQA_OPP_RELATIONSHIP,
aggr.ACTLFC_MQA_CUSTOMER_RELATIONSHIP,
aggr.ACTLFC_MEA_SUSPECT_RELATIONSHIP,
aggr.ACTLFC_MEA_OPP_RELATIONSHIP,
aggr.ACTLFC_MEA_CUSTOMER_RELATIONSHIP,
aggr.ACTLFC_COLD_SUSPECT_RELATIONSHIP,
aggr.ACTLFC_COLD_OPP_RELATIONSHIP,
aggr.ACTLFC_COLD_CUSTOMER_RELATIONSHIP,
aggr.ACTLFC_MUTUALLY_EXCLUSIVE_PRE_SUSPECT_DESIGNATION,
aggr.ACTLFC_MUTUALLY_EXCLUSIVE_PRE_SUSPECT_DESIGNATION_DATE,
aggr.ACTLFC_MUTUALLY_EXCLUSIVE_PRE_OPP_DESIGNATION,
aggr.ACTLFC_MUTUALLY_EXCLUSIVE_PRE_OPP_DESIGNATION_DATE,
aggr.ACTLFC_COLD_ACCOUNT_DATE_STAMP__C,
aggr.ACTLFC_COLD_ACCOUNT_DATE_STAMP__C_CAST,
aggr.ACTLFC_cold_account_date_eow,
aggr.ACTLFC_cold_account_date_eom,
aggr.ACTLFC_cold_account_date_eoq,
aggr.ACTLFC_cold_account_date_eoy,
aggr.ACTLFC_MEA_DATE_STAMP__C,
aggr.ACTLFC_MEA_DATE_STAMP__C_CAST,
aggr.ACTLFC_mea_date_eow,
aggr.ACTLFC_mea_date_eom,
aggr.ACTLFC_mea_date_eoq,
aggr.ACTLFC_mea_date_eoy,
aggr.ACTLFC_MQA_DATE_STAMP__C,
aggr.ACTLFC_MQA_DATE_STAMP__C_CAST,
aggr.ACTLFC_mqa_date_eow,
aggr.ACTLFC_mqa_date_eom,
aggr.ACTLFC_mqa_date_eoq,
aggr.ACTLFC_mqa_date_eoy,
aggr.ACTLFC_SUSPECT_DATE_STAMP__C,
aggr.ACTLFC_SUSPECT_DATE_STAMP__C_CAST,
aggr.ACTLFC_suspect_date_eow,
aggr.ACTLFC_suspect_date_eom,
aggr.ACTLFC_suspect_date_eoq,
aggr.ACTLFC_suspect_date_eoy,
aggr.ACTLFC_SUSPECT_WORKING_DATE_STAMP__C,
aggr.ACTLFC_SUSPECT_WORKING_DATE_STAMP__C_CAST,
aggr.ACTLFC_suspect_working_date_eow,
aggr.ACTLFC_suspect_working_date_eom,
aggr.ACTLFC_suspect_working_date_eoq,
aggr.ACTLFC_suspect_working_date_eoy,
aggr.ACTLFC_PROSPECT_DATE_STAMP__C,
aggr.ACTLFC_PROSPECT_DATE_STAMP__C_CAST,
aggr.ACTLFC_prospect_date_eow,
aggr.ACTLFC_prospect_date_eom,
aggr.ACTLFC_prospect_date_eoq,
aggr.ACTLFC_prospect_date_eoy,
aggr.ACTLFC_CUSTOMER_DATE_STAMP__C,
aggr.ACTLFC_CUSTOMER_DATE_STAMP__C_CAST,
aggr.ACTLFC_customer_date_eow,
aggr.ACTLFC_customer_date_eom,
aggr.ACTLFC_customer_date_eoq,
aggr.ACTLFC_customer_date_eoy,
aggr.ACTLFC_RECYCLED_DATE_STAMP__C,
aggr.ACTLFC_RECYCLED_DATE_STAMP__C_CAST,
aggr.ACTLFC_recycled_date_eow,
aggr.ACTLFC_recycled_date_eom,
aggr.ACTLFC_recycled_date_eoq,
aggr.ACTLFC_recycled_date_eoy,
aggr.ACTLFC_UNQUALIFIED_DATE_STAMP__C,
aggr.ACTLFC_UNQUALIFIED_DATE_STAMP__C_CAST,
aggr.ACTLFC_unqualified_date_eow,
aggr.ACTLFC_unqualified_date_eom,
aggr.ACTLFC_unqualified_date_eoq,
aggr.ACTLFC_unqualified_date_eoy,
aggr.ACTLFC_recycled_vs_new_flag,
aggr.ACTLFC_flag_has_marketing_lifecycle_at_suspect__c,
aggr.ACTLFC_account_lifecycle_cold_flag,
aggr.ACTLFC_account_lifecycle_mea_flag,
aggr.ACTLFC_account_lifecycle_mqa_flag,
aggr.ACTLFC_account_lifecycle_suspect_flag,
aggr.ACTLFC_account_lifecycle_suspect_working_flag,
aggr.ACTLFC_account_lifecycle_prospect_flag,
aggr.ACTLFC_account_lifecycle_customer_flag,
aggr.ACTLFC_account_lifecycle_recycled_flag,
aggr.ACTLFC_account_lifecycle_unqualified_flag,
aggr.ACTLFC_account_journey_path_lifecycle_nonlinear_flag,
aggr.ACTLFC_account_journey_path_lifecycle_nonlinear_flag_reason,
aggr.ACTLFC_FLAG_to_check
-- Influence Detail Data
FROM
DP_PROD_DB.SALESFORCE_TEMP.influence_account_opportunity_detail_v1_5 as aggr
GROUP BY 1,2,3,4,5,6,7,8,9,10,11,12,13,14,15,16,17,18,19,20,21,22,23,24,25,26,27,28,29,30,31,32,33,34,35,36,37,38,39,40,41,42,43,44,45,46,47,48,49,50,51,52,53,
aggr.ACTLFC_act_journey_path,
aggr.ACTLFC_act_journey_path_cnt,
aggr.ACTLFC_act_journey_path_id,
aggr.ACTLFC_OPP_CUSTOMER_RELATIONSHIP,
aggr.ACTLFC_SUSPECT_OPP_RELATIONSHIP,
aggr.ACTLFC_SUSPECT_CUSTOMER_RELATIONSHIP,
aggr.ACTLFC_MQA_SUSPECT_RELATIONSHIP,
aggr.ACTLFC_MQA_OPP_RELATIONSHIP,
aggr.ACTLFC_MQA_CUSTOMER_RELATIONSHIP,
aggr.ACTLFC_MEA_SUSPECT_RELATIONSHIP,
aggr.ACTLFC_MEA_OPP_RELATIONSHIP,
aggr.ACTLFC_MEA_CUSTOMER_RELATIONSHIP,
aggr.ACTLFC_COLD_SUSPECT_RELATIONSHIP,
aggr.ACTLFC_COLD_OPP_RELATIONSHIP,
aggr.ACTLFC_COLD_CUSTOMER_RELATIONSHIP,
aggr.ACTLFC_MUTUALLY_EXCLUSIVE_PRE_SUSPECT_DESIGNATION,
aggr.ACTLFC_MUTUALLY_EXCLUSIVE_PRE_SUSPECT_DESIGNATION_DATE,
aggr.ACTLFC_MUTUALLY_EXCLUSIVE_PRE_OPP_DESIGNATION,
aggr.ACTLFC_MUTUALLY_EXCLUSIVE_PRE_OPP_DESIGNATION_DATE,
aggr.ACTLFC_COLD_ACCOUNT_DATE_STAMP__C,
aggr.ACTLFC_COLD_ACCOUNT_DATE_STAMP__C_CAST,
aggr.ACTLFC_cold_account_date_eow,
aggr.ACTLFC_cold_account_date_eom,
aggr.ACTLFC_cold_account_date_eoq,
aggr.ACTLFC_cold_account_date_eoy,
aggr.ACTLFC_MEA_DATE_STAMP__C,
aggr.ACTLFC_MEA_DATE_STAMP__C_CAST,
aggr.ACTLFC_mea_date_eow,
aggr.ACTLFC_mea_date_eom,
aggr.ACTLFC_mea_date_eoq,
aggr.ACTLFC_mea_date_eoy,
aggr.ACTLFC_MQA_DATE_STAMP__C,
aggr.ACTLFC_MQA_DATE_STAMP__C_CAST,
aggr.ACTLFC_mqa_date_eow,
aggr.ACTLFC_mqa_date_eom,
aggr.ACTLFC_mqa_date_eoq,
aggr.ACTLFC_mqa_date_eoy,
aggr.ACTLFC_SUSPECT_DATE_STAMP__C,
aggr.ACTLFC_SUSPECT_DATE_STAMP__C_CAST,
aggr.ACTLFC_suspect_date_eow,
aggr.ACTLFC_suspect_date_eom,
aggr.ACTLFC_suspect_date_eoq,
aggr.ACTLFC_suspect_date_eoy,
aggr.ACTLFC_SUSPECT_WORKING_DATE_STAMP__C,
aggr.ACTLFC_SUSPECT_WORKING_DATE_STAMP__C_CAST,
aggr.ACTLFC_suspect_working_date_eow,
aggr.ACTLFC_suspect_working_date_eom,
aggr.ACTLFC_suspect_working_date_eoq,
aggr.ACTLFC_suspect_working_date_eoy,
aggr.ACTLFC_PROSPECT_DATE_STAMP__C,
aggr.ACTLFC_PROSPECT_DATE_STAMP__C_CAST,
aggr.ACTLFC_prospect_date_eow,
aggr.ACTLFC_prospect_date_eom,
aggr.ACTLFC_prospect_date_eoq,
aggr.ACTLFC_prospect_date_eoy,
aggr.ACTLFC_CUSTOMER_DATE_STAMP__C,
aggr.ACTLFC_CUSTOMER_DATE_STAMP__C_CAST,
aggr.ACTLFC_customer_date_eow,
aggr.ACTLFC_customer_date_eom,
aggr.ACTLFC_customer_date_eoq,
aggr.ACTLFC_customer_date_eoy,
aggr.ACTLFC_RECYCLED_DATE_STAMP__C,
aggr.ACTLFC_RECYCLED_DATE_STAMP__C_CAST,
aggr.ACTLFC_recycled_date_eow,
aggr.ACTLFC_recycled_date_eom,
aggr.ACTLFC_recycled_date_eoq,
aggr.ACTLFC_recycled_date_eoy,
aggr.ACTLFC_UNQUALIFIED_DATE_STAMP__C,
aggr.ACTLFC_UNQUALIFIED_DATE_STAMP__C_CAST,
aggr.ACTLFC_unqualified_date_eow,
aggr.ACTLFC_unqualified_date_eom,
aggr.ACTLFC_unqualified_date_eoq,
aggr.ACTLFC_unqualified_date_eoy,
aggr.ACTLFC_recycled_vs_new_flag,
aggr.ACTLFC_flag_has_marketing_lifecycle_at_suspect__c,
aggr.ACTLFC_account_lifecycle_cold_flag,
aggr.ACTLFC_account_lifecycle_mea_flag,
aggr.ACTLFC_account_lifecycle_mqa_flag,
aggr.ACTLFC_account_lifecycle_suspect_flag,
aggr.ACTLFC_account_lifecycle_suspect_working_flag,
aggr.ACTLFC_account_lifecycle_prospect_flag,
aggr.ACTLFC_account_lifecycle_customer_flag,
aggr.ACTLFC_account_lifecycle_recycled_flag,
aggr.ACTLFC_account_lifecycle_unqualified_flag,
aggr.ACTLFC_account_journey_path_lifecycle_nonlinear_flag,
aggr.ACTLFC_account_journey_path_lifecycle_nonlinear_flag_reason,
aggr.ACTLFC_FLAG_to_check)`
var sql_tbl_07 = snowflake.createStatement({sqlText: cmd2});

// seprated tables
// touchtype_6sense_paidmedia table_01

var table_01=`create or replace table DP_PROD_DB.SALESFORCE_TEMP.touchtype_6sense_paidmedia_v1_5 as select * from (
SELECT
''6Sense - Paid Media'' AS "Marketing_Touch_Type_DATA_SOURCE",
abm_pd.CRM_ACCOUNT_ID,
abm_pd.DATE AS Marketing_TouchPoint_Date,
CASE
WHEN (abm_pd.IMPRESSIONS > 0 AND abm_pd.CLICKS > 0) THEN ''Impression and Ad Click''
WHEN (abm_pd.IMPRESSIONS > 0 AND abm_pd.CLICKS = 0) THEN ''Impression''
WHEN (abm_pd.IMPRESSIONS = 0 AND abm_pd.CLICKS > 0) THEN ''Ad Click''
END AS "Marketing_Touch_Type",
CASE
WHEN (abm_pd.IMPRESSIONS > 0 AND abm_pd.CLICKS > 0) THEN (abm_pd.IMPRESSIONS + abm_pd.CLICKS)
WHEN (abm_pd.IMPRESSIONS > 0 AND abm_pd.CLICKS = 0) THEN abm_pd.IMPRESSIONS
WHEN (abm_pd.IMPRESSIONS = 0 AND abm_pd.CLICKS > 0) THEN abm_pd.CLICKS
END AS "Marketing_Touch_Type_Count",
NULL AS "InteractionType_Bizible_TouchPoint_WebVisit_Count",
NULL AS "InteractionType_Bizible_TouchPoint_WebChat_Count",
NULL AS "InteractionType_Bizible_TouchPoint_WebForm_Count",
NULL AS "InteractionType_Bizible_TouchPoint_CRM_Count",
NULL AS "InteractionType_Bizible_TouchPoint_ConnectwithDM_Count",
NULL AS "InteractionType_Bizible_TouchPoint_CallSpokeWith_Count",
NULL AS "InteractionType_Bizible_TouchPoint_CallGatekeeper_Count",
NULL AS "InteractionType_Bizible_TouchPoint_NoLeadTouchPoints_Count",
NULL AS "InteractionType_Bizible_TouchPoint_Unclassified_Count",
abm_pd.IMPRESSIONS AS "InteractionType_6Sense_PaidMedia_Impressions_Count",
abm_pd.CLICKS AS "InteractionType_6Sense_PaidMedia_Clicks_Count",
NULL AS "InteractionType_6Sense_WebVisit_PageLoad_Count",
NULL AS "InteractionType_6Sense_WebVisit_Play_Count",
NULL AS "InteractionType_6Sense_WebVisit_Click_Count",
NULL AS "InteractionType_6Sense_WebVisit_Submit_Count",
NULL AS "InteractionType_6Sense_WebVisit_Unclassified_Count",
CASE
WHEN "AD_VENDOR" = ''6Sense - Media'' THEN ''Display.6Sense''
WHEN "AD_VENDOR" = ''6Sense - External'' THEN ''Display.6Sense.External''
WHEN "AD_VENDOR" = ''6Sense - LinkedIn'' THEN ''Paid Social.6Sense.LinkedIn''
END  AS "Acquisition_Channel",
''6sense'' AS "Acquisition_Web_Source",
CASE
WHEN "AD_VENDOR" = ''6Sense - Media'' THEN ''display''
WHEN "AD_VENDOR" = ''6Sense - External'' THEN ''display''
WHEN "AD_VENDOR" = ''6Sense - LinkedIn'' THEN ''paidsocial''
END  AS "Acquisition_Medium",
abm_pd."CAMPAIGN_NAME" AS "Acquisition_Campaign_Name",
''(not set)'' AS "Acquisition_Creative_Name",
''(not set)'' AS "Acquisition_Landing_Page",
''(not set)''  AS "Acquisition_Referrer"
FROM
(
SELECT
CRM_ACCOUNT_ID,
"AD_VENDOR","CAMPAIGN_ID","CAMPAIGN_NAME",
DATE,
SUM(ZEROIFNULL(IMPRESSIONS)) AS IMPRESSIONS,SUM(ZEROIFNULL(CLICKS)) AS CLICKS ,SUM(ZEROIFNULL(NEWLY_ENGAGED)) AS NEWLY_ENGAGED, SUM(ZEROIFNULL(INCREASED_ENGAGEMENT)) AS INCREASED_ENGAGEMENT,SUM(ZEROIFNULL(SPEND)) AS SPEND
FROM (
SELECT
RECORD_CREATION_TS,
CRM_ACCOUNT_ID,CRM_ACCOUNT_NAME,CRM_ACCOUNT_COUNTRY,CRM_ACCOUNT_DOMAIN,
"6SENSE_MID","6SENSE_ACCOUNT_NAME","6SENSE_ACCOUNT_COUNTRY","6SENSE_ACCOUNT_DOMAIN",
AD_ID,AD_NAME,AD_GROUP,
''6Sense - Media'' AS "AD_VENDOR","6SENSE_CAMPAIGN_ID" AS "CAMPAIGN_ID","6SENSE_CAMPAIGN_NAME" AS "CAMPAIGN_NAME",
DATE,
IMPRESSIONS,CLICKS,NEWLY_ENGAGED,INCREASED_ENGAGEMENT,SPEND
FROM DP_PROD_DB.SIX_SENSE.SIX_SENSE_MEDIA
UNION
SELECT
RECORD_CREATION_TS,
CRM_ACCOUNT_ID,CRM_ACCOUNT_NAME,CRM_ACCOUNT_COUNTRY,CRM_ACCOUNT_DOMAIN,
"6SENSE_MID","6SENSE_ACCOUNT_NAME","6SENSE_ACCOUNT_COUNTRY","6SENSE_ACCOUNT_DOMAIN",
AD_ID,AD_NAME,AD_GROUP,
''6Sense - LinkedIn'' AS "AD_VENDOR","LINKEDIN_CAMPAIGN_ID" AS "CAMPAIGN_ID","LINKEDIN_CAMPAIGN_NAME" AS "CAMPAIGN_NAME",
DATE,
IMPRESSIONS,CLICKS,NEWLY_ENGAGED,INCREASED_ENGAGEMENT,SPEND
FROM DP_PROD_DB.SIX_SENSE.LINKEDIN_MEDIA
UNION
SELECT
RECORD_CREATION_TS,
CRM_ACCOUNT_ID,CRM_ACCOUNT_NAME,CRM_ACCOUNT_COUNTRY,CRM_ACCOUNT_DOMAIN,
"6SENSE_MID","6SENSE_ACCOUNT_NAME","6SENSE_ACCOUNT_COUNTRY","6SENSE_ACCOUNT_DOMAIN",
"6SENSE_AD_ID" AS "AD_ID","6SENSE_AD_NAME" AS "AD_NAME",AD_GROUP,
''6Sense - External'' AS "AD_VENDOR","6SENSE_CAMPAIGN_ID" AS "CAMPAIGN_ID","6SENSE_CAMPAIGN_NAME" AS "CAMPAIGN_NAME",
DATE,
IMPRESSIONS,CLICKS,NEWLY_ENGAGED,INCREASED_ENGAGEMENT,NULL AS SPEND
FROM DP_PROD_DB.SIX_SENSE.EXTERNAL_MEDIA
) AS x
GROUP BY
CRM_ACCOUNT_ID,
"AD_VENDOR","CAMPAIGN_ID","CAMPAIGN_NAME",
DATE,LAST_DAY(DATE,''month''),LAST_DAY(DATE,''quarter'')
HAVING (SUM(ZEROIFNULL(IMPRESSIONS)) + SUM(ZEROIFNULL(CLICKS))) > 0
ORDER BY LAST_DAY(DATE,''month'') DESC
) as abm_pd )`

var sql_tbl_01 = snowflake.createStatement({sqlText: table_01});

// touchtype_6sense_webvisit table_02

var table_02=`create or replace table DP_PROD_DB.SALESFORCE_TEMP.touchtype_6sense_webvisit_v1_5 as select * from (
SELECT
''6Sense - Web Visit'' AS "Marketing_Touch_Type_DATA_SOURCE",
abm_webv.CRM_ACCOUNT_ID,
abm_webv.DATE_VISITED AS Marketing_TouchPoint_Date,
CASE
WHEN (ZEROIFNULL(abm_webv.Total_a_pageload) > 0 AND ((ZEROIFNULL(Total_play) + ZEROIFNULL(Total_click) + ZEROIFNULL(Total_submit) > 0))) THEN ''Web Visit and Interaction''
WHEN (ZEROIFNULL(abm_webv.Total_a_pageload) = 0 AND ((ZEROIFNULL(Total_play) + ZEROIFNULL(Total_click) + ZEROIFNULL(Total_submit) > 0))) THEN ''Interaction''
WHEN (ZEROIFNULL(abm_webv.Total_a_pageload) > 0 AND ((ZEROIFNULL(Total_play) + ZEROIFNULL(Total_click) + ZEROIFNULL(Total_submit) = 0))) THEN ''Web Visit''
WHEN (ZEROIFNULL(abm_webv.Total_a_pageload)) > 0 THEN ''Web Visit''
WHEN (ZEROIFNULL(abm_webv.Total_unclassified)) > 0 THEN ''Unclassified''
END AS "Marketing_Touch_Type",
CASE
WHEN (ZEROIFNULL(abm_webv.Total_a_pageload) > 0 AND ((ZEROIFNULL(Total_play) + ZEROIFNULL(Total_click) + ZEROIFNULL(Total_submit)) > 0)) THEN (ZEROIFNULL(abm_webv.Total_a_pageload) + (ZEROIFNULL(Total_play) + ZEROIFNULL(Total_click) + ZEROIFNULL(Total_submit)))
WHEN (ZEROIFNULL(abm_webv.Total_a_pageload) = 0 AND ((ZEROIFNULL(Total_play) + ZEROIFNULL(Total_click) + ZEROIFNULL(Total_submit)) > 0)) THEN (ZEROIFNULL(Total_play) + ZEROIFNULL(Total_click) + ZEROIFNULL(Total_submit))
WHEN (ZEROIFNULL(abm_webv.Total_a_pageload) > 0 AND ((ZEROIFNULL(Total_play) + ZEROIFNULL(Total_click) + ZEROIFNULL(Total_submit)) = 0)) THEN abm_webv.Total_a_pageload
WHEN (ZEROIFNULL(abm_webv.Total_a_pageload)) > 0 THEN abm_webv.Total_a_pageload
WHEN (ZEROIFNULL(abm_webv.Total_unclassified)) > 0 THEN abm_webv.Total_unclassified
END AS "Marketing_Touch_Type_Count",
NULL AS "InteractionType_Bizible_TouchPoint_WebVisit_Count",
NULL AS "InteractionType_Bizible_TouchPoint_WebChat_Count",
NULL AS "InteractionType_Bizible_TouchPoint_WebForm_Count",
NULL AS "InteractionType_Bizible_TouchPoint_CRM_Count",
NULL AS "InteractionType_Bizible_TouchPoint_ConnectwithDM_Count",
NULL AS "InteractionType_Bizible_TouchPoint_CallSpokeWith_Count",
NULL AS "InteractionType_Bizible_TouchPoint_CallGatekeeper_Count",
NULL AS "InteractionType_Bizible_TouchPoint_NoLeadTouchPoints_Count",
NULL AS "InteractionType_Bizible_TouchPoint_Unclassified_Count",
NULL AS "InteractionType_6Sense_PaidMedia_Impressions_Count",
NULL AS "InteractionType_6Sense_PaidMedia_Clicks_Count",
ZEROIFNULL(abm_webv.Total_a_pageload) AS "InteractionType_6Sense_WebVisit_PageLoad_Count",
ZEROIFNULL(abm_webv.Total_play) AS "InteractionType_6Sense_WebVisit_Play_Count",
ZEROIFNULL(abm_webv.Total_click) AS "InteractionType_6Sense_WebVisit_Click_Count",
ZEROIFNULL(abm_webv.Total_submit) AS "InteractionType_6Sense_WebVisit_Submit_Count",
ZEROIFNULL(abm_webv.Total_unclassified) AS "InteractionType_6Sense_WebVisit_Unclassified_Count",
CASE
-- 6Sense
WHEN UTM_SOURCE = ''6sense'' and UTM_MEDIUM IN (''cpc'',''display'',''ppc'') THEN ''Display.6Sense''
WHEN UTM_SOURCE = ''6sense'' THEN ''Display.6Sense.External''
-- google
WHEN UTM_SOURCE = ''google'' and UTM_MEDIUM IN (''cpc'',''ppc'',''cpcignore'',''pc'') THEN ''Paid Search.Google''
WHEN UTM_SOURCE = ''google'' and UTM_MEDIUM IN (''display'',''banner'') THEN ''Display.Google''
WHEN UTM_SOURCE = ''google'' and UTM_MEDIUM IS NULL THEN ''Organic Search.Google''
WHEN UTM_SOURCE = ''google'' and UTM_MEDIUM IS NOT NULL THEN ''Paid Search.Google''
WHEN UTM_SOURCE IN (''adwords'',''marketingplatformgooglecom'') THEN ''Paid Search.Google''
-- youtube
WHEN UTM_SOURCE = ''youtube'' and UTM_MEDIUM IN (''cpc'') THEN CONCAT_WS(''.'',''Paid Search'',"UTM_SOURCE")
WHEN UTM_SOURCE = ''youtube'' and UTM_MEDIUM IN (''paidsocial'') THEN CONCAT_WS(''.'',''Paid Social'',"UTM_SOURCE")
WHEN UTM_SOURCE = ''youtube'' and UTM_MEDIUM IN (''social'',''referral'') THEN ''Organic Social.Youtube''
WHEN UTM_SOURCE = ''youtube'' THEN ''Organic Social.Youtube''
-- bing
WHEN UTM_SOURCE = ''bing'' and UTM_MEDIUM IN (''cpc'',''ppc'',''cpcignore'',''pc'') THEN ''Paid Search.Bing''
WHEN UTM_SOURCE = ''bing'' and UTM_MEDIUM IN (''display'',''banner'') THEN ''Display.Bing''
WHEN UTM_SOURCE = ''bing'' and UTM_MEDIUM IS NULL THEN ''Organic Search.Bing''
WHEN UTM_SOURCE = ''bing'' and UTM_MEDIUM IS NOT NULL THEN ''Paid Search.Bing''
-- yahoo
WHEN UTM_SOURCE = ''yahoo'' and UTM_MEDIUM IS NULL THEN ''Organic Search.Yahoo''
-- capterra
WHEN UTM_SOURCE = ''capterra'' and UTM_MEDIUM IN (''cpc'',''ppc'') THEN CONCAT_WS(''.'',''Paid Search'',"UTM_SOURCE")
-- facebook
WHEN UTM_SOURCE = ''facebook'' and UTM_MEDIUM IN (''paidsocial'',''cpc'') THEN ''Paid Social.Facebook''
WHEN UTM_SOURCE = ''facebook'' and UTM_MEDIUM IN (''social'',''referral'') THEN ''Organic Social.Facebook''
WHEN UTM_SOURCE = ''facebook'' or UTM_MEDIUM = ''facebook'' THEN ''Organic Social.Facebook''
-- twitter
WHEN UTM_SOURCE = ''twitter'' and UTM_MEDIUM IN (''paidsocial'',''cpc'') THEN ''Paid Social.Twitter''
WHEN UTM_SOURCE = ''twitter'' and UTM_MEDIUM IN (''social'',''referral'') THEN ''Organic Social.Twitter''
WHEN UTM_SOURCE = ''twitter'' or UTM_MEDIUM = ''twitter''  THEN ''Organic Social.Twitter''
-- linkedin
WHEN UTM_SOURCE = ''linkedin'' and UTM_MEDIUM IN (''paidsocial'',''cpc'') THEN ''Paid Social.LinkedIn''
WHEN UTM_SOURCE = ''linkedin'' and UTM_MEDIUM IN (''social'',''referral'') THEN ''Organic Social.LinkedIn''
WHEN UTM_SOURCE = ''linkedin'' or UTM_MEDIUM = ''linkedin'' THEN ''Organic Social.LinkedIn''
-- lytx
WHEN UTM_SOURCE = ''lytx'' and UTM_MEDIUM IN (''email'') THEN ''Email.Nurture''
WHEN UTM_SOURCE = ''lytx'' and UTM_MEDIUM IN (''newsletter'') THEN ''Email.Newsletter''
WHEN UTM_SOURCE = ''lytx'' and UTM_MEDIUM IN (''linkedin'',''twitter'',''facebook'',''socialnetwork'',''facebooklinkedin'') THEN ''Lytx.Social''
WHEN UTM_SOURCE = ''lytx'' and UTM_MEDIUM IN (''product'') THEN ''Lytx.Product''
WHEN UTM_SOURCE = ''lytx'' and UTM_MEDIUM IN (''pdf'',''ebook'') THEN ''Lytx.Resources''
WHEN UTM_SOURCE = ''lytx'' and UTM_MEDIUM IN (''chatbot'') THEN ''Lytx.ChatBot''
WHEN UTM_SOURCE = ''lytx'' THEN ''Lytx.Other''
WHEN UTM_SOURCE = ''lytxaccount'' and UTM_MEDIUM IN (''walkme'') THEN ''Lytx.WalkMe''
-- Direct
WHEN UTM_SOURCE IN (''direct'') THEN ''Direct''
-- Paid Search Other
WHEN UTM_MEDIUM IN (''cpc'',''ppc'') THEN CONCAT_WS(''.'',''Paid Search'',IFNULL("UTM_SOURCE",''Other''))
-- Display Other
WHEN UTM_MEDIUM IN (''display'',''cpm'',''paidcontent'',''displayl'') THEN CONCAT_WS(''.'',''Display'',IFNULL("UTM_SOURCE",''Other''))
-- Display Other
WHEN UTM_MEDIUM IN (''paidsocial'') THEN CONCAT_WS(''.'',''Paid Social'',IFNULL("UTM_SOURCE",''Other''))
-- Referral
WHEN UTM_MEDIUM IN (''referral'') THEN ''Web Referral''
-- Newsletter
WHEN UTM_MEDIUM IN (''newsletter'',''enewsletter'') THEN ''Email.Newsletter''
-- Email
WHEN UTM_MEDIUM IN (''email'',''organicemail'',''emailfollowup'',''sponsoredemail'',''eml'',''e-mail'',''hs-email'') THEN ''Email.Other''
-- Newsletter
WHEN UTM_MEDIUM IN (''webinar'') THEN ''Webinar''
-- Resources
WHEN UTM_MEDIUM IN (''epromo'') THEN CONCAT_WS(''.'',''Sponsored Email'',"UTM_SOURCE")
-- Print
WHEN UTM_MEDIUM IN (''print'') THEN ''Print.Other''
-- Resources
WHEN UTM_MEDIUM IN (''pdf'',''contentoffers'',''virtualhandout'') THEN ''Lytx.Resources''
-- DirectMail
WHEN UTM_MEDIUM IN (''directmail'') THEN ''Direct Mail''
-- Organic Social
WHEN UTM_MEDIUM IN (''social'') THEN ''Organic Social.Other''
-- Virtual Show
WHEN UTM_MEDIUM IN (''virtualshow'') THEN ''Tradeshow.Virtual''
-- Podcast
WHEN UTM_MEDIUM IN (''podcast'') THEN ''Podcast''
-- ChatBot
WHEN UTM_MEDIUM IN (''chatbot'') THEN ''Lytx.ChatBot''
-- Native
WHEN UTM_MEDIUM IN (''native'',''outbrain'') OR UTM_SOURCE IN (''taboola'') THEN ''Native''
-- ELSE
WHEN (UTM_SOURCE IS NULL and UTM_MEDIUM IS NULL) AND CONTAINS("REFERRER_DOMAIN",''google'') THEN ''Organic Search.Google''
WHEN (UTM_SOURCE IS NULL and UTM_MEDIUM IS NULL) AND CONTAINS("REFERRER_DOMAIN",''bing'') THEN ''Organic Search.Bing''
WHEN (UTM_SOURCE IS NULL and UTM_MEDIUM IS NULL) AND CONTAINS("REFERRER_DOMAIN",''yahoo'') THEN ''Organic Search.Yahoo''
WHEN (UTM_SOURCE IS NULL and UTM_MEDIUM IS NULL) AND CONTAINS("REFERRER_DOMAIN",''duckduckgo'') THEN ''Organic Search.DuckDuckGo''
WHEN (UTM_SOURCE IS NULL and UTM_MEDIUM IS NULL) AND CONTAINS("REFERRER_DOMAIN",''lytx'') THEN ''Lytx.Direct''
WHEN (UTM_SOURCE IS NULL and UTM_MEDIUM IS NULL) AND CONTAINS("REFERRER_DOMAIN",''rair'') THEN ''Lytx.Rair''
WHEN (UTM_SOURCE IS NULL and UTM_MEDIUM IS NULL) AND CONTAINS("REFERRER_DOMAIN",''drivecam'') THEN ''Lytx.Drivecam''
WHEN (UTM_SOURCE IS NULL and UTM_MEDIUM IS NULL) AND CONTAINS("REFERRER_DOMAIN",''infomail.drivecam.com'') THEN ''Email.Infomail''
WHEN (UTM_SOURCE IS NULL and UTM_MEDIUM IS NULL) AND CONTAINS("REFERRER_DOMAIN",''marketo.com'') THEN ''Email.Marketo''
WHEN (UTM_SOURCE IS NULL and UTM_MEDIUM IS NULL) AND CONTAINS("REFERRER_DOMAIN",''uberflip'') THEN ''Email.uberflip''
WHEN (UTM_SOURCE IS NULL and UTM_MEDIUM IS NULL) AND CONTAINS("REFERRER_DOMAIN",''linkedin'') THEN ''Organic Social.LinkedIn''
WHEN (UTM_SOURCE IS NULL and UTM_MEDIUM IS NULL) AND CONTAINS("REFERRER_DOMAIN",''facebook'') THEN ''Organic Social.Facebook''
WHEN (UTM_SOURCE IS NULL and UTM_MEDIUM IS NULL) AND CONTAINS("REFERRER_DOMAIN",''twitter'') THEN ''Organic Social.Twitter''
WHEN (UTM_SOURCE IS NULL and UTM_MEDIUM IS NULL) AND CONTAINS("REFERRER_DOMAIN",''asana'') THEN ''Web Referral.Asana''
WHEN (UTM_SOURCE IS NULL and UTM_MEDIUM IS NULL) AND CONTAINS("REFERRER_DOMAIN",''6sense'') THEN ''Web Referral.6Sense''
WHEN (UTM_SOURCE IS NULL and UTM_MEDIUM IS NULL) AND CONTAINS("REFERRER_DOMAIN",''clicktools'') THEN ''Web Referral.Clicktools''
WHEN (UTM_SOURCE IS NULL and UTM_MEDIUM IS NULL) AND CONTAINS("REFERRER_DOMAIN",''surfsight'') THEN ''Web Referral.Surfsight''
WHEN (UTM_SOURCE IS NULL and UTM_MEDIUM IS NULL) AND CONTAINS("REFERRER_DOMAIN",''force.com'') THEN ''Web Referral.Salesforce''
WHEN (UTM_SOURCE IS NULL and UTM_MEDIUM IS NULL) AND "REFERRER_DOMAIN" IS NULL THEN ''Direct''
WHEN (UTM_SOURCE IS NULL and UTM_MEDIUM IS NULL) AND "REFERRER_DOMAIN" IS NOT NULL THEN ''Web Referral.Misc''
WHEN (UTM_SOURCE IS NULL and UTM_MEDIUM IS NULL) THEN ''Other.NoInfo''
ELSE ''Other.Misc''
END AS "Acquisition_Channel",
abm_webv.UTM_SOURCE AS "Acquisition_Web_Source",
abm_webv.UTM_MEDIUM AS "Acquisition_Medium" ,
''(not set)'' AS "Acquisition_Campaign_Name",
''(not set)'' AS "Acquisition_Creative_Name",
"URL" AS "Acquisition_Landing_Page",
"REFERRER_DOMAIN" AS "Acquisition_Referrer"
FROM
(
SELECT
CRM_ACCOUNT_ID,DATE_VISITED,UTM_SOURCE,UTM_MEDIUM,"URL","REFERRER_DOMAIN",
SUM(ZEROIFNULL("Total_unclassified")) AS Total_unclassified,
SUM(ZEROIFNULL("Total_a_pageload")) AS Total_a_pageload,
SUM(ZEROIFNULL("Total_play")) AS Total_play,
SUM(ZEROIFNULL("Total_click")) AS Total_click,
SUM(ZEROIFNULL("Total_submit")) AS Total_submit
FROM
(
SELECT
pvt."RECORD_CREATION_TS",
pvt."CRM_ACCOUNT_ID",pvt."CRM_ACCOUNT_NAME",pvt."CRM_ACCOUNT_COUNTRY",pvt."CRM_ACCOUNT_DOMAIN",
pvt."""6SENSE_MID""" AS "6SENSE_MID",pvt."""6SENSE_ACCOUNT_NAME""" AS "6SENSE_ACCOUNT_NAME",pvt."""6SENSE_ACCOUNT_COUNTRY""" AS "6SENSE_ACCOUNT_COUNTRY",pvt."""6SENSE_ACCOUNT_DOMAIN""" AS "6SENSE_ACCOUNT_DOMAIN",
pvt."DATE_VISITED",
pvt."URL",pvt."REFERRER_DOMAIN",pvt."UTM_SOURCE",pvt."UTM_MEDIUM",
pvt."''unclassified''" as "Total_unclassified",
pvt."''a_pageload''" as "Total_a_pageload",
pvt."''play''" as "Total_play",
pvt."''click''" as "Total_click",
pvt."''submit''" as "Total_submit"
FROM
(
select *
from
(SELECT *
FROM DP_PROD_DB.SIX_SENSE.WEB_VISIT
--WHERE CRM_ACCOUNT_ID = ''001300000063Km9AAE''
)
PIVOT(SUM(TOTAL) FOR EVENT IN (''unclassified'',''a_pageload'',''play'',''click'',''submit'')) as p
ORDER BY "DATE_VISITED" DESC,"URL"
) as pvt
) AS X
GROUP BY CRM_ACCOUNT_ID,DATE_VISITED,UTM_SOURCE,UTM_MEDIUM,"URL","REFERRER_DOMAIN"
) as abm_webv   )`


var sql_tbl_02 = snowflake.createStatement({sqlText: table_02});



//touchtype_bizible_touchpoints table_03

var table_03=`create or replace table DP_PROD_DB.SALESFORCE_TEMP.touchtype_bizible_touchpoints_v1_5 as select * from ( SELECT
''Bizible'' AS "Marketing_Touch_Type_DATA_SOURCE",
biz_touchpoints.ACCOUNT_ID AS CRM_ACCOUNT_ID,
biz_touchpoints.TOUCHPOINT_DATE AS "Marketing_TouchPoint_Date",
biz_touchpoints."MARKETING_TOUCH_TYPE" AS "Marketing_Touch_Type",
biz_touchpoints."MARKETING_TOUCH_TYPE_COUNT" AS "Marketing_Touch_Type_Count",
CASE WHEN biz_touchpoints."MARKETING_TOUCH_TYPE" = ''Web Visit'' THEN "MARKETING_TOUCH_TYPE_COUNT" ELSE 0 END AS "InteractionType_Bizible_TouchPoint_WebVisit_Count",
CASE WHEN biz_touchpoints."MARKETING_TOUCH_TYPE" = ''Web Chat'' THEN "MARKETING_TOUCH_TYPE_COUNT" ELSE 0 END AS "InteractionType_Bizible_TouchPoint_WebChat_Count",
CASE WHEN biz_touchpoints."MARKETING_TOUCH_TYPE" = ''Web Form'' THEN "MARKETING_TOUCH_TYPE_COUNT" ELSE 0 END AS "InteractionType_Bizible_TouchPoint_WebForm_Count",
CASE WHEN biz_touchpoints."MARKETING_TOUCH_TYPE" = ''CRM'' THEN "MARKETING_TOUCH_TYPE_COUNT" ELSE 0 END AS "InteractionType_Bizible_TouchPoint_CRM_Count",
CASE WHEN biz_touchpoints."MARKETING_TOUCH_TYPE" = ''Connect with DM'' THEN "MARKETING_TOUCH_TYPE_COUNT" ELSE 0 END AS "InteractionType_Bizible_TouchPoint_ConnectwithDM_Count",
CASE WHEN biz_touchpoints."MARKETING_TOUCH_TYPE" = ''Call - Spoke With'' THEN "MARKETING_TOUCH_TYPE_COUNT" ELSE 0 END AS "InteractionType_Bizible_TouchPoint_CallSpokeWith_Count",
CASE WHEN biz_touchpoints."MARKETING_TOUCH_TYPE" = ''Call - Gatekeeper'' THEN "MARKETING_TOUCH_TYPE_COUNT" ELSE 0 END AS "InteractionType_Bizible_TouchPoint_CallGatekeeper_Count",
CASE WHEN biz_touchpoints."MARKETING_TOUCH_TYPE" = ''NO_LEAD_TOUCHPOINTS'' THEN "MARKETING_TOUCH_TYPE_COUNT" ELSE 0 END AS "InteractionType_Bizible_TouchPoint_NoLeadTouchPoints_Count",
CASE WHEN biz_touchpoints."MARKETING_TOUCH_TYPE" IS NULL THEN "MARKETING_TOUCH_TYPE_COUNT" ELSE 0 END AS "InteractionType_Bizible_TouchPoint_Unclassified_Count",
NULL AS "InteractionType_6Sense_PaidMedia_Impressions_Count",
NULL AS "InteractionType_6Sense_PaidMedia_Clicks_Count",
NULL AS "InteractionType_6Sense_WebVisit_PageLoad_Count",
NULL AS "InteractionType_6Sense_WebVisit_Play_Count",
NULL AS "InteractionType_6Sense_WebVisit_Click_Count",
NULL AS "InteractionType_6Sense_WebVisit_Submit_Count",
NULL AS "InteractionType_6Sense_WebVisit_Unclassified_Count",
CASE
-- CRM Actvity
--WHEN biz_touchpoints."WEB_SOURCE" = ''CRM Activity'' THEN CONCAT_WS(''.'',biz_touchpoints."WEB_SOURCE",biz_touchpoints."MEDIUM")
WHEN biz_touchpoints."WEB_SOURCE" = ''CRM Activity'' THEN CONCAT_WS(''.'',''Sales Engagement'',biz_touchpoints."MEDIUM")
-- Web Referral
WHEN biz_touchpoints."CHANNEL" IN (''Other'') AND biz_touchpoints."MEDIUM" = ''referral'' THEN ''Web Referral''
ELSE biz_touchpoints."CHANNEL" END AS "Acquisition_Channel",
biz_touchpoints."WEB_SOURCE" AS "Acquisition_Web_Source",
biz_touchpoints."MEDIUM" AS "Acquisition_Medium",
biz_touchpoints."CAMPAIGN_NAME" AS "Acquisition_Campaign_Name",
biz_touchpoints."CREATIVE_NAME" AS "Acquisition_Creative_Name",
biz_touchpoints."LANDING_PAGE" AS "Acquisition_Landing_Page",
biz_touchpoints."REFERRER_PAGE" AS "Acquisition_Referrer"
FROM
(SELECT ACCOUNT_ID,TOUCHPOINT_DATE,"MARKETING_TOUCH_TYPE",COUNT(ROW_KEY) AS "MARKETING_TOUCH_TYPE_COUNT",
"WEB_SOURCE","CHANNEL","MEDIUM","CAMPAIGN_NAME","CREATIVE_NAME","LANDING_PAGE","REFERRER_PAGE"
FROM BIZIBLE.PUBLIC.BIZ_TOUCHPOINTS as biz_touchpoints
WHERE ACCOUNT_ID IS NOT NULL
GROUP BY ACCOUNT_ID,TOUCHPOINT_DATE,"MARKETING_TOUCH_TYPE","WEB_SOURCE","CHANNEL","MEDIUM","CAMPAIGN_NAME","CREATIVE_NAME","LANDING_PAGE","REFERRER_PAGE"
) AS biz_touchpoints  )`


var sql_tbl_03 = snowflake.createStatement({sqlText: table_03});


//touchtype_analytics_table table_04

var table_04=`create or replace table DP_PROD_DB.SALESFORCE_TEMP.touchtype_analytics_table_v1_5 as select * from (
(select * from DP_PROD_DB.SALESFORCE_TEMP.touchtype_bizible_touchpoints_v1_5
union
select * from DP_PROD_DB.SALESFORCE_TEMP.touchtype_6sense_paidmedia_v1_5
union
select * from DP_PROD_DB.SALESFORCE_TEMP.touchtype_6sense_webvisit_v1_5))`

var sql_tbl_04 = snowflake.createStatement({sqlText: table_04});




// account_lifecycle_analytics_table  table_05

var table_05= `CREATE or replace TABLE DP_PROD_DB.SALESFORCE_TEMP.account_lifecycle_analytics_table_v1_5 as select * from(select *
from DP_PROD_DB.SALESFORCE_TEMP.act_lifecycle_temp_01_v1_5
)`

var sql_tbl_05 = snowflake.createStatement({sqlText: table_05});


// influence_account_opportunity_detail table_06

var table_06=`create or replace table DP_PROD_DB.SALESFORCE_TEMP.influence_account_opportunity_detail_v1_5 as select * from (
SELECT
-- To Reconcile with Salesforce Report User Interface
LEFT(opp.ID,15) AS OPP_ID_15,
LEFT(act.ID,15) AS ACT_ID_15,
-- ACCOUNT INFO
act.ID AS ACT_ID,act.NAME AS ACT_NAME,act.CREATED_DATE AS ACT_CREATED_DATE,act.WEBSITE,act.MARKET__C AS ACT_MARKET__C,act.MARKET_SEGMENT__C AS ACT_MARKET_SEGMENT__C,act.BUSINESS_UNIT_DIVISION__C AS ACT_BUSINESS_UNIT_DIVISION__C ,act.INDUSTRY as ACT_INDUSTRY,act.INDUSTRY_SECTOR__C AS ACT_INDUSTRY_SECTOR__C,act.NAICS_INDUSTRY_CODE__C AS ACT_NAICS_INDUSTRY_CODE__C,act.NAICS_DESCRIPTION__C AS ACT_NAICS_DESCRIPTION__C,act.FLEET_SIZE__C AS ACT_FLEET_SIZE__C,
-- Additional Account Info
act.RECORD_TYPE_ID AS ACT_RECORD_TYPE_ID,rcd_act.NAME AS ACT_RECORD_TYPE_ID_NAME, act.MARKETING_LIFECYCLE_AT_SUSPECT__C AS ACT_MARKETING_LIFECYCLE_AT_SUSPECT__C, act.MARKETING_LIFECYCLE__C AS ACT_MARKETING_LIFECYCLE__C, act.BUSINESS_UNIT_2020__C AS ACT_BUSINESS_UNIT_2020__C, act.INDUSTRY_DB__C AS ACT_INDUSTRY_DB__C, act.TERRITORY__C AS ACT_TERRITORY__C, act.STATE_DB__C AS ACT_STATE_DB__C, act.ACCOUNT_PROFILE_FIT6SENSE__C AS ACT_ACCOUNT_PROFILE_FIT6SENSE__C, act.ACCOUNT_PROFILE_SCORE6SENSE__C AS ACT_ACCOUNT_PROFILE_SCORE6SENSE__C, act.INTERNAL_TEST_ACCOUNT__C AS ACT_INTERNAL_TEST_ACCOUNT__C, act.ROUTING_REASON__C AS ACT_ROUTING_REASON__C, act.STATUS__C AS ACT_STATUS__C,act.UNQUALIFIED_REASON__C AS ACT_UNQUALIFIED_REASON__C,
-- OPP INFO
opp.ID AS OPP_ID,opp.NAME AS OPP_NAME,opp.CREATED_DATE AS OPP_CREATED_DATE,opp.CLOSE_DATE AS OPP_CLOSE_DATE,opp.LEAD_SOURCE AS OPP_LEAD_SOURCE,opp.STAGE_NAME AS OPP_STAGE_NAME,opp.TYPE AS OPP_TYPE,opp.COMMITTED_TERM__C AS OPP_COMMITTED_TERM__C,opp.PROBABILITY AS OPP_PROBABILITY,opp.IS_CLOSED AS OPP_IS_CLOSED,opp.IS_WON AS OPP_IS_WON,
-- OPP FINANCIAL METRICS
opp.CURRENCY_ISO_CODE as OPP_CURRENCY_ISO_CODE,curr.CONVERSION_RATE,
opp.ACV3__C AS OPP_ACV3__C,opp.TOTAL_BOOKING_AMOUNT2__C as OPP_TOTAL_BOOKING_AMOUNT2__C,
(opp.ACV3__C * curr.CONVERSION_RATE) AS OPP_ACV3__C_CONVERTED,(opp.TOTAL_BOOKING_AMOUNT2__C * curr.CONVERSION_RATE) as OPP_TOTAL_BOOKING_AMOUNT2__C_CONVERTED,
opp.SUBS_QTY__C as OPP_SUBS_QTY__C,opp.BOOKED_SUBS_QTY3__C as OPP_BOOKED_SUBS_QTY3__C,
opp.SALES_REPORTING_ACV__C AS OPP_SALES_REPORTING_ACV__C,opp.SALES_REPORTING_TOTAL_BOOKING_AMOUNT__C AS OPP_SALES_REPORTING_TOTAL_BOOKING_AMOUNT__C,
(opp.SALES_REPORTING_ACV__C * curr.CONVERSION_RATE) AS OPP_SALES_REPORTING_ACV__C_CONVERTED,(opp.SALES_REPORTING_TOTAL_BOOKING_AMOUNT__C * curr.CONVERSION_RATE) AS OPP_SALES_REPORTING_TOTAL_BOOKING_AMOUNT__C_CONVERTED,
opp.SALES_REPORTING_BOOKED_SUBS_QTY__C AS OPP_SALES_REPORTING_BOOKED_SUBS_QTY__C,
-- OPP OWNER INFO
usr.USER_ROLE_ID AS USR_USER_ROLE_ID,usr_role.ID AS USRROLE_ID, usr_role.NAME AS USRROLE_NAME,
row_number() OVER (PARTITION BY opp.ID,act.ID ORDER BY infl_data."Marketing_TouchPoint_Date" ASC) AS "Marketing_TouchPoint_Order",
CASE WHEN infl_data."Marketing_TouchPoint_Date" <= opp.CREATED_DATE THEN 1 ELSE 0 END AS "Marketing_TouchPoint_Before_Opp_Created",
CASE WHEN infl_data."Marketing_TouchPoint_Date" <= opp.CLOSE_DATE THEN 1 ELSE 0 END AS "Marketing_TouchPoint_Before_Opp_Close",
CASE WHEN infl_data."Marketing_TouchPoint_Date" <= act.COLD_ACCOUNT_DATE_STAMP__C THEN 1 ELSE 0 END AS "Marketing_TouchPoint_Before_Act_Cold",
CASE WHEN infl_data."Marketing_TouchPoint_Date" <= act.MEA_DATE_STAMP__C THEN 1 ELSE 0 END AS "Marketing_TouchPoint_Before_Act_MEA",
CASE WHEN infl_data."Marketing_TouchPoint_Date" <= act.MQA_DATE_STAMP__C THEN 1 ELSE 0 END AS "Marketing_TouchPoint_Before_Act_MQA",
CASE WHEN infl_data."Marketing_TouchPoint_Date" <= act.SUSPECT_DATE_STAMP__C THEN 1 ELSE 0 END AS "Marketing_TouchPoint_Before_Act_Suspect",
CASE WHEN infl_data."Marketing_TouchPoint_Date" <= act.SUSPECT_WORKING_DATE_STAMP__C THEN 1 ELSE 0 END AS "Marketing_TouchPoint_Before_Act_SuspectWorking",
CASE WHEN infl_data."Marketing_TouchPoint_Date" <= act.PROSPECT_DATE_STAMP__C THEN 1 ELSE 0 END AS "Marketing_TouchPoint_Before_Act_Prospect",
CASE WHEN infl_data."Marketing_TouchPoint_Date" <= act.CUSTOMER_DATE_STAMP__C THEN 1 ELSE 0 END AS "Marketing_TouchPoint_Before_Act_Customer",
CASE WHEN infl_data."Marketing_TouchPoint_Date" <= act.RECYCLED_DATE_STAMP__C THEN 1 ELSE 0 END AS "Marketing_TouchPoint_Before_Act_Recycled",
CASE WHEN infl_data."Marketing_TouchPoint_Date" <= act.UNQUALIFIED_DATE_STAMP__C THEN 1 ELSE 0 END AS "Marketing_TouchPoint_Before_Act_Unqualified",

infl_data."Marketing_TouchPoint_Date",
CASE WHEN infl_data."CRM_ACCOUNT_ID" IS NULL THEN ''Salesforce'' ELSE infl_data."Marketing_Touch_Type_DATA_SOURCE" END AS "Marketing_Touch_Type_DATA_SOURCE",
CASE WHEN infl_data."CRM_ACCOUNT_ID" IS NULL THEN 0 ELSE 1 END AS "Flag_Marketing_Touch_Type_DATA_SOURCE",

-- Influence based on Bizible or 6Sense or Salesforce
CASE
WHEN (
(CASE WHEN infl_data."Marketing_TouchPoint_Date" <= opp.CREATED_DATE THEN 1 ELSE 0 END) = 1 AND infl_data."Marketing_Touch_Type_DATA_SOURCE" IN (''6Sense - Paid Media'',''6Sense - Web Visit'',''Bizible'')) THEN 1
WHEN (
(CASE WHEN infl_data."Marketing_TouchPoint_Date" <= opp.CREATED_DATE THEN 1 ELSE 0 END) = 0 AND infl_data."Marketing_Touch_Type_DATA_SOURCE" IN (''6Sense - Paid Media'',''6Sense - Web Visit'',''Bizible'')) THEN 2
ELSE 0 END AS "Flag_Influence_TouchPoint_by_DataSource_Bizibleor6SenseorSalesforce",
CASE
WHEN (
(CASE WHEN infl_data."Marketing_TouchPoint_Date" <= opp.CLOSE_DATE THEN 1 ELSE 0 END) = 1 AND infl_data."Marketing_Touch_Type_DATA_SOURCE" IN (''6Sense - Paid Media'',''6Sense - Web Visit'',''Bizible'')) THEN 1
WHEN (
(CASE WHEN infl_data."Marketing_TouchPoint_Date" <= opp.CLOSE_DATE THEN 1 ELSE 0 END) = 0 AND infl_data."Marketing_Touch_Type_DATA_SOURCE" IN (''6Sense - Paid Media'',''6Sense - Web Visit'',''Bizible'')) THEN 2
ELSE 0 END AS "Flag_CLS_Influence_TouchPoint_by_DataSource_Bizibleor6SenseorSalesforce",
CASE
WHEN (
(CASE WHEN infl_data."Marketing_TouchPoint_Date" <= act.COLD_ACCOUNT_DATE_STAMP__C THEN 1 ELSE 0 END) = 1 AND infl_data."Marketing_Touch_Type_DATA_SOURCE" IN (''6Sense - Paid Media'',''6Sense - Web Visit'',''Bizible'')) THEN 1
WHEN (
(CASE WHEN infl_data."Marketing_TouchPoint_Date" <= act.COLD_ACCOUNT_DATE_STAMP__C THEN 1 ELSE 0 END) = 0 AND infl_data."Marketing_Touch_Type_DATA_SOURCE" IN (''6Sense - Paid Media'',''6Sense - Web Visit'',''Bizible'')) THEN 2
ELSE 0 END AS "Flag_ActCold_Influence_TouchPoint_by_DataSource_Bizibleor6SenseorSalesforce",
CASE
WHEN (
(CASE WHEN infl_data."Marketing_TouchPoint_Date" <= act.MEA_DATE_STAMP__C THEN 1 ELSE 0 END) = 1 AND infl_data."Marketing_Touch_Type_DATA_SOURCE" IN (''6Sense - Paid Media'',''6Sense - Web Visit'',''Bizible'')) THEN 1
WHEN (
(CASE WHEN infl_data."Marketing_TouchPoint_Date" <= act.MEA_DATE_STAMP__C THEN 1 ELSE 0 END) = 0 AND infl_data."Marketing_Touch_Type_DATA_SOURCE" IN (''6Sense - Paid Media'',''6Sense - Web Visit'',''Bizible'')) THEN 2
ELSE 0 END AS "Flag_ActMEA_Influence_TouchPoint_by_DataSource_Bizibleor6SenseorSalesforce",
CASE
WHEN (
(CASE WHEN infl_data."Marketing_TouchPoint_Date" <= act.MQA_DATE_STAMP__C THEN 1 ELSE 0 END) = 1 AND infl_data."Marketing_Touch_Type_DATA_SOURCE" IN (''6Sense - Paid Media'',''6Sense - Web Visit'',''Bizible'')) THEN 1
WHEN (
(CASE WHEN infl_data."Marketing_TouchPoint_Date" <= act.MQA_DATE_STAMP__C THEN 1 ELSE 0 END) = 0 AND infl_data."Marketing_Touch_Type_DATA_SOURCE" IN (''6Sense - Paid Media'',''6Sense - Web Visit'',''Bizible'')) THEN 2
ELSE 0 END AS "Flag_ActMQA_Influence_TouchPoint_by_DataSource_Bizibleor6SenseorSalesforce",
CASE
WHEN (
(CASE WHEN infl_data."Marketing_TouchPoint_Date" <= act.SUSPECT_DATE_STAMP__C THEN 1 ELSE 0 END) = 1 AND infl_data."Marketing_Touch_Type_DATA_SOURCE" IN (''6Sense - Paid Media'',''6Sense - Web Visit'',''Bizible'')) THEN 1
WHEN (
(CASE WHEN infl_data."Marketing_TouchPoint_Date" <= act.SUSPECT_DATE_STAMP__C THEN 1 ELSE 0 END) = 0 AND infl_data."Marketing_Touch_Type_DATA_SOURCE" IN (''6Sense - Paid Media'',''6Sense - Web Visit'',''Bizible'')) THEN 2
ELSE 0 END AS "Flag_ActSuspect_Influence_TouchPoint_by_DataSource_Bizibleor6SenseorSalesforce",
CASE
WHEN (
(CASE WHEN infl_data."Marketing_TouchPoint_Date" <= act.PROSPECT_DATE_STAMP__C THEN 1 ELSE 0 END) = 1 AND infl_data."Marketing_Touch_Type_DATA_SOURCE" IN (''6Sense - Paid Media'',''6Sense - Web Visit'',''Bizible'')) THEN 1
WHEN (
(CASE WHEN infl_data."Marketing_TouchPoint_Date" <= act.PROSPECT_DATE_STAMP__C THEN 1 ELSE 0 END) = 0 AND infl_data."Marketing_Touch_Type_DATA_SOURCE" IN (''6Sense - Paid Media'',''6Sense - Web Visit'',''Bizible'')) THEN 2
ELSE 0 END AS "Flag_ActProspect_Influence_TouchPoint_by_DataSource_Bizibleor6SenseorSalesforce",


-- Influence based on Bizible or 6Sense
CASE WHEN infl_data."Marketing_TouchPoint_Date" <= opp.CREATED_DATE AND infl_data."Marketing_Touch_Type_DATA_SOURCE" IN (''6Sense - Paid Media'',''6Sense - Web Visit'',''Bizible'') THEN 1 ELSE 0 END AS "Flag_Influence_TouchPoint_by_DataSource_Bizibleor6Sense",
CASE WHEN infl_data."Marketing_TouchPoint_Date" <= opp.CLOSE_DATE AND infl_data."Marketing_Touch_Type_DATA_SOURCE" IN (''6Sense - Paid Media'',''6Sense - Web Visit'',''Bizible'') THEN 1 else 0 END AS "Flag_CLS_Influence_TouchPoint_by_DataSource_Bizibleor6Sense",
CASE WHEN infl_data."Marketing_TouchPoint_Date" <= act.COLD_ACCOUNT_DATE_STAMP__C AND infl_data."Marketing_Touch_Type_DATA_SOURCE" IN (''6Sense - Paid Media'',''6Sense - Web Visit'',''Bizible'') THEN 1 else 0 END AS "Flag_ActCold_Influence_TouchPoint_by_DataSource_Bizibleor6Sense",
CASE WHEN infl_data."Marketing_TouchPoint_Date" <= act.MEA_DATE_STAMP__C AND infl_data."Marketing_Touch_Type_DATA_SOURCE" IN (''6Sense - Paid Media'',''6Sense - Web Visit'',''Bizible'') THEN 1 else 0 END AS "Flag_ActMEA_Influence_TouchPoint_by_DataSource_Bizibleor6Sense",
CASE WHEN infl_data."Marketing_TouchPoint_Date" <= act.MQA_DATE_STAMP__C AND infl_data."Marketing_Touch_Type_DATA_SOURCE" IN (''6Sense - Paid Media'',''6Sense - Web Visit'',''Bizible'') THEN 1 else 0 END AS "Flag_ActMQA_Influence_TouchPoint_by_DataSource_Bizibleor6Sense",
CASE WHEN infl_data."Marketing_TouchPoint_Date" <= act.SUSPECT_DATE_STAMP__C AND infl_data."Marketing_Touch_Type_DATA_SOURCE" IN (''6Sense - Paid Media'',''6Sense - Web Visit'',''Bizible'') THEN 1 else 0 END AS "Flag_ActSuspect_Influence_TouchPoint_by_DataSource_Bizibleor6Sense",
CASE WHEN infl_data."Marketing_TouchPoint_Date" <= act.PROSPECT_DATE_STAMP__C AND infl_data."Marketing_Touch_Type_DATA_SOURCE" IN (''6Sense - Paid Media'',''6Sense - Web Visit'',''Bizible'') THEN 1 else 0 END AS "Flag_ActProspect_Influence_TouchPoint_by_DataSource_Bizibleor6Sense",

-- Influence based on 6Sense Paid Media
CASE WHEN infl_data."Marketing_TouchPoint_Date" <= opp.CREATED_DATE AND infl_data."Marketing_Touch_Type_DATA_SOURCE" = ''6Sense - Paid Media'' THEN 1 else 0 END AS "Flag_Influence_TouchPoint_by_DataSource_6Sense-PaidMedia",
CASE WHEN infl_data."Marketing_TouchPoint_Date" <= opp.CLOSE_DATE AND infl_data."Marketing_Touch_Type_DATA_SOURCE" = ''6Sense - Paid Media'' THEN 1 else 0 END AS "Flag_CLS_Influence_TouchPoint_by_DataSource_6Sense-PaidMedia",
CASE WHEN infl_data."Marketing_TouchPoint_Date" <= act.COLD_ACCOUNT_DATE_STAMP__C AND infl_data."Marketing_Touch_Type_DATA_SOURCE" = ''6Sense - Paid Media'' THEN 1 else 0 END AS "Flag_ActCold_Influence_TouchPoint_by_DataSource_6Sense-PaidMedia",
CASE WHEN infl_data."Marketing_TouchPoint_Date" <= act.MEA_DATE_STAMP__C AND infl_data."Marketing_Touch_Type_DATA_SOURCE" = ''6Sense - Paid Media'' THEN 1 else 0 END AS "Flag_ActMEA_Influence_TouchPoint_by_DataSource_6Sense-PaidMedia",
CASE WHEN infl_data."Marketing_TouchPoint_Date" <= act.MQA_DATE_STAMP__C AND infl_data."Marketing_Touch_Type_DATA_SOURCE" = ''6Sense - Paid Media'' THEN 1 else 0 END AS "Flag_ActMQA_Influence_TouchPoint_by_DataSource_6Sense-PaidMedia",
CASE WHEN infl_data."Marketing_TouchPoint_Date" <= act.SUSPECT_DATE_STAMP__C AND infl_data."Marketing_Touch_Type_DATA_SOURCE" = ''6Sense - Paid Media'' THEN 1 else 0 END AS "Flag_ActSuspect_Influence_TouchPoint_by_DataSource_6Sense-PaidMedia",
CASE WHEN infl_data."Marketing_TouchPoint_Date" <= act.PROSPECT_DATE_STAMP__C AND infl_data."Marketing_Touch_Type_DATA_SOURCE" = ''6Sense - Paid Media'' THEN 1 else 0 END AS "Flag_ActProspect_Influence_TouchPoint_by_DataSource_6Sense-PaidMedia",

-- Influence based on 6Sense Web Visit
CASE WHEN infl_data."Marketing_TouchPoint_Date" <= opp.CREATED_DATE AND infl_data."Marketing_Touch_Type_DATA_SOURCE" = ''6Sense - Web Visit'' THEN 1 else 0 END AS "Flag_Influence_TouchPoint_by_DataSource_6Sense-WebVisit",
CASE WHEN infl_data."Marketing_TouchPoint_Date" <= opp.CLOSE_DATE AND infl_data."Marketing_Touch_Type_DATA_SOURCE" = ''6Sense - Web Visit'' THEN 1 else 0 END AS "Flag_CLS_Influence_TouchPoint_by_DataSource_6Sense-WebVisit",
CASE WHEN infl_data."Marketing_TouchPoint_Date" <= act.COLD_ACCOUNT_DATE_STAMP__C AND infl_data."Marketing_Touch_Type_DATA_SOURCE" = ''6Sense - Web Visit'' THEN 1 else 0 END AS "Flag_ActCold_Influence_TouchPoint_by_DataSource_6Sense-WebVisit",
CASE WHEN infl_data."Marketing_TouchPoint_Date" <= act.MEA_DATE_STAMP__C AND infl_data."Marketing_Touch_Type_DATA_SOURCE" = ''6Sense - Web Visit'' THEN 1 else 0 END AS "Flag_ActMEA_Influence_TouchPoint_by_DataSource_6Sense-WebVisit",
CASE WHEN infl_data."Marketing_TouchPoint_Date" <= act.MQA_DATE_STAMP__C AND infl_data."Marketing_Touch_Type_DATA_SOURCE" = ''6Sense - Web Visit'' THEN 1 else 0 END AS "Flag_ActMQA_Influence_TouchPoint_by_DataSource_6Sense-WebVisit",
CASE WHEN infl_data."Marketing_TouchPoint_Date" <= act.SUSPECT_DATE_STAMP__C AND infl_data."Marketing_Touch_Type_DATA_SOURCE" = ''6Sense - Web Visit'' THEN 1 else 0 END AS "Flag_ActSuspect_Influence_TouchPoint_by_DataSource_6Sense-WebVisit",
CASE WHEN infl_data."Marketing_TouchPoint_Date" <= act.PROSPECT_DATE_STAMP__C AND infl_data."Marketing_Touch_Type_DATA_SOURCE" = ''6Sense - Web Visit'' THEN 1 else 0 END AS "Flag_ActProspect_Influence_TouchPoint_by_DataSource_6Sense-WebVisit",

-- Influence based on Bizible
CASE WHEN infl_data."Marketing_TouchPoint_Date" <= opp.CREATED_DATE AND infl_data."Marketing_Touch_Type_DATA_SOURCE" = ''Bizible'' THEN 1 else 0 END AS "Flag_Influence_TouchPoint_by_DataSource_Bizible",
CASE WHEN infl_data."Marketing_TouchPoint_Date" <= opp.CLOSE_DATE AND infl_data."Marketing_Touch_Type_DATA_SOURCE" = ''Bizible'' THEN 1 else 0 END AS "Flag_CLS_Influence_TouchPoint_by_DataSource_Bizible",
CASE WHEN infl_data."Marketing_TouchPoint_Date" <= act.COLD_ACCOUNT_DATE_STAMP__C AND infl_data."Marketing_Touch_Type_DATA_SOURCE" = ''Bizible'' THEN 1 else 0 END AS "Flag_ActCold_Influence_TouchPoint_by_DataSource_Bizible",
CASE WHEN infl_data."Marketing_TouchPoint_Date" <= act.MEA_DATE_STAMP__C AND infl_data."Marketing_Touch_Type_DATA_SOURCE" = ''Bizible'' THEN 1 else 0 END AS "Flag_ActMEA_Influence_TouchPoint_by_DataSource_Bizible",
CASE WHEN infl_data."Marketing_TouchPoint_Date" <= act.MQA_DATE_STAMP__C AND infl_data."Marketing_Touch_Type_DATA_SOURCE" = ''Bizible'' THEN 1 else 0 END AS "Flag_ActMQA_Influence_TouchPoint_by_DataSource_Bizible",
CASE WHEN infl_data."Marketing_TouchPoint_Date" <= act.SUSPECT_DATE_STAMP__C AND infl_data."Marketing_Touch_Type_DATA_SOURCE" = ''Bizible'' THEN 1 else 0 END AS "Flag_ActSuspect_Influence_TouchPoint_by_DataSource_Bizible",
CASE WHEN infl_data."Marketing_TouchPoint_Date" <= act.PROSPECT_DATE_STAMP__C AND infl_data."Marketing_Touch_Type_DATA_SOURCE" = ''Bizible'' THEN 1 else 0 END AS "Flag_ActProspect_Influence_TouchPoint_by_DataSource_Bizible",

CASE WHEN infl_data."CRM_ACCOUNT_ID" IS NULL THEN ''Salesforce Opportunity'' ELSE infl_data."Marketing_Touch_Type" END AS "Marketing_Touch_Type",
infl_data."Marketing_Touch_Type_Count",

infl_data."InteractionType_Bizible_TouchPoint_WebVisit_Count",
infl_data."InteractionType_Bizible_TouchPoint_WebChat_Count",
infl_data."InteractionType_Bizible_TouchPoint_WebForm_Count",
infl_data."InteractionType_Bizible_TouchPoint_CRM_Count",
infl_data."InteractionType_Bizible_TouchPoint_ConnectwithDM_Count",
infl_data."InteractionType_Bizible_TouchPoint_CallSpokeWith_Count",
infl_data."InteractionType_Bizible_TouchPoint_CallGatekeeper_Count",
infl_data."InteractionType_Bizible_TouchPoint_NoLeadTouchPoints_Count",
infl_data."InteractionType_Bizible_TouchPoint_Unclassified_Count",
infl_data."InteractionType_6Sense_PaidMedia_Impressions_Count",
infl_data."InteractionType_6Sense_PaidMedia_Clicks_Count",
infl_data."InteractionType_6Sense_WebVisit_PageLoad_Count",
infl_data."InteractionType_6Sense_WebVisit_Play_Count",
infl_data."InteractionType_6Sense_WebVisit_Click_Count",
infl_data."InteractionType_6Sense_WebVisit_Submit_Count",
infl_data."InteractionType_6Sense_WebVisit_Unclassified_Count",



-- COUNT ONLY IF INFLUENCE
-- Influenced before Opp Created
CASE WHEN infl_data."Marketing_TouchPoint_Date" <= opp.CREATED_DATE AND infl_data."InteractionType_6Sense_PaidMedia_Impressions_Count" > 0 THEN 1 ELSE 0 END AS "Flag_Influence_TouchPoint_by_InteractionType_6Sense-PaidMedia_Impression",
CASE WHEN infl_data."Marketing_TouchPoint_Date" <= opp.CREATED_DATE AND infl_data."InteractionType_6Sense_PaidMedia_Clicks_Count" > 0 THEN 1 ELSE 0 END AS "Flag_Influence_TouchPoint_by_InteractionType_6Sense-PaidMedia_Clicks",
CASE WHEN infl_data."Marketing_TouchPoint_Date" <= opp.CREATED_DATE AND infl_data."InteractionType_6Sense_WebVisit_PageLoad_Count" > 0 THEN 1 ELSE 0 END AS "Flag_Influence_TouchPoint_by_InteractionType_6Sense-WebVisit_PageLoad",
CASE WHEN infl_data."Marketing_TouchPoint_Date" <= opp.CREATED_DATE AND infl_data."InteractionType_6Sense_WebVisit_Play_Count" > 0 THEN 1 ELSE 0 END AS "Flag_Influence_TouchPoint_by_InteractionType_6Sense-WebVisit_Play",
CASE WHEN infl_data."Marketing_TouchPoint_Date" <= opp.CREATED_DATE AND infl_data."InteractionType_6Sense_WebVisit_Click_Count" > 0 THEN 1 ELSE 0 END AS "Flag_Influence_TouchPoint_by_InteractionType_6Sense-WebVisit_Click",
CASE WHEN infl_data."Marketing_TouchPoint_Date" <= opp.CREATED_DATE AND infl_data."InteractionType_6Sense_WebVisit_Submit_Count" > 0 THEN 1 ELSE 0 END AS "Flag_Influence_TouchPoint_by_InteractionType_6Sense-WebVisit_Submit",
CASE WHEN infl_data."Marketing_TouchPoint_Date" <= opp.CREATED_DATE AND infl_data."InteractionType_6Sense_WebVisit_Unclassified_Count" > 0 THEN 1 ELSE 0 END AS "Flag_Influence_TouchPoint_by_InteractionType_6Sense-WebVisit_Unclassified",
CASE WHEN infl_data."Marketing_TouchPoint_Date" <= opp.CREATED_DATE AND infl_data."InteractionType_Bizible_TouchPoint_WebVisit_Count" > 0 THEN 1 ELSE 0 END AS "Flag_Influence_TouchPoint_by_InteractionType_Bizibile-TouchPoint_WebVisit",
CASE WHEN infl_data."Marketing_TouchPoint_Date" <= opp.CREATED_DATE AND infl_data."InteractionType_Bizible_TouchPoint_WebChat_Count" > 0 THEN 1 ELSE 0 END AS "Flag_Influence_TouchPoint_by_InteractionType_Bizibile-TouchPoint_WebChat",
CASE WHEN infl_data."Marketing_TouchPoint_Date" <= opp.CREATED_DATE AND infl_data."InteractionType_Bizible_TouchPoint_WebForm_Count" > 0 THEN 1 ELSE 0 END AS "Flag_Influence_TouchPoint_by_InteractionType_Bizibile-TouchPoint_WebForm",
CASE WHEN infl_data."Marketing_TouchPoint_Date" <= opp.CREATED_DATE AND infl_data."InteractionType_Bizible_TouchPoint_CRM_Count" > 0 THEN 1 ELSE 0 END AS "Flag_Influence_TouchPoint_by_InteractionType_Bizibile-TouchPoint_CRM",
CASE WHEN infl_data."Marketing_TouchPoint_Date" <= opp.CREATED_DATE AND infl_data."InteractionType_Bizible_TouchPoint_ConnectwithDM_Count" > 0 THEN 1 ELSE 0 END AS "Flag_Influence_TouchPoint_by_InteractionType_Bizibile-TouchPoint_ConnectwithDM",
CASE WHEN infl_data."Marketing_TouchPoint_Date" <= opp.CREATED_DATE AND infl_data."InteractionType_Bizible_TouchPoint_CallSpokeWith_Count" > 0 THEN 1 ELSE 0 END AS "Flag_Influence_TouchPoint_by_InteractionType_Bizibile-TouchPoint_CallSpokeWith",
CASE WHEN infl_data."Marketing_TouchPoint_Date" <= opp.CREATED_DATE AND infl_data."InteractionType_Bizible_TouchPoint_CallGatekeeper_Count" > 0 THEN 1 ELSE 0 END AS "Flag_Influence_TouchPoint_by_InteractionType_Bizibile-TouchPoint_CallGatekeeper",
CASE WHEN infl_data."Marketing_TouchPoint_Date" <= opp.CREATED_DATE AND infl_data."InteractionType_Bizible_TouchPoint_NoLeadTouchPoints_Count" > 0 THEN 1 ELSE 0 END AS "Flag_Influence_TouchPoint_by_InteractionType_Bizibile-TouchPoint_NoLeadTouchPoint",
CASE WHEN infl_data."Marketing_TouchPoint_Date" <= opp.CREATED_DATE AND infl_data."InteractionType_Bizible_TouchPoint_Unclassified_Count" > 0 THEN 1 ELSE 0 END AS "Flag_Influence_TouchPoint_by_InteractionType_Bizibile-TouchPoint_Unclassified",

-- Influenced before Opp Closed
CASE WHEN infl_data."Marketing_TouchPoint_Date" <= opp.CLOSE_DATE AND infl_data."InteractionType_6Sense_PaidMedia_Impressions_Count" > 0 THEN 1 ELSE 0 END AS "Flag_CLS_Influence_TouchPoint_by_InteractionType_6Sense-PaidMedia_Impression",
CASE WHEN infl_data."Marketing_TouchPoint_Date" <= opp.CLOSE_DATE AND infl_data."InteractionType_6Sense_PaidMedia_Clicks_Count" > 0 THEN 1 ELSE 0 END AS "Flag_CLS_Influence_TouchPoint_by_InteractionType_6Sense-PaidMedia_Clicks",
CASE WHEN infl_data."Marketing_TouchPoint_Date" <= opp.CLOSE_DATE AND infl_data."InteractionType_6Sense_WebVisit_PageLoad_Count" > 0 THEN 1 ELSE 0 END AS "Flag_CLS_Influence_TouchPoint_by_InteractionType_6Sense-WebVisit_PageLoad",
CASE WHEN infl_data."Marketing_TouchPoint_Date" <= opp.CLOSE_DATE AND infl_data."InteractionType_6Sense_WebVisit_Play_Count" > 0 THEN 1 ELSE 0 END AS "Flag_CLS_Influence_TouchPoint_by_InteractionType_6Sense-WebVisit_Play",
CASE WHEN infl_data."Marketing_TouchPoint_Date" <= opp.CLOSE_DATE AND infl_data."InteractionType_6Sense_WebVisit_Click_Count" > 0 THEN 1 ELSE 0 END AS "Flag_CLS_Influence_TouchPoint_by_InteractionType_6Sense-WebVisit_Click",
CASE WHEN infl_data."Marketing_TouchPoint_Date" <= opp.CLOSE_DATE AND infl_data."InteractionType_6Sense_WebVisit_Submit_Count" > 0 THEN 1 ELSE 0 END AS "Flag_CLS_Influence_TouchPoint_by_InteractionType_6Sense-WebVisit_Submit",
CASE WHEN infl_data."Marketing_TouchPoint_Date" <= opp.CLOSE_DATE AND infl_data."InteractionType_6Sense_WebVisit_Unclassified_Count" > 0 THEN 1 ELSE 0 END AS "Flag_CLS_Influence_TouchPoint_by_InteractionType_6Sense-WebVisit_Unclassified",
CASE WHEN infl_data."Marketing_TouchPoint_Date" <= opp.CLOSE_DATE AND infl_data."InteractionType_Bizible_TouchPoint_WebVisit_Count" > 0 THEN 1 ELSE 0 END AS "Flag_CLS_Influence_TouchPoint_by_InteractionType_Bizibile-TouchPoint_WebVisit",
CASE WHEN infl_data."Marketing_TouchPoint_Date" <= opp.CLOSE_DATE AND infl_data."InteractionType_Bizible_TouchPoint_WebChat_Count" > 0 THEN 1 ELSE 0 END AS "Flag_CLS_Influence_TouchPoint_by_InteractionType_Bizibile-TouchPoint_WebChat",
CASE WHEN infl_data."Marketing_TouchPoint_Date" <= opp.CLOSE_DATE AND infl_data."InteractionType_Bizible_TouchPoint_WebForm_Count" > 0 THEN 1 ELSE 0 END AS "Flag_CLS_Influence_TouchPoint_by_InteractionType_Bizibile-TouchPoint_WebForm",
CASE WHEN infl_data."Marketing_TouchPoint_Date" <= opp.CLOSE_DATE AND infl_data."InteractionType_Bizible_TouchPoint_CRM_Count" > 0 THEN 1 ELSE 0 END AS "Flag_CLS_Influence_TouchPoint_by_InteractionType_Bizibile-TouchPoint_CRM",
CASE WHEN infl_data."Marketing_TouchPoint_Date" <= opp.CLOSE_DATE AND infl_data."InteractionType_Bizible_TouchPoint_ConnectwithDM_Count" > 0 THEN 1 ELSE 0 END AS "Flag_CLS_Influence_TouchPoint_by_InteractionType_Bizibile-TouchPoint_ConnectwithDM",
CASE WHEN infl_data."Marketing_TouchPoint_Date" <= opp.CLOSE_DATE AND infl_data."InteractionType_Bizible_TouchPoint_CallSpokeWith_Count" > 0 THEN 1 ELSE 0 END AS "Flag_CLS_Influence_TouchPoint_by_InteractionType_Bizibile-TouchPoint_CallSpokeWith",
CASE WHEN infl_data."Marketing_TouchPoint_Date" <= opp.CLOSE_DATE AND infl_data."InteractionType_Bizible_TouchPoint_CallGatekeeper_Count" > 0 THEN 1 ELSE 0 END AS "Flag_CLS_Influence_TouchPoint_by_InteractionType_Bizibile-TouchPoint_CallGatekeeper",
CASE WHEN infl_data."Marketing_TouchPoint_Date" <= opp.CLOSE_DATE AND infl_data."InteractionType_Bizible_TouchPoint_NoLeadTouchPoints_Count" > 0 THEN 1 ELSE 0 END AS "Flag_CLS_Influence_TouchPoint_by_InteractionType_Bizibile-TouchPoint_NoLeadTouchPoint",
CASE WHEN infl_data."Marketing_TouchPoint_Date" <= opp.CLOSE_DATE AND infl_data."InteractionType_Bizible_TouchPoint_Unclassified_Count" > 0 THEN 1 ELSE 0 END AS "Flag_CLS_Influence_TouchPoint_by_InteractionType_Bizibile-TouchPoint_Unclassified",

-- Influenced before Account Cold
CASE WHEN infl_data."Marketing_TouchPoint_Date" <= act.COLD_ACCOUNT_DATE_STAMP__C AND infl_data."InteractionType_6Sense_PaidMedia_Impressions_Count" > 0 THEN 1 ELSE 0 END AS "Flag_ActCold_Influence_TouchPoint_by_InteractionType_6Sense-PaidMedia_Impression",
CASE WHEN infl_data."Marketing_TouchPoint_Date" <= act.COLD_ACCOUNT_DATE_STAMP__C AND infl_data."InteractionType_6Sense_PaidMedia_Clicks_Count" > 0 THEN 1 ELSE 0 END AS "Flag_ActCold_Influence_TouchPoint_by_InteractionType_6Sense-PaidMedia_Clicks",
CASE WHEN infl_data."Marketing_TouchPoint_Date" <= act.COLD_ACCOUNT_DATE_STAMP__C AND infl_data."InteractionType_6Sense_WebVisit_PageLoad_Count" > 0 THEN 1 ELSE 0 END AS "Flag_ActCold_Influence_TouchPoint_by_InteractionType_6Sense-WebVisit_PageLoad",
CASE WHEN infl_data."Marketing_TouchPoint_Date" <= act.COLD_ACCOUNT_DATE_STAMP__C AND infl_data."InteractionType_6Sense_WebVisit_Play_Count" > 0 THEN 1 ELSE 0 END AS "Flag_ActCold_Influence_TouchPoint_by_InteractionType_6Sense-WebVisit_Play",
CASE WHEN infl_data."Marketing_TouchPoint_Date" <= act.COLD_ACCOUNT_DATE_STAMP__C AND infl_data."InteractionType_6Sense_WebVisit_Click_Count" > 0 THEN 1 ELSE 0 END AS "Flag_ActCold_Influence_TouchPoint_by_InteractionType_6Sense-WebVisit_Click",
CASE WHEN infl_data."Marketing_TouchPoint_Date" <= act.COLD_ACCOUNT_DATE_STAMP__C AND infl_data."InteractionType_6Sense_WebVisit_Submit_Count" > 0 THEN 1 ELSE 0 END AS "Flag_ActCold_Influence_TouchPoint_by_InteractionType_6Sense-WebVisit_Submit",
CASE WHEN infl_data."Marketing_TouchPoint_Date" <= act.COLD_ACCOUNT_DATE_STAMP__C AND infl_data."InteractionType_6Sense_WebVisit_Unclassified_Count" > 0 THEN 1 ELSE 0 END AS "Flag_ActCold_Influence_TouchPoint_by_InteractionType_6Sense-WebVisit_Unclassified",
CASE WHEN infl_data."Marketing_TouchPoint_Date" <= act.COLD_ACCOUNT_DATE_STAMP__C AND infl_data."InteractionType_Bizible_TouchPoint_WebVisit_Count" > 0 THEN 1 ELSE 0 END AS "Flag_ActCold_Influence_TouchPoint_by_InteractionType_Bizibile-TouchPoint_WebVisit",
CASE WHEN infl_data."Marketing_TouchPoint_Date" <= act.COLD_ACCOUNT_DATE_STAMP__C AND infl_data."InteractionType_Bizible_TouchPoint_WebChat_Count" > 0 THEN 1 ELSE 0 END AS "Flag_ActCold_Influence_TouchPoint_by_InteractionType_Bizibile-TouchPoint_WebChat",
CASE WHEN infl_data."Marketing_TouchPoint_Date" <= act.COLD_ACCOUNT_DATE_STAMP__C AND infl_data."InteractionType_Bizible_TouchPoint_WebForm_Count" > 0 THEN 1 ELSE 0 END AS "Flag_ActCold_Influence_TouchPoint_by_InteractionType_Bizibile-TouchPoint_WebForm",
CASE WHEN infl_data."Marketing_TouchPoint_Date" <= act.COLD_ACCOUNT_DATE_STAMP__C AND infl_data."InteractionType_Bizible_TouchPoint_CRM_Count" > 0 THEN 1 ELSE 0 END AS "Flag_ActCold_Influence_TouchPoint_by_InteractionType_Bizibile-TouchPoint_CRM",
CASE WHEN infl_data."Marketing_TouchPoint_Date" <= act.COLD_ACCOUNT_DATE_STAMP__C AND infl_data."InteractionType_Bizible_TouchPoint_ConnectwithDM_Count" > 0 THEN 1 ELSE 0 END AS "Flag_ActCold_Influence_TouchPoint_by_InteractionType_Bizibile-TouchPoint_ConnectwithDM",
CASE WHEN infl_data."Marketing_TouchPoint_Date" <= act.COLD_ACCOUNT_DATE_STAMP__C AND infl_data."InteractionType_Bizible_TouchPoint_CallSpokeWith_Count" > 0 THEN 1 ELSE 0 END AS "Flag_ActCold_Influence_TouchPoint_by_InteractionType_Bizibile-TouchPoint_CallSpokeWith",
CASE WHEN infl_data."Marketing_TouchPoint_Date" <= act.COLD_ACCOUNT_DATE_STAMP__C AND infl_data."InteractionType_Bizible_TouchPoint_CallGatekeeper_Count" > 0 THEN 1 ELSE 0 END AS "Flag_ActCold_Influence_TouchPoint_by_InteractionType_Bizibile-TouchPoint_CallGatekeeper",
CASE WHEN infl_data."Marketing_TouchPoint_Date" <= act.COLD_ACCOUNT_DATE_STAMP__C AND infl_data."InteractionType_Bizible_TouchPoint_NoLeadTouchPoints_Count" > 0 THEN 1 ELSE 0 END AS "Flag_ActCold_Influence_TouchPoint_by_InteractionType_Bizibile-TouchPoint_NoLeadTouchPoint",
CASE WHEN infl_data."Marketing_TouchPoint_Date" <= act.COLD_ACCOUNT_DATE_STAMP__C AND infl_data."InteractionType_Bizible_TouchPoint_Unclassified_Count" > 0 THEN 1 ELSE 0 END AS "Flag_ActCold_Influence_TouchPoint_by_InteractionType_Bizibile-TouchPoint_Unclassified",

-- Influenced before Account MEA
CASE WHEN infl_data."Marketing_TouchPoint_Date" <= act.MEA_DATE_STAMP__C AND infl_data."InteractionType_6Sense_PaidMedia_Impressions_Count" > 0 THEN 1 ELSE 0 END AS "Flag_ActMEA_Influence_TouchPoint_by_InteractionType_6Sense-PaidMedia_Impression",
CASE WHEN infl_data."Marketing_TouchPoint_Date" <= act.MEA_DATE_STAMP__C AND infl_data."InteractionType_6Sense_PaidMedia_Clicks_Count" > 0 THEN 1 ELSE 0 END AS "Flag_ActMEA_Influence_TouchPoint_by_InteractionType_6Sense-PaidMedia_Clicks",
CASE WHEN infl_data."Marketing_TouchPoint_Date" <= act.MEA_DATE_STAMP__C AND infl_data."InteractionType_6Sense_WebVisit_PageLoad_Count" > 0 THEN 1 ELSE 0 END AS "Flag_ActMEA_Influence_TouchPoint_by_InteractionType_6Sense-WebVisit_PageLoad",
CASE WHEN infl_data."Marketing_TouchPoint_Date" <= act.MEA_DATE_STAMP__C AND infl_data."InteractionType_6Sense_WebVisit_Play_Count" > 0 THEN 1 ELSE 0 END AS "Flag_ActMEA_Influence_TouchPoint_by_InteractionType_6Sense-WebVisit_Play",
CASE WHEN infl_data."Marketing_TouchPoint_Date" <= act.MEA_DATE_STAMP__C AND infl_data."InteractionType_6Sense_WebVisit_Click_Count" > 0 THEN 1 ELSE 0 END AS "Flag_ActMEA_Influence_TouchPoint_by_InteractionType_6Sense-WebVisit_Click",
CASE WHEN infl_data."Marketing_TouchPoint_Date" <= act.MEA_DATE_STAMP__C AND infl_data."InteractionType_6Sense_WebVisit_Submit_Count" > 0 THEN 1 ELSE 0 END AS "Flag_ActMEA_Influence_TouchPoint_by_InteractionType_6Sense-WebVisit_Submit",
CASE WHEN infl_data."Marketing_TouchPoint_Date" <= act.MEA_DATE_STAMP__C AND infl_data."InteractionType_6Sense_WebVisit_Unclassified_Count" > 0 THEN 1 ELSE 0 END AS "Flag_ActMEA_Influence_TouchPoint_by_InteractionType_6Sense-WebVisit_Unclassified",
CASE WHEN infl_data."Marketing_TouchPoint_Date" <= act.MEA_DATE_STAMP__C AND infl_data."InteractionType_Bizible_TouchPoint_WebVisit_Count" > 0 THEN 1 ELSE 0 END AS "Flag_ActMEA_Influence_TouchPoint_by_InteractionType_Bizibile-TouchPoint_WebVisit",
CASE WHEN infl_data."Marketing_TouchPoint_Date" <= act.MEA_DATE_STAMP__C AND infl_data."InteractionType_Bizible_TouchPoint_WebChat_Count" > 0 THEN 1 ELSE 0 END AS "Flag_ActMEA_Influence_TouchPoint_by_InteractionType_Bizibile-TouchPoint_WebChat",
CASE WHEN infl_data."Marketing_TouchPoint_Date" <= act.MEA_DATE_STAMP__C AND infl_data."InteractionType_Bizible_TouchPoint_WebForm_Count" > 0 THEN 1 ELSE 0 END AS "Flag_ActMEA_Influence_TouchPoint_by_InteractionType_Bizibile-TouchPoint_WebForm",
CASE WHEN infl_data."Marketing_TouchPoint_Date" <= act.MEA_DATE_STAMP__C AND infl_data."InteractionType_Bizible_TouchPoint_CRM_Count" > 0 THEN 1 ELSE 0 END AS "Flag_ActMEA_Influence_TouchPoint_by_InteractionType_Bizibile-TouchPoint_CRM",
CASE WHEN infl_data."Marketing_TouchPoint_Date" <= act.MEA_DATE_STAMP__C AND infl_data."InteractionType_Bizible_TouchPoint_ConnectwithDM_Count" > 0 THEN 1 ELSE 0 END AS "Flag_ActMEA_Influence_TouchPoint_by_InteractionType_Bizibile-TouchPoint_ConnectwithDM",
CASE WHEN infl_data."Marketing_TouchPoint_Date" <= act.MEA_DATE_STAMP__C AND infl_data."InteractionType_Bizible_TouchPoint_CallSpokeWith_Count" > 0 THEN 1 ELSE 0 END AS "Flag_ActMEA_Influence_TouchPoint_by_InteractionType_Bizibile-TouchPoint_CallSpokeWith",
CASE WHEN infl_data."Marketing_TouchPoint_Date" <= act.MEA_DATE_STAMP__C AND infl_data."InteractionType_Bizible_TouchPoint_CallGatekeeper_Count" > 0 THEN 1 ELSE 0 END AS "Flag_ActMEA_Influence_TouchPoint_by_InteractionType_Bizibile-TouchPoint_CallGatekeeper",
CASE WHEN infl_data."Marketing_TouchPoint_Date" <= act.MEA_DATE_STAMP__C AND infl_data."InteractionType_Bizible_TouchPoint_NoLeadTouchPoints_Count" > 0 THEN 1 ELSE 0 END AS "Flag_ActMEA_Influence_TouchPoint_by_InteractionType_Bizibile-TouchPoint_NoLeadTouchPoint",
CASE WHEN infl_data."Marketing_TouchPoint_Date" <= act.MEA_DATE_STAMP__C AND infl_data."InteractionType_Bizible_TouchPoint_Unclassified_Count" > 0 THEN 1 ELSE 0 END AS "Flag_ActMEA_Influence_TouchPoint_by_InteractionType_Bizibile-TouchPoint_Unclassified",

-- Influenced before Account MQA
CASE WHEN infl_data."Marketing_TouchPoint_Date" <= act.MQA_DATE_STAMP__C AND infl_data."InteractionType_6Sense_PaidMedia_Impressions_Count" > 0 THEN 1 ELSE 0 END AS "Flag_ActMQA_Influence_TouchPoint_by_InteractionType_6Sense-PaidMedia_Impression",
CASE WHEN infl_data."Marketing_TouchPoint_Date" <= act.MQA_DATE_STAMP__C AND infl_data."InteractionType_6Sense_PaidMedia_Clicks_Count" > 0 THEN 1 ELSE 0 END AS "Flag_ActMQA_Influence_TouchPoint_by_InteractionType_6Sense-PaidMedia_Clicks",
CASE WHEN infl_data."Marketing_TouchPoint_Date" <= act.MQA_DATE_STAMP__C AND infl_data."InteractionType_6Sense_WebVisit_PageLoad_Count" > 0 THEN 1 ELSE 0 END AS "Flag_ActMQA_Influence_TouchPoint_by_InteractionType_6Sense-WebVisit_PageLoad",
CASE WHEN infl_data."Marketing_TouchPoint_Date" <= act.MQA_DATE_STAMP__C AND infl_data."InteractionType_6Sense_WebVisit_Play_Count" > 0 THEN 1 ELSE 0 END AS "Flag_ActMQA_Influence_TouchPoint_by_InteractionType_6Sense-WebVisit_Play",
CASE WHEN infl_data."Marketing_TouchPoint_Date" <= act.MQA_DATE_STAMP__C AND infl_data."InteractionType_6Sense_WebVisit_Click_Count" > 0 THEN 1 ELSE 0 END AS "Flag_ActMQA_Influence_TouchPoint_by_InteractionType_6Sense-WebVisit_Click",
CASE WHEN infl_data."Marketing_TouchPoint_Date" <= act.MQA_DATE_STAMP__C AND infl_data."InteractionType_6Sense_WebVisit_Submit_Count" > 0 THEN 1 ELSE 0 END AS "Flag_ActMQA_Influence_TouchPoint_by_InteractionType_6Sense-WebVisit_Submit",
CASE WHEN infl_data."Marketing_TouchPoint_Date" <= act.MQA_DATE_STAMP__C AND infl_data."InteractionType_6Sense_WebVisit_Unclassified_Count" > 0 THEN 1 ELSE 0 END AS "Flag_ActMQA_Influence_TouchPoint_by_InteractionType_6Sense-WebVisit_Unclassified",
CASE WHEN infl_data."Marketing_TouchPoint_Date" <= act.MQA_DATE_STAMP__C AND infl_data."InteractionType_Bizible_TouchPoint_WebVisit_Count" > 0 THEN 1 ELSE 0 END AS "Flag_ActMQA_Influence_TouchPoint_by_InteractionType_Bizibile-TouchPoint_WebVisit",
CASE WHEN infl_data."Marketing_TouchPoint_Date" <= act.MQA_DATE_STAMP__C AND infl_data."InteractionType_Bizible_TouchPoint_WebChat_Count" > 0 THEN 1 ELSE 0 END AS "Flag_ActMQA_Influence_TouchPoint_by_InteractionType_Bizibile-TouchPoint_WebChat",
CASE WHEN infl_data."Marketing_TouchPoint_Date" <= act.MQA_DATE_STAMP__C AND infl_data."InteractionType_Bizible_TouchPoint_WebForm_Count" > 0 THEN 1 ELSE 0 END AS "Flag_ActMQA_Influence_TouchPoint_by_InteractionType_Bizibile-TouchPoint_WebForm",
CASE WHEN infl_data."Marketing_TouchPoint_Date" <= act.MQA_DATE_STAMP__C AND infl_data."InteractionType_Bizible_TouchPoint_CRM_Count" > 0 THEN 1 ELSE 0 END AS "Flag_ActMQA_Influence_TouchPoint_by_InteractionType_Bizibile-TouchPoint_CRM",
CASE WHEN infl_data."Marketing_TouchPoint_Date" <= act.MQA_DATE_STAMP__C AND infl_data."InteractionType_Bizible_TouchPoint_ConnectwithDM_Count" > 0 THEN 1 ELSE 0 END AS "Flag_ActMQA_Influence_TouchPoint_by_InteractionType_Bizibile-TouchPoint_ConnectwithDM",
CASE WHEN infl_data."Marketing_TouchPoint_Date" <= act.MQA_DATE_STAMP__C AND infl_data."InteractionType_Bizible_TouchPoint_CallSpokeWith_Count" > 0 THEN 1 ELSE 0 END AS "Flag_ActMQA_Influence_TouchPoint_by_InteractionType_Bizibile-TouchPoint_CallSpokeWith",
CASE WHEN infl_data."Marketing_TouchPoint_Date" <= act.MQA_DATE_STAMP__C AND infl_data."InteractionType_Bizible_TouchPoint_CallGatekeeper_Count" > 0 THEN 1 ELSE 0 END AS "Flag_ActMQA_Influence_TouchPoint_by_InteractionType_Bizibile-TouchPoint_CallGatekeeper",
CASE WHEN infl_data."Marketing_TouchPoint_Date" <= act.MQA_DATE_STAMP__C AND infl_data."InteractionType_Bizible_TouchPoint_NoLeadTouchPoints_Count" > 0 THEN 1 ELSE 0 END AS "Flag_ActMQA_Influence_TouchPoint_by_InteractionType_Bizibile-TouchPoint_NoLeadTouchPoint",
CASE WHEN infl_data."Marketing_TouchPoint_Date" <= act.MQA_DATE_STAMP__C AND infl_data."InteractionType_Bizible_TouchPoint_Unclassified_Count" > 0 THEN 1 ELSE 0 END AS "Flag_ActMQA_Influence_TouchPoint_by_InteractionType_Bizibile-TouchPoint_Unclassified",

-- Influenced before Account Suspect
CASE WHEN infl_data."Marketing_TouchPoint_Date" <= act.SUSPECT_DATE_STAMP__C AND infl_data."InteractionType_6Sense_PaidMedia_Impressions_Count" > 0 THEN 1 ELSE 0 END AS "Flag_ActSuspect_Influence_TouchPoint_by_InteractionType_6Sense-PaidMedia_Impression",
CASE WHEN infl_data."Marketing_TouchPoint_Date" <= act.SUSPECT_DATE_STAMP__C AND infl_data."InteractionType_6Sense_PaidMedia_Clicks_Count" > 0 THEN 1 ELSE 0 END AS "Flag_ActSuspect_Influence_TouchPoint_by_InteractionType_6Sense-PaidMedia_Clicks",
CASE WHEN infl_data."Marketing_TouchPoint_Date" <= act.SUSPECT_DATE_STAMP__C AND infl_data."InteractionType_6Sense_WebVisit_PageLoad_Count" > 0 THEN 1 ELSE 0 END AS "Flag_ActSuspect_Influence_TouchPoint_by_InteractionType_6Sense-WebVisit_PageLoad",
CASE WHEN infl_data."Marketing_TouchPoint_Date" <= act.SUSPECT_DATE_STAMP__C AND infl_data."InteractionType_6Sense_WebVisit_Play_Count" > 0 THEN 1 ELSE 0 END AS "Flag_ActSuspect_Influence_TouchPoint_by_InteractionType_6Sense-WebVisit_Play",
CASE WHEN infl_data."Marketing_TouchPoint_Date" <= act.SUSPECT_DATE_STAMP__C AND infl_data."InteractionType_6Sense_WebVisit_Click_Count" > 0 THEN 1 ELSE 0 END AS "Flag_ActSuspect_Influence_TouchPoint_by_InteractionType_6Sense-WebVisit_Click",
CASE WHEN infl_data."Marketing_TouchPoint_Date" <= act.SUSPECT_DATE_STAMP__C AND infl_data."InteractionType_6Sense_WebVisit_Submit_Count" > 0 THEN 1 ELSE 0 END AS "Flag_ActSuspect_Influence_TouchPoint_by_InteractionType_6Sense-WebVisit_Submit",
CASE WHEN infl_data."Marketing_TouchPoint_Date" <= act.SUSPECT_DATE_STAMP__C AND infl_data."InteractionType_6Sense_WebVisit_Unclassified_Count" > 0 THEN 1 ELSE 0 END AS "Flag_ActSuspect_Influence_TouchPoint_by_InteractionType_6Sense-WebVisit_Unclassified",
CASE WHEN infl_data."Marketing_TouchPoint_Date" <= act.SUSPECT_DATE_STAMP__C AND infl_data."InteractionType_Bizible_TouchPoint_WebVisit_Count" > 0 THEN 1 ELSE 0 END AS "Flag_ActSuspect_Influence_TouchPoint_by_InteractionType_Bizibile-TouchPoint_WebVisit",
CASE WHEN infl_data."Marketing_TouchPoint_Date" <= act.SUSPECT_DATE_STAMP__C AND infl_data."InteractionType_Bizible_TouchPoint_WebChat_Count" > 0 THEN 1 ELSE 0 END AS "Flag_ActSuspect_Influence_TouchPoint_by_InteractionType_Bizibile-TouchPoint_WebChat",
CASE WHEN infl_data."Marketing_TouchPoint_Date" <= act.SUSPECT_DATE_STAMP__C AND infl_data."InteractionType_Bizible_TouchPoint_WebForm_Count" > 0 THEN 1 ELSE 0 END AS "Flag_ActSuspect_Influence_TouchPoint_by_InteractionType_Bizibile-TouchPoint_WebForm",
CASE WHEN infl_data."Marketing_TouchPoint_Date" <= act.SUSPECT_DATE_STAMP__C AND infl_data."InteractionType_Bizible_TouchPoint_CRM_Count" > 0 THEN 1 ELSE 0 END AS "Flag_ActSuspect_Influence_TouchPoint_by_InteractionType_Bizibile-TouchPoint_CRM",
CASE WHEN infl_data."Marketing_TouchPoint_Date" <= act.SUSPECT_DATE_STAMP__C AND infl_data."InteractionType_Bizible_TouchPoint_ConnectwithDM_Count" > 0 THEN 1 ELSE 0 END AS "Flag_ActSuspect_Influence_TouchPoint_by_InteractionType_Bizibile-TouchPoint_ConnectwithDM",
CASE WHEN infl_data."Marketing_TouchPoint_Date" <= act.SUSPECT_DATE_STAMP__C AND infl_data."InteractionType_Bizible_TouchPoint_CallSpokeWith_Count" > 0 THEN 1 ELSE 0 END AS "Flag_ActSuspect_Influence_TouchPoint_by_InteractionType_Bizibile-TouchPoint_CallSpokeWith",
CASE WHEN infl_data."Marketing_TouchPoint_Date" <= act.SUSPECT_DATE_STAMP__C AND infl_data."InteractionType_Bizible_TouchPoint_CallGatekeeper_Count" > 0 THEN 1 ELSE 0 END AS "Flag_ActSuspect_Influence_TouchPoint_by_InteractionType_Bizibile-TouchPoint_CallGatekeeper",
CASE WHEN infl_data."Marketing_TouchPoint_Date" <= act.SUSPECT_DATE_STAMP__C AND infl_data."InteractionType_Bizible_TouchPoint_NoLeadTouchPoints_Count" > 0 THEN 1 ELSE 0 END AS "Flag_ActSuspect_Influence_TouchPoint_by_InteractionType_Bizibile-TouchPoint_NoLeadTouchPoint",
CASE WHEN infl_data."Marketing_TouchPoint_Date" <= act.SUSPECT_DATE_STAMP__C AND infl_data."InteractionType_Bizible_TouchPoint_Unclassified_Count" > 0 THEN 1 ELSE 0 END AS "Flag_ActSuspect_Influence_TouchPoint_by_InteractionType_Bizibile-TouchPoint_Unclassified",

-- Influenced before Account Prospect
CASE WHEN infl_data."Marketing_TouchPoint_Date" <= act.PROSPECT_DATE_STAMP__C AND infl_data."InteractionType_6Sense_PaidMedia_Impressions_Count" > 0 THEN 1 ELSE 0 END AS "Flag_ActProspect_Influence_TouchPoint_by_InteractionType_6Sense-PaidMedia_Impression",
CASE WHEN infl_data."Marketing_TouchPoint_Date" <= act.PROSPECT_DATE_STAMP__C AND infl_data."InteractionType_6Sense_PaidMedia_Clicks_Count" > 0 THEN 1 ELSE 0 END AS "Flag_ActProspect_Influence_TouchPoint_by_InteractionType_6Sense-PaidMedia_Clicks",
CASE WHEN infl_data."Marketing_TouchPoint_Date" <= act.PROSPECT_DATE_STAMP__C AND infl_data."InteractionType_6Sense_WebVisit_PageLoad_Count" > 0 THEN 1 ELSE 0 END AS "Flag_ActProspect_Influence_TouchPoint_by_InteractionType_6Sense-WebVisit_PageLoad",
CASE WHEN infl_data."Marketing_TouchPoint_Date" <= act.PROSPECT_DATE_STAMP__C AND infl_data."InteractionType_6Sense_WebVisit_Play_Count" > 0 THEN 1 ELSE 0 END AS "Flag_ActProspect_Influence_TouchPoint_by_InteractionType_6Sense-WebVisit_Play",
CASE WHEN infl_data."Marketing_TouchPoint_Date" <= act.PROSPECT_DATE_STAMP__C AND infl_data."InteractionType_6Sense_WebVisit_Click_Count" > 0 THEN 1 ELSE 0 END AS "Flag_ActProspect_Influence_TouchPoint_by_InteractionType_6Sense-WebVisit_Click",
CASE WHEN infl_data."Marketing_TouchPoint_Date" <= act.PROSPECT_DATE_STAMP__C AND infl_data."InteractionType_6Sense_WebVisit_Submit_Count" > 0 THEN 1 ELSE 0 END AS "Flag_ActProspect_Influence_TouchPoint_by_InteractionType_6Sense-WebVisit_Submit",
CASE WHEN infl_data."Marketing_TouchPoint_Date" <= act.PROSPECT_DATE_STAMP__C AND infl_data."InteractionType_6Sense_WebVisit_Unclassified_Count" > 0 THEN 1 ELSE 0 END AS "Flag_ActProspect_Influence_TouchPoint_by_InteractionType_6Sense-WebVisit_Unclassified",
CASE WHEN infl_data."Marketing_TouchPoint_Date" <= act.PROSPECT_DATE_STAMP__C AND infl_data."InteractionType_Bizible_TouchPoint_WebVisit_Count" > 0 THEN 1 ELSE 0 END AS "Flag_ActProspect_Influence_TouchPoint_by_InteractionType_Bizibile-TouchPoint_WebVisit",
CASE WHEN infl_data."Marketing_TouchPoint_Date" <= act.PROSPECT_DATE_STAMP__C AND infl_data."InteractionType_Bizible_TouchPoint_WebChat_Count" > 0 THEN 1 ELSE 0 END AS "Flag_ActProspect_Influence_TouchPoint_by_InteractionType_Bizibile-TouchPoint_WebChat",
CASE WHEN infl_data."Marketing_TouchPoint_Date" <= act.PROSPECT_DATE_STAMP__C AND infl_data."InteractionType_Bizible_TouchPoint_WebForm_Count" > 0 THEN 1 ELSE 0 END AS "Flag_ActProspect_Influence_TouchPoint_by_InteractionType_Bizibile-TouchPoint_WebForm",
CASE WHEN infl_data."Marketing_TouchPoint_Date" <= act.PROSPECT_DATE_STAMP__C AND infl_data."InteractionType_Bizible_TouchPoint_CRM_Count" > 0 THEN 1 ELSE 0 END AS "Flag_ActProspect_Influence_TouchPoint_by_InteractionType_Bizibile-TouchPoint_CRM",
CASE WHEN infl_data."Marketing_TouchPoint_Date" <= act.PROSPECT_DATE_STAMP__C AND infl_data."InteractionType_Bizible_TouchPoint_ConnectwithDM_Count" > 0 THEN 1 ELSE 0 END AS "Flag_ActProspect_Influence_TouchPoint_by_InteractionType_Bizibile-TouchPoint_ConnectwithDM",
CASE WHEN infl_data."Marketing_TouchPoint_Date" <= act.PROSPECT_DATE_STAMP__C AND infl_data."InteractionType_Bizible_TouchPoint_CallSpokeWith_Count" > 0 THEN 1 ELSE 0 END AS "Flag_ActProspect_Influence_TouchPoint_by_InteractionType_Bizibile-TouchPoint_CallSpokeWith",
CASE WHEN infl_data."Marketing_TouchPoint_Date" <= act.PROSPECT_DATE_STAMP__C AND infl_data."InteractionType_Bizible_TouchPoint_CallGatekeeper_Count" > 0 THEN 1 ELSE 0 END AS "Flag_ActProspect_Influence_TouchPoint_by_InteractionType_Bizibile-TouchPoint_CallGatekeeper",
CASE WHEN infl_data."Marketing_TouchPoint_Date" <= act.PROSPECT_DATE_STAMP__C AND infl_data."InteractionType_Bizible_TouchPoint_NoLeadTouchPoints_Count" > 0 THEN 1 ELSE 0 END AS "Flag_ActProspect_Influence_TouchPoint_by_InteractionType_Bizibile-TouchPoint_NoLeadTouchPoint",
CASE WHEN infl_data."Marketing_TouchPoint_Date" <= act.PROSPECT_DATE_STAMP__C AND infl_data."InteractionType_Bizible_TouchPoint_Unclassified_Count" > 0 THEN 1 ELSE 0 END AS "Flag_ActProspect_Influence_TouchPoint_by_InteractionType_Bizibile-TouchPoint_Unclassified",

-- SUM COUNTS INFLUENCE
-- Influenced Before Opp Created
CASE WHEN infl_data."Marketing_TouchPoint_Date" <= opp.CREATED_DATE AND infl_data."InteractionType_6Sense_PaidMedia_Impressions_Count" > 0 THEN infl_data."InteractionType_6Sense_PaidMedia_Impressions_Count" ELSE 0 END AS "InteractionType_6Sense_PaidMedia_Impressions_Count_Influence",
CASE WHEN infl_data."Marketing_TouchPoint_Date" <= opp.CREATED_DATE AND infl_data."InteractionType_6Sense_PaidMedia_Clicks_Count" > 0 THEN infl_data."InteractionType_6Sense_PaidMedia_Clicks_Count" ELSE 0 END AS "InteractionType_6Sense_PaidMedia_Clicks_Count_Influence",
CASE WHEN infl_data."Marketing_TouchPoint_Date" <= opp.CREATED_DATE AND infl_data."InteractionType_6Sense_WebVisit_PageLoad_Count" > 0 THEN infl_data."InteractionType_6Sense_WebVisit_PageLoad_Count" ELSE 0 END AS "InteractionType_6Sense_WebVisit_PageLoad_Count_Influence",
CASE WHEN infl_data."Marketing_TouchPoint_Date" <= opp.CREATED_DATE AND infl_data."InteractionType_6Sense_WebVisit_Play_Count" > 0 THEN infl_data."InteractionType_6Sense_WebVisit_Play_Count" ELSE 0 END AS "InteractionType_6Sense_WebVisit_Play_Count_Influence",
CASE WHEN infl_data."Marketing_TouchPoint_Date" <= opp.CREATED_DATE AND infl_data."InteractionType_6Sense_WebVisit_Click_Count" > 0 THEN infl_data."InteractionType_6Sense_WebVisit_Click_Count" ELSE 0 END AS "InteractionType_6Sense_WebVisit_Click_Count_Influence",
CASE WHEN infl_data."Marketing_TouchPoint_Date" <= opp.CREATED_DATE AND infl_data."InteractionType_6Sense_WebVisit_Submit_Count" > 0 THEN infl_data."InteractionType_6Sense_WebVisit_Submit_Count" ELSE 0 END AS "InteractionType_6Sense_WebVisit_Submit_Count_Influence",
CASE WHEN infl_data."Marketing_TouchPoint_Date" <= opp.CREATED_DATE AND infl_data."InteractionType_6Sense_WebVisit_Unclassified_Count" > 0 THEN infl_data."InteractionType_6Sense_WebVisit_Unclassified_Count" ELSE 0 END AS "InteractionType_6Sense_WebVisit_Unclassified_Count_Influence",
CASE WHEN infl_data."Marketing_TouchPoint_Date" <= opp.CREATED_DATE AND infl_data."InteractionType_Bizible_TouchPoint_WebVisit_Count" > 0 THEN infl_data."InteractionType_Bizible_TouchPoint_WebVisit_Count" ELSE 0 END AS "InteractionType_Bizibile-TouchPoint_WebVisit_Count_Influence",
CASE WHEN infl_data."Marketing_TouchPoint_Date" <= opp.CREATED_DATE AND infl_data."InteractionType_Bizible_TouchPoint_WebChat_Count" > 0 THEN infl_data."InteractionType_Bizible_TouchPoint_WebChat_Count" ELSE 0 END AS "InteractionType_Bizibile-TouchPoint_WebChat_Count_Influence",
CASE WHEN infl_data."Marketing_TouchPoint_Date" <= opp.CREATED_DATE AND infl_data."InteractionType_Bizible_TouchPoint_WebForm_Count" > 0 THEN infl_data."InteractionType_Bizible_TouchPoint_WebForm_Count" ELSE 0 END AS "InteractionType_Bizibile-TouchPoint_WebForm_Count_Influence",
CASE WHEN infl_data."Marketing_TouchPoint_Date" <= opp.CREATED_DATE AND infl_data."InteractionType_Bizible_TouchPoint_CRM_Count" > 0 THEN infl_data."InteractionType_Bizible_TouchPoint_CRM_Count" ELSE 0 END AS "InteractionType_Bizibile-TouchPoint_CRM_Count_Influence",
CASE WHEN infl_data."Marketing_TouchPoint_Date" <= opp.CREATED_DATE AND infl_data."InteractionType_Bizible_TouchPoint_ConnectwithDM_Count" > 0 THEN infl_data."InteractionType_Bizible_TouchPoint_ConnectwithDM_Count" ELSE 0 END AS "InteractionType_Bizibile-TouchPoint_ConnectwithDM_Count_Influence",
CASE WHEN infl_data."Marketing_TouchPoint_Date" <= opp.CREATED_DATE AND infl_data."InteractionType_Bizible_TouchPoint_CallSpokeWith_Count" > 0 THEN infl_data."InteractionType_Bizible_TouchPoint_CallSpokeWith_Count" ELSE 0 END AS "InteractionType_Bizibile-TouchPoint_CallSpokeWith_Count_Influence",
CASE WHEN infl_data."Marketing_TouchPoint_Date" <= opp.CREATED_DATE AND infl_data."InteractionType_Bizible_TouchPoint_CallGatekeeper_Count" > 0 THEN infl_data."InteractionType_Bizible_TouchPoint_CallGatekeeper_Count" ELSE 0 END AS "InteractionType_Bizibile-TouchPoint_CallGatekeeper_Count_Influence",
CASE WHEN infl_data."Marketing_TouchPoint_Date" <= opp.CREATED_DATE AND infl_data."InteractionType_Bizible_TouchPoint_NoLeadTouchPoints_Count" > 0 THEN infl_data."InteractionType_Bizible_TouchPoint_NoLeadTouchPoints_Count" ELSE 0 END AS "InteractionType_Bizibile-TouchPoint_NoLeadTouchPoint_Count_Influence",
CASE WHEN infl_data."Marketing_TouchPoint_Date" <= opp.CREATED_DATE AND infl_data."InteractionType_Bizible_TouchPoint_Unclassified_Count" > 0 THEN infl_data."InteractionType_Bizible_TouchPoint_Unclassified_Count" ELSE 0 END AS "InteractionType_Bizibile-TouchPoint_Unclassified_Count_Influence",

-- Influenced Before Opp Close
CASE WHEN infl_data."Marketing_TouchPoint_Date" <= opp.CLOSE_DATE AND infl_data."InteractionType_6Sense_PaidMedia_Impressions_Count" > 0 THEN infl_data."InteractionType_6Sense_PaidMedia_Impressions_Count" ELSE 0 END AS "InteractionType_6Sense_PaidMedia_Impressions_Count_CLS_Influence",
CASE WHEN infl_data."Marketing_TouchPoint_Date" <= opp.CLOSE_DATE AND infl_data."InteractionType_6Sense_PaidMedia_Clicks_Count" > 0 THEN infl_data."InteractionType_6Sense_PaidMedia_Clicks_Count" ELSE 0 END AS "InteractionType_6Sense_PaidMedia_Clicks_Count_CLS_Influence",
CASE WHEN infl_data."Marketing_TouchPoint_Date" <= opp.CLOSE_DATE AND infl_data."InteractionType_6Sense_WebVisit_PageLoad_Count" > 0 THEN infl_data."InteractionType_6Sense_WebVisit_PageLoad_Count" ELSE 0 END AS "InteractionType_6Sense_WebVisit_PageLoad_Count_CLS_Influence",
CASE WHEN infl_data."Marketing_TouchPoint_Date" <= opp.CLOSE_DATE AND infl_data."InteractionType_6Sense_WebVisit_Play_Count" > 0 THEN infl_data."InteractionType_6Sense_WebVisit_Play_Count" ELSE 0 END AS "InteractionType_6Sense_WebVisit_Play_Count_CLS_Influence",
CASE WHEN infl_data."Marketing_TouchPoint_Date" <= opp.CLOSE_DATE AND infl_data."InteractionType_6Sense_WebVisit_Click_Count" > 0 THEN infl_data."InteractionType_6Sense_WebVisit_Click_Count" ELSE 0 END AS "InteractionType_6Sense_WebVisit_Click_Count_CLS_Influence",
CASE WHEN infl_data."Marketing_TouchPoint_Date" <= opp.CLOSE_DATE AND infl_data."InteractionType_6Sense_WebVisit_Submit_Count" > 0 THEN infl_data."InteractionType_6Sense_WebVisit_Submit_Count" ELSE 0 END AS "InteractionType_6Sense_WebVisit_Submit_Count_CLS_Influence",
CASE WHEN infl_data."Marketing_TouchPoint_Date" <= opp.CLOSE_DATE AND infl_data."InteractionType_6Sense_WebVisit_Unclassified_Count" > 0 THEN infl_data."InteractionType_6Sense_WebVisit_Unclassified_Count" ELSE 0 END AS "InteractionType_6Sense_WebVisit_Unclassified_Count_CLS_Influence",
CASE WHEN infl_data."Marketing_TouchPoint_Date" <= opp.CLOSE_DATE AND infl_data."InteractionType_Bizible_TouchPoint_WebVisit_Count" > 0 THEN infl_data."InteractionType_Bizible_TouchPoint_WebVisit_Count" ELSE 0 END AS "InteractionType_Bizibile-TouchPoint_WebVisit_Count_CLS_Influence",
CASE WHEN infl_data."Marketing_TouchPoint_Date" <= opp.CLOSE_DATE AND infl_data."InteractionType_Bizible_TouchPoint_WebChat_Count" > 0 THEN infl_data."InteractionType_Bizible_TouchPoint_WebChat_Count" ELSE 0 END AS "InteractionType_Bizibile-TouchPoint_WebChat_Count_CLS_Influence",
CASE WHEN infl_data."Marketing_TouchPoint_Date" <= opp.CLOSE_DATE AND infl_data."InteractionType_Bizible_TouchPoint_WebForm_Count" > 0 THEN infl_data."InteractionType_Bizible_TouchPoint_WebForm_Count" ELSE 0 END AS "InteractionType_Bizibile-TouchPoint_WebForm_Count_CLS_Influence",
CASE WHEN infl_data."Marketing_TouchPoint_Date" <= opp.CLOSE_DATE AND infl_data."InteractionType_Bizible_TouchPoint_CRM_Count" > 0 THEN infl_data."InteractionType_Bizible_TouchPoint_CRM_Count" ELSE 0 END AS "InteractionType_Bizibile-TouchPoint_CRM_Count_CLS_Influence",
CASE WHEN infl_data."Marketing_TouchPoint_Date" <= opp.CLOSE_DATE AND infl_data."InteractionType_Bizible_TouchPoint_ConnectwithDM_Count" > 0 THEN infl_data."InteractionType_Bizible_TouchPoint_ConnectwithDM_Count" ELSE 0 END AS "InteractionType_Bizibile-TouchPoint_ConnectwithDM_Count_CLS_Influence",
CASE WHEN infl_data."Marketing_TouchPoint_Date" <= opp.CLOSE_DATE AND infl_data."InteractionType_Bizible_TouchPoint_CallSpokeWith_Count" > 0 THEN infl_data."InteractionType_Bizible_TouchPoint_CallSpokeWith_Count" ELSE 0 END AS "InteractionType_Bizibile-TouchPoint_CallSpokeWith_Count_CLS_Influence",
CASE WHEN infl_data."Marketing_TouchPoint_Date" <= opp.CLOSE_DATE AND infl_data."InteractionType_Bizible_TouchPoint_CallGatekeeper_Count" > 0 THEN infl_data."InteractionType_Bizible_TouchPoint_CallGatekeeper_Count" ELSE 0 END AS "InteractionType_Bizibile-TouchPoint_CallGatekeeper_Count_CLS_Influence",
CASE WHEN infl_data."Marketing_TouchPoint_Date" <= opp.CLOSE_DATE AND infl_data."InteractionType_Bizible_TouchPoint_NoLeadTouchPoints_Count" > 0 THEN infl_data."InteractionType_Bizible_TouchPoint_NoLeadTouchPoints_Count" ELSE 0 END AS "InteractionType_Bizibile-TouchPoint_NoLeadTouchPoint_Count_CLS_Influence",
CASE WHEN infl_data."Marketing_TouchPoint_Date" <= opp.CLOSE_DATE AND infl_data."InteractionType_Bizible_TouchPoint_Unclassified_Count" > 0 THEN infl_data."InteractionType_Bizible_TouchPoint_Unclassified_Count" ELSE 0 END AS "InteractionType_Bizibile-TouchPoint_Unclassified_Count_CLS_Influence",

-- Influenced Before Accound Cold
CASE WHEN infl_data."Marketing_TouchPoint_Date" <= act.COLD_ACCOUNT_DATE_STAMP__C AND infl_data."InteractionType_6Sense_PaidMedia_Impressions_Count" > 0 THEN infl_data."InteractionType_6Sense_PaidMedia_Impressions_Count" ELSE 0 END AS "InteractionType_6Sense_PaidMedia_Impressions_Count_ActCold_Influence",
CASE WHEN infl_data."Marketing_TouchPoint_Date" <= act.COLD_ACCOUNT_DATE_STAMP__C AND infl_data."InteractionType_6Sense_PaidMedia_Clicks_Count" > 0 THEN infl_data."InteractionType_6Sense_PaidMedia_Clicks_Count" ELSE 0 END AS "InteractionType_6Sense_PaidMedia_Clicks_Count_ActCold_Influence",
CASE WHEN infl_data."Marketing_TouchPoint_Date" <= act.COLD_ACCOUNT_DATE_STAMP__C AND infl_data."InteractionType_6Sense_WebVisit_PageLoad_Count" > 0 THEN infl_data."InteractionType_6Sense_WebVisit_PageLoad_Count" ELSE 0 END AS "InteractionType_6Sense_WebVisit_PageLoad_Count_ActCold_Influence",
CASE WHEN infl_data."Marketing_TouchPoint_Date" <= act.COLD_ACCOUNT_DATE_STAMP__C AND infl_data."InteractionType_6Sense_WebVisit_Play_Count" > 0 THEN infl_data."InteractionType_6Sense_WebVisit_Play_Count" ELSE 0 END AS "InteractionType_6Sense_WebVisit_Play_Count_ActCold_Influence",
CASE WHEN infl_data."Marketing_TouchPoint_Date" <= act.COLD_ACCOUNT_DATE_STAMP__C AND infl_data."InteractionType_6Sense_WebVisit_Click_Count" > 0 THEN infl_data."InteractionType_6Sense_WebVisit_Click_Count" ELSE 0 END AS "InteractionType_6Sense_WebVisit_Click_Count_ActCold_Influence",
CASE WHEN infl_data."Marketing_TouchPoint_Date" <= act.COLD_ACCOUNT_DATE_STAMP__C AND infl_data."InteractionType_6Sense_WebVisit_Submit_Count" > 0 THEN infl_data."InteractionType_6Sense_WebVisit_Submit_Count" ELSE 0 END AS "InteractionType_6Sense_WebVisit_Submit_Count_ActCold_Influence",
CASE WHEN infl_data."Marketing_TouchPoint_Date" <= act.COLD_ACCOUNT_DATE_STAMP__C AND infl_data."InteractionType_6Sense_WebVisit_Unclassified_Count" > 0 THEN infl_data."InteractionType_6Sense_WebVisit_Unclassified_Count" ELSE 0 END AS "InteractionType_6Sense_WebVisit_Unclassified_Count_ActCold_Influence",
CASE WHEN infl_data."Marketing_TouchPoint_Date" <= act.COLD_ACCOUNT_DATE_STAMP__C AND infl_data."InteractionType_Bizible_TouchPoint_WebVisit_Count" > 0 THEN infl_data."InteractionType_Bizible_TouchPoint_WebVisit_Count" ELSE 0 END AS "InteractionType_Bizibile-TouchPoint_WebVisit_Count_ActCold_Influence",
CASE WHEN infl_data."Marketing_TouchPoint_Date" <= act.COLD_ACCOUNT_DATE_STAMP__C AND infl_data."InteractionType_Bizible_TouchPoint_WebChat_Count" > 0 THEN infl_data."InteractionType_Bizible_TouchPoint_WebChat_Count" ELSE 0 END AS "InteractionType_Bizibile-TouchPoint_WebChat_Count_ActCold_Influence",
CASE WHEN infl_data."Marketing_TouchPoint_Date" <= act.COLD_ACCOUNT_DATE_STAMP__C AND infl_data."InteractionType_Bizible_TouchPoint_WebForm_Count" > 0 THEN infl_data."InteractionType_Bizible_TouchPoint_WebForm_Count" ELSE 0 END AS "InteractionType_Bizibile-TouchPoint_WebForm_Count_ActCold_Influence",
CASE WHEN infl_data."Marketing_TouchPoint_Date" <= act.COLD_ACCOUNT_DATE_STAMP__C AND infl_data."InteractionType_Bizible_TouchPoint_CRM_Count" > 0 THEN infl_data."InteractionType_Bizible_TouchPoint_CRM_Count" ELSE 0 END AS "InteractionType_Bizibile-TouchPoint_CRM_Count_ActCold_Influence",
CASE WHEN infl_data."Marketing_TouchPoint_Date" <= act.COLD_ACCOUNT_DATE_STAMP__C AND infl_data."InteractionType_Bizible_TouchPoint_ConnectwithDM_Count" > 0 THEN infl_data."InteractionType_Bizible_TouchPoint_ConnectwithDM_Count" ELSE 0 END AS "InteractionType_Bizibile-TouchPoint_ConnectwithDM_Count_ActCold_Influence",
CASE WHEN infl_data."Marketing_TouchPoint_Date" <= act.COLD_ACCOUNT_DATE_STAMP__C AND infl_data."InteractionType_Bizible_TouchPoint_CallSpokeWith_Count" > 0 THEN infl_data."InteractionType_Bizible_TouchPoint_CallSpokeWith_Count" ELSE 0 END AS "InteractionType_Bizibile-TouchPoint_CallSpokeWith_Count_ActCold_Influence",
CASE WHEN infl_data."Marketing_TouchPoint_Date" <= act.COLD_ACCOUNT_DATE_STAMP__C AND infl_data."InteractionType_Bizible_TouchPoint_CallGatekeeper_Count" > 0 THEN infl_data."InteractionType_Bizible_TouchPoint_CallGatekeeper_Count" ELSE 0 END AS "InteractionType_Bizibile-TouchPoint_CallGatekeeper_Count_ActCold_Influence",
CASE WHEN infl_data."Marketing_TouchPoint_Date" <= act.COLD_ACCOUNT_DATE_STAMP__C AND infl_data."InteractionType_Bizible_TouchPoint_NoLeadTouchPoints_Count" > 0 THEN infl_data."InteractionType_Bizible_TouchPoint_NoLeadTouchPoints_Count" ELSE 0 END AS "InteractionType_Bizibile-TouchPoint_NoLeadTouchPoint_Count_ActCold_Influence",
CASE WHEN infl_data."Marketing_TouchPoint_Date" <= act.COLD_ACCOUNT_DATE_STAMP__C AND infl_data."InteractionType_Bizible_TouchPoint_Unclassified_Count" > 0 THEN infl_data."InteractionType_Bizible_TouchPoint_Unclassified_Count" ELSE 0 END AS "InteractionType_Bizibile-TouchPoint_Unclassified_Count_ActCold_Influence",

-- Influenced Before Accound MEA
CASE WHEN infl_data."Marketing_TouchPoint_Date" <= act.MEA_DATE_STAMP__C AND infl_data."InteractionType_6Sense_PaidMedia_Impressions_Count" > 0 THEN infl_data."InteractionType_6Sense_PaidMedia_Impressions_Count" ELSE 0 END AS "InteractionType_6Sense_PaidMedia_Impressions_Count_ActMEA_Influence",
CASE WHEN infl_data."Marketing_TouchPoint_Date" <= act.MEA_DATE_STAMP__C AND infl_data."InteractionType_6Sense_PaidMedia_Clicks_Count" > 0 THEN infl_data."InteractionType_6Sense_PaidMedia_Clicks_Count" ELSE 0 END AS "InteractionType_6Sense_PaidMedia_Clicks_Count_ActMEA_Influence",
CASE WHEN infl_data."Marketing_TouchPoint_Date" <= act.MEA_DATE_STAMP__C AND infl_data."InteractionType_6Sense_WebVisit_PageLoad_Count" > 0 THEN infl_data."InteractionType_6Sense_WebVisit_PageLoad_Count" ELSE 0 END AS "InteractionType_6Sense_WebVisit_PageLoad_Count_ActMEA_Influence",
CASE WHEN infl_data."Marketing_TouchPoint_Date" <= act.MEA_DATE_STAMP__C AND infl_data."InteractionType_6Sense_WebVisit_Play_Count" > 0 THEN infl_data."InteractionType_6Sense_WebVisit_Play_Count" ELSE 0 END AS "InteractionType_6Sense_WebVisit_Play_Count_ActMEA_Influence",
CASE WHEN infl_data."Marketing_TouchPoint_Date" <= act.MEA_DATE_STAMP__C AND infl_data."InteractionType_6Sense_WebVisit_Click_Count" > 0 THEN infl_data."InteractionType_6Sense_WebVisit_Click_Count" ELSE 0 END AS "InteractionType_6Sense_WebVisit_Click_Count_ActMEA_Influence",
CASE WHEN infl_data."Marketing_TouchPoint_Date" <= act.MEA_DATE_STAMP__C AND infl_data."InteractionType_6Sense_WebVisit_Submit_Count" > 0 THEN infl_data."InteractionType_6Sense_WebVisit_Submit_Count" ELSE 0 END AS "InteractionType_6Sense_WebVisit_Submit_Count_ActMEA_Influence",
CASE WHEN infl_data."Marketing_TouchPoint_Date" <= act.MEA_DATE_STAMP__C AND infl_data."InteractionType_6Sense_WebVisit_Unclassified_Count" > 0 THEN infl_data."InteractionType_6Sense_WebVisit_Unclassified_Count" ELSE 0 END AS "InteractionType_6Sense_WebVisit_Unclassified_Count_ActMEA_Influence",
CASE WHEN infl_data."Marketing_TouchPoint_Date" <= act.MEA_DATE_STAMP__C AND infl_data."InteractionType_Bizible_TouchPoint_WebVisit_Count" > 0 THEN infl_data."InteractionType_Bizible_TouchPoint_WebVisit_Count" ELSE 0 END AS "InteractionType_Bizibile-TouchPoint_WebVisit_Count_ActMEA_Influence",
CASE WHEN infl_data."Marketing_TouchPoint_Date" <= act.MEA_DATE_STAMP__C AND infl_data."InteractionType_Bizible_TouchPoint_WebChat_Count" > 0 THEN infl_data."InteractionType_Bizible_TouchPoint_WebChat_Count" ELSE 0 END AS "InteractionType_Bizibile-TouchPoint_WebChat_Count_ActMEA_Influence",
CASE WHEN infl_data."Marketing_TouchPoint_Date" <= act.MEA_DATE_STAMP__C AND infl_data."InteractionType_Bizible_TouchPoint_WebForm_Count" > 0 THEN infl_data."InteractionType_Bizible_TouchPoint_WebForm_Count" ELSE 0 END AS "InteractionType_Bizibile-TouchPoint_WebForm_Count_ActMEA_Influence",
CASE WHEN infl_data."Marketing_TouchPoint_Date" <= act.MEA_DATE_STAMP__C AND infl_data."InteractionType_Bizible_TouchPoint_CRM_Count" > 0 THEN infl_data."InteractionType_Bizible_TouchPoint_CRM_Count" ELSE 0 END AS "InteractionType_Bizibile-TouchPoint_CRM_Count_ActMEA_Influence",
CASE WHEN infl_data."Marketing_TouchPoint_Date" <= act.MEA_DATE_STAMP__C AND infl_data."InteractionType_Bizible_TouchPoint_ConnectwithDM_Count" > 0 THEN infl_data."InteractionType_Bizible_TouchPoint_ConnectwithDM_Count" ELSE 0 END AS "InteractionType_Bizibile-TouchPoint_ConnectwithDM_Count_ActMEA_Influence",
CASE WHEN infl_data."Marketing_TouchPoint_Date" <= act.MEA_DATE_STAMP__C AND infl_data."InteractionType_Bizible_TouchPoint_CallSpokeWith_Count" > 0 THEN infl_data."InteractionType_Bizible_TouchPoint_CallSpokeWith_Count" ELSE 0 END AS "InteractionType_Bizibile-TouchPoint_CallSpokeWith_Count_ActMEA_Influence",
CASE WHEN infl_data."Marketing_TouchPoint_Date" <= act.MEA_DATE_STAMP__C AND infl_data."InteractionType_Bizible_TouchPoint_CallGatekeeper_Count" > 0 THEN infl_data."InteractionType_Bizible_TouchPoint_CallGatekeeper_Count" ELSE 0 END AS "InteractionType_Bizibile-TouchPoint_CallGatekeeper_Count_ActMEA_Influence",
CASE WHEN infl_data."Marketing_TouchPoint_Date" <= act.MEA_DATE_STAMP__C AND infl_data."InteractionType_Bizible_TouchPoint_NoLeadTouchPoints_Count" > 0 THEN infl_data."InteractionType_Bizible_TouchPoint_NoLeadTouchPoints_Count" ELSE 0 END AS "InteractionType_Bizibile-TouchPoint_NoLeadTouchPoint_Count_ActMEA_Influence",
CASE WHEN infl_data."Marketing_TouchPoint_Date" <= act.MEA_DATE_STAMP__C AND infl_data."InteractionType_Bizible_TouchPoint_Unclassified_Count" > 0 THEN infl_data."InteractionType_Bizible_TouchPoint_Unclassified_Count" ELSE 0 END AS "InteractionType_Bizibile-TouchPoint_Unclassified_Count_ActMEA_Influence",

-- Influenced Before Accound MQA
CASE WHEN infl_data."Marketing_TouchPoint_Date" <= act.MQA_DATE_STAMP__C AND infl_data."InteractionType_6Sense_PaidMedia_Impressions_Count" > 0 THEN infl_data."InteractionType_6Sense_PaidMedia_Impressions_Count" ELSE 0 END AS "InteractionType_6Sense_PaidMedia_Impressions_Count_ActMQA_Influence",
CASE WHEN infl_data."Marketing_TouchPoint_Date" <= act.MQA_DATE_STAMP__C AND infl_data."InteractionType_6Sense_PaidMedia_Clicks_Count" > 0 THEN infl_data."InteractionType_6Sense_PaidMedia_Clicks_Count" ELSE 0 END AS "InteractionType_6Sense_PaidMedia_Clicks_Count_ActMQA_Influence",
CASE WHEN infl_data."Marketing_TouchPoint_Date" <= act.MQA_DATE_STAMP__C AND infl_data."InteractionType_6Sense_WebVisit_PageLoad_Count" > 0 THEN infl_data."InteractionType_6Sense_WebVisit_PageLoad_Count" ELSE 0 END AS "InteractionType_6Sense_WebVisit_PageLoad_Count_ActMQA_Influence",
CASE WHEN infl_data."Marketing_TouchPoint_Date" <= act.MQA_DATE_STAMP__C AND infl_data."InteractionType_6Sense_WebVisit_Play_Count" > 0 THEN infl_data."InteractionType_6Sense_WebVisit_Play_Count" ELSE 0 END AS "InteractionType_6Sense_WebVisit_Play_Count_ActMQA_Influence",
CASE WHEN infl_data."Marketing_TouchPoint_Date" <= act.MQA_DATE_STAMP__C AND infl_data."InteractionType_6Sense_WebVisit_Click_Count" > 0 THEN infl_data."InteractionType_6Sense_WebVisit_Click_Count" ELSE 0 END AS "InteractionType_6Sense_WebVisit_Click_Count_ActMQA_Influence",
CASE WHEN infl_data."Marketing_TouchPoint_Date" <= act.MQA_DATE_STAMP__C AND infl_data."InteractionType_6Sense_WebVisit_Submit_Count" > 0 THEN infl_data."InteractionType_6Sense_WebVisit_Submit_Count" ELSE 0 END AS "InteractionType_6Sense_WebVisit_Submit_Count_ActMQA_Influence",
CASE WHEN infl_data."Marketing_TouchPoint_Date" <= act.MQA_DATE_STAMP__C AND infl_data."InteractionType_6Sense_WebVisit_Unclassified_Count" > 0 THEN infl_data."InteractionType_6Sense_WebVisit_Unclassified_Count" ELSE 0 END AS "InteractionType_6Sense_WebVisit_Unclassified_Count_ActMQA_Influence",
CASE WHEN infl_data."Marketing_TouchPoint_Date" <= act.MQA_DATE_STAMP__C AND infl_data."InteractionType_Bizible_TouchPoint_WebVisit_Count" > 0 THEN infl_data."InteractionType_Bizible_TouchPoint_WebVisit_Count" ELSE 0 END AS "InteractionType_Bizibile-TouchPoint_WebVisit_Count_ActMQA_Influence",
CASE WHEN infl_data."Marketing_TouchPoint_Date" <= act.MQA_DATE_STAMP__C AND infl_data."InteractionType_Bizible_TouchPoint_WebChat_Count" > 0 THEN infl_data."InteractionType_Bizible_TouchPoint_WebChat_Count" ELSE 0 END AS "InteractionType_Bizibile-TouchPoint_WebChat_Count_ActMQA_Influence",
CASE WHEN infl_data."Marketing_TouchPoint_Date" <= act.MQA_DATE_STAMP__C AND infl_data."InteractionType_Bizible_TouchPoint_WebForm_Count" > 0 THEN infl_data."InteractionType_Bizible_TouchPoint_WebForm_Count" ELSE 0 END AS "InteractionType_Bizibile-TouchPoint_WebForm_Count_ActMQA_Influence",
CASE WHEN infl_data."Marketing_TouchPoint_Date" <= act.MQA_DATE_STAMP__C AND infl_data."InteractionType_Bizible_TouchPoint_CRM_Count" > 0 THEN infl_data."InteractionType_Bizible_TouchPoint_CRM_Count" ELSE 0 END AS "InteractionType_Bizibile-TouchPoint_CRM_Count_ActMQA_Influence",
CASE WHEN infl_data."Marketing_TouchPoint_Date" <= act.MQA_DATE_STAMP__C AND infl_data."InteractionType_Bizible_TouchPoint_ConnectwithDM_Count" > 0 THEN infl_data."InteractionType_Bizible_TouchPoint_ConnectwithDM_Count" ELSE 0 END AS "InteractionType_Bizibile-TouchPoint_ConnectwithDM_Count_ActMQA_Influence",
CASE WHEN infl_data."Marketing_TouchPoint_Date" <= act.MQA_DATE_STAMP__C AND infl_data."InteractionType_Bizible_TouchPoint_CallSpokeWith_Count" > 0 THEN infl_data."InteractionType_Bizible_TouchPoint_CallSpokeWith_Count" ELSE 0 END AS "InteractionType_Bizibile-TouchPoint_CallSpokeWith_Count_ActMQA_Influence",
CASE WHEN infl_data."Marketing_TouchPoint_Date" <= act.MQA_DATE_STAMP__C AND infl_data."InteractionType_Bizible_TouchPoint_CallGatekeeper_Count" > 0 THEN infl_data."InteractionType_Bizible_TouchPoint_CallGatekeeper_Count" ELSE 0 END AS "InteractionType_Bizibile-TouchPoint_CallGatekeeper_Count_ActMQA_Influence",
CASE WHEN infl_data."Marketing_TouchPoint_Date" <= act.MQA_DATE_STAMP__C AND infl_data."InteractionType_Bizible_TouchPoint_NoLeadTouchPoints_Count" > 0 THEN infl_data."InteractionType_Bizible_TouchPoint_NoLeadTouchPoints_Count" ELSE 0 END AS "InteractionType_Bizibile-TouchPoint_NoLeadTouchPoint_Count_ActMQA_Influence",
CASE WHEN infl_data."Marketing_TouchPoint_Date" <= act.MQA_DATE_STAMP__C AND infl_data."InteractionType_Bizible_TouchPoint_Unclassified_Count" > 0 THEN infl_data."InteractionType_Bizible_TouchPoint_Unclassified_Count" ELSE 0 END AS "InteractionType_Bizibile-TouchPoint_Unclassified_Count_ActMQA_Influence",

-- Influenced Before Accound Suspect
CASE WHEN infl_data."Marketing_TouchPoint_Date" <= act.SUSPECT_DATE_STAMP__C AND infl_data."InteractionType_6Sense_PaidMedia_Impressions_Count" > 0 THEN infl_data."InteractionType_6Sense_PaidMedia_Impressions_Count" ELSE 0 END AS "InteractionType_6Sense_PaidMedia_Impressions_Count_ActSuspect_Influence",
CASE WHEN infl_data."Marketing_TouchPoint_Date" <= act.SUSPECT_DATE_STAMP__C AND infl_data."InteractionType_6Sense_PaidMedia_Clicks_Count" > 0 THEN infl_data."InteractionType_6Sense_PaidMedia_Clicks_Count" ELSE 0 END AS "InteractionType_6Sense_PaidMedia_Clicks_Count_ActSuspect_Influence",
CASE WHEN infl_data."Marketing_TouchPoint_Date" <= act.SUSPECT_DATE_STAMP__C AND infl_data."InteractionType_6Sense_WebVisit_PageLoad_Count" > 0 THEN infl_data."InteractionType_6Sense_WebVisit_PageLoad_Count" ELSE 0 END AS "InteractionType_6Sense_WebVisit_PageLoad_Count_ActSuspect_Influence",
CASE WHEN infl_data."Marketing_TouchPoint_Date" <= act.SUSPECT_DATE_STAMP__C AND infl_data."InteractionType_6Sense_WebVisit_Play_Count" > 0 THEN infl_data."InteractionType_6Sense_WebVisit_Play_Count" ELSE 0 END AS "InteractionType_6Sense_WebVisit_Play_Count_ActSuspect_Influence",
CASE WHEN infl_data."Marketing_TouchPoint_Date" <= act.SUSPECT_DATE_STAMP__C AND infl_data."InteractionType_6Sense_WebVisit_Click_Count" > 0 THEN infl_data."InteractionType_6Sense_WebVisit_Click_Count" ELSE 0 END AS "InteractionType_6Sense_WebVisit_Click_Count_ActSuspect_Influence",
CASE WHEN infl_data."Marketing_TouchPoint_Date" <= act.SUSPECT_DATE_STAMP__C AND infl_data."InteractionType_6Sense_WebVisit_Submit_Count" > 0 THEN infl_data."InteractionType_6Sense_WebVisit_Submit_Count" ELSE 0 END AS "InteractionType_6Sense_WebVisit_Submit_Count_ActSuspect_Influence",
CASE WHEN infl_data."Marketing_TouchPoint_Date" <= act.SUSPECT_DATE_STAMP__C AND infl_data."InteractionType_6Sense_WebVisit_Unclassified_Count" > 0 THEN infl_data."InteractionType_6Sense_WebVisit_Unclassified_Count" ELSE 0 END AS "InteractionType_6Sense_WebVisit_Unclassified_Count_ActSuspect_Influence",
CASE WHEN infl_data."Marketing_TouchPoint_Date" <= act.SUSPECT_DATE_STAMP__C AND infl_data."InteractionType_Bizible_TouchPoint_WebVisit_Count" > 0 THEN infl_data."InteractionType_Bizible_TouchPoint_WebVisit_Count" ELSE 0 END AS "InteractionType_Bizibile-TouchPoint_WebVisit_Count_ActSuspect_Influence",
CASE WHEN infl_data."Marketing_TouchPoint_Date" <= act.SUSPECT_DATE_STAMP__C AND infl_data."InteractionType_Bizible_TouchPoint_WebChat_Count" > 0 THEN infl_data."InteractionType_Bizible_TouchPoint_WebChat_Count" ELSE 0 END AS "InteractionType_Bizibile-TouchPoint_WebChat_Count_ActSuspect_Influence",
CASE WHEN infl_data."Marketing_TouchPoint_Date" <= act.SUSPECT_DATE_STAMP__C AND infl_data."InteractionType_Bizible_TouchPoint_WebForm_Count" > 0 THEN infl_data."InteractionType_Bizible_TouchPoint_WebForm_Count" ELSE 0 END AS "InteractionType_Bizibile-TouchPoint_WebForm_Count_ActSuspect_Influence",
CASE WHEN infl_data."Marketing_TouchPoint_Date" <= act.SUSPECT_DATE_STAMP__C AND infl_data."InteractionType_Bizible_TouchPoint_CRM_Count" > 0 THEN infl_data."InteractionType_Bizible_TouchPoint_CRM_Count" ELSE 0 END AS "InteractionType_Bizibile-TouchPoint_CRM_Count_ActSuspect_Influence",
CASE WHEN infl_data."Marketing_TouchPoint_Date" <= act.SUSPECT_DATE_STAMP__C AND infl_data."InteractionType_Bizible_TouchPoint_ConnectwithDM_Count" > 0 THEN infl_data."InteractionType_Bizible_TouchPoint_ConnectwithDM_Count" ELSE 0 END AS "InteractionType_Bizibile-TouchPoint_ConnectwithDM_Count_ActSuspect_Influence",
CASE WHEN infl_data."Marketing_TouchPoint_Date" <= act.SUSPECT_DATE_STAMP__C AND infl_data."InteractionType_Bizible_TouchPoint_CallSpokeWith_Count" > 0 THEN infl_data."InteractionType_Bizible_TouchPoint_CallSpokeWith_Count" ELSE 0 END AS "InteractionType_Bizibile-TouchPoint_CallSpokeWith_Count_ActSuspect_Influence",
CASE WHEN infl_data."Marketing_TouchPoint_Date" <= act.SUSPECT_DATE_STAMP__C AND infl_data."InteractionType_Bizible_TouchPoint_CallGatekeeper_Count" > 0 THEN infl_data."InteractionType_Bizible_TouchPoint_CallGatekeeper_Count" ELSE 0 END AS "InteractionType_Bizibile-TouchPoint_CallGatekeeper_Count_ActSuspect_Influence",
CASE WHEN infl_data."Marketing_TouchPoint_Date" <= act.SUSPECT_DATE_STAMP__C AND infl_data."InteractionType_Bizible_TouchPoint_NoLeadTouchPoints_Count" > 0 THEN infl_data."InteractionType_Bizible_TouchPoint_NoLeadTouchPoints_Count" ELSE 0 END AS "InteractionType_Bizibile-TouchPoint_NoLeadTouchPoint_Count_ActSuspect_Influence",
CASE WHEN infl_data."Marketing_TouchPoint_Date" <= act.SUSPECT_DATE_STAMP__C AND infl_data."InteractionType_Bizible_TouchPoint_Unclassified_Count" > 0 THEN infl_data."InteractionType_Bizible_TouchPoint_Unclassified_Count" ELSE 0 END AS "InteractionType_Bizibile-TouchPoint_Unclassified_Count_ActSuspect_Influence",

-- Influenced Before Accound Prospect
CASE WHEN infl_data."Marketing_TouchPoint_Date" <= act.PROSPECT_DATE_STAMP__C AND infl_data."InteractionType_6Sense_PaidMedia_Impressions_Count" > 0 THEN infl_data."InteractionType_6Sense_PaidMedia_Impressions_Count" ELSE 0 END AS "InteractionType_6Sense_PaidMedia_Impressions_Count_ActProspect_Influence",
CASE WHEN infl_data."Marketing_TouchPoint_Date" <= act.PROSPECT_DATE_STAMP__C AND infl_data."InteractionType_6Sense_PaidMedia_Clicks_Count" > 0 THEN infl_data."InteractionType_6Sense_PaidMedia_Clicks_Count" ELSE 0 END AS "InteractionType_6Sense_PaidMedia_Clicks_Count_ActProspect_Influence",
CASE WHEN infl_data."Marketing_TouchPoint_Date" <= act.PROSPECT_DATE_STAMP__C AND infl_data."InteractionType_6Sense_WebVisit_PageLoad_Count" > 0 THEN infl_data."InteractionType_6Sense_WebVisit_PageLoad_Count" ELSE 0 END AS "InteractionType_6Sense_WebVisit_PageLoad_Count_ActProspect_Influence",
CASE WHEN infl_data."Marketing_TouchPoint_Date" <= act.PROSPECT_DATE_STAMP__C AND infl_data."InteractionType_6Sense_WebVisit_Play_Count" > 0 THEN infl_data."InteractionType_6Sense_WebVisit_Play_Count" ELSE 0 END AS "InteractionType_6Sense_WebVisit_Play_Count_ActProspect_Influence",
CASE WHEN infl_data."Marketing_TouchPoint_Date" <= act.PROSPECT_DATE_STAMP__C AND infl_data."InteractionType_6Sense_WebVisit_Click_Count" > 0 THEN infl_data."InteractionType_6Sense_WebVisit_Click_Count" ELSE 0 END AS "InteractionType_6Sense_WebVisit_Click_Count_ActProspect_Influence",
CASE WHEN infl_data."Marketing_TouchPoint_Date" <= act.PROSPECT_DATE_STAMP__C AND infl_data."InteractionType_6Sense_WebVisit_Submit_Count" > 0 THEN infl_data."InteractionType_6Sense_WebVisit_Submit_Count" ELSE 0 END AS "InteractionType_6Sense_WebVisit_Submit_Count_ActProspect_Influence",
CASE WHEN infl_data."Marketing_TouchPoint_Date" <= act.PROSPECT_DATE_STAMP__C AND infl_data."InteractionType_6Sense_WebVisit_Unclassified_Count" > 0 THEN infl_data."InteractionType_6Sense_WebVisit_Unclassified_Count" ELSE 0 END AS "InteractionType_6Sense_WebVisit_Unclassified_Count_ActProspect_Influence",
CASE WHEN infl_data."Marketing_TouchPoint_Date" <= act.PROSPECT_DATE_STAMP__C AND infl_data."InteractionType_Bizible_TouchPoint_WebVisit_Count" > 0 THEN infl_data."InteractionType_Bizible_TouchPoint_WebVisit_Count" ELSE 0 END AS "InteractionType_Bizibile-TouchPoint_WebVisit_Count_ActProspect_Influence",
CASE WHEN infl_data."Marketing_TouchPoint_Date" <= act.PROSPECT_DATE_STAMP__C AND infl_data."InteractionType_Bizible_TouchPoint_WebChat_Count" > 0 THEN infl_data."InteractionType_Bizible_TouchPoint_WebChat_Count" ELSE 0 END AS "InteractionType_Bizibile-TouchPoint_WebChat_Count_ActProspect_Influence",
CASE WHEN infl_data."Marketing_TouchPoint_Date" <= act.PROSPECT_DATE_STAMP__C AND infl_data."InteractionType_Bizible_TouchPoint_WebForm_Count" > 0 THEN infl_data."InteractionType_Bizible_TouchPoint_WebForm_Count" ELSE 0 END AS "InteractionType_Bizibile-TouchPoint_WebForm_Count_ActProspect_Influence",
CASE WHEN infl_data."Marketing_TouchPoint_Date" <= act.PROSPECT_DATE_STAMP__C AND infl_data."InteractionType_Bizible_TouchPoint_CRM_Count" > 0 THEN infl_data."InteractionType_Bizible_TouchPoint_CRM_Count" ELSE 0 END AS "InteractionType_Bizibile-TouchPoint_CRM_Count_ActProspect_Influence",
CASE WHEN infl_data."Marketing_TouchPoint_Date" <= act.PROSPECT_DATE_STAMP__C AND infl_data."InteractionType_Bizible_TouchPoint_ConnectwithDM_Count" > 0 THEN infl_data."InteractionType_Bizible_TouchPoint_ConnectwithDM_Count" ELSE 0 END AS "InteractionType_Bizibile-TouchPoint_ConnectwithDM_Count_ActProspect_Influence",
CASE WHEN infl_data."Marketing_TouchPoint_Date" <= act.PROSPECT_DATE_STAMP__C AND infl_data."InteractionType_Bizible_TouchPoint_CallSpokeWith_Count" > 0 THEN infl_data."InteractionType_Bizible_TouchPoint_CallSpokeWith_Count" ELSE 0 END AS "InteractionType_Bizibile-TouchPoint_CallSpokeWith_Count_ActProspect_Influence",
CASE WHEN infl_data."Marketing_TouchPoint_Date" <= act.PROSPECT_DATE_STAMP__C AND infl_data."InteractionType_Bizible_TouchPoint_CallGatekeeper_Count" > 0 THEN infl_data."InteractionType_Bizible_TouchPoint_CallGatekeeper_Count" ELSE 0 END AS "InteractionType_Bizibile-TouchPoint_CallGatekeeper_Count_ActProspect_Influence",
CASE WHEN infl_data."Marketing_TouchPoint_Date" <= act.PROSPECT_DATE_STAMP__C AND infl_data."InteractionType_Bizible_TouchPoint_NoLeadTouchPoints_Count" > 0 THEN infl_data."InteractionType_Bizible_TouchPoint_NoLeadTouchPoints_Count" ELSE 0 END AS "InteractionType_Bizibile-TouchPoint_NoLeadTouchPoint_Count_ActProspect_Influence",
CASE WHEN infl_data."Marketing_TouchPoint_Date" <= act.PROSPECT_DATE_STAMP__C AND infl_data."InteractionType_Bizible_TouchPoint_Unclassified_Count" > 0 THEN infl_data."InteractionType_Bizible_TouchPoint_Unclassified_Count" ELSE 0 END AS "InteractionType_Bizibile-TouchPoint_Unclassified_Count_ActProspect_Influence",

CASE WHEN infl_data."CRM_ACCOUNT_ID" IS NULL THEN ''Salesforce.Opportunity'' ELSE infl_data."Acquisition_Channel" END AS "Acquisition_Channel",
CASE WHEN infl_data."CRM_ACCOUNT_ID" IS NULL THEN ''Salesforce'' ELSE SPLIT_PART(infl_data."Acquisition_Channel",''.'',1) END AS "Acquisition_Channel_TopLevel",

-- Influence Before Opp Created Date
CASE WHEN infl_data."Marketing_TouchPoint_Date" <= opp.CREATED_DATE AND SPLIT_PART(infl_data."Acquisition_Channel",''.'',1) = ''Channel Referral'' THEN 1 else 0 END AS "Flag_Influence_TouchPoint_by_AcquisitionChannelTopLevel_ChannelReferral",
CASE WHEN infl_data."Marketing_TouchPoint_Date" <= opp.CREATED_DATE AND SPLIT_PART(infl_data."Acquisition_Channel",''.'',1) = ''Content Syndication'' THEN 1 else 0 END AS "Flag_Influence_TouchPoint_by_AcquisitionChannelTopLevel_ContentSyndication",
CASE WHEN infl_data."Marketing_TouchPoint_Date" <= opp.CREATED_DATE AND SPLIT_PART(infl_data."Acquisition_Channel",''.'',1) = ''Sales Engagement'' THEN 1 else 0 END AS "Flag_Influence_TouchPoint_by_AcquisitionChannelTopLevel_SalesEngagement",
CASE WHEN infl_data."Marketing_TouchPoint_Date" <= opp.CREATED_DATE AND SPLIT_PART(infl_data."Acquisition_Channel",''.'',1) = ''Direct'' THEN 1 else 0 END AS "Flag_Influence_TouchPoint_by_AcquisitionChannelTopLevel_Direct",
CASE WHEN infl_data."Marketing_TouchPoint_Date" <= opp.CREATED_DATE AND SPLIT_PART(infl_data."Acquisition_Channel",''.'',1) = ''Direct Mail'' THEN 1 else 0 END AS "Flag_Influence_TouchPoint_by_AcquisitionChannelTopLevel_DirectMail",
CASE WHEN infl_data."Marketing_TouchPoint_Date" <= opp.CREATED_DATE AND SPLIT_PART(infl_data."Acquisition_Channel",''.'',1) = ''Display'' THEN 1 else 0 END AS "Flag_Influence_TouchPoint_by_AcquisitionChannelTopLevel_Display",
CASE WHEN infl_data."Marketing_TouchPoint_Date" <= opp.CREATED_DATE AND SPLIT_PART(infl_data."Acquisition_Channel",''.'',1) = ''Email'' THEN 1 else 0 END AS "Flag_Influence_TouchPoint_by_AcquisitionChannelTopLevel_Email",
CASE WHEN infl_data."Marketing_TouchPoint_Date" <= opp.CREATED_DATE AND SPLIT_PART(infl_data."Acquisition_Channel",''.'',1) = ''Lead Referral'' THEN 1 else 0 END AS "Flag_Influence_TouchPoint_by_AcquisitionChannelTopLevel_LeadReferral",
CASE WHEN infl_data."Marketing_TouchPoint_Date" <= opp.CREATED_DATE AND SPLIT_PART(infl_data."Acquisition_Channel",''.'',1) = ''Live Event'' THEN 1 else 0 END AS "Flag_Influence_TouchPoint_by_AcquisitionChannelTopLevel_LiveEvent",
CASE WHEN infl_data."Marketing_TouchPoint_Date" <= opp.CREATED_DATE AND SPLIT_PART(infl_data."Acquisition_Channel",''.'',1) = ''Lytx'' THEN 1 else 0 END AS "Flag_Influence_TouchPoint_by_AcquisitionChannelTopLevel_Lytx",
CASE WHEN infl_data."Marketing_TouchPoint_Date" <= opp.CREATED_DATE AND SPLIT_PART(infl_data."Acquisition_Channel",''.'',1) = ''Native'' THEN 1 else 0 END AS "Flag_Influence_TouchPoint_by_AcquisitionChannelTopLevel_Native",
CASE WHEN infl_data."Marketing_TouchPoint_Date" <= opp.CREATED_DATE AND SPLIT_PART(infl_data."Acquisition_Channel",''.'',1) = ''Organic Search'' THEN 1 else 0 END AS "Flag_Influence_TouchPoint_by_AcquisitionChannelTopLevel_OrganicSearch",
CASE WHEN infl_data."Marketing_TouchPoint_Date" <= opp.CREATED_DATE AND SPLIT_PART(infl_data."Acquisition_Channel",''.'',1) = ''Organic Social'' THEN 1 else 0 END AS "Flag_Influence_TouchPoint_by_AcquisitionChannelTopLevel_OrganicSocial",
CASE WHEN infl_data."Marketing_TouchPoint_Date" <= opp.CREATED_DATE AND SPLIT_PART(infl_data."Acquisition_Channel",''.'',1) = ''Other'' THEN 1 else 0 END AS "Flag_Influence_TouchPoint_by_AcquisitionChannelTopLevel_Other",
CASE WHEN infl_data."Marketing_TouchPoint_Date" <= opp.CREATED_DATE AND SPLIT_PART(infl_data."Acquisition_Channel",''.'',1) = ''Paid Media'' THEN 1 else 0 END AS "Flag_Influence_TouchPoint_by_AcquisitionChannelTopLevel_PaidMedia",
CASE WHEN infl_data."Marketing_TouchPoint_Date" <= opp.CREATED_DATE AND SPLIT_PART(infl_data."Acquisition_Channel",''.'',1) = ''Paid Search'' THEN 1 else 0 END AS "Flag_Influence_TouchPoint_by_AcquisitionChannelTopLevel_PaidSearch",
CASE WHEN infl_data."Marketing_TouchPoint_Date" <= opp.CREATED_DATE AND SPLIT_PART(infl_data."Acquisition_Channel",''.'',1) = ''Paid Social'' THEN 1 else 0 END AS "Flag_Influence_TouchPoint_by_AcquisitionChannelTopLevel_PaidSocial",
CASE WHEN infl_data."Marketing_TouchPoint_Date" <= opp.CREATED_DATE AND SPLIT_PART(infl_data."Acquisition_Channel",''.'',1) = ''Podcast'' THEN 1 else 0 END AS "Flag_Influence_TouchPoint_by_AcquisitionChannelTopLevel_Podcast",
CASE WHEN infl_data."Marketing_TouchPoint_Date" <= opp.CREATED_DATE AND SPLIT_PART(infl_data."Acquisition_Channel",''.'',1) = ''PPL'' THEN 1 else 0 END AS "Flag_Influence_TouchPoint_by_AcquisitionChannelTopLevel_PPL",
CASE WHEN infl_data."Marketing_TouchPoint_Date" <= opp.CREATED_DATE AND SPLIT_PART(infl_data."Acquisition_Channel",''.'',1) = ''Print'' THEN 1 else 0 END AS "Flag_Influence_TouchPoint_by_AcquisitionChannelTopLevel_Print",
CASE WHEN infl_data."Marketing_TouchPoint_Date" <= opp.CREATED_DATE AND SPLIT_PART(infl_data."Acquisition_Channel",''.'',1) = ''Sponsored Email'' THEN 1 else 0 END AS "Flag_Influence_TouchPoint_by_AcquisitionChannelTopLevel_SponsoredEmail",
CASE WHEN infl_data."Marketing_TouchPoint_Date" <= opp.CREATED_DATE AND SPLIT_PART(infl_data."Acquisition_Channel",''.'',1) = ''Tradeshow'' THEN 1 else 0 END AS "Flag_Influence_TouchPoint_by_AcquisitionChannelTopLevel_Tradeshow",
CASE WHEN infl_data."Marketing_TouchPoint_Date" <= opp.CREATED_DATE AND SPLIT_PART(infl_data."Acquisition_Channel",''.'',1) = ''Web Referral'' THEN 1 else 0 END AS "Flag_Influence_TouchPoint_by_AcquisitionChannelTopLevel_Web Referral",
CASE WHEN infl_data."Marketing_TouchPoint_Date" <= opp.CREATED_DATE AND SPLIT_PART(infl_data."Acquisition_Channel",''.'',1) = ''Webinar'' THEN 1 else 0 END AS "Flag_Influence_TouchPoint_by_AcquisitionChannelTopLevel_Webinar",

-- Influence Before Opp Closed Date
CASE WHEN infl_data."Marketing_TouchPoint_Date" <= opp.CLOSE_DATE AND SPLIT_PART(infl_data."Acquisition_Channel",''.'',1) = ''Channel Referral'' THEN 1 else 0 END AS "Flag_CLS_Influence_TouchPoint_by_AcquisitionChannelTopLevel_ChannelReferral",
CASE WHEN infl_data."Marketing_TouchPoint_Date" <= opp.CLOSE_DATE AND SPLIT_PART(infl_data."Acquisition_Channel",''.'',1) = ''Content Syndication'' THEN 1 else 0 END AS "Flag_CLS_Influence_TouchPoint_by_AcquisitionChannelTopLevel_ContentSyndication",
CASE WHEN infl_data."Marketing_TouchPoint_Date" <= opp.CLOSE_DATE AND SPLIT_PART(infl_data."Acquisition_Channel",''.'',1) = ''Sales Engagement'' THEN 1 else 0 END AS "Flag_CLS_Influence_TouchPoint_by_AcquisitionChannelTopLevel_SalesEngagement",
CASE WHEN infl_data."Marketing_TouchPoint_Date" <= opp.CLOSE_DATE AND SPLIT_PART(infl_data."Acquisition_Channel",''.'',1) = ''Direct'' THEN 1 else 0 END AS "Flag_CLS_Influence_TouchPoint_by_AcquisitionChannelTopLevel_Direct",
CASE WHEN infl_data."Marketing_TouchPoint_Date" <= opp.CLOSE_DATE AND SPLIT_PART(infl_data."Acquisition_Channel",''.'',1) = ''Direct Mail'' THEN 1 else 0 END AS "Flag_CLS_Influence_TouchPoint_by_AcquisitionChannelTopLevel_DirectMail",
CASE WHEN infl_data."Marketing_TouchPoint_Date" <= opp.CLOSE_DATE AND SPLIT_PART(infl_data."Acquisition_Channel",''.'',1) = ''Display'' THEN 1 else 0 END AS "Flag_CLS_Influence_TouchPoint_by_AcquisitionChannelTopLevel_Display",
CASE WHEN infl_data."Marketing_TouchPoint_Date" <= opp.CLOSE_DATE AND SPLIT_PART(infl_data."Acquisition_Channel",''.'',1) = ''Email'' THEN 1 else 0 END AS "Flag_CLS_Influence_TouchPoint_by_AcquisitionChannelTopLevel_Email",
CASE WHEN infl_data."Marketing_TouchPoint_Date" <= opp.CLOSE_DATE AND SPLIT_PART(infl_data."Acquisition_Channel",''.'',1) = ''Lead Referral'' THEN 1 else 0 END AS "Flag_CLS_Influence_TouchPoint_by_AcquisitionChannelTopLevel_LeadReferral",
CASE WHEN infl_data."Marketing_TouchPoint_Date" <= opp.CLOSE_DATE AND SPLIT_PART(infl_data."Acquisition_Channel",''.'',1) = ''Live Event'' THEN 1 else 0 END AS "Flag_CLS_Influence_TouchPoint_by_AcquisitionChannelTopLevel_LiveEvent",
CASE WHEN infl_data."Marketing_TouchPoint_Date" <= opp.CLOSE_DATE AND SPLIT_PART(infl_data."Acquisition_Channel",''.'',1) = ''Lytx'' THEN 1 else 0 END AS "Flag_CLS_Influence_TouchPoint_by_AcquisitionChannelTopLevel_Lytx",
CASE WHEN infl_data."Marketing_TouchPoint_Date" <= opp.CLOSE_DATE AND SPLIT_PART(infl_data."Acquisition_Channel",''.'',1) = ''Native'' THEN 1 else 0 END AS "Flag_CLS_Influence_TouchPoint_by_AcquisitionChannelTopLevel_Native",
CASE WHEN infl_data."Marketing_TouchPoint_Date" <= opp.CLOSE_DATE AND SPLIT_PART(infl_data."Acquisition_Channel",''.'',1) = ''Organic Search'' THEN 1 else 0 END AS "Flag_CLS_Influence_TouchPoint_by_AcquisitionChannelTopLevel_OrganicSearch",
CASE WHEN infl_data."Marketing_TouchPoint_Date" <= opp.CLOSE_DATE AND SPLIT_PART(infl_data."Acquisition_Channel",''.'',1) = ''Organic Social'' THEN 1 else 0 END AS "Flag_CLS_Influence_TouchPoint_by_AcquisitionChannelTopLevel_OrganicSocial",
CASE WHEN infl_data."Marketing_TouchPoint_Date" <= opp.CLOSE_DATE AND SPLIT_PART(infl_data."Acquisition_Channel",''.'',1) = ''Other'' THEN 1 else 0 END AS "Flag_CLS_Influence_TouchPoint_by_AcquisitionChannelTopLevel_Other",
CASE WHEN infl_data."Marketing_TouchPoint_Date" <= opp.CLOSE_DATE AND SPLIT_PART(infl_data."Acquisition_Channel",''.'',1) = ''Paid Media'' THEN 1 else 0 END AS "Flag_CLS_Influence_TouchPoint_by_AcquisitionChannelTopLevel_PaidMedia",
CASE WHEN infl_data."Marketing_TouchPoint_Date" <= opp.CLOSE_DATE AND SPLIT_PART(infl_data."Acquisition_Channel",''.'',1) = ''Paid Search'' THEN 1 else 0 END AS "Flag_CLS_Influence_TouchPoint_by_AcquisitionChannelTopLevel_PaidSearch",
CASE WHEN infl_data."Marketing_TouchPoint_Date" <= opp.CLOSE_DATE AND SPLIT_PART(infl_data."Acquisition_Channel",''.'',1) = ''Paid Social'' THEN 1 else 0 END AS "Flag_CLS_Influence_TouchPoint_by_AcquisitionChannelTopLevel_PaidSocial",
CASE WHEN infl_data."Marketing_TouchPoint_Date" <= opp.CLOSE_DATE AND SPLIT_PART(infl_data."Acquisition_Channel",''.'',1) = ''Podcast'' THEN 1 else 0 END AS "Flag_CLS_Influence_TouchPoint_by_AcquisitionChannelTopLevel_Podcast",
CASE WHEN infl_data."Marketing_TouchPoint_Date" <= opp.CLOSE_DATE AND SPLIT_PART(infl_data."Acquisition_Channel",''.'',1) = ''PPL'' THEN 1 else 0 END AS "Flag_CLS_Influence_TouchPoint_by_AcquisitionChannelTopLevel_PPL",
CASE WHEN infl_data."Marketing_TouchPoint_Date" <= opp.CLOSE_DATE AND SPLIT_PART(infl_data."Acquisition_Channel",''.'',1) = ''Print'' THEN 1 else 0 END AS "Flag_CLS_Influence_TouchPoint_by_AcquisitionChannelTopLevel_Print",
CASE WHEN infl_data."Marketing_TouchPoint_Date" <= opp.CLOSE_DATE AND SPLIT_PART(infl_data."Acquisition_Channel",''.'',1) = ''Sponsored Email'' THEN 1 else 0 END AS "Flag_CLS_Influence_TouchPoint_by_AcquisitionChannelTopLevel_SponsoredEmail",
CASE WHEN infl_data."Marketing_TouchPoint_Date" <= opp.CLOSE_DATE AND SPLIT_PART(infl_data."Acquisition_Channel",''.'',1) = ''Tradeshow'' THEN 1 else 0 END AS "Flag_CLS_Influence_TouchPoint_by_AcquisitionChannelTopLevel_Tradeshow",
CASE WHEN infl_data."Marketing_TouchPoint_Date" <= opp.CLOSE_DATE AND SPLIT_PART(infl_data."Acquisition_Channel",''.'',1) = ''Web Referral'' THEN 1 else 0 END AS "Flag_CLS_Influence_TouchPoint_by_AcquisitionChannelTopLevel_Web Referral",
CASE WHEN infl_data."Marketing_TouchPoint_Date" <= opp.CLOSE_DATE AND SPLIT_PART(infl_data."Acquisition_Channel",''.'',1) = ''Webinar'' THEN 1 else 0 END AS "Flag_CLS_Influence_TouchPoint_by_AcquisitionChannelTopLevel_Webinar",

-- Influence Before Account Cold Date
CASE WHEN infl_data."Marketing_TouchPoint_Date" <= act.COLD_ACCOUNT_DATE_STAMP__C AND SPLIT_PART(infl_data."Acquisition_Channel",''.'',1) = ''Channel Referral'' THEN 1 else 0 END AS "Flag_ActCold_Influence_TouchPoint_by_AcquisitionChannelTopLevel_ChannelReferral",
CASE WHEN infl_data."Marketing_TouchPoint_Date" <= act.COLD_ACCOUNT_DATE_STAMP__C AND SPLIT_PART(infl_data."Acquisition_Channel",''.'',1) = ''Content Syndication'' THEN 1 else 0 END AS "Flag_ActCold_Influence_TouchPoint_by_AcquisitionChannelTopLevel_ContentSyndication",
CASE WHEN infl_data."Marketing_TouchPoint_Date" <= act.COLD_ACCOUNT_DATE_STAMP__C AND SPLIT_PART(infl_data."Acquisition_Channel",''.'',1) = ''Sales Engagement'' THEN 1 else 0 END AS "Flag_ActCold_Influence_TouchPoint_by_AcquisitionChannelTopLevel_SalesEngagement",
CASE WHEN infl_data."Marketing_TouchPoint_Date" <= act.COLD_ACCOUNT_DATE_STAMP__C AND SPLIT_PART(infl_data."Acquisition_Channel",''.'',1) = ''Direct'' THEN 1 else 0 END AS "Flag_ActCold_Influence_TouchPoint_by_AcquisitionChannelTopLevel_Direct",
CASE WHEN infl_data."Marketing_TouchPoint_Date" <= act.COLD_ACCOUNT_DATE_STAMP__C AND SPLIT_PART(infl_data."Acquisition_Channel",''.'',1) = ''Direct Mail'' THEN 1 else 0 END AS "Flag_ActCold_Influence_TouchPoint_by_AcquisitionChannelTopLevel_DirectMail",
CASE WHEN infl_data."Marketing_TouchPoint_Date" <= act.COLD_ACCOUNT_DATE_STAMP__C AND SPLIT_PART(infl_data."Acquisition_Channel",''.'',1) = ''Display'' THEN 1 else 0 END AS "Flag_ActCold_Influence_TouchPoint_by_AcquisitionChannelTopLevel_Display",
CASE WHEN infl_data."Marketing_TouchPoint_Date" <= act.COLD_ACCOUNT_DATE_STAMP__C AND SPLIT_PART(infl_data."Acquisition_Channel",''.'',1) = ''Email'' THEN 1 else 0 END AS "Flag_ActCold_Influence_TouchPoint_by_AcquisitionChannelTopLevel_Email",
CASE WHEN infl_data."Marketing_TouchPoint_Date" <= act.COLD_ACCOUNT_DATE_STAMP__C AND SPLIT_PART(infl_data."Acquisition_Channel",''.'',1) = ''Lead Referral'' THEN 1 else 0 END AS "Flag_ActCold_Influence_TouchPoint_by_AcquisitionChannelTopLevel_LeadReferral",
CASE WHEN infl_data."Marketing_TouchPoint_Date" <= act.COLD_ACCOUNT_DATE_STAMP__C AND SPLIT_PART(infl_data."Acquisition_Channel",''.'',1) = ''Live Event'' THEN 1 else 0 END AS "Flag_ActCold_Influence_TouchPoint_by_AcquisitionChannelTopLevel_LiveEvent",
CASE WHEN infl_data."Marketing_TouchPoint_Date" <= act.COLD_ACCOUNT_DATE_STAMP__C AND SPLIT_PART(infl_data."Acquisition_Channel",''.'',1) = ''Lytx'' THEN 1 else 0 END AS "Flag_ActCold_Influence_TouchPoint_by_AcquisitionChannelTopLevel_Lytx",
CASE WHEN infl_data."Marketing_TouchPoint_Date" <= act.COLD_ACCOUNT_DATE_STAMP__C AND SPLIT_PART(infl_data."Acquisition_Channel",''.'',1) = ''Native'' THEN 1 else 0 END AS "Flag_ActCold_Influence_TouchPoint_by_AcquisitionChannelTopLevel_Native",
CASE WHEN infl_data."Marketing_TouchPoint_Date" <= act.COLD_ACCOUNT_DATE_STAMP__C AND SPLIT_PART(infl_data."Acquisition_Channel",''.'',1) = ''Organic Search'' THEN 1 else 0 END AS "Flag_ActCold_Influence_TouchPoint_by_AcquisitionChannelTopLevel_OrganicSearch",
CASE WHEN infl_data."Marketing_TouchPoint_Date" <= act.COLD_ACCOUNT_DATE_STAMP__C AND SPLIT_PART(infl_data."Acquisition_Channel",''.'',1) = ''Organic Social'' THEN 1 else 0 END AS "Flag_ActCold_Influence_TouchPoint_by_AcquisitionChannelTopLevel_OrganicSocial",
CASE WHEN infl_data."Marketing_TouchPoint_Date" <= act.COLD_ACCOUNT_DATE_STAMP__C AND SPLIT_PART(infl_data."Acquisition_Channel",''.'',1) = ''Other'' THEN 1 else 0 END AS "Flag_ActCold_Influence_TouchPoint_by_AcquisitionChannelTopLevel_Other",
CASE WHEN infl_data."Marketing_TouchPoint_Date" <= act.COLD_ACCOUNT_DATE_STAMP__C AND SPLIT_PART(infl_data."Acquisition_Channel",''.'',1) = ''Paid Media'' THEN 1 else 0 END AS "Flag_ActCold_Influence_TouchPoint_by_AcquisitionChannelTopLevel_PaidMedia",
CASE WHEN infl_data."Marketing_TouchPoint_Date" <= act.COLD_ACCOUNT_DATE_STAMP__C AND SPLIT_PART(infl_data."Acquisition_Channel",''.'',1) = ''Paid Search'' THEN 1 else 0 END AS "Flag_ActCold_Influence_TouchPoint_by_AcquisitionChannelTopLevel_PaidSearch",
CASE WHEN infl_data."Marketing_TouchPoint_Date" <= act.COLD_ACCOUNT_DATE_STAMP__C AND SPLIT_PART(infl_data."Acquisition_Channel",''.'',1) = ''Paid Social'' THEN 1 else 0 END AS "Flag_ActCold_Influence_TouchPoint_by_AcquisitionChannelTopLevel_PaidSocial",
CASE WHEN infl_data."Marketing_TouchPoint_Date" <= act.COLD_ACCOUNT_DATE_STAMP__C AND SPLIT_PART(infl_data."Acquisition_Channel",''.'',1) = ''Podcast'' THEN 1 else 0 END AS "Flag_ActCold_Influence_TouchPoint_by_AcquisitionChannelTopLevel_Podcast",
CASE WHEN infl_data."Marketing_TouchPoint_Date" <= act.COLD_ACCOUNT_DATE_STAMP__C AND SPLIT_PART(infl_data."Acquisition_Channel",''.'',1) = ''PPL'' THEN 1 else 0 END AS "Flag_ActCold_Influence_TouchPoint_by_AcquisitionChannelTopLevel_PPL",
CASE WHEN infl_data."Marketing_TouchPoint_Date" <= act.COLD_ACCOUNT_DATE_STAMP__C AND SPLIT_PART(infl_data."Acquisition_Channel",''.'',1) = ''Print'' THEN 1 else 0 END AS "Flag_ActCold_Influence_TouchPoint_by_AcquisitionChannelTopLevel_Print",
CASE WHEN infl_data."Marketing_TouchPoint_Date" <= act.COLD_ACCOUNT_DATE_STAMP__C AND SPLIT_PART(infl_data."Acquisition_Channel",''.'',1) = ''Sponsored Email'' THEN 1 else 0 END AS "Flag_ActCold_Influence_TouchPoint_by_AcquisitionChannelTopLevel_SponsoredEmail",
CASE WHEN infl_data."Marketing_TouchPoint_Date" <= act.COLD_ACCOUNT_DATE_STAMP__C AND SPLIT_PART(infl_data."Acquisition_Channel",''.'',1) = ''Tradeshow'' THEN 1 else 0 END AS "Flag_ActCold_Influence_TouchPoint_by_AcquisitionChannelTopLevel_Tradeshow",
CASE WHEN infl_data."Marketing_TouchPoint_Date" <= act.COLD_ACCOUNT_DATE_STAMP__C AND SPLIT_PART(infl_data."Acquisition_Channel",''.'',1) = ''Web Referral'' THEN 1 else 0 END AS "Flag_ActCold_Influence_TouchPoint_by_AcquisitionChannelTopLevel_Web Referral",
CASE WHEN infl_data."Marketing_TouchPoint_Date" <= act.COLD_ACCOUNT_DATE_STAMP__C AND SPLIT_PART(infl_data."Acquisition_Channel",''.'',1) = ''Webinar'' THEN 1 else 0 END AS "Flag_ActCold_Influence_TouchPoint_by_AcquisitionChannelTopLevel_Webinar",

-- Influence Before Account MEA Date
CASE WHEN infl_data."Marketing_TouchPoint_Date" <= act.MEA_DATE_STAMP__C AND SPLIT_PART(infl_data."Acquisition_Channel",''.'',1) = ''Channel Referral'' THEN 1 else 0 END AS "Flag_ActMEA_Influence_TouchPoint_by_AcquisitionChannelTopLevel_ChannelReferral",
CASE WHEN infl_data."Marketing_TouchPoint_Date" <= act.MEA_DATE_STAMP__C AND SPLIT_PART(infl_data."Acquisition_Channel",''.'',1) = ''Content Syndication'' THEN 1 else 0 END AS "Flag_ActMEA_Influence_TouchPoint_by_AcquisitionChannelTopLevel_ContentSyndication",
CASE WHEN infl_data."Marketing_TouchPoint_Date" <= act.MEA_DATE_STAMP__C AND SPLIT_PART(infl_data."Acquisition_Channel",''.'',1) = ''Sales Engagement'' THEN 1 else 0 END AS "Flag_ActMEA_Influence_TouchPoint_by_AcquisitionChannelTopLevel_SalesEngagement",
CASE WHEN infl_data."Marketing_TouchPoint_Date" <= act.MEA_DATE_STAMP__C AND SPLIT_PART(infl_data."Acquisition_Channel",''.'',1) = ''Direct'' THEN 1 else 0 END AS "Flag_ActMEA_Influence_TouchPoint_by_AcquisitionChannelTopLevel_Direct",
CASE WHEN infl_data."Marketing_TouchPoint_Date" <= act.MEA_DATE_STAMP__C AND SPLIT_PART(infl_data."Acquisition_Channel",''.'',1) = ''Direct Mail'' THEN 1 else 0 END AS "Flag_ActMEA_Influence_TouchPoint_by_AcquisitionChannelTopLevel_DirectMail",
CASE WHEN infl_data."Marketing_TouchPoint_Date" <= act.MEA_DATE_STAMP__C AND SPLIT_PART(infl_data."Acquisition_Channel",''.'',1) = ''Display'' THEN 1 else 0 END AS "Flag_ActMEA_Influence_TouchPoint_by_AcquisitionChannelTopLevel_Display",
CASE WHEN infl_data."Marketing_TouchPoint_Date" <= act.MEA_DATE_STAMP__C AND SPLIT_PART(infl_data."Acquisition_Channel",''.'',1) = ''Email'' THEN 1 else 0 END AS "Flag_ActMEA_Influence_TouchPoint_by_AcquisitionChannelTopLevel_Email",
CASE WHEN infl_data."Marketing_TouchPoint_Date" <= act.MEA_DATE_STAMP__C AND SPLIT_PART(infl_data."Acquisition_Channel",''.'',1) = ''Lead Referral'' THEN 1 else 0 END AS "Flag_ActMEA_Influence_TouchPoint_by_AcquisitionChannelTopLevel_LeadReferral",
CASE WHEN infl_data."Marketing_TouchPoint_Date" <= act.MEA_DATE_STAMP__C AND SPLIT_PART(infl_data."Acquisition_Channel",''.'',1) = ''Live Event'' THEN 1 else 0 END AS "Flag_ActMEA_Influence_TouchPoint_by_AcquisitionChannelTopLevel_LiveEvent",
CASE WHEN infl_data."Marketing_TouchPoint_Date" <= act.MEA_DATE_STAMP__C AND SPLIT_PART(infl_data."Acquisition_Channel",''.'',1) = ''Lytx'' THEN 1 else 0 END AS "Flag_ActMEA_Influence_TouchPoint_by_AcquisitionChannelTopLevel_Lytx",
CASE WHEN infl_data."Marketing_TouchPoint_Date" <= act.MEA_DATE_STAMP__C AND SPLIT_PART(infl_data."Acquisition_Channel",''.'',1) = ''Native'' THEN 1 else 0 END AS "Flag_ActMEA_Influence_TouchPoint_by_AcquisitionChannelTopLevel_Native",
CASE WHEN infl_data."Marketing_TouchPoint_Date" <= act.MEA_DATE_STAMP__C AND SPLIT_PART(infl_data."Acquisition_Channel",''.'',1) = ''Organic Search'' THEN 1 else 0 END AS "Flag_ActMEA_Influence_TouchPoint_by_AcquisitionChannelTopLevel_OrganicSearch",
CASE WHEN infl_data."Marketing_TouchPoint_Date" <= act.MEA_DATE_STAMP__C AND SPLIT_PART(infl_data."Acquisition_Channel",''.'',1) = ''Organic Social'' THEN 1 else 0 END AS "Flag_ActMEA_Influence_TouchPoint_by_AcquisitionChannelTopLevel_OrganicSocial",
CASE WHEN infl_data."Marketing_TouchPoint_Date" <= act.MEA_DATE_STAMP__C AND SPLIT_PART(infl_data."Acquisition_Channel",''.'',1) = ''Other'' THEN 1 else 0 END AS "Flag_ActMEA_Influence_TouchPoint_by_AcquisitionChannelTopLevel_Other",
CASE WHEN infl_data."Marketing_TouchPoint_Date" <= act.MEA_DATE_STAMP__C AND SPLIT_PART(infl_data."Acquisition_Channel",''.'',1) = ''Paid Media'' THEN 1 else 0 END AS "Flag_ActMEA_Influence_TouchPoint_by_AcquisitionChannelTopLevel_PaidMedia",
CASE WHEN infl_data."Marketing_TouchPoint_Date" <= act.MEA_DATE_STAMP__C AND SPLIT_PART(infl_data."Acquisition_Channel",''.'',1) = ''Paid Search'' THEN 1 else 0 END AS "Flag_ActMEA_Influence_TouchPoint_by_AcquisitionChannelTopLevel_PaidSearch",
CASE WHEN infl_data."Marketing_TouchPoint_Date" <= act.MEA_DATE_STAMP__C AND SPLIT_PART(infl_data."Acquisition_Channel",''.'',1) = ''Paid Social'' THEN 1 else 0 END AS "Flag_ActMEA_Influence_TouchPoint_by_AcquisitionChannelTopLevel_PaidSocial",
CASE WHEN infl_data."Marketing_TouchPoint_Date" <= act.MEA_DATE_STAMP__C AND SPLIT_PART(infl_data."Acquisition_Channel",''.'',1) = ''Podcast'' THEN 1 else 0 END AS "Flag_ActMEA_Influence_TouchPoint_by_AcquisitionChannelTopLevel_Podcast",
CASE WHEN infl_data."Marketing_TouchPoint_Date" <= act.MEA_DATE_STAMP__C AND SPLIT_PART(infl_data."Acquisition_Channel",''.'',1) = ''PPL'' THEN 1 else 0 END AS "Flag_ActMEA_Influence_TouchPoint_by_AcquisitionChannelTopLevel_PPL",
CASE WHEN infl_data."Marketing_TouchPoint_Date" <= act.MEA_DATE_STAMP__C AND SPLIT_PART(infl_data."Acquisition_Channel",''.'',1) = ''Print'' THEN 1 else 0 END AS "Flag_ActMEA_Influence_TouchPoint_by_AcquisitionChannelTopLevel_Print",
CASE WHEN infl_data."Marketing_TouchPoint_Date" <= act.MEA_DATE_STAMP__C AND SPLIT_PART(infl_data."Acquisition_Channel",''.'',1) = ''Sponsored Email'' THEN 1 else 0 END AS "Flag_ActMEA_Influence_TouchPoint_by_AcquisitionChannelTopLevel_SponsoredEmail",
CASE WHEN infl_data."Marketing_TouchPoint_Date" <= act.MEA_DATE_STAMP__C AND SPLIT_PART(infl_data."Acquisition_Channel",''.'',1) = ''Tradeshow'' THEN 1 else 0 END AS "Flag_ActMEA_Influence_TouchPoint_by_AcquisitionChannelTopLevel_Tradeshow",
CASE WHEN infl_data."Marketing_TouchPoint_Date" <= act.MEA_DATE_STAMP__C AND SPLIT_PART(infl_data."Acquisition_Channel",''.'',1) = ''Web Referral'' THEN 1 else 0 END AS "Flag_ActMEA_Influence_TouchPoint_by_AcquisitionChannelTopLevel_Web Referral",
CASE WHEN infl_data."Marketing_TouchPoint_Date" <= act.MEA_DATE_STAMP__C AND SPLIT_PART(infl_data."Acquisition_Channel",''.'',1) = ''Webinar'' THEN 1 else 0 END AS "Flag_ActMEA_Influence_TouchPoint_by_AcquisitionChannelTopLevel_Webinar",

-- Influence Before Account MQA Date
CASE WHEN infl_data."Marketing_TouchPoint_Date" <= act.MQA_DATE_STAMP__C AND SPLIT_PART(infl_data."Acquisition_Channel",''.'',1) = ''Channel Referral'' THEN 1 else 0 END AS "Flag_ActMQA_Influence_TouchPoint_by_AcquisitionChannelTopLevel_ChannelReferral",
CASE WHEN infl_data."Marketing_TouchPoint_Date" <= act.MQA_DATE_STAMP__C AND SPLIT_PART(infl_data."Acquisition_Channel",''.'',1) = ''Content Syndication'' THEN 1 else 0 END AS "Flag_ActMQA_Influence_TouchPoint_by_AcquisitionChannelTopLevel_ContentSyndication",
CASE WHEN infl_data."Marketing_TouchPoint_Date" <= act.MQA_DATE_STAMP__C AND SPLIT_PART(infl_data."Acquisition_Channel",''.'',1) = ''Sales Engagement'' THEN 1 else 0 END AS "Flag_ActMQA_Influence_TouchPoint_by_AcquisitionChannelTopLevel_SalesEngagement",
CASE WHEN infl_data."Marketing_TouchPoint_Date" <= act.MQA_DATE_STAMP__C AND SPLIT_PART(infl_data."Acquisition_Channel",''.'',1) = ''Direct'' THEN 1 else 0 END AS "Flag_ActMQA_Influence_TouchPoint_by_AcquisitionChannelTopLevel_Direct",
CASE WHEN infl_data."Marketing_TouchPoint_Date" <= act.MQA_DATE_STAMP__C AND SPLIT_PART(infl_data."Acquisition_Channel",''.'',1) = ''Direct Mail'' THEN 1 else 0 END AS "Flag_ActMQA_Influence_TouchPoint_by_AcquisitionChannelTopLevel_DirectMail",
CASE WHEN infl_data."Marketing_TouchPoint_Date" <= act.MQA_DATE_STAMP__C AND SPLIT_PART(infl_data."Acquisition_Channel",''.'',1) = ''Display'' THEN 1 else 0 END AS "Flag_ActMQA_Influence_TouchPoint_by_AcquisitionChannelTopLevel_Display",
CASE WHEN infl_data."Marketing_TouchPoint_Date" <= act.MQA_DATE_STAMP__C AND SPLIT_PART(infl_data."Acquisition_Channel",''.'',1) = ''Email'' THEN 1 else 0 END AS "Flag_ActMQA_Influence_TouchPoint_by_AcquisitionChannelTopLevel_Email",
CASE WHEN infl_data."Marketing_TouchPoint_Date" <= act.MQA_DATE_STAMP__C AND SPLIT_PART(infl_data."Acquisition_Channel",''.'',1) = ''Lead Referral'' THEN 1 else 0 END AS "Flag_ActMQA_Influence_TouchPoint_by_AcquisitionChannelTopLevel_LeadReferral",
CASE WHEN infl_data."Marketing_TouchPoint_Date" <= act.MQA_DATE_STAMP__C AND SPLIT_PART(infl_data."Acquisition_Channel",''.'',1) = ''Live Event'' THEN 1 else 0 END AS "Flag_ActMQA_Influence_TouchPoint_by_AcquisitionChannelTopLevel_LiveEvent",
CASE WHEN infl_data."Marketing_TouchPoint_Date" <= act.MQA_DATE_STAMP__C AND SPLIT_PART(infl_data."Acquisition_Channel",''.'',1) = ''Lytx'' THEN 1 else 0 END AS "Flag_ActMQA_Influence_TouchPoint_by_AcquisitionChannelTopLevel_Lytx",
CASE WHEN infl_data."Marketing_TouchPoint_Date" <= act.MQA_DATE_STAMP__C AND SPLIT_PART(infl_data."Acquisition_Channel",''.'',1) = ''Native'' THEN 1 else 0 END AS "Flag_ActMQA_Influence_TouchPoint_by_AcquisitionChannelTopLevel_Native",
CASE WHEN infl_data."Marketing_TouchPoint_Date" <= act.MQA_DATE_STAMP__C AND SPLIT_PART(infl_data."Acquisition_Channel",''.'',1) = ''Organic Search'' THEN 1 else 0 END AS "Flag_ActMQA_Influence_TouchPoint_by_AcquisitionChannelTopLevel_OrganicSearch",
CASE WHEN infl_data."Marketing_TouchPoint_Date" <= act.MQA_DATE_STAMP__C AND SPLIT_PART(infl_data."Acquisition_Channel",''.'',1) = ''Organic Social'' THEN 1 else 0 END AS "Flag_ActMQA_Influence_TouchPoint_by_AcquisitionChannelTopLevel_OrganicSocial",
CASE WHEN infl_data."Marketing_TouchPoint_Date" <= act.MQA_DATE_STAMP__C AND SPLIT_PART(infl_data."Acquisition_Channel",''.'',1) = ''Other'' THEN 1 else 0 END AS "Flag_ActMQA_Influence_TouchPoint_by_AcquisitionChannelTopLevel_Other",
CASE WHEN infl_data."Marketing_TouchPoint_Date" <= act.MQA_DATE_STAMP__C AND SPLIT_PART(infl_data."Acquisition_Channel",''.'',1) = ''Paid Media'' THEN 1 else 0 END AS "Flag_ActMQA_Influence_TouchPoint_by_AcquisitionChannelTopLevel_PaidMedia",
CASE WHEN infl_data."Marketing_TouchPoint_Date" <= act.MQA_DATE_STAMP__C AND SPLIT_PART(infl_data."Acquisition_Channel",''.'',1) = ''Paid Search'' THEN 1 else 0 END AS "Flag_ActMQA_Influence_TouchPoint_by_AcquisitionChannelTopLevel_PaidSearch",
CASE WHEN infl_data."Marketing_TouchPoint_Date" <= act.MQA_DATE_STAMP__C AND SPLIT_PART(infl_data."Acquisition_Channel",''.'',1) = ''Paid Social'' THEN 1 else 0 END AS "Flag_ActMQA_Influence_TouchPoint_by_AcquisitionChannelTopLevel_PaidSocial",
CASE WHEN infl_data."Marketing_TouchPoint_Date" <= act.MQA_DATE_STAMP__C AND SPLIT_PART(infl_data."Acquisition_Channel",''.'',1) = ''Podcast'' THEN 1 else 0 END AS "Flag_ActMQA_Influence_TouchPoint_by_AcquisitionChannelTopLevel_Podcast",
CASE WHEN infl_data."Marketing_TouchPoint_Date" <= act.MQA_DATE_STAMP__C AND SPLIT_PART(infl_data."Acquisition_Channel",''.'',1) = ''PPL'' THEN 1 else 0 END AS "Flag_ActMQA_Influence_TouchPoint_by_AcquisitionChannelTopLevel_PPL",
CASE WHEN infl_data."Marketing_TouchPoint_Date" <= act.MQA_DATE_STAMP__C AND SPLIT_PART(infl_data."Acquisition_Channel",''.'',1) = ''Print'' THEN 1 else 0 END AS "Flag_ActMQA_Influence_TouchPoint_by_AcquisitionChannelTopLevel_Print",
CASE WHEN infl_data."Marketing_TouchPoint_Date" <= act.MQA_DATE_STAMP__C AND SPLIT_PART(infl_data."Acquisition_Channel",''.'',1) = ''Sponsored Email'' THEN 1 else 0 END AS "Flag_ActMQA_Influence_TouchPoint_by_AcquisitionChannelTopLevel_SponsoredEmail",
CASE WHEN infl_data."Marketing_TouchPoint_Date" <= act.MQA_DATE_STAMP__C AND SPLIT_PART(infl_data."Acquisition_Channel",''.'',1) = ''Tradeshow'' THEN 1 else 0 END AS "Flag_ActMQA_Influence_TouchPoint_by_AcquisitionChannelTopLevel_Tradeshow",
CASE WHEN infl_data."Marketing_TouchPoint_Date" <= act.MQA_DATE_STAMP__C AND SPLIT_PART(infl_data."Acquisition_Channel",''.'',1) = ''Web Referral'' THEN 1 else 0 END AS "Flag_ActMQA_Influence_TouchPoint_by_AcquisitionChannelTopLevel_Web Referral",
CASE WHEN infl_data."Marketing_TouchPoint_Date" <= act.MQA_DATE_STAMP__C AND SPLIT_PART(infl_data."Acquisition_Channel",''.'',1) = ''Webinar'' THEN 1 else 0 END AS "Flag_ActMQA_Influence_TouchPoint_by_AcquisitionChannelTopLevel_Webinar",

-- Influence Before Account Suspect Date
CASE WHEN infl_data."Marketing_TouchPoint_Date" <= act.SUSPECT_DATE_STAMP__C AND SPLIT_PART(infl_data."Acquisition_Channel",''.'',1) = ''Channel Referral'' THEN 1 else 0 END AS "Flag_ActSuspect_Influence_TouchPoint_by_AcquisitionChannelTopLevel_ChannelReferral",
CASE WHEN infl_data."Marketing_TouchPoint_Date" <= act.SUSPECT_DATE_STAMP__C AND SPLIT_PART(infl_data."Acquisition_Channel",''.'',1) = ''Content Syndication'' THEN 1 else 0 END AS "Flag_ActSuspect_Influence_TouchPoint_by_AcquisitionChannelTopLevel_ContentSyndication",
CASE WHEN infl_data."Marketing_TouchPoint_Date" <= act.SUSPECT_DATE_STAMP__C AND SPLIT_PART(infl_data."Acquisition_Channel",''.'',1) = ''Sales Engagement'' THEN 1 else 0 END AS "Flag_ActSuspect_Influence_TouchPoint_by_AcquisitionChannelTopLevel_SalesEngagement",
CASE WHEN infl_data."Marketing_TouchPoint_Date" <= act.SUSPECT_DATE_STAMP__C AND SPLIT_PART(infl_data."Acquisition_Channel",''.'',1) = ''Direct'' THEN 1 else 0 END AS "Flag_ActSuspect_Influence_TouchPoint_by_AcquisitionChannelTopLevel_Direct",
CASE WHEN infl_data."Marketing_TouchPoint_Date" <= act.SUSPECT_DATE_STAMP__C AND SPLIT_PART(infl_data."Acquisition_Channel",''.'',1) = ''Direct Mail'' THEN 1 else 0 END AS "Flag_ActSuspect_Influence_TouchPoint_by_AcquisitionChannelTopLevel_DirectMail",
CASE WHEN infl_data."Marketing_TouchPoint_Date" <= act.SUSPECT_DATE_STAMP__C AND SPLIT_PART(infl_data."Acquisition_Channel",''.'',1) = ''Display'' THEN 1 else 0 END AS "Flag_ActSuspect_Influence_TouchPoint_by_AcquisitionChannelTopLevel_Display",
CASE WHEN infl_data."Marketing_TouchPoint_Date" <= act.SUSPECT_DATE_STAMP__C AND SPLIT_PART(infl_data."Acquisition_Channel",''.'',1) = ''Email'' THEN 1 else 0 END AS "Flag_ActSuspect_Influence_TouchPoint_by_AcquisitionChannelTopLevel_Email",
CASE WHEN infl_data."Marketing_TouchPoint_Date" <= act.SUSPECT_DATE_STAMP__C AND SPLIT_PART(infl_data."Acquisition_Channel",''.'',1) = ''Lead Referral'' THEN 1 else 0 END AS "Flag_ActSuspect_Influence_TouchPoint_by_AcquisitionChannelTopLevel_LeadReferral",
CASE WHEN infl_data."Marketing_TouchPoint_Date" <= act.SUSPECT_DATE_STAMP__C AND SPLIT_PART(infl_data."Acquisition_Channel",''.'',1) = ''Live Event'' THEN 1 else 0 END AS "Flag_ActSuspect_Influence_TouchPoint_by_AcquisitionChannelTopLevel_LiveEvent",
CASE WHEN infl_data."Marketing_TouchPoint_Date" <= act.SUSPECT_DATE_STAMP__C AND SPLIT_PART(infl_data."Acquisition_Channel",''.'',1) = ''Lytx'' THEN 1 else 0 END AS "Flag_ActSuspect_Influence_TouchPoint_by_AcquisitionChannelTopLevel_Lytx",
CASE WHEN infl_data."Marketing_TouchPoint_Date" <= act.SUSPECT_DATE_STAMP__C AND SPLIT_PART(infl_data."Acquisition_Channel",''.'',1) = ''Native'' THEN 1 else 0 END AS "Flag_ActSuspect_Influence_TouchPoint_by_AcquisitionChannelTopLevel_Native",
CASE WHEN infl_data."Marketing_TouchPoint_Date" <= act.SUSPECT_DATE_STAMP__C AND SPLIT_PART(infl_data."Acquisition_Channel",''.'',1) = ''Organic Search'' THEN 1 else 0 END AS "Flag_ActSuspect_Influence_TouchPoint_by_AcquisitionChannelTopLevel_OrganicSearch",
CASE WHEN infl_data."Marketing_TouchPoint_Date" <= act.SUSPECT_DATE_STAMP__C AND SPLIT_PART(infl_data."Acquisition_Channel",''.'',1) = ''Organic Social'' THEN 1 else 0 END AS "Flag_ActSuspect_Influence_TouchPoint_by_AcquisitionChannelTopLevel_OrganicSocial",
CASE WHEN infl_data."Marketing_TouchPoint_Date" <= act.SUSPECT_DATE_STAMP__C AND SPLIT_PART(infl_data."Acquisition_Channel",''.'',1) = ''Other'' THEN 1 else 0 END AS "Flag_ActSuspect_Influence_TouchPoint_by_AcquisitionChannelTopLevel_Other",
CASE WHEN infl_data."Marketing_TouchPoint_Date" <= act.SUSPECT_DATE_STAMP__C AND SPLIT_PART(infl_data."Acquisition_Channel",''.'',1) = ''Paid Media'' THEN 1 else 0 END AS "Flag_ActSuspect_Influence_TouchPoint_by_AcquisitionChannelTopLevel_PaidMedia",
CASE WHEN infl_data."Marketing_TouchPoint_Date" <= act.SUSPECT_DATE_STAMP__C AND SPLIT_PART(infl_data."Acquisition_Channel",''.'',1) = ''Paid Search'' THEN 1 else 0 END AS "Flag_ActSuspect_Influence_TouchPoint_by_AcquisitionChannelTopLevel_PaidSearch",
CASE WHEN infl_data."Marketing_TouchPoint_Date" <= act.SUSPECT_DATE_STAMP__C AND SPLIT_PART(infl_data."Acquisition_Channel",''.'',1) = ''Paid Social'' THEN 1 else 0 END AS "Flag_ActSuspect_Influence_TouchPoint_by_AcquisitionChannelTopLevel_PaidSocial",
CASE WHEN infl_data."Marketing_TouchPoint_Date" <= act.SUSPECT_DATE_STAMP__C AND SPLIT_PART(infl_data."Acquisition_Channel",''.'',1) = ''Podcast'' THEN 1 else 0 END AS "Flag_ActSuspect_Influence_TouchPoint_by_AcquisitionChannelTopLevel_Podcast",
CASE WHEN infl_data."Marketing_TouchPoint_Date" <= act.SUSPECT_DATE_STAMP__C AND SPLIT_PART(infl_data."Acquisition_Channel",''.'',1) = ''PPL'' THEN 1 else 0 END AS "Flag_ActSuspect_Influence_TouchPoint_by_AcquisitionChannelTopLevel_PPL",
CASE WHEN infl_data."Marketing_TouchPoint_Date" <= act.SUSPECT_DATE_STAMP__C AND SPLIT_PART(infl_data."Acquisition_Channel",''.'',1) = ''Print'' THEN 1 else 0 END AS "Flag_ActSuspect_Influence_TouchPoint_by_AcquisitionChannelTopLevel_Print",
CASE WHEN infl_data."Marketing_TouchPoint_Date" <= act.SUSPECT_DATE_STAMP__C AND SPLIT_PART(infl_data."Acquisition_Channel",''.'',1) = ''Sponsored Email'' THEN 1 else 0 END AS "Flag_ActSuspect_Influence_TouchPoint_by_AcquisitionChannelTopLevel_SponsoredEmail",
CASE WHEN infl_data."Marketing_TouchPoint_Date" <= act.SUSPECT_DATE_STAMP__C AND SPLIT_PART(infl_data."Acquisition_Channel",''.'',1) = ''Tradeshow'' THEN 1 else 0 END AS "Flag_ActSuspect_Influence_TouchPoint_by_AcquisitionChannelTopLevel_Tradeshow",
CASE WHEN infl_data."Marketing_TouchPoint_Date" <= act.SUSPECT_DATE_STAMP__C AND SPLIT_PART(infl_data."Acquisition_Channel",''.'',1) = ''Web Referral'' THEN 1 else 0 END AS "Flag_ActSuspect_Influence_TouchPoint_by_AcquisitionChannelTopLevel_Web Referral",
CASE WHEN infl_data."Marketing_TouchPoint_Date" <= act.SUSPECT_DATE_STAMP__C AND SPLIT_PART(infl_data."Acquisition_Channel",''.'',1) = ''Webinar'' THEN 1 else 0 END AS "Flag_ActSuspect_Influence_TouchPoint_by_AcquisitionChannelTopLevel_Webinar",

-- Influence Before Account Prospect Date
CASE WHEN infl_data."Marketing_TouchPoint_Date" <= act.PROSPECT_DATE_STAMP__C AND SPLIT_PART(infl_data."Acquisition_Channel",''.'',1) = ''Channel Referral'' THEN 1 else 0 END AS "Flag_ActProspect_Influence_TouchPoint_by_AcquisitionChannelTopLevel_ChannelReferral",
CASE WHEN infl_data."Marketing_TouchPoint_Date" <= act.PROSPECT_DATE_STAMP__C AND SPLIT_PART(infl_data."Acquisition_Channel",''.'',1) = ''Content Syndication'' THEN 1 else 0 END AS "Flag_ActProspect_Influence_TouchPoint_by_AcquisitionChannelTopLevel_ContentSyndication",
CASE WHEN infl_data."Marketing_TouchPoint_Date" <= act.PROSPECT_DATE_STAMP__C AND SPLIT_PART(infl_data."Acquisition_Channel",''.'',1) = ''Sales Engagement'' THEN 1 else 0 END AS "Flag_ActProspect_Influence_TouchPoint_by_AcquisitionChannelTopLevel_SalesEngagement",
CASE WHEN infl_data."Marketing_TouchPoint_Date" <= act.PROSPECT_DATE_STAMP__C AND SPLIT_PART(infl_data."Acquisition_Channel",''.'',1) = ''Direct'' THEN 1 else 0 END AS "Flag_ActProspect_Influence_TouchPoint_by_AcquisitionChannelTopLevel_Direct",
CASE WHEN infl_data."Marketing_TouchPoint_Date" <= act.PROSPECT_DATE_STAMP__C AND SPLIT_PART(infl_data."Acquisition_Channel",''.'',1) = ''Direct Mail'' THEN 1 else 0 END AS "Flag_ActProspect_Influence_TouchPoint_by_AcquisitionChannelTopLevel_DirectMail",
CASE WHEN infl_data."Marketing_TouchPoint_Date" <= act.PROSPECT_DATE_STAMP__C AND SPLIT_PART(infl_data."Acquisition_Channel",''.'',1) = ''Display'' THEN 1 else 0 END AS "Flag_ActProspect_Influence_TouchPoint_by_AcquisitionChannelTopLevel_Display",
CASE WHEN infl_data."Marketing_TouchPoint_Date" <= act.PROSPECT_DATE_STAMP__C AND SPLIT_PART(infl_data."Acquisition_Channel",''.'',1) = ''Email'' THEN 1 else 0 END AS "Flag_ActProspect_Influence_TouchPoint_by_AcquisitionChannelTopLevel_Email",
CASE WHEN infl_data."Marketing_TouchPoint_Date" <= act.PROSPECT_DATE_STAMP__C AND SPLIT_PART(infl_data."Acquisition_Channel",''.'',1) = ''Lead Referral'' THEN 1 else 0 END AS "Flag_ActProspect_Influence_TouchPoint_by_AcquisitionChannelTopLevel_LeadReferral",
CASE WHEN infl_data."Marketing_TouchPoint_Date" <= act.PROSPECT_DATE_STAMP__C AND SPLIT_PART(infl_data."Acquisition_Channel",''.'',1) = ''Live Event'' THEN 1 else 0 END AS "Flag_ActProspect_Influence_TouchPoint_by_AcquisitionChannelTopLevel_LiveEvent",
CASE WHEN infl_data."Marketing_TouchPoint_Date" <= act.PROSPECT_DATE_STAMP__C AND SPLIT_PART(infl_data."Acquisition_Channel",''.'',1) = ''Lytx'' THEN 1 else 0 END AS "Flag_ActProspect_Influence_TouchPoint_by_AcquisitionChannelTopLevel_Lytx",
CASE WHEN infl_data."Marketing_TouchPoint_Date" <= act.PROSPECT_DATE_STAMP__C AND SPLIT_PART(infl_data."Acquisition_Channel",''.'',1) = ''Native'' THEN 1 else 0 END AS "Flag_ActProspect_Influence_TouchPoint_by_AcquisitionChannelTopLevel_Native",
CASE WHEN infl_data."Marketing_TouchPoint_Date" <= act.PROSPECT_DATE_STAMP__C AND SPLIT_PART(infl_data."Acquisition_Channel",''.'',1) = ''Organic Search'' THEN 1 else 0 END AS "Flag_ActProspect_Influence_TouchPoint_by_AcquisitionChannelTopLevel_OrganicSearch",
CASE WHEN infl_data."Marketing_TouchPoint_Date" <= act.PROSPECT_DATE_STAMP__C AND SPLIT_PART(infl_data."Acquisition_Channel",''.'',1) = ''Organic Social'' THEN 1 else 0 END AS "Flag_ActProspect_Influence_TouchPoint_by_AcquisitionChannelTopLevel_OrganicSocial",
CASE WHEN infl_data."Marketing_TouchPoint_Date" <= act.PROSPECT_DATE_STAMP__C AND SPLIT_PART(infl_data."Acquisition_Channel",''.'',1) = ''Other'' THEN 1 else 0 END AS "Flag_ActProspect_Influence_TouchPoint_by_AcquisitionChannelTopLevel_Other",
CASE WHEN infl_data."Marketing_TouchPoint_Date" <= act.PROSPECT_DATE_STAMP__C AND SPLIT_PART(infl_data."Acquisition_Channel",''.'',1) = ''Paid Media'' THEN 1 else 0 END AS "Flag_ActProspect_Influence_TouchPoint_by_AcquisitionChannelTopLevel_PaidMedia",
CASE WHEN infl_data."Marketing_TouchPoint_Date" <= act.PROSPECT_DATE_STAMP__C AND SPLIT_PART(infl_data."Acquisition_Channel",''.'',1) = ''Paid Search'' THEN 1 else 0 END AS "Flag_ActProspect_Influence_TouchPoint_by_AcquisitionChannelTopLevel_PaidSearch",
CASE WHEN infl_data."Marketing_TouchPoint_Date" <= act.PROSPECT_DATE_STAMP__C AND SPLIT_PART(infl_data."Acquisition_Channel",''.'',1) = ''Paid Social'' THEN 1 else 0 END AS "Flag_ActProspect_Influence_TouchPoint_by_AcquisitionChannelTopLevel_PaidSocial",
CASE WHEN infl_data."Marketing_TouchPoint_Date" <= act.PROSPECT_DATE_STAMP__C AND SPLIT_PART(infl_data."Acquisition_Channel",''.'',1) = ''Podcast'' THEN 1 else 0 END AS "Flag_ActProspect_Influence_TouchPoint_by_AcquisitionChannelTopLevel_Podcast",
CASE WHEN infl_data."Marketing_TouchPoint_Date" <= act.PROSPECT_DATE_STAMP__C AND SPLIT_PART(infl_data."Acquisition_Channel",''.'',1) = ''PPL'' THEN 1 else 0 END AS "Flag_ActProspect_Influence_TouchPoint_by_AcquisitionChannelTopLevel_PPL",
CASE WHEN infl_data."Marketing_TouchPoint_Date" <= act.PROSPECT_DATE_STAMP__C AND SPLIT_PART(infl_data."Acquisition_Channel",''.'',1) = ''Print'' THEN 1 else 0 END AS "Flag_ActProspect_Influence_TouchPoint_by_AcquisitionChannelTopLevel_Print",
CASE WHEN infl_data."Marketing_TouchPoint_Date" <= act.PROSPECT_DATE_STAMP__C AND SPLIT_PART(infl_data."Acquisition_Channel",''.'',1) = ''Sponsored Email'' THEN 1 else 0 END AS "Flag_ActProspect_Influence_TouchPoint_by_AcquisitionChannelTopLevel_SponsoredEmail",
CASE WHEN infl_data."Marketing_TouchPoint_Date" <= act.PROSPECT_DATE_STAMP__C AND SPLIT_PART(infl_data."Acquisition_Channel",''.'',1) = ''Tradeshow'' THEN 1 else 0 END AS "Flag_ActProspect_Influence_TouchPoint_by_AcquisitionChannelTopLevel_Tradeshow",
CASE WHEN infl_data."Marketing_TouchPoint_Date" <= act.PROSPECT_DATE_STAMP__C AND SPLIT_PART(infl_data."Acquisition_Channel",''.'',1) = ''Web Referral'' THEN 1 else 0 END AS "Flag_ActProspect_Influence_TouchPoint_by_AcquisitionChannelTopLevel_Web Referral",
CASE WHEN infl_data."Marketing_TouchPoint_Date" <= act.PROSPECT_DATE_STAMP__C AND SPLIT_PART(infl_data."Acquisition_Channel",''.'',1) = ''Webinar'' THEN 1 else 0 END AS "Flag_ActProspect_Influence_TouchPoint_by_AcquisitionChannelTopLevel_Webinar",

CASE WHEN (SPLIT_PART(infl_data."Acquisition_Channel",''.'',1) = ''Channel Referral'') THEN 1 else 0 END AS "Flag_Has_TouchPoint_by_AcquisitionChannelTopLevel_ChannelReferral",
CASE WHEN (SPLIT_PART(infl_data."Acquisition_Channel",''.'',1) = ''Content Syndication'') THEN 1 else 0 END AS "Flag_Has_TouchPoint_by_AcquisitionChannelTopLevel_ContentSyndication",
CASE WHEN (SPLIT_PART(infl_data."Acquisition_Channel",''.'',1) = ''Sales Engagement'') THEN 1 else 0 END AS "Flag_Has_TouchPoint_by_AcquisitionChannelTopLevel_SalesEngagement",
CASE WHEN (SPLIT_PART(infl_data."Acquisition_Channel",''.'',1) = ''Direct'') THEN 1 else 0 END AS "Flag_Has_TouchPoint_by_AcquisitionChannelTopLevel_Direct",
CASE WHEN (SPLIT_PART(infl_data."Acquisition_Channel",''.'',1) = ''Direct Mail'') THEN 1 else 0 END AS "Flag_Has_TouchPoint_by_AcquisitionChannelTopLevel_DirectMail",
CASE WHEN (SPLIT_PART(infl_data."Acquisition_Channel",''.'',1) = ''Display'') THEN 1 else 0 END AS "Flag_Has_TouchPoint_by_AcquisitionChannelTopLevel_Display",
CASE WHEN (SPLIT_PART(infl_data."Acquisition_Channel",''.'',1) = ''Email'') THEN 1 else 0 END AS "Flag_Has_TouchPoint_by_AcquisitionChannelTopLevel_Email",
CASE WHEN (SPLIT_PART(infl_data."Acquisition_Channel",''.'',1) = ''Lead Referral'') THEN 1 else 0 END AS "Flag_Has_TouchPoint_by_AcquisitionChannelTopLevel_LeadReferral",
CASE WHEN (SPLIT_PART(infl_data."Acquisition_Channel",''.'',1) = ''Live Event'') THEN 1 else 0 END AS "Flag_Has_TouchPoint_by_AcquisitionChannelTopLevel_LiveEvent",
CASE WHEN (SPLIT_PART(infl_data."Acquisition_Channel",''.'',1) = ''Lytx'') THEN 1 else 0 END AS "Flag_Has_TouchPoint_by_AcquisitionChannelTopLevel_Lytx",
CASE WHEN (SPLIT_PART(infl_data."Acquisition_Channel",''.'',1) = ''Native'') THEN 1 else 0 END AS "Flag_Has_TouchPoint_by_AcquisitionChannelTopLevel_Native",
CASE WHEN (SPLIT_PART(infl_data."Acquisition_Channel",''.'',1) = ''Organic Search'') THEN 1 else 0 END AS "Flag_Has_TouchPoint_by_AcquisitionChannelTopLevel_OrganicSearch",
CASE WHEN (SPLIT_PART(infl_data."Acquisition_Channel",''.'',1) = ''Organic Social'') THEN 1 else 0 END AS "Flag_Has_TouchPoint_by_AcquisitionChannelTopLevel_OrganicSocial",
CASE WHEN (SPLIT_PART(infl_data."Acquisition_Channel",''.'',1) = ''Other'') THEN 1 else 0 END AS "Flag_Has_TouchPoint_by_AcquisitionChannelTopLevel_Other",
CASE WHEN (SPLIT_PART(infl_data."Acquisition_Channel",''.'',1) = ''Paid Media'') THEN 1 else 0 END AS "Flag_Has_TouchPoint_by_AcquisitionChannelTopLevel_PaidMedia",
CASE WHEN (SPLIT_PART(infl_data."Acquisition_Channel",''.'',1) = ''Paid Search'') THEN 1 else 0 END AS "Flag_Has_TouchPoint_by_AcquisitionChannelTopLevel_PaidSearch",
CASE WHEN (SPLIT_PART(infl_data."Acquisition_Channel",''.'',1) = ''Paid Social'') THEN 1 else 0 END AS "Flag_Has_TouchPoint_by_AcquisitionChannelTopLevel_PaidSocial",
CASE WHEN (SPLIT_PART(infl_data."Acquisition_Channel",''.'',1) = ''Podcast'') THEN 1 else 0 END AS "Flag_Has_TouchPoint_by_AcquisitionChannelTopLevel_Podcast",
CASE WHEN (SPLIT_PART(infl_data."Acquisition_Channel",''.'',1) = ''PPL'') THEN 1 else 0 END AS "Flag_Has_TouchPoint_by_AcquisitionChannelTopLevel_PPL",
CASE WHEN (SPLIT_PART(infl_data."Acquisition_Channel",''.'',1) = ''Print'') THEN 1 else 0 END AS "Flag_Has_TouchPoint_by_AcquisitionChannelTopLevel_Print",
CASE WHEN (SPLIT_PART(infl_data."Acquisition_Channel",''.'',1) = ''Sponsored Email'') THEN 1 else 0 END AS "Flag_Has_TouchPoint_by_AcquisitionChannelTopLevel_SponsoredEmail",
CASE WHEN (SPLIT_PART(infl_data."Acquisition_Channel",''.'',1) = ''Tradeshow'') THEN 1 else 0 END AS "Flag_Has_TouchPoint_by_AcquisitionChannelTopLevel_Tradeshow",
CASE WHEN (SPLIT_PART(infl_data."Acquisition_Channel",''.'',1) = ''Web Referral'') THEN 1 else 0 END AS "Flag_Has_TouchPoint_by_AcquisitionChannelTopLevel_Web Referral",
CASE WHEN (SPLIT_PART(infl_data."Acquisition_Channel",''.'',1) = ''Webinar'') THEN 1 else 0 END AS "Flag_Has_TouchPoint_by_AcquisitionChannelTopLevel_Webinar",
CASE WHEN infl_data."CRM_ACCOUNT_ID" IS NULL THEN ''salesforce'' ELSE infl_data."Acquisition_Web_Source" END AS "Acquisition_Web_Source",
CASE WHEN infl_data."CRM_ACCOUNT_ID" IS NULL THEN ''opportunity'' ELSE infl_data."Acquisition_Medium" END AS "Acquisition_Medium",
infl_data."Acquisition_Campaign_Name",
infl_data."Acquisition_Creative_Name",
infl_data."Acquisition_Landing_Page",
infl_data."Acquisition_Referrer",
-- Account Lifecycle Info
act_lifecycle."ACT_JOURNEY_PATH" AS ACTLFC_act_journey_path,
act_lifecycle."ACT_JOURNEY_PATH_CNT" AS ACTLFC_act_journey_path_cnt,
act_lifecycle."ACT_JOURNEY_PATH_ID" AS ACTLFC_act_journey_path_id,
act_lifecycle."OPP_CUSTOMER_RELATIONSHIP" AS ACTLFC_OPP_CUSTOMER_RELATIONSHIP,
act_lifecycle."SUSPECT_OPP_RELATIONSHIP" AS ACTLFC_SUSPECT_OPP_RELATIONSHIP,
act_lifecycle."SUSPECT_CUSTOMER_RELATIONSHIP" AS ACTLFC_SUSPECT_CUSTOMER_RELATIONSHIP,
act_lifecycle."MQA_SUSPECT_RELATIONSHIP" AS ACTLFC_MQA_SUSPECT_RELATIONSHIP,
act_lifecycle."MQA_OPP_RELATIONSHIP" AS ACTLFC_MQA_OPP_RELATIONSHIP,
act_lifecycle."MQA_CUSTOMER_RELATIONSHIP" AS ACTLFC_MQA_CUSTOMER_RELATIONSHIP,
act_lifecycle."MEA_SUSPECT_RELATIONSHIP" AS ACTLFC_MEA_SUSPECT_RELATIONSHIP,
act_lifecycle."MEA_OPP_RELATIONSHIP" AS ACTLFC_MEA_OPP_RELATIONSHIP,
act_lifecycle."MEA_CUSTOMER_RELATIONSHIP" AS ACTLFC_MEA_CUSTOMER_RELATIONSHIP,
act_lifecycle."COLD_SUSPECT_RELATIONSHIP" AS ACTLFC_COLD_SUSPECT_RELATIONSHIP,
act_lifecycle."COLD_OPP_RELATIONSHIP" AS ACTLFC_COLD_OPP_RELATIONSHIP,
act_lifecycle."COLD_CUSTOMER_RELATIONSHIP" AS ACTLFC_COLD_CUSTOMER_RELATIONSHIP,
act_lifecycle."MUTUALLY_EXCLUSIVE_PRE_SUSPECT_DESIGNATION" AS ACTLFC_MUTUALLY_EXCLUSIVE_PRE_SUSPECT_DESIGNATION,
act_lifecycle."MUTUALLY_EXCLUSIVE_PRE_SUSPECT_DESIGNATION_DATE" AS ACTLFC_MUTUALLY_EXCLUSIVE_PRE_SUSPECT_DESIGNATION_DATE,
act_lifecycle."MUTUALLY_EXCLUSIVE_PRE_OPP_DESIGNATION" AS ACTLFC_MUTUALLY_EXCLUSIVE_PRE_OPP_DESIGNATION,
act_lifecycle."MUTUALLY_EXCLUSIVE_PRE_OPP_DESIGNATION_DATE" AS ACTLFC_MUTUALLY_EXCLUSIVE_PRE_OPP_DESIGNATION_DATE,
act_lifecycle."COLD_ACCOUNT_DATE_STAMP__C" AS ACTLFC_COLD_ACCOUNT_DATE_STAMP__C,
act_lifecycle."COLD_ACCOUNT_DATE_STAMP__C_CAST" AS ACTLFC_COLD_ACCOUNT_DATE_STAMP__C_CAST,
act_lifecycle."COLD_ACCOUNT_DATE_EOW" AS ACTLFC_cold_account_date_eow,
act_lifecycle."COLD_ACCOUNT_DATE_EOM" AS ACTLFC_cold_account_date_eom,
act_lifecycle."COLD_ACCOUNT_DATE_EOQ" AS ACTLFC_cold_account_date_eoq,
act_lifecycle."COLD_ACCOUNT_DATE_EOY" AS ACTLFC_cold_account_date_eoy,
act_lifecycle."MEA_DATE_STAMP__C" AS ACTLFC_MEA_DATE_STAMP__C,
act_lifecycle."MEA_DATE_STAMP__C_CAST" AS ACTLFC_MEA_DATE_STAMP__C_CAST,
act_lifecycle."MEA_DATE_EOW" AS ACTLFC_mea_date_eow,
act_lifecycle."MEA_DATE_EOM" AS ACTLFC_mea_date_eom,
act_lifecycle."MEA_DATE_EOQ" AS ACTLFC_mea_date_eoq,
act_lifecycle."MEA_DATE_EOY" AS ACTLFC_mea_date_eoy,
act_lifecycle."MQA_DATE_STAMP__C" AS ACTLFC_MQA_DATE_STAMP__C,
act_lifecycle."MQA_DATE_STAMP__C_CAST" AS ACTLFC_MQA_DATE_STAMP__C_CAST,
act_lifecycle."MQA_DATE_EOW" AS ACTLFC_mqa_date_eow,
act_lifecycle."MQA_DATE_EOM" AS ACTLFC_mqa_date_eom,
act_lifecycle."MQA_DATE_EOQ" AS ACTLFC_mqa_date_eoq,
act_lifecycle."MQA_DATE_EOY" AS ACTLFC_mqa_date_eoy,
act_lifecycle."SUSPECT_DATE_STAMP__C" AS ACTLFC_SUSPECT_DATE_STAMP__C,
act_lifecycle."SUSPECT_DATE_STAMP__C_CAST" AS ACTLFC_SUSPECT_DATE_STAMP__C_CAST,
act_lifecycle."SUSPECT_DATE_EOW" AS ACTLFC_suspect_date_eow,
act_lifecycle."SUSPECT_DATE_EOM" AS ACTLFC_suspect_date_eom,
act_lifecycle."SUSPECT_DATE_EOQ" AS ACTLFC_suspect_date_eoq,
act_lifecycle."SUSPECT_DATE_EOY" AS ACTLFC_suspect_date_eoy,
act_lifecycle."SUSPECT_WORKING_DATE_STAMP__C" AS ACTLFC_SUSPECT_WORKING_DATE_STAMP__C,
act_lifecycle."SUSPECT_WORKING_DATE_STAMP__C_CAST" AS ACTLFC_SUSPECT_WORKING_DATE_STAMP__C_CAST,
act_lifecycle."SUSPECT_WORKING_DATE_EOW" AS ACTLFC_suspect_working_date_eow,
act_lifecycle."SUSPECT_WORKING_DATE_EOM" AS ACTLFC_suspect_working_date_eom,
act_lifecycle."SUSPECT_WORKING_DATE_EOQ" AS ACTLFC_suspect_working_date_eoq,
act_lifecycle."SUSPECT_WORKING_DATE_EOY" AS ACTLFC_suspect_working_date_eoy,
act_lifecycle."PROSPECT_DATE_STAMP__C" AS ACTLFC_PROSPECT_DATE_STAMP__C,
act_lifecycle."PROSPECT_DATE_STAMP__C_CAST" AS ACTLFC_PROSPECT_DATE_STAMP__C_CAST,
act_lifecycle."PROSPECT_DATE_EOW" AS ACTLFC_prospect_date_eow,
act_lifecycle."PROSPECT_DATE_EOM" AS ACTLFC_prospect_date_eom,
act_lifecycle."PROSPECT_DATE_EOQ" AS ACTLFC_prospect_date_eoq,
act_lifecycle."PROSPECT_DATE_EOY" AS ACTLFC_prospect_date_eoy,
act_lifecycle."CUSTOMER_DATE_STAMP__C" AS ACTLFC_CUSTOMER_DATE_STAMP__C,
act_lifecycle."CUSTOMER_DATE_STAMP__C_CAST" AS ACTLFC_CUSTOMER_DATE_STAMP__C_CAST,
act_lifecycle."CUSTOMER_DATE_EOW" AS ACTLFC_customer_date_eow,
act_lifecycle."CUSTOMER_DATE_EOM" AS ACTLFC_customer_date_eom,
act_lifecycle."CUSTOMER_DATE_EOQ" AS ACTLFC_customer_date_eoq,
act_lifecycle."CUSTOMER_DATE_EOY" AS ACTLFC_customer_date_eoy,
act_lifecycle."RECYCLED_DATE_STAMP__C" AS ACTLFC_RECYCLED_DATE_STAMP__C,
act_lifecycle."RECYCLED_DATE_STAMP__C_CAST" AS ACTLFC_RECYCLED_DATE_STAMP__C_CAST,
act_lifecycle."RECYCLED_DATE_EOW" AS ACTLFC_recycled_date_eow,
act_lifecycle."RECYCLED_DATE_EOM" AS ACTLFC_recycled_date_eom,
act_lifecycle."RECYCLED_DATE_EOQ" AS ACTLFC_recycled_date_eoq,
act_lifecycle."RECYCLED_DATE_EOY" AS ACTLFC_recycled_date_eoy,
act_lifecycle."UNQUALIFIED_DATE_STAMP__C" AS ACTLFC_UNQUALIFIED_DATE_STAMP__C,
act_lifecycle."UNQUALIFIED_DATE_STAMP__C_CAST" AS ACTLFC_UNQUALIFIED_DATE_STAMP__C_CAST,
act_lifecycle."UNQUALIFIED_DATE_EOW" AS ACTLFC_unqualified_date_eow,
act_lifecycle."UNQUALIFIED_DATE_EOM" AS ACTLFC_unqualified_date_eom,
act_lifecycle."UNQUALIFIED_DATE_EOQ" AS ACTLFC_unqualified_date_eoq,
act_lifecycle."UNQUALIFIED_DATE_EOY" AS ACTLFC_unqualified_date_eoy,
act_lifecycle."RECYCLED_VS_NEW_FLAG" AS ACTLFC_recycled_vs_new_flag,
act_lifecycle."FLAG_HAS_MARKETING_LIFECYCLE_AT_SUSPECT__C" AS ACTLFC_flag_has_marketing_lifecycle_at_suspect__c,
act_lifecycle."ACCOUNT_LIFECYCLE_COLD_FLAG" AS ACTLFC_account_lifecycle_cold_flag,
act_lifecycle."ACCOUNT_LIFECYCLE_MEA_FLAG" AS ACTLFC_account_lifecycle_mea_flag,
act_lifecycle."ACCOUNT_LIFECYCLE_MQA_FLAG" AS ACTLFC_account_lifecycle_mqa_flag,
act_lifecycle."ACCOUNT_LIFECYCLE_SUSPECT_FLAG" AS ACTLFC_account_lifecycle_suspect_flag,
act_lifecycle."ACCOUNT_LIFECYCLE_SUSPECT_WORKING_FLAG" AS ACTLFC_account_lifecycle_suspect_working_flag,
act_lifecycle."ACCOUNT_LIFECYCLE_PROSPECT_FLAG" AS ACTLFC_account_lifecycle_prospect_flag,
act_lifecycle."ACCOUNT_LIFECYCLE_CUSTOMER_FLAG" AS ACTLFC_account_lifecycle_customer_flag,
act_lifecycle."ACCOUNT_LIFECYCLE_RECYCLED_FLAG" AS ACTLFC_account_lifecycle_recycled_flag,
act_lifecycle."ACCOUNT_LIFECYCLE_UNQUALIFIED_FLAG" AS ACTLFC_account_lifecycle_unqualified_flag,
act_lifecycle."ACCOUNT_JOURNEY_PATH_LIFECYCLE_NONLINEAR_FLAG" AS ACTLFC_account_journey_path_lifecycle_nonlinear_flag,
act_lifecycle."ACCOUNT_JOURNEY_PATH_LIFECYCLE_NONLINEAR_FLAG_REASON" AS ACTLFC_account_journey_path_lifecycle_nonlinear_flag_reason,
act_lifecycle."FLAG_TO_CHECK" AS ACTLFC_FLAG_to_check

FROM DP_PROD_DB.SALESFORCE.ACCOUNT_ENRICHED AS act
-- ACT Record Type
INNER JOIN "DP_PROD_DB"."SALESFORCE"."RECORD_TYPE" as rcd_act
ON act."RECORD_TYPE_ID" = rcd_act."ID"
AND (rcd_act."ID" = ''012300000005VEYAA2'' OR rcd_act."ID" = ''0126R000001UknZQAS'')
-- OPP
INNER JOIN DP_PROD_DB.SALESFORCE.OPPORTUNITY as opp
ON act.ID = opp.ACCOUNT_ID
-- AND opp.TYPE = ''New Business''
-- AND (opp.CLOSE_DATE >= ''2023-01-01'' and opp.CLOSE_DATE <= ''2023-03-31'')
-- AND opp.IS_CLOSED = FALSE
and opp.PARENT_OPPORTUNITY__C IS NULL
-- OPP RECORD TYPE
INNER JOIN "DP_PROD_DB"."SALESFORCE"."RECORD_TYPE" as rcd_opp
ON opp."RECORD_TYPE_ID" = rcd_opp."ID"
AND (rcd_opp."ID" = ''012800000005wl4AAA'' OR rcd_opp."ID" = ''0121E000000MBF6QAO'')
-- OPP OWNER
INNER JOIN DP_PROD_DB.SALESFORCE.USER usr
ON opp.owner_id = usr.ID
AND opp.owner_id <> ''0056R00000C6W2MQAV''
-- OPP USER ROLE
LEFT JOIN DP_PROD_DB.SALESFORCE.USER_ROLE usr_role
ON usr.USER_ROLE_ID = usr_role.ID
-- OPP CURRENCY
INNER JOIN DP_PROD_DB.SALESFORCE.CURRENCY_TYPE curr
ON opp.CURRENCY_ISO_CODE = curr.ISO_CODE
AND curr.IS_ACTIVE = TRUE
-- touchtype_analytics_table as source
LEFT JOIN
(
select * from DP_PROD_DB.SALESFORCE_TEMP.touchtype_bizible_touchpoints_v1_5
union
select * from DP_PROD_DB.SALESFORCE_TEMP.touchtype_6sense_paidmedia_v1_5
union
select * from DP_PROD_DB.SALESFORCE_TEMP.touchtype_6sense_webvisit_v1_5
) AS  infl_data
--DP_PROD_DB.SALESFORCE_TEMP.touchtype_analytics_table_v1_5  AS  infl_data
ON act.ID = infl_data."CRM_ACCOUNT_ID"
-- account_lifecycle_analytics_table as source
LEFT JOIN DP_PROD_DB.SALESFORCE_TEMP.account_lifecycle_analytics_table_v1_5  AS act_lifecycle
ON act.ID = act_lifecycle.ID
WHERE
-- act.MARKET__C IN (''Elephant'',''Enterprise'',''Hippo'',''Upper Mid'',''Lower Mid'',''Upper Small'')
usr_role.NAME NOT LIKE ''%Compliance%''
AND act."INTERNAL_TEST_ACCOUNT__C" = FALSE
AND act."IS_DELETED" = FALSE
--AND opp.ID = ''0066R00000q8Hw4QAE''
)`

var sql_tbl_06 = snowflake.createStatement({sqlText: table_06});


		try {
			var res1 = sql1.execute();
			
			// seprated tables in order execute 
			var res_tb1_01 = sql_tbl_01.execute();
			var res_tb1_02 = sql_tbl_02.execute();
			var res_tb1_03 = sql_tbl_03.execute();
			var res_tb1_04 = sql_tbl_04.execute();
			var res_tb1_05 = sql_tbl_05.execute();
			var res_tb1_06 = sql_tbl_06.execute();
			// influence_account_opportunity_aggr final table result set 
			var res_tb1_07 = sql_tbl_07.execute();
			
			//result=result1.next();
			result= "MAQ report Data loaded to the TABLE  DP_PROD_DB.SALESFORCE_TEMP.influence_account_opportunity_aggr" +
			        " and touchtype_6sense_paidmedia,touchtype_6sense_webvisit,touchtype_bizible_touchpoints,touchtype_analytics_table,influence_account_opportunity_detail," +
			        "account_lifecycle_analytics_table created" 
			 
		}
		catch (err)  {
          result =  "Failed: Code: " + err.code + "\\n  State: " + err.state;
          result += "\\n  Message: " + err.message;
          result += "\\nStack Trace:\\n" + err.stackTraceTxt;
		}
		return result;
	';

/// grant 
GRANT USAGE ON SCHEMA DP_PROD_DB.SALESFORCE_TEMP TO ROLE LYTX_DP_MKTOPS_ANALYST_PROD;    

grant select on future tables in schema DP_PROD_DB.SALESFORCE_TEMP to role LYTX_DP_MKTOPS_ANALYST_PROD;
grant usage on procedure DP_PROD_DB.SALESFORCE_TEMP.MQA_REPORT_TABLES_v1_5() to role LYTX_DP_MKTOPS_ANALYST_PROD;


/// load data 
USE ROLE  LYTX_DP_MKTOPS_ANALYST_PROD;
USE DATABASE DP_PROD_DB;
USE WAREHOUSE GL_PROD_VWH_S;
USE SCHEMA SALESFORCE_TEMP;
call MQA_REPORT_TABLES_v1_5();

//to get the result 
select count(*) from DP_PROD_DB.SALESFORCE_TEMP.influence_account_opportunity_aggr ;
select * from DP_PROD_DB.SALESFORCE_TEMP.influence_account_opportunity_aggr ;

// All the seven tables 
SELECT * FROM DP_PROD_DB.SALESFORCE_TEMP.INFLUENCE_ACCOUNT_OPPORTUNITY_AGGR LIMIT 10;
SELECT * FROM DP_PROD_DB.SALESFORCE_TEMP.INFLUENCE_ACCOUNT_OPPORTUNITY_DETAIL LIMIT 10;
SELECT * FROM DP_PROD_DB.SALESFORCE_TEMP.ACCOUNT_LIFECYCLE_ANALYTICS_TABLE LIMIT 10;
SELECT * FROM DP_PROD_DB.SALESFORCE_TEMP.TOUCHTYPE_6SENSE_PAIDMEDIA LIMIT 10;
SELECT * FROM DP_PROD_DB.SALESFORCE_TEMP.TOUCHTYPE_6SENSE_WEBVISIT LIMIT 10;
SELECT * FROM DP_PROD_DB.SALESFORCE_TEMP.TOUCHTYPE_BIZIBLE_TOUCHPOINTS LIMIT 10;
SELECT * FROM DP_PROD_DB.SALESFORCE_TEMP.TOUCHTYPE_ANALYTICS_TABLE LIMIT 10;