import json
import boto3
import uuid

from lytxlogger.lytx_logger import LytxLogger

lytxLogger = LytxLogger.create("logger_" + __name__)
trackingId = str(uuid.uuid1())


def getEnvName(resourceName):
    if '-dev-' in resourceName:
        return "dev"
    elif '-stg-' in resourceName:
        return "stg"
    elif '-prod-' in resourceName:
        return "prod"


def populate_parameter():
    ssm = boto3.client('ssm')
    global scheduleId, glueJob

    #parameter = ssm.get_parameter(Name='/services/glue/bizible/scheduleId', WithDecryption=False)
    #scheduleId = parameter['Parameter']['Value']

    parameter = ssm.get_parameter(Name='/services/glue/bizible/glueJob', WithDecryption=False)
    glueJob = parameter['Parameter']['Value']
    

def lambda_handler(event, context):
    lytxLogger.init_logger(getEnvName(context.function_name), "lambda", "lambda", context.function_name,
                          context.aws_request_id, trackingId)
    lytxLogger.info("lambda ore-dev-dp-lambda-bizible-ingest started")
    glue = boto3.client('glue')
    populate_parameter()
    scheduleId = event.get('scheduleId')
    scheduleId_list = scheduleId.split(',')
    print(scheduleId_list)
    lytxLogger.debug(f"Job to start for id: {scheduleId_list}")
    # Trigger the Glue job with custom parameters
    
    
    for id in scheduleId_list:
        try:
            response = glue.start_job_run(
                JobName=glueJob,
                Arguments={
                    '--scheduleId': id
                }
            )
        except Exception as e:
            lytxLogger.error('Failed due to, '+str(e),error_code="unknown")
            raise e
    