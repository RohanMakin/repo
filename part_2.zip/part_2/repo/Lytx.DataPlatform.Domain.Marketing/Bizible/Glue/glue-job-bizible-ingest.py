import boto3
import awswrangler as wr
import pandas as pd
import numpy as np
import snowflake.connector
import os
from boto3.dynamodb.conditions import Key, Attr
from botocore.exceptions import ClientError
import datetime as dt
from datetime import datetime, timezone, timedelta
import sys
import logging
from awsglue.utils import getResolvedOptions

from Logger.lytx_logger import LytxLogger

lytxLogger = LytxLogger.create("logger_" + __name__)
lytxLogger.init_logger("dev", "bizible", "glue", "ore-dev-dp-glue-job-bizible-ingest", "1234", "11111")

dynamodb_resource = boto3.resource('dynamodb')
s3 = boto3.resource('s3')
s3_client = boto3.client('s3')

logger = logging.getLogger()
logging.basicConfig(format='%(asctime)s %(levelname)s-%(message)s',
                    datefmt='%Y-%m-%d %H:%M:%S')
logger.setLevel(logging.DEBUG)


def getEnvName(resourceName):
    if '-dev-' in resourceName:
        return "dev"
    elif '-stg-' in resourceName:
        return "stg"
    elif '-prod-' in resourceName:
        return "prod"


def populate_parameter():
    ssm = boto3.client('ssm')
    global dynamo_config_master_table, dynamo_job_details_table, snowflake_account, snowflake_user, snowflake_password, snowflake_database, snowflake_warehouse, snowflake_schema, s3_bucket, sns_topic_job_fail

    parameter = ssm.get_parameter(Name='/services/glue/bizible/snowflakeAccount', WithDecryption=False)
    snowflake_account = parameter['Parameter']['Value']

    parameter = ssm.get_parameter(Name='/services/glue/bizible/user', WithDecryption=False)
    snowflake_user = parameter['Parameter']['Value']
    parameter = ssm.get_parameter(Name='/services/glue/bizible/snowflakePassword', WithDecryption=False)
    snowflake_password = parameter['Parameter']['Value']

    parameter = ssm.get_parameter(Name='/services/glue/bizible/snowflakeDatabase', WithDecryption=False)
    snowflake_database = parameter['Parameter']['Value']

    parameter = ssm.get_parameter(Name='/services/glue/bizible/snowflakeWarehouse', WithDecryption=False)
    snowflake_warehouse = parameter['Parameter']['Value']

    parameter = ssm.get_parameter(Name='/services/glue/bizible/snowflakeSchema', WithDecryption=False)
    snowflake_schema = parameter['Parameter']['Value']

    parameter = ssm.get_parameter(Name='/services/glue/bizible/s3Bucket', WithDecryption=False)
    s3_bucket = parameter['Parameter']['Value']

    parameter = ssm.get_parameter(Name='/services/dynamodb/config_master_table', WithDecryption=False)
    dynamo_config_master_table = parameter['Parameter']['Value']

    parameter = ssm.get_parameter(Name='/services/dynamodb/job_details_table', WithDecryption=False)
    dynamo_job_details_table = parameter['Parameter']['Value']

    parameter = ssm.get_parameter(Name='/service/sns/glue/fail', WithDecryption=False)
    sns_topic_job_fail = parameter['Parameter']['Value']
    lytxLogger.info('============================Populate Parameter completed')


def connect_bizible_database():
    try:
        con = snowflake.connector.connect(
            user=snowflake_user,
            password=snowflake_password,
            account=snowflake_account,
            warehouse=snowflake_warehouse,
            database=snowflake_database,
            schema=snowflake_schema
        )
        cursor = con.cursor()
    except Exception as e:
        print(f"connect_bizible_database failed with error: {e}")
        raise e

    return cursor, con


def query_bizible_table(cursor, query_string, tables_metadata):
    try:
        print(f"Query: {query_string}")
        cursor.execute(query_string)
        # Fetch the results
        results = cursor.fetchall()
        columns = [desc[0] for desc in cursor.description]
        string_results = [{col: (str(value) if value is not None else None) for col, value in zip(columns, row)} for row in results ]
        # df = pd.DataFrame(results, columns=[desc[0] for desc in cursor.description])
        df = pd.DataFrame(string_results)

        print(df.head(10))
        return df
    except Exception as e:
        print(f'query_bizible_table failed with error: {e}')
        raise e


def get_processed_date(df, incremental_field):
    try:
        print(f"max_processed_date check: {incremental_field}")
        return df[incremental_field].max()
        # return pd.to_datetime('2023-12-15')
    except Exception as e:
        print(f"max_processed_date failed with error: {e}")
        raise e


def write_parquet_to_s3(df, s3_path):
    try:
        wr.s3.to_parquet(df=df, path=s3_path)
    except Exception as e:
        print(f"write_parquet_to_s3 failed with error: {e}")
        raise e


def write_json_to_s3(df, s3_path):
    try:
        # Derive the JSON path by replacing the appropriate parts of the S3 path
        json_path = s3_path.replace("Bizible/", "redshift/Bizible/").replace('.parquet', '.json')
        current_dtypes = df.dtypes.apply(lambda x: x.name).to_dict()
        #print(f"current DATATYPE: {current_dtypes}")
        if current_dtypes is not None:
            for key, value in current_dtypes.items():
                current_dtypes[key] = 'string'

            df = df.astype(current_dtypes)
        #print(f"After DATATYPES : {current_dtypes}")
        wr.s3.to_json(df=df, path=json_path, orient='records', lines=True)
        print(f"DataFrame successfully written to {json_path}")
    except Exception as e:
        print(f"Exception occured while generating json file for Bizible: {str(e)}")


def read_dynamo_metadata(scheduleId):
    table = dynamodb_resource.Table(dynamo_config_master_table)
    result = []
    try:
        result = table.query(
            KeyConditionExpression="scheduleId = :scheduleId",
            FilterExpression="isActive = :isActive",
            ExpressionAttributeValues={
                ":scheduleId": scheduleId,
                ":isActive": True
            },
        )
        # if not result['Items']:
        #     raise ValueError("No object entry found in dynamodb for the metadata")

        return result['Items']

    except ClientError as err:
        print('Failed get_metadata_dynamo()')
        raise err


def get_last_run_detail(tableId):
    try:
        table = dynamodb_resource.Table(dynamo_job_details_table)
        response = table.get_item(
            Key={
                'tableId': tableId
            }
        )
        return response
    except Exception as e:
        print(f'get_last_run_detail failed with error : {e}')
        raise e


def publish_message(sns_topic_arn, comment):
    """
    Publishes a message to a SNS topic.
    """
    sns_client = boto3.client('sns')
    sns_message = comment
    sns_subject = 'Warning!Alert : Bizible Glue Job Failed'
    try:

        response = sns_client.publish(
            TopicArn=sns_topic_arn,
            Message=sns_message,
            Subject=sns_subject,
        )['MessageId']

    except ClientError:
        print(f' Could not publish message to the topic.')
        raise
    else:
        print("Published message to SNS ")
        # return response


def get_object_range_count(cursor, tables_metadata, range_start_date, load_type):
    if load_type == 'FULL_LOAD' and (
            'createdDateField' not in tables_metadata or tables_metadata['createdDateField'] == ''):
        query = f"SELECT sysdate() as maxDate, cast('1900-01-01' as datetime) as minDate,count(1) as records_count FROM {tables_metadata['tableName']}"

    elif load_type == 'FULL_LOAD':
        query = f"SELECT max({tables_metadata['createdDateField']}) as maxDate, min ({tables_metadata['createdDateField']}) as minDate,count(1) as records_count FROM {tables_metadata['tableName']} where date_part(YEAR,{tables_metadata['createdDateField']})> 2000 "
    else:
        query = f"SELECT max({tables_metadata['incrementalField']}) as maxDate, min ({tables_metadata['incrementalField']}) as minDate,count(1) as records_count FROM {tables_metadata['tableName']} where {tables_metadata['incrementalField']}> '{range_start_date}' "
    print(f"get_object_range_count query: {query}")
    cursor.execute(query)
    results = cursor.fetchall()
    end_date = results[0][0]
    start_date = results[0][1]
    records_count = results[0][2]
    print(f"endYear: {end_date},startYear: {start_date},recordCount: {records_count}")
    return start_date, end_date, records_count


def get_query_string(tables_metadata, load_type, load_start_date=None, load_end_date=None):
    try:
        if load_type.upper() == 'FULL_LOAD':

            start_range = f" where {tables_metadata['createdDateField']} >= '{load_start_date}'" if load_start_date is not None and load_start_date != "" else ""

            end_range = f" and {tables_metadata['createdDateField']} < '{load_end_date}'" if load_end_date is not None and load_end_date != "" else ""

            filterCondition = f" and {tables_metadata['queryFilter']}" if 'queryFilter' in tables_metadata and \
                                                                          tables_metadata['queryFilter'] != "" else ""

            query_string = f"Select * from {tables_metadata['tableName']} {start_range} {end_range} {filterCondition}"
        else:
            filterCondition = f" and {tables_metadata['queryFilter']}" if 'queryFilter' in tables_metadata and \
                                                                          tables_metadata['queryFilter'] != "" else ""

            query_string = f"Select * from {tables_metadata['tableName']} where {tables_metadata['incrementalField']} >= dateadd(hour,-6,'{load_start_date}')  {filterCondition}"
        return query_string
    except Exception as e:
        print(f'get_query_string failed with error : {e}')
        raise e


def updateJobDetails(tables_metadata, loadStartDateTime, loadEndDateTime, jobComment, jobStartDate, jobEnddate,
                     jobStatus, recordsCount=0):
    table = dynamodb_resource.Table(dynamo_job_details_table)
    response = table.update_item(
        Key={
            'tableId': tables_metadata['tableId']
        },
        UpdateExpression="SET #incrementalField=:incrementalField,#loadStartDateTime=:loadStartDateTime,#loadEndDateTime=:loadEndDateTime,#jobComment=:jobComment,#jobEndDate=:jobEndDate,#jobStartDate=:jobStartDate,#jobStatus=:jobStatus,#loadType=:loadType,#recordsCount=:recordsCount,#scheduleId=:scheduleId",
        ExpressionAttributeNames={
            '#incrementalField': 'incrementalField',
            '#loadStartDateTime': 'loadStartDateTime',
            '#loadEndDateTime': 'loadEndDateTime',
            '#jobComment': 'comment',
            '#jobEndDate': 'jobEndDate',
            '#jobStartDate': 'jobStartDate',
            '#jobStatus': 'jobStatus',
            '#loadType': 'loadType',
            '#recordsCount': 'recordsCount',
            '#scheduleId': 'scheduleId'

        },
        ExpressionAttributeValues={
            ':incrementalField': str(tables_metadata['incrementalField']),
            ':loadStartDateTime': str(loadStartDateTime),
            ':loadEndDateTime': str(loadEndDateTime),
            ':jobComment': jobComment,
            ':jobEndDate': str(jobEnddate),
            ':jobStartDate': str(jobStartDate),
            ':jobStatus': jobStatus,
            ':loadType': str(tables_metadata['loadType']),
            ':recordsCount': recordsCount,
            ':scheduleId': str(tables_metadata['scheduleId'])

        },
        ReturnValues="UPDATED_NEW"
    )


def copy_raw_file_to_stage(s3_bucket, raw_key, stage_key):
    copy_source = {
        'Bucket': s3_bucket,
        'Key': raw_key
    }

    print(f'File copied from {raw_key} to {stage_key}')
    s3_client.copy_object(CopySource=copy_source, Bucket=s3_bucket, Key=stage_key)
    print("copy succeeded ")


def execute_tables_extract(tables_list):
    connection = ''
    try:
        cursor, connection = connect_bizible_database()
        for tables_metadata in tables_list:
            print(f"tables_metadata: {tables_metadata}")
            load_start_date = 'NA'
            load_end_date = 'NA'
            job_status = 'NA'
            job_start_date = datetime.now(timezone.utc).strftime("%Y-%m-%d %H:%M:%S")
            object_name = tables_metadata['tableName'] if 'select ' not in tables_metadata['tableName'].lower() else \
            tables_metadata['tableId'].split('/')[1]
            incremental_field = tables_metadata['incrementalField']
            load_type = tables_metadata['loadType']
            tableId = tables_metadata['tableId']
            max_processed_date = 'NA'
            print(f'object_name: {object_name} and incremental_field: {incremental_field}')
            records_count = 0
            thresholdCount = 600000
            today_date = dt.date.today()
            today_date_min_2 = today_date - timedelta(hours=3)
            range_start_date = 'NA'
            job_comment = 'NA'
            try:
                last_run_response = get_last_run_detail(tableId)
                print(f"Response check : {last_run_response}")
                is_first_load = False
                query_string_list = []
                # if no entry in the job detail then first time load

                if 'Item' not in last_run_response:
                    is_first_load = True
                    load_type = 'FULL_LOAD'
                else:
                    is_first_load = False

                if load_type == 'FULL_LOAD':
                    range_start_date = '1900-01-01'
                else:
                    range_start_date = last_run_response['Item']['loadEndDateTime'] if last_run_response['Item'][
                                                                                           'jobStatus'] == 'SUCCESS' else \
                    last_run_response['Item']['loadStartDateTime']
                start_date, end_date, records_count = get_object_range_count(cursor, tables_metadata, range_start_date,
                                                                             load_type)

                if records_count > thresholdCount and load_type.upper() == 'FULL_LOAD':
                    for year_num in range(start_date.year, end_date.year + 1):
                        out_of_range = 0
                        for month_num in range(1, 13):
                            if month_num < start_date.month and year_num == start_date.year:
                                continue
                            elif month_num > end_date.month and year_num == end_date.year:
                                out_of_range = 1
                                break
                            else:
                                full_load_start_date = dt.datetime(year_num, month_num, 1)
                                full_load_start_date_part_1 = dt.datetime(year_num, month_num, 11)
                                full_load_start_date_part_2 = dt.datetime(year_num, month_num, 21)
                                # if current month then 
                                if str(today_date.year) == str(year_num) and str(today_date.month) == str(month_num):
                                    # load_end_date = dt.datetime(year_num , month_num ,today_date.day )   
                                    if today_date.day < 11:
                                        full_load_end_date = end_date
                                        query_string = get_query_string(tables_metadata, load_type,
                                                                        full_load_start_date, full_load_end_date)
                                        query_string_list.append(query_string)
                                    elif today_date.day < 21:
                                        full_load_end_date = dt.datetime(year_num, month_num, 11)
                                        full_load_end_date_part1 = end_date
                                        query_string = get_query_string(tables_metadata, load_type,
                                                                        full_load_start_date, full_load_end_date)
                                        query_string_list.append(query_string)
                                        query_string_part1 = get_query_string(tables_metadata, load_type,
                                                                              full_load_start_date_part_1,
                                                                              full_load_end_date_part1)
                                        query_string_list.append(query_string_part1)
                                    elif today_date.day > 21:
                                        full_load_end_date = dt.datetime(year_num, month_num, 11)
                                        full_load_end_date_part1 = dt.datetime(year_num, month_num, 21)
                                        full_load_end_date_part2 = end_date
                                        query_string = get_query_string(tables_metadata, load_type,
                                                                        full_load_start_date, full_load_end_date)
                                        query_string_list.append(query_string)
                                        query_string_part1 = get_query_string(tables_metadata, load_type,
                                                                              full_load_start_date_part_1,
                                                                              full_load_end_date_part1)
                                        query_string_list.append(query_string_part1)
                                        query_string_part2 = get_query_string(tables_metadata, load_type,
                                                                              full_load_start_date_part_2,
                                                                              full_load_end_date_part2)
                                        query_string_list.append(query_string_part2)

                                elif month_num == 12:

                                    full_load_end_date = dt.datetime(year_num, month_num, 11)
                                    full_load_end_date_part1 = dt.datetime(year_num, month_num, 21)
                                    full_load_end_date_part2 = dt.datetime(year_num + 1, 1, 1)
                                    query_string = get_query_string(tables_metadata, load_type, full_load_start_date,
                                                                    full_load_end_date)
                                    query_string_list.append(query_string)
                                    query_string_part1 = get_query_string(tables_metadata, load_type,
                                                                          full_load_start_date_part_1,
                                                                          full_load_end_date_part1)
                                    query_string_list.append(query_string_part1)
                                    query_string_part2 = get_query_string(tables_metadata, load_type,
                                                                          full_load_start_date_part_2,
                                                                          full_load_end_date_part2)
                                    query_string_list.append(query_string_part2)

                                else:

                                    full_load_end_date = dt.datetime(year_num, month_num, 11)
                                    full_load_end_date_part1 = dt.datetime(year_num, month_num, 21)
                                    full_load_end_date_part2 = dt.datetime(year_num, month_num + 1, 1)
                                    query_string = get_query_string(tables_metadata, load_type, full_load_start_date,
                                                                    full_load_end_date)
                                    query_string_list.append(query_string)
                                    query_string_part1 = get_query_string(tables_metadata, load_type,
                                                                          full_load_start_date_part_1,
                                                                          full_load_end_date_part1)
                                    query_string_list.append(query_string_part1)
                                    query_string_part2 = get_query_string(tables_metadata, load_type,
                                                                          full_load_start_date_part_2,
                                                                          full_load_end_date_part2)
                                    query_string_list.append(query_string_part2)

                            print(f"in 1st block Query String list is {query_string_list}")
                        # if out_of_range == 1:
                        # break
                    load_start_date = start_date
                    load_end_date = today_date_min_2
                elif records_count < thresholdCount and load_type.upper() == 'INCREMENTAL':
                    load_start_date = last_run_response['Item']['loadEndDateTime'] if last_run_response['Item'][
                                                                                          'jobStatus'] == 'SUCCESS' else \
                    last_run_response['Item']['loadStartDateTime']
                    query_string = get_query_string(tables_metadata, load_type, load_start_date)
                    query_string_list.append(query_string)
                    print(f"in 2nd block Query String list is {query_string_list}")

                elif records_count < thresholdCount and load_type.upper() == 'FULL_LOAD':
                    load_start_date = '1900-01-01'
                    query_string = get_query_string(tables_metadata, load_type)
                    query_string_list.append(query_string)
                    print(f"in 3rd block Query String list is {query_string_list}")
                else:
                    print("incremental load is more than threshold.")

                job_status = 'STARTED'

                updateJobDetails(tables_metadata, loadStartDateTime=load_start_date, loadEndDateTime='NA',
                                 jobComment='Connection to Bizible established and query started',
                                 jobStartDate=job_start_date, jobEnddate='NA', jobStatus=job_status,
                                 recordsCount=records_count)

                for index, value in enumerate(query_string_list):
                    query_string = value
                    print(f"Query for the current iteration is  {query_string}")
                    if records_count > 0:
                        df = query_bizible_table(cursor, query_string, tables_metadata)
                        date = dt.date.today()
                        print(f"date check : {date}")
                        # add incremental to and from date in the file name
                        if incremental_field != '':
                            file_name = object_name + '_' + load_type + '_' + datetime.now().strftime(
                                "%Y%m%d_%H%M%S.%f") + '_schid_' + scheduleId
                        else:
                            file_name = object_name + '_' + load_type + '_' + '_schid_' + scheduleId + '_' + str(index)

                        yyyy_mm_ddpathstr = '' + str(date.year) + '/' + str(date.month) + '/' + str(date.day)
                        # remove hardcoding for bucketname

                        stage_key = f'Bizible/stage/{object_name}/{yyyy_mm_ddpathstr}/{file_name}.parquet' if incremental_field != '' else f'Bizible/stage/{object_name}/{file_name}.parquet'

                        stage_s3_path = f's3://{s3_bucket}/{stage_key}'

                        print(f"S3 path check : {stage_s3_path}")

                        print(f"incremental field check : {tables_metadata['incrementalField']}")

                        if load_end_date == 'NA' and tables_metadata['incrementalField'] != '':
                            max_processed_date = get_processed_date(df, tables_metadata['incrementalField'])
                            load_end_date = max_processed_date

                        job_status = 'RUNNING'
                        job_comment = 'Writing data in S3'

                        write_parquet_to_s3(df, stage_s3_path)
                        write_json_to_s3(df, stage_s3_path)

                        # stage_key = f'Bizible/stage/{object_name}/{yyyy_mm_ddpathstr}/{file_name}.parquet'

                        # copy_raw_file_to_stage(s3_bucket, raw_key, stage_key)

                        job_end_date = datetime.now(timezone.utc).strftime("%Y-%m-%d %H:%M:%S")
                        job_status = 'SUCCESS'
                        job_comment = 'Written data in S3 successfully'

                    else:
                        load_end_date = load_start_date
                        job_end_date = datetime.now(timezone.utc).strftime("%Y-%m-%d %H:%M:%S")
                        job_status = 'SUCCESS'
                        job_comment = '0 records found, no file written in S3'
                        # updateJobDetails(tables_metadata, loadStartDateTime=load_start_date, loadEndDateTime=load_end_date,
                        #                  jobComment='0 records found, no file written in S3', jobStartDate=job_start_date,
                        #                  jobEnddate=job_end_date, jobStatus=job_status, recordsCount=0)
                updateJobDetails(tables_metadata, loadStartDateTime=load_start_date, loadEndDateTime=load_end_date,
                                 jobComment=job_comment, jobStartDate=job_start_date,
                                 jobEnddate=job_end_date, jobStatus=job_status, recordsCount=records_count)

            except Exception as e:
                job_end_date = datetime.now(timezone.utc).strftime("%Y-%m-%d %H:%M:%S")
                if job_status != 'NA':
                    job_status = 'FAILED'
                    updateJobDetails(tables_metadata, loadStartDateTime=load_start_date, loadEndDateTime=load_end_date,
                                     jobComment=f"Failed with error: {e}", jobStartDate=job_start_date,
                                     jobEnddate=job_end_date, jobStatus=job_status, recordsCount=records_count)
                print(f' Failed with error{e}')
                publish_message(sns_topic_job_fail, f"Error occurred for table: {object_name} with error :" + str(e))


    except Exception as e:
        print(f'outer Exception Failed with error{e}')
        raise e

    finally:
        if connection:
            connection.close()


args = getResolvedOptions(sys.argv, ['scheduleId'])

scheduleId = args['scheduleId']

populate_parameter()
tables_list = read_dynamo_metadata(scheduleId=scheduleId)
print(f"tablelist------------------------------>{tables_list}")
logger.debug(f"tablelist------------------------------>{tables_list}")
if tables_list:
    execute_tables_extract(tables_list)
else:
    print(f'No active tables present for the schedule: {scheduleId}')