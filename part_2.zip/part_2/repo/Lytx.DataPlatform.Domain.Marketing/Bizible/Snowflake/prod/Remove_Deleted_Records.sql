use role GL_DEVELOPER_NON_PROD;
USE DATABASE "DP_PROD_DB";
use warehouse "GL_PROD_VWH_S";

Use schema "BIZIBLE";


CREATE OR REPLACE PROCEDURE BIZIBLE.REMOVE_DELETED_RECORDS()
returns string not null
language javascript
as
$$
var result = "";

var cmd1 =`CALL APPLY_FULL_LOAD('BIZ_ACCOUNT_TO_EMAILS_ALL_ID')`
var sql1 = snowflake.createStatement({sqlText: cmd1});	

var cmd2 =`CALL APPLY_FULL_LOAD('BIZ_CAMPAIGN_MEMBERS_ALL_ID')`
var sql2 = snowflake.createStatement({sqlText: cmd2});	

var cmd3 =`CALL APPLY_FULL_LOAD('BIZ_CONTACTS_ALL_ID')`
var sql3 = snowflake.createStatement({sqlText: cmd3});	

var cmd4 =`CALL APPLY_FULL_LOAD('BIZ_COSTS_ALL_ID')`
var sql4 = snowflake.createStatement({sqlText: cmd4});	

var cmd5 =`CALL APPLY_FULL_LOAD('BIZ_CRM_TASKS_ALL_ID')`
var sql5 = snowflake.createStatement({sqlText: cmd5});	

var cmd6 =`CALL APPLY_FULL_LOAD('BIZ_FACTS_ALL_ID')`
var sql6 = snowflake.createStatement({sqlText: cmd6});	

var cmd7 =`CALL APPLY_FULL_LOAD('BIZ_LEADS_ALL_ID')`
var sql7 = snowflake.createStatement({sqlText: cmd7});	

var cmd8 =`CALL APPLY_FULL_LOAD('BIZ_PAGE_VIEWS_ALL_ID')`
var sql8 = snowflake.createStatement({sqlText: cmd8});	

var cmd9 =`CALL APPLY_FULL_LOAD('BIZ_SESSIONS_ALL_ID')`
var sql9 = snowflake.createStatement({sqlText: cmd9});	
  
var cmd10 =`delete from bizible.BIZ_CAMPAIGN_MEMBERS q1
using (select camp.id from 
(select * from bizible.BIZ_CAMPAIGN_MEMBERS bcm where bcm.modified_date <
(
select case when max(coalesce(a.modified_date,'1900-01-01')) > max(coalesce(b.modified_date,'1900-01-01')) then max(coalesce(b.modified_date,'1900-01-01')) else max(coalesce(a.modified_date,'1900-01-01')) end
 from bizible.BIZ_CAMPAIGN_MEMBERS a
 join bizible.BIZ_CAMPAIGN_MEMBERS_ALL_ID b)) camp
 left join bizible.BIZ_CAMPAIGN_MEMBERS_ALL_ID full_id on camp.id = full_id.id
where full_id.id is null) q2 where q1.id = q2.id`
var sql10 = snowflake.createStatement({sqlText: cmd10});		

var cmd11 =`delete from bizible.BIZ_ACCOUNT_TO_EMAILS q1
using (select camp.id from 
(select * from bizible.BIZ_ACCOUNT_TO_EMAILS bcm where bcm.modified_date <
(
select case when max(coalesce(a.modified_date,'1900-01-01')) > max(coalesce(b.modified_date,'1900-01-01')) then max(coalesce(b.modified_date,'1900-01-01')) else max(coalesce(a.modified_date,'1900-01-01')) end
 from bizible.BIZ_ACCOUNT_TO_EMAILS a
 join bizible.BIZ_ACCOUNT_TO_EMAILS_ALL_ID b)) camp
 left join bizible.BIZ_ACCOUNT_TO_EMAILS_ALL_ID full_id on camp.id = full_id.id
where full_id.id is null) q2 where q1.id = q2.id`
var sql11 = snowflake.createStatement({sqlText: cmd11});	


var cmd12 =`delete from bizible.BIZ_COSTS q1
using (select camp.id from 
(select * from bizible.BIZ_COSTS bcm where bcm._modified_date <
(
select case when max(coalesce(a._modified_date,'1900-01-01')) > max(coalesce(b._modified_date,'1900-01-01')) then max(coalesce(b._modified_date,'1900-01-01')) else max(coalesce(a._modified_date,'1900-01-01')) end
 from bizible.BIZ_COSTS a
 join bizible.BIZ_COSTS_ALL_ID b)) camp
 left join bizible.BIZ_COSTS_ALL_ID full_id on camp.id = full_id.id
where full_id.id is null) q2 where q1.id = q2.id`
var sql12 = snowflake.createStatement({sqlText: cmd12});


var cmd13 =`delete from bizible.BIZ_CONTACTS q1
using (select camp.id from 
(select * from bizible.BIZ_CONTACTS bcm where bcm.modified_date <
(
select case when max(coalesce(a.modified_date,'1900-01-01')) > max(coalesce(b.modified_date,'1900-01-01')) then max(coalesce(b.modified_date,'1900-01-01')) else max(coalesce(a.modified_date,'1900-01-01')) end
 from bizible.BIZ_CONTACTS a
 join bizible.BIZ_CONTACTS_ALL_ID b)) camp
 left join bizible.BIZ_CONTACTS_ALL_ID full_id on camp.id = full_id.id
where full_id.id is null) q2 where q1.id = q2.id`
var sql13 = snowflake.createStatement({sqlText: cmd13});	

var cmd14 =`delete from bizible.BIZ_CRM_TASKS q1
using (select camp.id from 
(select * from bizible.BIZ_CRM_TASKS bcm where bcm.modified_date <
(
select case when max(coalesce(a.modified_date,'1900-01-01')) > max(coalesce(b.modified_date,'1900-01-01')) then max(coalesce(b.modified_date,'1900-01-01')) else max(coalesce(a.modified_date,'1900-01-01')) end
 from bizible.BIZ_CRM_TASKS a
 join bizible.BIZ_CRM_TASKS_ALL_ID b)) camp
 left join bizible.BIZ_CRM_TASKS_ALL_ID full_id on camp.id = full_id.id
where full_id.id is null) q2 where q1.id = q2.id`
var sql14 = snowflake.createStatement({sqlText: cmd14});	

var cmd15 =`delete from bizible.BIZ_LEADS q1
using (select camp.id from 
(select * from bizible.BIZ_LEADS bcm where bcm.modified_date <
(
select case when max(coalesce(a.modified_date,'1900-01-01')) > max(coalesce(b.modified_date,'1900-01-01')) then max(coalesce(b.modified_date,'1900-01-01')) else max(coalesce(a.modified_date,'1900-01-01')) end
 from bizible.BIZ_LEADS a
 join bizible.BIZ_LEADS_ALL_ID b)) camp
 left join bizible.BIZ_LEADS_ALL_ID full_id on camp.id = full_id.id
where full_id.id is null) q2 where q1.id = q2.id`
var sql15 = snowflake.createStatement({sqlText: cmd15});	

var cmd16 =`delete from bizible.BIZ_PAGE_VIEWS q1
using (select camp.id from 
(select * from bizible.BIZ_PAGE_VIEWS bcm where bcm.modified_date <
(
select case when max(coalesce(a.modified_date,'1900-01-01')) > max(coalesce(b.modified_date,'1900-01-01')) then max(coalesce(b.modified_date,'1900-01-01')) else max(coalesce(a.modified_date,'1900-01-01')) end
 from bizible.BIZ_PAGE_VIEWS a
 join bizible.BIZ_PAGE_VIEWS_ALL_ID b)) camp
 left join bizible.BIZ_PAGE_VIEWS_ALL_ID full_id on camp.id = full_id.id
where full_id.id is null) q2 where q1.id = q2.id`
var sql16 = snowflake.createStatement({sqlText: cmd16});	

var cmd17 =`delete from bizible.BIZ_SESSIONS q1
using (select camp.id from 
(select * from bizible.BIZ_SESSIONS bcm where bcm.modified_date <
(
select case when max(coalesce(a.modified_date,'1900-01-01')) > max(coalesce(b.modified_date,'1900-01-01')) then max(coalesce(b.modified_date,'1900-01-01')) else max(coalesce(a.modified_date,'1900-01-01')) end
 from bizible.BIZ_SESSIONS a
 join bizible.BIZ_SESSIONS_ALL_ID b)) camp
 left join bizible.BIZ_SESSIONS_ALL_ID full_id on camp.id = full_id.id
where full_id.id is null) q2 where q1.id = q2.id`
var sql17 = snowflake.createStatement({sqlText: cmd17});	

var cmd18 =`delete from bizible.BIZ_FACTS q1
using 
(	select camp.COST_KEY,camp.ATP_KEY,camp.TP_KEY,camp.PAGE_VIEW_KEY,camp.SESSION_KEY,camp.VISITOR_ID,camp.COOKIE_ID,camp.FORM_SUBMIT_KEY 
from 
	(select * from bizible.BIZ_FACTS bcm where bcm.modified_date <
		(
			select case when max(coalesce(a.modified_date,'1900-01-01')) > max(coalesce(b.modified_date,'1900-01-01')) then max(coalesce(b.modified_date,'1900-01-01')) else max(coalesce(a.modified_date,'1900-01-01')) end
			from bizible.BIZ_FACTS a
			join bizible.BIZ_FACTS_ALL_ID b
		)
	) camp
		left join bizible.BIZ_FACTS_ALL_ID full_id 
		ON coalesce(camp.COST_KEY,-1) = coalesce(full_id.COST_KEY,-1) 
			and coalesce(camp.ATP_KEY,-1) = coalesce(full_id.ATP_KEY,-1) 
			and coalesce(camp.TP_KEY,-1) = coalesce(full_id.TP_KEY,-1) 
			and coalesce(camp.PAGE_VIEW_KEY,-1) = coalesce(full_id.PAGE_VIEW_KEY,-1) 
			and coalesce(camp.SESSION_KEY,-1) = coalesce(full_id.SESSION_KEY,-1) 
			and coalesce(camp.VISITOR_ID,'unknown') = coalesce(full_id.VISITOR_ID,'unknown') 
			and coalesce(camp.COOKIE_ID,'unknown') = coalesce(full_id.COOKIE_ID,'unknown') 
			and coalesce(camp.FORM_SUBMIT_KEY,-1) = coalesce(full_id.FORM_SUBMIT_KEY,-1)
		where full_id.COST_KEY is null 
			and full_id.ATP_KEY is null  
			and full_id.TP_KEY is null
			and full_id.PAGE_VIEW_KEY is null
			and full_id.SESSION_KEY is null
			and full_id.VISITOR_ID is null
			and full_id.COOKIE_ID is null
			and full_id.FORM_SUBMIT_KEY is null
) q2 where coalesce(q1.COST_KEY,-1) = coalesce(q2.COST_KEY,-1) 
			and coalesce(q1.ATP_KEY,-1) = coalesce(q2.ATP_KEY,-1) 
			and coalesce(q1.TP_KEY,-1) = coalesce(q2.TP_KEY,-1) 
			and coalesce(q1.PAGE_VIEW_KEY,-1) = coalesce(q2.PAGE_VIEW_KEY,-1) 
			and coalesce(q1.SESSION_KEY,-1) = coalesce(q2.SESSION_KEY,-1) 
			and coalesce(q1.VISITOR_ID,'unknown') = coalesce(q2.VISITOR_ID,'unknown') 
			and coalesce(q1.COOKIE_ID,'unknown') = coalesce(q2.COOKIE_ID,'unknown') 
			and coalesce(q1.FORM_SUBMIT_KEY,-1) = coalesce(q2.FORM_SUBMIT_KEY,-1)`
var sql18 = snowflake.createStatement({sqlText: cmd18});	

 try {
      var result1 = sql1.execute();
	  var result2 = sql2.execute();
	  var result3 = sql3.execute();
	  var result4 = sql4.execute();
	  var result5 = sql5.execute();
	  var result6 = sql6.execute();
	  var result7 = sql7.execute();
	  var result8 = sql8.execute();
	  var result9 = sql9.execute();
      var result10 = sql10.execute();
	  var result11 = sql11.execute();
	  var result12 = sql12.execute();
	  var result13 = sql13.execute();
	  var result14 = sql14.execute();
	  var result15 = sql15.execute();
	  var result16 = sql16.execute();
	  var result17 = sql17.execute();
	  var result18 = sql18.execute();
	  result = "Succeeded";
	  
      
      }
catch (err)  {
      return "ddl Failed: " + err;   // Return a success error indicator.
      }
return result;

$$;	



CREATE OR REPLACE TASK REMOVE_DELETED_RECORDS_TASK
WAREHOUSE = GL_PROD_VWH_S
SCHEDULE = 'USING CRON 45 5,6 * * * UTC'
AS
CALL REMOVE_DELETED_RECORDS();

ALTER TASK REMOVE_DELETED_RECORDS_TASK RESUME;