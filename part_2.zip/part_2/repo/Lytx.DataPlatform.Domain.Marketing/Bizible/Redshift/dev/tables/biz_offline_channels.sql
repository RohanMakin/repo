CREATE TABLE bizible.biz_offline_channels (
    crm_campaign_type character varying(50) ENCODE lzo,
    channel character varying(36) ENCODE lzo,
    sub_channel character varying(32) ENCODE lzo
) DISTSTYLE AUTO;

CREATE TABLE bizible_temp._temp_biz_offline_channels (
    crm_campaign_type character varying(50) ENCODE lzo,
    channel character varying(36) ENCODE lzo,
    sub_channel character varying(32) ENCODE lzo
) DISTSTYLE AUTO;