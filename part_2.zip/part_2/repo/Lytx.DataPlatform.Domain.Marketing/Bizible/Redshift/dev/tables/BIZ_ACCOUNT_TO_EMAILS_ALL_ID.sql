create TABLE BIZIBLE_TEMP.BIZ_ACCOUNT_TO_EMAILS_ALL_ID (
	ID character varying(250) ENCODE lzo,
	CREATED_DATE timestamp without time zone ENCODE az64,
	MODIFIED_DATE timestamp without time zone ENCODE az64,
	RECORD_CREATION_TS timestamp without time zone ENCODE az64,
	RECORD_UPDATE_TS timestamp without time zone ENCODE az64
);

create TABLE BIZIBLE_TEMP.TEMP_BIZ_ACCOUNT_TO_EMAILS_ALL_ID (
	ID character varying(250) ENCODE lzo,
	CREATED_DATE timestamp without time zone ENCODE az64,
	MODIFIED_DATE timestamp without time zone ENCODE az64
);
