create TABLE BIZIBLE_TEMP.BIZ_CAMPAIGN_MEMBERS_ALL_ID (
	ID character varying(36) ENCODE lzo,
	CREATED_DATE timestamp without time zone ENCODE az64,
	MODIFIED_DATE timestamp without time zone ENCODE az64,
	RECORD_CREATION_TS timestamp without time zone ENCODE az64,
	RECORD_UPDATE_TS timestamp without time zone ENCODE az64
);

create TABLE BIZIBLE_TEMP.TEMP_BIZ_CAMPAIGN_MEMBERS_ALL_ID (
	ID character varying(36) ENCODE lzo,
	CREATED_DATE timestamp without time zone ENCODE az64,
	MODIFIED_DATE timestamp without time zone ENCODE az64
);


