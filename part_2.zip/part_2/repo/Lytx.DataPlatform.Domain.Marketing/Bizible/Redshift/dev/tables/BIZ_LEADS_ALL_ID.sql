
CREATE TABLE bizible_temp.biz_leads_all_id (
    id character varying(30) ENCODE lzo,
    created_date timestamp without time zone ENCODE az64,
    modified_date timestamp without time zone ENCODE az64,
    record_creation_ts timestamp without time zone ENCODE az64,
    record_update_ts timestamp without time zone ENCODE az64
)
DISTSTYLE AUTO;

CREATE TABLE bizible_temp.temp_biz_leads_all_id (
    id character varying(30) ENCODE lzo,
    created_date timestamp without time zone ENCODE az64,
    modified_date timestamp without time zone ENCODE az64
)
DISTSTYLE AUTO;