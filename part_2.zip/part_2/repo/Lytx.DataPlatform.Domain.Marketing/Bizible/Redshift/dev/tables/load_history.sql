CREATE TABLE bizible.load_history (
    id bigint identity(1, 1) ENCODE az64,
    table_name character varying(255) ENCODE lzo,
    file_path character varying(65535) ENCODE lzo,
    success boolean ENCODE raw,
    error_message character varying(65535) ENCODE lzo,
    timestamp timestamp without time zone DEFAULT ('now':: character varying):: timestamp with time zone ENCODE raw
) DISTSTYLE AUTO
SORTKEY
    (timestamp);