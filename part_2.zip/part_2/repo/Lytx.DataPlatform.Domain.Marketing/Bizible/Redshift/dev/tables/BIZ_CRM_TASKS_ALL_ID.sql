
create TABLE BIZIBLE_TEMP.BIZ_CRM_TASKS_ALL_ID (
    id character varying(39) ENCODE lzo,
    created_date timestamp without time zone ENCODE az64,
    modified_date timestamp without time zone ENCODE az64,
    record_creation_ts timestamp without time zone ENCODE az64,
    record_update_ts timestamp without time zone ENCODE az64
)

create TABLE BIZIBLE_TEMP.TEMP_BIZ_CRM_TASKS_ALL_ID (
    id character varying(39) ENCODE lzo,
    created_date timestamp without time zone ENCODE az64,
    modified_date timestamp without time zone ENCODE az64
)
