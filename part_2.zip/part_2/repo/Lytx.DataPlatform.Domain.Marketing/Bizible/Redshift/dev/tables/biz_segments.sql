CREATE TABLE bizible.biz_segments (
    id character varying(75) ENCODE lzo,
    name character varying(75) ENCODE lzo,
    row_key bigint ENCODE az64,
    _created_date timestamp without time zone ENCODE az64,
    _modified_date timestamp without time zone ENCODE az64,
    _deleted_date timestamp without time zone ENCODE az64,
    record_creation_ts timestamp without time zone ENCODE az64,
    record_update_ts timestamp without time zone ENCODE az64
) DISTSTYLE AUTO;

CREATE TABLE bizible_temp.temp_biz_segments (
    id character varying(75) ENCODE lzo,
    name character varying(75) ENCODE lzo,
    row_key bigint ENCODE az64,
    _created_date timestamp without time zone ENCODE az64,
    _modified_date timestamp without time zone ENCODE az64,
    _deleted_date timestamp without time zone ENCODE az64
) DISTSTYLE AUTO;