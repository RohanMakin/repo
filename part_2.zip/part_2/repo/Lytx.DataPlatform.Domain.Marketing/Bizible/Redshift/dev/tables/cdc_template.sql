CREATE TABLE bizible.cdc_template (
    id character varying(100) ENCODE lzo,
    source_schema_name character varying(100) ENCODE lzo,
    source_object_name character varying(100) ENCODE lzo,
    column_names character varying(65535) ENCODE lzo,
    target_schema_name character varying(100) ENCODE lzo,
    target_object_name character varying(100) ENCODE lzo,
    dedup_table_name character varying(65535) ENCODE lzo,
    create_dedup_table_sql character varying(65535) ENCODE lzo,
    merge_table_sql character varying(65535) ENCODE lzo,
    primary_key_column character varying(100) ENCODE lzo,
    last_modified_date_column character varying(100) ENCODE lzo,
    full_load character varying(65535) ENCODE lzo,
    s3_folder_path character varying(65535) ENCODE lzo,
    json_schema_path character varying(65535) ENCODE lzo,
    schema_version character varying(18) DEFAULT '1.0':: character varying ENCODE lzo,
    record_creation_ts timestamp without time zone DEFAULT ('now':: character varying):: timestamp with time zone ENCODE az64,
    record_update_ts timestamp without time zone ENCODE az64
) DISTSTYLE AUTO;