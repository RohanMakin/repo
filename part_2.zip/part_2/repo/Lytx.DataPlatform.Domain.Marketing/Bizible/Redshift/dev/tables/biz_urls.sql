CREATE TABLE bizible.biz_urls (
    id character varying(3400) ENCODE lzo,
    scheme character varying(22) ENCODE lzo,
    host character varying(150) ENCODE lzo,
    port character varying(10) ENCODE lzo,
    path character varying(3400) ENCODE lzo,
    row_key bigint ENCODE az64,
    page_title character varying(220) ENCODE lzo,
    _created_date timestamp without time zone ENCODE az64,
    _modified_date timestamp without time zone ENCODE az64,
    _deleted_date timestamp without time zone ENCODE az64,
    record_creation_ts timestamp without time zone ENCODE az64,
    record_update_ts timestamp without time zone ENCODE az64
) DISTSTYLE AUTO;

CREATE TABLE bizible_temp.temp_biz_urls (
    id character varying(3400) ENCODE lzo,
    scheme character varying(22) ENCODE lzo,
    host character varying(150) ENCODE lzo,
    port character varying(10) ENCODE lzo,
    path character varying(3400) ENCODE lzo,
    row_key bigint ENCODE az64,
    page_title character varying(220) ENCODE lzo,
    _created_date timestamp without time zone ENCODE az64,
    _modified_date timestamp without time zone ENCODE az64,
    _deleted_date timestamp without time zone ENCODE az64
) DISTSTYLE AUTO;