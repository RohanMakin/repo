
CREATE TABLE bizible_temp.biz_facts_all_id (
    cost_key numeric(38,0) ENCODE az64,
    atp_key numeric(38,0) ENCODE az64,
    tp_key numeric(38,0) ENCODE az64,
    page_view_key numeric(38,0) ENCODE az64,
    session_key numeric(38,0) ENCODE az64,
    visitor_id character varying(65535) ENCODE lzo,
    cookie_id character varying(65535) ENCODE lzo,
    form_submit_key numeric(38,0) ENCODE az64,
    date date ENCODE az64,
    modified_date timestamp without time zone ENCODE az64,
    record_creation_ts timestamp without time zone ENCODE az64,
    record_update_ts timestamp without time zone ENCODE az64
)
DISTSTYLE AUTO;

CREATE TABLE bizible_temp.temp_biz_facts_all_id (
    cost_key numeric(38,0) ENCODE az64,
    atp_key numeric(38,0) ENCODE az64,
    tp_key numeric(38,0) ENCODE az64,
    page_view_key numeric(38,0) ENCODE az64,
    session_key numeric(38,0) ENCODE az64,
    visitor_id character varying(65535) ENCODE lzo,
    cookie_id character varying(65535) ENCODE lzo,
    form_submit_key numeric(38,0) ENCODE az64,
    date date ENCODE az64,
    modified_date timestamp without time zone ENCODE az64
)
DISTSTYLE AUTO;
