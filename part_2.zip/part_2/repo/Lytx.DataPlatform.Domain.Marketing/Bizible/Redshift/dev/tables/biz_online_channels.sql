CREATE TABLE bizible.biz_online_channels (
    channel character varying(36) ENCODE lzo,
    sub_channel character varying(32) ENCODE lzo,
    campaign character varying(40) ENCODE lzo,
    medium character varying(32) ENCODE lzo,
    source character varying(32) ENCODE lzo,
    landing_page character varying(32) ENCODE lzo,
    referring_website character varying(500) ENCODE lzo
) DISTSTYLE AUTO;

CREATE TABLE bizible_temp.temp_biz_online_channels (
    channel character varying(36) ENCODE lzo,
    sub_channel character varying(32) ENCODE lzo,
    campaign character varying(40) ENCODE lzo,
    medium character varying(32) ENCODE lzo,
    source character varying(32) ENCODE lzo,
    landing_page character varying(32) ENCODE lzo,
    referring_website character varying(500) ENCODE lzo
) DISTSTYLE AUTO;