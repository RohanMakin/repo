CREATE TABLE bizible.biz_stage_definitions (
    id character varying(40) ENCODE lzo,
    modified_date timestamp without time zone ENCODE az64,
    stage_name character varying(80) ENCODE lzo,
    is_inactive boolean ENCODE raw,
    is_in_custom_model boolean ENCODE raw,
    is_boomerang boolean ENCODE raw,
    is_transition_tracking boolean ENCODE raw,
    stage_status character varying(8) ENCODE lzo,
    is_from_salesforce boolean ENCODE raw,
    is_default boolean ENCODE raw,
    rank integer ENCODE az64,
    is_deleted boolean ENCODE raw,
    _created_date timestamp without time zone ENCODE az64,
    _modified_date timestamp without time zone ENCODE az64,
    _deleted_date timestamp without time zone ENCODE az64,
    record_creation_ts timestamp without time zone ENCODE az64,
    record_update_ts timestamp without time zone ENCODE az64
) DISTSTYLE AUTO;

CREATE TABLE bizible_temp.temp_biz_stage_definitions (
    id character varying(40) ENCODE lzo,
    modified_date timestamp without time zone ENCODE az64,
    stage_name character varying(80) ENCODE lzo,
    is_inactive boolean ENCODE raw,
    is_in_custom_model boolean ENCODE raw,
    is_boomerang boolean ENCODE raw,
    is_transition_tracking boolean ENCODE raw,
    stage_status character varying(8) ENCODE lzo,
    is_from_salesforce boolean ENCODE raw,
    is_default boolean ENCODE raw,
    rank integer ENCODE az64,
    is_deleted boolean ENCODE raw,
    _created_date timestamp without time zone ENCODE az64,
    _modified_date timestamp without time zone ENCODE az64,
    _deleted_date timestamp without time zone ENCODE az64
) DISTSTYLE AUTO;