CREATE OR REPLACE PROCEDURE bizible.apply_cdc(p_schema_name character varying(100), p_table_name character varying(100), p_iam_role character varying(100), p_days_back_to_consider integer, p_from_date date)
 NONATOMIC
 LANGUAGE plpgsql
AS $$
DECLARE
    vc_create_dedup_table_sql CHARACTER VARYING(65535);
    vc_merge_table_sql CHARACTER VARYING(65535);
    vc_full_load BOOLEAN;
    vc_s3_folder_path CHARACTER VARYING(65535);
    vc_json_schema_path CHARACTER VARYING(65535);
    vc_temp_schema_name CHARACTER VARYING(100);
    vc_temp_table_name CHARACTER VARYING(100);
    vc_temp_table CHARACTER VARYING(100);
    vc_column_names CHARACTER VARYING(65535);
    v_file_paths CHARACTER VARYING(65535) := '';
    v_result CHARACTER VARYING(65535):= '';
    vc_copy_sql_command CHARACTER VARYING(65535);
    vc_full_load_sql_command CHARACTER VARYING(65535);
    vc_dedup_table_name CHARACTER VARYING(65535);
    i INT;
    sql_text  CHARACTER VARYING(65535);
    vc_s3_folder_path_day CHARACTER VARYING(65535);
    vd_from_date date;
BEGIN
   -- Set the default value for p_from_date if it is NULL
    vd_from_date:=coalesce(p_from_date,CURRENT_DATE);
    -- Retrieve CDC template details
    SELECT DEDUP_TABLE_NAME,
           CREATE_DEDUP_TABLE_SQL,
           MERGE_TABLE_SQL,
           FULL_LOAD,
           S3_FOLDER_PATH,
           JSON_SCHEMA_PATH,
           SOURCE_SCHEMA_NAME,
           SOURCE_OBJECT_NAME,
           COLUMN_NAMES
    INTO vc_dedup_table_name,
         vc_create_dedup_table_sql,
         vc_merge_table_sql,
         vc_full_load,
         vc_s3_folder_path,
         vc_json_schema_path,
         vc_temp_schema_name,
         vc_temp_table_name,
         vc_column_names
    FROM bizible.CDC_TEMPLATE
    WHERE TARGET_OBJECT_NAME = p_table_name
      AND TARGET_SCHEMA_NAME = p_schema_name;

    RAISE INFO 'Data selected from CDC_TEMPLATE';

    vc_temp_table := vc_temp_schema_name || '.' || vc_temp_table_name;

    -- Validate CDC template data
    IF (vc_full_load IS FALSE AND vc_create_dedup_table_sql IS NULL) OR vc_merge_table_sql IS NULL THEN
        v_result := 'Failure, CDC template table does not have template saved for ' || p_table_name || ' table';
        sql_text := 'INSERT INTO bizible.load_history (table_name, file_path, success, error_message) VALUES ('
            || quote_literal(p_table_name) || ', '
            || quote_literal('CDC_TEMPLATE') || ', '
            || 'FALSE, '
            || quote_literal(v_result)
            || ')';

        -- Execute the dynamic SQL statement
        EXECUTE sql_text;
        RETURN;
    END IF;

    -- Truncate the temporary table
    EXECUTE 'TRUNCATE TABLE ' || vc_temp_table;

    -- Perform full load or incremental load
    IF vc_full_load = 'TRUE' THEN
        -- Full load
        vc_full_load_sql_command := 'COPY ' || vc_temp_table||'('||vc_column_names||')'|| ' FROM ''' || vc_s3_folder_path || ''' IAM_ROLE ''' || p_iam_role || ''' format as json ''' || vc_json_schema_path || ''' timeformat ''auto''';
        EXECUTE vc_full_load_sql_command;
        EXECUTE 'TRUNCATE TABLE ' || p_schema_name || '.' || p_table_name;
        EXECUTE vc_merge_table_sql;
		v_file_paths := vc_s3_folder_path;
        RAISE INFO 'sql_command: %', vc_merge_table_sql;
    ELSE
      -- BEGIN -- Incremental load
     --  START TRANSACTION;
        FOR i IN 0..(p_days_back_to_consider - 1) LOOP
            vc_s3_folder_path_day := vc_s3_folder_path || TO_CHAR(vd_from_date - i, 'YYYY') || '/' || TO_CHAR(vd_from_date - i, 'FMMM') || '/' || TO_CHAR(vd_from_date - i, 'FMDD') || '/';
            vc_copy_sql_command := 'COPY ' || vc_temp_table || '(' || vc_column_names || ') FROM ''' || vc_s3_folder_path_day || ''' IAM_ROLE ''' || p_iam_role || ''' FORMAT AS JSON ''' || vc_json_schema_path || ''' TIMEFORMAT ''auto''';
            BEGIN
                EXECUTE vc_copy_sql_command;
                v_file_paths := v_file_paths || vc_s3_folder_path_day || ';;';
            EXCEPTION WHEN OTHERS THEN
                RAISE INFO 'Path not found for day: %', vc_s3_folder_path_day;
                RAISE INFO 'copy command : %',vc_copy_sql_command;
            END;
        END LOOP;

        -- Create deduplication table and merge data
        EXECUTE 'DROP TABLE IF EXISTS ' || vc_dedup_table_name;
        RAISE INFO 'Dedup table dropped if exists';
        EXECUTE vc_create_dedup_table_sql;
        EXECUTE vc_merge_table_sql;
        RAISE INFO 'Incremental load executed';
    END IF;
    -- Log successful load
    v_result := 'Loaded Successfully without any error';
    sql_text := 'INSERT INTO bizible.load_history (table_name, file_path, success, error_message) VALUES ('
        || quote_literal(p_table_name) || ', '
        || quote_literal(v_file_paths) || ', '
        || 'TRUE, '
        || quote_literal(v_result)
        || ')';
    EXECUTE sql_text;

    RAISE INFO 'Status: %', v_result;
EXCEPTION
    WHEN OTHERS THEN
        v_result := 'Failed: Code: ' || SQLSTATE || ' Message: ' || SQLERRM;
        sql_text := 'INSERT INTO bizible.load_history (table_name, file_path, success, error_message) VALUES ('
            || quote_literal(p_table_name) || ', '
            || quote_literal(v_file_paths) || ', '
            || 'FALSE, '
            || quote_literal(v_result)
            || ')';

        -- Execute the dynamic SQL statement
        EXECUTE sql_text;

END;
$$
