CREATE OR REPLACE PROCEDURE bizible_temp.remove_deleted_records()
 NONATOMIC
 LANGUAGE plpgsql
AS $$
BEGIN
	
   --POPULATE ALL_IDS
   call bizible.apply_cdc('bizible_temp','biz_campaign_members_all_id','arn:aws:iam::407799361832:role/LYTX_DP_APP_REDSHIFT_ACCESS_PROD',1,NULL);
   
   call bizible.apply_cdc('bizible_temp','biz_contacts_all_id','arn:aws:iam::407799361832:role/LYTX_DP_APP_REDSHIFT_ACCESS_PROD',1,NULL);

   call bizible.apply_cdc('bizible_temp','biz_facts_all_id','arn:aws:iam::407799361832:role/LYTX_DP_APP_REDSHIFT_ACCESS_PROD',1,NULL);
   
   call bizible.apply_cdc('bizible_temp','biz_page_views_all_id','arn:aws:iam::407799361832:role/LYTX_DP_APP_REDSHIFT_ACCESS_PROD',1,NULL);
   
   call bizible.apply_cdc('bizible_temp','biz_account_to_emails_all_id','arn:aws:iam::407799361832:role/LYTX_DP_APP_REDSHIFT_ACCESS_PROD',1,NULL);
   
   call bizible.apply_cdc('bizible_temp','biz_crm_tasks_all_id','arn:aws:iam::407799361832:role/LYTX_DP_APP_REDSHIFT_ACCESS_PROD',1,NULL);
   
   call bizible.apply_cdc('bizible_temp','biz_costs_all_id','arn:aws:iam::407799361832:role/LYTX_DP_APP_REDSHIFT_ACCESS_PROD',1,NULL);
   
   call bizible.apply_cdc('bizible_temp','biz_leads_all_id','arn:aws:iam::407799361832:role/LYTX_DP_APP_REDSHIFT_ACCESS_PROD',1,NULL);
   
   call bizible.apply_cdc('bizible_temp','biz_sessions_all_id','arn:aws:iam::407799361832:role/LYTX_DP_APP_REDSHIFT_ACCESS_PROD',1,NULL);
   
      delete from bizible.BIZ_CAMPAIGN_MEMBERS 
    using
    (select camp.id 
    from 
    (select * from bizible.BIZ_CAMPAIGN_MEMBERS bcm where bcm.modified_date <
    (
        select case when mx_mod_main < mx_mod_all then mx_mod_main else mx_mod_all end
        from (select max(coalesce(modified_date,'1900-01-01')) mx_mod_main , 1 id from bizible.BIZ_CAMPAIGN_MEMBERS) a
        join (select max(coalesce(modified_date,'1900-01-01')) as mx_mod_all , 1 id from bizible_temp.BIZ_CAMPAIGN_MEMBERS_ALL_ID) b
        on a.id=b.id
    )) camp 
    left join bizible_temp.BIZ_CAMPAIGN_MEMBERS_ALL_ID full_id on camp.id = full_id.id
    where full_id.id is null) q2 where BIZ_CAMPAIGN_MEMBERS.id = q2.id;

       delete from bizible.BIZ_ACCOUNT_TO_EMAILS 
    using
    (select ate.id 
    from 
    (select * from bizible.BIZ_ACCOUNT_TO_EMAILS bcm where bcm.modified_date <
    (
        select case when mx_mod_main < mx_mod_all then mx_mod_main else mx_mod_all end
        from (select max(coalesce(modified_date,'1900-01-01')) mx_mod_main , 1 id from bizible.BIZ_ACCOUNT_TO_EMAILS) a
        join (select max(coalesce(modified_date,'1900-01-01')) as mx_mod_all , 1 id from bizible_temp.BIZ_ACCOUNT_TO_EMAILS_ALL_ID) b
        on a.id=b.id
    )) ate 
    left join bizible_temp.BIZ_ACCOUNT_TO_EMAILS_ALL_ID full_id on ate.id = full_id.id
    where full_id.id is null) q2 where BIZ_ACCOUNT_TO_EMAILS.id = q2.id;

    delete from bizible.BIZ_COSTS 
    using
    (select cost.id 
    from 
    (select * from bizible.BIZ_COSTS bcm where bcm._modified_date <
    (
        select case when mx_mod_main < mx_mod_all then mx_mod_main else mx_mod_all end
        from (select max(coalesce(_modified_date,'1900-01-01')) mx_mod_main , 1 id from bizible.BIZ_COSTS) a
        join (select max(coalesce(_modified_date,'1900-01-01')) as mx_mod_all , 1 id from bizible_temp.BIZ_COSTS_ALL_ID) b
        on a.id=b.id
    )) cost 
    left join bizible_temp.BIZ_COSTS_ALL_ID full_id on cost.id = full_id.id
    where full_id.id is null) q2 where BIZ_COSTS.id = q2.id ;
    
    
    delete from bizible.BIZ_CONTACTS 
    using
    (select cont.id 
    from 
    (select * from bizible.BIZ_CONTACTS bcm where bcm.modified_date <
    (
        select case when mx_mod_main < mx_mod_all then mx_mod_main else mx_mod_all end
        from (select max(coalesce(modified_date,'1900-01-01')) mx_mod_main , 1 id from bizible.BIZ_CONTACTS) a
        join (select max(coalesce(modified_date,'1900-01-01')) as mx_mod_all , 1 id from bizible_temp.BIZ_CONTACTS_ALL_ID) b
        on a.id=b.id
    )) cont 
    left join bizible_temp.BIZ_CONTACTS_ALL_ID full_id on cont.id = full_id.id
    where full_id.id is null) q2 where BIZ_CONTACTS.id = q2.id ;
    
    
    delete from bizible.BIZ_CRM_TASKS 
    using
    (select task.id 
    from 
    (select * from bizible.BIZ_CRM_TASKS bcm where bcm.modified_date <
    (
        select case when mx_mod_main < mx_mod_all then mx_mod_main else mx_mod_all end
        from (select max(coalesce(modified_date,'1900-01-01')) mx_mod_main , 1 id from bizible.BIZ_CRM_TASKS) a
        join (select max(coalesce(modified_date,'1900-01-01')) as mx_mod_all , 1 id from bizible_temp.BIZ_CRM_TASKS_ALL_ID) b
        on a.id=b.id
    )) task 
    left join bizible_temp.BIZ_CRM_TASKS_ALL_ID full_id on task.id = full_id.id
    where full_id.id is null) q2 where BIZ_CRM_TASKS.id = q2.id ;
    
    
    
    delete from bizible.BIZ_LEADS 
    using
    (select lead.id 
    from 
    (select * from bizible.BIZ_LEADS bcm where bcm.modified_date <
    (
        select case when mx_mod_main < mx_mod_all then mx_mod_main else mx_mod_all end
        from (select max(coalesce(modified_date,'1900-01-01')) mx_mod_main , 1 id from bizible.BIZ_LEADS) a
        join (select max(coalesce(modified_date,'1900-01-01')) as mx_mod_all , 1 id from bizible_temp.BIZ_LEADS_ALL_ID) b
        on a.id=b.id
    )) lead 
    left join bizible_temp.BIZ_LEADS_ALL_ID full_id on lead.id = full_id.id
    where full_id.id is null) q2 where BIZ_LEADS.id = q2.id;
    
    
    
    delete from bizible.BIZ_PAGE_VIEWS 
    using
    (select p_view.id 
    from 
    (select * from bizible.BIZ_PAGE_VIEWS bcm where bcm.modified_date <
    (
        select case when mx_mod_main < mx_mod_all then mx_mod_main else mx_mod_all end
        from (select max(coalesce(modified_date,'1900-01-01')) mx_mod_main , 1 id from bizible.BIZ_PAGE_VIEWS) a
        join (select max(coalesce(modified_date,'1900-01-01')) as mx_mod_all , 1 id from bizible_temp.BIZ_PAGE_VIEWS_ALL_ID) b
        on a.id=b.id
    )) p_view 
    left join bizible_temp.BIZ_PAGE_VIEWS_ALL_ID full_id on p_view.id = full_id.id
    where full_id.id is null) q2 where BIZ_PAGE_VIEWS.id = q2.id;
    
    delete from bizible.BIZ_SESSIONS 
    using
    (select sess.id 
    from 
    (select * from bizible.BIZ_SESSIONS bcm where bcm.modified_date <
    (
        select case when mx_mod_main < mx_mod_all then mx_mod_main else mx_mod_all end
        from (select max(coalesce(modified_date,'1900-01-01')) mx_mod_main , 1 id from bizible.BIZ_SESSIONS) a
        join (select max(coalesce(modified_date,'1900-01-01')) as mx_mod_all , 1 id from bizible_temp.BIZ_SESSIONS_ALL_ID) b
        on a.id=b.id
    )) sess 
    left join bizible_temp.BIZ_SESSIONS_ALL_ID full_id on sess.id = full_id.id
    where full_id.id is null) q2 where BIZ_SESSIONS.id = q2.id ;
    
    delete from bizible.BIZ_FACTS 
    using
    (select fact.COST_KEY,fact.ATP_KEY,fact.TP_KEY,fact.PAGE_VIEW_KEY,fact.SESSION_KEY,fact.VISITOR_ID,fact.COOKIE_ID,fact.FORM_SUBMIT_KEY  
    from 
    (select * from bizible.BIZ_FACTS bcm where bcm.modified_date <
    (
        select case when mx_mod_main < mx_mod_all then mx_mod_main else mx_mod_all end
        from (select max(coalesce(modified_date,'1900-01-01')) mx_mod_main , 1 id from bizible.BIZ_FACTS) a
        join (select max(coalesce(modified_date,'1900-01-01')) as mx_mod_all , 1 id from bizible_temp.BIZ_FACTS_ALL_ID) b
        on a.id=b.id
    )) fact 
    left join bizible_temp.BIZ_FACTS_ALL_ID full_id 
    on coalesce(fact.COST_KEY,-1) = coalesce(full_id.COST_KEY,-1) 
    	and coalesce(fact.ATP_KEY,-1) = coalesce(full_id.ATP_KEY,-1) 
    	and coalesce(fact.TP_KEY,-1) = coalesce(full_id.TP_KEY,-1) 
    	and coalesce(fact.PAGE_VIEW_KEY,-1) = coalesce(full_id.PAGE_VIEW_KEY,-1) 
    	and coalesce(fact.SESSION_KEY,-1) = coalesce(full_id.SESSION_KEY,-1) 
    	and coalesce(fact.VISITOR_ID,'unknown') = coalesce(full_id.VISITOR_ID,'unknown') 
    	and coalesce(fact.COOKIE_ID,'unknown') = coalesce(full_id.COOKIE_ID,'unknown') 
    	and coalesce(fact.FORM_SUBMIT_KEY,-1) = coalesce(full_id.FORM_SUBMIT_KEY,-1)
    	where full_id.COST_KEY is null 
    	and full_id.ATP_KEY is null  
    	and full_id.TP_KEY is null
    	and full_id.PAGE_VIEW_KEY is null
    	and full_id.SESSION_KEY is null
    	and full_id.VISITOR_ID is null
    	and full_id.COOKIE_ID is null
    	and full_id.FORM_SUBMIT_KEY is null) q2  
    where 
    	coalesce(BIZ_FACTS.COST_KEY,-1) = coalesce(q2.COST_KEY,-1) 
    	and coalesce(BIZ_FACTS.ATP_KEY,-1) = coalesce(q2.ATP_KEY,-1) 
    	and coalesce(BIZ_FACTS.TP_KEY,-1) = coalesce(q2.TP_KEY,-1) 
    	and coalesce(BIZ_FACTS.PAGE_VIEW_KEY,-1) = coalesce(q2.PAGE_VIEW_KEY,-1) 
    	and coalesce(BIZ_FACTS.SESSION_KEY,-1) = coalesce(q2.SESSION_KEY,-1) 
    	and coalesce(BIZ_FACTS.VISITOR_ID,'unknown') = coalesce(q2.VISITOR_ID,'unknown') 
    	and coalesce(BIZ_FACTS.COOKIE_ID,'unknown') = coalesce(q2.COOKIE_ID,'unknown') 
    	and coalesce(BIZ_FACTS.FORM_SUBMIT_KEY,-1) = coalesce(q2.FORM_SUBMIT_KEY,-1) ;

   
END;
$$
