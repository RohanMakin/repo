CREATE OR REPLACE PROCEDURE bizible.call_apply_cdc_for_bizible_object_list()
 NONATOMIC
 LANGUAGE plpgsql
AS $$
BEGIN

--    call bizible.apply_cdc('bizible','biz_campaign_members','arn:aws:iam::746068287266:role/LYTX_DP_APP_REDSHIFT_ACCESS_NON_PROD',10,NULL);
--    call bizible.apply_cdc('bizible','biz_ad_groups','arn:aws:iam::746068287266:role/LYTX_DP_APP_REDSHIFT_ACCESS_NON_PROD',10,NULL);
--    call bizible.apply_cdc('bizible','biz_ad_providers','arn:aws:iam::746068287266:role/LYTX_DP_APP_REDSHIFT_ACCESS_NON_PROD',10,NULL);
--    call bizible.apply_cdc('bizible','biz_email_to_visitor_ids','arn:aws:iam::746068287266:role/LYTX_DP_APP_REDSHIFT_ACCESS_NON_PROD',10,NULL);
--    call bizible.apply_cdc('bizible','biz_currencies','arn:aws:iam::746068287266:role/LYTX_DP_APP_REDSHIFT_ACCESS_NON_PROD',10,NULL);
--    call bizible.apply_cdc('bizible','biz_crm_tasks','arn:aws:iam::746068287266:role/LYTX_DP_APP_REDSHIFT_ACCESS_NON_PROD',10,NULL);
--    call bizible.apply_cdc('bizible','biz_crm_events','arn:aws:iam::746068287266:role/LYTX_DP_APP_REDSHIFT_ACCESS_NON_PROD',10,NULL);
--    call bizible.apply_cdc('bizible','biz_creatives','arn:aws:iam::746068287266:role/LYTX_DP_APP_REDSHIFT_ACCESS_NON_PROD',10,NULL);
--    call bizible.apply_cdc('bizible','biz_costs','arn:aws:iam::746068287266:role/LYTX_DP_APP_REDSHIFT_ACCESS_NON_PROD',10,NULL);
--    call bizible.apply_cdc('bizible','biz_conversion_rates','arn:aws:iam::746068287266:role/LYTX_DP_APP_REDSHIFT_ACCESS_NON_PROD',10,NULL);
--    call bizible.apply_cdc('bizible','biz_contacts','arn:aws:iam::746068287266:role/LYTX_DP_APP_REDSHIFT_ACCESS_NON_PROD',10,NULL);
--    call bizible.apply_cdc('bizible','biz_channels','arn:aws:iam::746068287266:role/LYTX_DP_APP_REDSHIFT_ACCESS_NON_PROD',10,NULL);
--    call bizible.apply_cdc('bizible','biz_account_to_emails','arn:aws:iam::746068287266:role/LYTX_DP_APP_REDSHIFT_ACCESS_NON_PROD',10,NULL);
--    call bizible.apply_cdc('bizible','biz_accounts','arn:aws:iam::746068287266:role/LYTX_DP_APP_REDSHIFT_ACCESS_NON_PROD',10,NULL);
--    call bizible.apply_cdc('bizible','biz_facts','arn:aws:iam::746068287266:role/LYTX_DP_APP_REDSHIFT_ACCESS_NON_PROD',10,NULL);
--    call bizible.apply_cdc('bizible','biz_ads','arn:aws:iam::746068287266:role/LYTX_DP_APP_REDSHIFT_ACCESS_NON_PROD',10,NULL);

    call bizible.apply_cdc('bizible','biz_web_host_mappings','arn:aws:iam::407799361832:role/LYTX_DP_APP_REDSHIFT_ACCESS_PROD',1,NULL);
    call bizible.apply_cdc('bizible','biz_user_touchpoints','arn:aws:iam::407799361832:role/LYTX_DP_APP_REDSHIFT_ACCESS_PROD',1,NULL);
    call bizible.apply_cdc('bizible','biz_urls','arn:aws:iam::407799361832:role/LYTX_DP_APP_REDSHIFT_ACCESS_PROD',1,NULL);
    call bizible.apply_cdc('bizible','biz_touchpoints','arn:aws:iam::407799361832:role/LYTX_DP_APP_REDSHIFT_ACCESS_PROD',1,NULL);
    call bizible.apply_cdc('bizible','biz_stage_definitions','arn:aws:iam::407799361832:role/LYTX_DP_APP_REDSHIFT_ACCESS_PROD',1,NULL);
    call bizible.apply_cdc('bizible','biz_site_links','arn:aws:iam::407799361832:role/LYTX_DP_APP_REDSHIFT_ACCESS_PROD',1,NULL);
    call bizible.apply_cdc('bizible','biz_sessions','arn:aws:iam::407799361832:role/LYTX_DP_APP_REDSHIFT_ACCESS_PROD',1,NULL);
    call bizible.apply_cdc('bizible','biz_segments','arn:aws:iam::407799361832:role/LYTX_DP_APP_REDSHIFT_ACCESS_PROD',1,NULL);
    call bizible.apply_cdc('bizible','biz_opp_stage_transitions','arn:aws:iam::407799361832:role/LYTX_DP_APP_REDSHIFT_ACCESS_PROD',1,NULL);
    call bizible.apply_cdc('bizible','biz_page_views','arn:aws:iam::407799361832:role/LYTX_DP_APP_REDSHIFT_ACCESS_PROD',1,NULL);
    call bizible.apply_cdc('bizible','biz_opportunities','arn:aws:iam::407799361832:role/LYTX_DP_APP_REDSHIFT_ACCESS_PROD',1,NULL);
    call bizible.apply_cdc('bizible','biz_lead_stage_transitions','arn:aws:iam::407799361832:role/LYTX_DP_APP_REDSHIFT_ACCESS_PROD',1,NULL);
    call bizible.apply_cdc('bizible','biz_leads','arn:aws:iam::407799361832:role/LYTX_DP_APP_REDSHIFT_ACCESS_PROD',1,NULL);
    call bizible.apply_cdc('bizible','biz_keywords','arn:aws:iam::407799361832:role/LYTX_DP_APP_REDSHIFT_ACCESS_PROD',1,NULL);
    call bizible.apply_cdc('bizible','biz_form_submits','arn:aws:iam::407799361832:role/LYTX_DP_APP_REDSHIFT_ACCESS_PROD',1,NULL);
    END;
$$
