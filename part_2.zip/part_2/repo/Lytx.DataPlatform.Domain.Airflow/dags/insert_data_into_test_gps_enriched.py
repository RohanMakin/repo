import logging
from datetime import datetime
from airflow import DAG
from airflow.operators.python import PythonOperator
from airflow.providers.postgres.hooks.postgres import PostgresHook

dag = DAG(
    'insert_data_into_test_gps_enriched',
    start_date=datetime(2025, 2, 11),
    schedule_interval=None,
    # catchup=True,  # Ensure we handle past DAG runs properly
    # max_active_tasks=3,
)

redshift_hook = PostgresHook(postgres_conn_id='redshift_dp_prod_db', database='dp_prod_db')


def run_redshift_query():

    sql_query = """

        begin;

            DELETE from "dp_config"."test_gps_enriched_level0";

            DELETE FROM "dp_config"."test_gps_enriched_level0_historical";

            INSERT INTO "dp_config"."test_gps_enriched_level0"
            SELECT *
            FROM "gps"."gps_enriched_level0"
            WHERE "device_date" >= CURRENT_DATE - INTERVAL '30 days';

        commit;
        end;

    """
    records = redshift_hook.run(sql_query)
    logging.info(records)
    return records


run_redshift_query = PythonOperator(
    task_id='run_redshift_query',
    python_callable=run_redshift_query,
    dag=dag,
)

run_redshift_query
# The DAG will run the `run_redshift_query` function when executed
# The function will connect to Redshift and run the SQL query
