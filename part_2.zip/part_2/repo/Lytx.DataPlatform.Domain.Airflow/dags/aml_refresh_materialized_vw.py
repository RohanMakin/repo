############################################################################
# Name  : authentication_redshift_loader
# Written By : Anand Palaniappan
# Description: To load authentication data from S3 to Redshift
############################################################################


import logging
import pytz
from datetime import timedelta, datetime
from airflow import DAG
from airflow.hooks.base_hook import BaseHook
from airflow.providers.slack.operators.slack_webhook import SlackWebhookOperator
from airflow.providers.postgres.operators.postgres import PostgresOperator
from airflow.operators.dummy import DummyOperator

global result

logging.getLogger().setLevel(logging.WARN)


# Alerts the dataplatform_alerts_channel of any errors ###
def task_fail_slack_alert(context):
    slack_webhook_token = BaseHook.get_connection('slack_connection_id').password
    shifted_time = context.get('execution_date').astimezone(pytz.timezone('US/Pacific')).strftime('%m-%d-%Y %H:%M:%S')

    slack_msg = f"""
            :red_circle: Task Failed. See details below:
            *Task*: {context.get('task_instance').task_id}
            *Dag*: {context.get('task_instance').dag_id}
            *Execution Time*: {shifted_time}
            *Log Url*: {context.get('task_instance').log_url}
            """

    failed_alert = SlackWebhookOperator(
        task_id='slack_send_alert',
        http_conn_id='slack_connection_id',
        webhook_token=slack_webhook_token,
        message=slack_msg,
        username='airflow')

    return failed_alert.execute(context=context)


args = {
    'owner': 'Anand Palaniappan',
    'start_date': datetime(2024, 5, 30),
    'email': ['anand.palaniappan@lytx.com'],
    'email_on_failure': False,
    'on_failure_callback': task_fail_slack_alert,
    'pass_value': 'pass',
    'database': 'dp_prod_db',
    'conn_id': 'redshift_dp_prod_db',
    'postgres_conn_id': 'redshift_dp_prod_db',
}

dag = DAG(
    dag_id='aml_refresh_materialized_vw',
    default_args=args,
    schedule_interval='35 */3 * * *',
    dagrun_timeout=timedelta(minutes=120),
    catchup=False,
)

start_task = DummyOperator(task_id='start_task', dag=dag)

refresh_aml_vw = PostgresOperator(
    task_id='refresh_aml_vw',
    sql='REFRESH MATERIALIZED VIEW dp_prod_db.risk.device_inside_lens_prediction_aml_vw;',
    autocommit=True,
    postgres_conn_id=args['conn_id'],
    dag=dag,
)

end_task = DummyOperator(task_id='end_task', dag=dag)

start_task >> refresh_aml_vw >> end_task
