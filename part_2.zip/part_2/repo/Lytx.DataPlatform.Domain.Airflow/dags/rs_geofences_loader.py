import json
import logging
import pytz
import urllib.parse
from datetime import timedelta, datetime
from airflow import DAG
from airflow.hooks.base_hook import BaseHook
from airflow.providers.slack.operators.slack_webhook import SlackWebhookOperator
from airflow.providers.postgres.operators.postgres import PostgresOperator
from airflow.operators.dummy import DummyOperator
from airflow.operators.python_operator import PythonOperator
from airflow.providers.amazon.aws.sensors.sqs import SqsSensor

global result

SQS_URL = 'https://sqs.us-west-2.amazonaws.com/407799361832/ore-prod-dp-sqs-geofence-airflow'
SELECT_QRY = """geofence.geofences (inclusive,kafka_ts,end_date,geofence_type_id,group_id,effective_end_time,geofence_geography,include_sub_groups,is_active,asset_group_id,
    effective_days_of_week,effective_start_time,name,correlation_id,fence_roll_up_id,id,root_group_id,event_recorder_id,vehicle_id,geofence_geography_json,company_id,
    messageTimestamp,record_creation_ts)
    select inclusive,kafka_ts::timestamp,enddate,geofencetypeid,groupid,effectiveendtime,geofencegeography,includesubgroups,isactive,assetgroupid,effectivedaysofweek,
    effectivestarttime,name,correlationid,fencerollupid,id,rootgroupid,eventrecorderid,vehicleid,geofencegeographyjson,companyid,messageTimestamp,
    CURRENT_TIMESTAMP from geofence_ext.geofences_refined
    """


def task_fail_slack_alert(context):
    slack_webhook_token = BaseHook.get_connection('slack_connection_id').password
    shifted_time = context.get('execution_date').astimezone(pytz.timezone('US/Pacific')).strftime('%m-%d-%Y %H:%M:%S')
    slack_msg = f"""
            :red_circle: Task Failed. See details below:
            *Task*: {context.get('task_instance').task_id}
            *Dag*: {context.get('task_instance').dag_id}
            *Execution Time*: {shifted_time}
            *Log Url*: {context.get('task_instance').log_url}
            """
    failed_alert = SlackWebhookOperator(
        task_id='slack_send_alert',
        http_conn_id='slack_connection_id',
        webhook_token=slack_webhook_token,
        message=slack_msg,
        username='airflow')
    return failed_alert.execute(context=context)


def get_timestamp(**kwargs):
    ti = kwargs['ti']
    # Retrieve the timestamp argument from Airflow Variables or context
    x_timestamp_str = kwargs.get('dag_run').conf.get('x_timestamp') if kwargs.get('dag_run') else None

    if x_timestamp_str:
        try:
            # Convert the string to a datetime object
            x_timestamp = datetime.strptime(x_timestamp_str, '%Y-%m-%d %H:%M:%S')
        except ValueError:
            logging.error(f"Incorrect format for timestamp: {x_timestamp_str}. Expected format: 'YYYY-MM-DD HH:MM:SS'")
            # Use the current datetime if the provided timestamp is invalid
            x_timestamp = datetime.now()
    else:
        x_timestamp = datetime.now()

    # Log the timestamp
    logging.info(f"x_timestamp: {x_timestamp}")

    # Push the timestamp to XCom
    ti.xcom_push(key='x_timestamp', value=x_timestamp.strftime('%Y-%m-%d %H:%M:%S'))


def read_sqs_message(**kwargs):
    sqs_messages = kwargs['ti'].xcom_pull(key='messages', task_ids='receive_sqs_message')
    s3_events = []
    s3_path = []
    s3_keys = []
    if sqs_messages:
        for message in sqs_messages:
            body = json.loads(message['Body'])
            for record in body['Records']:
                bucket = record['s3']['bucket']['name']
                key = urllib.parse.unquote(record['s3']['object']['key'])
                s3_events.append((bucket, key))
                s3_path.append("s3://"+bucket+"/"+key)
                s3_keys.append(key)
    kwargs['ti'].xcom_push(key='s3_events', value=s3_events)
    kwargs['ti'].xcom_push(key='s3_path', value=s3_path)
    kwargs['ti'].xcom_push(key='s3_keys', value=s3_keys)


def check_sqs_message(**kwargs):
    messages = kwargs['ti'].xcom_pull(task_ids='receive_sqs_message')
    if messages is None:
        return 'end_task'
    return 'process_sqs_message'


def get_companyid_and_keys_filter(input_s3_keys):
    s3_keys_filter, company_id_filter = '', ''
    company_set = set()
    for keys in input_s3_keys:
        # s3_keys_filter.append("'"+keys+"',")
        s3_keys_filter = s3_keys_filter + "'" + keys + "',"
        key_parts = keys.split("/")
        for part in key_parts:
            if part.startswith('companyId='):
                company_id_value = part.split('=')[1]
                company_set.add(company_id_value)
                break
    # remove last comma
    if s3_keys_filter.endswith(','):
        s3_keys_filter = s3_keys_filter[:-1]
    company_id_filter = ",".join(company_set)
    return s3_keys_filter, company_id_filter


def create_insert_query(**kwargs):
    input_s3_keys = kwargs['ti'].xcom_pull(key='s3_path', task_ids='process_sqs_message')
    logging.info("value of input_s3_keys ", input_s3_keys)
    s3_keys_filter, company_id_filter = get_companyid_and_keys_filter(input_s3_keys)
    insert_records_sql = f"""
        insert into {SELECT_QRY} where "$path" in ({s3_keys_filter}) and companyid in ({company_id_filter});
        """
    kwargs['ti'].xcom_push(key='insert_records_sql', value=insert_records_sql)


args = {
    'owner': 'Anand Palaniappan',
    'start_date': datetime(2024, 6, 10),
    'email': ['anand.palaniappan@lytx.com'],
    'email_on_failure': False,
    'on_failure_callback': task_fail_slack_alert,
    'pass_value': 'pass',
    'database': 'dp_prod_db',
    'conn_id': 'redshift_dp_prod_db',
    'postgres_conn_id': 'redshift_dp_prod_db',
}


dag = DAG(
    dag_id='rs_geofences_loader',
    default_args=args,
    schedule_interval='*/5 * * * *',
    dagrun_timeout=timedelta(minutes=120),
    catchup=False,
)

with dag:
    start_task = DummyOperator(task_id='start_task', dag=dag)

    get_timestamp_task = PythonOperator(
        task_id='get_timestamp_task',
        python_callable=get_timestamp,
        provide_context=True,
    )

    receive_sqs_message = SqsSensor(
        task_id='receive_sqs_message',
        sqs_queue=SQS_URL,
        max_messages=5,  # Read up to 5 messages
        timeout=60,  # waits for a minute before timing out
        mode='reschedule',  # Reschedule to avoid blocking a worker
        soft_fail=True,
        poke_interval=10,
        dag=dag,
    )

    check_sqs_response = PythonOperator(
        task_id='check_sqs_response',
        python_callable=check_sqs_message,
        provide_context=True,
        dag=dag,
    )

    process_sqs_message = PythonOperator(
        task_id='process_sqs_message',
        python_callable=read_sqs_message,
        provide_context=True,
        dag=dag,
    )

    generate_insert_query = PythonOperator(
        task_id='generate_insert_query',
        python_callable=create_insert_query,
        provide_context=True
    )

    execute_insert = PostgresOperator(
        task_id='execute_insert',
        sql="{{ task_instance.xcom_pull(task_ids='generate_insert_query', key='insert_records_sql') }}",
    )

    end_task = DummyOperator(task_id='end_task', dag=dag)

start_task >> get_timestamp_task >> receive_sqs_message >> check_sqs_response >> [process_sqs_message, end_task]
process_sqs_message >> generate_insert_query >> execute_insert >> end_task
