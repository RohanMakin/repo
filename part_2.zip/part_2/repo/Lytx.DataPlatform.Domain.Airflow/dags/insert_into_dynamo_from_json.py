from airflow import DAG
from airflow.providers.amazon.aws.hooks.s3 import S3Hook
from airflow.operators.python_operator import PythonOperator
from datetime import datetime
import json
import boto3

# Define constants
AWS_CONN_ID = 'aws_default'
S3_BUCKET_NAME = 'lytx-dataplatform-code-prod-oregon-003'
S3_OBJECT_KEY = 'managed_airflow/files/table_list.json'
DYNAMO_DB_TABLE_NAME = 'managed_airflow_to_archive_records_at_redshift'

# Initialize DynamoDB client
dynamodb = boto3.client('dynamodb')


# Function to process the JSON file and insert into DynamoDB
def insert_into_dynamo_db(**kwargs):
    # Hook to get file from S3
    s3_hook = S3Hook(aws_conn_id=AWS_CONN_ID)

    # Read the JSON file from S3
    file_obj = s3_hook.get_key(S3_OBJECT_KEY, S3_BUCKET_NAME)

    if file_obj:
        # Parse the JSON data
        json_data = json.loads(file_obj.get()['Body'].read().decode('utf-8'))

        # Iterate over each item and insert it into DynamoDB
        for item in json_data:
            # Insert item into DynamoDB table
            dynamodb.put_item(
                TableName=DYNAMO_DB_TABLE_NAME,
                Item={
                    'PK': item['PK'],
                    'SK': item['SK'],
                    'DB': item['DB'],
                    'schema': item['schema'],
                    'condition_column': item['condition_column'],
                    'retention_days': item['retention_days'],
                    'other_filter': item['other_filter']
                }
            )
            print(f"Inserted item: {item}")
    else:
        raise Exception("File not found in S3")


# Define the DAG
dag = DAG(
    'insert_json_to_dynamo',
    description='Read JSON from S3 and insert into DynamoDB',
    schedule_interval=None,  # Trigger this DAG manually
    start_date=datetime(2025, 3, 19),
    catchup=False,
)

# PythonOperator to insert data into DynamoDB
insert_task = PythonOperator(
    task_id='insert_data_to_dynamo',
    python_callable=insert_into_dynamo_db,
    provide_context=True,
    dag=dag,
)

insert_task
