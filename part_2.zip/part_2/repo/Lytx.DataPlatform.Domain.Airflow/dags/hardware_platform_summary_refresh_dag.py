import logging
import pytz
from datetime import timedelta, datetime
from airflow import DAG
# from airflow.hooks.base_hook import BaseHook
# from airflow.providers.slack.operators.slack_webhook import SlackWebhookOperator
from airflow.providers.slack.hooks.slack_webhook import SlackWebhookHook
from airflow.providers.postgres.hooks.postgres import PostgresHook
from airflow.operators.python import PythonOperator
from airflow.operators.dummy import DummyOperator
from config.env_config import CONFIG
from airflow.models import Variable

env = Variable.get("env")
redshift_conn = CONFIG[env]['redshift_conn']
redshift_db = CONFIG[env]['redshift_db']
slack_channel = CONFIG[env]['slack_channel']
slack_conn = CONFIG[env]['slack_conn']


# Alerts the dataplatform_alerts_channel of any errors ###
def task_fail_slack_alert(context):
    # slack_webhook_token = BaseHook.get_connection('slack_connection_id').password
    shifted_time = context.get('execution_date').astimezone(pytz.timezone('US/Pacific')).strftime('%m-%d-%Y %H:%M:%S')

    slack_msg = f"""
            :red_circle: Task Failed. See details below:
            *Task*: {context.get('task_instance').task_id}
            *Dag*: {context.get('task_instance').dag_id}
            *Execution Time*: {shifted_time}
            *Log Url*: {context.get('task_instance').log_url}
            """

    try:
        hook = SlackWebhookHook(
            slack_webhook_conn_id=slack_conn
            # message=slack_msg,
        )
        hook.send(text=slack_msg)
        print('Slack alert sent succcessfully')
    except Exception as e:
        print('Failed to send slack alert - ', e)


args = {
    'owner': 'Palash Gupta',
    'start_date': datetime(2025, 10, 17),
    'email': ['palash.gupta@lytx.com'],
    'email_on_failure': False,
    'on_failure_callback': task_fail_slack_alert,
    'retries': 3,
    'retry_delay': timedelta(minutes=5),
}

dag = DAG(
    dag_id='hardware_platform_summary_refresh_dag',
    default_args=args,
    schedule_interval='*/30 * * * *',
    dagrun_timeout=timedelta(minutes=120),
    catchup=False,
)


def execute_calc_hardware_platform_summary(ds, ts, **context):
    print('Execution date - ', ds)
    print('Execution timestamp - ', ts)
    hook = PostgresHook(postgres_conn_id=redshift_conn)
    date_str = str(ds)
    date_obj = datetime.strptime(date_str, '%Y-%m-%d')
    start_of_day = date_obj.replace(hour=0, minute=0, second=0, microsecond=0)
    end_of_day = date_obj.replace(hour=23, minute=59, second=59, microsecond=0)
    print("Start of day:", start_of_day)
    print("End of day:", end_of_day)
    start_ts = str(start_of_day)
    end_ts = str(end_of_day)
    sql = f"CALL safety_events.calc_hardware_platform_summary('{start_ts}'::timestamp, '{end_ts}'::timestamp);"
    try:
        logging.info(f"Executing procedure: {sql}")
        hook.run(sql)
        logging.info(f"Procedure executed successfully for window {start_ts} → {end_ts}")
    except Exception as e:
        logging.error(f"Error executing Redshift procedure: {str(e)}")
        raise


start_task = DummyOperator(task_id='start_task', dag=dag)
end_task = DummyOperator(task_id='end_task', dag=dag)

run_procedure = PythonOperator(
    task_id='run_calc_hardware_platform_summary',
    python_callable=execute_calc_hardware_platform_summary,
    op_kwargs={
            "ds": "{{ ds }}",
            "ts": "{{ ts }}"
        },
    provide_context=True,
    retries=3,
    retry_delay=timedelta(minutes=5),
    )

start_task >> run_procedure >> end_task
