from datetime import datetime
from airflow import DAG
# from airflow.hooks.base_hook import BaseHook
# from airflow.providers.slack.operators.slack_webhook import SlackWebhookOperator
from airflow.providers.slack.hooks.slack_webhook import SlackWebhookHook
from airflow.operators.python import PythonOperator
from airflow.operators.dummy import DummyOperator
from config.env_config import CONFIG
from airflow.models import Variable

env = Variable.get("env")
redshift_conn = CONFIG[env]['redshift_conn']
redshift_db = CONFIG[env]['redshift_db']
slack_channel = CONFIG[env]['slack_channel']
slack_conn = CONFIG[env]['slack_conn']


def slack_alert(context):
    shifted_time = context.get('execution_date')
    slack_msg = f"""
            :red_circle: Task Failed. See details below:
            *Task*: {context.get('task_instance').task_id}
            *Dag*: {context.get('task_instance').dag_id}
            *Execution Time*: {shifted_time}
            *Log Url*: {context.get('task_instance').log_url}
            """
    print('Slack channel - ', slack_channel)
    print('Slack conn - ', slack_conn)

    # try:
    #     failed_alert = SlackWebhookOperator(
    #         task_id='slack_send_alert',
    #         slack_webhook_conn_id=slack_conn,
    #         message=slack_msg)
    #     failed_alert.execute(context=context)
    #     print('Slack alert sent succcessfully')
    # except Exception as e:
    #     print('Failed to send slack alert - ', e)

    try:
        hook = SlackWebhookHook(
            slack_webhook_conn_id=slack_conn
            # message=slack_msg,
        )
        hook.send(text=slack_msg)
        print('Slack alert sent succcessfully')
    except Exception as e:
        print('Failed to send slack alert - ', e)


default_args = {
    'owner': 'airflow',
    'depends_on_past': False,
    'start_date': datetime(2025, 10, 20),
    'email_on_failure': False,
    'email_on_retry': False,
    # 'retries': 2,
    # 'retry_delay': timedelta(minutes=2),
    # 'on_failure_callback': slack_alert,
}


dag = DAG(
    dag_id='example_dag',
    default_args=default_args,
    schedule_interval=None,
    catchup=False,
)


def func():
    print('Welcome to Airflow')
    raise Exception("Failing this task intentionally!")


start_task = DummyOperator(task_id='start_task', dag=dag)
end_task = DummyOperator(task_id='end_task', dag=dag)

run_task = PythonOperator(
    task_id='run_task',
    python_callable=func,
    on_failure_callback=slack_alert,
    # retries=2,
    # retry_delay=timedelta(minutes=2),
)

start_task >> run_task >> end_task
