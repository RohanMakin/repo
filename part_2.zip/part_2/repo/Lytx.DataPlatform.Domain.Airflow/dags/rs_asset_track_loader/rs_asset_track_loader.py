import logging
import pytz
from datetime import timedelta, datetime
from airflow import DAG
from airflow.hooks.base_hook import BaseHook
from airflow.providers.slack.operators.slack_webhook import SlackWebhookOperator
from airflow.providers.postgres.operators.postgres import PostgresOperator
from airflow.operators.check_operator import ValueCheckOperator
from airflow.operators.dummy import DummyOperator
from airflow.operators.python_operator import PythonOperator

global result

logging.getLogger().setLevel(logging.WARN)
TABLE_NAME = 'asset.asset_track'
EXT_TABLE_NAME = 'asset_ext.asset_stage'
TABLE_COLUMN_NAMES1 = 'serial_number,gps_date_time,timezone,event_code,battery,kafka_ts,stack_id,company_id,asset_id,device_id,correlation_id,event_recorder_id,group_id,'
TABLE_COLUMN_NAMES2 = 'root_group_id,vehicle_id,latitude,longitude,speed,heading,numsats,horizontal_accuracy,speed_gps,voltage_external,powerstageinfotype_id,hdop'
TABLE_COLUMN_NAMES = TABLE_COLUMN_NAMES1 + TABLE_COLUMN_NAMES2
EXT_TABLE_COLUMN_NAMES1 = 'serialnumber,gpsdatetime,timezone,eventcode,battery,cast(kafka_ts as TIMESTAMPTZ),stackid,companyid,assetid,deviceid,correlationid,'
EXT_TABLE_COLUMN_NAMES2 = 'eventrecorderid,groupid,rootgroupid,vehicleid,latitude,longitude,speed,heading,numsats,horizontalaccuracy,speedgps,voltageexternal,'
EXT_TABLE_COLUMN_NAMES3 = 'powerstageinfotypeid,hdop'
EXT_TABLE_COLUMN_NAMES = EXT_TABLE_COLUMN_NAMES1 + EXT_TABLE_COLUMN_NAMES2 + EXT_TABLE_COLUMN_NAMES3
EXT_TABLE_SUBQUERY_VALUE = ''
S3_BUCKET_WITH_PREFIX = 's3://lytx-asset-track-cloud-prod-oregon-011/stage/'


def task_fail_slack_alert(context):
    slack_webhook_token = BaseHook.get_connection('slack_connection_id').password
    shifted_time = context.get('execution_date').astimezone(pytz.timezone('US/Pacific')).strftime('%m-%d-%Y %H:%M:%S')
    slack_msg = f"""
            :red_circle: Task Failed. See details below:
            *Task*: {context.get('task_instance').task_id}
            *Dag*: {context.get('task_instance').dag_id}
            *Execution Time*: {shifted_time}
            *Log Url*: {context.get('task_instance').log_url}
            """
    failed_alert = SlackWebhookOperator(
        task_id='slack_send_alert',
        http_conn_id='slack_connection_id',
        webhook_token=slack_webhook_token,
        message=slack_msg,
        username='airflow')
    return failed_alert.execute(context=context)


# Define the function that handles the timestamp parameter
def get_timestamp(**kwargs):
    ti = kwargs['ti']
    # Retrieve the timestamp argument from Airflow Variables or context
    x_timestamp_str = kwargs.get('dag_run').conf.get('x_timestamp') if kwargs.get('dag_run') else None

    if x_timestamp_str:
        try:
            # Convert the string to a datetime object
            x_timestamp = datetime.strptime(x_timestamp_str, '%Y-%m-%d %H:%M:%S')
        except ValueError:
            logging.error(f"Incorrect format for timestamp: {x_timestamp_str}. Expected format: 'YYYY-MM-DD HH:MM:SS'")
            # Use the current datetime if the provided timestamp is invalid
            x_timestamp = datetime.now()
    else:
        x_timestamp = datetime.now()

    # Log the timestamp
    logging.info(f"x_timestamp: {x_timestamp}")

    # Push the timestamp to XCom
    ti.xcom_push(key='x_timestamp', value=x_timestamp.strftime('%Y-%m-%d %H:%M:%S'))


def generate_partition_values(**kwargs):
    ti = kwargs['ti']
    curr_timestamp_str = ti.xcom_pull(task_ids='get_timestamp_task', key='x_timestamp')
    curr_timestamp = datetime.strptime(curr_timestamp_str, '%Y-%m-%d %H:%M:%S')
    now = curr_timestamp - timedelta(days=1)
    partition_values = {
        'year': now.strftime('%Y'),  # Year (4 digits)
        'month': now.strftime('%m').lstrip('0'),  # Month (1 digits)
        'day': now.strftime('%d').lstrip('0'),  # Day (1 digits)
    }
    # Format the partition_value string
    partition = ','.join([f"{key}='{value}'" for key, value in partition_values.items()])
    # Format the location_value string
    location = '/'.join([f"{value}" for key, value in partition_values.items()]) + '/'
    condition = ' and '.join([f"{key}='{value}'" for key, value in partition_values.items()])
    # Push values to XCom
    ti.xcom_push(key='partition_value', value=partition)
    ti.xcom_push(key='location_value', value=location)
    ti.xcom_push(key='condition_value', value=condition)


def generate_sql(**kwargs):
    ti = kwargs['ti']
    condition = ti.xcom_pull(task_ids='generate_partition_values_task', key='condition_value')

    partition_check_sql = f"""
        select 'pass'::varchar from {EXT_TABLE_NAME} where {condition} limit 1;
        """

    insert_records_sql = f"""
        insert into {TABLE_NAME} ({TABLE_COLUMN_NAMES}) select {EXT_TABLE_COLUMN_NAMES} from {EXT_TABLE_NAME} where {condition};
        """
    ti.xcom_push(key='insert_records', value=insert_records_sql)
    ti.xcom_push(key='partition_check', value=partition_check_sql)


args = {
    'owner': 'Anand Palaniappan',
    'start_date': datetime(2024, 6, 10),
    'email': ['anand.palaniappan@lytx.com'],
    'email_on_failure': False,
    'on_failure_callback': task_fail_slack_alert,
    'pass_value': 'pass',
    'database': 'dp_prod_db',
    'conn_id': 'redshift_dp_prod_db',
    'postgres_conn_id': 'redshift_dp_prod_db',
}

dag = DAG(
    dag_id='rs_asset_track_loader',
    default_args=args,
    schedule_interval='0 9 * * *',
    dagrun_timeout=timedelta(minutes=120),
    catchup=False,
)

with dag:
    start_task = DummyOperator(task_id='start_task', dag=dag)

    get_timestamp_task = PythonOperator(
        task_id='get_timestamp_task',
        python_callable=get_timestamp,
        provide_context=True,
    )

    generate_partition_values_task = PythonOperator(
        task_id='generate_partition_values_task',
        python_callable=generate_partition_values,
        provide_context=True,
    )

    generate_sql_task = PythonOperator(
        task_id='generate_sql_task',
        python_callable=generate_sql,
        provide_context=True,
    )

    asset_file_check = ValueCheckOperator(
        task_id='asset_file_check',
        retries=3,
        retry_delay=timedelta(minutes=15),
        sql="{{ task_instance.xcom_pull(task_ids='generate_sql_task', key='partition_check') }}",
        pass_value='pass',
        dag=dag,
    )

    asset_file_load = PostgresOperator(
        task_id='asset_file_load',
        sql="{{ task_instance.xcom_pull(task_ids='generate_sql_task', key='insert_records') }}",
    )

    end_task = DummyOperator(task_id='end_task', dag=dag)

start_task >> get_timestamp_task >> generate_partition_values_task >> generate_sql_task >> asset_file_check >> asset_file_load >> end_task
