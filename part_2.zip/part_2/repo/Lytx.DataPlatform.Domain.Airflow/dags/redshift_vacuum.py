import logging
import pytz
from datetime import timedelta, datetime
from airflow import DAG
from airflow.hooks.base_hook import BaseHook
from airflow.providers.slack.operators.slack_webhook import SlackWebhookOperator
from airflow.operators.python import BranchPythonOperator
from airflow.operators.dummy import DummyOperator
from airflow.utils.task_group import TaskGroup
from airflow.operators.python_operator import PythonOperator
from airflow.hooks.postgres_hook import PostgresHook
from airflow.sensors.python import PythonSensor


def task_fail_slack_alert(context):
    slack_webhook_token = BaseHook.get_connection('slack_connection_id').password
    shifted_time = context.get('execution_date').astimezone(pytz.timezone('US/Pacific')).strftime('%m-%d-%Y %H:%M:%S')
    slack_msg = f"""
            :red_circle: Task Failed. See details below:
            *Task*: {context.get('task_instance').task_id}
            *Dag*: {context.get('task_instance').dag_id}
            *Execution Time*: {shifted_time}
            *Log Url*: {context.get('task_instance').log_url}
            """
    failed_alert = SlackWebhookOperator(
        task_id='slack_send_alert',
        http_conn_id='slack_connection_id',
        webhook_token=slack_webhook_token,
        message=slack_msg,
        username='airflow')
    return failed_alert.execute(context=context)


def get_timestamp(**kwargs):
    ti = kwargs['ti']
    # Retrieve the timestamp argument from Airflow Variables or context
    x_timestamp_str = kwargs.get('dag_run').conf.get('x_timestamp') if kwargs.get('dag_run') else None

    if x_timestamp_str:
        try:
            # Convert the string to a datetime object
            x_timestamp = datetime.strptime(x_timestamp_str, '%Y-%m-%d %H:%M:%S')
        except ValueError:
            logging.error(f"Incorrect format for timestamp: {x_timestamp_str}. Expected format: 'YYYY-MM-DD HH:MM:SS'")
            # Use the current datetime if the provided timestamp is invalid
            x_timestamp = datetime.now()
    else:
        x_timestamp = datetime.now()

    # Log the timestamp
    logging.info(f"x_timestamp: {x_timestamp}")

    # Push the timestamp to XCom
    ti.xcom_push(key='x_timestamp', value=x_timestamp.strftime('%Y-%m-%d %H:%M:%S'))


def run_query_vacuum(conn_id, query, **kwargs):
    try:
        hook = PostgresHook(postgres_conn_id=conn_id)
        conn = hook.get_conn()
        conn.autocommit = True
        cur = conn.cursor()
        cur.execute(query)
    except Exception as e:
        print(f"Query failed with error: {e}")
    return True


def check_day(**kwargs):
    return 'daily_path.device_erlogs_daily'
#     dt = kwargs['ti'].xcom_pull(key='x_timestamp', task_ids='get_timestamp_task')
#     print(dt, type(dt))
#     # Check if the day is Saturday
#     date_obj = datetime.strptime(dt, "%Y-%m-%d %H:%M:%S")
#     if date_obj.weekday() == 6:  # 0 means Monday, 6 means Saturday
#         return 'weekly_path.device_erlogs_weekly'
#     else:
#         return 'daily_path.device_erlogs_daily'


args = {
    'owner': 'Anand Palaniappan',
    'start_date': datetime(2024, 8, 8),
    'email': ['anand.palaniappan@lytx.com'],
    'email_on_failure': False,
    'on_failure_callback': task_fail_slack_alert,
    'pass_value': 'pass',
    'database': 'dp_prod_db',
    'conn_id': 'redshift_dp_prod_db',
    'postgres_conn_id': 'redshift_dp_prod_db',
}

dag = DAG(
    dag_id='rs_vacuum_scheduler',
    default_args=args,
    schedule_interval='30 7 * * *',
    dagrun_timeout=timedelta(minutes=300),
    catchup=False,
)

with dag:
    start_task = DummyOperator(task_id='start_task', dag=dag)

    get_timestamp_task = PythonOperator(
        task_id='get_timestamp_task',
        python_callable=get_timestamp,
        provide_context=True,
    )

    check_day_task = BranchPythonOperator(
        task_id='check_day_task',
        python_callable=check_day,
        provide_context=True,
        retries=3,  # Number of retries for this specific task
        retry_delay=timedelta(minutes=10),  # Delay between retries for this task
        dag=dag
    )
    with TaskGroup("weekly_path") as weekly_path:
        device_erlogs_weekly = PythonSensor(
            task_id='device_erlogs_weekly',
            python_callable=run_query_vacuum,
            op_kwargs={'conn_id': args['conn_id'],
                       'query': "VACUUM SORT ONLY devices.device_erlogs;"},
            retries=1,
            retry_delay=timedelta(seconds=60),
            timeout=2 * 60 * 60,
            mode='reschedule',  # Release worker and reschedule instead of holding the worker
            dag=dag,
        )

        device_vnet_samples_weekly = PythonSensor(
            task_id='device_vnet_samples_weekly',
            python_callable=run_query_vacuum,
            op_kwargs={'conn_id': args['conn_id'],
                       'query': "VACUUM SORT ONLY ecm.device_vnet_samples;"},
            retries=1,
            retry_delay=timedelta(seconds=60),
            timeout=2 * 60 * 60,
            trigger_rule="none_skipped",
            mode='reschedule',  # Release worker and reschedule instead of holding the worker
            dag=dag,
        )

#         gps_enriched_level0_weekly = PythonSensor(
#             task_id='gps_enriched_level0_weekly',
#             python_callable=run_query_vacuum,
#             op_kwargs={'conn_id': args['conn_id'],
#                        'query': "VACUUM SORT ONLY gps.gps_enriched_level0;"},
#             retries=1,
#             retry_delay=timedelta(seconds=60),
#             timeout=2 * 60 * 60,
#             trigger_rule="none_skipped",
#             mode='reschedule',  # Release worker and reschedule instead of holding the worker
#             dag=dag,
#         )
#
#         gps_enriched_level1_weekly = PythonSensor(
#             task_id='gps_enriched_level1_weekly',
#             python_callable=run_query_vacuum,
#             op_kwargs={'conn_id': args['conn_id'],
#                        'query': "VACUUM SORT ONLY gps.gps_enriched_level1;"},
#             retries=1,
#             retry_delay=timedelta(seconds=60),
#             timeout=2 * 60 * 60,
#             trigger_rule="none_skipped",
#             mode='reschedule',  # Release worker and reschedule instead of holding the worker
#             dag=dag,
#         )
#
#         gps_enriched_level2_weekly = PythonSensor(
#             task_id='gps_enriched_level2_weekly',
#             python_callable=run_query_vacuum,
#             op_kwargs={'conn_id': args['conn_id'],
#                        'query': "VACUUM SORT ONLY gps.gps_enriched_level2;"},
#             retries=1,
#             retry_delay=timedelta(seconds=60),
#             timeout=2 * 60 * 60,
#             trigger_rule="none_skipped",
#             mode='reschedule',  # Release worker and reschedule instead of holding the worker
#             dag=dag,
#         )
#
#         gps_enriched_level3_weekly = PythonSensor(
#             task_id='gps_enriched_level3_weekly',
#             python_callable=run_query_vacuum,
#             op_kwargs={'conn_id': args['conn_id'],
#                        'query': "VACUUM SORT ONLY gps.gps_enriched_level3;"},
#             retries=1,
#             retry_delay=timedelta(seconds=60),
#             timeout=2 * 60 * 60,
#             trigger_rule="none_skipped",
#             mode='reschedule',  # Release worker and reschedule instead of holding the worker
#             dag=dag,
#         )

        vehicle_distance_aggregation_weekly = PythonSensor(
            task_id='vehicle_distance_aggregation_weekly',
            python_callable=run_query_vacuum,
            op_kwargs={'conn_id': args['conn_id'],
                       'query': "VACUUM SORT ONLY trip.vehicle_distance_aggregation;"},
            retries=1,
            retry_delay=timedelta(seconds=60),
            timeout=2 * 60 * 60,
            trigger_rule="none_skipped",
            mode='reschedule',  # Release worker and reschedule instead of holding the worker
            dag=dag,
        )

        group_distance_aggregation_weekly = PythonSensor(
            task_id='group_distance_aggregation_weekly',
            python_callable=run_query_vacuum,
            op_kwargs={'conn_id': args['conn_id'],
                       'query': "VACUUM SORT ONLY trip.group_distance_aggregation;"},
            retries=1,
            retry_delay=timedelta(seconds=60),
            timeout=2 * 60 * 60,
            trigger_rule="none_skipped",
            mode='reschedule',  # Release worker and reschedule instead of holding the worker
            dag=dag,
        )

        safety_events_weekly = PythonSensor(
            task_id='safety_events_weekly',
            python_callable=run_query_vacuum,
            op_kwargs={'conn_id': args['conn_id'],
                       'query': "VACUUM SORT ONLY safety_events.safety_events;"},
            retries=1,
            retry_delay=timedelta(seconds=60),
            timeout=2 * 60 * 60,
            trigger_rule="none_skipped",
            mode='reschedule',  # Release worker and reschedule instead of holding the worker
            dag=dag,
        )

        behavior_events_weekly = PythonSensor(
            task_id='behavior_events_weekly',
            python_callable=run_query_vacuum,
            op_kwargs={'conn_id': args['conn_id'],
                       'query': "VACUUM SORT ONLY safety_events.behavior_events;"},
            retries=1,
            retry_delay=timedelta(seconds=60),
            timeout=2 * 60 * 60,
            trigger_rule="none_skipped",
            mode='reschedule',  # Release worker and reschedule instead of holding the worker
            dag=dag,
        )

        device_erlogs_weekly >> device_vnet_samples_weekly >> vehicle_distance_aggregation_weekly >> group_distance_aggregation_weekly
        group_distance_aggregation_weekly >> safety_events_weekly >> behavior_events_weekly

    with TaskGroup("daily_path") as daily_path:
        device_erlogs_daily = PythonSensor(
            task_id='device_erlogs_daily',
            python_callable=run_query_vacuum,
            op_kwargs={'conn_id': args['conn_id'],
                       'query': "VACUUM RECLUSTER devices.device_erlogs;"},
            retries=1,
            retry_delay=timedelta(seconds=60),
            timeout=2 * 60 * 60,
            mode='reschedule',  # Release worker and reschedule instead of holding the worker
            dag=dag,
        )

        device_vnet_samples_daily = PythonSensor(
            task_id='device_vnet_samples_daily',
            python_callable=run_query_vacuum,
            op_kwargs={'conn_id': args['conn_id'],
                       'query': "VACUUM RECLUSTER ecm.device_vnet_samples;"},
            retries=1,
            retry_delay=timedelta(seconds=60),
            timeout=2 * 60 * 60,
            trigger_rule="none_skipped",
            mode='reschedule',  # Release worker and reschedule instead of holding the worker
            dag=dag,
        )

        gps_enriched_level0_daily = PythonSensor(
            task_id='gps_enriched_level0_daily',
            python_callable=run_query_vacuum,
            op_kwargs={'conn_id': args['conn_id'],
                       'query': "VACUUM RECLUSTER gps.gps_enriched_level0;"},
            retries=1,
            retry_delay=timedelta(seconds=60),
            timeout=2 * 60 * 60,
            trigger_rule="none_skipped",
            mode='reschedule',  # Release worker and reschedule instead of holding the worker
            dag=dag,
        )

        gps_enriched_level1_daily = PythonSensor(
            task_id='gps_enriched_level1_daily',
            python_callable=run_query_vacuum,
            op_kwargs={'conn_id': args['conn_id'],
                       'query': "VACUUM RECLUSTER gps.gps_enriched_level1;"},
            retries=1,
            retry_delay=timedelta(seconds=60),
            timeout=2 * 60 * 60,
            trigger_rule="none_skipped",
            mode='reschedule',  # Release worker and reschedule instead of holding the worker
            dag=dag,
        )

        gps_enriched_level2_daily = PythonSensor(
            task_id='gps_enriched_level2_daily',
            python_callable=run_query_vacuum,
            op_kwargs={'conn_id': args['conn_id'],
                       'query': "VACUUM RECLUSTER gps.gps_enriched_level2;"},
            retries=1,
            retry_delay=timedelta(seconds=60),
            timeout=2 * 60 * 60,
            trigger_rule="none_skipped",
            mode='reschedule',  # Release worker and reschedule instead of holding the worker
            dag=dag,
        )

        gps_enriched_level3_daily = PythonSensor(
            task_id='gps_enriched_level3_daily',
            python_callable=run_query_vacuum,
            op_kwargs={'conn_id': args['conn_id'],
                       'query': "VACUUM RECLUSTER gps.gps_enriched_level3;"},
            retries=1,
            retry_delay=timedelta(seconds=60),
            timeout=2 * 60 * 60,
            trigger_rule="none_skipped",
            mode='reschedule',  # Release worker and reschedule instead of holding the worker
            dag=dag,
        )

        vehicle_distance_aggregation_daily = PythonSensor(
            task_id='vehicle_distance_aggregation_daily',
            python_callable=run_query_vacuum,
            op_kwargs={'conn_id': args['conn_id'],
                       'query': "VACUUM RECLUSTER trip.vehicle_distance_aggregation;"},
            retries=1,
            retry_delay=timedelta(seconds=60),
            timeout=2 * 60 * 60,
            trigger_rule="none_skipped",
            mode='reschedule',  # Release worker and reschedule instead of holding the worker
            dag=dag,
        )

        group_distance_aggregation_daily = PythonSensor(
            task_id='group_distance_aggregation_daily',
            python_callable=run_query_vacuum,
            op_kwargs={'conn_id': args['conn_id'],
                       'query': "VACUUM RECLUSTER trip.group_distance_aggregation;"},
            retries=1,
            retry_delay=timedelta(seconds=60),
            timeout=2 * 60 * 60,
            trigger_rule="none_skipped",
            mode='reschedule',  # Release worker and reschedule instead of holding the worker
            dag=dag,
        )

        safety_events_daily = PythonSensor(
            task_id='safety_events_daily',
            python_callable=run_query_vacuum,
            op_kwargs={'conn_id': args['conn_id'],
                       'query': "VACUUM RECLUSTER safety_events.safety_events;"},
            retries=1,
            retry_delay=timedelta(seconds=60),
            timeout=2 * 60 * 60,
            trigger_rule="none_skipped",
            mode='reschedule',  # Release worker and reschedule instead of holding the worker
            dag=dag,
        )

        behavior_events_daily = PythonSensor(
            task_id='behavior_events_daily',
            python_callable=run_query_vacuum,
            op_kwargs={'conn_id': args['conn_id'],
                       'query': "VACUUM RECLUSTER safety_events.behavior_events;"},
            retries=1,
            retry_delay=timedelta(seconds=60),
            timeout=2 * 60 * 60,
            trigger_rule="none_skipped",
            mode='reschedule',  # Release worker and reschedule instead of holding the worker
            dag=dag,
        )

        device_erlogs_daily >> device_vnet_samples_daily >> gps_enriched_level0_daily >> gps_enriched_level1_daily >> gps_enriched_level2_daily >> gps_enriched_level3_daily
        gps_enriched_level3_daily >> vehicle_distance_aggregation_daily >> group_distance_aggregation_daily >> safety_events_daily >> behavior_events_daily

    end_task = DummyOperator(task_id='end_task', dag=dag, trigger_rule='none_failed_or_skipped')

    start_task >> get_timestamp_task >> check_day_task
    check_day_task >> [weekly_path, daily_path]
    weekly_path >> end_task
    daily_path >> end_task
