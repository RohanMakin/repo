from airflow import DAG
from airflow.operators.python import PythonOperator
from datetime import datetime
import platform


def log_python_version():
    import sys
    version = sys.version
    print(f"Python version: {version}")
    print(f"Platform: {platform.platform()}")


with DAG(
    dag_id='check_python_version',
    schedule_interval=None,
    start_date=datetime(2023, 1, 1),
    catchup=False,
    tags=["debug", "version"],
) as dag:

    check_version = PythonOperator(
        task_id='log_python_version',
        python_callable=log_python_version
    )
