from airflow import DAG
from airflow.operators.bash import BashOperator
from airflow.utils.dates import days_ago
from config.env_config import CONFIG
from airflow.models import Variable

env = Variable.get("env")  # Must be set via Airflow Variables
s3_bucket = CONFIG[env]['s3_bucket']
S3_BUCKET = s3_bucket
S3_KEY_UPLOAD = 'managed_airflow/zips/plugins_whl.zip'
S3_KEY_DOWNLOAD = 'managed_airflow/constraints/constraints-3.11.txt'
PIP3_CMD = 'pip3 download -c /tmp/cons/constraints.txt -r /usr/local/airflow/requirements/requirements.txt -d /tmp/whls;zip -j /tmp/plugins.zip /tmp/whls/*.whl;'
AWS_CMD = 'aws s3 cp /tmp/plugins.zip s3:'
BASH_CMD = PIP3_CMD + AWS_CMD

with DAG(dag_id="create_whl_file", schedule_interval=None, catchup=False, start_date=days_ago(1)) as dag:
    cli_command = BashOperator(
        task_id="bash_command",
        bash_command=f"mkdir /tmp/whls; mkdir /tmp/cons; aws s3 cp s3://{S3_BUCKET}/{S3_KEY_DOWNLOAD} /tmp/cons/constraints.txt; {BASH_CMD}//{S3_BUCKET}/{S3_KEY_UPLOAD}"
    )
