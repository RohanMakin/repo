# Single-source config file to manage env-specific settings (e.g., S3 buckets, Airflow vars, feature flags) across dev/stg/prod without duplicating DAG logic.

CONFIG = {
    "dev": {
        "s3_bucket": "lytx-dataplatform-code-dev-oregon-003",
        "redshift_conn": "redshift_conn",
        "redshift_db": "dp_stg_db",
        "slack_channel": "#dataplatform-airflow-alerts",
        "slack_conn": "slack_connection_id"
    },
    "stg": {
        "s3_bucket": "lytx-dataplatform-code-stg-oregon-003",
        "redshift_conn": "redshift_conn",
        "redshift_db": "dp_stg_db",
        "slack_channel": "#dataplatform-airflow-alerts",
        "slack_conn": "slack_connection_id"
    },
    "prod": {
        "s3_bucket": "lytx-dataplatform-code-prod-oregon-003",
        "redshift_conn": "redshift_dp_prod_db",
        "redshift_db": "dp_prod_db",
        "slack_channel": "#dataplatform_alerts_airflow",
        "slack_conn": "slack_connection"
    }
}
