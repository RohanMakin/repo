import logging
import redshift_connector
from airflow import DAG
from datetime import datetime
from datetime import timedelta
from airflow.operators.python import PythonOperator
from airflow.hooks.base_hook import BaseHook

logging.getLogger().setLevel(logging.WARN)

default_args = {
    'owner': 'Alex Tyler',
    'depends_on_past': False,
    'start_date': datetime(2022, 1, 1, 0, 0),
    'email': ['alex.tyler@lytx.org', 'anand.palaniappan@lytx.com'],
    'email_on_failure': False,
    'email_on_retry': False,
    'retries': 0
}

dag = DAG(
    dag_id='test_dag',
    default_args=default_args,
    description='Test dag for loading in packages',
    schedule_interval='@once',
    dagrun_timeout=timedelta(minutes=5),
    max_active_runs=1,
    catchup=False
)


def test_process():
    redshift_conn = BaseHook.get_connection('redshift_dp_prod_db')

    conn = redshift_connector.connect(
        host=redshift_conn.host,
        port=redshift_conn.port,
        database='dp_prod_db',
        user=redshift_conn.login,
        password=redshift_conn.password
    )

    logging.warn("Successfully connected Redshift")

    conn.close()


test = PythonOperator(
    task_id='test_dag',
    python_callable=test_process,
    provide_context=True,
    dag=dag
)

test
