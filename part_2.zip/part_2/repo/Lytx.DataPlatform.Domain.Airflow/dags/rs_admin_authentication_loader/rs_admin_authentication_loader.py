import logging
import pytz
from datetime import timedelta, datetime
from airflow import DAG
from airflow.hooks.base_hook import BaseHook
from airflow.providers.slack.operators.slack_webhook import SlackWebhookOperator
from airflow.providers.postgres.operators.postgres import PostgresOperator
from airflow.operators.check_operator import ValueCheckOperator
from airflow.operators.dummy import DummyOperator
from airflow.utils.task_group import TaskGroup
from airflow.operators.python_operator import PythonOperator
from airflow.models import Variable
global result
logging.getLogger().setLevel(logging.WARN)
TABLE_NAME = 'admin.authentication_events_ms'
TABLE_COLUMN_NAMES1 = '(user_id,keycloak_user_id,login_date,event_type,kafka_topic,kafka_partition,kafka_offset,kafka_timestamp,kafka_timestamp_type,kafka_datetime,'
TABLE_COLUMN_NAMES2 = 'kafka_key,etl_process_timestamp,etl_process_utc_ts)'
TABLE_COLUMN_NAMES = TABLE_COLUMN_NAMES1 + TABLE_COLUMN_NAMES2
EXT_TABLE_NAME = 'admin_ext.authentication_events_ms_stage'
EXT_TABLE_COLUMN_NAMES1 = 'userid,keycloakuserid,logindate,eventtype,kafkatopic,kafkapartition,kafkaoffset,kafkatimestamp,kafkatimestamptype,kafkadatetime,kafkakey,'
EXT_TABLE_COLUMN_NAMES2 = 'etlprocesstimestamp,etlprocessutcts'
EXT_TABLE_COLUMN_NAMES = EXT_TABLE_COLUMN_NAMES1 + EXT_TABLE_COLUMN_NAMES2
EXT_TABLE_SUBQUERY1 = ' from (select userid,keycloakuserid,cast(logindate as TIMESTAMPTZ),eventtype,kafkatopic,kafkapartition,kafkaoffset,kafkatimestamp,kafkatimestamptype,'
EXT_TABLE_SUBQUERY2 = 'CAST(kafkadatetime as TIMESTAMPTZ),kafkakey,etlprocesstimestamp,CAST(etlprocessutcts as TIMESTAMPTZ),ROW_NUMBER() OVER (PARTITION BY '
EXT_TABLE_SUBQUERY3 = 'userid, eventtype ORDER BY cast(logindate as TIMESTAMPTZ) DESC) as rn'
EXT_TABLE_SUBQUERY = EXT_TABLE_SUBQUERY1 + EXT_TABLE_SUBQUERY2 + EXT_TABLE_SUBQUERY3
EXT_TABLE_SUBQUERY_END = ')query where rn=1'
S3_BUCKET_WITH_PREFIX = 's3://lytx-admin-kafka-prod-oregon-003/authentication/events/microservice/stage/'
EXT_MERGE_COLUMNS = [('user_id', 'userid'), ('event_type', 'eventtype')]


def task_fail_slack_alert(context):
    slack_webhook_token = BaseHook.get_connection('slack_connection_id').password
    shifted_time = context.get('execution_date').astimezone(pytz.timezone('US/Pacific')).strftime('%m-%d-%Y %H:%M:%S')
    slack_msg = f"""
            :red_circle: Task Failed. See details below:
            *Task*: {context.get('task_instance').task_id}
            *Dag*: {context.get('task_instance').dag_id}
            *Execution Time*: {shifted_time}
            *Log Url*: {context.get('task_instance').log_url}
            """
    failed_alert = SlackWebhookOperator(
        task_id='slack_send_alert',
        http_conn_id='slack_connection_id',
        webhook_token=slack_webhook_token,
        message=slack_msg,
        username='airflow')
    return failed_alert.execute(context=context)


def generate_partition_values():
    now = datetime.now() - timedelta(hours=1)
    partition_values = {
        'partition_0': now.strftime('%Y'),  # Year (4 digits)
        'partition_1': now.strftime('%m'),  # Month (2 digits)
        'partition_2': now.strftime('%d'),  # Day (2 digits)
        'partition_3': now.strftime('%H'),  # Hour (2 digits)
    }
    # Format the partition_value string
    partition = ','.join([f"{key}='{value}'" for key, value in partition_values.items()])
    # Format the location_value string
    location = '/'.join([f"{value}" for key, value in partition_values.items()]) + '/'
    condition = ' and '.join([f"{key}='{value}'" for key, value in partition_values.items()])
    return partition, location, condition


partition_value, location_value, condition_value = generate_partition_values()


def generate_delete_condition(columns, temp_table):
    # column_pairs = columns.split(',')
    # conditions = ' and '.join([f"{TABLE_NAME}.{col} = {temp_table}.{col}" for col in column_pairs]) #changing the logic to handle the rename in the code
    conditions = ' and '.join([
        f"{TABLE_NAME}.{col1} = {temp_table}.{col2}"
        for col1, col2 in columns
    ])
    return conditions


def set_temp_table_name(**kwargs):
    current_timestamp_ms = str(int(datetime.now().timestamp() * 1000))
    temp_table_name = f'{TABLE_NAME}_{current_timestamp_ms}'
    Variable.set("temp_table_name", temp_table_name)


args = {
    'owner': 'Anand Palaniappan',
    'start_date': datetime(2024, 5, 10),
    'email': ['anand.palaniappan@lytx.com'],
    'email_on_failure': False,
    'on_failure_callback': task_fail_slack_alert,
    'pass_value': 'pass',
    'database': 'dp_prod_db',
    'conn_id': 'redshift_dp_prod_db',
    'postgres_conn_id': 'redshift_dp_prod_db',
}
dag = DAG(
    dag_id='rs_admin_authentication_loader',
    default_args=args,
    schedule_interval='35 * * * *',
    dagrun_timeout=timedelta(minutes=120),
    catchup=False,
)
with dag:
    set_temp_table_name_task = PythonOperator(
        task_id='set_temp_table_name',
        python_callable=set_temp_table_name,
    )
    TEMP_TABLE_NAME_WITH_TIMESTAMP = '{{ var.value.temp_table_name }}'
    MERGE_CONDITION = generate_delete_condition(EXT_MERGE_COLUMNS, TEMP_TABLE_NAME_WITH_TIMESTAMP)
    # This create_table has been changed to accomodate the merge use case
    create_table = f"""
    create table {TEMP_TABLE_NAME_WITH_TIMESTAMP} as
    select distinct {EXT_TABLE_COLUMN_NAMES} {EXT_TABLE_SUBQUERY} from {EXT_TABLE_NAME} where {condition_value} {EXT_TABLE_SUBQUERY_END};
    """
    delete_records = f"""
    delete from {TABLE_NAME}
    using {TEMP_TABLE_NAME_WITH_TIMESTAMP}
    where {MERGE_CONDITION};
    """
    insert_records = f"""
    insert into {TABLE_NAME} {TABLE_COLUMN_NAMES}  select {EXT_TABLE_COLUMN_NAMES} from {TEMP_TABLE_NAME_WITH_TIMESTAMP};
    """
    drop_table = f"""
    drop table {TEMP_TABLE_NAME_WITH_TIMESTAMP};
    """
    start_task = DummyOperator(task_id='start_task', dag=dag)
    create_table_partition = PostgresOperator(
        task_id='create_table_partition',
        sql='sql_files/create_table_partition.sql',
        params={'single_quote': "'",
                'ext_table_name': EXT_TABLE_NAME,
                's3_bucket_prefix': S3_BUCKET_WITH_PREFIX,
                'partition_value': partition_value,
                'location_value': location_value,
                },
        autocommit=True,
        postgres_conn_id=args['conn_id'],
        dag=dag,
    )
    authentication_file_check = ValueCheckOperator(
        task_id='authentication_file_check',
        retries=6,
        retry_delay=timedelta(minutes=15),
        sql='sql_files/authentication_file_check.sql',
        params={'single_quote': "'",
                'ext_table_name': EXT_TABLE_NAME,
                's3_bucket_prefix': S3_BUCKET_WITH_PREFIX,
                'condition_value': condition_value
                },
        pass_value='pass',
        dag=dag,
    )
    with TaskGroup("authentication_file_load") as authentication_file_load:
        create_records_table = PostgresOperator(
            task_id='create_records_table',
            sql=create_table,
        )
        delete_records_table = PostgresOperator(
            task_id='delete_records_table',
            sql=delete_records,
        )
        insert_records_table = PostgresOperator(
            task_id='insert_records_table',
            sql=insert_records,
        )
        drop_records_table = PostgresOperator(
            task_id='drop_records_table',
            sql=drop_table,
        )
        create_records_table >> delete_records_table >> insert_records_table >> drop_records_table
end_task = DummyOperator(task_id='end_task', dag=dag)
start_task >> set_temp_table_name_task >> create_table_partition >> authentication_file_check >> authentication_file_load >> end_task
