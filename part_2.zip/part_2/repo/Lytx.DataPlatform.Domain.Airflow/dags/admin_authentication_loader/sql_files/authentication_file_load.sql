create temp table {{ params.temp_table_name }} as select distinct {{ params.ext_table_column_names }} from {{ params.ext_table_name }} where {{ params.condition_value }};
delete from {{ params.table_name }} using {{ params.temp_table_name }} where {{ params.table_name }}.{{ params.ext_delete_column }} = {{ params.temp_table_name }}.{{ params.ext_delete_column }};
insert into {{ params.table_name }} select * from {{ params.temp_table_name }};

