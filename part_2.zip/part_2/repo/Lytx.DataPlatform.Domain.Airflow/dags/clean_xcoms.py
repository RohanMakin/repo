from airflow import DAG
from datetime import datetime
from datetime import timedelta
from airflow.models import XCom
from airflow.utils.session import provide_session
from airflow.operators.python import PythonOperator

default_args = {
    'owner': 'Alex Tyler',
    'depends_on_past': False,
    'start_date': datetime(2022, 1, 1, 0, 0),
    'email': ['alex.tyler@lytx.org', 'anand.palaniappan@lytx.com'],
    'email_on_failure': False,
    'email_on_retry': False,
    'retries': 0
}

dag = DAG(
    dag_id='clean_xcoms',
    default_args=default_args,
    description='Utility to clean up XCOM store from other DAGs',
    schedule_interval='@weekly',
    dagrun_timeout=timedelta(minutes=5),
    max_active_runs=1,
    catchup=False
)


@provide_session
def cleanup_xcoms(session=None):
    # List of params for deletion
    # Foramt: key -> deleteparams[X][0], task_id -> deleteparams[X][1], dag_id -> deleteparams[X][2]
    delete_params = [
        ['snowflake_payload', 'query_and_build', 'post_snowflake'],
        ['return_value', 'start', 'load_configs'],
        ['return_value', 'bash_command', 'create_whl_file']
        ]

    for item in delete_params:
        session.query(XCom).filter(
            XCom.key == item[0], XCom.task_id == item[1], XCom.dag_id == item[2]
        ).delete()
        session.commit()


clean = PythonOperator(
    task_id='cleanup_xcoms',
    python_callable=cleanup_xcoms,
    dag=dag
)

clean
