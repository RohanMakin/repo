from airflow import DAG
from airflow.utils.dates import days_ago
from airflow.operators.bash import BashOperator

S3_BUCKET = 'lytx-dataplatform-code-prod-oregon-003'
S3_KEY_UPLOAD = 'managed_airflow/zips/plugins_whl.zip'
S3_KEY_DOWNLOAD = 'managed_airflow/constraints/constraints-3.10.txt'
MKDIR = 'mkdir /tmp/whls; mkdir /tmp/cons; aws s3 cp s3:'
PIP3 = 'pip3 download -c /tmp/cons/constraints.txt -r /usr/local/airflow/requirements/requirements.txt -d /tmp/whls;zip -j /tmp/plugins.zip /tmp/whls/*.whl'

with DAG(dag_id="install_packages", schedule_interval=None, catchup=False, start_date=days_ago(1)) as dag:
    cli_command = BashOperator(
        task_id="bash_command",
        bash_command=f"{MKDIR}//{S3_BUCKET}/{S3_KEY_DOWNLOAD} /tmp/cons/constraints.txt; {PIP3};aws s3 cp /tmp/plugins.zip s3://{S3_BUCKET}/{S3_KEY_UPLOAD}"
    )
