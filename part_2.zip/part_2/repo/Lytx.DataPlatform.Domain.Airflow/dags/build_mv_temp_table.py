# flake8: noqa
from datetime import timedelta, datetime
from airflow import DAG
from airflow.providers.slack.hooks.slack_webhook import SlackWebhookHook
from airflow.providers.common.sql.operators.sql import SQLExecuteQueryOperator
from airflow.operators.python import PythonOperator
from airflow.operators.dummy import DummyOperator
from config.env_config import CONFIG
from airflow.models import Variable
import boto3
import pytz
import json

## TODO:
# - Handle running the queries on both consumer dbs. This may be as simple as adding two environment variables for the connection strings and making 2 of each sql operator, pointed at each db. 
# - Update DAG to retry whole operation 3 times before hard-failing
# - Add PagerDuty integration on failures. Ideally warn if DAG fails but retries, then alert if DAG hard fails


env = Variable.get("env")
consumer_conn_1 = 'consumer_conn_1'
consumer_conn_2 = 'consumer_conn_2'
src_db_name = 'dp_prod_db'
slack_conn = 'slack_connection_id'
mv_refresh_queue_name = CONFIG[env].get('materialized_view_refresh_queue_name', '')


# Alerts the dataplatform_alerts_channel of any errors ###
def task_fail_slack_alert(context):
    shifted_time = context.get('execution_date').astimezone(pytz.timezone('US/Pacific')).strftime('%m-%d-%Y %H:%M:%S')

    slack_msg = f"""
            :red_circle: Task Failed. See details below:
            *Task*: {context.get('task_instance').task_id}
            *Dag*: {context.get('task_instance').dag_id}
            *Execution Time*: {shifted_time}
            *Log Url*: {context.get('task_instance').log_url}
            """

    try:
        if False:
            hook = SlackWebhookHook(
                slack_webhook_conn_id=slack_conn
            )
            hook.send(text=slack_msg)
        print('Slack alert sent succcessfully')
    except Exception as e:
        print('Failed to send slack alert - ', e)


def publish_sqs_message():
    sqs_client = boto3.client('sqs')
    try:
        response = sqs_client.get_queue_url(QueueName=mv_refresh_queue_name)
        mv_refresh_queue_url = response['QueueUrl']
    except sqs_client.exceptions.QueueDoesNotExist:
        print('Queue does not exist')
        mv_refresh_queue_url = ''
    except Exception as e:
        print(f'Error getting queue URL: {e}')
        mv_refresh_queue_url = ''

    if len(mv_refresh_queue_url) > 0:
        sqs_client.send_message(
            QueueUrl=mv_refresh_queue_url,
            MessageBody=json.dumps({
                "successfulRefresh": True
            })
        )


args = {
    'owner': 'Quentin Fulsher',
    'start_date': datetime(2025, 11, 5),
    'email': ['quentin.fulsher@lytx.com'],
    'email_on_failure': False,
    'on_failure_callback': task_fail_slack_alert,
    'retries': 0
}

dag = DAG(
    dag_id='build_consumer_temp_tables',
    default_args=args,
    schedule_interval='0 23 * * *',  # At 23:00 (11 PM) every day
    dagrun_timeout=timedelta(hours=4),
    catchup=False
)

start_task = DummyOperator(task_id='start_task', dag=dag)
middle_task_0 = DummyOperator(task_id='middle_task_0', dag=dag)
middle_task_1 = DummyOperator(task_id='middle_task_1', dag=dag)
middle_task_2 = DummyOperator(task_id='middle_task_2', dag=dag)
middle_task_3 = DummyOperator(task_id='middle_task_3', dag=dag)
end_task = DummyOperator(task_id='end_task', dag=dag)


# Materialized views only
schema_view_names = [
    ('asset','vehicles_export','vehicles_ms'),
    ('config','default_report_config_export','default_report_config'),
    ('devices','daily_group_device_tracking_export','daily_group_device_tracking'),
    ('groups','group_options_hierarchy_export','group_options_hierarchy_ms'),
    ('groups','groups_adjacency_table_export','groups_adjacency_table_ms'),
    ('groups','groups_export','groups_ms'),
    ('safety_events','driver_alert_view_mv','driver_alert_view_mv'),
    ('safety_events','behavior_report_mv','behavior_report_mv'),
    ('safety_events','coaches_effectiveness_users_mv','coaches_effectiveness_users_mv'),
    ('safety_events','coaches_profile_behaviour_group_mv','coaches_profile_behaviour_group_mv'),
    ('safety_events','coaches_profile_drivers_mv','coaches_profile_drivers_mv'),
    ('safety_events','coaches_profile_summary_mv','coaches_profile_summary_mv'),
    ('safety_events','coaching_impact_export','coaching_impact'),
    ('safety_events','coaching_impact_aggregated_coaches_report_mv','coaching_impact_aggregated_coaches_report_mv'),
    ('safety_events','coaching_impact_group_coaches_count_mv','coaching_impact_group_coaches_count_mv'),
    ('safety_events','coaching_impact_group_mv','coaching_impact_group_mv'),
    ('safety_events','coaching_impact_mv','coaching_impact_mv'),
    ('safety_events','driver_coaching_history_mv','driver_coaching_history_mv'),
    ('safety_events','driver_scores_view_mv','driver_scores_view_mv'),
    ('safety_events','group_report_mv','group_report_mv'),
    ('safety_events','safe_driver_groups_tab_mv','safe_driver_groups_tab_mv'),
    ('safety_events','safe_driving_groups_report_mv','safe_driving_groups_report_mv'),
    ('safety_events','safe_driving_report_mv','safe_driving_report_mv'),
    ('safety_events','safe_driving_groups_report_monthly_mv','safe_driving_groups_report_monthly_mv'),
    ('safety_events','safe_driving_report_monthly_mv','safe_driving_report_monthly_mv'),
    ('safety_events','safe_driving_report_quarterly_mv','safe_driving_report_quarterly_mv'),
    ('safety_events','safety_events_behavior_insights_mv','safety_events_behavior_insights_mv'),
    ('safety_events','safety_events_behavior_report_insights_mv','safety_events_behavior_report_insights_mv'),
    ('safety_events','safety_events_driver_insights_mv','safety_events_driver_insights_mv'),
    ('safety_events','safety_events_trigger_insights_mv','safety_events_trigger_insights_mv'),
    ('safety_events','safety_events_insights_mv','safety_events_insights_mv'),
    ('safety_events','solo_export','solo'),
    ('safety_violations','fleet_ops_violaitons_idles_aggregations_mv','fleet_ops_violaitons_idles_aggregations_mv'),
    ('trip','fleet_ops_driver_details_export','fleet_ops_driver_details'),
    ('trip','fleet_ops_group_details_export','fleet_ops_group_details'),
    ('trip','fleet_ops_trips_aggregations_mv','fleet_ops_trips_aggregations_mv'),
    ('trip','fleet_ops_vehicle_details_export','fleet_ops_vehicle_details'),
    ('trip','vehicle_distance_aggregation_export','vehicle_distance_aggregation'),
    ('users','driver_groupwise_history_monthly_mv','driver_groupwise_history_monthly_mv'),
    ('users','driver_groupwise_quarterly_history_mv','driver_groupwise_quarterly_history_mv'),
    ('users','users_data_mv','users_data_mv'),
    ('users','users_export','users_ms')
]

warm_up_tasks = [
    SQLExecuteQueryOperator(
        task_id="warm_up_1",
        sql="select 1",
        conn_id=consumer_conn_1,
        on_failure_callback=task_fail_slack_alert,
        dag=dag
    ),
    SQLExecuteQueryOperator(
        task_id="warm_up_2",
        sql="select 1",
        conn_id=consumer_conn_2,
        on_failure_callback=task_fail_slack_alert,
        dag=dag
    )
]


sp_clean_start_tasks = [
    SQLExecuteQueryOperator(
        task_id="sp_clean_start_1",
        sql="call repl.sp_clean();",
        conn_id=consumer_conn_1,
        on_failure_callback=task_fail_slack_alert,
        dag=dag,
        autocommit=True
    ),
    SQLExecuteQueryOperator(
        task_id="sp_clean_start_2",
        sql="call repl.sp_clean();",
        conn_id=consumer_conn_2,
        on_failure_callback=task_fail_slack_alert,
        dag=dag,
        autocommit=True
    )
]

sp_clean_end_tasks = [
    SQLExecuteQueryOperator(
        task_id="sp_clean_end_1",
        sql="call repl.sp_clean();",
        conn_id=consumer_conn_1,
        on_failure_callback=task_fail_slack_alert,
        dag=dag,
        autocommit=True
    ),
    SQLExecuteQueryOperator(
        task_id="sp_clean_end_2",
        sql="call repl.sp_clean();",
        conn_id=consumer_conn_2,
        on_failure_callback=task_fail_slack_alert,
        dag=dag,
        autocommit=True
    )
]

sp_import_tasks = []
for schema, export_view, view in schema_view_names:
    sp_import_tasks.append(SQLExecuteQueryOperator(
        task_id=f'copy_data_{schema}_{view}_1',
        sql='call repl.sp_import(%s, %s, %s, %s);',
        parameters=(schema, export_view, view, src_db_name),
        conn_id=consumer_conn_1,
        #retries=3,
        on_failure_callback=task_fail_slack_alert,
        dag=dag,
    ))
    sp_import_tasks.append(SQLExecuteQueryOperator(
        task_id=f'copy_data_{schema}_{view}_2',
        sql='call repl.sp_import(%s, %s, %s, %s);',
        parameters=(schema, export_view, view, src_db_name),
        conn_id=consumer_conn_2,
        #retries=3,
        on_failure_callback=task_fail_slack_alert,
        dag=dag,
    ))

sp_swap_all_tasks = [
    SQLExecuteQueryOperator(
        task_id='sp_swap_all_1',
        sql='call repl.sp_swap_all();',
        conn_id=consumer_conn_1,
        on_failure_callback=task_fail_slack_alert,
        dag=dag,
    ),
    SQLExecuteQueryOperator(
        task_id='sp_swap_all_2',
        sql='call repl.sp_swap_all();',
        conn_id=consumer_conn_2,
        on_failure_callback=task_fail_slack_alert,
        dag=dag,
    )
]

publish_sqs_task = PythonOperator(
    task_id='publish_sqs_message_to_update_cache',
    python_callable=publish_sqs_message,
    dag=dag,
)

start_task >> warm_up_tasks >> middle_task_0 >> sp_clean_start_tasks  >> middle_task_1 >> sp_import_tasks >> middle_task_2 >> sp_swap_all_tasks >> middle_task_3 >> sp_clean_end_tasks >> publish_sqs_task >> end_task
