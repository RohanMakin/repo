from airflow import DAG
from airflow.operators.python import PythonOperator
from airflow.providers.microsoft.mssql.hooks.mssql import MsSqlHook
from airflow.models import Variable
from datetime import datetime


def fetch_and_print_data():
    edw_table_name = Variable.get("edw_table_name")
    # Create the hook
    hook = MsSqlHook(mssql_conn_id='mssql_edw')

    # SQL query to execute
    sql = f"SELECT TOP 10 * FROM {edw_table_name};"

    print('SQL Query: ', sql)

    # Execute and fetch results
    records = hook.get_records(sql)

    # Print results
    for row in records:
        print(row)


default_args = {
    'owner': 'airflow',
    'start_date': datetime(2023, 1, 1)
}

with DAG(
    dag_id='mssql_hook_example',
    default_args=default_args,
    schedule_interval=None,
    catchup=False,
    tags=['mssql', 'pythonoperator'],
) as dag:

    fetch_task = PythonOperator(
        task_id='fetch_mssql_data',
        python_callable=fetch_and_print_data
    )

    fetch_task
