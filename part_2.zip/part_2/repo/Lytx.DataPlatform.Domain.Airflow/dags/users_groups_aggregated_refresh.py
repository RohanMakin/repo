# Author: palash.gupta@lytx.com
# Optimized DAG to run Redshift stored procedures for loading users group aggregated sp

# Import libraries
import os
import pytz
import logging
from datetime import datetime
from airflow import DAG
from airflow.operators.python import PythonOperator
from airflow.operators.dummy import DummyOperator
from airflow.providers.postgres.hooks.postgres import PostgresHook
from airflow.hooks.base_hook import BaseHook
from airflow.providers.slack.operators.slack_webhook import SlackWebhookOperator

# Fetch dag file name to create dag name
dag_file_name = os.path.splitext(os.path.basename(__file__))[0]

# Redshift SQL queries to execute
stored_procedures = [
    "call dp_prod_db.public.refresh_user_groups_aggregated_sp()",
]

# Function definitions


# Alerts the dataplatform_alerts_channel of any errors
def task_failure_slack_alert(context):
    slack_webhook_token = BaseHook.get_connection('slack_connection_id').password
    shifted_time = context.get('execution_date').astimezone(pytz.timezone('US/Pacific')).strftime('%m-%d-%Y %H:%M:%S')

    slack_msg = f"""
            :red_circle: Task Failed. See details below:
            *Task*: {context.get('task_instance').task_id}
            *Dag*: {context.get('task_instance').dag_id}
            *Execution Time*: {shifted_time}
            *Log Url*: {context.get('task_instance').log_url}
            """

    failed_alert = SlackWebhookOperator(
        task_id='slack_send_alert',
        http_conn_id='slack_connection_id',
        webhook_token=slack_webhook_token,
        message=slack_msg,
        username='airflow')

    return failed_alert.execute(context=context)


# Execute SQL/Stored Procedures on Redshift
def execute_sql(sql: str, **kwargs):
    try:
        logging.info(f"Executing SQL: {sql}")
        hook = PostgresHook(postgres_conn_id='redshift_dp_prod_db', database='dp_prod_db')
        hook.run(sql)
        logging.info("SQL execution successful")
    except Exception as e:
        logging.error(f"Error executing SQL: {sql}\n{str(e)}")
        raise


# Default DAG arguments
default_args = {
    'owner': 'Palash Gupta',
    'depends_on_past': False,
    'on_failure_callback': task_failure_slack_alert,
    'retries': 0
}

# Dag definition
with DAG(
    dag_id=f"{dag_file_name}",
    default_args=default_args,
    description='Runs Redshift stored procedures to refresh users groups aggregated data',
    start_date=datetime(2025, 7, 25),
    schedule_interval='0 0 * * *',
    catchup=False,
    max_active_tasks=1,
    tags=['redshift', 'users_groups_aggregated'],
) as dag:

    start_task = DummyOperator(task_id='start')
    end_task = DummyOperator(task_id='end')

    # Dynamically create tasks for each stored procedure
    procedure_tasks = [
        PythonOperator(
            task_id=f"run_{procedure.split('.')[-1].split('_sp')[0]}",
            python_callable=execute_sql,
            op_kwargs={"sql": procedure},
        )
        for procedure in stored_procedures
    ]

    # Define task dependencies
    start_task >> procedure_tasks[0] >> end_task
