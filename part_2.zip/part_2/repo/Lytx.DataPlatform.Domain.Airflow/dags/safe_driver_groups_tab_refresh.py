# airflow/dags/safe_driver_groups_tab_refresh.py
from airflow import DAG
from airflow.operators.dummy import DummyOperator
from airflow.operators.python import PythonOperator
from airflow.providers.postgres.hooks.postgres import PostgresHook
from airflow.providers.slack.operators.slack_webhook import SlackWebhookOperator
from airflow.hooks.base_hook import BaseHook
from datetime import datetime
import pytz
import logging
import os

dag_file_name = os.path.splitext(os.path.basename(__file__))[0]


def task_failure_slack_alert(context):
    slack_token = BaseHook.get_connection('slack_connection_id').password
    shifted_time = context['execution_date'].astimezone(pytz.timezone('US/Pacific')).strftime('%m-%d-%Y %H:%M:%S')
    msg = f"""
    :red_circle: *Task Failed!*
    *Task*: {context['task_instance'].task_id}
    *Dag*: {context['task_instance'].dag_id}
    *Execution Time*: {shifted_time}
    *Log Url*: {context['task_instance'].log_url}
    """
    return SlackWebhookOperator(
        task_id='slack_failure_alert',
        http_conn_id='slack_connection_id',
        webhook_token=slack_token,
        message=msg,
        username='airflow'
    ).execute(context=context)


def execute_sql(sql: str, **kwargs):
    logging.info(f"Executing SQL: {sql}")
    hook = PostgresHook(postgres_conn_id='redshift_dp_prod_db', database='dp_prod_db')
    hook.run(sql)
    logging.info("Execution successful")


default_args = {
    'owner': 'Data Platform',
    'on_failure_callback': task_failure_slack_alert,
    'depends_on_past': False,
    'retries': 0
}

with DAG(
    dag_id=dag_file_name,
    default_args=default_args,
    start_date=datetime(2025, 8, 21),
    schedule_interval='0 2 * * *',
    catchup=False,
    tags=['redshift', 'safe_driver_groups']
) as dag:

    start = DummyOperator(task_id='start')
    end = DummyOperator(task_id='end')

    run_procedure = PythonOperator(
        task_id='run_safe_driver_groups_refresh',
        python_callable=execute_sql,
        op_kwargs={"sql": "CALL public.refresh_safe_driver_groups_tab_sp()"},
    )

    start >> run_procedure >> end
