import pytz
import boto3
import logging
import pandas as pd
import redshift_connector
from airflow.models import DAG
from datetime import datetime, timedelta
from airflow.hooks.base_hook import BaseHook
from airflow.operators.python import PythonOperator
from airflow.providers.slack.operators.slack_webhook import SlackWebhookOperator

logging.getLogger().setLevel(logging.WARN)


# Alerts the dataplatform_alerts_channel of any errors ###
def task_fail_slack_alert(context):
    slack_webhook_token = BaseHook.get_connection('slack_connection_id').password
    shifted_time = context.get('execution_date').astimezone(pytz.timezone('US/Pacific')).strftime('%m-%d-%Y %H:%M:%S')

    slack_msg = f"""
            :red_circle: Task Failed. See details below:
            *Task*: {context.get('task_instance').task_id}
            *Dag*: {context.get('task_instance').dag_id}
            *Execution Time*: {shifted_time}
            *Log Url*: {context.get('task_instance').log_url}
            """

    failed_alert = SlackWebhookOperator(
        task_id='slack_send_alert',
        http_conn_id='slack_connection_id',
        webhook_token=slack_webhook_token,
        message=slack_msg,
        username='airflow')

    return failed_alert.execute(context=context)


default_args = {
    'owner': 'Alex Tyler',
    'depends_on_past': False,
    'on_failure_callback': task_fail_slack_alert,
    'retries': 0
}

dag = DAG(
    dag_id='fetch_data_rights',
    default_args=default_args,
    description='Fetchs Data Rights and sends them to DynamoDB',
    start_date=datetime(2023, 1, 1, 0, 0),
    schedule_interval='@daily',
    dagrun_timeout=timedelta(minutes=2),
    max_active_runs=1,
    catchup=False
)


def redshift_to_dynamodb():
    query_non_fedex = """
    SELECT DISTINCT HS_COMPANY_ID__C AS COMPANY_ID, Data_Rights_Level__c AS DATA_RIGHTS
    FROM SALESFORCE.ACCOUNT
    WHERE DATA_RIGHTS IS NOT NULL
        AND COMPANY_ID IS NOT NULL
        AND IS_DELETED = FALSE
        AND PARENT_ID IS NULL;
    """

    query_fedex = """
    SELECT DISTINCT HS_COMPANY_ID__C AS COMPANY_ID, Data_Rights_Level__c AS DATA_RIGHTS
    FROM SALESFORCE.ACCOUNT
    WHERE DATA_RIGHTS IS NOT NULL
        AND COMPANY_ID IS NOT NULL
        AND COMPANY_ID <> 6151
        AND parent_account_name__c LIKE 'FedEx%';
    """

    query_non_null_parent_id = """
    SELECT DISTINCT HS_COMPANY_ID__C AS COMPANY_ID, Data_Rights_Level__c AS DATA_RIGHTS
    FROM SALESFORCE.ACCOUNT
    WHERE DATA_RIGHTS IS NOT NULL
        AND COMPANY_ID IS NOT NULL
        AND COMPANY_ID <> 6151
        AND parent_account_name__c IS NOT NULL
        AND parent_account_name__c NOT LIKE 'FedEx%';
    """

    redshift_conn = BaseHook.get_connection('redshift_dp_prod_db')

    conn = redshift_connector.connect(
        host=redshift_conn.host,
        port=redshift_conn.port,
        database='dp_prod_db',
        user=redshift_conn.login,
        password=redshift_conn.password
    )

    logging.warn("Successfully connected Redshift")

    cursor = conn.cursor()

    cursor.execute(query_non_fedex)
    df_non_fedex: pd.DataFrame = cursor.fetch_dataframe()

    cursor.execute(query_fedex)
    df_fedex: pd.DataFrame = cursor.fetch_dataframe()

    cursor.execute(query_non_null_parent_id)
    df_non_null_parent: pd.DataFrame = cursor.fetch_dataframe()

    cursor.close()
    conn.close()

    df = pd.concat([df_non_fedex, df_fedex, df_non_null_parent], ignore_index=True)
    df['company_id'] = pd.to_numeric(df['company_id'])
    df = df.drop_duplicates(subset=['company_id'], keep='first')

    logging.warn("Done querying dataset, now parsing and uploading to Dynamo")

    dynamodb = boto3.resource('dynamodb')
    table = dynamodb.Table('salesforce_data_rights')

    try:
        with table.batch_writer() as writer:
            for row in df.to_dict('records'):
                salesforce_rights_lvl = row['data_rights']

                if salesforce_rights_lvl == 'Platinum':
                    rights_lvl = 'level0'
                elif salesforce_rights_lvl == 'Gold':
                    rights_lvl = 'level1'
                elif salesforce_rights_lvl == 'Silver':
                    rights_lvl = 'level2'
                elif salesforce_rights_lvl == 'Bronze':
                    rights_lvl = 'level3'
                else:
                    logging.warn(f"Error mapping rights level for company: {row['company_id']} with level {row['data_rights']}")
                    rights_lvl = 'level0'

                writer.put_item(
                    Item={
                        'CompanyId': row['company_id'],
                        'DataGovLevel': rights_lvl
                    }
                )
    except Exception as e:
        logging.warn(row)
        raise e

    logging.warn("All data sent to DynamoDB successfully")


query_and_send = PythonOperator(
    task_id='query_and_send_data',
    provide_context=True,
    python_callable=redshift_to_dynamodb,
    dag=dag
)

query_and_send
