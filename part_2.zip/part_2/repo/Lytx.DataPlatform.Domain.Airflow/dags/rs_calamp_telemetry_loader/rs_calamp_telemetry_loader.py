import json
import logging
import urllib.parse
import re
import pytz
from datetime import timedelta, datetime
from airflow import DAG
from airflow.hooks.base_hook import BaseHook
from airflow.providers.slack.operators.slack_webhook import SlackWebhookOperator
from airflow.providers.postgres.operators.postgres import PostgresOperator
from airflow.operators.dummy import DummyOperator
from airflow.operators.python_operator import PythonOperator
from airflow.providers.amazon.aws.sensors.sqs import SqsSensor

global result

SQS_URL = 'https://sqs.us-west-2.amazonaws.com/407799361832/ore-prod-dp-sqs-calamp-airflow'
SELECT_QRY = """
ecm.calampfuel(
    kafka_received_timestamp, mobile_id_type, authentication, ip_address, port, timestamp, time_of_fix, latitude, longitude,
    speed_mph, heading, altitude, satellites, fix_status, network_id, rssi, communication_state, gps_horizontal_dilution,
    event_index, event_code, inputs, unit_status, forwarding, routing, responsere_direction, vin, esn, random_key,
    message_type, serial_number, sequence_number, jpod, odometer, distance_meter, fuel_consumption, duration_sec,
    mean_rpm, mean_throttle, driving_status, device_date, record_creation_ts
)
SELECT
    CAST(SUBSTRING(kafkareceivedtimestamp, 1, 26) AS timestamp),
    mobileidtype,
    authentication,
    ipaddress,
    port,
    CAST(timestamp AS timestamp),
    CAST(timeoffix AS timestamp),
    latitude,
    longitude,
    speedmph,
    heading,
    altitude,
    satellites,
    fixstatus,
    networkid,
    rssi,
    communicationstate,
    gpshorizontaldilution,
    eventindex,
    eventcode,
    inputs,
    unitstatus,
    forwarding,
    routing,
    responseredirection,
    vin,
    esn,
    randomkey,
    messagetype,
    serialnumber,
    sequencenumber,
    jpod,
    odometer,
    distancemeter,
    fuelconsumption,
    durationsec,
    meanrpm,
    meanthrottle,
    drivingstatus,
    CAST(timestamp AS date),
    CURRENT_TIMESTAMP
FROM
    ecm_ext.telemetry_calamp_fuel_v1_0_refined
"""


def task_fail_slack_alert(context):
    slack_webhook_token = BaseHook.get_connection('slack_connection_id').password
    shifted_time = context.get('execution_date').astimezone(pytz.timezone('US/Pacific')).strftime('%m-%d-%Y %H:%M:%S')
    slack_msg = f"""
            :red_circle: Task Failed. See details below:
            *Task*: {context.get('task_instance').task_id}
            *Dag*: {context.get('task_instance').dag_id}
            *Execution Time*: {shifted_time}
            *Log Url*: {context.get('task_instance').log_url}
            """
    failed_alert = SlackWebhookOperator(
        task_id='slack_send_alert',
        http_conn_id='slack_connection_id',
        webhook_token=slack_webhook_token,
        message=slack_msg,
        username='airflow')
    return failed_alert.execute(context=context)


def get_timestamp(**kwargs):
    ti = kwargs['ti']
    # Retrieve the timestamp argument from Airflow Variables or context
    x_timestamp_str = kwargs.get('dag_run').conf.get('x_timestamp') if kwargs.get('dag_run') else None

    if x_timestamp_str:
        try:
            # Convert the string to a datetime object
            x_timestamp = datetime.strptime(x_timestamp_str, '%Y-%m-%d %H:%M:%S')
        except ValueError:
            logging.error(f"Incorrect format for timestamp: {x_timestamp_str}. Expected format: 'YYYY-MM-DD HH:MM:SS'")
            # Use the current datetime if the provided timestamp is invalid
            x_timestamp = datetime.now()
    else:
        x_timestamp = datetime.now()

    # Log the timestamp
    logging.info(f"x_timestamp: {x_timestamp}")

    # Push the timestamp to XCom
    ti.xcom_push(key='x_timestamp', value=x_timestamp.strftime('%Y-%m-%d %H:%M:%S'))


def read_sqs_message(**kwargs):
    sqs_messages = kwargs['ti'].xcom_pull(key='messages', task_ids='receive_sqs_message')
    s3_events = []
    s3_path = []
    s3_keys = []
    if sqs_messages:
        for message in sqs_messages:
            body = json.loads(message['Body'])
            for record in body['Records']:
                bucket = record['s3']['bucket']['name']
                key = urllib.parse.unquote(record['s3']['object']['key'])
                s3_events.append((bucket, key))
                s3_path.append("s3://"+bucket+"/"+key)
                s3_keys.append(key)
    kwargs['ti'].xcom_push(key='s3_events', value=s3_events)
    kwargs['ti'].xcom_push(key='s3_path', value=s3_path)
    kwargs['ti'].xcom_push(key='s3_keys', value=s3_keys)


def check_sqs_message(**kwargs):
    messages = kwargs['ti'].xcom_pull(task_ids='receive_sqs_message')
    if messages is None:
        return 'end_task'
    return 'process_sqs_message'


def extract_unique_datetime_components(s3_paths):
    # Define sets to store unique components
    unique_years = set()
    unique_months = set()
    unique_days = set()
    unique_hours = set()
    pattern = re.compile(r'(\d{4})/(\d{2})/(\d{2})/(\d{2})')

    for path in s3_paths:
        match = pattern.search(path)
        if match:
            year, month, day, hour = match.groups()
            unique_years.add(year)
            unique_months.add(month)
            unique_days.add(day)
            unique_hours.add(hour)

    def format_as_quoted_list(components):
        return '(' + ','.join(f"'{component}'" for component in sorted(components)) + ')'

    years_str = format_as_quoted_list(unique_years)
    months_str = format_as_quoted_list(unique_months)
    days_str = format_as_quoted_list(unique_days)
    hours_str = format_as_quoted_list(unique_hours)

    return years_str, months_str, days_str, hours_str


def get_keys_filter(input_s3_keys):
    s3_keys_filter = ''
    for keys in input_s3_keys:
        s3_keys_filter = s3_keys_filter + "'" + keys + "',"
    # remove last comma
    if s3_keys_filter.endswith(','):
        s3_keys_filter = s3_keys_filter[:-1]
    return s3_keys_filter


def create_insert_query(**kwargs):
    input_s3_keys = kwargs['ti'].xcom_pull(key='s3_path', task_ids='process_sqs_message')
    logging.info("value of input_s3_keys ", input_s3_keys)
    s3_keys_filter = get_keys_filter(input_s3_keys)
    years_str, months_str, days_str, hours_str = extract_unique_datetime_components(input_s3_keys)
    insert_records_sql = f"""
    INSERT INTO {SELECT_QRY}
    WHERE "$path" IN ({s3_keys_filter})
        AND partition_0 IN {years_str}
        AND partition_1 IN {months_str}
        AND partition_2 IN {days_str}
        AND partition_3 IN {hours_str};
    """

    kwargs['ti'].xcom_push(key='insert_records_sql', value=insert_records_sql)


args = {
    'owner': 'Anand Palaniappan',
    'start_date': datetime(2024, 7, 10),
    'email': ['anand.palaniappan@lytx.com'],
    'email_on_failure': False,
    'on_failure_callback': task_fail_slack_alert,
    'pass_value': 'pass',
    'database': 'dp_prod_db',
    'conn_id': 'redshift_dp_prod_db',
    'postgres_conn_id': 'redshift_dp_prod_db',
}

dag = DAG(
    dag_id='rs_calamp_loader',
    default_args=args,
    schedule_interval='*/20 * * * *',
    dagrun_timeout=timedelta(minutes=120),
    catchup=False,
)

with dag:
    start_task = DummyOperator(task_id='start_task', dag=dag)

    get_timestamp_task = PythonOperator(
        task_id='get_timestamp_task',
        python_callable=get_timestamp,
        provide_context=True,
    )

    receive_sqs_message = SqsSensor(
        task_id='receive_sqs_message',
        sqs_queue=SQS_URL,
        max_messages=10,  # Read up to 5 messages
        timeout=120,  # waits for a minute before timing out
        mode='reschedule',  # Reschedule to avoid blocking a worker
        soft_fail=True,  # Gracefully fail after no messages in SQS
        poke_interval=10,
        dag=dag,
    )

    check_sqs_response = PythonOperator(
        task_id='check_sqs_response',
        python_callable=check_sqs_message,
        provide_context=True,
        dag=dag,
    )

    process_sqs_message = PythonOperator(
        task_id='process_sqs_message',
        python_callable=read_sqs_message,
        provide_context=True,
        dag=dag,
    )

    generate_insert_query = PythonOperator(
        task_id='generate_insert_query',
        python_callable=create_insert_query,
        provide_context=True
    )

    execute_insert = PostgresOperator(
        task_id='execute_insert',
        sql="{{ task_instance.xcom_pull(task_ids='generate_insert_query', key='insert_records_sql') }}",
    )

    end_task = DummyOperator(task_id='end_task', dag=dag)

start_task >> get_timestamp_task >> receive_sqs_message >> check_sqs_response >> [process_sqs_message, end_task]
process_sqs_message >> generate_insert_query >> execute_insert >> end_task
