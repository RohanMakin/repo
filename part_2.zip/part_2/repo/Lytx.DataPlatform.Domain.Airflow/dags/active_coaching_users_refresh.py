############################################################################
# Name  : active_coaching_users_refresh_mvs
# Written By : Ryan Blelloch
# Description: To refresh Coaching Impact Coaches MVs
############################################################################


import logging
import pytz
from datetime import timedelta, datetime
from airflow import DAG
from airflow.providers.slack.hooks.slack_webhook import SlackWebhookHook
from airflow.providers.postgres.operators.postgres import PostgresOperator
from airflow.operators.dummy import DummyOperator
from config.env_config import CONFIG
from airflow.models import Variable

global result

logging.getLogger().setLevel(logging.WARN)

env = Variable.get("env")
redshift_conn = CONFIG[env]['redshift_conn']
redshift_db = CONFIG[env]['redshift_db']
slack_conn = CONFIG[env]['slack_conn']


# Alerts the dataplatform_alerts_channel of any errors ###
def task_fail_slack_alert(context):
    shifted_time = context.get('execution_date').astimezone(pytz.timezone('US/Pacific')).strftime('%m-%d-%Y %H:%M:%S')

    slack_msg = f"""
            :red_circle: Task Failed. See details below:
            *Task*: {context.get('task_instance').task_id}
            *Dag*: {context.get('task_instance').dag_id}
            *Execution Time*: {shifted_time}
            *Log Url*: {context.get('task_instance').log_url}
            """

    try:
        hook = SlackWebhookHook(
            slack_webhook_conn_id=slack_conn
        )
        hook.send(text=slack_msg)
        print('Slack alert sent succcessfully')
    except Exception as e:
        print('Failed to send slack alert - ', e)


args = {
    'owner': 'Ryan Blelloch',
    'start_date': datetime(2025, 10, 22),
    'email': ['ryan.blelloch@lytx.com'],
    'email_on_failure': False,
    'on_failure_callback': task_fail_slack_alert,
}

dag = DAG(
    dag_id='se_refresh_active_coaching_users_vws',
    default_args=args,
    schedule_interval='2 1,3,5,7,9 * * *',
    dagrun_timeout=timedelta(minutes=120),
    catchup=False,
)


start_task = DummyOperator(task_id='start_task', dag=dag)
end_task = DummyOperator(task_id='end_task', dag=dag)

mv_names = [
    'active_coaching_users_mv'
]

refresh_mv_tasks = []

for mv in mv_names:
    task = PostgresOperator(
        task_id=f'refresh_{mv}',
        sql=f'REFRESH MATERIALIZED VIEW {redshift_db}.users.{mv};',
        autocommit=True,
        postgres_conn_id=redshift_conn,
        on_failure_callback=task_fail_slack_alert,
        dag=dag,
    )
    refresh_mv_tasks.append(task)

    start_task >> task >> end_task
