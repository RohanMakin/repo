Create schema config;

CREATE TABLE config.copy_log (
    id bigint identity(1,1) ENCODE az64,
    table_name character varying(255) ENCODE lzo,
    manifest_file character varying(65535) ENCODE lzo,
    column_names_seq character varying(65535) ENCODE lzo,
    success boolean ENCODE raw,
    error_message character varying(65535) ENCODE lzo,
    timestamp timestamp without time zone DEFAULT ('now'::character varying)::timestamp with time zone ENCODE az64,
    files character varying(65535) ENCODE lzo
)
DISTSTYLE AUTO;

