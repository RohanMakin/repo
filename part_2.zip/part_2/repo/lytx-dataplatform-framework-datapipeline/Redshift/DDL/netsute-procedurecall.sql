call netsuite.apply_cdc('netsuite','subscription_analytics','arn:aws:iam::407799361832:role/LYTX_DP_APP_REDSHIFT_ACCESS_PROD',1,NULL);

call netsuite.apply_cdc('netsuite','sis','arn:aws:iam::407799361832:role/LYTX_DP_APP_REDSHIFT_ACCESS_PROD',1,NULL);

call netsuite.apply_cdc('netsuite','system_notes','arn:aws:iam::407799361832:role/LYTX_DP_APP_REDSHIFT_ACCESS_PROD',1,NULL);

call netsuite.apply_cdc('netsuite','charges','arn:aws:iam::407799361832:role/LYTX_DP_APP_REDSHIFT_ACCESS_PROD',1,NULL);