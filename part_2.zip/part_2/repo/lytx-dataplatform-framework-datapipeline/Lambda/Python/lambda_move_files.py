import uuid
import json
import boto3
import logging
import os
import time
import hashlib
import datetime as dt
from lytxlogger.lytx_logger import LytxLogger

# Set up logging to print only error from other python logging
logger = logging.getLogger()
logger.setLevel(logging.ERROR)

SQS = boto3.client("sqs")
#Queues
QUEUE_NAME_JOB_STATUS = ''
QUEUE_NAME_JOB_INVOKE = ''

s3 = boto3.resource('s3')
clientname=boto3.client('s3')

#3 parameters for RDS & SecreteStroe environment
database_name = ''
db_cluster_arn = ''
db_credentials_secrets_store_arn = ''

IS_FILES_AVAILABLE_TO_MOVE = "false"
SOURCE_FILE_EXT='avro'

# This is the Data API client that will be used in our examples below
rds_client = boto3.client('rds-data')
lytxLogger = LytxLogger.create("logger_" + __name__)
trackingId = str(uuid.uuid4())


def lambda_handler(event, context):
    global DATASOURCE_NAME, STEP_NAME, JOB_ID_DB, SOURCE_BUCKET_DB, TARGET_BUCKET_DB, IS_ACTIVE_DB, trackingId, targetBucketCompleteWithYrMmDd

    DATASOURCE_NAME = ""
    STEP_NAME = 'SAVE_RAW'
    # below will populate by db data
    JOB_ID_DB = "1"
    # below will populate by db data
    SOURCE_BUCKET_DB = ''
    # below will populate by db data
    TARGET_BUCKET_DB = ''
    # below will populate by db data
    IS_ACTIVE_DB = ''
    targetBucketCompleteWithYrMmDd = ''
    trackingId = str(uuid.uuid4())

    lytxLogger.init_logger( getEnvName(context.function_name) , event['DATA_SOURCE'] , "lambda", context.function_name , context.aws_request_id, trackingId)
    
    lytxLogger.info("input event data : {} ".format(event['DATA_SOURCE']))
    DATASOURCE_NAME = event['DATA_SOURCE']
    
    
    global MAX_FILE_MOVE_COUNT
    try:
        MAX_FILE_MOVE_COUNT = event['MAX_FILE_MOVE_COUNT']
    except Exception as e:
        MAX_FILE_MOVE_COUNT = 10
        lytxLogger.info("Not recieved MAX_FILE_MOVE_COUNT , default is "+str(MAX_FILE_MOVE_COUNT))
    global SOURCE_FILE_EXT
    try:
        SOURCE_FILE_EXT = event['SOURCE_FILE_EXT']
    except Exception as e:
        SOURCE_FILE_EXT='avro'
        lytxLogger.debug("Not recieved SOURCE_FILE_EXT , default is "+SOURCE_FILE_EXT)
    
    
    
    lytxLogger.info("DATASOURCE_NAME : {} , MAX_FILE_MOVE_COUNT: {},SOURCE_FILE_EXT:{} ".format(DATASOURCE_NAME,MAX_FILE_MOVE_COUNT,SOURCE_FILE_EXT))
    
    #get the config paramerter
    populateParameter()
    
    lytxLogger.debug("inside lambda_handler QUEUE_NAME_JOB_INVOKE : {} , QUEUE_NAME_JOB_STATUS: {},database_name:{},db_cluster_arn:{},db_credentials_secrets_store_arn:{} ".format(QUEUE_NAME_JOB_INVOKE,QUEUE_NAME_JOB_STATUS,database_name,db_cluster_arn,db_credentials_secrets_store_arn))
    
    #CAll db to get job master data and populate global variables
    master_data_found = getMasterData()
    
    if not master_data_found:
        lytxLogger.debug(f"0 Records found from RDS for ds = {DATASOURCE_NAME}, stopping execution")
        return f"0 Records found from RDS for ds = {DATASOURCE_NAME}, stopping execution"
    
    sourceBucketName = getBucketName(SOURCE_BUCKET_DB)
    sourceBucketSubFolders = getBucketNameSubFolers(SOURCE_BUCKET_DB)
    
    targetBucketName = getBucketName(TARGET_BUCKET_DB)
    targetBucketSubFolders = getBucketNameSubFolers(TARGET_BUCKET_DB)
    
    date = dt.date.today()
    yyyyMmDDPathstr = 'year=' + str(date.year) + '/month=' + str(date.month) + '/day=' + str(date.day) + '/'

    targetBucketCompleteWithYrMmDd = TARGET_BUCKET_DB +'/'+ yyyyMmDDPathstr
    targetBucketSubFoldersWithYrMmDd = targetBucketSubFolders +'/'+ yyyyMmDDPathstr
    
    lytxLogger.debug(event)
    s3fileName = ""
    s3fileNameWithLastComma = ""
    try:
        bucket = s3.Bucket(sourceBucketName)
        lytxLogger.debug(date)
        objs = bucket.objects.filter(Prefix=sourceBucketSubFolders)
							  
        lytxLogger.debug("sourceBucketName:"+sourceBucketName)
        lytxLogger.debug("sourceBucketSubFolders:"+sourceBucketSubFolders)
        fileCount = 0
        
        YEAR_KEY_PATH = "/year="
        oldest_file_date=""
        oldest_file_key=""
        latest_file_date=""
        latest_file_key=""
        recordCount=0
        for record in objs:
            key = record.key
            #lytxLogger.debug("key: "+key)
            recordCount =recordCount+1
            if key.endswith(SOURCE_FILE_EXT) and key.startswith(sourceBucketSubFolders) and fileCount < MAX_FILE_MOVE_COUNT:
                #lytxLogger.debug(os.path.basename(key))
                s3fileName += os.path.basename(key) + ","
                fileCount =fileCount+1
                if fileCount == 1:
                    oldest_file_key = key
            latest_file_key = key
                    
        #get the date from s3 bucket key
        oldest_file_date     = getDateStringFromKey(oldest_file_key)
        latest_file_date  = getDateStringFromKey(latest_file_key)
        days_diff=0
        if None != oldest_file_date and None != latest_file_date:
            days_diff = (latest_file_date - oldest_file_date).days
        
        lytxLogger.info("Files lag data" , metadata={ "oldest_file_date":oldest_file_date, "latest_file_date":latest_file_date, "days_diff": days_diff})
        
        global IS_FILES_AVAILABLE_TO_MOVE        
        if(len(s3fileName)>0):
            end = len(s3fileName)-1
            s3fileNameWithLastComma = s3fileName[0:end]
            IS_FILES_AVAILABLE_TO_MOVE = "true"
        else:
            IS_FILES_AVAILABLE_TO_MOVE = "false"
		
        lytxLogger.info("s3fileName without partition path:"+s3fileName)
        lytxLogger.info("IS_FILES_AVAILABLE_TO_MOVE:"+IS_FILES_AVAILABLE_TO_MOVE)    
        lytxLogger.info("fileCount:"+str(fileCount))  
        #Send start msg to job status sqs
        sendMsgToJobStatus( getMsgJson(s3fileNameWithLastComma,"START","started move process", JOB_ID_DB,SOURCE_BUCKET_DB, TARGET_BUCKET_DB) )
        
        if fileCount == 0:
             lytxLogger.info("process completed with no move")
             return "completed"
       
        fileCount = 0
        for record in objs:
            key = record.key
            #lytxLogger.debug(record)
          
            if key.endswith(SOURCE_FILE_EXT):
                
                copy_source = {
                'Bucket': sourceBucketName,
                'Key': key
                }
                try:
                  destbucket = s3.Bucket(targetBucketName)
                  #lytxLogger.debug(os.path.dirname(key))
                  #if os.path.dirname(key).startswith('ingest'):
                  if os.path.dirname(key).startswith(sourceBucketSubFolders)and fileCount < MAX_FILE_MOVE_COUNT:
                      destbucket.copy(copy_source, targetBucketSubFoldersWithYrMmDd+os.path.basename(key))
                      clientname.delete_object(Bucket=sourceBucketName, Key=key)
                      fileCount =fileCount+1
                      lytxLogger.debug("target full path: {}".format(targetBucketSubFoldersWithYrMmDd+os.path.basename(key)) )
                      
                except Exception as e:
                        #Send start msg to job status sqs
                        sendMsgToJobStatus( getMsgJson(s3fileNameWithLastComma,"FAILED",'Failed due to, '+ str(e), JOB_ID_DB,SOURCE_BUCKET_DB, TARGET_BUCKET_DB ))
                        raise e
    except Exception as e:
        #Send start msg to job status sqs
        sendMsgToJobStatus( getMsgJson("","FAILED",'Failed due to, '+ str(e), JOB_ID_DB,SOURCE_BUCKET_DB, TARGET_BUCKET_DB ))
        lytxLogger.error('Failed due to, '+str(e),error_code="unknown")
        raise e
    
    lytxLogger.debug("fileCount for actual file moved:"+str(fileCount))    
            
    #Send Completed msg to job status sqs
    if IS_FILES_AVAILABLE_TO_MOVE=="true":
        sendMsgToJobStatus( getMsgJson(s3fileNameWithLastComma,"SUCCESS","Completed move process", JOB_ID_DB,SOURCE_BUCKET_DB, TARGET_BUCKET_DB) )
        lytxLogger.debug("JobStatus success sqs msg sent")
    
    #Send Completed msg to job invoke sqs
    if IS_FILES_AVAILABLE_TO_MOVE=="true":
        sendMsgToJobInvoke( getMsgJson(s3fileNameWithLastComma,"SUCCESS","Completed move process", JOB_ID_DB,SOURCE_BUCKET_DB, TARGET_BUCKET_DB) )
        lytxLogger.debug("JobInvoke success sqs msg sent")
    
    lytxLogger.info("process completed")
    
    return "completed"

def getDateStringFromKey(key):
    lytxLogger.debug("key{}".format(key))
    year = 0
    month = 0
    day = 0
    hour = 0
    for data in key.split("/"):
        #print(data)
        if 'year' in data:
            year = int(data.split("=")[1])
        elif 'month' in data:
            month = int(data.split("=")[1])
        elif 'day' in data:
            day = int(data.split("=")[1])
        elif 'hour' in data:
            hour = int(data.split("=")[1])
    
    if year > 0 and month > 0 and day > 0:
        return dt.datetime(year, month, day,hour)
    return None
    

STEP_STATUS1 = ""
def getMsgJson(s3fileNameWithLastComma,STEP_STATUS,COMMENT,JOB_ID_DB,SOURCE_BUCKET_DB, TARGET_BUCKET_DB):
    HASH = ""
    global STEP_STATUS1
    lytxLogger.debug("STEP_STATUS:"+STEP_STATUS)
    
    if IS_FILES_AVAILABLE_TO_MOVE=="true":
        HASH = hashlib.md5(s3fileNameWithLastComma.encode()).hexdigest()
        STEP_STATUS1 = STEP_STATUS
        lytxLogger.debug("STEP_STATUS1 if:"+STEP_STATUS1)
    else:
        STEP_STATUS1 = "NO_FILES_TO_MOVE"
        COMMENT = "No files found to move"
        HASH = ""
        lytxLogger.debug("STEP_STATUS1 else:"+STEP_STATUS1)
    
    
    lytxLogger.info("sqs msgJson data",metadata={ "filenames": s3fileNameWithLastComma,"hash": HASH,"source_bucket_name": SOURCE_BUCKET_DB,"targetBucketCompleteWithYrMmDd": s3fileNameWithLastComma,"step_name": STEP_NAME,"job_id": JOB_ID_DB, "comment":COMMENT,"datasource_name":DATASOURCE_NAME})
    msgJson = {
            "JOB_ID": JOB_ID_DB,
            "DATASOURCE_NAME": DATASOURCE_NAME,
            "SOURCE": SOURCE_BUCKET_DB,
            "TARGET": targetBucketCompleteWithYrMmDd,
            "STEP_NAME": STEP_NAME,
            "FILENAMES": s3fileNameWithLastComma,
            "HASH": HASH,
                "STEP_STATUS": STEP_STATUS1,
            "DATE": dt.datetime.now().strftime("%Y-%m-%dT%H:%M:%SZ"),
            "COMMENT":COMMENT,
            "TRACKING_ID":trackingId
          }
    return json.dumps(msgJson)
    
def getQueueURL(queueName):
    """Retrieve the URL for the configured queue name"""
    q = SQS.get_queue_url(QueueName=queueName).get('QueueUrl')
    lytxLogger.debug("Queue URL is {}".format(q))
    return q
    
def sendMsgToJobStatus(msgJsonStr):
    try:
        lytxLogger.debug("sendMsgToJobStatus: Recording msgJsonStr: {}".format( msgJsonStr))
        url = getQueueURL(QUEUE_NAME_JOB_STATUS)
        lytxLogger.debug("Got queue URL {}".format( url))
        unique1 = str(time.time())+"_"+QUEUE_NAME_JOB_STATUS
        lytxLogger.debug("JobStatus MessageDeduplicationId {}".format( unique1))
        
        resp = SQS.send_message(QueueUrl=url, MessageBody=msgJsonStr,MessageGroupId="L1_GR1",MessageDeduplicationId=unique1)
        lytxLogger.debug("Send result: {}".format(resp))
    except Exception as e:
        raise Exception("Exception while sendMsgToJobStatus: %s" % e)
    
def sendMsgToJobInvoke(msgJsonStr):
    try:
        lytxLogger.debug("sendMsgToJobInvoke Recording msgJsonStr: {}".format( msgJsonStr))
        url = getQueueURL(QUEUE_NAME_JOB_INVOKE)
        lytxLogger.debug("Got queue URL {}".format(url))
        unique1 = str(time.time())+"_"+QUEUE_NAME_JOB_INVOKE
        lytxLogger.debug("JobInvoke MessageDeduplicationId  {}".format( unique1))
        
        resp = SQS.send_message(QueueUrl=url, MessageBody=msgJsonStr,MessageGroupId="L1_GR2",MessageDeduplicationId=unique1)
        lytxLogger.debug("Send result: {}".format( resp))
    except Exception as e:
        raise Exception("Exception while sendMsgToJobInvoke: %s" % e)

#--------------------------------------------------------------------------------
# Helper Functions
#--------------------------------------------------------------------------------

def execute_statement(sql, sql_parameters=[]):
    response = rds_client.execute_statement(
        secretArn=db_credentials_secrets_store_arn,
        database=database_name,
        resourceArn=db_cluster_arn,
        sql=sql,
        parameters=sql_parameters
    )
    return response


def getMasterData():
    lytxLogger.debug('===== Parameterized query for job_master_data =====')
    sql = 'select "SOURCE_DIR","TARGET_DIR","IS_ACTIVE","STEP_ID" from admin_schema.job_master_data where "JOB_STEP"=\'SAVE_RAW\' AND "DATA_SOURCE"=:ds'
    ds = DATASOURCE_NAME
    sql_parameters = [{'name':'ds', 'value':{'stringValue': f'{ds}'}}]
    response = execute_statement(sql, sql_parameters)
    
    rows = response['records']
    rcounter = 0
    ccounter = 0
    global SOURCE_BUCKET_DB
    global TARGET_BUCKET_DB
    global IS_ACTIVE_DB
    global JOB_ID_DB
    if len(rows) == 0:
        return False

    for row in rows:
        lytxLogger.debug("row:")
        rcounter = rcounter + 1
        for col in row:
            lytxLogger.debug("col:")
            ccounter = ccounter + 1
            
            lytxLogger.debug(col)
            if ccounter==1 and rcounter==1:
                SOURCE_BUCKET_DB = col['stringValue']
            if ccounter==2 and rcounter==1:
                TARGET_BUCKET_DB = col['stringValue']
            if ccounter==3 and rcounter==1:
                IS_ACTIVE_DB = col['stringValue']
            if ccounter==4 and rcounter==1:
                JOB_ID_DB = str(col['longValue'])
    
    lytxLogger.debug("SOURCE_BUCKET_DB:"+SOURCE_BUCKET_DB)
    lytxLogger.debug("TARGET_BUCKET_DB:"+TARGET_BUCKET_DB)
    lytxLogger.debug("IS_ACTIVE_DB:"+IS_ACTIVE_DB)
    lytxLogger.debug("JOB_ID_DB:"+JOB_ID_DB)
    lytxLogger.debug("db response['records']: {}".format( response['records']))
    return True

def getBucketName(buckerFullName):
    lytxLogger.debug('===== getBucketName start =====')
    strArr = buckerFullName.split("/",1)
    lytxLogger.debug("BucketName:"+strArr[0])
    lytxLogger.debug('===== getBucketName end =====')
    return strArr[0]

def getBucketNameSubFolers(buckerFullName):
    lytxLogger.debug('===== getBucketNameSubFolers start =====')
    strArr = buckerFullName.split("/",1)
    lytxLogger.debug("Without BucketName:"+strArr[1])
    lytxLogger.debug('===== getBucketNameSubFolers end =====')
    return strArr[1]

def getEnvName(resourceName):
    if '-dev-' in resourceName:
        return "dev"
    elif '-stg-' in resourceName:
        return "stg"
    elif '-prod-' in resourceName:
        return "prod"

#--------------------------------------------------------------------------------
# get all config props from parameter store
#--------------------------------------------------------------------------------
def populateParameter():
    ssm = boto3.client('ssm')
    global QUEUE_NAME_JOB_INVOKE
    global QUEUE_NAME_JOB_STATUS
    global database_name
    global db_cluster_arn
    global db_credentials_secrets_store_arn
        
    parameter = ssm.get_parameter(Name='/services/rds/aurora-postgresql/dp_admin/database', WithDecryption=False)
    database_name = parameter['Parameter']['Value']
    parameter = ssm.get_parameter(Name='/services/rds/aurora-postgresql/dp_admin/cluster_arn', WithDecryption=False)
    db_cluster_arn = parameter['Parameter']['Value']
    parameter = ssm.get_parameter(Name='/services/sm/rds/db_admin/arn', WithDecryption=False)
    db_credentials_secrets_store_arn = parameter['Parameter']['Value']
    parameter = ssm.get_parameter(Name='/service/sqs/glue-invoke', WithDecryption=False)
    QUEUE_NAME_JOB_INVOKE = parameter['Parameter']['Value']
    parameter = ssm.get_parameter(Name='/service/sqs/job-status', WithDecryption=False)
    QUEUE_NAME_JOB_STATUS = parameter['Parameter']['Value']
    lytxLogger.debug("inside populateParameter QUEUE_NAME_JOB_INVOKE : {} , QUEUE_NAME_JOB_STATUS: {},database_name:{},db_cluster_arn:{},db_credentials_secrets_store_arn:{} ".format(QUEUE_NAME_JOB_INVOKE,QUEUE_NAME_JOB_STATUS,database_name,db_cluster_arn,db_credentials_secrets_store_arn))
    
    
