import logging
import os
import urllib
import boto3

logger = logging.getLogger()
logger.setLevel(logging.INFO)
client = boto3.client("s3")


def get_key_from_event(event):
    details = event["detail"]
    bucket = details["bucket"]["name"]
   #key = urllib.parse.unquote_plus(details["object"]["key"], encoding="utf-8")
    key = details["object"]["key"]
    return bucket, key


def get_key_from_file(key):
    if "/topics/" in key:
        key = key.replace("/topics/","/")
    return key.replace("ingest", "raw")


def lambda_handler(event, context):
    bucket, key = get_key_from_event(event)
    logger.info(
        "Input Event from S3 event notification bucket: %s key: %s", bucket, key
    )
    new_key = get_key_from_file(key)
    logger.info("The File will move to S3 bucket: %s key: %s", bucket, new_key)
    try:
        source_key = bucket + "/" + key
        copy_response = client.copy_object(
            Bucket=bucket, CopySource=source_key, Key=new_key
        )
        # check if the copy is completed and returned response code of 200
        logger.info("File successfully moved to S3 bucket: %s key: %s", bucket, new_key)
        if copy_response["ResponseMetadata"]["HTTPStatusCode"] == 200:
            client.delete_object(Bucket=bucket, Key=key)
    except Exception as e:
        logger.error("Exception: %s", e)
    return {"bucket": bucket, "key": new_key}
