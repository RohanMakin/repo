import json
import boto3
from lytxlogger.lytx_logger import LytxLogger
import uuid
import time
import os
import datetime as dt
from datetime import datetime
from json import JSONDecodeError
from botocore.exceptions import ClientError
from collections import OrderedDict

SQS = boto3.client("sqs")
s3 = boto3.resource('s3')
s3_client = boto3.client('s3')
dynamodb_resource = boto3.resource('dynamodb')
sns_topic_job_fail = os.environ['FAILURE_SNS_TOPIC']


global dynamo_config_master_table
# dynamo_config_master_table = "lytx-data-platform-stg-redshift-autoloader-config-master"
dynamo_config_master_table = os.environ['DYNAMO_CONFIG_MASTER_TABLE']
dynamo_file_details_table = os.environ['DYNAMO_FILE_DETAILS_TABLE']

# dynamo_file_details_table = "lytx-data-platform-stg-redshift-autoloader-file-details"

lytxLogger = LytxLogger.create("logger_" + __name__)


def get_env_name(resourceName):
    if '-dev-' in resourceName:
        return "dev"
    elif '-stg-' in resourceName:
        return "stg"
    elif '-prod-' in resourceName:
        return "prod"
        
def remove_duplicates(dict_list):
    # Use an OrderedDict to preserve the order and remove duplicates
    try:
        unique_dict_list = list(OrderedDict((tuple(sorted(d.items())), d) for d in dict_list).values())
        return unique_dict_list
    except Exception as e:
        lytxLogger.error(f'Failed to remove duplicates with error = {str(e)}', error_code = "remove_duplicates_error")
        
    

def read_dynamo_metadata(bucketName):
    table = dynamodb_resource.Table(dynamo_config_master_table)
    result = []
    try:
        result = table.query(
            KeyConditionExpression="bucketName = :bucketName",
            FilterExpression="isActive = :isActive",
            ExpressionAttributeValues={
                ":bucketName": bucketName,
                ":isActive": True
            },
        )
        # if not result['Items']:
        #     raise ValueError("No object entry found in dynamodb for the metadata")

        return result['Items']

    except ClientError as err:
        lytxLogger.error(f'Failed to read the dynamo metadata, error = {str(err)}', error_code = "read_dynamo_metadata")
        raise err


def insert_items_in_dynamoDb(items, table_name):
    retry_count = 0
    max_retry = 3
    status = 'Failure'
    while retry_count < max_retry and status == 'Failure':
        try:
            # Get the DynamoDB table
            table = dynamodb_resource.Table(table_name)
            unique_dict_list = remove_duplicates(items)
            # Create a batch writer
            with table.batch_writer() as batch:
                for item in unique_dict_list:
                    # Insert each item into the batch
                    batch.put_item(Item=item)
            lytxLogger.info(f"{len(unique_dict_list)} items inserted successfully.")
            status = 'Success'

        except Exception as e:
            lytxLogger.error(f'Failed to write file details into dynamoDb with error = {str(e)}', error_code = "insert_dynamo_data")
            retry_count += 1
            if retry_count == 3:
                publish_message(sns_topic_job_fail, f"insert_items_in_dynamoDb in Autoloader Dynamodb lambda failed for {items} with error : {str(e)}")



def check_file_prefix_present(bucket_key, batch_dict):
    is_present = False
    batchSize = None
    dataSource = None
    isActive = None
    columnList = None
    redshiftTableName = None
    copyOptions = None

    for key in batch_dict.keys():
        if bucket_key.startswith(key):
            batchSize = batch_dict[key]["batchSize"]
            dataSource = batch_dict[key]["dataSource"]
            isActive = batch_dict[key]["isActive"]
            columnList = batch_dict[key]["columnList"]
            redshiftTableName = batch_dict[key]["redshiftTableName"]
            copyOptions = batch_dict[key]["copyOptions"]
            is_present = True
    return is_present, batchSize, dataSource, isActive, columnList, redshiftTableName, copyOptions

def get_bucket_key(bucket_name, key_prefix):
    """Concatenate bucket name and key prefix."""
    return f"{bucket_name}|{key_prefix}"


def get_optimized_metadata_dict(batch_dict, s3bucketName, keyPrefix):
    bucket_key = get_bucket_key(s3bucketName, keyPrefix)
    is_present_in_batch_dict, batchSize, dataSource, isActive, columnList, redshiftTableName,copyOptions = check_file_prefix_present(
        bucket_key, batch_dict)

    if not is_present_in_batch_dict:
        # read dynamo for the metadata if batch dict does not have the entry for the same.
        list_object_metadata = read_dynamo_metadata(s3bucketName)
        # insert into dictionary batch_dict for other iterations to retrieve metadata instead of Dynamodba
        for object_metadata in list_object_metadata:
            bucketKey = object_metadata["bucketName"] + "|" + object_metadata["filePrefix"]
            # print(f"new bucket key ===============> {bucketKey}")
            lytxLogger.info(f"new bucket key ===============> {bucketKey}")
            batch_dict[bucketKey] = object_metadata

        # read from temp dictionary batch_dict
        is_present_in_batch_dict, batchSize, dataSource, isActive, columnList, redshiftTableName, copyOptions = check_file_prefix_present(
            bucket_key, batch_dict)

    return is_present_in_batch_dict, batchSize, dataSource, isActive, columnList, redshiftTableName, copyOptions


def publish_message(sns_topic_arn, comment):
    """
    Publishes a message to a SNS topic.
    """
    sns_client = boto3.client('sns')
    sns_message = comment
    sns_subject = 'Warning!Alert : Insert_items_in_dynamoDb_Autoloader_Step1 lambda failed'
    try:

        response = sns_client.publish(
            TopicArn=sns_topic_arn,
            Message=sns_message,
            Subject=sns_subject,
        )['MessageId']

    except ClientError:
        lytxLogger.error(f'Could not publish message to the topic.',error_code = "ClientError")
        raise
    else:
        lytxLogger.error("Published message to SNS ",error_code = "Sns_publish_error")
        # return response

def lambda_handler(event, context):

    tracking_id = str(uuid.uuid4())
    lytxLogger.init_logger(get_env_name(context.function_name), 'REDSHIFT_AUTOLOADER_INSERT_FILE_DETAILS', "lambda",
                           context.function_name,
                           context.aws_request_id, tracking_id)
    utc_time_now = str(datetime.utcnow())

    # print(f"event =============== {event}")
    lytxLogger.info(f"event =============== {event}")


    messages_to_reprocess = []
    batch_failure_response = {}

    batch_dict = {}
    items_list = []

    for counter, record in enumerate(event['Records']):
        global msgbody
        try:
            msgbody = json.loads(record.get("body"))
            # lytxLogger.info(f"{counter+1}. msgbody : {msgbody}")
            # print(f"{counter + 1}. msgbody : {msgbody}")
            # print(f"itemlist at the start of iteration----->>>>{items_list}")

            s3bucketName = msgbody["detail"]["bucket"]["name"] if "detail" in msgbody and "bucket" in msgbody[
                "detail"] and "name" in msgbody["detail"]["bucket"] else None
            keyPrefix = msgbody["detail"]["object"]["key"] if "detail" in msgbody and "object" in msgbody[
                "detail"] and "key" in msgbody["detail"]["object"] else None
            filePath = "s3://" + s3bucketName + "/" + keyPrefix
            contentSize = msgbody["detail"]["object"]["size"] if "detail" in msgbody and "object" in msgbody[
                "detail"] and "size" in msgbody["detail"]["object"] else None


            # print(f"calculated bucketname ============ {s3bucketName}")
            # print(f"calculated keyPrefix ============ {keyPrefix}")

            is_present_in_batch_dict, batchSize, dataSource, isActive, columnList, redshiftTableName, copyOptions=get_optimized_metadata_dict(batch_dict, s3bucketName, keyPrefix)


            # print(f"is present --------->>> {is_present_in_batch_dict}")

            if is_present_in_batch_dict:
                items_list.append({"filePath": filePath,
                                   "bucketName": s3bucketName,
                                   "isActive": isActive,
                                   "batchSize": batchSize,
                                   "dataSource": dataSource,
                                   "status": "FILE_LANDED",
                                   "contentSize": contentSize,
                                   "columnList": columnList,
                                   "redshiftTableName": redshiftTableName,
                                   "copyOptions": copyOptions,
                                   "createdTimestamp": utc_time_now
                                   })

            # print(f"batch_dict created--------------> {batch_dict}")

            # print(f"items_list to add into dynamo--------------> {items_list}")
        except JSONDecodeError as je:
            # messageReceiptHandle = record["receiptHandle"]
            # deleteMsgFromQueue(messageReceiptHandle)
            # moveFilesFromUnprocessed(msgbody)
            # lytxLogger.error(str(e), error_code="MALFORMED_JSON_MESSAGE")
            lytxLogger.error(f"Received malformed json message - {record.get('body')}", error_code="MALFORMED_JSON_MESSAGE")

            publish_message(sns_topic_job_fail,
             f"Malformed Json message received : {record.get('body')} , error : {str(je)}")
        except Exception as e:
            message_object = json.loads(record.get("body"))
            # append for reprocessing
            # lytxLogger.error(str(e),error_code="UNKNOWN_ERROR")
            lytxLogger.error("Error : {str(e)}",error_code="UNKNOWN_ERROR")
            # publish_message(SNS_TOPIC_JOB_FAIL,
            #                 f"Error occurred: for Datasource: {msgbody['dataSource']} and Subfolder: {msgbody['sourceBucketName']}/{msgbody['sourceBucketSubFolders']} with error :" + str(
            #                     e))
            # print(f"Error : {str(e)}")
            messages_to_reprocess.append({"itemIdentifier": record['messageId']})
            publish_message(sns_topic_job_fail, f"Autoloader Dynamodb insert lambda failed and error occurred for record : {message_object} with error : {str(e)}")

    if items_list:
        insert_items_in_dynamoDb(items_list, dynamo_file_details_table)

    batch_failure_response["batchItemFailures"] = messages_to_reprocess
    lytxLogger.info(f"batch_failure_response: {batch_failure_response}")
    lytxLogger.info(f"Lambda completed")
    return batch_failure_response

