#Reprocess unprocessed files from lytx-gps-kafka-<env>-003/stage/unprocessed/ which still there due to refine glue error
import json
import boto3
import logging
import os
import time
import hashlib
import uuid
import datetime as dt


logger = logging.getLogger()
logger.setLevel(logging.INFO)

SQS = boto3.client("sqs")
#Queues
QUEUE_NAME_JOB_INVOKE = ''
trackingId = str(uuid.uuid1())
#sample input json required for this lambda
#{
#  "jobRunId": ["jr_345c437dcf20b1fb42c8e7f55478389ab733b257234437ff82258771200402e9"],
#  "DATASOURCE_NAME": "GPS",
#  "SOURCE": "lytx-gps-kafka-dev-oregon-003/stage/unprocessed/",
#  "COMMENT": "Optimization already completed,message to start refinement"
#}
def lambda_handler(event, context):
    
    #get the config paramerter
    populateParameter()
    global DATASOURCE_NAME,SOURCE,COMMENT
    logger.info("started...")
    logger.info(event)
    
    #check for required input
    if event.__contains__("DATASOURCE_NAME") == False:
        logger.error("DATASOURCE_NAME is missing in input json")
        return 'DATASOURCE_NAME is missing in input json'
    
    if event.__contains__("SOURCE") == False:
        logger.error("SOURCE is missing in input json")
        return 'SOURCE is missing in input json'
    
    if event.__contains__("JOB_RUN_IDS") == False:
        logger.error("JOB_RUN_IDS is missing in input json")
        return 'JOB_RUN_IDS is missing in input json'
    
    DATASOURCE_NAME = event["DATASOURCE_NAME"]
    SOURCE = event["SOURCE"]
    COMMENT = event["COMMENT"]
    
    
    for jobRunId in event["JOB_RUN_IDS"]:
        logger.info("jobRunId arg:%s",jobRunId)
        
        sendMsgToJobInvoke( prepareGlueInvokeSqsMsg(jobRunId) )
    
    logger.info("finished")
    return 'Success'

def prepareGlueInvokeSqsMsg(jobRunId):
    logger.debug("prepareGlueInvokeSqsMsg start %s",jobRunId)
    
    msgJson = {
            "JOB_ID": "",
            "DATASOURCE_NAME": DATASOURCE_NAME,
            "SOURCE": SOURCE+jobRunId,
            "TARGET": "",
            "STEP_NAME": "REFINED",
            "FILENAMES": jobRunId,
            "HASH": hashlib.md5(jobRunId.encode()).hexdigest(),
            "STEP_STATUS": "INITIATED",
            "DATE": dt.datetime.now().strftime("%Y-%m-%dT%H:%M:%SZ"),
            "COMMENT":COMMENT,
            "TRACKING_ID": trackingId
          }
    
    
    logger.debug("prepareGlueInvokeSqsMsg end")
    return json.dumps(msgJson)

def getQueueURL(queueName):
    """Retrieve the URL for the configured queue name"""
    q = SQS.get_queue_url(QueueName=queueName).get('QueueUrl')
    logger.debug("Queue URL is %s", q)
    return q


def sendMsgToJobInvoke(msgJsonStr):
    try:
        logger.info("sendMsgToJobInvoke Recording msgJsonStr: %s", msgJsonStr)
        url = getQueueURL(QUEUE_NAME_JOB_INVOKE)
        logging.debug("Got queue URL %s", url)
        unique1 = str(time.time())+"_"+QUEUE_NAME_JOB_INVOKE
        logging.debug("JobInvoke MessageDeduplicationId  %s", unique1)
        
        resp = SQS.send_message(QueueUrl=url, MessageBody=msgJsonStr,MessageGroupId="L1_GR_REPROCESS",MessageDeduplicationId=unique1)
        logger.debug("Send result: %s", resp)
    except Exception as e:
        raise Exception("Exception while sendMsgToJobInvoke: %s" % e)
    
#--------------------------------------------------------------------------------
# get all config props from parameter store
#--------------------------------------------------------------------------------
def populateParameter():
    ssm = boto3.client('ssm')
    global QUEUE_NAME_JOB_INVOKE
    parameter = ssm.get_parameter(Name='/service/sqs/glue-invoke', WithDecryption=False)
    QUEUE_NAME_JOB_INVOKE = parameter['Parameter']['Value']
    
