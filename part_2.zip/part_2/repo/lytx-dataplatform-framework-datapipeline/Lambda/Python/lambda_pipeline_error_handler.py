import json
import boto3
import logging
import time
import hashlib
import datetime as dt

logger = logging.getLogger()
logger.setLevel(logging.INFO)

sqs = boto3.client("sqs")
# This is the Data API client that will be used in our examples below
rds_client = boto3.client('rds-data')

#parameters will get populated from parameter store start
database_name=''
db_cluster_arn=''
db_credentials_secrets_store_arn=''
queue_name_job_invoke = ''
#parameters will get populated from parameter store end

#durationInHr : time range to search in old data records
durationInHr=1
#--------------------------------------------------------------------------------
# Main Functions 
#--------------------------------------------------------------------------------
def lambda_handler(event, context):
    print("process started")
    global durationInHr
    try:
        durationInHr = event['FAILURE_TIME_PERIOD_IN_HR_NUMBER']
    except Exception as e:
        durationInHr = 1
        logger.info("Not recieved FAILURE_TIME_PERIOD_IN_HR_NUMBER , default is "+str(durationInHr))
    
    populateParameter()
    
    #fetch failed record from job_details table and validate for already processed - trigger reprocess msg
    validateAndProcess()
    
    print("process completed")
    
    return {
        'statusCode': 200
    }
#--------------------------------------------------------------------------------
# Helper Functions for common msg template
#--------------------------------------------------------------------------------

def getMsgJson(DATASOURCE_NAME,STEP_STATUS,COMMENT,JOB_ID_DB,SOURCE, TARGET,FILENAMES,HASH,REPROCESS_STEP1):
    
    msgJson = {
            "JOB_ID": JOB_ID_DB,
            "DATASOURCE_NAME": DATASOURCE_NAME,
            "SOURCE": SOURCE,
            "TARGET": TARGET,
            "STEP_NAME": REPROCESS_STEP1,
            "FILENAMES": FILENAMES,
            "HASH": HASH,
            "STEP_STATUS": STEP_STATUS,
            "DATE": dt.datetime.now().strftime("%Y-%m-%dT%H:%M:%SZ"),
            "COMMENT":COMMENT
          }
    return json.dumps(msgJson)
    

#--------------------------------------------------------------------------------
# Helper Functions
#--------------------------------------------------------------------------------

def getQueueURL(queueName):
    """Retrieve the URL for the configured queue name"""
    q = sqs.get_queue_url(QueueName=queueName).get('QueueUrl')
    logger.debug("Queue URL is %s", q)
    return q

#--------------------------------------------------------------------------------
# Send sqs msg to glue job
#--------------------------------------------------------------------------------
def sendMsgToJobInvoke(msgJsonStr):
    try:
        logger.debug("sendMsgToJobInvoke Recording msgJsonStr: %s", msgJsonStr)
        print("sendMsgToJobInvoke Recording msgJsonStr:",msgJsonStr)
        url = getQueueURL(queue_name_job_invoke)
        logging.info("Got queue URL %s", url)
        unique1 = str(time.time())+"_"+queue_name_job_invoke
        logging.debug("JobInvoke MessageDeduplicationId  %s", unique1)
        
        resp = sqs.send_message(QueueUrl=url, MessageBody=msgJsonStr,MessageGroupId="L1_GR2",MessageDeduplicationId=unique1)
        logger.info("Send result: %s", resp)
    except Exception as e:
        raise Exception("Exception while sendMsgToJobInvoke: %s" % e)

#--------------------------------------------------------------------------------
# Helper Functions
#--------------------------------------------------------------------------------
def execute_statement(sql, sql_parameters=[]):
    print(sql)
    response = rds_client.execute_statement(
        secretArn=db_credentials_secrets_store_arn,
        database=database_name,
        resourceArn=db_cluster_arn,
        sql=sql,
        parameters=sql_parameters
    )
    return response

#--------------------------------------------------------------------------------
# Check and validate for failure records
#--------------------------------------------------------------------------------

def validateAndProcess():
    logger.debug('===== Parameterized query for job_details =====')
    sql = 'select "ID","JOB_ID","DATASOURCE_NAME","FILENAMES","HASH","SOURCE","TARGET","STEP_NAME","STEP_STATUS","DATE","COMMENT" from admin_schema.job_details where ("STEP_NAME"=\'OPTIMIZED\' or "STEP_NAME"=\'REFINED\' ) AND "STEP_STATUS"=\'FAILED_RETRIABLE\' AND to_timestamp("DATE",\'YYYY-MM-DD HH24:MI:SS\') BETWEEN NOW() - INTERVAL \''+str(durationInHr)+' HOURS\' AND NOW()'
    sql_parameters = []
    response = execute_statement(sql, sql_parameters)
    print("FAILED_RETRIABLE records:")
    print(response['records'])
    
    rows = response['records']
    rcounter = 0
    ccounter = 0
    dictionary = {
            "ID":0,
            "JOB_ID":"",
            "DATASOURCE_NAME":"",
            "FILENAMES":"",
            "HASH":"",
            "SOURCE":"",
            "TARGET":"",
            "STEP_NAME":"",
            "STEP_STATUS":"",
            "DATE":"",
            "COMMENT":""
        }
    for row in rows:
        rcounter = rcounter + 1
        #reset temp db data store variable
        
        ccounter = 0
        print("before validateAndProcess dictionary:"+json.dumps(dictionary))
        #global dictionary
        for col in row:
            ccounter = ccounter + 1
            print(col)
            
            if ccounter==1 :
                dictionary["ID"] = col['longValue']
            if ccounter==2 :
                dictionary["JOB_ID"] = col['stringValue']
            if ccounter==3 :
                dictionary["DATASOURCE_NAME"] = col['stringValue']
            if ccounter==4 :
                dictionary["FILENAMES"] = col['stringValue']
            if ccounter==5 :
                dictionary["HASH"] = col['stringValue']
            if ccounter==6 :
                dictionary["SOURCE"] = col['stringValue']
            if ccounter==7 :
                dictionary["TARGET"] = col['stringValue']
            if ccounter==8 :
                dictionary["STEP_NAME"] = col['stringValue']
            if ccounter==9 :
                dictionary["STEP_STATUS"] = col['stringValue']
            if ccounter==10 :
                dictionary["DATE"] = col['stringValue']
            if ccounter==11 :
                dictionary["COMMENT"] = str(col['stringValue'])
        
        #logger.info("after validateAndProcess DB FAILED RECORD ID: %s, JOB_ID: %s,DATASOURCE_NAME: %s,FILENAMES: %s,HASH: %s,SOURCE: %s,TARGET: %s,STEP_NAME: %s,STEP_STATUS: %s,DATE: %s", str(ID),JOB_ID,DATASOURCE_NAME,FILENAMES,HASH,SOURCE,TARGET,STEP_NAME,STEP_STATUS,DATE)
        print("after validateAndProcess dictionary:"+json.dumps(dictionary))
        #take action to reprocessed
        validateAndSendReprocessMsg(dictionary)
        #dictionary.clear()

#--------------------------------------------------------------------------------
# validate for failure records to reprocess only if not success in that time peried
#--------------------------------------------------------------------------------


def validateAndSendReprocessMsg(dictionary):
    print("validateAndSendReprocessMsg dictionary:"+json.dumps(dictionary))
    FAILED_ID = dictionary["ID"]
    STEP_NAME1 = dictionary["STEP_NAME"]
    DATE1 = dictionary["DATE"]
    DATASOURCE_NAME1 = dictionary["DATASOURCE_NAME"]
    SOURCE1 = dictionary["SOURCE"]
    TARGET1 = dictionary["TARGET"]
    JOB_ID1 = dictionary["JOB_ID"]
    FILENAMES1 = dictionary["FILENAMES"]
    HASH1 = dictionary["HASH"]
    REPROCESS_STEP1=STEP_NAME1
    #validate
    sql = 'select "ID" from admin_schema.job_details where "DATASOURCE_NAME"=\''+DATASOURCE_NAME1+'\' AND "STEP_NAME"=\''+STEP_NAME1+'\' AND "HASH"=\''+HASH1+'\' AND "STEP_STATUS"=\'SUCCESS\'  AND to_timestamp("DATE",\'YYYY-MM-DD HH24:MI:SS\') > to_timestamp(\''+DATE1+'\',\'YYYY-MM-DD HH24:MI:SS\')'
    sql_parameters = []
    response = execute_statement(sql, sql_parameters)
    print("SUCCESS db records:")
    print(response['records'])
    
    rows = response['records']
    isAlreadySuccessInSameTime=0
    for row in rows:
        isAlreadySuccessInSameTime=1
        break;
    print("sqs DATASOURCE_NAME:"+DATASOURCE_NAME1)
    if isAlreadySuccessInSameTime==0:
        #Send Completed msg to job invoke sqs
        
        sendMsgToJobInvoke( getMsgJson(DATASOURCE_NAME1,"START","Re-initiate glue on failure case for job_details FAILED_ID:"+str(FAILED_ID), JOB_ID1,SOURCE1, TARGET1,FILENAMES1,HASH1,REPROCESS_STEP1) )
        print("JobInvoke success sqs msg sent for DATE1:"+DATE1+",DB job_details FAILED_ID:"+str(FAILED_ID))
    else:
        print("No need to send reprocess sqs msg for glue process to start for DATE1:"+DATE1+",DB job_details FAILED_ID:"+str(FAILED_ID))

#--------------------------------------------------------------------------------
# get all config props from parameter store
#--------------------------------------------------------------------------------
def populateParameter():
    ssm = boto3.client('ssm')
    global queue_name_job_invoke
    global database_name
    global db_cluster_arn
    global db_credentials_secrets_store_arn
        
    parameter = ssm.get_parameter(Name='/services/rds/aurora-postgresql/dp_admin/database', WithDecryption=False)
    database_name = parameter['Parameter']['Value']
    parameter = ssm.get_parameter(Name='/services/rds/aurora-postgresql/dp_admin/cluster_arn', WithDecryption=False)
    db_cluster_arn = parameter['Parameter']['Value']
    parameter = ssm.get_parameter(Name='/services/sm/rds/db_admin/arn', WithDecryption=False)
    db_credentials_secrets_store_arn = parameter['Parameter']['Value']
    parameter = ssm.get_parameter(Name='/service/sqs/glue-invoke', WithDecryption=False)
    queue_name_job_invoke = parameter['Parameter']['Value']
