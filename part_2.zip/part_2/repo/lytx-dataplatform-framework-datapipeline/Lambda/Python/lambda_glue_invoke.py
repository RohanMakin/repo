import json
import os
import logging
import time
import hashlib
import datetime as dt
from lytxlogger.lytx_logger import LytxLogger
import boto3
from json import JSONDecodeError


lytxLogger = LytxLogger.create("logger_" + __name__)


# Set up logging to print only error from other python logging
logger = logging.getLogger()
logger.setLevel(logging.ERROR)

client = boto3.client('glue')
SQS = boto3.client("sqs")

# Queues
QUEUE_NAME_JOB_STATUS = ''

# 3 parameters for RDS & SecreteStroe environment
database_name = ''
db_cluster_arn = ''
db_credentials_secrets_store_arn = ''

# This is the Data API client that will be used in our examples below
rds_client = boto3.client('rds-data')
# Msg common data
# DATASOURCE_NAME = 'GPS'
Datasource = ''
N_WEATHER = ''

queueUrlMap = {}

# STEP_NAME = 'OPTIMIZED'

# Variables for the job:
# glueJobName = "etl_glue_job_dev"
        
# Define Lambda function
def lambda_handler(event, context):

    # get the config paramerter
    records = event['Records']

    messages_to_reprocess = []
    batch_failure_response = {}

    for counter, record in enumerate(records):
        try:
            global msgbody
            msgbody = json.loads(record.get("body"))

            # msgbody = json.loads(event['Records'][0].get("body"))
            # making it global variable
            global Datasource, filenames, hash_val , refined_step , optimization_step
            Datasource = msgbody['DATASOURCE_NAME']

            global TRACKING_ID
            if msgbody.__contains__('TRACKING_ID'):
                TRACKING_ID = msgbody['TRACKING_ID']
            lytxLogger.init_logger( getEnvName(context.function_name), Datasource , "lambda", context.function_name , context.aws_request_id, TRACKING_ID )
            lytxLogger.debug(f"{counter + 1}. Event record in progress = {record}")
            lytxLogger.debug(f"{counter + 1}. All Event records in request = {records}")
            lytxLogger.debug(f"{counter + 1}. msgbody = {msgbody}")
            populateParameter()
            lytxLogger.info(
                "inside lambda_handler QUEUE_NAME_JOB_STATUS: {},database_name:{},db_cluster_arn:{},db_credentials_secrets_store_arn:{} ".format(
                QUEUE_NAME_JOB_STATUS, database_name, db_cluster_arn, db_credentials_secrets_store_arn))

            filenames = msgbody['FILENAMES']
            hash_val = msgbody['HASH']

            step_name = msgbody['STEP_NAME']
            lytxLogger.debug("step_name = {}".format( step_name))
            optimization_step = 'OPTIMIZED'
            refined_step = 'REFINED'

            current_step_name = ''

            #Call only for GPS refine
            if step_name == 'SAVE_RAW' or step_name == optimization_step :
                callOptimization(optimization_step)
                global SOURCE_DIR
                if step_name == 'SAVE_RAW':
                    SOURCE_DIR = msgbody['TARGET']
                else:
                    SOURCE_DIR = msgbody['SOURCE']
                current_step_name = optimization_step
            else:
                callRefined(refined_step, Datasource)
                SOURCE_DIR = msgbody['SOURCE']
                lytxLogger.debug("SOURCE_DIR = {}".format( SOURCE_DIR))
                current_step_name = refined_step

            lytxLogger.debug("lambda_handler IS_ACTIVE: {}".format(IS_ACTIVE))

            if IS_ACTIVE != 'Y':
                msg = "completed with no job called , as job is deactive for Datasource:"+Datasource+" , STEP_NAME:"+current_step_name
                lytxLogger.info(msg)
                continue

            # parsing parttition info to glue
            global date, key_name, TARGET_DIR, PARTITION_KEY

            date = dt.date.today()
            # key_name = '/' +'year=' + str(date.year) + '/month=' + str(date.month) + '/day=' + str(date.day) + '/'
            key_name = '/' + 'year=' + str(date.year) + '/month=' + str(date.month) + '/day=' + str(date.day)
            PARTITION_KEY = key_name

            lytxLogger.debug('## TRIGGERED BY SQS EVENT TO INVOKE GLUE JOB: ')
            lytxLogger.debug('## DATASOURCE NAME RECEIVED FROM SQS IS : ' + Datasource)
            glueJobName = ETL_GLUE_JOB_NAME

            # check the Available job names listed in glue to match the datasource
            glue_jobs_names = client.list_jobs(MaxResults=50)
            check_list = any(job_list == glueJobName for job_list in glue_jobs_names['JobNames'])

            while "NextToken" in glue_jobs_names and check_list != True:
                glue_jobs_names = client.list_jobs(NextToken=glue_jobs_names["NextToken"], MaxResults=50)
                check_list = any(job_list == glueJobName for job_list in glue_jobs_names['JobNames'])

            # lytxLogger.info(glue_jobs_names)
            # lytxLogger.debug(check_list)
            if check_list == True:
                lytxLogger.info("etl job matches the job list in glue")
            else:
                sendMsgToJobStatus(getMsgJson("FAILED", 'error:etl job name not exists', STEP_ID, SOURCE_DIR, TARGET_DIR))
                lytxLogger.info(f"error:etl job name - {glueJobName} not exists ")
                continue
        except JSONDecodeError as jde:
            lytxLogger.error(str(jde), error_code="MALFORMED_JSON_MESSAGE")
            lytxLogger.error(f'Received malformed json message - {record.get("body")}', error_code="MALFORMED_JSON_MESSAGE")
            continue
        except ValueError as ve:
            lytxLogger.error(str(ve), error_code="DATASOURCE_NOT_FOUND")
            lytxLogger.error('Entry related with Datasource not found in RDS', error_code="DATASOURCE_NOT_FOUND")
            continue
        except Exception as e:
            lytxLogger.error(str(e), error_code="UNKNOWN_FAILURE")
            lytxLogger.error(F'Failed due to unknown reasons while initialization sqs messageId = {record["messageId"]}', error_code="UNKNOWN_FAILURE")
            messages_to_reprocess.append({"itemIdentifier": record['messageId']})
            continue


        #will remove later  SQS_VIDEO_DOWNLOADER , S3_VIDEO_BASE_URL ,once glue job refractor of gps
        try:
            response = client.start_job_run(JobName=glueJobName, Arguments={'--SOURCE': SOURCE_DIR, '--FILE_NAMES': filenames, '--TARGET': TARGET_DIR,
                                                                            '--NOOA_STAGE_DIR': NOOA_TARGET_DIR,
                                                                            '--NOOA_RISKY_WEATHER_LIST': NOOA_RISKY_WEATHER_LIST,
                                                                            '--SQS_VIDEO_DOWNLOADER': SQS_VIDEO_DOWNLOADER,
                                                                            '--S3_VIDEO_BASE_URL': S3_VIDEO_BASE_URL,
                                                                            '--PARTITION_KEY': PARTITION_KEY,'--DATASOURCE_NAME': Datasource,'--N_WEATHER': N_WEATHER,'--TRACKING_ID':TRACKING_ID})
            lytxLogger.info("start_job_run response {}".format(response))
            status = client.get_job_run(JobName=glueJobName, RunId=response['JobRunId'])
            lytxLogger.info(status)
            state = status['JobRun']['JobRunState']
            job_run_id = response['JobRunId']
            lytxLogger.info('## STARTED GLUE JOB: ' + glueJobName)
            lytxLogger.info('## GLUE JOB RUN ID: ' + response['JobRunId'])
            lytxLogger.info('## GLUE JOB STATUS: ' + status['JobRun']['JobRunState'])
            sendMsgToJobStatus(getMsgJson("START", 'Job Started ' + str(glueJobName), STEP_ID, SOURCE_DIR, TARGET_DIR))

        except Exception as e:
            lytxLogger.error(str(e),error_code="GLUE_INVOKE_FAILED")
            lytxLogger.error('Error starting glue job',error_code="GLUE_INVOKE_FAILED")
            sendMsgToJobStatus(getMsgJson("FAILED_RETRIABLE", 'Job Failed due to, ' + str(e), STEP_ID, SOURCE_DIR, TARGET_DIR))
            messages_to_reprocess.append({"itemIdentifier": record['messageId']})

    batch_failure_response["batchItemFailures"] = messages_to_reprocess
    lytxLogger.info(f'## batch_failure_response: {batch_failure_response}')
    lytxLogger.info('## Glue invoke lambda execution completed successfully')
    return batch_failure_response


def callOptimization(jobStep):
    sql_parameterized_query(jobStep)
    
def callRefined(jobStep, ds):
    # CAll db to get job master data and populate global variables
    if jobStep == 'REFINED' and ds == 'GPS':
        retrive_nooa_query()
    sql_parameterized_query(jobStep)


def execute_statement(sql, sql_parameters=[]):
    response = rds_client.execute_statement(
        secretArn=db_credentials_secrets_store_arn,
        database=database_name,
        resourceArn=db_cluster_arn,
        sql=sql,
        parameters=sql_parameters
    )
    return response


def sql_parameterized_query(JOB_STEP_NAME):
    global SOURCE_DIR, TARGET_DIR, IS_ACTIVE, STEP_ID, JOB_STEP, ETL_GLUE_JOB_NAME
    lytxLogger.debug('===== Parameterized query for job_master_data =====')
    # sql = 'select "SOURCE_DIR" ,"TARGET_DIR","IS_ACTIVE","STEP_ID","JOB_STEP","ETL_GLUE_JOB_NAME" from admin_schema.job_master_data where "JOB_STEP"=\'OPTIMIZED\' and "DATA_SOURCE"=:ds'
    sql = 'select "SOURCE_DIR" ,"TARGET_DIR","IS_ACTIVE","STEP_ID","JOB_STEP","ETL_GLUE_JOB_NAME" from admin_schema.job_master_data where  "DATA_SOURCE"=:ds and "JOB_STEP" = :jobStep order by "JOB_STEP" ASC'
    ds = Datasource
    jobStep = JOB_STEP_NAME
    lytxLogger.debug('Datasource {}'.format(ds))
    sql_parameters = [{'name': 'ds', 'value': {'stringValue': f'{ds}'}},
                      {'name': 'jobStep', 'value': {'stringValue': f'{jobStep}'}}]
    response = execute_statement(sql, sql_parameters)
    lytxLogger.info('printing the api responce {}'.format(response))
    api_responce = (response['records'])
    if not api_responce:
        lytxLogger.warn("List is empty for the api responce")
        raise ValueError('error:API responce returns 0 records from the database select query')
    true = 'NULL'
    # TODO if records size is greater than 1 then error and exit
    api_responce = (response['records'][0])

    db_result = []
    for x in api_responce:
        for y in x.values():
            db_result.append(y)
    lytxLogger.debug('db_result: {}'.format(db_result))
    SOURCE_DIR, TARGET_DIR, IS_ACTIVE, STEP_ID, JOB_STEP, ETL_GLUE_JOB_NAME = db_result

    global JOB_STEP_DB
    JOB_STEP_DB = JOB_STEP


NOOA_TARGET_DIR = ''
JOB_STEP_DB = ''


# retrive nooa data
def retrive_nooa_query():
    sql_nova = 'select "TARGET_DIR" from admin_schema.job_master_data where "DATA_SOURCE"=\'NOAA\' and "JOB_STEP" in (\'OPTIMIZED\') order by "JOB_STEP" ASC'
    nova_response = execute_statement(sql_nova)
    lytxLogger.debug('printing the api responce for nooa {}'.format(nova_response))
    api_responce = (nova_response['records'])
    if not api_responce:
        lytxLogger.warn("List is empty for the api responce for nooa")
        raise ValueError('error:API responce returns 0 records from the database select query')
    true = 'NULL'
    global NOOA_TARGET_DIR
    NOOA_TARGET_DIR = (nova_response['records'][0][0]['stringValue'])
    # api_responce2 = (nova_response['records'][1])
    # for x in api_responce2:
    #    api_responce.append(x)

    lytxLogger.debug(NOOA_TARGET_DIR)


def getMsgJson(STEP_STATUS, COMMENT, STEP_ID, SOURCE_DIR, TARGET_DIR):
    lytxLogger.info("sqs msgJson data",
                    metadata={"filenames": filenames, "hash": hash_val, "source_bucket_name": SOURCE_DIR,
                              "target_bucket_name": TARGET_DIR, "step_name": JOB_STEP_DB, "job_id": STEP_ID,
                              "comment": COMMENT, "datasource_name": Datasource})
    msgJson = {
        "JOB_ID": STEP_ID,
        "DATASOURCE_NAME": Datasource,
        "SOURCE": SOURCE_DIR,
        "TARGET": TARGET_DIR,
        "STEP_NAME": JOB_STEP_DB,
        "FILENAMES": filenames,
        "HASH": hash_val,
        "STEP_STATUS": STEP_STATUS,
        "DATE": dt.datetime.now().strftime("%Y-%m-%dT%H:%M:%SZ"),
        "COMMENT": COMMENT,
        "TRACKING_ID": TRACKING_ID
    }
    return json.dumps(msgJson)


def getQueueURL(queueName):
    """Retrieve the URL for the configured queue name"""
    if queueUrlMap.__contains__(queueName):
        q_url = queueUrlMap[queueName]
    else:
        q_url = SQS.get_queue_url(QueueName=queueName).get('QueueUrl')
        queueUrlMap[queueName] = q_url
    lytxLogger.debug("Queue URL is {}".format(q_url))
    return q_url


def sendMsgToJobStatus(msgJsonStr):
    try:
        lytxLogger.info("sendMsgToJobStatus: Recording msgJsonStr: {}".format(msgJsonStr))
        url = getQueueURL(QUEUE_NAME_JOB_STATUS)
        lytxLogger.debug("Got queue URL {}".format(url))
        unique1 = str(time.time()) + "_" + QUEUE_NAME_JOB_STATUS
        lytxLogger.debug("JobStatus MessageDeduplicationId {}".format(unique1))

        resp = SQS.send_message(QueueUrl=url, MessageBody=msgJsonStr, MessageGroupId="L1_GR1",
                                MessageDeduplicationId=unique1)
        lytxLogger.info("Send result: {}".format(resp))
    except Exception as e:
        raise Exception("Exception while sendMsgToJobStatus: %s" % e)


def getEnvName(resourceName):
    if '-dev-' in resourceName:
        print('dev ')
        return "dev"
    elif '-stg-' in resourceName:
        print('stg ')
        return "stg"
    elif '-prod-' in resourceName:
        print('prod ')
        return "prod"


# --------------------------------------------------------------------------------
# get all config props from parameter store
# --------------------------------------------------------------------------------
def populateParameter():
    ssm = boto3.client('ssm')
    global QUEUE_NAME_JOB_STATUS
    global database_name
    global db_cluster_arn
    global db_credentials_secrets_store_arn
    global SQS_VIDEO_DOWNLOADER
    global NOOA_RISKY_WEATHER_LIST
    global S3_VIDEO_BASE_URL
    global N_WEATHER

    # Video Location for weather
    parameter = ssm.get_parameter(Name='/noaa/risky-weather-conditions', WithDecryption=False)
    NOOA_RISKY_WEATHER_LIST = parameter['Parameter']['Value']
    parameter = ssm.get_parameter(Name='/service/sqs/video-request', WithDecryption=False)
    SQS_VIDEO_DOWNLOADER = parameter['Parameter']['Value']
    parameter = ssm.get_parameter(Name='/video-download/bucket-name', WithDecryption=False)
    S3_VIDEO_BASE_URL = parameter['Parameter']['Value']

    parameter = ssm.get_parameter(Name='/services/rds/aurora-postgresql/dp_admin/database', WithDecryption=False)
    database_name = parameter['Parameter']['Value']
    parameter = ssm.get_parameter(Name='/services/rds/aurora-postgresql/dp_admin/cluster_arn', WithDecryption=False)
    db_cluster_arn = parameter['Parameter']['Value']
    parameter = ssm.get_parameter(Name='/services/sm/rds/db_admin/arn', WithDecryption=False)
    db_credentials_secrets_store_arn = parameter['Parameter']['Value']
    parameter = ssm.get_parameter(Name='/service/sqs/job-status', WithDecryption=False)
    QUEUE_NAME_JOB_STATUS = parameter['Parameter']['Value']
    parameter = ssm.get_parameter(Name='/noaa/n-weather-condition', WithDecryption=False)
    N_WEATHER = parameter['Parameter']['Value']
    
    lytxLogger.debug(
        "inside populateParameter QUEUE_NAME_JOB_STATUS: {},database_name:{},db_cluster_arn:{},db_credentials_secrets_store_arn:{} ".format(
        QUEUE_NAME_JOB_STATUS, database_name, db_cluster_arn, db_credentials_secrets_store_arn))