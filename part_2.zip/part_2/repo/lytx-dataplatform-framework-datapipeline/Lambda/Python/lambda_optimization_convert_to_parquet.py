import json
import uuid
import boto3
import time
import awswrangler as wr
import hashlib
import urllib
import logging
import datetime as dt
import pandas as pd
from boto3.dynamodb.conditions import Key, Attr
from botocore.exceptions import ClientError

logger = logging.getLogger()
logger.setLevel(logging.INFO)
# Define the clients
s3_client = boto3.client("s3")
SQS = boto3.client("sqs")
dynamodb_resource = boto3.resource('dynamodb')

trackingId = str(uuid.uuid1())

DATASOURCE_NAME = ""
STEP_NAME = 'PARQUET_CONVERSION'
# below will populate by db data
JOB_ID_DB = ""
# below will populate by db data
SOURCE_BUCKET_DB = ''
# below will populate by db data
TARGET_BUCKET_DB = ''
# below will populate by db data
IS_ACTIVE_DB = ''

fileNames = ""
envName = ""


def getEnvName(resourceName):
    if '-dev-' in resourceName:
        return "dev"
    elif '-stg-' in resourceName:
        return "stg"
    elif '-prod-' in resourceName:
        return "prod"


def populateParameter():
    ssm = boto3.client('ssm')
    global QUEUE_NAME_JOB_STATUS
    global database_name
    global db_cluster_arn
    global db_credentials_secrets_store_arn
    global dynamo_config_master_table
    global dynamo_job_details_table
    parameter = ssm.get_parameter(Name='/services/rds/aurora-postgresql/dp_admin/database', WithDecryption=False)
    database_name = parameter['Parameter']['Value']
    parameter = ssm.get_parameter(Name='/services/rds/aurora-postgresql/dp_admin/cluster_arn', WithDecryption=False)
    db_cluster_arn = parameter['Parameter']['Value']
    parameter = ssm.get_parameter(Name='/services/sm/rds/db_admin/arn', WithDecryption=False)
    db_credentials_secrets_store_arn = parameter['Parameter']['Value']

    parameter = ssm.get_parameter(Name='/service/sqs/job-status', WithDecryption=False)
    QUEUE_NAME_JOB_STATUS = parameter['Parameter']['Value']
    parameter = ssm.get_parameter(Name=f'lytx-{envName}-dynamo-config-master-table', WithDecryption=False)
    dynamo_config_master_table = parameter['Parameter']['Value']
    parameter = ssm.get_parameter(Name=f'lytx-{envName}-dynamo-job-details-table', WithDecryption=False)
    dynamo_job_details_table = parameter['Parameter']['Value']

    logger.debug(
        "inside populateParameter QUEUE_NAME_JOB_STATUS: {},database_name:{},db_cluster_arn:{},db_credentials_secrets_store_arn:{} ".format(
            QUEUE_NAME_JOB_STATUS, database_name, db_cluster_arn, db_credentials_secrets_store_arn))


def getMsgJson(fileNames, STEP_STATUS, COMMENT, JOB_ID_DB, SOURCE_BUCKET_DB, TARGET_BUCKET_DB, STEP_NAME):
    HASH = hashlib.md5(fileNames.encode()).hexdigest()

    msgJson = {
        "JOB_ID": JOB_ID_DB,
        "DATASOURCE_NAME": DATASOURCE_NAME,
        "SOURCE": SOURCE_BUCKET_DB,
        "TARGET": TARGET_BUCKET_DB,
        "STEP_NAME": STEP_NAME,
        "FILENAMES": fileNames,
        "HASH": HASH,
        "STEP_STATUS": STEP_STATUS,
        "DATE": dt.datetime.now().strftime("%Y-%m-%dT%H:%M:%SZ"),
        "COMMENT": COMMENT,
        "TRACKING_ID": trackingId
    }
    return json.dumps(msgJson)


def getQueueURL(queueName):
    """Retrieve the URL for the configured queue name"""
    q = SQS.get_queue_url(QueueName=queueName).get('QueueUrl')
    logger.debug("Queue URL is {}".format(q))
    return q


def sendMsgToJobStatus(msgJsonStr):
    try:
        logger.info("sendMsgToJobStatus: Recording msgJsonStr: {}".format(msgJsonStr))
        url = getQueueURL(QUEUE_NAME_JOB_STATUS)
        unique1 = str(time.time()) + "_" + QUEUE_NAME_JOB_STATUS
        resp = SQS.send_message(QueueUrl=url, MessageBody=msgJsonStr, MessageGroupId="L1_GR1",
                                MessageDeduplicationId=unique1)
        logger.debug("Send result: {}".format(resp))
    except Exception as e:
        raise Exception("Exception while sendMsgToJobStatus: %s" % e)


def get_schema_source(bucket, key):
    if "netsuite" in bucket:
        tableId = "NETSUITE/" + key.split('/')[1].upper()
        logger.debug(
            "tableId for NetSuite object is: %s", tableId
        )
        schemaWrite = get_schema_dynamo(dynamo_config_master_table, "tableId", tableId)
        # schemaWrite1 = get_schema_dynamo1(dynamo_job_details_table, "tableId", tableId)
        # print(f"schemaWrite1 is{schemaWrite1}")
    else:
        dataSource = "MARKETO_" + key.split('/')[1].upper()
        logger.debug(
            "dataSource for Marketo object is: %s", dataSource
        )
        schemaWrite = read_schema_version_from_db(dataSource, "WRITE_PARQUET_SCHEMA")

    return schemaWrite


# get_dynamo_db_job_details
def get_schema_dynamo1(tableName, filterkey, filterValue):
    """
    Scans dynamodb metadata table for schema that were being declared for the respective table.
    """
    table = dynamodb_resource.Table(tableName)
    result = []
    scan_kwargs = {
        'FilterExpression': '#TID=:TID',
        'ProjectionExpression': "#TID, #TN, #CM",
        'ExpressionAttributeNames': {"#TID": str(filterkey), "#TN": "tableName", "#CM": "comment"},
        'ExpressionAttributeValues': {
            ":TID": str(filterValue)}
    }
    try:
        done = False
        start_key = None
        while not done:
            if start_key:
                scan_kwargs['ExclusiveStartKey'] = start_key
            response = table.scan(**scan_kwargs)
            print(f"inside get_schema_dynamo1 response is {response}")
            result.extend(response.get('Items', []))
            print(f"inside get_schema_dynamo1 result is {result}")
            start_key = response.get('LastEvaluatedKey', None)
            done = start_key is None
        if not result:
            logger.debug("No object entry found in dynamodb for fetching schema")
            raise ValueError("No object entry found in dynamodb for fetching schema")
    except ClientError as err:
        logger.error(
            "Couldn't scan for schema. Here's why: %s: %s",
            err.response['Error']['Code'], err.response['Error']['Message'])
        raise err

    if 'comment' in result[0]:
        print(f"inside IF for get_schema_dynamo1")
        return result[0]['comment']
    else:
        logger.debug("No Schema entry found in dynamodb")
        raise ValueError("No schema entry found in dynamodb")


def get_schema_dynamo(tableName, filterkey, filterValue):
    """
    Scans dynamodb metadata table for schema that were being declared for the respective table.
    """
    table = dynamodb_resource.Table(tableName)
    result = []
    scan_kwargs = {
        'FilterExpression': '#TID=:TID',
        'ProjectionExpression': "#TID, #TN, #SW",
        'ExpressionAttributeNames': {"#TID": str(filterkey), "#TN": "tableName", "#SW": "schemaWrite"},
        'ExpressionAttributeValues': {
            ":TID": str(filterValue)}
    }
    try:
        done = False
        start_key = None
        while not done:
            if start_key:
                scan_kwargs['ExclusiveStartKey'] = start_key
            response = table.scan(**scan_kwargs)
            # print(f"response is {response}")
            result.extend(response.get('Items', []))
            # print(f"result is {result}")
            start_key = response.get('LastEvaluatedKey', None)
            done = start_key is None
        if not result:
            logger.debug("No object entry found in dynamodb for fetching schema")
            raise ValueError("No object entry found in dynamodb for fetching schema")
    except ClientError as err:
        logger.error(
            "Couldn't scan for schema. Here's why: %s: %s",
            err.response['Error']['Code'], err.response['Error']['Message'])
        raise err

    if 'schemaWrite' in result[0]:
        # print(f"inside IF for get_schema_")
        return eval(result[0]['schemaWrite'])
    else:
        logger.debug("No Schema entry found in dynamodb")
        raise ValueError("No schema entry found in dynamodb")


def read_schema_version_from_db(ds, ops):
    global prev_id, declared_schema, VERSION, OPERATION
    logger.debug('===== Parameterized query for job_master_data =====')
    sql = """select "ID","SCHEMA","VERSION","OPERATION" from admin_schema.schema_version  where  "DATA_SOURCE"=:ds and "OPERATION"=:ops """
    sql_parameters = [{'name': 'ds', 'value': {'stringValue': f'{ds}'}},
                      {'name': 'ops', 'value': {'stringValue': f'{ops}'}}]
    response = execute_statement(sql, sql_parameters)
    logger.debug('printing the api response {}'.format(json.dumps(response)))
    api_response = (response['records'])
    # logger.debug(api_response)
    if not api_response:
        logger.warning("List is empty for the api response from RDS")
        raise ValueError(
            'Schema Not found due to error:API response returns 0 records from the database RDS select query')
    true = 'NULL'
    api_response = (response['records'][0])
    logger.debug("api_response {}".format(json.dumps(api_response)))

    db_result = []
    for x in api_response:
        for y in x.values():
            db_result.append(y)
    prev_id, declared_schema, VERSION, OPERATION = db_result
    logger.debug("db_result:{} ,prev_id:{} ,declared_schema:{} ,VERSION:{} ,OPERATION:{}".format(db_result, prev_id,
                                                                                                 declared_schema,
                                                                                                 VERSION, OPERATION))
    return eval(declared_schema)


def execute_statement(sql, sql_parameters=[]):
    rds_client = boto3.client('rds-data')
    response = rds_client.execute_statement(
        secretArn=db_credentials_secrets_store_arn,
        database=database_name,
        resourceArn=db_cluster_arn,
        sql=sql,
        parameters=sql_parameters
    )
    return response


def validate_schema(df, declared_schema):
    csv_schema_list = [df.columns[i] for i in range(0, len(df.columns))]
    declared_schema_list = list(declared_schema.keys())
    csv_schema_list.sort()
    declared_schema_list.sort()
    if len(csv_schema_list) != len(declared_schema_list):
        return False
    else:
        return csv_schema_list == declared_schema_list


def get_key_from_event(event):
    bucket = event["bucket"]
    # key = urllib.parse.unquote_plus(event["key"], encoding="utf-8")
    key = event["key"]
    return bucket, key


def get_s3_key_for_stage(bucket, key):
    ext = '.' + key.split('.')[-1]
    stage_key = key.replace("raw", "stage").replace(ext, ".parquet")
    return "s3://" + bucket + "/" + stage_key


def read_file_df(source_key, ext, schemaRead=None):
    df = None
    if ext == 'json':
        df = wr.s3.read_json(path=source_key, lines=True)
    elif ext == 'csv' and schemaRead is not None:
        df = wr.s3.read_csv(path=source_key, delimiter=",", na_values=["null", "none"], low_memory=False,
                            dtype=schemaRead)
    elif ext == 'csv' and schemaRead is None:
        df = wr.s3.read_csv(path=source_key, delimiter=",", na_values=["null", "none"], low_memory=False)
    else:
        logger.info("Unknown file format encountered")
        raise ValueError("Unknown file format")
    return df


def check_condition_job_details(response):
    # Extract the necessary fields from the response
    items = response.get('Items', [])

    if items:
        item = items[0]
        print(f"item is {item}")
        load_type = item.get('loadType', '')
        print(f"load_type is {load_type}")
        comment = item.get('comment', '').upper()  # Convert comment to uppercase for case-insensitive check
        print(f"comment is {comment}")
        job_Status = item.get('jobStatus', '')
        print(f"jobStatus is : {job_Status}")
        tableId = item.get('tableId', '').upper()

        # Check if 'loadType' is 'FULL_LOAD' and 'WHERE' is not in the comment
        if 'WHERE' not in comment:
            return True

    return False


def write_df_to_stage(df, path, schemaWrite=None):
    if schemaWrite is None:
        wr.s3.to_parquet(df=df, path=path)
    else:
        df_new = df
        for col, dtype in schemaWrite.items():
            if dtype == 'date' or dtype == 'timestamp':
                df_new[col] = pd.to_datetime(df_new[col], errors='coerce')
        wr.s3.to_parquet(df=df_new, path=path, dtype=schemaWrite)
        if "netsuite" in path.lower():
            print("inside Netsuite")
            jobname = f'ore-{envName}-dp-glue-job-netsuite-subscriptionanalytics-sis'
            # contains_where = get_dynamo_db_job_details(path)
            # print(f"contains_where {contains_where}")
            # table = dynamodb_resource.Table(dynamo_job_details_table)
            # parts = path.split('/')
            # table_id = f"{parts[3].upper()}/{parts[4].upper()}"
            # response = table.query(KeyConditionExpression=Key("tableId").eq(tableId))
            # print(f"response is {response}")
            # if (tableId =='NETSUITE/CHARGES' or tableId =='NETSUITE/SYSTEM_NOTES'):
            #     resultJobDetails = check_condition_job_details(response)
            # print(f"resultJobDetails is :{resultJobDetails}")
            if not (
                    'subscription_analytics' in path.lower() or 'system_notes' in path.lower() or 'sis' in path.lower()):
                print("looking for file other than SIS or subscription")
                write_df_to_stage_in_json(df=df_new, path=path, jsonSchemaWrite=schemaWrite)
            if ('subscription_analytics' in path.lower() or 'system_notes' in path.lower() or 'sis' in path.lower()):
                try:
                    print(f"looking for SIS or subscription path {path}")
                    print(f"before calling Glue")
                    glu_client = boto3.client("glue")
                    response = glu_client.start_job_run(JobName=jobname,
                                                        Arguments={'--PATH': path})
                    job_run_id = response['JobRunId']
                    print(f'Started Glue job with JobRunId: {job_run_id}')
                    print(f"after Glue is completed")
                except Exception as e:
                    lytxLogger.error(str(e), error_code="GLUE_INVOKE_FAILED")
                    lytxLogger.error('Error starting glue job', error_code="GLUE_INVOKE_FAILED")


def write_df_to_stage_in_json(df, path, jsonSchemaWrite=None):
    try:
        # Derive the JSON path by replacing the appropriate parts of the S3 path
        json_path = path.replace("netsuite/", "redshift/netsuite/").replace('.parquet', '.json')

        # Log the derived JSON path
        print(f"Derived JSON path: {json_path}")
        # Enforce schema if provided
        if jsonSchemaWrite is not None:

            for key, value in jsonSchemaWrite.items():
                jsonSchemaWrite[key] = 'string'
            df = df.astype(jsonSchemaWrite)

        # Write the DataFrame to S3 as newline-delimited JSON
        wr.s3.to_json(df=df, path=json_path, orient='records', lines=True)

        print(f"DataFrame successfully written to {json_path}")

    except Exception as e:
        print(f"Exception occured while generating json file for netsuite: {str(e)}")


def get_data_source(target_s3_path):
    if "/netsuite" in target_s3_path:
        return "NetSuite"
    elif "/Marketo" in target_s3_path:
        return "Marketo"
    elif "/6Sense" in target_s3_path:
        return "6Sense"
    else:
        return target_s3_path.split('/')[1]


def updateJobDetails(tableName, tableId, status):
    table = dynamodb_resource.Table(tableName)
    table.update_item(
        Key={'tableId': tableId},
        UpdateExpression="set jobStatus = :jobStatus",
        ExpressionAttributeValues={':jobStatus': str(status)},
        ReturnValues="UPDATED_NEW")


def lambda_handler(event, context):
    bucket, key = get_key_from_event(event)
    logger.info(
        "Input Event from S3 event notification bucket: %s key: %s", bucket, key
    )
    target_s3_path = get_s3_key_for_stage(bucket, key)
    global DATASOURCE_NAME
    DATASOURCE_NAME = get_data_source(target_s3_path)
    global envName, schemaRead
    envName = getEnvName(context.function_name)
    declared_schema = None

    SOURCE_FILE_NAME = key.split('/')[-1]
    SOURCE_BUCKET_DB = bucket + "/" + key.replace(SOURCE_FILE_NAME, "")
    TARGET_BUCKET_DB = SOURCE_BUCKET_DB.replace("raw", "stage")
    try:
        populateParameter()
        ext = key.split('.')[-1]
        source_key = "s3://" + bucket + "/" + key

        sendMsgToJobStatus(
            getMsgJson(SOURCE_FILE_NAME, "START", "Lambda Started for parquet conversion " + str(context.function_name),
                       "6", SOURCE_BUCKET_DB, TARGET_BUCKET_DB, STEP_NAME))

        # table = dynamodb_resource.Table(dynamo_job_details_table)
        # tableId = "NETSUITE/" + key.split('/')[1].upper()
        # response = table.query(KeyConditionExpression=Key("tableId").eq(tableId))
        # print(f"response is {response}")
        # if (tableId =='NETSUITE/CHARGES' or tableId =='NETSUITE/SYSTEM_NOTES'):
        #     resultJobDetails = check_condition_job_details(response)
        # print(f"resultJobDetails is :{resultJobDetails}")

        schemaRead = f"str" if "netsuite" in target_s3_path.lower() else None
        df = read_file_df(source_key, ext, schemaRead)
        logger.info("Number of rows before blank rows removal is: %s", len(df))
        df.dropna(how="all", inplace=True)
        logger.info("Number of rows after blank rows removal is: %s", len(df))
        if not df.empty:
            if "netsuite" in target_s3_path.lower() or "marketo" in target_s3_path.lower():
                declared_schema = get_schema_source(bucket, key)
                if not validate_schema(df, declared_schema):
                    logger.debug(
                        "Schema validation failed as there are extra or changed columns in declared schema and file schema ")
                    updateJobDetails(dynamo_job_details_table, tableId="NETSUITE/" + key.split('/')[1].upper(),
                                     status="SCHEMA_CHANGED")

                    raise ValueError(
                        "Error Code:Schema validation failed as there are extra or changed columns in declared schema and file schema")
            logger.info("The File will move to S3 path: %s", target_s3_path)
            write_df_to_stage(df, target_s3_path, declared_schema)
            sendMsgToJobStatus(getMsgJson(SOURCE_FILE_NAME, "SUCCESS",
                                          "Lambda completed for parquet conversion " + str(context.function_name), "6",
                                          SOURCE_BUCKET_DB, TARGET_BUCKET_DB, STEP_NAME))
            return {"source_key": source_key, "new_path": target_s3_path}
        else:
            logger.info("Data file: %s is Empty.", source_key)
            sendMsgToJobStatus(getMsgJson(SOURCE_FILE_NAME, "SUCCESS", "Empty file(s) for parquet conversion ", "6",
                                          SOURCE_BUCKET_DB, TARGET_BUCKET_DB, STEP_NAME))
            return {"source_key": source_key}
    except Exception as e:
        logger.error("Exception: %s", e)
        sendMsgToJobStatus(getMsgJson(SOURCE_FILE_NAME, "FAILED",
                                      "Job Failed due to, " + str(e), "6",
                                      SOURCE_BUCKET_DB, TARGET_BUCKET_DB, STEP_NAME))
        raise e
