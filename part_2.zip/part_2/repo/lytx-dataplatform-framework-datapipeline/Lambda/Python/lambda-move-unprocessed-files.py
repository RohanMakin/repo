import json
import boto3
import logging
import time
import os
import datetime as dt
from json import JSONDecodeError
from botocore.exceptions import ClientError


from lytxlogger.lytx_logger import LytxLogger

lytxLogger = LytxLogger.create("logger_" + __name__)

SQS = boto3.client("sqs")
s3 = boto3.resource('s3')
s3_client = boto3.client('s3')

def lambda_handler(event, context):
    global QUEUE_NAME_MOVE_FILES, sourceBucketName, sourceBucketSubFolders, DATASOURCE, hash_val, TRACKING_ID, filenames, STEP_NAME, QUEUE_NAME_JOB_STATUS, SNS_TOPIC_JOB_FAIL
    STEP_NAME = 'MOVE_FILES'
    DATASOURCE = ''
    hash_val = 'Na'
    filenames = ''
    # QUEUE_NAME_MOVE_FILES = 'Test_Copy_Data_from_Unprocessed.fifo'
    TRACKING_ID = ''
    lytxLogger.info("move_stage_unprocessed_files started")

    populateParameter()

    lytxLogger.info(f"Incoming Event : {event}")
    messages_to_reprocess = []
    batch_failure_response = {}
    # try:
    for counter, record in enumerate(event['Records']):
        global msgbody
        try:
            msgbody = json.loads(record.get("body"))
            lytxLogger.info(f"{counter+1}. msgbody : {msgbody}")
            messageReceiptHandle = record["receiptHandle"]
            deleteMsgFromQueue(messageReceiptHandle)
            moveFilesFromUnprocessed(msgbody)

        except JSONDecodeError as e:
            lytxLogger.error(str(e), error_code="MALFORMED_JSON_MESSAGE")
            lytxLogger.error(f"Received malformed json message - {record.get('body')}", error_code="MALFORMED_JSON_MESSAGE")

            publish_message(SNS_TOPIC_JOB_FAIL,
                            f"Malformed Json message received : {record.get('body')} , error : {str(e)}")
        except Exception as e:
            # append for reprocessing
            lytxLogger.error(str(e),error_code="UNKNOWN_ERROR")
            lytxLogger.error(f'Error occurred: ',error_code="UNKNOWN_ERROR")
            publish_message(SNS_TOPIC_JOB_FAIL,
                            f"Error occurred: for Datasource: {msgbody['dataSource']} and Subfolder: {msgbody['sourceBucketName']}/{msgbody['sourceBucketSubFolders']} with error :" + str(
                                e))
            messages_to_reprocess.append({"itemIdentifier": record['messageId']})
    '''
    Batch_failure_response is used to handle partial failure in case batch size is increased from 1, by returning batch_failure_response.
    '''
    
    batch_failure_response["batchItemFailures"] = messages_to_reprocess
    lytxLogger.info(f"batch_failure_response: {batch_failure_response}")
    lytxLogger.info(f"Lambda completed")
    return batch_failure_response



def getQueueURL(queueName):
    """Retrieve the URL for the configured queue name"""
    print("IN getQueueURL with queueName: {}".format(queueName))

    q = SQS.get_queue_url(QueueName=queueName).get('QueueUrl')
    print("Queue URL is {}".format(q))
    lytxLogger.debug("Queue URL is {}".format(q))
    return q


def deleteMsgFromQueue(receiptHandle):
    try:
        lytxLogger.info("IN deleteMsgFromQueue with receiptHandle: {}".format(receiptHandle))

        lytxLogger.debug("deleteMsgFromQueue with receiptHandle: {}".format(receiptHandle))
        url = getQueueURL(QUEUE_NAME_MOVE_FILES)
        print("Got queue URL {}".format(url))
        lytxLogger.debug("Got queue URL {}".format(url))
        resp = SQS.delete_message(QueueUrl=url, ReceiptHandle=receiptHandle)
        lytxLogger.debug("Send result: {}".format(resp))
    except Exception as e:
        raise Exception("Exception while deleting message : %s" % e)


def moveFilesFromUnprocessed(msgbody):
    try:
        lytxLogger.info("move_stage_unprocessed_files started from moveFilesFromUnprocessed ")
        lytxLogger.info(f"msgbody : {msgbody}")
        sourceBucketName = msgbody['sourceBucketName']
        sourceBucketSubFolders = msgbody['sourceBucketSubFolders']
        targetBucketName = msgbody['targetBucketName']
        targetBucketSubFolders = msgbody['targetBucketSubFolders']
        DATASOURCE = msgbody['dataSource']
        TRACKING_ID = msgbody['trackingId']

        # targetBucketName = sourceBucketName
        lytxLogger.info(f"sourceBucketName: {sourceBucketName}")
        lytxLogger.info(f"sourceBucketSubFolders: {sourceBucketSubFolders}")
        lytxLogger.info(f"targetBucketName: {targetBucketName}")
        lytxLogger.info(f"targetBucketSubFolders: {targetBucketSubFolders}")
        lytxLogger.info(f"DATASOURCE: {DATASOURCE}")
        lytxLogger.info(f"TRACKING_ID: {TRACKING_ID}")

        JOB_ID = 8  
        filenames = ''

        bucket = s3.Bucket(sourceBucketName)
        objs = bucket.objects.filter(Prefix=sourceBucketSubFolders)
        lytxLogger.info(f"sourceBucketName = {sourceBucketName}")
        # Send start msg to job status sqs
        sendMsgToJobStatus(getMsgJson("START", 'Move files job Started for Tracking_ID: ' + TRACKING_ID, JOB_ID,
                                      sourceBucketName + '/' + sourceBucketSubFolders,
                                      targetBucketName + '/' + targetBucketSubFolders, filenames, DATASOURCE,
                                      TRACKING_ID))
        for record in objs:
            key = record.key
            if len(os.path.basename(key)) > 0:
                filenames += os.path.basename(key) + ","
            lytxLogger.info(f"{format(record)}")
            copy_source = {
                'Bucket': sourceBucketName,
                'Key': key
            }
            try:
                destbucket = s3.Bucket(targetBucketName)
                if os.path.dirname(key).endswith("_$folder$"):
                    s3_client.delete_object(Bucket=sourceBucketName, Key=key)
                elif os.path.dirname(key).startswith(sourceBucketSubFolders):
                    destbucket.copy(copy_source, targetBucketSubFolders + key.replace(sourceBucketSubFolders, ""))
                    s3_client.delete_object(Bucket=sourceBucketName, Key=key)
            except Exception as e:
                lytxLogger.error(f"Error occurred,{str(e)}",error_code="MOVE_FILES_FAILED")
                lytxLogger.error(f"Failed to move file : {format(record)}",error_code="MOVE_FILES_FAILED")
                raise e
            # raise Exception("Exception while copying: %s" % e)
        sendMsgToJobStatus(getMsgJson("SUCCESS", 'Move files job completed for Tracking_ID: ' + TRACKING_ID, JOB_ID,
                                      sourceBucketName + '/' + sourceBucketSubFolders,
                                      targetBucketName + '/' + targetBucketSubFolders, filenames, DATASOURCE,
                                      TRACKING_ID))
        lytxLogger.info("move_stage_unprocessed_files completed from moveFilesFromUnprocessed ")

    except Exception as e:
        sendMsgToJobStatus(
            getMsgJson("FAILED", "Move files job failed with Error for Tracking_ID: " + TRACKING_ID + str(e), JOB_ID,
                       sourceBucketName + '/' + sourceBucketSubFolders, targetBucketName + '/' + targetBucketSubFolders,
                       filenames, DATASOURCE, TRACKING_ID))
        lytxLogger.error(f"Error occurred,{str(e)}",error_code="UNKNOWN_ERROR")
        raise Exception(f"Error while copying files for Datasource: {DATASOURCE} with error: {str(e)}")
        # raise e


def getMsgJson(STEP_STATUS, COMMENT, JOB_ID, SOURCE_DIR, TARGET_DIR, FILENAMES, DATASOURCE, TRACKING_ID):
    lytxLogger.info("sqs msgJson data",
                    metadata={"filenames": FILENAMES, "hash": hash_val, "source_bucket_name": SOURCE_DIR,
                              "target_bucket_name": TARGET_DIR, "step_name": STEP_NAME, "job_id": JOB_ID,
                              "comment": COMMENT, "datasource_name": DATASOURCE})
    msgJson = {
        "JOB_ID": JOB_ID,
        "DATASOURCE_NAME": DATASOURCE,
        "SOURCE": SOURCE_DIR,
        "TARGET": TARGET_DIR,
        "STEP_NAME": STEP_NAME,
        "FILENAMES": FILENAMES,
        "HASH": hash_val,
        "STEP_STATUS": STEP_STATUS,
        "DATE": dt.datetime.now().strftime("%Y-%m-%dT%H:%M:%SZ"),
        "COMMENT": COMMENT,
        "TRACKING_ID": TRACKING_ID
    }
    return json.dumps(msgJson)


def getQueueURL(queueName):
    """Retrieve the URL for the configured queue name"""
    q = SQS.get_queue_url(QueueName=queueName).get('QueueUrl')
    lytxLogger.debug("Queue URL is {}".format(q))
    return q


def sendMsgToJobStatus(msgJsonStr):
    try:
        lytxLogger.info("sendMsgToJobStatus: Recording msgJsonStr: {}".format(msgJsonStr))
        url = getQueueURL(QUEUE_NAME_JOB_STATUS)
        lytxLogger.debug("Got queue URL {}".format(url))
        unique1 = str(time.time()) + "_" + QUEUE_NAME_JOB_STATUS
        lytxLogger.debug("JobStatus MessageDeduplicationId {}".format(unique1))

        resp = SQS.send_message(QueueUrl=url, MessageBody=msgJsonStr, MessageGroupId="L1_GR1",
                                MessageDeduplicationId=unique1)
        lytxLogger.info("Send result: {}".format(resp))
    except Exception as e:
        raise Exception("Exception while sendMsgToJobStatus: %s" % e)


def populateParameter():
    try:
        ssm = boto3.client('ssm')
        global QUEUE_NAME_MOVE_FILES
        global QUEUE_NAME_JOB_STATUS
        global SNS_TOPIC_JOB_FAIL
        parameter = ssm.get_parameter(Name='/service/sqs/move-files', WithDecryption=False)
        QUEUE_NAME_MOVE_FILES = parameter['Parameter']['Value']
        parameter = ssm.get_parameter(Name='/service/sqs/job-status', WithDecryption=False)
        QUEUE_NAME_JOB_STATUS = parameter['Parameter']['Value']
        parameter = ssm.get_parameter(Name='/service/sns/glue/fail', WithDecryption=False)
        SNS_TOPIC_JOB_FAIL = parameter['Parameter']['Value']
        lytxLogger.debug(
            "inside populateParameter QUEUE_NAME_JOB_STATUS: {},QUEUE_NAME_MOVE_FILES: {},SNS_TOPIC_JOB_FAIL: {}".format(
                QUEUE_NAME_JOB_STATUS, QUEUE_NAME_MOVE_FILES, SNS_TOPIC_JOB_FAIL))
    except Exception as e:
        raise Exception("Exception while populating parameters: %s" % e)


def publish_message(sns_topic_arn, comment):
    """
    Publishes a message to a SNS topic.
    """
    sns_client = boto3.client('sns')
    sns_message = comment
    sns_subject = 'Warning!Alert : Move files failed after refined'
    try:

        response = sns_client.publish(
            TopicArn=sns_topic_arn,
            Message=sns_message,
            Subject=sns_subject,
        )['MessageId']

    except ClientError:
        lytxLogger.warn(f' Could not publish message to the topic.')
        raise
    else:
        lytxLogger.info("Published message to SNS ")
        # return response