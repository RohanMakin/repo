import uuid
import json
import boto3
import logging
import os
import time
import hashlib
import datetime as dt
from lytxlogger.lytx_logger import LytxLogger

# Set up logging to print only error from other python logging
logger = logging.getLogger()
logger.setLevel(logging.ERROR)

SQS = boto3.client("sqs")
# Queues
QUEUE_NAME_JOB_STATUS = ''
QUEUE_NAME_JOB_INVOKE = ''

# Msg common data
#DATASOURCE_NAME = 'GPS'
STEP_NAME = 'SAVE_RAW'
# below will populate by db data
JOB_ID_DB = "1"
# below will populate by db data
SOURCE_BUCKET_DB = ''
# below will populate by db data
TARGET_BUCKET_DB = ''
# below will populate by db data
IS_ACTIVE_DB = ''
SOURCE_FOR_OPTIMIZED_STEP = ''

targetBucketCompleteWithYrMmDd = ''
s3 = boto3.resource('s3')
clientname = boto3.client('s3')

# 3 parameters for RDS & SecreteStroe environment
database_name = ''
db_cluster_arn = ''
db_credentials_secrets_store_arn = ''

IS_FILES_AVAILABLE_TO_MOVE = "true"
SOURCE_FILE_EXT = 'avro'

# This is the Data API client that will be used in our examples below
rds_client = boto3.client('rds-data')
lytxLogger = LytxLogger.create("logger_" + __name__)
trackingId = str(uuid.uuid1())


def lambda_handler(event, context):
    lytxLogger.init_logger(getEnvName(context.function_name), "lambda", "lambda", context.function_name,
                           context.aws_request_id, trackingId)

    # get the config paramerter
    global ds_name
    
    if 'DATASOURCE_NAME' in event:
        ds_name = str(event["DATASOURCE_NAME"])
    else:
        lytxLogger.debug("Error Code : DATASOURCE_NAME not provided")
        return {"Error Code": "DATASOURCE_NAME not provided"}
    
    
    populateParameter()

    lytxLogger.debug(
        "inside lambda_handler QUEUE_NAME_JOB_INVOKE : {} , QUEUE_NAME_JOB_STATUS: {},database_name:{},db_cluster_arn:{},db_credentials_secrets_store_arn:{} ".format(
            QUEUE_NAME_JOB_INVOKE, QUEUE_NAME_JOB_STATUS, database_name, db_cluster_arn,
            db_credentials_secrets_store_arn))

    # CAll db to get job master data and populate global variables
    getMovedRawFilesData()
    
    if JOB_MOVED_RAW_FILES_ID_DB is None:
        return {"Error Code": "No record to process"}


    if JOB_MOVED_RAW_FILES_ID_DB is not None:
        print("Found unprocessed raw files entry for performing optimization")
        getJobDetailsData()
        getMasterData()

        sendMsgToJobStatus(
            getMsgJson(FILENAMES, "SUCCESS", "Already Completed move process, pending optimization getting triggered",
                       JOB_ID_DB, SOURCE_BUCKET_DB, TARGET_BUCKET_DB))
        lytxLogger.debug("JobStatus success sqs msg sent")

        sendMsgToJobInvoke(
            getMsgJson(FILENAMES, "SUCCESS", "Already Completed move process, pending optimization getting triggered",
                       JOB_ID_DB, SOURCE_BUCKET_DB, TARGET_BUCKET_DB))
        lytxLogger.debug("JobInvoke success sqs msg sent")

        update_success_to_job_moved_raw_files_table()
    else:
        print("No files pending in raw without optimization perfomed.")

    return "completed"


STEP_STATUS1 = ""


def getMsgJson(s3fileNameWithLastComma, STEP_STATUS, COMMENT, JOB_ID_DB, SOURCE_BUCKET_DB, TARGET_BUCKET_DB):
    HASH = ""
    global STEP_STATUS1
    lytxLogger.debug("STEP_STATUS:" + STEP_STATUS)

    if IS_FILES_AVAILABLE_TO_MOVE == "true":
        HASH = hashlib.md5(s3fileNameWithLastComma.encode()).hexdigest()
        STEP_STATUS1 = STEP_STATUS
        lytxLogger.debug("STEP_STATUS1 if:" + STEP_STATUS1)
    else:
        STEP_STATUS1 = "NO_FILES_TO_MOVE"
        COMMENT = "No files found to move"
        HASH = ""
        lytxLogger.debug("STEP_STATUS1 else:" + STEP_STATUS1)

    lytxLogger.info("sqs msgJson data", metadata={"filenames": s3fileNameWithLastComma, "hash": HASH,
                                                  "source_bucket_name": SOURCE_BUCKET_DB,
                                                  "targetBucketCompleteWithYrMmDd": SOURCE_FOR_OPTIMIZED_STEP,
                                                  "step_name": STEP_NAME, "job_id": JOB_ID_DB, "comment": COMMENT,
                                                  "datasource_name": DATASOURCE_NAME})
    msgJson = {
        "JOB_ID": JOB_ID_DB,
        "DATASOURCE_NAME": DATASOURCE_NAME,
        "SOURCE": SOURCE_BUCKET_DB,
        "TARGET": SOURCE_FOR_OPTIMIZED_STEP,
        "STEP_NAME": STEP_NAME,
        "FILENAMES": s3fileNameWithLastComma,
        "HASH": HASH,
        "STEP_STATUS": STEP_STATUS1,
        "DATE": dt.datetime.now().strftime("%Y-%m-%dT%H:%M:%SZ"),
        "COMMENT": COMMENT,
        "TRACKING_ID": trackingId
    }
    return json.dumps(msgJson)


def getQueueURL(queueName):
    """Retrieve the URL for the configured queue name"""
    q = SQS.get_queue_url(QueueName=queueName).get('QueueUrl')
    lytxLogger.debug("Queue URL is {}".format(q))
    return q


def sendMsgToJobStatus(msgJsonStr):
    try:
        lytxLogger.debug("sendMsgToJobStatus: Recording msgJsonStr: {}".format(msgJsonStr))
        url = getQueueURL(QUEUE_NAME_JOB_STATUS)
        lytxLogger.debug("Got queue URL {}".format(url))
        unique1 = str(time.time()) + "_" + QUEUE_NAME_JOB_STATUS
        lytxLogger.debug("JobStatus MessageDeduplicationId {}".format(unique1))

        resp = SQS.send_message(QueueUrl=url, MessageBody=msgJsonStr, MessageGroupId="L1_GR1",
                                MessageDeduplicationId=unique1)
        lytxLogger.debug("Send result: {}".format(resp))
    except Exception as e:
        raise Exception("Exception while sendMsgToJobStatus: %s" % e)


def sendMsgToJobInvoke(msgJsonStr):
    try:
        lytxLogger.debug("sendMsgToJobInvoke Recording msgJsonStr: {}".format(msgJsonStr))
        url = getQueueURL(QUEUE_NAME_JOB_INVOKE)
        lytxLogger.debug("Got queue URL {}".format(url))
        unique1 = str(time.time()) + "_" + QUEUE_NAME_JOB_INVOKE
        lytxLogger.debug("JobInvoke MessageDeduplicationId  {}".format(unique1))

        resp = SQS.send_message(QueueUrl=url, MessageBody=msgJsonStr, MessageGroupId="L1_GR2",
                                MessageDeduplicationId=unique1)
        lytxLogger.debug("Send result: {}".format(resp))
    except Exception as e:
        raise Exception("Exception while sendMsgToJobInvoke: %s" % e)


# --------------------------------------------------------------------------------
# Helper Functions
# --------------------------------------------------------------------------------

def execute_statement(sql, sql_parameters=[]):
    response = rds_client.execute_statement(
        secretArn=db_credentials_secrets_store_arn,
        database=database_name,
        resourceArn=db_cluster_arn,
        sql=sql,
        parameters=sql_parameters
    )
    return response


def update_success_to_job_moved_raw_files_table():
    lytxLogger.debug("updating success in table: admin_schema.job_moved_raw_files,  ID : {}".format(JOB_MOVED_RAW_FILES_ID_DB))

    sql = 'update admin_schema.job_moved_raw_files set "STATUS" = \'OPTIMIZATION_TRIGGERED\', "COMMENT" = \'Triggered optimization glue job successfully\' WHERE "ID"=:jmrfid'
    jmrfid = JOB_MOVED_RAW_FILES_ID_DB
    sql_parameters = [{'name': 'jmrfid', 'value': {'longValue': jmrfid}}]
    response = execute_statement(sql, sql_parameters)
    lytxLogger.debug(f"update response : {response}")

    lytxLogger.debug("Inserting record into history table admin_schema.job_moved_raw_files_history : {}".format(JOB_MOVED_RAW_FILES_ID_DB))
    sql = 'insert into admin_schema.job_moved_raw_files_history select * from admin_schema.job_moved_raw_files  WHERE "ID"=:jmrfid'
    jmrfid = JOB_MOVED_RAW_FILES_ID_DB
    sql_parameters = [{'name': 'jmrfid', 'value': {'longValue': jmrfid}}]
    response = execute_statement(sql, sql_parameters)
    lytxLogger.debug(f"insert response : {response}")

    lytxLogger.debug("Deleting record from table admin_schema.job_moved_raw_files id : {}".format(
        JOB_MOVED_RAW_FILES_ID_DB))
    sql = 'delete from admin_schema.job_moved_raw_files WHERE "ID"=:jmrfid'
    jmrfid = JOB_MOVED_RAW_FILES_ID_DB
    sql_parameters = [{'name': 'jmrfid', 'value': {'longValue': jmrfid}}]
    response = execute_statement(sql, sql_parameters)
    lytxLogger.debug(f"delete response : {response}")



def getMasterData():
    lytxLogger.debug('===== Parameterized query for job_master_data =====')
    sql = 'select "SOURCE_DIR","TARGET_DIR","IS_ACTIVE","STEP_ID" from admin_schema.job_master_data where "JOB_STEP"=\'SAVE_RAW\' AND "DATA_SOURCE"=:ds'
    ds = DATASOURCE_NAME
    sql_parameters = [{'name': 'ds', 'value': {'stringValue': f'{ds}'}}]
    response = execute_statement(sql, sql_parameters)

    rows = response['records']
    rcounter = 0
    ccounter = 0
    global SOURCE_BUCKET_DB
    global TARGET_BUCKET_DB
    global IS_ACTIVE_DB
    global JOB_ID_DB
    for row in rows:
        lytxLogger.debug("row:")
        rcounter = rcounter + 1
        for col in row:
            lytxLogger.debug("col:")
            ccounter = ccounter + 1

            lytxLogger.debug(col)
            if ccounter == 1 and rcounter == 1:
                SOURCE_BUCKET_DB = col['stringValue']
            if ccounter == 2 and rcounter == 1:
                TARGET_BUCKET_DB = col['stringValue']
            if ccounter == 3 and rcounter == 1:
                IS_ACTIVE_DB = col['stringValue']
            if ccounter == 4 and rcounter == 1:
                JOB_ID_DB = str(col['longValue'])

    lytxLogger.debug("SOURCE_BUCKET_DB:" + SOURCE_BUCKET_DB)
    lytxLogger.debug("TARGET_BUCKET_DB:" + TARGET_BUCKET_DB)
    lytxLogger.debug("IS_ACTIVE_DB:" + IS_ACTIVE_DB)
    lytxLogger.debug("JOB_ID_DB:" + JOB_ID_DB)
    lytxLogger.debug("db response['records']: {}".format(response['records']))


def getMovedRawFilesData():
    lytxLogger.debug('===== Parameterized query for job_master_data =====')
    sql = 'select "ID", "JOB_DETAILS_ID", "DATASOURCE_NAME" from admin_schema.job_moved_raw_files where "STATUS"=\'OPTIMIZATION_PENDING\' and "DATASOURCE_NAME"=:ds_name'
    sql_parameters = [{'name': 'ds_name', 'value': {'stringValue': ds_name}}]
    response = execute_statement(sql,sql_parameters)

    
    global JOB_MOVED_RAW_FILES_ID_DB
    global JOB_MOVED_RAW_FILES_JOB_DETAILS_ID_DB
    global JOB_MOVED_RAW_FILES_DATASOURCE_NAME_DB
    
    JOB_MOVED_RAW_FILES_ID_DB = None
    
    if len(response['records'])==0:
        return {"Error Code": "No Entry to process"}
    rows = response['records']
    rcounter = 0
    ccounter = 0

    for row in rows:
        lytxLogger.debug("row:")
        rcounter = rcounter + 1
        for col in row:
            lytxLogger.debug("col:")
            ccounter = ccounter + 1

            lytxLogger.debug(col)
            if ccounter == 1 and rcounter == 1:
                JOB_MOVED_RAW_FILES_ID_DB = col['longValue']
            if ccounter == 2 and rcounter == 1:
                JOB_MOVED_RAW_FILES_JOB_DETAILS_ID_DB = col['longValue']
            if ccounter == 3 and rcounter == 1:
                JOB_MOVED_RAW_FILES_DATASOURCE_NAME_DB = col['stringValue']
        break

    lytxLogger.debug("JOB_MOVED_RAW_FILES_ID_DB:" + str(JOB_MOVED_RAW_FILES_ID_DB))
    lytxLogger.debug("JOB_MOVED_RAW_FILES_JOB_DETAILS_ID_DB:" + str(JOB_MOVED_RAW_FILES_JOB_DETAILS_ID_DB))
    lytxLogger.debug("JOB_MOVED_RAW_FILES_DATASOURCE_NAME_DB:" + JOB_MOVED_RAW_FILES_DATASOURCE_NAME_DB)
    lytxLogger.debug("db response['records']: {}".format(response['records']))


def getJobDetailsData():
    lytxLogger.debug('===== Parameterized query for job_master_data =====')
    sql = 'select "ID", "JOB_ID", "DATASOURCE_NAME", "FILENAMES", "HASH", "SOURCE", "TARGET", "STEP_NAME", "STEP_STATUS", "DATE", "COMMENT" from admin_schema.job_details where "ID"=:jid'
    jid = JOB_MOVED_RAW_FILES_JOB_DETAILS_ID_DB
    sql_parameters = [{'name': 'jid', 'value': {'longValue': jid}}]
    response = execute_statement(sql, sql_parameters)
    
    rows = response['records']
    rcounter = 0
    ccounter = 0
    global DATASOURCE_NAME
    global FILENAMES
    global SOURCE_FOR_OPTIMIZED_STEP
    # global JOB_ID_DB
    # global HASH
    for row in rows:
        lytxLogger.debug("row:")
        rcounter = rcounter + 1
        for col in row:
            lytxLogger.debug("col:")
            ccounter = ccounter + 1

            lytxLogger.debug(col)
            if ccounter == 3 and rcounter == 1:
                DATASOURCE_NAME = col['stringValue']
            if ccounter == 4 and rcounter == 1:
                FILENAMES = col['stringValue']
            if ccounter == 7 and rcounter == 1:
                SOURCE_FOR_OPTIMIZED_STEP = col['stringValue']
        break

    lytxLogger.debug("DATASOURCE_NAME:" + str(DATASOURCE_NAME))
    lytxLogger.debug("FILENAMES:" + str(FILENAMES))
    lytxLogger.debug("SOURCE_FOR_OPTIMIZED_STEP:" + SOURCE_FOR_OPTIMIZED_STEP)
    lytxLogger.debug("db response['records']: {}".format(response['records']))


def getEnvName(resourceName):
    if '-dev-' in resourceName:
        return "dev"
    elif '-stg-' in resourceName:
        return "stg"
    elif '-prod-' in resourceName:
        return "prod"


# --------------------------------------------------------------------------------
# get all config props from parameter store
# --------------------------------------------------------------------------------
def populateParameter():
    ssm = boto3.client('ssm')
    global QUEUE_NAME_JOB_INVOKE
    global QUEUE_NAME_JOB_STATUS
    global database_name
    global db_cluster_arn
    global db_credentials_secrets_store_arn

    parameter = ssm.get_parameter(Name='/services/rds/aurora-postgresql/dp_admin/database', WithDecryption=False)
    database_name = parameter['Parameter']['Value']
    parameter = ssm.get_parameter(Name='/services/rds/aurora-postgresql/dp_admin/cluster_arn', WithDecryption=False)
    db_cluster_arn = parameter['Parameter']['Value']
    parameter = ssm.get_parameter(Name='/services/sm/rds/db_admin/arn', WithDecryption=False)
    db_credentials_secrets_store_arn = parameter['Parameter']['Value']
    parameter = ssm.get_parameter(Name='/service/sqs/glue-invoke', WithDecryption=False)
    QUEUE_NAME_JOB_INVOKE = parameter['Parameter']['Value']
    parameter = ssm.get_parameter(Name='/service/sqs/job-status', WithDecryption=False)
    QUEUE_NAME_JOB_STATUS = parameter['Parameter']['Value']
    lytxLogger.debug(
        "inside populateParameter QUEUE_NAME_JOB_INVOKE : {} , QUEUE_NAME_JOB_STATUS: {},database_name:{},db_cluster_arn:{},db_credentials_secrets_store_arn:{} ".format(
            QUEUE_NAME_JOB_INVOKE, QUEUE_NAME_JOB_STATUS, database_name, db_cluster_arn,
            db_credentials_secrets_store_arn))