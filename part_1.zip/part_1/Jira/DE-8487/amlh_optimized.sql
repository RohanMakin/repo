-- =============================================================================
-- OPTIMIZED AMLH (Account Marketing Lifecycle History) ETL Script
-- =============================================================================
-- Key Optimizations Applied:
--   1. Flattened nested subqueries into sequential CTEs/temp tables
--   2. Consolidated 20 delta temp tables into 1 single-pass calculation
--   3. Extracted journey path order values as integer columns (no string parsing)
--   4. Removed duplicate opportunity stage subquery
--   5. Added proper DISTKEY/SORTKEY for Redshift performance
--   6. Removed unnecessary DISTINCT keywords
--   7. Simplified nonlinear flag logic
--   8. Created reusable date period calculation pattern
-- =============================================================================

-- =============================================================================
-- STEP 0: Helper function for date period calculations (optional - run once)
-- =============================================================================
-- Uncomment if you want to use a date dimension approach instead of inline calcs
/*
CREATE TABLE IF NOT EXISTS act_mrkt_lifecycle.dim_date AS
SELECT 
    date_value::date AS date_key,
    CAST(DATE_TRUNC('week', date_value) + INTERVAL '6 days' AS date) AS end_of_week,
    LAST_DAY(date_value) AS end_of_month,
    CAST(DATEADD(day, -1, DATEADD(quarter, 1, DATE_TRUNC('quarter', date_value))) AS date) AS end_of_quarter,
    CAST(DATEADD(day, -1, DATEADD(year, 1, DATE_TRUNC('year', date_value))) AS date) AS end_of_year
FROM (
    SELECT DATEADD(day, seq, '2015-01-01'::date) AS date_value 
    FROM (SELECT ROW_NUMBER() OVER() - 1 AS seq FROM stl_scan LIMIT 5000)
)
WHERE date_value <= '2030-12-31';
*/

-- =============================================================================
-- STEP 1: Create base AMLH cleaned data with deduplication
-- =============================================================================
DROP TABLE IF EXISTS amlh_temp_base;
CREATE TEMPORARY TABLE amlh_temp_base DISTSTYLE KEY DISTKEY(account__c) AS
SELECT 
    amlh.*
FROM salesforce.account_marketing_lifecycle_history__c AS amlh
INNER JOIN (
    SELECT 
        amlh_raw.account__c,
        COALESCE(amlh_raw.recycle_counter__c, 0) AS recycle_counter__c,
        MAX(amlh_raw.created_date) AS max_created_date
    FROM salesforce.account_marketing_lifecycle_history__c AS amlh_raw
    INNER JOIN salesforce.account AS act 
        ON amlh_raw.account__c = act.id
    INNER JOIN salesforce.record_type AS rcd 
        ON act.record_type_id = rcd.id
        AND rcd.id IN ('012300000005VEYAA2', '0126R000001UknZQAS')
    WHERE amlh_raw.is_deleted = FALSE
        AND act.is_deleted = FALSE
        AND act.internal_test_account__c = FALSE
    GROUP BY 1, 2
) AS amlh_dedup
    ON amlh.account__c = amlh_dedup.account__c
    AND COALESCE(amlh.recycle_counter__c, 0) = amlh_dedup.recycle_counter__c
    AND amlh.created_date = amlh_dedup.max_created_date
WHERE amlh.is_deleted = FALSE;

RAISE INFO 'Step 1 complete: Base AMLH data created';

-- =============================================================================
-- STEP 2: Normalize timestamps and handle NULL dates with sentinel value
-- =============================================================================
DROP TABLE IF EXISTS amlh_temp_normalized;
CREATE TEMPORARY TABLE amlh_temp_normalized DISTSTYLE KEY DISTKEY(account__c) AS
SELECT
    account__c,
    COALESCE(recycle_counter__c, 0) AS recycle_counter__c,
    created_date,
    active_marketing_lifecycle_record__c,
    marketing_lifecycle_at_suspect__c,
    buying_stage_at_suspect__c,
    routing_reason__c,
    unqualified_reason__c,
    opportunity__c,
    name,
    -- Original timestamps (for later use)
    cold_account_date_stamp__c AS cold_account_date_stamp__c_orig,
    mea_date_stamp__c AS mea_date_stamp__c_orig,
    mqa_date_stamp__c AS mqa_date_stamp__c_orig,
    suspect_date_stamp__c AS suspect_date_stamp__c_orig,
    suspect_working_date_stamp__c AS suspect_working_date_stamp__c_orig,
    prospect_date_stamp__c AS prospect_date_stamp__c_orig,
    customer_date_stamp__c AS customer_date_stamp__c_orig,
    recycle_date_stamp__c AS recycle_date_stamp__c_orig,
    unqualified_date_stamp__c AS unqualified_date_stamp__c_orig,
    recycle_exp_date__c,
    -- Normalized timestamps with sentinel for NULLs (for ordering)
    -- Apply adjustments for same-day cold/mea and close suspect/mqa timestamps
    CASE 
        WHEN cold_account_date_stamp__c IS NULL THEN '2222-01-01 11:22:33.444'::timestamp
        WHEN CAST(cold_account_date_stamp__c AS date) = CAST(mea_date_stamp__c AS date) 
            THEN DATEADD(day, -1, cold_account_date_stamp__c)
        ELSE cold_account_date_stamp__c
    END AS cold_ts_normalized,
    COALESCE(mea_date_stamp__c, '2222-01-01 11:22:33.444'::timestamp) AS mea_ts_normalized,
    COALESCE(mqa_date_stamp__c, '2222-01-01 11:22:33.444'::timestamp) AS mqa_ts_normalized,
    CASE 
        WHEN suspect_date_stamp__c IS NULL THEN '2222-01-01 11:22:33.444'::timestamp
        WHEN DATEDIFF(minute, suspect_date_stamp__c, mqa_date_stamp__c) BETWEEN 0 AND 2 
            THEN DATEADD(minute, 2, suspect_date_stamp__c)
        ELSE suspect_date_stamp__c
    END AS suspect_ts_normalized,
    COALESCE(suspect_working_date_stamp__c, '2222-01-01 11:22:33.444'::timestamp) AS suspect_working_ts_normalized,
    COALESCE(prospect_date_stamp__c, '2222-01-01 11:22:33.444'::timestamp) AS prospect_ts_normalized,
    COALESCE(customer_date_stamp__c, '2222-01-01 11:22:33.444'::timestamp) AS customer_ts_normalized,
    COALESCE(recycle_date_stamp__c, '2222-01-01 11:22:33.444'::timestamp) AS recycle_ts_normalized,
    COALESCE(unqualified_date_stamp__c, '2222-01-01 11:22:33.444'::timestamp) AS unqualified_ts_normalized
FROM amlh_temp_base;

RAISE INFO 'Step 2 complete: Timestamps normalized';

-- =============================================================================
-- STEP 3: Calculate journey order for each lifecycle stage using UNPIVOT + ranking
-- =============================================================================
DROP TABLE IF EXISTS amlh_temp_journey_orders;
CREATE TEMPORARY TABLE amlh_temp_journey_orders DISTSTYLE KEY DISTKEY(account__c) AS
WITH unpivoted AS (
    SELECT 
        account__c,
        recycle_counter__c,
        created_date,
        lifecycle_stage,
        stage_timestamp,
        -- Only assign order if timestamp is not the sentinel value
        CASE 
            WHEN TRUNC(stage_timestamp) >= '2222-01-01' THEN 0
            ELSE ROW_NUMBER() OVER (
                PARTITION BY account__c, recycle_counter__c, created_date 
                ORDER BY stage_timestamp
            )
        END AS stage_order
    FROM amlh_temp_normalized
    UNPIVOT (
        stage_timestamp FOR lifecycle_stage IN (
            cold_ts_normalized AS 'cold',
            mea_ts_normalized AS 'mea',
            mqa_ts_normalized AS 'mqa',
            suspect_ts_normalized AS 'suspect',
            suspect_working_ts_normalized AS 'suspect_working',
            prospect_ts_normalized AS 'prospect',
            customer_ts_normalized AS 'customer',
            recycle_ts_normalized AS 'recycle',
            unqualified_ts_normalized AS 'unqualified'
        )
    )
)
SELECT 
    account__c,
    recycle_counter__c,
    created_date,
    MAX(CASE WHEN lifecycle_stage = 'cold' THEN NULLIF(stage_order, 0) END) AS cold_order,
    MAX(CASE WHEN lifecycle_stage = 'mea' THEN NULLIF(stage_order, 0) END) AS mea_order,
    MAX(CASE WHEN lifecycle_stage = 'mqa' THEN NULLIF(stage_order, 0) END) AS mqa_order,
    MAX(CASE WHEN lifecycle_stage = 'suspect' THEN NULLIF(stage_order, 0) END) AS suspect_order,
    MAX(CASE WHEN lifecycle_stage = 'suspect_working' THEN NULLIF(stage_order, 0) END) AS suspect_working_order,
    MAX(CASE WHEN lifecycle_stage = 'prospect' THEN NULLIF(stage_order, 0) END) AS prospect_order,
    MAX(CASE WHEN lifecycle_stage = 'customer' THEN NULLIF(stage_order, 0) END) AS customer_order,
    MAX(CASE WHEN lifecycle_stage = 'recycle' THEN NULLIF(stage_order, 0) END) AS recycle_order,
    MAX(CASE WHEN lifecycle_stage = 'unqualified' THEN NULLIF(stage_order, 0) END) AS unqualified_order,
    -- Journey length is the max non-zero order
    GREATEST(
        COALESCE(MAX(CASE WHEN lifecycle_stage = 'cold' THEN NULLIF(stage_order, 0) END), 0),
        COALESCE(MAX(CASE WHEN lifecycle_stage = 'mea' THEN NULLIF(stage_order, 0) END), 0),
        COALESCE(MAX(CASE WHEN lifecycle_stage = 'mqa' THEN NULLIF(stage_order, 0) END), 0),
        COALESCE(MAX(CASE WHEN lifecycle_stage = 'suspect' THEN NULLIF(stage_order, 0) END), 0),
        COALESCE(MAX(CASE WHEN lifecycle_stage = 'suspect_working' THEN NULLIF(stage_order, 0) END), 0),
        COALESCE(MAX(CASE WHEN lifecycle_stage = 'prospect' THEN NULLIF(stage_order, 0) END), 0),
        COALESCE(MAX(CASE WHEN lifecycle_stage = 'customer' THEN NULLIF(stage_order, 0) END), 0),
        COALESCE(MAX(CASE WHEN lifecycle_stage = 'recycle' THEN NULLIF(stage_order, 0) END), 0),
        COALESCE(MAX(CASE WHEN lifecycle_stage = 'unqualified' THEN NULLIF(stage_order, 0) END), 0)
    ) AS journey_length
FROM unpivoted
GROUP BY account__c, recycle_counter__c, created_date;

RAISE INFO 'Step 3 complete: Journey orders calculated';

-- =============================================================================
-- STEP 4: Determine nonlinear flag and reason (single pass)
-- =============================================================================
DROP TABLE IF EXISTS amlh_temp_journey_flags;
CREATE TEMPORARY TABLE amlh_temp_journey_flags DISTSTYLE KEY DISTKEY(account__c) AS
SELECT 
    jo.*,
    -- Nonlinear flag determination
    CASE
        WHEN cold_order IS NULL THEN 'Non-Linear'
        WHEN mea_order = 1 OR mqa_order = 1 OR suspect_order = 1 
             OR suspect_working_order = 1 OR prospect_order = 1 
             OR customer_order = 1 OR recycle_order = 1 OR unqualified_order = 1 THEN 'Non-Linear'
        WHEN prospect_order = cold_order + 1 THEN 'Non-Linear'
        WHEN recycle_order = cold_order + 1 AND journey_length <> 2 THEN 'Non-Linear'
        WHEN unqualified_order = cold_order + 1 AND journey_length <> 2 THEN 'Non-Linear'
        WHEN customer_order = cold_order + 1 AND journey_length <> 2 THEN 'Non-Linear'
        WHEN suspect_order = recycle_order + 1 THEN 'Non-Linear'
        WHEN suspect_order = unqualified_order + 1 THEN 'Non-Linear'
        WHEN customer_order = unqualified_order + 1 THEN 'Non-Linear'
        WHEN unqualified_order = customer_order + 1 THEN 'Non-Linear'
        WHEN suspect_order > prospect_order THEN 'Non-Linear'
        WHEN recycle_order < journey_length THEN 'Non-Linear'
        WHEN unqualified_order < journey_length THEN 'Non-Linear'
        WHEN customer_order < journey_length THEN 'Non-Linear'
        WHEN mea_order > mqa_order THEN 'Non-Linear'
        WHEN suspect_order IS NULL AND prospect_order IS NOT NULL THEN 'Non-Linear'
        WHEN mqa_order IS NOT NULL AND mea_order IS NULL THEN 'Non-Linear'
        ELSE 'Linear'
    END AS nonlinear_flag,
    -- Nonlinear reason determination
    CASE
        WHEN cold_order IS NULL THEN 'cold_order IS NULL'
        WHEN mea_order = 1 THEN 'mea_order = 1'
        WHEN mqa_order = 1 THEN 'mqa_order = 1'
        WHEN suspect_order = 1 THEN 'suspect_order = 1'
        WHEN suspect_working_order = 1 THEN 'suspect_working_order = 1'
        WHEN prospect_order = 1 THEN 'prospect_order = 1'
        WHEN customer_order = 1 THEN 'customer_order = 1'
        WHEN recycle_order = 1 THEN 'recycle_order = 1'
        WHEN unqualified_order = 1 THEN 'unqualified_order = 1'
        WHEN prospect_order = cold_order + 1 THEN 'prospect_order = cold_order + 1'
        WHEN recycle_order = cold_order + 1 AND journey_length <> 2 THEN 'cold, recycle, more'
        WHEN unqualified_order = cold_order + 1 AND journey_length <> 2 THEN 'cold, unqualified, more'
        WHEN customer_order = cold_order + 1 AND journey_length <> 2 THEN 'cold, customer, more'
        WHEN suspect_order = recycle_order + 1 THEN 'suspect_order = recycled_order + 1'
        WHEN suspect_order = unqualified_order + 1 THEN 'suspect_order = unqualified_order + 1'
        WHEN customer_order = unqualified_order + 1 THEN 'customer_order = unqualified_order + 1'
        WHEN unqualified_order = customer_order + 1 THEN 'unqualified_order = customer_order + 1'
        WHEN recycle_order < journey_length THEN 'recycled_order < journey_length'
        WHEN unqualified_order < journey_length THEN 'unqualified_order < journey_length'
        WHEN customer_order < journey_length THEN 'customer_order < journey_length'
        WHEN mea_order > mqa_order THEN 'mea_order > mqa_order'
        WHEN suspect_order IS NULL AND prospect_order IS NOT NULL THEN 'suspect_order IS NULL & prospect_order IS NOT NULL'
        WHEN mqa_order IS NOT NULL AND mea_order IS NULL THEN 'mqa_order IS NOT NULL & mea_order IS NULL'
        ELSE 'Linear'
    END AS nonlinear_reason,
    -- Build journey path strings
    'COLD ' || COALESCE(cold_order, 0)::varchar(4) || ' --> ' ||
    'MEA ' || COALESCE(mea_order, 0)::varchar(4) || ' --> ' ||
    'MQA ' || COALESCE(mqa_order, 0)::varchar(4) || ' --> ' ||
    'SUS ' || COALESCE(suspect_order, 0)::varchar(4) || ' --> ' ||
    'S_W ' || COALESCE(suspect_working_order, 0)::varchar(4) || ' --> ' ||
    'PROS ' || COALESCE(prospect_order, 0)::varchar(4) || ' --> ' ||
    'CUST ' || COALESCE(customer_order, 0)::varchar(4) || ' --> ' ||
    'REC ' || COALESCE(recycle_order, 0)::varchar(4) || ' --> ' ||
    'UNQ ' || COALESCE(unqualified_order, 0)::varchar(4) AS act_journey_path,
    
    COALESCE(cold_order, 0)::varchar(4) || ' --> ' ||
    COALESCE(mea_order, 0)::varchar(4) || ' --> ' ||
    COALESCE(mqa_order, 0)::varchar(4) || ' --> ' ||
    COALESCE(suspect_order, 0)::varchar(4) || ' --> ' ||
    COALESCE(suspect_working_order, 0)::varchar(4) || ' --> ' ||
    COALESCE(prospect_order, 0)::varchar(4) || ' --> ' ||
    COALESCE(customer_order, 0)::varchar(4) || ' --> ' ||
    COALESCE(recycle_order, 0)::varchar(4) || ' --> ' ||
    COALESCE(unqualified_order, 0)::varchar(4) AS act_journey_path_id
FROM amlh_temp_journey_orders jo;

RAISE INFO 'Step 4 complete: Journey flags calculated';

-- =============================================================================
-- STEP 5: Build the main materialized view with all account and journey data
-- =============================================================================
DROP MATERIALIZED VIEW IF EXISTS act_mrkt_lifecycle.AMLH_TEMP_MV_1;
CREATE MATERIALIZED VIEW act_mrkt_lifecycle.AMLH_TEMP_MV_1 
DISTSTYLE KEY DISTKEY(ACT_ID) 
SORTKEY(ACT_ID, AMLH_RECYCLE_COUNTER__C)
AS
SELECT
    -- Account Info
    act.ID AS ACT_ID,
    act.IS_DELETED AS ACT_IS_DELETED,
    act.NAME AS ACT_NAME,
    usr.NAME AS ACT_OWNER,
    usr_role.NAME AS ACT_OWNER_ROLE,
    usro.NAME AS ACT_OPENER,
    act.CREATED_DATE AS ACT_CREATED_DATE,
    act.RECORD_TYPE_ID AS ACT_RECORD_TYPE_ID,
    rcd.NAME AS ACT_RECORD_TYPE_ID_NAME,
    act.MARKETING_LIFECYCLE_AT_SUSPECT__C AS ACT_MARKETING_LIFECYCLE_AT_SUSPECT__C,
    act.BUYING_STAGE_AT_SUSPECT__C AS ACT_BUYING_STAGE_AT_SUSPECT__C,
    act.MARKETING_LIFECYCLE__C AS ACT_MARKETING_LIFECYCLE__C,
    act.BUSINESS_UNIT_2020__C AS ACT_BUSINESS_UNIT_2020__C,
    act.BUSINESS_UNIT_DIVISION__C AS ACT_BUSINESS_UNIT_DIVISION__C,
    act.MARKET__C AS ACT_MARKET__C,
    act.FLEET_SIZE__C AS ACT_FLEET_SIZE__C,
    act.MARKET_SEGMENT__C AS ACT_MARKET_SEGMENT__C,
    CASE 
        WHEN act.MARKET_SEGMENT__C IN ('Trucking', 'Local') THEN 'Trucking and Local' 
        WHEN act.MARKET_SEGMENT__C IN ('NA') OR act.MARKET_SEGMENT__C IS NULL THEN 'Not Categorized' 
        ELSE act.MARKET_SEGMENT__C 
    END AS ACT_MARKET_SEGMENT__C_GROUP,
    act.INDUSTRY AS ACT_INDUSTRY,
    act.INDUSTRY_DB__C AS ACT_INDUSTRY_DB__C,
    act.INDUSTRY_SECTOR__C AS ACT_INDUSTRY_SECTOR__C,
    act.TERRITORY__C AS ACT_TERRITORY__C,
    act.GEOGRAPHIC_REGION__C AS ACT_GEOGRAPHIC_REGION__C,
    act.STATE_DB__C AS ACT_STATE_DB__C,
    act.ACCOUNT_PROFILE_FIT6SENSE__C AS ACT_ACCOUNT_PROFILE_FIT6SENSE__C,
    act.ACCOUNT_PROFILE_SCORE6SENSE__C AS ACT_ACCOUNT_PROFILE_SCORE6SENSE__C,
    act.INTERNAL_TEST_ACCOUNT__C AS ACT_INTERNAL_TEST_ACCOUNT__C,
    act.ROUTING_REASON__C AS ACT_ROUTING_REASON__C,
    act.MIGRATION_RETURN_TO_MARKETING_REASON__C AS ACT_MIGRATION_RETURN_TO_MARKETING_REASON__C,
    act.STATUS__C AS ACT_STATUS__C,
    act.BUYER_TYPE__C AS ACT_BUYER_TYPE__C,
    act.CAMPAIGN_TEXT__C AS ACT_CAMPAIGN_TEXT__C,
    act.BILLING_MODEL__C AS ACT_BILLING_MODEL__C,
    act.REGION__C AS ACT_REGION__C,
    act.BILLING_STATE AS ACT_BILLING_STATE,
    -- Account Status Group
    CASE
        WHEN act.STATUS__C IN ('Data Review', 'Initial Trial', 'Initial Trial Pending', 'Prospect', 'Suspect') THEN 'Active with Sales'
        WHEN act.STATUS__C IN ('Client', 'Pending Client', 'Pending Client - Contract Signed') THEN 'Client'
        WHEN act.STATUS__C IN ('Prospect Nuture', 'Recycle', 'Suspect Nurture', 'Suspect Nuture') THEN 'Marketing Engagement'
        WHEN act.STATUS__C IN ('Active', 'Inactive', 'Industry Org', 'Non-Contractual', 'Other') THEN 'Other/NA'
        WHEN act.STATUS__C IN ('Pending Forward Consent', 'Referred to Partner') THEN 'Referred to Partner'
        WHEN act.STATUS__C IN ('SERVICE SUSPENDED', 'SERVICE TERMINATED', 'Terminated') THEN 'Service Terminated'
        WHEN act.STATUS__C IN ('DOA', 'Duplicate', 'Duplicate - 6Sense', 'Out of Business', 'Unqualified') THEN 'Unqualified'
    END AS ACT_STATUS_GROUP,
    act.UNQUALIFIED_REASON__C AS ACT_UNQUALIFIED_REASON__C,
    
    -- Account Journey Path (from pre-calculated temp tables)
    norm.name AS AMLH_NAME,
    norm.account__c AS AMLH_ACCOUNT__C,
    norm.recycle_counter__c AS AMLH_RECYCLE_COUNTER__C,
    norm.created_date AS AMLH_CREATED_DATE,
    norm.active_marketing_lifecycle_record__c AS AMLH_ACTIVE_MARKETING_LIFECYCLE_RECORD__C,
    norm.marketing_lifecycle_at_suspect__c AS AMLH_MARKETING_LIFECYCLE_AT_SUSPECT__C,
    norm.buying_stage_at_suspect__c AS AMLH_BUYING_STAGE_AT_SUSPECT__C,
    norm.routing_reason__c AS AMLH_ROUTING_REASON__C,
    norm.unqualified_reason__c AS AMLH_UNQUALIFIED_REASON__C,
    norm.opportunity__c AS AMLH_OPPORTUNITY__C,
    jf.act_journey_path AS AMLH_ACT_JOURNEY_PATH,
    jf.journey_length AS AMLH_ACT_JOURNEY_PATH_CNT,
    jf.act_journey_path_id AS AMLH_ACT_JOURNEY_PATH_ID,
    jf.nonlinear_flag AS AMLH_ACCOUNT_JOURNEY_PATH_LIFECYCLE_NONLINEAR_FLAG,
    jf.nonlinear_reason AS AMLH_ACCOUNT_JOURNEY_PATH_LIFECYCLE_NONLINEAR_FLAG_REASON,
    
    -- Journey order values (stored as integers for efficient querying)
    jf.cold_order AS AMLH_COLD_ORDER,
    jf.mea_order AS AMLH_MEA_ORDER,
    jf.mqa_order AS AMLH_MQA_ORDER,
    jf.suspect_order AS AMLH_SUSPECT_ORDER,
    jf.suspect_working_order AS AMLH_SUSPECT_WORKING_ORDER,
    jf.prospect_order AS AMLH_PROSPECT_ORDER,
    jf.customer_order AS AMLH_CUSTOMER_ORDER,
    jf.recycle_order AS AMLH_RECYCLE_ORDER,
    jf.unqualified_order AS AMLH_UNQUALIFIED_ORDER,
    
    -- Lifecycle Stage Dates (from account)
    act.COLD_ACCOUNT_DATE_STAMP__C AS ACT_COLD_ACCOUNT_DATE_STAMP__C,
    CAST(act.COLD_ACCOUNT_DATE_STAMP__C AS date) AS ACT_COLD_ACCOUNT_DATE_STAMP__C_CAST,
    act.MEA_DATE_STAMP__C AS ACT_MEA_DATE_STAMP__C,
    CAST(act.MEA_DATE_STAMP__C AS date) AS ACT_MEA_DATE_STAMP__C_CAST,
    act.MQA_DATE_STAMP__C AS ACT_MQA_DATE_STAMP__C,
    CAST(act.MQA_DATE_STAMP__C AS date) AS ACT_MQA_DATE_STAMP__C_CAST,
    act.SUSPECT_DATE_STAMP__C AS ACT_SUSPECT_DATE_STAMP__C,
    CAST(act.SUSPECT_DATE_STAMP__C AS date) AS ACT_SUSPECT_DATE_STAMP__C_CAST,
    act.SUSPECT_WORKING_DATE_STAMP__C AS ACT_SUSPECT_WORKING_DATE_STAMP__C,
    CAST(act.SUSPECT_WORKING_DATE_STAMP__C AS date) AS ACT_SUSPECT_WORKING_DATE_STAMP__C_CAST,
    act.PROSPECT_DATE_STAMP__C AS ACT_PROSPECT_DATE_STAMP__C,
    CAST(act.PROSPECT_DATE_STAMP__C AS date) AS ACT_PROSPECT_DATE_STAMP__C_CAST,
    act.CUSTOMER_DATE_STAMP__C AS ACT_CUSTOMER_DATE_STAMP__C,
    CAST(act.CUSTOMER_DATE_STAMP__C AS date) AS ACT_CUSTOMER_DATE_STAMP__C_CAST,
    act.RECYCLED_DATE_STAMP__C AS ACT_RECYCLED_DATE_STAMP__C,
    CAST(act.RECYCLED_DATE_STAMP__C AS date) AS ACT_RECYCLED_DATE_STAMP__C_CAST,
    act.UNQUALIFIED_DATE_STAMP__C AS ACT_UNQUALIFIED_DATE_STAMP__C,
    CAST(act.UNQUALIFIED_DATE_STAMP__C AS date) AS ACT_UNQUALIFIED_DATE_STAMP__C_CAST,
    
    -- Lifecycle Stage Dates (from AMLH record)
    norm.cold_account_date_stamp__c_orig AS AMLH_COLD_ACCOUNT_DATE_STAMP__C,
    CAST(norm.cold_account_date_stamp__c_orig AS date) AS AMLH_COLD_ACCOUNT_DATE_STAMP__C_CAST,
    CAST(DATE_TRUNC('week', norm.cold_account_date_stamp__c_orig) + INTERVAL '6 days' AS date) AS AMLH_COLD_ACCOUNT_DATE_EOW,
    LAST_DAY(norm.cold_account_date_stamp__c_orig) AS AMLH_COLD_ACCOUNT_DATE_EOM,
    CAST(DATEADD(day, -1, DATEADD(quarter, 1, DATE_TRUNC('quarter', norm.cold_account_date_stamp__c_orig))) AS date) AS AMLH_COLD_ACCOUNT_DATE_EOQ,
    CAST(DATEADD(day, -1, DATEADD(year, 1, DATE_TRUNC('year', norm.cold_account_date_stamp__c_orig))) AS date) AS AMLH_COLD_ACCOUNT_DATE_EOY,
    
    norm.mea_date_stamp__c_orig AS AMLH_MEA_DATE_STAMP__C,
    CAST(norm.mea_date_stamp__c_orig AS date) AS AMLH_MEA_DATE_STAMP__C_CAST,
    CAST(DATE_TRUNC('week', norm.mea_date_stamp__c_orig) + INTERVAL '6 days' AS date) AS AMLH_MEA_DATE_EOW,
    LAST_DAY(norm.mea_date_stamp__c_orig) AS AMLH_MEA_DATE_EOM,
    CAST(DATEADD(day, -1, DATEADD(quarter, 1, DATE_TRUNC('quarter', norm.mea_date_stamp__c_orig))) AS date) AS AMLH_MEA_DATE_EOQ,
    CAST(DATEADD(day, -1, DATEADD(year, 1, DATE_TRUNC('year', norm.mea_date_stamp__c_orig))) AS date) AS AMLH_MEA_DATE_EOY,
    
    norm.mqa_date_stamp__c_orig AS AMLH_MQA_DATE_STAMP__C,
    CAST(norm.mqa_date_stamp__c_orig AS date) AS AMLH_MQA_DATE_STAMP__C_CAST,
    CAST(DATE_TRUNC('week', norm.mqa_date_stamp__c_orig) + INTERVAL '6 days' AS date) AS AMLH_MQA_DATE_EOW,
    LAST_DAY(norm.mqa_date_stamp__c_orig) AS AMLH_MQA_DATE_EOM,
    CAST(DATEADD(day, -1, DATEADD(quarter, 1, DATE_TRUNC('quarter', norm.mqa_date_stamp__c_orig))) AS date) AS AMLH_MQA_DATE_EOQ,
    CAST(DATEADD(day, -1, DATEADD(year, 1, DATE_TRUNC('year', norm.mqa_date_stamp__c_orig))) AS date) AS AMLH_MQA_DATE_EOY,
    
    norm.suspect_date_stamp__c_orig AS AMLH_SUSPECT_DATE_STAMP__C,
    CAST(norm.suspect_date_stamp__c_orig AS date) AS AMLH_SUSPECT_DATE_STAMP__C_CAST,
    CAST(DATE_TRUNC('week', norm.suspect_date_stamp__c_orig) + INTERVAL '6 days' AS date) AS AMLH_SUSPECT_DATE_EOW,
    LAST_DAY(norm.suspect_date_stamp__c_orig) AS AMLH_SUSPECT_DATE_EOM,
    CAST(DATEADD(day, -1, DATEADD(quarter, 1, DATE_TRUNC('quarter', norm.suspect_date_stamp__c_orig))) AS date) AS AMLH_SUSPECT_DATE_EOQ,
    CAST(DATEADD(day, -1, DATEADD(year, 1, DATE_TRUNC('year', norm.suspect_date_stamp__c_orig))) AS date) AS AMLH_SUSPECT_DATE_EOY,
    
    norm.suspect_working_date_stamp__c_orig AS AMLH_SUSPECT_WORKING_DATE_STAMP__C,
    CAST(norm.suspect_working_date_stamp__c_orig AS date) AS AMLH_SUSPECT_WORKING_DATE_STAMP__C_CAST,
    CAST(DATE_TRUNC('week', norm.suspect_working_date_stamp__c_orig) + INTERVAL '6 days' AS date) AS AMLH_SUSPECT_WORKING_DATE_EOW,
    LAST_DAY(norm.suspect_working_date_stamp__c_orig) AS AMLH_SUSPECT_WORKING_DATE_EOM,
    CAST(DATEADD(day, -1, DATEADD(quarter, 1, DATE_TRUNC('quarter', norm.suspect_working_date_stamp__c_orig))) AS date) AS AMLH_SUSPECT_WORKING_DATE_EOQ,
    CAST(DATEADD(day, -1, DATEADD(year, 1, DATE_TRUNC('year', norm.suspect_working_date_stamp__c_orig))) AS date) AS AMLH_SUSPECT_WORKING_DATE_EOY,
    
    norm.prospect_date_stamp__c_orig AS AMLH_PROSPECT_DATE_STAMP__C,
    CAST(norm.prospect_date_stamp__c_orig AS date) AS AMLH_PROSPECT_DATE_STAMP__C_CAST,
    CAST(DATE_TRUNC('week', norm.prospect_date_stamp__c_orig) + INTERVAL '6 days' AS date) AS AMLH_PROSPECT_DATE_EOW,
    LAST_DAY(norm.prospect_date_stamp__c_orig) AS AMLH_PROSPECT_DATE_EOM,
    CAST(DATEADD(day, -1, DATEADD(quarter, 1, DATE_TRUNC('quarter', norm.prospect_date_stamp__c_orig))) AS date) AS AMLH_PROSPECT_DATE_EOQ,
    CAST(DATEADD(day, -1, DATEADD(year, 1, DATE_TRUNC('year', norm.prospect_date_stamp__c_orig))) AS date) AS AMLH_PROSPECT_DATE_EOY,
    
    norm.customer_date_stamp__c_orig AS AMLH_CUSTOMER_DATE_STAMP__C,
    CAST(norm.customer_date_stamp__c_orig AS date) AS AMLH_CUSTOMER_DATE_STAMP__C_CAST,
    CAST(DATE_TRUNC('week', norm.customer_date_stamp__c_orig) + INTERVAL '6 days' AS date) AS AMLH_CUSTOMER_DATE_EOW,
    LAST_DAY(norm.customer_date_stamp__c_orig) AS AMLH_CUSTOMER_DATE_EOM,
    CAST(DATEADD(day, -1, DATEADD(quarter, 1, DATE_TRUNC('quarter', norm.customer_date_stamp__c_orig))) AS date) AS AMLH_CUSTOMER_DATE_EOQ,
    CAST(DATEADD(day, -1, DATEADD(year, 1, DATE_TRUNC('year', norm.customer_date_stamp__c_orig))) AS date) AS AMLH_CUSTOMER_DATE_EOY,
    
    norm.recycle_date_stamp__c_orig AS AMLH_RECYCLED_DATE_STAMP__C,
    CAST(norm.recycle_date_stamp__c_orig AS date) AS AMLH_RECYCLED_DATE_STAMP__C_CAST,
    CAST(DATE_TRUNC('week', norm.recycle_date_stamp__c_orig) + INTERVAL '6 days' AS date) AS AMLH_RECYCLED_DATE_EOW,
    LAST_DAY(norm.recycle_date_stamp__c_orig) AS AMLH_RECYCLED_DATE_EOM,
    CAST(DATEADD(day, -1, DATEADD(quarter, 1, DATE_TRUNC('quarter', norm.recycle_date_stamp__c_orig))) AS date) AS AMLH_RECYCLED_DATE_EOQ,
    CAST(DATEADD(day, -1, DATEADD(year, 1, DATE_TRUNC('year', norm.recycle_date_stamp__c_orig))) AS date) AS AMLH_RECYCLED_DATE_EOY,
    
    norm.unqualified_date_stamp__c_orig AS AMLH_UNQUALIFIED_DATE_STAMP__C,
    CAST(norm.unqualified_date_stamp__c_orig AS date) AS AMLH_UNQUALIFIED_DATE_STAMP__C_CAST,
    CAST(DATE_TRUNC('week', norm.unqualified_date_stamp__c_orig) + INTERVAL '6 days' AS date) AS AMLH_UNQUALIFIED_DATE_EOW,
    LAST_DAY(norm.unqualified_date_stamp__c_orig) AS AMLH_UNQUALIFIED_DATE_EOM,
    CAST(DATEADD(day, -1, DATEADD(quarter, 1, DATE_TRUNC('quarter', norm.unqualified_date_stamp__c_orig))) AS date) AS AMLH_UNQUALIFIED_DATE_EOQ,
    CAST(DATEADD(day, -1, DATEADD(year, 1, DATE_TRUNC('year', norm.unqualified_date_stamp__c_orig))) AS date) AS AMLH_UNQUALIFIED_DATE_EOY,
    
    norm.recycle_exp_date__c AS AMLH_RECYCLE_EXP_DATE__C,
    CAST(norm.recycle_exp_date__c AS date) AS AMLH_RECYCLE_EXP_DATE__C_CAST,
    CAST(DATE_TRUNC('week', norm.recycle_exp_date__c) + INTERVAL '6 days' AS date) AS AMLH_RECYCLE_EXP_DATE__C_EOW,
    LAST_DAY(norm.recycle_exp_date__c) AS AMLH_RECYCLE_EXP_DATE__C_EOM,
    CAST(DATEADD(day, -1, DATEADD(quarter, 1, DATE_TRUNC('quarter', norm.recycle_exp_date__c))) AS date) AS AMLH_RECYCLE_EXP_DATE__C_EOQ,
    CAST(DATEADD(day, -1, DATEADD(year, 1, DATE_TRUNC('year', norm.recycle_exp_date__c))) AS date) AS AMLH_RECYCLE_EXP_DATE__C_EOY,
    
    -- Effective Date (Customer date or sentinel)
    CASE WHEN norm.customer_date_stamp__c_orig IS NULL THEN 'Null AMLH Customer Date' ELSE 'Has AMLH Customer Date' END AS AMLH_EFFECTIVE_TYPE,
    COALESCE(norm.customer_date_stamp__c_orig, '2222-01-01'::timestamp) AS AMLH_EFFECTIVE_DATE_STAMP__C,
    CAST(COALESCE(norm.customer_date_stamp__c_orig, '2222-01-01'::timestamp) AS date) AS AMLH_EFFECTIVE_DATE_STAMP__C_CAST,
    CAST(DATE_TRUNC('week', COALESCE(norm.customer_date_stamp__c_orig, '2222-01-01'::timestamp)) + INTERVAL '6 days' AS date) AS AMLH_EFFECTIVE_DATE_EOW,
    LAST_DAY(COALESCE(norm.customer_date_stamp__c_orig, '2222-01-01'::timestamp)) AS AMLH_EFFECTIVE_DATE_EOM,
    CAST(DATEADD(day, -1, DATEADD(quarter, 1, DATE_TRUNC('quarter', COALESCE(norm.customer_date_stamp__c_orig, '2222-01-01'::timestamp)))) AS date) AS AMLH_EFFECTIVE_DATE_EOQ,
    CAST(DATEADD(day, -1, DATEADD(year, 1, DATE_TRUNC('year', COALESCE(norm.customer_date_stamp__c_orig, '2222-01-01'::timestamp)))) AS date) AS AMLH_EFFECTIVE_DATE_EOY,
    
    -- Lifecycle Stage Flags
    CASE WHEN norm.recycle_date_stamp__c_orig IS NOT NULL THEN 'Recycled' ELSE 'New' END AS AMLH_RECYCLED_VS_NEW_FLAG,
    CASE WHEN norm.marketing_lifecycle_at_suspect__c IS NOT NULL THEN 1 ELSE 0 END AS AMLH_FLAG_HAS_MARKETING_LIFECYCLE_AT_SUSPECT__C,
    CASE WHEN norm.cold_account_date_stamp__c_orig IS NOT NULL THEN 1 ELSE 0 END AS AMLH_ACCOUNT_LIFECYCLE_COLD_FLAG,
    CASE WHEN norm.mea_date_stamp__c_orig IS NOT NULL THEN 1 ELSE 0 END AS AMLH_ACCOUNT_LIFECYCLE_MEA_FLAG,
    CASE WHEN norm.mqa_date_stamp__c_orig IS NOT NULL THEN 1 ELSE 0 END AS AMLH_ACCOUNT_LIFECYCLE_MQA_FLAG,
    CASE WHEN norm.suspect_date_stamp__c_orig IS NOT NULL THEN 1 ELSE 0 END AS AMLH_ACCOUNT_LIFECYCLE_SUSPECT_FLAG,
    CASE WHEN norm.suspect_working_date_stamp__c_orig IS NOT NULL THEN 1 ELSE 0 END AS AMLH_ACCOUNT_LIFECYCLE_SUSPECT_WORKING_FLAG,
    CASE WHEN norm.prospect_date_stamp__c_orig IS NOT NULL THEN 1 ELSE 0 END AS AMLH_ACCOUNT_LIFECYCLE_PROSPECT_FLAG,
    CASE WHEN norm.customer_date_stamp__c_orig IS NOT NULL THEN 1 ELSE 0 END AS AMLH_ACCOUNT_LIFECYCLE_CUSTOMER_FLAG,
    CASE WHEN norm.recycle_date_stamp__c_orig IS NOT NULL THEN 1 ELSE 0 END AS AMLH_ACCOUNT_LIFECYCLE_RECYCLED_FLAG,
    CASE WHEN norm.unqualified_date_stamp__c_orig IS NOT NULL THEN 1 ELSE 0 END AS AMLH_ACCOUNT_LIFECYCLE_UNQUALIFIED_FLAG,
    CASE WHEN DATEDIFF(minute, norm.suspect_date_stamp__c_orig, norm.mqa_date_stamp__c_orig) BETWEEN 0 AND 2 THEN 1 ELSE 0 END AS AMLH_ACCOUNT_LIFECYCLE_SUSPECT_MQA_TIMESTAMP_FLAG,
    
    -- Flag to check eligibility
    CASE
        WHEN norm.marketing_lifecycle_at_suspect__c IS NULL THEN 'Not Eligible: No Lifecycle'
        WHEN (
            CASE
                WHEN norm.marketing_lifecycle_at_suspect__c = 'Cold Account' THEN norm.cold_account_date_stamp__c_orig
                WHEN norm.marketing_lifecycle_at_suspect__c = 'MEA' THEN norm.mea_date_stamp__c_orig
                WHEN norm.marketing_lifecycle_at_suspect__c = 'MQA' THEN norm.mqa_date_stamp__c_orig
                WHEN norm.marketing_lifecycle_at_suspect__c = 'Suspect Working' THEN norm.suspect_working_date_stamp__c_orig
                WHEN norm.marketing_lifecycle_at_suspect__c = 'Recycled' THEN norm.recycle_date_stamp__c_orig
                WHEN norm.marketing_lifecycle_at_suspect__c = 'Unqualified' THEN norm.unqualified_date_stamp__c_orig
            END
        ) > norm.suspect_date_stamp__c_orig THEN 'Not Eligible: Lifecycle > Suspect Date'
        WHEN norm.marketing_lifecycle_at_suspect__c IS NOT NULL AND norm.suspect_date_stamp__c_orig IS NULL THEN 'Eligible: No Suspect Date'
        WHEN norm.marketing_lifecycle_at_suspect__c IS NOT NULL AND norm.suspect_date_stamp__c_orig IS NOT NULL THEN 'Eligible: Has Suspect Date'
        ELSE 'Other'
    END AS AMLH_FLAG_TO_CHECK,
    
    -- Parent Account Info
    CASE WHEN act.PARENT_ID IS NULL THEN 0 ELSE 1 END AS ACT_HAS_PARENT_ACT_FLAG,
    CASE WHEN act.PARENT_ID = '000000000000000AAA' THEN 1 ELSE 0 END AS ACT_PARENT_ACT_FLAG,
    act.PARENT_ID AS ACT_PARENT_ID,
    parent_act.IS_DELETED AS PARENT_ACT_IS_DELETED,
    parent_act.NAME AS PARENT_ACT_NAME,
    parent_act.CREATED_DATE AS PARENT_ACT_CREATED_DATE,
    parent_act.RECORD_TYPE_ID AS PARENT_ACT_RECORD_TYPE_ID,
    parent_rcd.NAME AS PARENT_ACT_RECORD_TYPE_ID_NAME,
    parent_act.MARKETING_LIFECYCLE_AT_SUSPECT__C AS PARENT_ACT_MARKETING_LIFECYCLE_AT_SUSPECT__C,
    parent_act.MARKETING_LIFECYCLE__C AS PARENT_ACT_MARKETING_LIFECYCLE__C,
    parent_act.BUSINESS_UNIT_2020__C AS PARENT_ACT_BUSINESS_UNIT_2020__C,
    parent_act.BUSINESS_UNIT_DIVISION__C AS PARENT_ACT_BUSINESS_UNIT_DIVISION__C,
    parent_act.MARKET__C AS PARENT_ACT_MARKET__C,
    parent_act.FLEET_SIZE__C AS PARENT_ACT_FLEET_SIZE__C,
    parent_act.MARKET_SEGMENT__C AS PARENT_ACT_MARKET_SEGMENT__C,
    parent_act.INDUSTRY AS PARENT_ACT_INDUSTRY,
    parent_act.INDUSTRY_DB__C AS PARENT_ACT_INDUSTRY_DB__C,
    parent_act.INDUSTRY_SECTOR__C AS PARENT_ACT_INDUSTRY_SECTOR__C,
    parent_act.TERRITORY__C AS PARENT_ACT_TERRITORY__C,
    parent_act.STATE_DB__C AS PARENT_ACT_STATE_DB__C,
    parent_act.ACCOUNT_PROFILE_FIT6SENSE__C AS PARENT_ACT_ACCOUNT_PROFILE_FIT6SENSE__C,
    parent_act.ACCOUNT_PROFILE_SCORE6SENSE__C AS PARENT_ACT_ACCOUNT_PROFILE_SCORE6SENSE__C

FROM salesforce.account AS act
-- Account Record Type
INNER JOIN salesforce.record_type AS rcd 
    ON act.record_type_id = rcd.id
    AND rcd.id IN ('012300000005VEYAA2', '0126R000001UknZQAS')
-- Account Owner
LEFT JOIN salesforce.user AS usr 
    ON act.owner_id = usr.id
    AND usr.name NOT IN ('Scott Rose', 'Rick Walters', 'Micah Rea', 'Compliance', 'ELD Compliance Manager')
-- Account Owner Role
LEFT JOIN salesforce.user_role AS usr_role 
    ON usr.user_role_id = usr_role.id
-- Account Opener
LEFT JOIN salesforce.user AS usro 
    ON act.opener__c = usro.id
    AND usro.name NOT IN ('Scott Rose', 'Rick Walters', 'Micah Rea', 'Compliance', 'ELD Compliance Manager')
-- Parent Account
LEFT JOIN salesforce.account AS parent_act 
    ON act.parent_id = parent_act.id
LEFT JOIN salesforce.record_type AS parent_rcd 
    ON parent_act.record_type_id = parent_rcd.id
-- AMLH Normalized Data
INNER JOIN amlh_temp_normalized AS norm 
    ON act.id = norm.account__c
-- Journey Flags
INNER JOIN amlh_temp_journey_flags AS jf 
    ON norm.account__c = jf.account__c
    AND norm.recycle_counter__c = jf.recycle_counter__c
    AND norm.created_date = jf.created_date
ORDER BY act.id;

RAISE INFO 'Step 5 complete: Main MV created';

-- =============================================================================
-- STEP 6: Calculate ALL deltas in a SINGLE pass (replaces 20 temp tables)
-- =============================================================================
DROP TABLE IF EXISTS amlh_temp_all_deltas;
CREATE TEMPORARY TABLE amlh_temp_all_deltas DISTSTYLE KEY DISTKEY(AMLH_ACCOUNT__C) AS
SELECT
    AMLH_ACCOUNT__C,
    AMLH_NAME,
    -- Cold to other stages
    CASE WHEN AMLH_COLD_ACCOUNT_DATE_STAMP__C_CAST IS NOT NULL AND AMLH_MEA_DATE_STAMP__C_CAST IS NOT NULL 
         THEN DATEDIFF(day, AMLH_COLD_ACCOUNT_DATE_STAMP__C_CAST, AMLH_MEA_DATE_STAMP__C_CAST) END AS AMLH_DELTA_DAYS_COLD_MEA,
    CASE WHEN AMLH_COLD_ACCOUNT_DATE_STAMP__C_CAST IS NOT NULL AND AMLH_MQA_DATE_STAMP__C_CAST IS NOT NULL 
         THEN DATEDIFF(day, AMLH_COLD_ACCOUNT_DATE_STAMP__C_CAST, AMLH_MQA_DATE_STAMP__C_CAST) END AS AMLH_DELTA_DAYS_COLD_MQA,
    CASE WHEN AMLH_COLD_ACCOUNT_DATE_STAMP__C_CAST IS NOT NULL AND AMLH_SUSPECT_DATE_STAMP__C_CAST IS NOT NULL 
         THEN DATEDIFF(day, AMLH_COLD_ACCOUNT_DATE_STAMP__C_CAST, AMLH_SUSPECT_DATE_STAMP__C_CAST) END AS AMLH_DELTA_DAYS_COLD_SUSPECT,
    CASE WHEN AMLH_COLD_ACCOUNT_DATE_STAMP__C_CAST IS NOT NULL AND AMLH_PROSPECT_DATE_STAMP__C_CAST IS NOT NULL 
         THEN DATEDIFF(day, AMLH_COLD_ACCOUNT_DATE_STAMP__C_CAST, AMLH_PROSPECT_DATE_STAMP__C_CAST) END AS AMLH_DELTA_DAYS_COLD_PROSPECT,
    CASE WHEN AMLH_COLD_ACCOUNT_DATE_STAMP__C_CAST IS NOT NULL AND AMLH_CUSTOMER_DATE_STAMP__C_CAST IS NOT NULL 
         THEN DATEDIFF(day, AMLH_COLD_ACCOUNT_DATE_STAMP__C_CAST, AMLH_CUSTOMER_DATE_STAMP__C_CAST) END AS AMLH_DELTA_DAYS_COLD_CUSTOMER,
    CASE WHEN AMLH_COLD_ACCOUNT_DATE_STAMP__C_CAST IS NOT NULL AND AMLH_EFFECTIVE_DATE_STAMP__C_CAST IS NOT NULL 
         THEN DATEDIFF(day, AMLH_COLD_ACCOUNT_DATE_STAMP__C_CAST, AMLH_EFFECTIVE_DATE_STAMP__C_CAST) END AS AMLH_DELTA_DAYS_COLD_EFFECTIVE,
    -- MEA to other stages
    CASE WHEN AMLH_MEA_DATE_STAMP__C_CAST IS NOT NULL AND AMLH_MQA_DATE_STAMP__C_CAST IS NOT NULL 
         THEN DATEDIFF(day, AMLH_MEA_DATE_STAMP__C_CAST, AMLH_MQA_DATE_STAMP__C_CAST) END AS AMLH_DELTA_DAYS_MEA_MQA,
    CASE WHEN AMLH_MEA_DATE_STAMP__C_CAST IS NOT NULL AND AMLH_SUSPECT_DATE_STAMP__C_CAST IS NOT NULL 
         THEN DATEDIFF(day, AMLH_MEA_DATE_STAMP__C_CAST, AMLH_SUSPECT_DATE_STAMP__C_CAST) END AS AMLH_DELTA_DAYS_MEA_SUSPECT,
    CASE WHEN AMLH_MEA_DATE_STAMP__C_CAST IS NOT NULL AND AMLH_PROSPECT_DATE_STAMP__C_CAST IS NOT NULL 
         THEN DATEDIFF(day, AMLH_MEA_DATE_STAMP__C_CAST, AMLH_PROSPECT_DATE_STAMP__C_CAST) END AS AMLH_DELTA_DAYS_MEA_PROSPECT,
    CASE WHEN AMLH_MEA_DATE_STAMP__C_CAST IS NOT NULL AND AMLH_CUSTOMER_DATE_STAMP__C_CAST IS NOT NULL 
         THEN DATEDIFF(day, AMLH_MEA_DATE_STAMP__C_CAST, AMLH_CUSTOMER_DATE_STAMP__C_CAST) END AS AMLH_DELTA_DAYS_MEA_CUSTOMER,
    CASE WHEN AMLH_MEA_DATE_STAMP__C_CAST IS NOT NULL AND AMLH_EFFECTIVE_DATE_STAMP__C_CAST IS NOT NULL 
         THEN DATEDIFF(day, AMLH_MEA_DATE_STAMP__C_CAST, AMLH_EFFECTIVE_DATE_STAMP__C_CAST) END AS AMLH_DELTA_DAYS_MEA_EFFECTIVE,
    -- MQA to other stages
    CASE WHEN AMLH_MQA_DATE_STAMP__C_CAST IS NOT NULL AND AMLH_SUSPECT_DATE_STAMP__C_CAST IS NOT NULL 
         THEN DATEDIFF(day, AMLH_MQA_DATE_STAMP__C_CAST, AMLH_SUSPECT_DATE_STAMP__C_CAST) END AS AMLH_DELTA_DAYS_MQA_SUSPECT,
    CASE WHEN AMLH_MQA_DATE_STAMP__C_CAST IS NOT NULL AND AMLH_PROSPECT_DATE_STAMP__C_CAST IS NOT NULL 
         THEN DATEDIFF(day, AMLH_MQA_DATE_STAMP__C_CAST, AMLH_PROSPECT_DATE_STAMP__C_CAST) END AS AMLH_DELTA_DAYS_MQA_PROSPECT,
    CASE WHEN AMLH_MQA_DATE_STAMP__C_CAST IS NOT NULL AND AMLH_CUSTOMER_DATE_STAMP__C_CAST IS NOT NULL 
         THEN DATEDIFF(day, AMLH_MQA_DATE_STAMP__C_CAST, AMLH_CUSTOMER_DATE_STAMP__C_CAST) END AS AMLH_DELTA_DAYS_MQA_CUSTOMER,
    CASE WHEN AMLH_MQA_DATE_STAMP__C_CAST IS NOT NULL AND AMLH_EFFECTIVE_DATE_STAMP__C_CAST IS NOT NULL 
         THEN DATEDIFF(day, AMLH_MQA_DATE_STAMP__C_CAST, AMLH_EFFECTIVE_DATE_STAMP__C_CAST) END AS AMLH_DELTA_DAYS_MQA_EFFECTIVE,
    -- Suspect to other stages
    CASE WHEN AMLH_SUSPECT_DATE_STAMP__C_CAST IS NOT NULL AND AMLH_PROSPECT_DATE_STAMP__C_CAST IS NOT NULL 
         THEN DATEDIFF(day, AMLH_SUSPECT_DATE_STAMP__C_CAST, AMLH_PROSPECT_DATE_STAMP__C_CAST) END AS AMLH_DELTA_DAYS_SUSPECT_PROSPECT,
    CASE WHEN AMLH_SUSPECT_DATE_STAMP__C_CAST IS NOT NULL AND AMLH_CUSTOMER_DATE_STAMP__C_CAST IS NOT NULL 
         THEN DATEDIFF(day, AMLH_SUSPECT_DATE_STAMP__C_CAST, AMLH_CUSTOMER_DATE_STAMP__C_CAST) END AS AMLH_DELTA_DAYS_SUSPECT_CUSTOMER,
    CASE WHEN AMLH_SUSPECT_DATE_STAMP__C_CAST IS NOT NULL AND AMLH_EFFECTIVE_DATE_STAMP__C_CAST IS NOT NULL 
         THEN DATEDIFF(day, AMLH_SUSPECT_DATE_STAMP__C_CAST, AMLH_EFFECTIVE_DATE_STAMP__C_CAST) END AS AMLH_DELTA_DAYS_SUSPECT_EFFECTIVE
FROM act_mrkt_lifecycle.AMLH_TEMP_MV_1
WHERE AMLH_ACCOUNT_JOURNEY_PATH_LIFECYCLE_NONLINEAR_FLAG = 'Linear';

RAISE INFO 'Step 6 complete: All deltas calculated in single pass';

-- =============================================================================
-- STEP 7: Create final AMLH table with deltas and pre-suspect designation
-- =============================================================================
DROP TABLE IF EXISTS ACT_MRKT_LIFECYCLE.AMLH CASCADE;
CREATE TABLE ACT_MRKT_LIFECYCLE.AMLH 
DISTSTYLE KEY DISTKEY(ACT_ID) 
SORTKEY(ACT_ID, AMLH_RECYCLE_COUNTER__C)
AS
SELECT
    mv.*,
    -- Pre-Suspect Designation (using integer order columns instead of string parsing)
    CASE
        -- Cold - Not Routed
        WHEN mv.AMLH_COLD_ORDER IS NOT NULL 
             AND mv.AMLH_SUSPECT_ORDER IS NULL 
             AND (mv.AMLH_COLD_ORDER > COALESCE(mv.AMLH_MEA_ORDER, 0))
             AND (mv.AMLH_COLD_ORDER > COALESCE(mv.AMLH_MQA_ORDER, 0))
        THEN 'Pre-Suspect Cold - Not Routed'
        -- Cold - Routed
        WHEN mv.AMLH_COLD_ORDER IS NOT NULL 
             AND mv.AMLH_SUSPECT_ORDER IS NOT NULL 
             AND mv.AMLH_COLD_ORDER < mv.AMLH_SUSPECT_ORDER
             AND (mv.AMLH_COLD_ORDER > COALESCE(mv.AMLH_MEA_ORDER, 0) OR COALESCE(mv.AMLH_MEA_ORDER, 0) > mv.AMLH_SUSPECT_ORDER)
             AND (mv.AMLH_COLD_ORDER > COALESCE(mv.AMLH_MQA_ORDER, 0) OR COALESCE(mv.AMLH_MQA_ORDER, 0) > mv.AMLH_SUSPECT_ORDER)
        THEN 'Pre-Suspect Cold - Routed'
        -- MEA - Not Routed
        WHEN mv.AMLH_MEA_ORDER IS NOT NULL 
             AND mv.AMLH_SUSPECT_ORDER IS NULL 
             AND mv.AMLH_MEA_ORDER > COALESCE(mv.AMLH_COLD_ORDER, 0)
             AND mv.AMLH_MEA_ORDER > COALESCE(mv.AMLH_MQA_ORDER, 0)
        THEN 'Pre-Suspect MEA - Not Routed'
        -- MEA - Routed
        WHEN mv.AMLH_MEA_ORDER IS NOT NULL 
             AND mv.AMLH_SUSPECT_ORDER IS NOT NULL 
             AND mv.AMLH_MEA_ORDER < mv.AMLH_SUSPECT_ORDER
             AND (mv.AMLH_MEA_ORDER > COALESCE(mv.AMLH_COLD_ORDER, 0) OR COALESCE(mv.AMLH_COLD_ORDER, 0) > mv.AMLH_SUSPECT_ORDER)
             AND (mv.AMLH_MEA_ORDER > COALESCE(mv.AMLH_MQA_ORDER, 0) 
                  OR (COALESCE(mv.AMLH_MQA_ORDER, 0) > mv.AMLH_SUSPECT_ORDER 
                      AND DATEDIFF(minute, mv.AMLH_SUSPECT_DATE_STAMP__C, mv.AMLH_MQA_DATE_STAMP__C) > 15))
        THEN 'Pre-Suspect MEA - Routed'
        -- MQA - Not Routed
        WHEN mv.AMLH_MQA_ORDER IS NOT NULL 
             AND mv.AMLH_SUSPECT_ORDER IS NULL 
             AND mv.AMLH_MQA_ORDER > COALESCE(mv.AMLH_COLD_ORDER, 0)
             AND mv.AMLH_MQA_ORDER > COALESCE(mv.AMLH_MEA_ORDER, 0)
        THEN 'Pre-Suspect MQA - Not Routed'
        -- MQA - Routed
        WHEN mv.AMLH_MQA_ORDER IS NOT NULL 
             AND mv.AMLH_SUSPECT_ORDER IS NOT NULL 
             AND (mv.AMLH_MQA_ORDER < mv.AMLH_SUSPECT_ORDER 
                  OR (mv.AMLH_MQA_ORDER > mv.AMLH_SUSPECT_ORDER 
                      AND DATEDIFF(minute, mv.AMLH_SUSPECT_DATE_STAMP__C, mv.AMLH_MQA_DATE_STAMP__C) <= 15))
             AND (mv.AMLH_MQA_ORDER > COALESCE(mv.AMLH_COLD_ORDER, 0) OR COALESCE(mv.AMLH_COLD_ORDER, 0) > mv.AMLH_SUSPECT_ORDER)
             AND (mv.AMLH_MQA_ORDER > COALESCE(mv.AMLH_MEA_ORDER, 0) OR COALESCE(mv.AMLH_MEA_ORDER, 0) > mv.AMLH_SUSPECT_ORDER)
        THEN 'Pre-Suspect MQA - Routed'
        ELSE 'Other'
    END AS AMLH_MUTUALLY_EXCLUSIVE_PRE_SUSPECT_DESIGNATION,
    
    -- Pre-Suspect Designation Date
    CASE
        -- Cold scenarios
        WHEN mv.AMLH_COLD_ORDER IS NOT NULL 
             AND mv.AMLH_SUSPECT_ORDER IS NULL 
             AND (mv.AMLH_COLD_ORDER > COALESCE(mv.AMLH_MEA_ORDER, 0))
             AND (mv.AMLH_COLD_ORDER > COALESCE(mv.AMLH_MQA_ORDER, 0))
        THEN CAST(mv.AMLH_COLD_ACCOUNT_DATE_STAMP__C AS date)
        WHEN mv.AMLH_COLD_ORDER IS NOT NULL 
             AND mv.AMLH_SUSPECT_ORDER IS NOT NULL 
             AND mv.AMLH_COLD_ORDER < mv.AMLH_SUSPECT_ORDER
             AND (mv.AMLH_COLD_ORDER > COALESCE(mv.AMLH_MEA_ORDER, 0) OR COALESCE(mv.AMLH_MEA_ORDER, 0) > mv.AMLH_SUSPECT_ORDER)
             AND (mv.AMLH_COLD_ORDER > COALESCE(mv.AMLH_MQA_ORDER, 0) OR COALESCE(mv.AMLH_MQA_ORDER, 0) > mv.AMLH_SUSPECT_ORDER)
        THEN CAST(mv.AMLH_COLD_ACCOUNT_DATE_STAMP__C AS date)
        -- MEA scenarios
        WHEN mv.AMLH_MEA_ORDER IS NOT NULL 
             AND mv.AMLH_SUSPECT_ORDER IS NULL 
             AND mv.AMLH_MEA_ORDER > COALESCE(mv.AMLH_COLD_ORDER, 0)
             AND mv.AMLH_MEA_ORDER > COALESCE(mv.AMLH_MQA_ORDER, 0)
        THEN CAST(mv.AMLH_MEA_DATE_STAMP__C AS date)
        WHEN mv.AMLH_MEA_ORDER IS NOT NULL 
             AND mv.AMLH_SUSPECT_ORDER IS NOT NULL 
             AND mv.AMLH_MEA_ORDER < mv.AMLH_SUSPECT_ORDER
             AND (mv.AMLH_MEA_ORDER > COALESCE(mv.AMLH_COLD_ORDER, 0) OR COALESCE(mv.AMLH_COLD_ORDER, 0) > mv.AMLH_SUSPECT_ORDER)
             AND (mv.AMLH_MEA_ORDER > COALESCE(mv.AMLH_MQA_ORDER, 0) 
                  OR (COALESCE(mv.AMLH_MQA_ORDER, 0) > mv.AMLH_SUSPECT_ORDER 
                      AND DATEDIFF(minute, mv.AMLH_SUSPECT_DATE_STAMP__C, mv.AMLH_MQA_DATE_STAMP__C) > 15))
        THEN CAST(mv.AMLH_MEA_DATE_STAMP__C AS date)
        -- MQA scenarios
        WHEN mv.AMLH_MQA_ORDER IS NOT NULL 
             AND mv.AMLH_SUSPECT_ORDER IS NULL 
             AND mv.AMLH_MQA_ORDER > COALESCE(mv.AMLH_COLD_ORDER, 0)
             AND mv.AMLH_MQA_ORDER > COALESCE(mv.AMLH_MEA_ORDER, 0)
        THEN CAST(mv.AMLH_MQA_DATE_STAMP__C AS date)
        WHEN mv.AMLH_MQA_ORDER IS NOT NULL 
             AND mv.AMLH_SUSPECT_ORDER IS NOT NULL 
             AND (mv.AMLH_MQA_ORDER < mv.AMLH_SUSPECT_ORDER 
                  OR (mv.AMLH_MQA_ORDER > mv.AMLH_SUSPECT_ORDER 
                      AND DATEDIFF(minute, mv.AMLH_SUSPECT_DATE_STAMP__C, mv.AMLH_MQA_DATE_STAMP__C) <= 15))
             AND (mv.AMLH_MQA_ORDER > COALESCE(mv.AMLH_COLD_ORDER, 0) OR COALESCE(mv.AMLH_COLD_ORDER, 0) > mv.AMLH_SUSPECT_ORDER)
             AND (mv.AMLH_MQA_ORDER > COALESCE(mv.AMLH_MEA_ORDER, 0) OR COALESCE(mv.AMLH_MEA_ORDER, 0) > mv.AMLH_SUSPECT_ORDER)
        THEN CAST(mv.AMLH_MQA_DATE_STAMP__C AS date)
        ELSE NULL
    END AS AMLH_MUTUALLY_EXCLUSIVE_PRE_SUSPECT_DESIGNATION_DATE,
    
    -- Date period calculations for pre-suspect designation date (computed in wrapper)
    -- Deltas from single-pass calculation
    d.AMLH_DELTA_DAYS_COLD_MEA,
    d.AMLH_DELTA_DAYS_COLD_MQA,
    d.AMLH_DELTA_DAYS_COLD_SUSPECT,
    d.AMLH_DELTA_DAYS_COLD_PROSPECT,
    d.AMLH_DELTA_DAYS_COLD_CUSTOMER,
    d.AMLH_DELTA_DAYS_COLD_EFFECTIVE,
    d.AMLH_DELTA_DAYS_MEA_MQA,
    d.AMLH_DELTA_DAYS_MEA_SUSPECT,
    d.AMLH_DELTA_DAYS_MEA_PROSPECT,
    d.AMLH_DELTA_DAYS_MEA_CUSTOMER,
    d.AMLH_DELTA_DAYS_MEA_EFFECTIVE,
    d.AMLH_DELTA_DAYS_MQA_SUSPECT,
    d.AMLH_DELTA_DAYS_MQA_PROSPECT,
    d.AMLH_DELTA_DAYS_MQA_CUSTOMER,
    d.AMLH_DELTA_DAYS_MQA_EFFECTIVE,
    d.AMLH_DELTA_DAYS_SUSPECT_PROSPECT,
    d.AMLH_DELTA_DAYS_SUSPECT_CUSTOMER,
    d.AMLH_DELTA_DAYS_SUSPECT_EFFECTIVE
FROM act_mrkt_lifecycle.AMLH_TEMP_MV_1 mv
LEFT JOIN amlh_temp_all_deltas d 
    ON mv.AMLH_ACCOUNT__C = d.AMLH_ACCOUNT__C 
    AND mv.AMLH_NAME = d.AMLH_NAME;

-- Add pre-suspect designation date period columns
ALTER TABLE ACT_MRKT_LIFECYCLE.AMLH ADD COLUMN AMLH_MUTUALLY_EXCLUSIVE_PRE_SUSPECT_DESIGNATION_DATE_EOW date;
ALTER TABLE ACT_MRKT_LIFECYCLE.AMLH ADD COLUMN AMLH_MUTUALLY_EXCLUSIVE_PRE_SUSPECT_DESIGNATION_DATE_EOM date;
ALTER TABLE ACT_MRKT_LIFECYCLE.AMLH ADD COLUMN AMLH_MUTUALLY_EXCLUSIVE_PRE_SUSPECT_DESIGNATION_DATE_EOQ date;
ALTER TABLE ACT_MRKT_LIFECYCLE.AMLH ADD COLUMN AMLH_MUTUALLY_EXCLUSIVE_PRE_SUSPECT_DESIGNATION_DATE_EOY date;

UPDATE ACT_MRKT_LIFECYCLE.AMLH
SET 
    AMLH_MUTUALLY_EXCLUSIVE_PRE_SUSPECT_DESIGNATION_DATE_EOW = CAST(DATE_TRUNC('week', AMLH_MUTUALLY_EXCLUSIVE_PRE_SUSPECT_DESIGNATION_DATE) + INTERVAL '6 days' AS date),
    AMLH_MUTUALLY_EXCLUSIVE_PRE_SUSPECT_DESIGNATION_DATE_EOM = LAST_DAY(AMLH_MUTUALLY_EXCLUSIVE_PRE_SUSPECT_DESIGNATION_DATE),
    AMLH_MUTUALLY_EXCLUSIVE_PRE_SUSPECT_DESIGNATION_DATE_EOQ = CAST(DATEADD(day, -1, DATEADD(quarter, 1, DATE_TRUNC('quarter', AMLH_MUTUALLY_EXCLUSIVE_PRE_SUSPECT_DESIGNATION_DATE))) AS date),
    AMLH_MUTUALLY_EXCLUSIVE_PRE_SUSPECT_DESIGNATION_DATE_EOY = CAST(DATEADD(day, -1, DATEADD(year, 1, DATE_TRUNC('year', AMLH_MUTUALLY_EXCLUSIVE_PRE_SUSPECT_DESIGNATION_DATE))) AS date)
WHERE AMLH_MUTUALLY_EXCLUSIVE_PRE_SUSPECT_DESIGNATION_DATE IS NOT NULL;

RAISE INFO 'Step 7 complete: Final AMLH table created';

-- =============================================================================
-- STEP 8: Create opportunity stage dates (single extraction - used twice)
-- =============================================================================
DROP TABLE IF EXISTS opp_stage_dates_base;
CREATE TEMPORARY TABLE opp_stage_dates_base DISTSTYLE KEY DISTKEY(opportunity_id) AS
WITH stage_history AS (
    SELECT 
        opportunity_id,
        created_date,
        new_value,
        CASE 
            WHEN new_value IN ('Closed - Booked', 'Closed - Booked (SO)', 'Closed - Parent', 
                              'Closed - Ready to Book', 'Closed Won', 'On Hold',
                              'Pending Additional Signature', 'Pending Approval', 'Pending Client Signature')
            THEN 'Win'
            ELSE new_value
        END AS stage_category
    FROM salesforce.opportunity_field_history
    WHERE field = 'StageName'
      AND new_value IN (
          'Identify', 'Analyze', 'Present', 'Prove', 'Finalize',
          'Nurture', 'Qualify', 'Discover', 'Propose', 'Validate', 'Negotiate',
          'Closed - Booked', 'Closed - Booked (SO)', 'Closed - Parent', 
          'Closed - Ready to Book', 'Closed Won', 'On Hold',
          'Pending Additional Signature', 'Pending Approval', 'Pending Client Signature'
      )
),
pivoted AS (
    SELECT 
        opportunity_id,
        MIN(CASE WHEN stage_category = 'Identify' THEN created_date END) AS identify,
        MIN(CASE WHEN stage_category = 'Analyze' THEN created_date END) AS analyze,
        MIN(CASE WHEN stage_category = 'Present' THEN created_date END) AS present,
        MIN(CASE WHEN stage_category = 'Prove' THEN created_date END) AS prove,
        MIN(CASE WHEN stage_category = 'Finalize' THEN created_date END) AS finalize,
        MIN(CASE WHEN stage_category = 'Nurture' THEN created_date END) AS nurture,
        MIN(CASE WHEN stage_category = 'Qualify' THEN created_date END) AS qualify,
        MIN(CASE WHEN stage_category = 'Discover' THEN created_date END) AS discover,
        MIN(CASE WHEN stage_category = 'Propose' THEN created_date END) AS propose,
        MIN(CASE WHEN stage_category = 'Validate' THEN created_date END) AS validate,
        MIN(CASE WHEN stage_category = 'Negotiate' THEN created_date END) AS negotiate,
        MAX(CASE WHEN stage_category = 'Win' THEN created_date END) AS win
    FROM stage_history
    GROUP BY opportunity_id
)
SELECT 
    opp.id AS opportunity_id,
    opp.created_date AS stage0,
    -- Map old/new stage names based on cutoff date
    COALESCE(
        CASE WHEN p.identify < '2024-10-08' THEN p.identify ELSE p.nurture END,
        CASE WHEN p.analyze < '2024-10-08' THEN p.analyze ELSE p.qualify END,
        CASE WHEN p.present < '2024-10-08' THEN p.present ELSE p.discover END,
        CASE WHEN p.prove < '2024-10-08' THEN p.prove ELSE p.propose END,
        CASE WHEN p.finalize < '2024-10-08' THEN p.finalize ELSE p.validate END,
        p.negotiate,
        p.win
    ) AS stage1,
    COALESCE(
        CASE WHEN p.analyze < '2024-10-08' THEN p.analyze ELSE p.qualify END,
        CASE WHEN p.present < '2024-10-08' THEN p.present ELSE p.discover END,
        CASE WHEN p.prove < '2024-10-08' THEN p.prove ELSE p.propose END,
        CASE WHEN p.finalize < '2024-10-08' THEN p.finalize ELSE p.validate END,
        p.negotiate,
        p.win
    ) AS stage2,
    COALESCE(
        CASE WHEN p.present < '2024-10-08' THEN p.present ELSE p.discover END,
        CASE WHEN p.prove < '2024-10-08' THEN p.prove ELSE p.propose END,
        CASE WHEN p.finalize < '2024-10-08' THEN p.finalize ELSE p.validate END,
        p.negotiate,
        p.win
    ) AS stage3,
    COALESCE(
        CASE WHEN p.prove < '2024-10-08' THEN p.prove ELSE p.propose END,
        CASE WHEN p.finalize < '2024-10-08' THEN p.finalize ELSE p.validate END,
        p.negotiate,
        p.win
    ) AS stage4,
    COALESCE(
        CASE WHEN p.finalize < '2024-10-08' THEN p.finalize ELSE p.negotiate END,
        p.win
    ) AS stage5,
    p.win
FROM salesforce.opportunity opp
LEFT JOIN pivoted p ON opp.id = p.opportunity_id;

RAISE INFO 'Step 8 complete: Opportunity stage dates extracted';

-- =============================================================================
-- STEP 9: Create AMLH_OPPS table with opportunity data
-- =============================================================================
DROP TABLE IF EXISTS ACT_MRKT_LIFECYCLE.AMLH_OPPS CASCADE;
CREATE TABLE ACT_MRKT_LIFECYCLE.AMLH_OPPS 
DISTSTYLE KEY DISTKEY(ACT_ID) 
SORTKEY(ACT_ID, AMLH_RECYCLE_COUNTER__C)
AS
WITH opp_with_details AS (
    SELECT 
        opp.*,
        curr.CONVERSION_RATE,
        usr.NAME AS OWNER_NAME,
        usr_role.NAME AS OWNER_USERROLE_NAME
    FROM salesforce.opportunity AS opp
    INNER JOIN salesforce.record_type AS rcd_opp 
        ON opp.record_type_id = rcd_opp.id
        AND rcd_opp.id IN ('012800000005wl4AAA', '0121E000000MBF6QAO')
    LEFT JOIN salesforce.user AS usr 
        ON opp.owner_id = usr.id
        AND opp.owner_id <> '0056R00000C6W2MQAV'
    LEFT JOIN salesforce.user_role AS usr_role 
        ON usr.user_role_id = usr_role.id
    INNER JOIN salesforce.currency_type AS curr 
        ON opp.currency_iso_code = curr.iso_code
        AND curr.is_active = TRUE
    WHERE usr_role.name NOT IN ('Scott Rose', 'Rick Walters', 'Micah Rea', 'Compliance', 'ELD Compliance Manager')
)
SELECT
    amlh.*,
    -- Opportunity Info
    opp.ID AS OPP_ID,
    opp.NAME AS OPP_NAME,
    CAST(opp.CREATED_DATE AS date) AS OPP_CREATED_DATE,
    CAST(DATE_TRUNC('week', opp.created_date) + INTERVAL '6 days' AS date) AS OPP_CREATED_DATE__C_EOW,
    LAST_DAY(opp.created_date) AS OPP_CREATED_DATE__C_EOM,
    CAST(DATEADD(day, -1, DATEADD(quarter, 1, DATE_TRUNC('quarter', opp.created_date))) AS date) AS OPP_CREATED_DATE__C_EOQ,
    CAST(DATEADD(day, -1, DATEADD(year, 1, DATE_TRUNC('year', opp.created_date))) AS date) AS OPP_CREATED_DATE__C_EOY,
    opp.CLOSE_DATE AS OPP_CLOSE_DATE,
    opp.LEAD_SOURCE AS OPP_LEAD_SOURCE,
    opp.STAGE_NAME AS OPP_STAGE_NAME,
    opp.SUB_STAGE__C AS OPP_SUB_STAGE__C,
    opp.SALES_REPORTING_OPPORTUNITY_TYPE__C AS OPP_SALES_REPORTING_OPPORTUNITY_TYPE__C,
    opp.COMPETITIVE_INFLUENCE__C AS OPP_COMPETITIVE_INFLUENCE__C,
    opp.PRIMARY_COMPETITOR__C AS OPP_PRIMARY_COMPETITOR__C,
    opp.LOSS_STALL_REASON__C AS OPP_LOSS_STALL_REASON__C,
    opp.LOSS_STALL_REASON_DETAIL__C AS OPP_LOSS_STALL_REASON_DETAIL__C,
    opp.LOST_REASON__C AS OPP_LOST_REASON__C,
    opp.LEADING_PRODUCT__C AS OPP_LEADING_PRODUCT__C,
    opp.PRODUCT_INTEREST__C AS OPP_PRODUCT_INTEREST__C,
    opp.PUSH_COUNT AS OPP_PUSH_COUNT,
    
    -- Opportunity Stage Category
    CASE 
        WHEN opp.ID IS NULL OR opp.STAGE_NAME IS NULL 
             OR opp.STAGE_NAME IN ('Awaiting Auto-Renewal', 'Cancelled', 'Churn', 'Closed - Auto Renewal',
                                   'Closed - Migrated', 'Closed - Reduced', 'Closed - Terminated', 'Closed - Transfer',
                                   'Closed / Duplicate', 'Closed / Invalid', 'Closed Auto-Renewed',
                                   'Closed Booked - Cancelled', 'Paved - Invoice')
        THEN 'No Opp'
        WHEN opp.STAGE_NAME IN ('Closed - Booked', 'Closed - Booked (SO)', 'Closed - Parent', 'Closed - Ready to Book',
                                'Closed Won', 'On Hold', 'Pending Additional Signature', 'Pending Approval', 'Pending Client Signature')
        THEN 'Closed - Booked'
        WHEN opp.STAGE_NAME IN ('Closed Lost', 'Closed Return to CDM', 'Closed Stalled', 'Closed/Unqualified', 'Stalled / At Risk')
        THEN 'Closed - Not Booked'
        ELSE 'Open'
    END AS OPP_STAGE_NAME_CATEGORY,
    
    opp.TYPE AS OPP_TYPE,
    opp.COMMITTED_TERM__C AS OPP_COMMITTED_TERM__C,
    opp.PROBABILITY AS OPP_PROBABILITY,
    opp.IS_CLOSED AS OPP_IS_CLOSED,
    opp.IS_WON AS OPP_IS_WON,
    
    -- Financial Metrics
    opp.CURRENCY_ISO_CODE AS OPP_CURRENCY_ISO_CODE,
    opp.CONVERSION_RATE AS OPP_CONVERSION_RATE,
    opp.ACV3__C AS OPP_ACV3__C,
    opp.FORECASTED_ACV__C AS OPP_FORECASTED_ACV__C,
    opp.FORECASTED_ARR__C AS OPP_FORECASTED_ARR__C,
    opp.SALES_REPORTING_ARR__C AS OPP_SALES_REPORTING_ARR__C,
    CASE WHEN opp.ID IS NULL THEN NULL 
         WHEN opp.STAGE_NAME = 'Closed - Booked (SO)' THEN COALESCE(opp.ACV3__C, opp.FORECASTED_ACV__C) 
         ELSE opp.FORECASTED_ACV__C 
    END AS OPP_BOOKEDFORECASTED_ACV3__C,
    CASE WHEN opp.ID IS NULL THEN NULL 
         WHEN opp.STAGE_NAME = 'Closed - Booked (SO)' THEN COALESCE(opp.ACV3__C, opp.FORECASTED_ACV__C) 
         ELSE opp.FORECASTED_ACV__C 
    END AS OPP_BOOKEDFORECASTED_ACV_QTY3__C,
    CASE WHEN opp.ID IS NULL THEN NULL 
         WHEN opp.STAGE_NAME = 'Closed - Booked (SO)' THEN COALESCE(opp.SALES_REPORTING_ARR__C, opp.FORECASTED_ARR__C) 
         ELSE opp.FORECASTED_ARR__C 
    END AS OPP_BOOKEDFORECASTED_ARR__C,
    opp.REPORTING_ARR__C AS OPP_REPORTING_ARR__C,
    opp.TOTAL_BOOKING_AMOUNT2__C AS OPP_TOTAL_BOOKING_AMOUNT2__C,
    (opp.ACV3__C * opp.CONVERSION_RATE) AS OPP_ACV3__C_CONVERTED,
    (opp.TOTAL_BOOKING_AMOUNT2__C * opp.CONVERSION_RATE) AS OPP_TOTAL_BOOKING_AMOUNT2__C_CONVERTED,
    opp.SUBS_QTY__C AS OPP_SUBS_QTY__C,
    opp.BOOKED_SUBS_QTY3__C AS OPP_BOOKED_SUBS_QTY3__C,
    opp.FORECASTED_SUBS_QTY__C AS OPP_FORECASTED_SUBS_QTY__C,
    CASE WHEN opp.ID IS NULL THEN NULL 
         WHEN opp.STAGE_NAME = 'Closed - Booked (SO)' THEN COALESCE(opp.BOOKED_SUBS_QTY3__C, opp.FORECASTED_SUBS_QTY__C) 
         ELSE opp.FORECASTED_SUBS_QTY__C 
    END AS OPP_BOOKEDFORECASTED_SUBS_QTY3__C,
    opp.SALES_REPORTING_ACV__C AS OPP_SALES_REPORTING_ACV__C,
    opp.SALES_REPORTING_TOTAL_BOOKING_AMOUNT__C AS OPP_SALES_REPORTING_TOTAL_BOOKING_AMOUNT__C,
    (opp.SALES_REPORTING_ACV__C * opp.CONVERSION_RATE) AS OPP_SALES_REPORTING_ACV__C_CONVERTED,
    (opp.SALES_REPORTING_TOTAL_BOOKING_AMOUNT__C * opp.CONVERSION_RATE) AS OPP_SALES_REPORTING_TOTAL_BOOKING_AMOUNT__C_CONVERTED,
    opp.SALES_REPORTING_BOOKED_SUBS_QTY__C AS OPP_SALES_REPORTING_BOOKED_SUBS_QTY__C,
    
    -- Owner Info
    opp.OWNER_NAME AS OPP_OWNER_NAME,
    opp.OWNER_USERROLE_NAME AS OPP_OWNER_USERROLE_NAME,
    
    -- Stage Dates (from pre-calculated temp table)
    CAST(sd.stage0 AS date) AS OPP_STAGE_0_DATE,
    CAST(sd.stage1 AS date) AS OPP_STAGE_1_DATE,
    CAST(sd.stage2 AS date) AS OPP_STAGE_2_DATE,
    CAST(sd.stage3 AS date) AS OPP_STAGE_3_DATE,
    CAST(sd.stage4 AS date) AS OPP_STAGE_4_DATE,
    CAST(sd.stage5 AS date) AS OPP_STAGE_5_DATE,
    CAST(sd.win AS date) AS OPP_WIN_DATE,
    
    -- Stage Velocity (calculated inline)
    DATEDIFF(day, CAST(opp.created_date AS date), CAST(sd.stage1 AS date)) AS OPP_STAGE_DELTA_DAYS_OPPCREATION_STAGE_1,
    DATEDIFF(day, CAST(sd.stage0 AS date), CAST(sd.stage1 AS date)) AS OPP_STAGE_DELTA_DAYS_STAGE_0_STAGE_1,
    DATEDIFF(day, CAST(sd.stage1 AS date), CAST(sd.stage2 AS date)) AS OPP_STAGE_DELTA_DAYS_STAGE_1_STAGE_2,
    DATEDIFF(day, CAST(sd.stage2 AS date), CAST(sd.stage3 AS date)) AS OPP_STAGE_DELTA_DAYS_STAGE_2_STAGE_3,
    DATEDIFF(day, CAST(sd.stage3 AS date), CAST(sd.stage4 AS date)) AS OPP_STAGE_DELTA_DAYS_STAGE_3_STAGE_4,
    DATEDIFF(day, CAST(sd.stage4 AS date), CAST(sd.stage5 AS date)) AS OPP_STAGE_DELTA_DAYS_STAGE_4_STAGE_5,
    DATEDIFF(day, CAST(sd.stage5 AS date), CAST(sd.win AS date)) AS OPP_STAGE_DELTA_DAYS_STAGE_5_WIN,
    DATEDIFF(day, CAST(sd.stage1 AS date), CAST(sd.win AS date)) AS OPP_STAGE_DELTA_DAYS_STAGE_1_WIN,
    
    -- Global Unqualified Reason
    CASE
        WHEN (CASE 
                WHEN opp.ID IS NULL OR opp.STAGE_NAME IS NULL 
                     OR opp.STAGE_NAME IN ('Awaiting Auto-Renewal', 'Cancelled', 'Churn', 'Closed - Auto Renewal',
                                           'Closed - Migrated', 'Closed - Reduced', 'Closed - Terminated', 'Closed - Transfer',
                                           'Closed / Duplicate', 'Closed / Invalid', 'Closed Auto-Renewed',
                                           'Closed Booked - Cancelled', 'Paved - Invoice')
                THEN 'No Opp'
                WHEN opp.STAGE_NAME IN ('Closed - Booked', 'Closed - Booked (SO)', 'Closed - Parent', 'Closed - Ready to Book',
                                        'Closed Won', 'On Hold', 'Pending Additional Signature', 'Pending Approval', 'Pending Client Signature')
                THEN 'Closed - Booked'
                WHEN opp.STAGE_NAME IN ('Closed Lost', 'Closed Return to CDM', 'Closed Stalled', 'Closed/Unqualified', 'Stalled / At Risk')
                THEN 'Closed - Not Booked'
                ELSE 'Open'
              END) = 'No Opp' 
             OR opp.ID IS NULL
        THEN amlh.AMLH_UNQUALIFIED_REASON__C
        ELSE COALESCE(opp.LOSS_STALL_REASON__C, 'Missing')
    END AS GLOBAL_UNQUALIFIED_REASON,
    
    -- Global Unqualified Date Cohort
    CASE 
        WHEN (CASE
                WHEN opp.ID IS NULL OR opp.STAGE_NAME IS NULL 
                     OR opp.STAGE_NAME IN ('Awaiting Auto-Renewal', 'Cancelled', 'Churn', 'Closed - Auto Renewal',
                                           'Closed - Migrated', 'Closed - Reduced', 'Closed - Terminated', 'Closed - Transfer',
                                           'Closed / Duplicate', 'Closed / Invalid', 'Closed Auto-Renewed',
                                           'Closed Booked - Cancelled', 'Paved - Invoice')
                THEN amlh.AMLH_UNQUALIFIED_REASON__C
                ELSE COALESCE(opp.LOSS_STALL_REASON__C, 'Missing')
              END) IS NOT NULL
        THEN CASE 
                WHEN sd.stage5 IS NOT NULL THEN 'STAGE_5'
                WHEN sd.stage4 IS NOT NULL THEN 'STAGE_4'
                WHEN sd.stage3 IS NOT NULL THEN 'STAGE_3'
                WHEN sd.stage2 IS NOT NULL THEN 'STAGE_2'
                WHEN sd.stage1 IS NOT NULL THEN 'STAGE_1'
                WHEN sd.stage0 IS NOT NULL THEN 'STAGE_0'
                WHEN amlh.AMLH_SUSPECT_DATE_STAMP__C IS NOT NULL THEN 'SUSPECT'
                WHEN amlh.AMLH_MQA_DATE_STAMP__C IS NOT NULL THEN 'MQA'
                WHEN amlh.AMLH_MEA_DATE_STAMP__C IS NOT NULL THEN 'MEA'
                WHEN amlh.AMLH_COLD_ACCOUNT_DATE_STAMP__C IS NOT NULL THEN 'COLD'
                ELSE 'No Date'
             END
        ELSE 'No Date'
    END AS OPP_GLOBAL_UNQUALIFIED_DATE_COHORT,
    
    -- Opp Stage Lost
    CASE 
        WHEN opp.CLOSE_DATE < sd.stage1 THEN 'STAGE_0'
        WHEN opp.CLOSE_DATE BETWEEN sd.stage1 AND sd.stage2 THEN 'STAGE_1'
        WHEN opp.CLOSE_DATE BETWEEN sd.stage2 AND sd.stage3 THEN 'STAGE_2'
        WHEN opp.CLOSE_DATE BETWEEN sd.stage3 AND sd.stage4 THEN 'STAGE_3'
        WHEN opp.CLOSE_DATE BETWEEN sd.stage4 AND sd.stage5 THEN 'STAGE_4'
        WHEN opp.CLOSE_DATE > sd.stage5 THEN 'STAGE_5'
        ELSE NULL
    END AS OPP_STAGE_LOST

FROM ACT_MRKT_LIFECYCLE.AMLH AS amlh
LEFT JOIN opp_with_details AS opp 
    ON amlh.ACT_ID = opp.ACCOUNT_ID
    AND amlh.AMLH_OPPORTUNITY__C = opp.ID
    AND opp.PARENT_OPPORTUNITY__C IS NULL
LEFT JOIN opp_stage_dates_base AS sd 
    ON amlh.AMLH_OPPORTUNITY__C = sd.opportunity_id;

RAISE INFO 'Step 9 complete: AMLH_OPPS table created';

-- =============================================================================
-- STEP 10: Cleanup temporary tables
-- =============================================================================
DROP TABLE IF EXISTS amlh_temp_base;
DROP TABLE IF EXISTS amlh_temp_normalized;
DROP TABLE IF EXISTS amlh_temp_journey_orders;
DROP TABLE IF EXISTS amlh_temp_journey_flags;
DROP TABLE IF EXISTS amlh_temp_all_deltas;
DROP TABLE IF EXISTS opp_stage_dates_base;

RAISE INFO 'ETL Complete: All tables created successfully';

-- =============================================================================
-- Summary of Optimizations Applied:
-- =============================================================================
-- 1. Reduced 8+ levels of nested subqueries to sequential temp tables
-- 2. Consolidated 20 delta temp tables into 1 single-pass calculation
-- 3. Added integer order columns (AMLH_COLD_ORDER, etc.) for efficient comparisons
-- 4. Extracted opportunity stage pivot query once and reused
-- 5. Added DISTKEY/SORTKEY for optimal Redshift performance
-- 6. Removed redundant DISTINCT keywords
-- 7. Simplified nonlinear flag logic with consolidated CASE statements
-- 8. Used CTEs instead of correlated subqueries where possible
-- =============================================================================
