-- overlap in dates shows that the data in public.web_visit is correct

SELECT 
    COALESCE(pub.date_visited, prod.date_visited) as date_visited,
    pub.sum_total as public_total,
    prod.sum_total as prod_total,
    pub.sum_total - prod.sum_total as difference
FROM (
    SELECT date_visited, SUM(total) as sum_total
    FROM public.web_visit
    GROUP BY date_visited
) pub
INNER JOIN (
    SELECT date_visited, SUM(total) as sum_total
    FROM dp_prod_db.six_sense.web_visit
    GROUP BY date_visited
) prod ON pub.date_visited = prod.date_visited
ORDER BY date_visited;

-- number of nulls reduced 

SELECT
    COALESCE(prod.date_visited, pub.date_visited) as date_visited,
    COALESCE(prod.url, pub.url) as url,
    prod.null_count as prod_null_record_creation_ts,
    pub.null_count as public_null_record_creation_ts,
    prod.null_count - pub.null_count as difference
FROM (
    SELECT
        date_visited,
        url,
        COUNT() as null_count
    FROM dp_prod_db.six_sense.web_visit
    WHERE date_visited > '2025-03-31'
        AND record_creation_ts IS NULL
    GROUP BY date_visited, url
) prod
FULL OUTER JOIN (
    SELECT
        date_visited,
        url,
        COUNT() as null_count
    FROM public.web_visit
    WHERE date_visited > '2025-03-31'
        AND record_creation_ts IS NULL
    GROUP BY date_visited, url
) pub
    ON prod.date_visited = pub.date_visited
    AND prod.url = pub.url
ORDER BY COALESCE(prod.null_count, pub.null_count) DESC;

-- missing data present 

select date_visited, 
    count(*)
from public.web_visit
    where date_visited between '2025-04-25' and '2025-05-03'
       or date_visited between '2025-05-13' and '2025-06-02'
group by date_visited
order by date_visited 

-- Inflated from April 13th to the 24th, that is resolved

select date_visited, 
    count(*)
from public.web_visit
    where date_visited between '2025-04-13' and '2025-04-24'
group by date_visited
order by date_visited 

-- colnames and datatypes match

SELECT 
    COALESCE(prod.column_name, pub.column_name) as column_name,
    prod.data_type as prod_data_type,
    pub.data_type as public_data_type,
    CASE 
        WHEN prod.column_name IS NULL THEN 'Missing in prod'
        WHEN pub.column_name IS NULL THEN 'Missing in public'
        WHEN prod.data_type != pub.data_type THEN 'Type mismatch'
        ELSE 'Match'
    END as status
FROM (
    SELECT column_name, data_type
    FROM information_schema.columns
    WHERE table_schema = 'six_sense' 
        AND table_name = 'web_visit'
) prod
FULL OUTER JOIN (
    SELECT column_name, data_type
    FROM information_schema.columns
    WHERE table_schema = 'public' 
        AND table_name = 'web_visit'
) pub ON prod.column_name = pub.column_name
ORDER BY column_name;

-- reduction in NULLs overall, maybe overkill, but maybe not

SELECT 
    'crm_account_name' as column_name,
    SUM(CASE WHEN crm_account_name IS NULL THEN 1 ELSE 0 END) as prod_null_count,
    (SELECT SUM(CASE WHEN crm_account_name IS NULL THEN 1 ELSE 0 END) FROM public.web_visit WHERE date_visited > '2025-03-31') as public_null_count
FROM dp_prod_db.six_sense.web_visit
WHERE date_visited > '2025-03-31'

UNION ALL

SELECT 
    'crm_account_country',
    SUM(CASE WHEN crm_account_country IS NULL THEN 1 ELSE 0 END),
    (SELECT SUM(CASE WHEN crm_account_country IS NULL THEN 1 ELSE 0 END) FROM public.web_visit WHERE date_visited > '2025-03-31')
FROM dp_prod_db.six_sense.web_visit
WHERE date_visited > '2025-03-31'

UNION ALL

SELECT 
    'crm_account_domain',
    SUM(CASE WHEN crm_account_domain IS NULL THEN 1 ELSE 0 END),
    (SELECT SUM(CASE WHEN crm_account_domain IS NULL THEN 1 ELSE 0 END) FROM public.web_visit WHERE date_visited > '2025-03-31')
FROM dp_prod_db.six_sense.web_visit
WHERE date_visited > '2025-03-31'

UNION ALL

SELECT 
    'url',
    SUM(CASE WHEN url IS NULL THEN 1 ELSE 0 END),
    (SELECT SUM(CASE WHEN url IS NULL THEN 1 ELSE 0 END) FROM public.web_visit WHERE date_visited > '2025-03-31')
FROM dp_prod_db.six_sense.web_visit
WHERE date_visited > '2025-03-31'

UNION ALL

SELECT 
    'event',
    SUM(CASE WHEN event IS NULL THEN 1 ELSE 0 END),
    (SELECT SUM(CASE WHEN event IS NULL THEN 1 ELSE 0 END) FROM public.web_visit WHERE date_visited > '2025-03-31')
FROM dp_prod_db.six_sense.web_visit
WHERE date_visited > '2025-03-31'

UNION ALL

SELECT 
    'referrer_domain',
    SUM(CASE WHEN referrer_domain IS NULL THEN 1 ELSE 0 END),
    (SELECT SUM(CASE WHEN referrer_domain IS NULL THEN 1 ELSE 0 END) FROM public.web_visit WHERE date_visited > '2025-03-31')
FROM dp_prod_db.six_sense.web_visit
WHERE date_visited > '2025-03-31'

UNION ALL

SELECT 
    'utm_source',
    SUM(CASE WHEN utm_source IS NULL THEN 1 ELSE 0 END),
    (SELECT SUM(CASE WHEN utm_source IS NULL THEN 1 ELSE 0 END) FROM public.web_visit WHERE date_visited > '2025-03-31')
FROM dp_prod_db.six_sense.web_visit
WHERE date_visited > '2025-03-31'

UNION ALL

SELECT 
    'utm_medium',
    SUM(CASE WHEN utm_medium IS NULL THEN 1 ELSE 0 END),
    (SELECT SUM(CASE WHEN utm_medium IS NULL THEN 1 ELSE 0 END) FROM public.web_visit WHERE date_visited > '2025-03-31')
FROM dp_prod_db.six_sense.web_visit
WHERE date_visited > '2025-03-31'

UNION ALL

SELECT 
    'total',
    SUM(CASE WHEN total IS NULL THEN 1 ELSE 0 END),
    (SELECT SUM(CASE WHEN total IS NULL THEN 1 ELSE 0 END) FROM public.web_visit WHERE date_visited > '2025-03-31')
FROM dp_prod_db.six_sense.web_visit
WHERE date_visited > '2025-03-31'

UNION ALL

SELECT 
    'date_visited',
    SUM(CASE WHEN date_visited IS NULL THEN 1 ELSE 0 END),
    (SELECT SUM(CASE WHEN date_visited IS NULL THEN 1 ELSE 0 END) FROM public.web_visit WHERE date_visited > '2025-03-31')
FROM dp_prod_db.six_sense.web_visit
WHERE date_visited > '2025-03-31'

UNION ALL

SELECT 
    '6sense_mid',
    SUM(CASE WHEN "6sense_mid" IS NULL THEN 1 ELSE 0 END),
    (SELECT SUM(CASE WHEN "6sense_mid" IS NULL THEN 1 ELSE 0 END) FROM public.web_visit WHERE date_visited > '2025-03-31')
FROM dp_prod_db.six_sense.web_visit
WHERE date_visited > '2025-03-31'

UNION ALL

SELECT 
    '6sense_account_name',
    SUM(CASE WHEN "6sense_account_name" IS NULL THEN 1 ELSE 0 END),
    (SELECT SUM(CASE WHEN "6sense_account_name" IS NULL THEN 1 ELSE 0 END) FROM public.web_visit WHERE date_visited > '2025-03-31')
FROM dp_prod_db.six_sense.web_visit
WHERE date_visited > '2025-03-31'

UNION ALL

SELECT 
    '6sense_account_country',
    SUM(CASE WHEN "6sense_account_country" IS NULL THEN 1 ELSE 0 END),
    (SELECT SUM(CASE WHEN "6sense_account_country" IS NULL THEN 1 ELSE 0 END) FROM public.web_visit WHERE date_visited > '2025-03-31')
FROM dp_prod_db.six_sense.web_visit
WHERE date_visited > '2025-03-31'

UNION ALL

SELECT 
    '6sense_account_domain',
    SUM(CASE WHEN "6sense_account_domain" IS NULL THEN 1 ELSE 0 END),
    (SELECT SUM(CASE WHEN "6sense_account_domain" IS NULL THEN 1 ELSE 0 END) FROM public.web_visit WHERE date_visited > '2025-03-31')
FROM dp_prod_db.six_sense.web_visit
WHERE date_visited > '2025-03-31'

UNION ALL

SELECT 
    'record_creation_ts',
    SUM(CASE WHEN record_creation_ts IS NULL THEN 1 ELSE 0 END),
    (SELECT SUM(CASE WHEN record_creation_ts IS NULL THEN 1 ELSE 0 END) FROM public.web_visit WHERE date_visited > '2025-03-31')
FROM dp_prod_db.six_sense.web_visit
WHERE date_visited > '2025-03-31'

UNION ALL

SELECT 
    'utm_content',
    SUM(CASE WHEN utm_content IS NULL THEN 1 ELSE 0 END),
    (SELECT SUM(CASE WHEN utm_content IS NULL THEN 1 ELSE 0 END) FROM public.web_visit WHERE date_visited > '2025-03-31')
FROM dp_prod_db.six_sense.web_visit
WHERE date_visited > '2025-03-31'

UNION ALL

SELECT 
    'utm_campaign',
    SUM(CASE WHEN utm_campaign IS NULL THEN 1 ELSE 0 END),
    (SELECT SUM(CASE WHEN utm_campaign IS NULL THEN 1 ELSE 0 END) FROM public.web_visit WHERE date_visited > '2025-03-31')
FROM dp_prod_db.six_sense.web_visit
WHERE date_visited > '2025-03-31'

UNION ALL

SELECT 
    'utm_term',
    SUM(CASE WHEN utm_term IS NULL THEN 1 ELSE 0 END),
    (SELECT SUM(CASE WHEN utm_term IS NULL THEN 1 ELSE 0 END) FROM public.web_visit WHERE date_visited > '2025-03-31')
FROM dp_prod_db.six_sense.web_visit
WHERE date_visited > '2025-03-31';

-- outliers in old data set, they will be replaced by Rohan

WITH daily_counts AS (
    SELECT 
        date_visited,
        COUNT(*) as row_count,
        'dp_prod_db' as schema
    FROM dp_prod_db.six_sense.web_visit
    WHERE date_visited > '2025-03-31'
    GROUP BY date_visited
    
    UNION ALL
    
    SELECT 
        date_visited,
        COUNT(*) as row_count,
        'public' as schema
    FROM public.web_visit
    WHERE date_visited > '2025-03-31'
    GROUP BY date_visited
),
stats AS (
    SELECT 
        schema,
        AVG(row_count) as avg_rows,
        STDDEV(row_count) as stddev_rows
    FROM daily_counts
    GROUP BY schema
)
SELECT 
    d.date_visited,
    d.row_count,
    d.schema,
    s.avg_rows,
    s.stddev_rows,
    (d.row_count - s.avg_rows) / NULLIF(s.stddev_rows, 0) as std_deviations_from_mean,
    CASE 
        WHEN ABS((d.row_count - s.avg_rows) / NULLIF(s.stddev_rows, 0)) > 2 THEN 'OUTLIER'
        ELSE 'Normal'
    END as status
FROM daily_counts d
JOIN stats s ON d.schema = s.schema
WHERE ABS((d.row_count - s.avg_rows) / NULLIF(s.stddev_rows, 0)) > 2
ORDER BY ABS((d.row_count - s.avg_rows) / NULLIF(s.stddev_rows, 0)) DESC;

