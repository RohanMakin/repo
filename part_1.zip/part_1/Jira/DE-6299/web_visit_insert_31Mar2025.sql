-- 1. Insert Validated Data From Temporary Table
INSERT INTO six_sense.web_visit (
    crm_account_id,
    crm_account_name,
    crm_account_country,
    crm_account_domain,
    url,
    event,
    referrer_domain,
    utm_source,
    utm_medium,
    total,
    date_visited,
    "6SENSE_MID",
    "6SENSE_ACCOUNT_NAME",
    "6SENSE_ACCOUNT_COUNTRY",
    "6SENSE_ACCOUNT_DOMAIN",
    record_creation_ts,
    utm_content,
    utm_campaign,
    utm_term
)
SELECT
    crm_account_id,
    crm_account_name,
    crm_account_country,
    crm_account_domain,
    url,
    event,
    referrer_domain,
    utm_source,
    utm_medium,
    total,
    date_visited,
    "6SENSE_MID",
    "6SENSE_ACCOUNT_NAME",
    "6SENSE_ACCOUNT_COUNTRY",
    "6SENSE_ACCOUNT_DOMAIN",
    record_creation_ts,
    utm_content,
    utm_campaign,
    utm_term
FROM public.web_visit
WHERE TO_DATE(date_visited, 'YYYY-MM-DD') = DATE '2025-03-31';

-- 2. Verify Insert
SELECT COUNT(*) AS inserted_rows
FROM six_sense.web_visit
WHERE TO_DATE(date_visited, 'YYYY-MM-DD') = DATE '2025-03-31';

SELECT COUNT(*) AS temp_rows
FROM public.web_visit
WHERE TO_DATE(date_visited, 'YYYY-MM-DD') = DATE '2025-03-31';
