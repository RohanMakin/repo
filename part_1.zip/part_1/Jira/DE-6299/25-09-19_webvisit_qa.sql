-- New script in dp_prod_db 2.
-- Date: Sep 22, 2025
-- Time: 12:28:50 PM
-- New script in dp_prod_db 2.
-- Date: Sep 22, 2025
-- Time: 12:02:49 PM
-- Redshift web visit data check

WITH webvisit_base AS (
    SELECT
        CRM_ACCOUNT_ID,
        DATE_VISITED,
        UTM_SOURCE,
        UTM_MEDIUM,
        UTM_CAMPAIGN,
        UTM_CONTENT,
        UTM_TERM,
        URL,
        REFERRER_DOMAIN,
        COALESCE("unclassified", 0) AS Total_unclassified,
        COALESCE("a_pageload", 0) AS Total_a_pageload,
        COALESCE("play", 0) AS Total_play,
        COALESCE("click", 0) AS Total_click,
        COALESCE("submit", 0) AS Total_submit,
        COALESCE("a_pageload", 0) + COALESCE("play", 0) + COALESCE("click", 0) + COALESCE("submit", 0) AS Total_interaction
    FROM (
        SELECT * FROM SIX_SENSE.WEB_VISIT
        PIVOT (
            SUM(TOTAL) FOR EVENT IN ('unclassified', 'a_pageload', 'play', 'click', 'submit')
        )
    )
)
--SELECT COUNT(*) FROM (
    SELECT
        DATE_VISITED,
        UTM_SOURCE,
        UTM_MEDIUM,
        SUM(1) AS num_records,
        SUM(COALESCE(Total_unclassified, 0)) AS Total_unclassified,
        SUM(COALESCE(Total_a_pageload, 0)) AS Total_a_pageload,
        SUM(COALESCE(Total_play, 0)) AS Total_play,
        SUM(COALESCE(Total_click, 0)) AS Total_click,
        SUM(COALESCE(Total_submit, 0)) AS Total_submit,
        SUM(COALESCE(Total_a_pageload, 0) + COALESCE(Total_play, 0) + COALESCE(Total_click, 0) + COALESCE(Total_submit, 0)) AS Total_interaction
    FROM webvisit_base
    WHERE CRM_ACCOUNT_ID IS NOT NULL
    GROUP BY DATE_VISITED, UTM_SOURCE, UTM_MEDIUM
    ORDER BY DATE_VISITED
--);