import logging
import pytz
from datetime import timedelta, datetime
from airflow import DAG
from airflow.providers.slack.hooks.slack_webhook import SlackWebhookHook
from airflow.providers.postgres.hooks.postgres import PostgresHook
from airflow.operators.python import PythonOperator
from airflow.operators.dummy import DummyOperator
from config.env_config import CONFIG
from airflow.models import Variable

env = Variable.get("env")
redshift_bt_conn = CONFIG[env]['redshift_bt_conn']
redshift_bt_db = CONFIG[env]['redshift_bt_db']
slack_conn = CONFIG[env]['slack_conn']


# Alerts the dataplatform_alerts_channel of any errors
def task_fail_slack_alert(context):
    shifted_time = context.get('execution_date').astimezone(pytz.timezone('US/Pacific')).strftime('%m-%d-%Y %H:%M:%S')

    slack_msg = f"""
            :red_circle: Task Failed. See details below:
            *Task*: {context.get('task_instance').task_id}
            *Dag*: {context.get('task_instance').dag_id}
            *Execution Time*: {shifted_time}
            *Log Url*: {context.get('task_instance').log_url}
            """

    try:
        hook = SlackWebhookHook(
            slack_webhook_conn_id=slack_conn
        )
        hook.send(text=slack_msg)
        print('Slack alert sent successfully')
    except Exception as e:
        print('Failed to send slack alert - ', e)


args = {
    'owner': 'Rohan Makin',
    'start_date': datetime(2025, 11, 13),
    'email': ['rohan.makin@lytx.com'],  # notification email
    'email_on_failure': False,
    'on_failure_callback': task_fail_slack_alert,
    'retries': 3,
    'retry_delay': timedelta(minutes=5),
}

dag = DAG(
    dag_id='run_mqa_report_tables_v1_11',
    default_args=args,
    schedule_interval='0 5 * * *',  # 9 PM PST
    dagrun_timeout=timedelta(minutes=120),
    catchup=False,
)


def execute_mqa_report_tables_v1_11():
    hook = PostgresHook(postgres_conn_id=redshift_bt_conn)
    sql = f"CALL {redshift_bt_db}.act_mrkt_lifecycle.mqa_report_tables_v1_11(result => NULL);"
    try:
        logging.info(f"Executing stored procedure: {sql}")
        hook.run(sql)
        logging.info("Stored procedure executed successfully!")
    except Exception as e:
        logging.error(f"Error executing stored procedure: {str(e)}")
        raise


start_task = DummyOperator(task_id='start_task', dag=dag)

run_procedure = PythonOperator(
    task_id='execute_mqa_report_tables_v1_11',
    python_callable=execute_mqa_report_tables_v1_11,
    dag=dag,
    )

end_task = DummyOperator(task_id='end_task', dag=dag)

start_task >> run_procedure >> end_task
