-- DROP PROCEDURE act_mrkt_lifecycle.mqa_report_tables_v1_11(out varchar);

CREATE OR REPLACE PROCEDURE act_mrkt_lifecycle.mqa_report_tables_v1_11(out result varchar)
	LANGUAGE plpgsql
AS $$
	
	
DECLARE
  min_val int;
BEGIN
-- Step 01a: ACCOUNT MARKETING LIFECYCLE TABLE TEMP TABLE

 drop materialized view if exists act_mrkt_lifecycle.AMLH_TEMP_MV_1;
 
 CREATE MATERIALIZED VIEW act_mrkt_lifecycle.AMLH_TEMP_MV_1 DISTSTYLE ALL AS

SELECT
    *
FROM
    (
        SELECT distinct
            -- Account Info
            act.ID AS ACT_ID,
            -- Account Info
            act.ISDELETED AS ACT_IS_DELETED,
            act.NAME AS ACT_NAME,
            usr.NAME AS ACT_OWNER,
            usr_role.NAME AS ACT_OWNER_ROLE,
            usro.NAME AS ACT_OPENER,
            act.CREATEDDATE AS ACT_CREATED_DATE,
            act.RECORDTYPEID AS ACT_RECORD_TYPE_ID,
            rcd.NAME AS ACT_RECORD_TYPE_ID_NAME,
            act.MARKETING_LIFECYCLE_AT_SUSPECT__C AS ACT_MARKETING_LIFECYCLE_AT_SUSPECT__C,
            act.BUYING_STAGE_AT_SUSPECT__C AS ACT_BUYING_STAGE_AT_SUSPECT__C,
            act.MARKETING_LIFECYCLE__C AS ACT_MARKETING_LIFECYCLE__C,
            act.BUSINESS_UNIT_2020__C AS ACT_BUSINESS_UNIT_2020__C,
            act.BUSINESS_UNIT_DIVISION__C AS ACT_BUSINESS_UNIT_DIVISION__C,
           -- act.BILLING_MODEL__C as ACT_BILLING_MODEL__C,
            act.MARKET__C AS ACT_MARKET__C,
            act.FLEET_SIZE__C AS ACT_FLEET_SIZE__C,
            act.MARKET_SEGMENT__C AS ACT_MARKET_SEGMENT__C,
            CASE 
				WHEN act.MARKET_SEGMENT__C IN ('Trucking','Local') THEN 'Trucking and Local' 
				WHEN act.MARKET_SEGMENT__C IN ('NA') OR act.MARKET_SEGMENT__C IS NULL THEN 'Not Categorized' 
				ELSE act.MARKET_SEGMENT__C END AS ACT_MARKET_SEGMENT__C_GROUP,
            act.INDUSTRY AS ACT_INDUSTRY,
            act.INDUSTRY_DB__C AS ACT_INDUSTRY_DB__C,
            act.INDUSTRY_SECTOR__C AS ACT_INDUSTRY_SECTOR__C,
            act.TERRITORY__C AS ACT_TERRITORY__C,
            act.GEOGRAPHIC_REGION__C AS ACT_GEOGRAPHIC_REGION__C,
            act.STATE_DB__C AS ACT_STATE_DB__C,
			act.FIT_MODEL_TIER__C AS ACT_FIT_MODEL_TIER__C,
            act.ACCOUNTPROFILEFIT6SENSE__C AS ACT_ACCOUNT_PROFILE_FIT6SENSE__C,
            act.ACCOUNTPROFILESCORE6SENSE__C AS ACT_ACCOUNT_PROFILE_SCORE6SENSE__C,
            act.INTERNAL_TEST_ACCOUNT__C AS ACT_INTERNAL_TEST_ACCOUNT__C,
            act.ROUTING_REASON__C AS ACT_ROUTING_REASON__C,
            act.MIGRATION_RETURN_TO_MARKETING_REASON__C AS ACT_MIGRATION_RETURN_TO_MARKETING_REASON__C,
            act.STATUS__C AS ACT_STATUS__C,
            act.BUYER_TYPE__C as ACT_BUYER_TYPE__C,
			-- 20250302
			act.CAMPAIGN_TEXT__C AS ACT_CAMPAIGN_TEXT__C,
            act.BILLING_MODEL__C AS ACT_BILLING_MODEL__C,
            act.REGION__C AS ACT_REGION__C,
            act.BILLINGSTATE AS ACT_BILLING_STATE,
            CASE
                WHEN act.STATUS__C IN (
                    'Data Review',
                    'Initial Trial',
                    'Initial Trial Pending',
                    'Prospect',
                    'Suspect'
                ) THEN 'Active with Sales'
                WHEN act.STATUS__C IN (
                    'Client',
                    'Pending Client',
                    'Pending Client - Contract Signed'
                ) THEN 'Client'
                WHEN act.STATUS__C IN (
                    'Prospect Nuture',
                    'Recycle',
                    'Suspect Nurture',
                    'Suspect Nuture'
                ) THEN 'Marketing Engagement'
                WHEN act.STATUS__C IN (
                    'Active',
                    'Inactive',
                    'Industry Org',
                    'Non-Contractual',
                    'Other'
                ) THEN 'Other/NA'
                WHEN act.STATUS__C IN (
                    'Pending Forward Consent',
                    'Referred to Partner'
                ) THEN 'Referred to Partner'
                WHEN act.STATUS__C IN (
                    'SERVICE SUSPENDED',
                    'SERVICE TERMINATED',
                    'Terminated'
                ) THEN 'Service Terminated'
                WHEN act.STATUS__C IN (
                    'DOA',
                    'Duplicate',
                    'Duplicate - 6Sense',
                    'Out of Business',
                    'Unqualified'
                ) THEN 'Unqualified'
            END AS ACT_STATUS_GROUP,
            act.UNQUALIFIED_REASON__C AS ACT_UNQUALIFIED_REASON__C,
            -- Account Journey Pathx
            act_journey.AMLH_NAME,
            act_journey.ACCOUNT__C AS AMLH_ACCOUNT__C,
            act_journey.RECYCLE_COUNTER__C AS AMLH_RECYCLE_COUNTER__C,
            act_journey.CREATED_DATE AS AMLH_CREATED_DATE,
            act_journey.ACTIVE_MARKETING_LIFECYCLE_RECORD__C AS AMLH_ACTIVE_MARKETING_LIFECYCLE_RECORD__C,
            act_journey.MARKETING_LIFECYCLE_AT_SUSPECT__C AS AMLH_MARKETING_LIFECYCLE_AT_SUSPECT__C,
            act_journey.BUYING_STAGE_AT_SUSPECT__C AS AMLH_BUYING_STAGE_AT_SUSPECT__C,
            act_journey.ROUTING_REASON__C AS AMLH_ROUTING_REASON__C,
            act_journey.UNQUALIFIED_REASON__C AS AMLH_UNQUALIFIED_REASON__C,
            act_journey.OPPORTUNITY__C AS AMLH_OPPORTUNITY__C,
            act_journey.ACT_JOURNEY_PATH AS AMLH_ACT_JOURNEY_PATH,
            act_journey.ACT_JOURNEY_PATH_CNT AS AMLH_ACT_JOURNEY_PATH_CNT,
            act_journey.ACT_JOURNEY_PATH_ID AS AMLH_ACT_JOURNEY_PATH_ID,
            act_journey.ACCOUNT_JOURNEY_PATH_LIFECYCLE_NONLINEAR_FLAG AS AMLH_ACCOUNT_JOURNEY_PATH_LIFECYCLE_NONLINEAR_FLAG,
            act_journey.ACCOUNT_JOURNEY_PATH_LIFECYCLE_NONLINEAR_FLAG_REASON AS AMLH_ACCOUNT_JOURNEY_PATH_LIFECYCLE_NONLINEAR_FLAG_REASON,
            -- Lifecycle Stages
            
            act.COLD_ACCOUNT_DATE_STAMP__C as ACT_COLD_ACCOUNT_DATE_STAMP__C,
            CAST(act.COLD_ACCOUNT_DATE_STAMP__C as DATE) AS ACT_COLD_ACCOUNT_DATE_STAMP__C_CAST,
            amlh_raw.COLD_ACCOUNT_DATE_STAMP__C AS AMLH_COLD_ACCOUNT_DATE_STAMP__C,
            CAST(amlh_raw.COLD_ACCOUNT_DATE_STAMP__C as DATE) AS AMLH_COLD_ACCOUNT_DATE_STAMP__C_CAST,
            
            cast(date_trunc('week',amlh_raw.COLD_ACCOUNT_DATE_STAMP__C) + '6 days'::interval as date) as AMLH_COLD_ACCOUNT_DATE_EOW,
            last_day(amlh_raw.COLD_ACCOUNT_DATE_STAMP__C) as AMLH_COLD_ACCOUNT_DATE_EOM,
            cast(dateadd(day, -1, dateadd(QTR,1,DATE_TRUNC('QTR', amlh_raw.COLD_ACCOUNT_DATE_STAMP__C)))as date) as AMLH_COLD_ACCOUNT_DATE_EOQ,
            cast(dateadd(day, -1, dateadd(year, 1, DATE_TRUNC('year', amlh_raw.COLD_ACCOUNT_DATE_STAMP__C)))as date) as AMLH_COLD_ACCOUNT_DATE_EOY,
        
            act.MEA_DATE_STAMP__C as ACT_MEA_DATE_STAMP__C,
            CAST(act.MEA_DATE_STAMP__C as DATE) AS ACT_MEA_DATE_STAMP__C_CAST,
            amlh_raw.MEA_DATE_STAMP__C AS AMLH_MEA_DATE_STAMP__C,
            CAST(amlh_raw.MEA_DATE_STAMP__C as DATE) AS AMLH_MEA_DATE_STAMP__C_CAST,
            
            cast(date_trunc('week',amlh_raw.MEA_DATE_STAMP__C) + '6 days'::interval as date) as AMLH_MEA_DATE_EOW,
            last_day(amlh_raw.MEA_DATE_STAMP__C) as AMLH_MEA_DATE_EOM,
            cast(dateadd(day, -1, dateadd(QTR,1,DATE_TRUNC('QTR', amlh_raw.MEA_DATE_STAMP__C)))as date) as AMLH_MEA_DATE_EOQ,
            cast(dateadd(day, -1, dateadd(year, 1, DATE_TRUNC('year', amlh_raw.MEA_DATE_STAMP__C)))as date) as AMLH_MEA_DATE_EOY,
            

            act.MQA_DATE_STAMP__C as ACT_MQA_DATE_STAMP__C,
            CAST(act.MQA_DATE_STAMP__C as DATE) AS ACT_MQA_DATE_STAMP__C_CAST,
            amlh_raw.MQA_DATE_STAMP__C AS AMLH_MQA_DATE_STAMP__C,
            CAST(amlh_raw.MQA_DATE_STAMP__C as DATE) AS AMLH_MQA_DATE_STAMP__C_CAST,

            cast(date_trunc('week',amlh_raw.MQA_DATE_STAMP__C) + '6 days'::interval as date) as AMLH_MQA_DATE_EOW,
            last_day(amlh_raw.MQA_DATE_STAMP__C) as AMLH_MQA_DATE_EOM,
            cast(dateadd(day, -1, dateadd(QTR,1,DATE_TRUNC('QTR', amlh_raw.MQA_DATE_STAMP__C)))as date) as AMLH_MQA_DATE_EOQ,
            cast(dateadd(day, -1, dateadd(year, 1, DATE_TRUNC('year', amlh_raw.MQA_DATE_STAMP__C)))as date) as AMLH_MQA_DATE_EOY,
            
            
            act.SUSPECT_DATE_STAMP__C as ACT_SUSPECT_DATE_STAMP__C,
            CAST(act.SUSPECT_DATE_STAMP__C as DATE) AS ACT_SUSPECT_DATE_STAMP__C_CAST,
            amlh_raw.SUSPECT_DATE_STAMP__C AS AMLH_SUSPECT_DATE_STAMP__C,
            CAST(amlh_raw.SUSPECT_DATE_STAMP__C as DATE) AS AMLH_SUSPECT_DATE_STAMP__C_CAST,
            
            cast(date_trunc('week',amlh_raw.SUSPECT_DATE_STAMP__C) + '6 days'::interval as date) as AMLH_SUSPECT_DATE_EOW,
            last_day(amlh_raw.SUSPECT_DATE_STAMP__C) as AMLH_SUSPECT_DATE_EOM,
            cast(dateadd(day, -1, dateadd(QTR,1,DATE_TRUNC('QTR', amlh_raw.SUSPECT_DATE_STAMP__C)))as date) as AMLH_SUSPECT_DATE_EOQ,
            cast(dateadd(day, -1, dateadd(year, 1, DATE_TRUNC('year', amlh_raw.SUSPECT_DATE_STAMP__C)))as date) as AMLH_SUSPECT_DATE_EOY,                     
            
            
            act.SUSPECT_WORKING_DATE_STAMP__C as ACT_SUSPECT_WORKING_DATE_STAMP__C,
            CAST(act.SUSPECT_WORKING_DATE_STAMP__C as DATE) AS ACT_SUSPECT_WORKING_DATE_STAMP__C_CAST,
            amlh_raw.SUSPECT_WORKING_DATE_STAMP__C AS AMLH_SUSPECT_WORKING_DATE_STAMP__C,
            CAST(amlh_raw.SUSPECT_WORKING_DATE_STAMP__C as DATE) AS AMLH_SUSPECT_WORKING_DATE_STAMP__C_CAST,          
            
            
            cast(date_trunc('week',amlh_raw.SUSPECT_WORKING_DATE_STAMP__C) + '6 days'::interval as date) as AMLH_SUSPECT_WORKING_DATE_EOW,
            last_day(amlh_raw.SUSPECT_WORKING_DATE_STAMP__C) as AMLH_SUSPECT_WORKING_DATE_EOM,
            cast(dateadd(day, -1, dateadd(QTR,1,DATE_TRUNC('QTR', amlh_raw.SUSPECT_WORKING_DATE_STAMP__C)))as date) as AMLH_SUSPECT_WORKING_DATE_EOQ,
            cast(dateadd(day, -1, dateadd(year, 1, DATE_TRUNC('year', amlh_raw.SUSPECT_WORKING_DATE_STAMP__C)))as date) as AMLH_SUSPECT_WORKING_DATE_EOY,              
            
            
            act.PROSPECT_DATE_STAMP__C as ACT_PROSPECT_DATE_STAMP__C,
            CAST(act.PROSPECT_DATE_STAMP__C as DATE) AS ACT_PROSPECT_DATE_STAMP__C_CAST,
            amlh_raw.PROSPECT_DATE_STAMP__C AS AMLH_PROSPECT_DATE_STAMP__C,
            CAST(amlh_raw.PROSPECT_DATE_STAMP__C as DATE) AS AMLH_PROSPECT_DATE_STAMP__C_CAST,

            cast(date_trunc('week',amlh_raw.PROSPECT_DATE_STAMP__C) + '6 days'::interval as date) as AMLH_PROSPECT_DATE_EOW,
            last_day(amlh_raw.PROSPECT_DATE_STAMP__C) as AMLH_PROSPECT_DATE_EOM,
            cast(dateadd(day, -1, dateadd(QTR,1,DATE_TRUNC('QTR', amlh_raw.PROSPECT_DATE_STAMP__C)))as date) as AMLH_PROSPECT_DATE_EOQ,
            cast(dateadd(day, -1, dateadd(year, 1, DATE_TRUNC('year', amlh_raw.PROSPECT_DATE_STAMP__C)))as date) as AMLH_PROSPECT_DATE_EOY,                                     
            
            act.CUSTOMER_DATE_STAMP__C as ACT_CUSTOMER_DATE_STAMP__C,
            CAST(act.CUSTOMER_DATE_STAMP__C as DATE) AS ACT_CUSTOMER_DATE_STAMP__C_CAST,
            amlh_raw.CUSTOMER_DATE_STAMP__C AS AMLH_CUSTOMER_DATE_STAMP__C,
            CAST(amlh_raw.CUSTOMER_DATE_STAMP__C as DATE) AS AMLH_CUSTOMER_DATE_STAMP__C_CAST,
  
            cast(date_trunc('week',amlh_raw.CUSTOMER_DATE_STAMP__C) + '6 days'::interval as date) as AMLH_CUSTOMER_DATE_EOW,
            last_day(amlh_raw.CUSTOMER_DATE_STAMP__C) as AMLH_CUSTOMER_DATE_EOM,
            cast(dateadd(day, -1, dateadd(QTR,1,DATE_TRUNC('QTR', amlh_raw.CUSTOMER_DATE_STAMP__C)))as date) as AMLH_CUSTOMER_DATE_EOQ,
            cast(dateadd(day, -1, dateadd(year, 1, DATE_TRUNC('year', amlh_raw.CUSTOMER_DATE_STAMP__C)))as date) as AMLH_CUSTOMER_DATE_EOY,
            
            act.RECYCLED_DATE_STAMP__C as ACT_RECYCLED_DATE_STAMP__C,
            CAST(act.RECYCLED_DATE_STAMP__C as DATE) AS ACT_RECYCLED_DATE_STAMP__C_CAST,
            amlh_raw.RECYCLE_DATE_STAMP__C AS AMLH_RECYCLED_DATE_STAMP__C,
            CAST(amlh_raw.RECYCLE_DATE_STAMP__C as DATE) AS AMLH_RECYCLED_DATE_STAMP__C_CAST,
  
            cast(date_trunc('week',amlh_raw.RECYCLE_DATE_STAMP__C) + '6 days'::interval as date) as AMLH_RECYCLED_DATE_EOW,
            last_day(amlh_raw.RECYCLE_DATE_STAMP__C) as AMLH_RECYCLED_DATE_EOM,
            cast(dateadd(day, -1, dateadd(QTR,1,DATE_TRUNC('QTR', amlh_raw.RECYCLE_DATE_STAMP__C)))as date) as AMLH_RECYCLED_DATE_EOQ,
            cast(dateadd(day, -1, dateadd(year, 1, DATE_TRUNC('year', amlh_raw.RECYCLE_DATE_STAMP__C)))as date) as AMLH_RECYCLED_DATE_EOY,              
            
            act.UNQUALIFIED_DATE_STAMP__C as ACT_UNQUALIFIED_DATE_STAMP__C,
            CAST(act.UNQUALIFIED_DATE_STAMP__C as DATE) AS ACT_UNQUALIFIED_DATE_STAMP__C_CAST,
            amlh_raw.UNQUALIFIED_DATE_STAMP__C AS AMLH_UNQUALIFIED_DATE_STAMP__C,
            CAST(amlh_raw.UNQUALIFIED_DATE_STAMP__C as DATE) AS AMLH_UNQUALIFIED_DATE_STAMP__C_CAST,
            
            cast(date_trunc('week',amlh_raw.UNQUALIFIED_DATE_STAMP__C) + '6 days'::interval as date) as AMLH_UNQUALIFIED_DATE_EOW,
            last_day(amlh_raw.UNQUALIFIED_DATE_STAMP__C) as AMLH_UNQUALIFIED_DATE_EOM,
            cast(dateadd(day, -1, dateadd(QTR,1,DATE_TRUNC('QTR', amlh_raw.UNQUALIFIED_DATE_STAMP__C)))as date) as AMLH_UNQUALIFIED_DATE_EOQ,
            cast(dateadd(day, -1, dateadd(year, 1, DATE_TRUNC('year', amlh_raw.UNQUALIFIED_DATE_STAMP__C)))as date) as AMLH_UNQUALIFIED_DATE_EOY,                         
            
            amlh_raw.RECYCLE_EXP_DATE__C AS AMLH_RECYCLE_EXP_DATE__C,
            CAST(amlh_raw.RECYCLE_EXP_DATE__C as DATE) AS AMLH_RECYCLE_EXP_DATE__C_CAST,
            
            cast(date_trunc('week',amlh_raw.RECYCLE_EXP_DATE__C) + '6 days'::interval as date) as AMLH_RECYCLE_EXP_DATE__C_EOW,
            last_day(amlh_raw.RECYCLE_EXP_DATE__C) as AMLH_RECYCLE_EXP_DATE__C_EOM,
            cast(dateadd(day, -1, dateadd(QTR,1,DATE_TRUNC('QTR', amlh_raw.RECYCLE_EXP_DATE__C)))as date) as AMLH_RECYCLE_EXP_DATE__C_EOQ,
            cast(dateadd(day, -1, dateadd(year, 1, DATE_TRUNC('year', amlh_raw.RECYCLE_EXP_DATE__C)))as date) as AMLH_RECYCLE_EXP_DATE__C_EOY,             

			--20250315
			CASE WHEN amlh_raw.CUSTOMER_DATE_STAMP__C IS NULL THEN 'Null AMLH Customer Date' else 'Has AMLH Customer Date' END AS AMLH_EFFECTIVE_TYPE,
            COALESCE(amlh_raw.CUSTOMER_DATE_STAMP__C, '2222-01-01') AS AMLH_EFFECTIVE_DATE_STAMP__C,
            CAST(COALESCE(amlh_raw.CUSTOMER_DATE_STAMP__C, '2222-01-01') as DATE) AS AMLH_EFFECTIVE_DATE_STAMP__C_CAST,
  
            cast(date_trunc('week',CAST(COALESCE(amlh_raw.CUSTOMER_DATE_STAMP__C, '2222-01-01') as DATE)) + '6 days'::interval as date) as AMLH_EFFECTIVE_DATE_EOW,
            last_day(CAST(COALESCE(amlh_raw.CUSTOMER_DATE_STAMP__C, '2222-01-01') as DATE)) as AMLH_EFFECTIVE_DATE_EOM,
            cast(dateadd(day, -1, dateadd(QTR,1,DATE_TRUNC('QTR', CAST(COALESCE(amlh_raw.CUSTOMER_DATE_STAMP__C, '2222-01-01') as DATE))))as date) as AMLH_EFFECTIVE_DATE_EOQ,
            cast(dateadd(day, -1, dateadd(year, 1, DATE_TRUNC('year', CAST(COALESCE(amlh_raw.CUSTOMER_DATE_STAMP__C, '2222-01-01') as DATE))))as date) as AMLH_EFFECTIVE_DATE_EOY,            

            -- Lifecycle Stage Flags
            (
                CASE
                    WHEN amlh_raw.RECYCLE_DATE_STAMP__C IS NOT NULL THEN 'Recycled'
                    ELSE 'New'
                END
            ) AS AMLH_RECYCLED_VS_NEW_FLAG,
            CASE
                WHEN amlh_raw.MARKETING_LIFECYCLE_AT_SUSPECT__C IS NOT NULL THEN 1
                ELSE 0
            END AS AMLH_FLAG_HAS_MARKETING_LIFECYCLE_AT_SUSPECT__C,
            (
                CASE
                    WHEN amlh_raw.COLD_ACCOUNT_DATE_STAMP__C IS NOT NULL THEN 1
                    ELSE 0
                END
            ) AS AMLH_ACCOUNT_LIFECYCLE_COLD_FLAG,
            (
                CASE
                    WHEN amlh_raw.MEA_DATE_STAMP__C IS NOT NULL THEN 1
                    ELSE 0
                END
            ) AS AMLH_ACCOUNT_LIFECYCLE_MEA_FLAG,
            (
                CASE
                    WHEN amlh_raw.MQA_DATE_STAMP__C IS NOT NULL THEN 1
                    ELSE 0
                END
            ) AS AMLH_ACCOUNT_LIFECYCLE_MQA_FLAG,
            (
                CASE
                    WHEN amlh_raw.SUSPECT_DATE_STAMP__C IS NOT NULL THEN 1
                    ELSE 0
                END
            ) AS AMLH_ACCOUNT_LIFECYCLE_SUSPECT_FLAG,
            (
                CASE
                    WHEN amlh_raw.SUSPECT_WORKING_DATE_STAMP__C IS NOT NULL THEN 1
                    ELSE 0
                END
            ) AS AMLH_ACCOUNT_LIFECYCLE_SUSPECT_WORKING_FLAG,
            (
                CASE
                    WHEN amlh_raw.PROSPECT_DATE_STAMP__C IS NOT NULL THEN 1
                    ELSE 0
                END
            ) AS AMLH_ACCOUNT_LIFECYCLE_PROSPECT_FLAG,
            (
                CASE
                    WHEN amlh_raw.CUSTOMER_DATE_STAMP__C IS NOT NULL THEN 1
                    ELSE 0
                END             
            
            ) AS AMLH_ACCOUNT_LIFECYCLE_CUSTOMER_FLAG,
            (
                CASE
                    WHEN amlh_raw.RECYCLE_DATE_STAMP__C IS NOT NULL THEN 1
                    ELSE 0
                END
            ) AS AMLH_ACCOUNT_LIFECYCLE_RECYCLED_FLAG,
            (
                CASE
                    WHEN amlh_raw.UNQUALIFIED_DATE_STAMP__C IS NOT NULL THEN 1
                    ELSE 0
                END
            ) AS AMLH_ACCOUNT_LIFECYCLE_UNQUALIFIED_FLAG,
            (
                CASE
                    WHEN DATEDIFF(MINUTE, amlh_raw.SUSPECT_DATE_STAMP__C, amlh_raw.MQA_DATE_STAMP__C) between 0 and 2 THEN 1
                    ELSE 0
                END 
            ) AS AMLH_ACCOUNT_LIFECYCLE_SUSPECT_MQA_TIMESTAMP_FLAG,
            CASE
                WHEN amlh_raw.MARKETING_LIFECYCLE_AT_SUSPECT__C IS NULL THEN 'Not Eligible: No Lifecycle'
                WHEN (
                    CASE
                        WHEN amlh_raw.MARKETING_LIFECYCLE_AT_SUSPECT__C IS NULL THEN NULL
                        WHEN amlh_raw.MARKETING_LIFECYCLE_AT_SUSPECT__C = 'Cold Account' THEN amlh_raw.COLD_ACCOUNT_DATE_STAMP__C
                        WHEN amlh_raw.MARKETING_LIFECYCLE_AT_SUSPECT__C = 'MEA' THEN amlh_raw.MEA_DATE_STAMP__C
                        WHEN amlh_raw.MARKETING_LIFECYCLE_AT_SUSPECT__C = 'MQA' THEN amlh_raw.MQA_DATE_STAMP__C
                        WHEN amlh_raw.MARKETING_LIFECYCLE_AT_SUSPECT__C = 'Suspect Working' THEN amlh_raw.SUSPECT_WORKING_DATE_STAMP__C
                        WHEN amlh_raw.MARKETING_LIFECYCLE_AT_SUSPECT__C = 'Recycled' THEN amlh_raw.RECYCLE_DATE_STAMP__C
                        WHEN amlh_raw.MARKETING_LIFECYCLE_AT_SUSPECT__C = 'Unqualified' THEN amlh_raw.UNQUALIFIED_DATE_STAMP__C
                    END
                ) -- AS COMPARE_DATE,
                > amlh_raw.SUSPECT_DATE_STAMP__C THEN 'Not Eligible: Lifecycle > Suspect Date'
                WHEN (
                    amlh_raw.MARKETING_LIFECYCLE_AT_SUSPECT__C IS NOT NULL
                    AND amlh_raw.SUSPECT_DATE_STAMP__C IS NULL
                ) THEN 'Eligible: No Suspect Date'
                WHEN (
                    amlh_raw.MARKETING_LIFECYCLE_AT_SUSPECT__C IS NOT NULL
                    AND amlh_raw.SUSPECT_DATE_STAMP__C IS NOT NULL
                ) THEN 'Eligible: Has  Suspect Date'
                ELSE 'Other'
            END AS AMLH_FLAG_TO_CHECK,
            -- Parent Account Info
            (
                CASE
                    WHEN (act.PARENTID IS NULL) THEN 0
                    ELSE 1
                END
            ) AS ACT_HAS_PARENT_ACT_FLAG,
            (
                CASE
                    WHEN (act.PARENTID = '000000000000000AAA') THEN 1
                    ELSE 0
                END
            ) AS ACT_PARENT_ACT_FLAG,
            act.PARENTID AS ACT_PARENT_ID,
            parent_act.PARENT_ACT_IS_DELETED,
            parent_act.PARENT_ACT_NAME,
            parent_act.PARENT_ACT_CREATED_DATE,
            parent_act.PARENT_ACT_RECORD_TYPE_ID,
            parent_act.PARENT_ACT_RECORD_TYPE_ID_NAME,
            parent_act.PARENT_ACT_MARKETING_LIFECYCLE_AT_SUSPECT__C,
            parent_act.PARENT_ACT_MARKETING_LIFECYCLE__C,
            parent_act.PARENT_ACT_BUSINESS_UNIT_2020__C,
            parent_act.PARENT_ACT_BUSINESS_UNIT_DIVISION__C,
            parent_act.PARENT_ACT_MARKET__C,
            parent_act.PARENT_ACT_FLEET_SIZE__C,
            parent_act.PARENT_ACT_MARKET_SEGMENT__C,
            parent_act.PARENT_ACT_INDUSTRY,
            parent_act.PARENT_ACT_INDUSTRY_DB__C,
            parent_act.PARENT_ACT_INDUSTRY_SECTOR__C,
            parent_act.PARENT_ACT_TERRITORY__C,
            parent_act.PARENT_ACT_STATE_DB__C,
            parent_act.PARENT_ACT_FIT_MODEL_TIER__C,
            parent_act.PARENT_ACT_ACCOUNT_PROFILE_FIT6SENSE__C,
            parent_act.PARENT_ACT_ACCOUNT_PROFILE_SCORE6SENSE__C
        FROM
            SALESFORCE_BT.ACCOUNT AS act
            LEFT JOIN SALESFORCE_BT.USER usr 
                ON act.ownerid = usr.ID
                AND usr.NAME NOT IN ('Scott Rose', 'Rick Walters', 'Micah Rea', 'Compliance', 'ELD Compliance Manager')
            -- ACT OWNER USER ROLE
            LEFT JOIN SALESFORCE_BT.USERROLE usr_role 
                ON usr.USERROLEID = usr_role.ID
            LEFT JOIN SALESFORCE_BT.USER usro
                ON act.OPENER__C = usro.ID 
                AND usro.NAME NOT IN ('Scott Rose', 'Rick Walters', 'Micah Rea', 'Compliance', 'ELD Compliance Manager')              
            -- Record Type
            INNER JOIN SALESFORCE_BT.RECORDTYPE as rcd ON act.RECORDTYPEID = rcd.ID
            AND (
                rcd.ID = '012300000005VEYAA2'
                OR rcd.ID = '0126R000001UknZQAS'
            )
            -- Parent Account
            LEFT JOIN (
                -- Parent Account Information
                SELECT
                    DISTINCT act.ID,
                    parent_act.PARENTID,
                    parent_act.ISDELETED as PARENT_ACT_IS_DELETED,
                    parent_act.NAME as PARENT_ACT_NAME,
                    parent_act.CREATEDDATE as PARENT_ACT_CREATED_DATE,
                    parent_act.RECORDTYPEID as PARENT_ACT_RECORD_TYPE_ID,
                    rcd.NAME as PARENT_ACT_RECORD_TYPE_ID_NAME,
                    parent_act.MARKETING_LIFECYCLE_AT_SUSPECT__C as PARENT_ACT_MARKETING_LIFECYCLE_AT_SUSPECT__C,
                    parent_act.MARKETING_LIFECYCLE__C as PARENT_ACT_MARKETING_LIFECYCLE__C,
                    parent_act.BUSINESS_UNIT_2020__C as PARENT_ACT_BUSINESS_UNIT_2020__C,
                    parent_act.BUSINESS_UNIT_DIVISION__C as PARENT_ACT_BUSINESS_UNIT_DIVISION__C,
                    parent_act.MARKET__C as PARENT_ACT_MARKET__C,
                    parent_act.FLEET_SIZE__C as PARENT_ACT_FLEET_SIZE__C,
                    parent_act.MARKET_SEGMENT__C as PARENT_ACT_MARKET_SEGMENT__C,
                    parent_act.INDUSTRY as PARENT_ACT_INDUSTRY,
                    parent_act.INDUSTRY_DB__C as PARENT_ACT_INDUSTRY_DB__C,
                    parent_act.INDUSTRY_SECTOR__C as PARENT_ACT_INDUSTRY_SECTOR__C,
                    parent_act.TERRITORY__C as PARENT_ACT_TERRITORY__C,
                    parent_act.STATE_DB__C as PARENT_ACT_STATE_DB__C,
                    parent_act.FIT_MODEL_TIER__C as PARENT_ACT_FIT_MODEL_TIER__C,
                    parent_act.ACCOUNTPROFILEFIT6SENSE__C as PARENT_ACT_ACCOUNT_PROFILE_FIT6SENSE__C,
                    parent_act.ACCOUNTPROFILESCORE6SENSE__C as PARENT_ACT_ACCOUNT_PROFILE_SCORE6SENSE__C
                FROM
                    SALESFORCE_BT.ACCOUNT AS act
                    LEFT JOIN SALESFORCE_BT.ACCOUNT as parent_act ON act.parentid = parent_act.ID
                    LEFT JOIN SALESFORCE_BT.RECORDTYPE as rcd ON parent_act.RECORDTYPEID = rcd.ID
            ) as parent_act ON act.ID = parent_act.ID
            RIGHT OUTER JOIN (               

                SELECT
                    act_journey_prep.ACCOUNT__C,
                    act_journey_prep.RECYCLE_COUNTER__C,
                    act_journey_prep.CREATED_DATE,
                    act_journey_prep.ACTIVE_MARKETING_LIFECYCLE_RECORD__C,
                    act_journey_prep.MARKETING_LIFECYCLE_AT_SUSPECT__C,
                    act_journey_prep.BUYING_STAGE_AT_SUSPECT__C,
                    act_journey_prep.ROUTING_REASON__C,
                    act_journey_prep.UNQUALIFIED_REASON__C,
                    act_journey_prep.OPPORTUNITY__C,
                    act_journey_prep.ACCOUNT_JOURNEY_PATH_LIFECYCLE_NONLINEAR_FLAG_REASON,
                    act_journey_prep.ACCOUNT_JOURNEY_PATH_LIFECYCLE_NONLINEAR_FLAG,
                    act_journey_prep.ACT_JOURNEY_PATH_CNT,
                    act_journey_prep.NAME AS AMLH_NAME,                    
                        'COLD ' ||
                        cast(cold AS char(4)) ||
                        ' --> '||                        
                        'MEA '||
                        cast(mea as char(4)) ||
                        ' --> ' ||
                        'MQA ' ||
                        cast(mqa AS char(4)) ||
                        ' --> ' ||
                        'SUS ' ||
                        cast(suspect AS char(4)) ||
                        ' --> '||
                        'S_W ' ||
                        cast(suspect_working AS char(4)) ||
                        ' --> ' ||
                        'PROS ' ||
                        cast(prospect AS char(4)) ||
                        ' --> ' ||
                        'CUST ' ||
                        cast(customer AS char(4)) ||
                        ' --> ' ||
                        'REC ' ||
                        cast(recycled AS char(4)) ||
                        ' --> ' ||
                        'UNQ ' ||
                        cast(unqualified AS char(4))
                     AS act_journey_path,
                        cast(cold AS char(4)) ||
                        ' --> ' ||                        
                        cast(mea as char(4)) ||
                        ' --> ' ||
                        cast(mqa AS char(4)) ||
                        ' --> ' ||
                        cast(suspect AS char(4)) ||
                        ' --> '||
                        cast(suspect_working AS char(4)) ||
                        ' --> ' ||
                        cast(prospect AS char(4)) ||
                        ' --> ' ||
                        cast(customer AS char(4)) ||
                        ' --> ' ||
                        cast(recycled AS char(4)) ||
                        ' --> ' ||
                        cast(unqualified AS char(4))
                     AS act_journey_path_id                
                     

                FROM
                    (                       
                        
SELECT
                            x.ACCOUNT__C,
                            x.RECYCLE_COUNTER__C,
                            x.CREATED_DATE,
                            x.ACTIVE_MARKETING_LIFECYCLE_RECORD__C,
                            x.MARKETING_LIFECYCLE_AT_SUSPECT__C,
                            x.BUYING_STAGE_AT_SUSPECT__C,
                            x.ROUTING_REASON__C,
                            x.UNQUALIFIED_REASON__C,
                            x.OPPORTUNITY__C,
                            x.NAME,
                            x.account_journey_path_lifecycle_nonlinear_flag_reason,
                            x.account_journey_path_lifecycle_nonlinear_flag,
                            coalesce(x.cold_order, 0) as cold,
                            coalesce(x.mea_order, 0) as mea,
                            coalesce(x.mqa_order, 0) as mqa,
                            coalesce(x.suspect_order, 0) as suspect,
                            coalesce(x.suspect_working_order, 0) as suspect_working,
                            coalesce(x.prospect_order, 0) as prospect,
                            coalesce(x.customer_order, 0) as customer,
                            coalesce(x.recycled_order, 0) as recycled,
                            coalesce(x.unqualified_order, 0) as unqualified,
                            x.journey_length AS ACT_JOURNEY_PATH_CNT
                        from
                        (

                               SELECT
                                    DISTINCT 
                                    ACCOUNT__C,
                                    RECYCLE_COUNTER__C,
                                    CREATED_DATE,
                                    ACTIVE_MARKETING_LIFECYCLE_RECORD__C,
                                    MARKETING_LIFECYCLE_AT_SUSPECT__C,
                                    BUYING_STAGE_AT_SUSPECT__C,
                                    ROUTING_REASON__C,
                                    UNQUALIFIED_REASON__C,
                                    OPPORTUNITY__C,
                                    Name,
                                    CASE
                                        WHEN cold_order IS NULL
                                        OR mea_order = 1
                                        OR mqa_order = 1
                                        OR suspect_order = 1
                                        OR suspect_working_order = 1
                                        OR prospect_order = 1 
                                        OR customer_order = 1
                                        OR recycled_order = 1
                                        OR unqualified_order = 1
                                        OR prospect_order = cold_order + 1
                                        OR (
                                            recycled_order = cold_order + 1
                                            AND journey_length <> 2
                                        )
                                        OR (
                                            unqualified_order = cold_order + 1
                                            AND journey_length <> 2
                                        ) 
                                        OR (
                                            customer_order = cold_order + 1
                                            AND journey_length <> 2
                                        )
                                        OR suspect_order = recycled_order + 1
                                        OR suspect_order = unqualified_order + 1 
                                        OR customer_order = unqualified_order + 1
                                        OR unqualified_order = customer_order + 1
                                        OR (
                                            suspect_order > prospect_order
                                        )
                                        OR (
                                            recycled_order < journey_length
                                        )
                                        OR (
                                            unqualified_order < journey_length
                                        )
                                        OR (
                                            customer_order < journey_length
                                                        )
                                        OR (
                                            mea_order > mqa_order
                                        )
                                        OR (
                                            suspect_order IS NULL
                                            AND prospect_order IS NOT NULL
                                        )
                                        OR (
                                            mqa_order IS NOT NULL
                                            AND mea_order IS NULL
                                        )
                                        THEN 'Non-Linear'
                                        ELSE 'Linear'
                                    END AS ACCOUNT_JOURNEY_PATH_LIFECYCLE_NONLINEAR_FLAG,
                                    cold_order,
                                    mea_order,
                                    mqa_order,
                                    suspect_order,
                                    suspect_working_order,
                                    prospect_order,
                                    customer_order,
                                    recycled_order,
                                    unqualified_order,
                                    journey_length,
                                    CASE
                                        WHEN cold_order IS NULL THEN 'cold_order IS NULL'
                                        WHEN mea_order = 1 THEN 'mea_order = 1'
                                        WHEN mqa_order = 1 THEN 'mqa_order = 1'
                                        WHEN suspect_order = 1 THEN 'suspect_order = 1'
                                        WHEN suspect_working_order = 1 THEN 'suspect_working_order = 1'
                                        WHEN prospect_order = 1 THEN 'prospect_order = 1' 
                                        WHEN customer_order = 1 THEN 'customer_order = 1'
                                        WHEN recycled_order = 1 THEN 'recycled_order = 1'
                                        WHEN unqualified_order = 1 THEN 'unqualified_order = 1'
                                        WHEN prospect_order = cold_order + 1 THEN 'prospect_order = cold_order + 1'
                                        WHEN (recycled_order = cold_order + 1 AND journey_length <> 2) THEN 'cold, recycle, more'
                                        WHEN (unqualified_order = cold_order + 1 AND journey_length <> 2) THEN 'cold, unqualifed, more'
                                        WHEN (customer_order = cold_order + 1 AND journey_length <> 2) THEN 'cold, customer, more'
                                        WHEN suspect_order = recycled_order + 1 THEN 'suspect_order = recycled_order + 1'
                                        WHEN suspect_order = unqualified_order + 1 THEN 'suspect_order = unqualified_order + 1'
                                        WHEN customer_order = unqualified_order + 1 THEN 'customer_order = unqualified_order + 1'
                                        WHEN unqualified_order = customer_order + 1 THEN 'unqualified_order = customer_order + 1'
                                        WHEN recycled_order < journey_length THEN 'recycled_order < journey_length '
                                        WHEN unqualified_order < journey_length THEN 'unqualified_order < journey_length' 
                                        WHEN customer_order < journey_length THEN 'customer_order < journey_length'
                                        WHEN mea_order > mqa_order THEN 'mea_order > mqa_order'
                                        WHEN (
                                            suspect_order IS NULL
                                            AND prospect_order IS NOT NULL
                                        ) THEN 'suspect_order IS NULL & prospect_order IS NOT NULL'
                                        WHEN (
                                            mqa_order IS NOT NULL
                                            AND mea_order IS NULL
                                        ) THEN 'mqa_order IS NOT NULL & mea_order IS NULL'
                                        ELSE 'Linear'
                                    END AS ACCOUNT_JOURNEY_PATH_LIFECYCLE_NONLINEAR_FLAG_REASON
                                FROM
                                    (                                       


                                        SELECT
                                            *,
                                            CASE
                                                WHEN cold_place = 0 THEN NULL
                                                ELSE cold_place
                                            END AS cold_order,
                                            CASE
                                                WHEN mea_place = 0 THEN NULL
                                                ELSE mea_place
                                            END AS mea_order,
                                            CASE
                                                WHEN mqa_place = 0 THEN NULL
                                                ELSE mqa_place
                                            END AS mqa_order,
                                            CASE
                                                WHEN suspect_place = 0 THEN NULL
                                                ELSE suspect_place
                                            END AS suspect_order,
                                            CASE
                                                WHEN suspect_working_place = 0 THEN NULL
                                                ELSE suspect_working_place
                                            END AS suspect_working_order,
                                            CASE
                                                WHEN prospect_place = 0 THEN NULL
                                                ELSE prospect_place
                                            END AS prospect_order,
                                            CASE
                                                WHEN customer_place = 0 THEN NULL
                                                ELSE customer_place
                                            END AS customer_order,
                                            CASE
                                                WHEN recycled_place = 0 THEN NULL
                                                ELSE recycled_place
                                            END AS recycled_order,
                                            CASE
                                                WHEN unqualified_place = 0 THEN NULL
                                                ELSE unqualified_place
                                            END AS unqualified_order
                                        FROM

                                        (
                                        SELECT 
                                                    DISTINCT 
                                                    ACCOUNT__C,
                                                    RECYCLE_COUNTER__C,
                                                    CREATED_DATE,
                                                    ACTIVE_MARKETING_LIFECYCLE_RECORD__C,
                                                    MARKETING_LIFECYCLE_AT_SUSPECT__C,
                                                    BUYING_STAGE_AT_SUSPECT__C,
                                                    ROUTING_REASON__C,
                                                    UNQUALIFIED_REASON__C,
                                                    OPPORTUNITY__C,
                                                    Name,
                                                    --created_date,
                                                    COLD_ACCOUNT_DATE_STAMP__CAST AS cold_place,
                                                    MEA_DATE_STAMP__CAST AS mea_place,
                                                    MQA_DATE_STAMP__CAST AS mqa_place,
                                                    SUSPECT_DATE_STAMP__CAST AS suspect_place,
                                                    SUSPECT_WORKING_DATE_STAMP__CAST AS suspect_working_place,
                                                    PROSPECT_DATE_STAMP__CAST AS prospect_place,
                                                    CUSTOMER_DATE_STAMP__CAST AS customer_place,
                                                    RECYCLED_DATE_STAMP__CAST AS recycled_place,
                                                    UNQUALIFIED_DATE_STAMP__CAST AS unqualified_place,
                                                    CASE
                                                        WHEN cold_place > mea_place
                                                        AND cold_place > mqa_place
                                                        AND cold_place > suspect_place
                                                        AND cold_place > suspect_working_place
                                                        AND cold_place > prospect_place 
                                                        AND cold_place > customer_place
                                                        AND cold_place > recycled_place
                                                        AND cold_place > unqualified_place THEN cold_place
                                                        WHEN mea_place > cold_place
                                                        AND mea_place > mqa_place
                                                        AND mea_place > suspect_place
                                                        AND mea_place > suspect_working_place
                                                        AND mea_place > prospect_place 
                                                        AND mea_place > customer_place
                                                        AND mea_place > recycled_place
                                                        AND mea_place > unqualified_place THEN mea_place
                                                        WHEN mqa_place > cold_place
                                                        AND mqa_place > mea_place
                                                        AND mqa_place > suspect_place
                                                        AND mqa_place > suspect_working_place
                                                        AND mqa_place > prospect_place 
                                                        AND mqa_place > customer_place
                                                        AND mqa_place > recycled_place
                                                        AND mqa_place > unqualified_place THEN mqa_place
                                                        WHEN suspect_place > cold_place
                                                        AND suspect_place > mea_place
                                                        AND suspect_place > mqa_place
                                                        AND suspect_place > suspect_working_place
                                                        AND suspect_place > prospect_place 
                                                        AND suspect_place > customer_place
                                                        AND suspect_place > recycled_place
                                                        AND suspect_place > unqualified_place THEN suspect_place
                                                        WHEN suspect_working_place > cold_place
                                                        AND suspect_working_place > mea_place
                                                        AND suspect_working_place > mqa_place
                                                        AND suspect_working_place > suspect_place
                                                        AND suspect_working_place > prospect_place 
                                                        AND suspect_working_place > customer_place
                                                        AND suspect_working_place > recycled_place
                                                        AND suspect_working_place > unqualified_place THEN suspect_working_place
                                                        WHEN prospect_place > cold_place
                                                        AND prospect_place > mea_place
                                                        AND prospect_place > mqa_place
                                                        AND prospect_place > suspect_place
                                                        AND prospect_place > suspect_working_place 
                                                        AND prospect_place > customer_place
                                                        AND prospect_place > recycled_place
                                                        AND prospect_place > unqualified_place THEN prospect_place
                                                        WHEN customer_place > cold_place
                                                        AND customer_place > mea_place
                                                        AND customer_place > mqa_place
                                                        AND customer_place > suspect_place
                                                        AND customer_place > suspect_working_place
                                                        AND customer_place > suspect_place
                                                        AND customer_place > recycled_place
                                                        AND customer_place > unqualified_place THEN customer_place
                                                        WHEN recycled_place > cold_place
                                                        AND recycled_place > mea_place
                                                        AND recycled_place > mqa_place
                                                        AND recycled_place > suspect_place
                                                        AND recycled_place > suspect_working_place
                                                        AND recycled_place > prospect_place 
                                                        AND recycled_place > customer_place
                                                        AND recycled_place > unqualified_place THEN recycled_place
                                                        WHEN unqualified_place > cold_place
                                                        AND unqualified_place > mea_place
                                                        AND unqualified_place > mqa_place
                                                        AND unqualified_place > suspect_place
                                                        AND unqualified_place > suspect_working_place
                                                        AND unqualified_place > prospect_place 
                                                        AND unqualified_place > customer_place
                                                        AND unqualified_place > recycled_place THEN unqualified_place
                                                    END AS journey_length

FROM
(


                                                        SELECT
                                                            DISTINCT 
                                                            ACCOUNT__C,
                                                            RECYCLE_COUNTER__C,
                                                            CREATED_DATE,
                                                            ACTIVE_MARKETING_LIFECYCLE_RECORD__C,
                                                            MARKETING_LIFECYCLE_AT_SUSPECT__C,
                                                            BUYING_STAGE_AT_SUSPECT__C,
                                                            ROUTING_REASON__C,
                                                            UNQUALIFIED_REASON__C,
                                                            OPPORTUNITY__C,
                                                            Name,
                                                            --created_date,
                                                            lifecycle_date_stamp,
                                                            date_order
                                                            FROM
(
SELECT DISTINCT account__c,
                recycle_counter__c,
                created_date,
                active_marketing_lifecycle_record__c,
                marketing_lifecycle_at_suspect__c,
                buying_stage_at_suspect__c,
                routing_reason__c,
                unqualified_reason__c,
                opportunity__c,
                Name,
                --created_date,
                lifecycle_date_stamp,
                date_value ,
                CASE
                                WHEN TRUNC(date_value) >= '2222-01-01' THEN 0
                                ELSE date_order
                END AS date_order
FROM            (
                                SELECT DISTINCT account__c,
                                                recycle_counter__c,
                                                created_date,
                                                active_marketing_lifecycle_record__c,
                                                marketing_lifecycle_at_suspect__c,
                                                buying_stage_at_suspect__c,
                                                routing_reason__c,
                                                unqualified_reason__c,
                                                opportunity__c,
                                                Name,
                                                --created_date,
                                                lifecycle_date_stamp,
                                                date_value,
                                                Row_number() OVER ( partition BY account__c, recycle_counter__c, created_date, active_marketing_lifecycle_record__c --NAME
                                                ORDER BY date_value ) AS date_order
                                FROM            (
                                                                SELECT DISTINCT account__c,
                                                                                COALESCE(recycle_counter__c, 0) AS recycle_counter__c,
                                                                                created_date,
                                                                                active_marketing_lifecycle_record__c,
                                                                                marketing_lifecycle_at_suspect__c,
                                                                                buying_stage_at_suspect__c,
                                                                                routing_reason__c,
                                                                                unqualified_reason__c,
                                                                                opportunity__c,
                                                                                Name,
                                                                                --created_date,
                                                                                CASE
                                                                                                WHEN (
                                                                                                                                Cast(cold_account_date_stamp__cas AS DATE) = Cast(mea_date_stamp__cast AS DATE) ) THEN Dateadd(day, -1, cold_account_date_stamp__cas)
                                                                                                ELSE cold_account_date_stamp__cas
                                                                                END AS cold_account_date_stamp__cast,
                                                                                mea_date_stamp__cast,
                                                                                mqa_date_stamp__cast,
                                                                                CASE
                                                                                                WHEN (
                                                                                                                                Datediff( minute, suspect_date_stamp__cas, mqa_date_stamp__cast ) BETWEEN 0 AND             2 ) THEN Dateadd(minutes, 2, suspect_date_stamp__cas)
                                                                                                ELSE suspect_date_stamp__cas
                                                                                END AS suspect_date_stamp__cast,
                                                                                suspect_working_date_stamp__cast,
                                                                                prospect_date_stamp__cast,
                                                                                customer_date_stamp__cast,
                                                                                recycled_date_stamp__cast,
                                                                                unqualified_date_stamp__cast
                                                                FROM            (
                                                                                                SELECT DISTINCT account__c,
                                                                                                                COALESCE(recycle_counter__c, 0) AS recycle_counter__c,
                                                                                                                CREATEDDATE AS created_date,
                                                                                                                active_marketing_lifecycle_record__c,
                                                                                                                marketing_lifecycle_at_suspect__c,
                                                                                                                buying_stage_at_suspect__c,
                                                                                                                routing_reason__c,
                                                                                                                unqualified_reason__c,
                                                                                                                opportunity__c,
                                                                                                                Name,
                                                                                                                --created_date,
                                                                                                                COALESCE( cold_account_date_stamp__c, '2222-01-01 11:22:33.444' )    AS cold_account_date_stamp__cas,
                                                                                                                COALESCE( mea_date_stamp__c, '2222-01-01 11:22:33.444' )             AS mea_date_stamp__cast,
                                                                                                                COALESCE( mqa_date_stamp__c, '2222-01-01 11:22:33.444' )             AS mqa_date_stamp__cast,
                                                                                                                COALESCE( suspect_date_stamp__c, '2222-01-01 11:22:33.444' )         AS suspect_date_stamp__cas,
                                                                                                                COALESCE( suspect_working_date_stamp__c, '2222-01-01 11:22:33.444' ) AS suspect_working_date_stamp__cast,
                                                                                                                COALESCE( prospect_date_stamp__c, '2222-01-01 11:22:33.444' )        AS prospect_date_stamp__cast,
                                                                                                                COALESCE( customer_date_stamp__c, '2222-01-01 11:22:33.444' )        AS customer_date_stamp__cast,
                                                                                                                COALESCE( recycle_date_stamp__c, '2222-01-01 11:22:33.444' )         AS recycled_date_stamp__cast,
                                                                                                                COALESCE( unqualified_date_stamp__c, '2222-01-01 11:22:33.444' )     AS unqualified_date_stamp__cast
                                                                                                FROM                                                                                                                (
                                                                                                                       SELECT amlh_clean.*
                                                                                                                       FROM   (
                                                                                                                                              SELECT DISTINCT amlh.*
                                                                                                                                              FROM            SALESFORCE_BT.account_marketing_lifecycle_history__c AS amlh
                                                                                                                                              INNER JOIN
                                                                                                                                                              (
                                                                                                                                                                         SELECT     amlh_raw.account__c,
                                                                                                                                                                                    COALESCE(amlh_raw.recycle_counter__c, 0)                       AS recycle_counter__c,
                                                                                                                                                                                    Max(amlh_raw.createddate)                                   AS max_created_date,
                                                                                                                                                                                    Sum(1)                                                       AS cnt
                                                                                                                                                                         FROM       SALESFORCE_BT.account_marketing_lifecycle_history__c AS amlh_raw
                                                                                                                                                                         INNER JOIN SALESFORCE_BT.account                                AS act
                                                                                                                                                                         ON         amlh_raw.account__c = act.id -- Record Type
                                                                                                                                                                         INNER JOIN SALESFORCE_BT.RECORDTYPE AS rcd
                                                                                                                                                                         ON         act.RECORDTYPEID = rcd.id
                                                                                                                                                                         AND        (
                                                                                                                                                                                               rcd.id = '012300000005VEYAA2'
                                                                                                                                                                                    OR         rcd.id = '0126R000001UknZQAS' )
                                                                                                                                                                         WHERE      amlh_raw.ISDELETED = false
                                                                                                                                                                         AND        act.ISDELETED = false
                                                                                                                                                                         AND        act.internal_test_account__c = false
                                                                                                                                                                         GROUP BY   1,
                                                                                                                                                                                    2 --HAVING SUM(1) > 1
                                                                                                                                                                         ORDER BY   1,
                                                                                                                                                                                    2 ) AS amlh_qa_acts
                                                                                                                                              ON              amlh.account__c = amlh_qa_acts.account__c
                                                                                                                                              AND             COALESCE(amlh.recycle_counter__c, 0) = amlh_qa_acts.recycle_counter__c
                                                                                                                                              AND             amlh.CREATEDDATE = amlh_qa_acts.max_created_date
                                                                                                                                              WHERE           amlh.ISDELETED = false
                                                                                                                                              ORDER BY        amlh.account__c,
                                                                                                                                                              COALESCE(amlh.recycle_counter__c, 0) ) AS amlh_clean ) --WHERE ACCOUNT__C = '0018000000y0AwLAAU'
                                                                                                ORDER BY        account__c,
                                                                                                                COALESCE(recycle_counter__c, 0) ) AS amlh_clean
                                                                                --WHERE ACCOUNT__C = '0018000000y0AwLAAU'
                                                                ORDER BY        account__c,
                                                                                COALESCE(recycle_counter__c, 0) ) UNPIVOT ( date_value for lifecycle_date_stamp IN ( cold_account_date_stamp__cast,
                                                                                                                                                                  mea_date_stamp__cast,
                                                                                                                                                                  mqa_date_stamp__cast,
                                                                                                                                                                  suspect_date_stamp__cast,
                                                                                                                                                                  suspect_working_date_stamp__cast,
                                                                                                                                                                  prospect_date_stamp__cast,
                                                                                                                                                                  customer_date_stamp__cast,
                                                                                                                                                                  recycled_date_stamp__cast,
                                                                                                                                                                  unqualified_date_stamp__cast ) ) )
)


                                                            --end prepare for pivot
)
                                                    PIVOT (
                                                        MAX(date_order) FOR lifecycle_date_stamp IN (
                                                            --this isn't really a "max", I need an agg fx to pivot so it's the max of a single value
                                                            'cold_account_date_stamp__cast',
                                                            'customer_date_stamp__cast',
                                                            'mea_date_stamp__cast',
                                                            'mqa_date_stamp__cast',
                                                            'suspect_date_stamp__cast',
                                                            'suspect_working_date_stamp__cast',
                                                            'prospect_date_stamp__cast',
                                                            'recycled_date_stamp__cast',
                                                            'unqualified_date_stamp__cast'
                                                        )
                                                    )
                                                    )
 
)
) as x
) as act_journey_prep
            ) as act_journey ON act.ID = act_journey.ACCOUNT__C
            INNER JOIN SALESFORCE_BT.account_marketing_lifecycle_history__c AS amlh_raw on act_journey.ACCOUNT__C = amlh_raw.ACCOUNT__C
            and act_journey.RECYCLE_COUNTER__C = coalesce(amlh_raw.RECYCLE_COUNTER__C, 0)
            and act_journey.CREATED_DATE = amlh_raw.CREATEDDATE
        order by
            act.ID
);

RAISE INFO 'MV created';
    -- STEP 01a_1 : create temp tables for below.
                drop table if exists amlh_temp_cold_mea;
                create temporary table amlh_temp_cold_mea diststyle all as 
                SELECT
                    AMLH_ACCOUNT__C,
                    AMLH_NAME,
                    AMLH_COLD_ACCOUNT_DATE_STAMP__C_CAST,
                    AMLH_MEA_DATE_STAMP__C_CAST,
                    DATEDIFF(day,AMLH_COLD_ACCOUNT_DATE_STAMP__C_CAST,AMLH_MEA_DATE_STAMP__C_CAST) AS AMLH_DELTA_DAYS_COLD_MEA
                from act_mrkt_lifecycle.AMLH_TEMP_MV_1
                WHERE (AMLH_COLD_ACCOUNT_DATE_STAMP__C_CAST IS NOT NULL AND AMLH_MEA_DATE_STAMP__C_CAST IS NOT NULL) ;

                drop table if exists amlh_temp_cold_mqa;
                create temporary table amlh_temp_cold_mqa diststyle all as 
                SELECT
                    AMLH_ACCOUNT__C,
                    AMLH_NAME,
                    AMLH_COLD_ACCOUNT_DATE_STAMP__C_CAST,
                    AMLH_MQA_DATE_STAMP__C_CAST,
                    DATEDIFF(day,AMLH_COLD_ACCOUNT_DATE_STAMP__C_CAST,AMLH_MQA_DATE_STAMP__C_CAST) AS AMLH_DELTA_DAYS_COLD_MQA
                from act_mrkt_lifecycle.AMLH_TEMP_MV_1
                WHERE (AMLH_COLD_ACCOUNT_DATE_STAMP__C_CAST IS NOT NULL AND AMLH_MQA_DATE_STAMP__C_CAST IS NOT NULL)  ;

                drop table if exists amlh_temp_cold_suspect;
                create temporary table amlh_temp_cold_suspect diststyle all as 
                SELECT
                    AMLH_ACCOUNT__C,
                    AMLH_NAME,
                    AMLH_COLD_ACCOUNT_DATE_STAMP__C_CAST,
                    AMLH_SUSPECT_DATE_STAMP__C_CAST,
                    DATEDIFF(day,AMLH_COLD_ACCOUNT_DATE_STAMP__C_CAST,AMLH_SUSPECT_DATE_STAMP__C_CAST) AS AMLH_DELTA_DAYS_COLD_SUSPECT
                from act_mrkt_lifecycle.AMLH_TEMP_MV_1
                WHERE (AMLH_COLD_ACCOUNT_DATE_STAMP__C_CAST IS NOT NULL AND AMLH_SUSPECT_DATE_STAMP__C_CAST IS NOT NULL)  ;

                drop table if exists amlh_temp_cold_prospect;
                create temporary table amlh_temp_cold_prospect diststyle all as 
                SELECT
                    AMLH_ACCOUNT__C,
                    AMLH_NAME,
                    AMLH_COLD_ACCOUNT_DATE_STAMP__C_CAST,
                    AMLH_PROSPECT_DATE_STAMP__C_CAST,
                    DATEDIFF(day,AMLH_COLD_ACCOUNT_DATE_STAMP__C_CAST,AMLH_PROSPECT_DATE_STAMP__C_CAST) AS AMLH_DELTA_DAYS_COLD_PROSPECT
                from act_mrkt_lifecycle.AMLH_TEMP_MV_1
                WHERE (AMLH_COLD_ACCOUNT_DATE_STAMP__C_CAST IS NOT NULL AND AMLH_PROSPECT_DATE_STAMP__C_CAST IS NOT NULL) ;

				--20250314
                drop table if exists amlh_temp_cold_customer;
                create temporary table amlh_temp_cold_customer diststyle all as 
                SELECT
                    AMLH_ACCOUNT__C,
                    AMLH_NAME,
                    AMLH_COLD_ACCOUNT_DATE_STAMP__C_CAST,
                    AMLH_CUSTOMER_DATE_STAMP__C_CAST,
                    DATEDIFF(day,AMLH_COLD_ACCOUNT_DATE_STAMP__C_CAST,AMLH_CUSTOMER_DATE_STAMP__C_CAST) AS AMLH_DELTA_DAYS_COLD_CUSTOMER
                from act_mrkt_lifecycle.AMLH_TEMP_MV_1
                WHERE (AMLH_COLD_ACCOUNT_DATE_STAMP__C_CAST IS NOT NULL AND AMLH_CUSTOMER_DATE_STAMP__C_CAST IS NOT NULL) ;

				--20250314
                drop table if exists amlh_temp_cold_effective;
                create temporary table amlh_temp_cold_effective diststyle all as 
                SELECT
                    AMLH_ACCOUNT__C,
                    AMLH_NAME,
                    AMLH_COLD_ACCOUNT_DATE_STAMP__C_CAST,
                    AMLH_EFFECTIVE_DATE_STAMP__C_CAST,
                    DATEDIFF(day,AMLH_COLD_ACCOUNT_DATE_STAMP__C_CAST,AMLH_EFFECTIVE_DATE_STAMP__C_CAST) AS AMLH_DELTA_DAYS_COLD_EFFECTIVE
                from act_mrkt_lifecycle.AMLH_TEMP_MV_1
                WHERE (AMLH_COLD_ACCOUNT_DATE_STAMP__C_CAST IS NOT NULL AND AMLH_EFFECTIVE_DATE_STAMP__C_CAST IS NOT NULL) ;

                drop table if exists amlh_temp_mea_mqa;
                create temporary table amlh_temp_mea_mqa diststyle all as 
                SELECT
                    AMLH_ACCOUNT__C,
                    AMLH_NAME,
                    AMLH_MEA_DATE_STAMP__C_CAST,
                    AMLH_MQA_DATE_STAMP__C_CAST,
                    DATEDIFF(day,AMLH_MEA_DATE_STAMP__C_CAST,AMLH_MQA_DATE_STAMP__C_CAST) AS AMLH_DELTA_DAYS_MEA_MQA
                from act_mrkt_lifecycle.AMLH_TEMP_MV_1
                WHERE (AMLH_MEA_DATE_STAMP__C_CAST IS NOT NULL AND AMLH_MQA_DATE_STAMP__C_CAST IS NOT NULL)  ;

                drop table if exists amlh_temp_mea_suspect;
                create temporary table amlh_temp_mea_suspect diststyle all as 
                SELECT
                    AMLH_ACCOUNT__C,
                    AMLH_NAME,
                    AMLH_MEA_DATE_STAMP__C_CAST,
                    AMLH_SUSPECT_DATE_STAMP__C_CAST,
                    DATEDIFF(day,AMLH_MEA_DATE_STAMP__C_CAST,AMLH_SUSPECT_DATE_STAMP__C_CAST) AS AMLH_DELTA_DAYS_MEA_SUSPECT
                from act_mrkt_lifecycle.AMLH_TEMP_MV_1
                WHERE (AMLH_MEA_DATE_STAMP__C_CAST IS NOT NULL AND AMLH_SUSPECT_DATE_STAMP__C_CAST IS NOT NULL)  ;

                drop table if exists amlh_temp_mea_prospect;
                create temporary table amlh_temp_mea_prospect diststyle all as
                SELECT
                    AMLH_ACCOUNT__C,
                    AMLH_NAME,
                    AMLH_MEA_DATE_STAMP__C_CAST,
                    AMLH_PROSPECT_DATE_STAMP__C_CAST,
                    DATEDIFF(day,AMLH_MEA_DATE_STAMP__C_CAST,AMLH_PROSPECT_DATE_STAMP__C_CAST) AS AMLH_DELTA_DAYS_MEA_PROSPECT
                from act_mrkt_lifecycle.AMLH_TEMP_MV_1 
                WHERE (AMLH_MEA_DATE_STAMP__C_CAST IS NOT NULL AND AMLH_PROSPECT_DATE_STAMP__C_CAST IS NOT NULL)  ;

				--20250314
                drop table if exists amlh_temp_mea_customer;
                create temporary table amlh_temp_mea_customer diststyle all as
                SELECT
                    AMLH_ACCOUNT__C,
                    AMLH_NAME,
                    AMLH_MEA_DATE_STAMP__C_CAST,
                    AMLH_CUSTOMER_DATE_STAMP__C_CAST,
                    DATEDIFF(day,AMLH_MEA_DATE_STAMP__C_CAST,AMLH_CUSTOMER_DATE_STAMP__C_CAST) AS AMLH_DELTA_DAYS_MEA_CUSTOMER
                from act_mrkt_lifecycle.AMLH_TEMP_MV_1 
                WHERE (AMLH_MEA_DATE_STAMP__C_CAST IS NOT NULL AND AMLH_CUSTOMER_DATE_STAMP__C_CAST IS NOT NULL)  ;

				--20250314
                drop table if exists amlh_temp_mea_effective;
                create temporary table amlh_temp_mea_effective diststyle all as
                SELECT
                    AMLH_ACCOUNT__C,
                    AMLH_NAME,
                    AMLH_MEA_DATE_STAMP__C_CAST,
                    AMLH_EFFECTIVE_DATE_STAMP__C_CAST,
                    DATEDIFF(day,AMLH_MEA_DATE_STAMP__C_CAST,AMLH_EFFECTIVE_DATE_STAMP__C_CAST) AS AMLH_DELTA_DAYS_MEA_EFFECTIVE
                from act_mrkt_lifecycle.AMLH_TEMP_MV_1 
                WHERE (AMLH_MEA_DATE_STAMP__C_CAST IS NOT NULL AND AMLH_EFFECTIVE_DATE_STAMP__C_CAST IS NOT NULL)  ;

                drop table if exists amlh_temp_mqa_suspect;
                create temporary table amlh_temp_mqa_suspect diststyle all as
                SELECT
                    AMLH_ACCOUNT__C,
                    AMLH_NAME,
                    AMLH_MQA_DATE_STAMP__C_CAST,
                    AMLH_SUSPECT_DATE_STAMP__C_CAST,
                    DATEDIFF(day,AMLH_MQA_DATE_STAMP__C_CAST,AMLH_SUSPECT_DATE_STAMP__C_CAST) AS AMLH_DELTA_DAYS_MQA_SUSPECT
                from act_mrkt_lifecycle.AMLH_TEMP_MV_1 
                WHERE (AMLH_MQA_DATE_STAMP__C_CAST IS NOT NULL AND AMLH_SUSPECT_DATE_STAMP__C_CAST IS NOT NULL)  ;

                drop table if exists amlh_temp_mqa_prospect;
                create temporary table amlh_temp_mqa_prospect diststyle all as
                SELECT
                    AMLH_ACCOUNT__C,
                    AMLH_NAME,
                    AMLH_MQA_DATE_STAMP__C_CAST,
                    AMLH_PROSPECT_DATE_STAMP__C_CAST,
                    DATEDIFF(day,AMLH_MQA_DATE_STAMP__C_CAST,AMLH_PROSPECT_DATE_STAMP__C_CAST) AS AMLH_DELTA_DAYS_MQA_PROSPECT
                from act_mrkt_lifecycle.AMLH_TEMP_MV_1  
                WHERE (AMLH_MQA_DATE_STAMP__C_CAST IS NOT NULL AND AMLH_PROSPECT_DATE_STAMP__C_CAST IS NOT NULL) ;

				--20250314
                drop table if exists amlh_temp_mqa_customer;
                create temporary table amlh_temp_mqa_customer diststyle all as
                SELECT
                    AMLH_ACCOUNT__C,
                    AMLH_NAME,
                    AMLH_MQA_DATE_STAMP__C_CAST,
                    AMLH_CUSTOMER_DATE_STAMP__C_CAST,
                    DATEDIFF(day,AMLH_MQA_DATE_STAMP__C_CAST,AMLH_CUSTOMER_DATE_STAMP__C_CAST) AS AMLH_DELTA_DAYS_MQA_CUSTOMER
                from act_mrkt_lifecycle.AMLH_TEMP_MV_1  
                WHERE (AMLH_MQA_DATE_STAMP__C_CAST IS NOT NULL AND AMLH_CUSTOMER_DATE_STAMP__C_CAST IS NOT NULL) ;

				--20250314
                drop table if exists amlh_temp_mqa_effective;
                create temporary table amlh_temp_mqa_effective diststyle all as
                SELECT
                    AMLH_ACCOUNT__C,
                    AMLH_NAME,
                    AMLH_MQA_DATE_STAMP__C_CAST,
                    AMLH_EFFECTIVE_DATE_STAMP__C_CAST,
                    DATEDIFF(day,AMLH_MQA_DATE_STAMP__C_CAST,AMLH_EFFECTIVE_DATE_STAMP__C_CAST) AS AMLH_DELTA_DAYS_MQA_EFFECTIVE
                from act_mrkt_lifecycle.AMLH_TEMP_MV_1  
                WHERE (AMLH_MQA_DATE_STAMP__C_CAST IS NOT NULL AND AMLH_EFFECTIVE_DATE_STAMP__C_CAST IS NOT NULL) ;

                drop table if exists amlh_temp_suspect_prospect;
                create temporary table amlh_temp_suspect_prospect diststyle all as
                SELECT
                    AMLH_ACCOUNT__C,
                    AMLH_NAME,
                    AMLH_SUSPECT_DATE_STAMP__C_CAST,
                    AMLH_PROSPECT_DATE_STAMP__C_CAST,
                    DATEDIFF(day,AMLH_SUSPECT_DATE_STAMP__C_CAST,AMLH_PROSPECT_DATE_STAMP__C_CAST) AS AMLH_DELTA_DAYS_SUSPECT_PROSPECT
                from act_mrkt_lifecycle.AMLH_TEMP_MV_1  
                WHERE (AMLH_SUSPECT_DATE_STAMP__C_CAST IS NOT NULL AND AMLH_PROSPECT_DATE_STAMP__C_CAST IS NOT NULL) ;
				
				--20250314
                drop table if exists amlh_temp_suspect_customer;
                create temporary table amlh_temp_suspect_customer diststyle all as
                SELECT
                    AMLH_ACCOUNT__C,
                    AMLH_NAME,
                    AMLH_SUSPECT_DATE_STAMP__C_CAST,
                    AMLH_CUSTOMER_DATE_STAMP__C_CAST,
                    DATEDIFF(day,AMLH_SUSPECT_DATE_STAMP__C_CAST,AMLH_CUSTOMER_DATE_STAMP__C_CAST) AS AMLH_DELTA_DAYS_SUSPECT_CUSTOMER
                from act_mrkt_lifecycle.AMLH_TEMP_MV_1  
                WHERE (AMLH_SUSPECT_DATE_STAMP__C_CAST IS NOT NULL AND AMLH_CUSTOMER_DATE_STAMP__C_CAST IS NOT NULL) ;
				
				--20250314
                drop table if exists amlh_temp_suspect_effective;
                create temporary table amlh_temp_suspect_effective diststyle all as
                SELECT
                    AMLH_ACCOUNT__C,
                    AMLH_NAME,
                    AMLH_SUSPECT_DATE_STAMP__C_CAST,
                    AMLH_EFFECTIVE_DATE_STAMP__C_CAST,
                    DATEDIFF(day,AMLH_SUSPECT_DATE_STAMP__C_CAST,AMLH_EFFECTIVE_DATE_STAMP__C_CAST) AS AMLH_DELTA_DAYS_SUSPECT_EFFECTIVE
                from act_mrkt_lifecycle.AMLH_TEMP_MV_1  
                WHERE (AMLH_SUSPECT_DATE_STAMP__C_CAST IS NOT NULL AND AMLH_EFFECTIVE_DATE_STAMP__C_CAST IS NOT NULL) ;
				
				
RAISE INFO 'step 1a complete';
    -- Step 01b: ACCOUNT MARKETING LIFECYCLE TABLE

        DROP TABLE IF EXISTS ACT_MRKT_LIFECYCLE.AMLH CASCADE;

        CREATE TABLE ACT_MRKT_LIFECYCLE.AMLH AS

    SELECT
        *,
        -- AMLH_MUTUALLY_EXCLUSIVE_PRE_SUSPECT_DESIGNATION_DATE FILTERS
        
                cast(date_trunc('week',AMLH_MUTUALLY_EXCLUSIVE_PRE_SUSPECT_DESIGNATION_DATE) + '6 days'::interval as date) as AMLH_MUTUALLY_EXCLUSIVE_PRE_SUSPECT_DESIGNATION_DATE_EOW,
                last_day(AMLH_MUTUALLY_EXCLUSIVE_PRE_SUSPECT_DESIGNATION_DATE) as AMLH_MUTUALLY_EXCLUSIVE_PRE_SUSPECT_DESIGNATION_DATE_EOM,
                cast(dateadd(day, -1, dateadd(QTR,1,DATE_TRUNC('QTR', AMLH_MUTUALLY_EXCLUSIVE_PRE_SUSPECT_DESIGNATION_DATE)))as date) as AMLH_MUTUALLY_EXCLUSIVE_PRE_SUSPECT_DESIGNATION_DATE_EOQ,
                cast(dateadd(day, -1, dateadd(year, 1, DATE_TRUNC('year', AMLH_MUTUALLY_EXCLUSIVE_PRE_SUSPECT_DESIGNATION_DATE)))as date) as AMLH_MUTUALLY_EXCLUSIVE_PRE_SUSPECT_DESIGNATION_DATE_EOY
        
    FROM
        (
            SELECT
                amlh_temp.*,
                -- MUTUALLY_EXCLUSIVE_PRE_SUSPECT_DESIGNATION
                CASE
                    WHEN SUBSTRING(AMLH_ACT_JOURNEY_PATH_ID, 1, 1) <> 0 -- cold exists
                    AND SUBSTRING(AMLH_ACT_JOURNEY_PATH_ID, 19, 1) = 0 -- not routed
                    AND SUBSTRING(AMLH_ACT_JOURNEY_PATH_ID, 1, 1) > SUBSTRING(AMLH_ACT_JOURNEY_PATH_ID, 7, 1) -- cold only or cold after mea
                    AND SUBSTRING(AMLH_ACT_JOURNEY_PATH_ID, 1, 1) > SUBSTRING(AMLH_ACT_JOURNEY_PATH_ID, 13, 1) -- cold only or cold after mqa
                    THEN 'Pre-Suspect Cold - Not Routed' 
                    WHEN SUBSTRING(AMLH_ACT_JOURNEY_PATH_ID, 1, 1) <> 0 -- cold exists
                    AND SUBSTRING(AMLH_ACT_JOURNEY_PATH_ID, 19, 1) <> 0 --suspect exists
                    AND SUBSTRING(AMLH_ACT_JOURNEY_PATH_ID, 1, 1) < SUBSTRING(AMLH_ACT_JOURNEY_PATH_ID, 19, 1) --cold is before suspect
                    AND (
                        SUBSTRING(AMLH_ACT_JOURNEY_PATH_ID, 1, 1) > SUBSTRING(AMLH_ACT_JOURNEY_PATH_ID, 7, 1) -- cold only or cold after mea
                        OR SUBSTRING(AMLH_ACT_JOURNEY_PATH_ID, 7, 1) > SUBSTRING(AMLH_ACT_JOURNEY_PATH_ID, 19, 1) -- or mea is after suspect
                    ) 
                    AND (
                        SUBSTRING(AMLH_ACT_JOURNEY_PATH_ID, 1, 1) > SUBSTRING(AMLH_ACT_JOURNEY_PATH_ID, 13, 1) --cold only or cold after mqa
                        OR SUBSTRING(AMLH_ACT_JOURNEY_PATH_ID, 13, 1) > SUBSTRING(AMLH_ACT_JOURNEY_PATH_ID, 19, 1) --or mqa is after suspect
                    ) 
                    THEN 'Pre-Suspect Cold - Routed'
                    WHEN SUBSTRING(AMLH_ACT_JOURNEY_PATH_ID, 7, 1) <> 0 --mea exists
                    AND SUBSTRING(AMLH_ACT_JOURNEY_PATH_ID, 19, 1) = 0 -- not routed
                    AND SUBSTRING(AMLH_ACT_JOURNEY_PATH_ID, 7, 1) > SUBSTRING(AMLH_ACT_JOURNEY_PATH_ID, 1, 1) --mea is after cold
                    AND SUBSTRING(AMLH_ACT_JOURNEY_PATH_ID, 7, 1) > SUBSTRING(AMLH_ACT_JOURNEY_PATH_ID, 13, 1) --  mqa is zero or before mea             
                    THEN 'Pre-Suspect MEA - Not Routed' 
                    WHEN SUBSTRING(AMLH_ACT_JOURNEY_PATH_ID, 7, 1) <> 0 --mea exists
                    AND SUBSTRING(AMLH_ACT_JOURNEY_PATH_ID, 19, 1) <> 0 -- suspect exists
                    AND SUBSTRING(AMLH_ACT_JOURNEY_PATH_ID, 7, 1) < SUBSTRING(AMLH_ACT_JOURNEY_PATH_ID, 19, 1) --mea is before suspect
                    AND (
                        SUBSTRING(AMLH_ACT_JOURNEY_PATH_ID, 7, 1) > SUBSTRING(AMLH_ACT_JOURNEY_PATH_ID, 1, 1) -- cold is before mea
                        OR SUBSTRING(AMLH_ACT_JOURNEY_PATH_ID, 1, 1) > SUBSTRING(AMLH_ACT_JOURNEY_PATH_ID, 19, 1) --or cold is after suspect
                    ) 
                    AND (
                        SUBSTRING(AMLH_ACT_JOURNEY_PATH_ID, 7, 1) > SUBSTRING(AMLH_ACT_JOURNEY_PATH_ID, 13, 1) --mqa is before mea or mqa is zero
                        OR (
                        SUBSTRING(AMLH_ACT_JOURNEY_PATH_ID, 13, 1) > SUBSTRING(AMLH_ACT_JOURNEY_PATH_ID, 19, 1) --or mqa is after suspect
                        AND DATEDIFF(minute, AMLH_SUSPECT_DATE_STAMP__C, AMLH_MQA_DATE_STAMP__C) > 15
                        --AND diff between mqa and supect is greater than 15 mins
                        )
                    )
                    THEN 'Pre-Suspect MEA - Routed' 
                    WHEN SUBSTRING(AMLH_ACT_JOURNEY_PATH_ID, 13, 1) <> 0 --mqa exists
                    AND SUBSTRING(AMLH_ACT_JOURNEY_PATH_ID, 19, 1) = 0 -- suspect does not exist
                    AND SUBSTRING(AMLH_ACT_JOURNEY_PATH_ID, 13, 1) > SUBSTRING(AMLH_ACT_JOURNEY_PATH_ID, 1, 1) --mqa is greater than cold
                    AND SUBSTRING(AMLH_ACT_JOURNEY_PATH_ID, 13, 1) > SUBSTRING(AMLH_ACT_JOURNEY_PATH_ID, 7, 1) --mqa is greater than mea
                    THEN 'Pre-Suspect MQA - Not Routed' 
                    WHEN SUBSTRING(AMLH_ACT_JOURNEY_PATH_ID, 13, 1) <> 0 --mqa exists
                    AND SUBSTRING(AMLH_ACT_JOURNEY_PATH_ID, 19, 1) <> 0 -- suspect exists
                    AND (
                    SUBSTRING(AMLH_ACT_JOURNEY_PATH_ID, 13, 1) < SUBSTRING(AMLH_ACT_JOURNEY_PATH_ID, 19, 1) --mqa is before suspect
                    OR  (
                        SUBSTRING(AMLH_ACT_JOURNEY_PATH_ID, 13, 1) > SUBSTRING(AMLH_ACT_JOURNEY_PATH_ID, 19, 1) --or mqa is after suspect
                        AND DATEDIFF(minute, AMLH_SUSPECT_DATE_STAMP__C, AMLH_MQA_DATE_STAMP__C) <= 15 
                        --AND diff between mqa and supect is less than or equal to 15 mins
                            )
                        )
                    AND (
                        SUBSTRING(AMLH_ACT_JOURNEY_PATH_ID, 13, 1) > SUBSTRING(AMLH_ACT_JOURNEY_PATH_ID, 1, 1) -- mqa is after than cold
                        OR SUBSTRING(AMLH_ACT_JOURNEY_PATH_ID, 1, 1) > SUBSTRING(AMLH_ACT_JOURNEY_PATH_ID, 19, 1) --or cold is after suspect
                    ) 
                    AND (
                        SUBSTRING(AMLH_ACT_JOURNEY_PATH_ID, 13, 1) > SUBSTRING(AMLH_ACT_JOURNEY_PATH_ID, 7, 1) --mqa is after mea
                        OR SUBSTRING(AMLH_ACT_JOURNEY_PATH_ID, 7, 1) > SUBSTRING(AMLH_ACT_JOURNEY_PATH_ID, 19, 1) --or mea is after suspect
                    ) 
                    THEN 'Pre-Suspect MQA - Routed'
                    ELSE 'Other'
                END AS AMLH_MUTUALLY_EXCLUSIVE_PRE_SUSPECT_DESIGNATION,
                -- MUTUALLY_EXCLUSIVE_PRE_SUSPECT_DESIGNATION_DATE
                CASE
                    WHEN SUBSTRING(AMLH_ACT_JOURNEY_PATH_ID, 1, 1) <> 0 -- cold exists
                    AND SUBSTRING(AMLH_ACT_JOURNEY_PATH_ID, 19, 1) = 0 -- not routed
                    AND SUBSTRING(AMLH_ACT_JOURNEY_PATH_ID, 1, 1) > SUBSTRING(AMLH_ACT_JOURNEY_PATH_ID, 7, 1) -- cold is greater than mea
                    AND SUBSTRING(AMLH_ACT_JOURNEY_PATH_ID, 1, 1) > SUBSTRING(AMLH_ACT_JOURNEY_PATH_ID, 13, 1) -- cold is greater than mqa
                    THEN CAST(AMLH_COLD_ACCOUNT_DATE_STAMP__C AS DATE)
                    WHEN 
                        SUBSTRING(AMLH_ACT_JOURNEY_PATH_ID, 1, 1) <> 0 -- cold exists
                        AND SUBSTRING(AMLH_ACT_JOURNEY_PATH_ID, 19, 1) <> 0 --suspect exists
                        AND SUBSTRING(AMLH_ACT_JOURNEY_PATH_ID, 1, 1) < SUBSTRING(AMLH_ACT_JOURNEY_PATH_ID, 19, 1) --cold is before suspect
                        AND (SUBSTRING(AMLH_ACT_JOURNEY_PATH_ID, 1, 1) > SUBSTRING(AMLH_ACT_JOURNEY_PATH_ID, 7, 1) --cold only or after mea 
                            OR SUBSTRING(AMLH_ACT_JOURNEY_PATH_ID, 7, 1) > SUBSTRING(AMLH_ACT_JOURNEY_PATH_ID, 19, 1)) -- or mea is after suspect
                        AND (SUBSTRING(AMLH_ACT_JOURNEY_PATH_ID, 1, 1) > SUBSTRING(AMLH_ACT_JOURNEY_PATH_ID, 13, 1)  --cold is after mqa
                            OR SUBSTRING(AMLH_ACT_JOURNEY_PATH_ID, 13, 1) > SUBSTRING(AMLH_ACT_JOURNEY_PATH_ID, 19, 1) ) --or mqa is after suspect
                        THEN CAST(AMLH_COLD_ACCOUNT_DATE_STAMP__C AS DATE)
                WHEN SUBSTRING(AMLH_ACT_JOURNEY_PATH_ID, 7, 1) <> 0 --mea exists
                    AND SUBSTRING(AMLH_ACT_JOURNEY_PATH_ID, 19, 1) = 0 --no suspect
                    AND SUBSTRING(AMLH_ACT_JOURNEY_PATH_ID, 7, 1) > SUBSTRING(AMLH_ACT_JOURNEY_PATH_ID, 1, 1) --mea is greater than cold
                    AND SUBSTRING(AMLH_ACT_JOURNEY_PATH_ID, 7, 1) > SUBSTRING(AMLH_ACT_JOURNEY_PATH_ID, 13, 1) --mea is greater than mqa               
                    THEN CAST(AMLH_MEA_DATE_STAMP__C AS DATE)
                    
                    WHEN SUBSTRING(AMLH_ACT_JOURNEY_PATH_ID, 7, 1) <> 0 --mea exists
                    AND SUBSTRING(AMLH_ACT_JOURNEY_PATH_ID, 19, 1) <> 0 -- suspect exists
                    AND SUBSTRING(AMLH_ACT_JOURNEY_PATH_ID, 7, 1) < SUBSTRING(AMLH_ACT_JOURNEY_PATH_ID, 19, 1) --mea is before suspect
                    AND (
                        SUBSTRING(AMLH_ACT_JOURNEY_PATH_ID, 7, 1) > SUBSTRING(AMLH_ACT_JOURNEY_PATH_ID, 1, 1) -- cold is before mea
                        OR SUBSTRING(AMLH_ACT_JOURNEY_PATH_ID, 1, 1) > SUBSTRING(AMLH_ACT_JOURNEY_PATH_ID, 19, 1) --or cold is after suspect
                    ) 
                    AND (
                        SUBSTRING(AMLH_ACT_JOURNEY_PATH_ID, 7, 1) > SUBSTRING(AMLH_ACT_JOURNEY_PATH_ID, 13, 1) --mqa is before mea or mqa is zero
                        OR (
                        SUBSTRING(AMLH_ACT_JOURNEY_PATH_ID, 13, 1) > SUBSTRING(AMLH_ACT_JOURNEY_PATH_ID, 19, 1) --or mqa is after suspect
                        AND DATEDIFF(minute, AMLH_SUSPECT_DATE_STAMP__C, AMLH_MQA_DATE_STAMP__C) > 15
                        --AND diff between mqa and supect is greater than 15 mins
                        )
                    )            
                    THEN CAST(AMLH_MEA_DATE_STAMP__C AS DATE)
                    
                WHEN SUBSTRING(AMLH_ACT_JOURNEY_PATH_ID, 13, 1) <> 0 --mqa exists
                    AND SUBSTRING(AMLH_ACT_JOURNEY_PATH_ID, 19, 1) = 0   -- not routed
                    AND SUBSTRING(AMLH_ACT_JOURNEY_PATH_ID, 13, 1) > SUBSTRING(AMLH_ACT_JOURNEY_PATH_ID, 1, 1) --mqa is greater than cold
                    AND SUBSTRING(AMLH_ACT_JOURNEY_PATH_ID, 13, 1) > SUBSTRING(AMLH_ACT_JOURNEY_PATH_ID, 7, 1) --mqa is greater than mea             
                    THEN CAST(AMLH_MQA_DATE_STAMP__C AS DATE)
                    
                WHEN SUBSTRING(AMLH_ACT_JOURNEY_PATH_ID, 13, 1) <> 0 --mqa exists
                    AND SUBSTRING(AMLH_ACT_JOURNEY_PATH_ID, 19, 1) <> 0 -- suspect exists
                    AND (
                    SUBSTRING(AMLH_ACT_JOURNEY_PATH_ID, 13, 1) < SUBSTRING(AMLH_ACT_JOURNEY_PATH_ID, 19, 1) --mqa is before suspect
                    OR  (
                        SUBSTRING(AMLH_ACT_JOURNEY_PATH_ID, 13, 1) > SUBSTRING(AMLH_ACT_JOURNEY_PATH_ID, 19, 1) --or mqa is after suspect
                        AND DATEDIFF(minute, AMLH_SUSPECT_DATE_STAMP__C, AMLH_MQA_DATE_STAMP__C) <= 15 
                        --AND diff between mqa and supect is less than or equal to 15 mins
                            )
                        )
                    AND (
                        SUBSTRING(AMLH_ACT_JOURNEY_PATH_ID, 13, 1) > SUBSTRING(AMLH_ACT_JOURNEY_PATH_ID, 1, 1) -- mqa is after than cold
                        OR SUBSTRING(AMLH_ACT_JOURNEY_PATH_ID, 1, 1) > SUBSTRING(AMLH_ACT_JOURNEY_PATH_ID, 19, 1) --or cold is after suspect
                    ) 
                    AND (
                        SUBSTRING(AMLH_ACT_JOURNEY_PATH_ID, 13, 1) > SUBSTRING(AMLH_ACT_JOURNEY_PATH_ID, 7, 1) --mqa is after mea
                        OR SUBSTRING(AMLH_ACT_JOURNEY_PATH_ID, 7, 1) > SUBSTRING(AMLH_ACT_JOURNEY_PATH_ID, 19, 1) --or mea is after suspect
                    )               
                    THEN CAST(AMLH_MQA_DATE_STAMP__C AS DATE)
                    ELSE NULL
                END AS AMLH_MUTUALLY_EXCLUSIVE_PRE_SUSPECT_DESIGNATION_DATE,

                    -- DELTAS VIA THEJOINS 
                    amlh_temp_delta.AMLH_DELTA_DAYS_COLD_MEA,
                    amlh_temp_delta.AMLH_DELTA_DAYS_COLD_MQA,
                    amlh_temp_delta.AMLH_DELTA_DAYS_COLD_SUSPECT,
                    amlh_temp_delta.AMLH_DELTA_DAYS_COLD_PROSPECT,
                    amlh_temp_delta.AMLH_DELTA_DAYS_MEA_MQA,
                    amlh_temp_delta.AMLH_DELTA_DAYS_MEA_SUSPECT,
                    amlh_temp_delta.AMLH_DELTA_DAYS_MEA_PROSPECT,
                    amlh_temp_delta.AMLH_DELTA_DAYS_MQA_SUSPECT,
                    amlh_temp_delta.AMLH_DELTA_DAYS_MQA_PROSPECT,
                    amlh_temp_delta.AMLH_DELTA_DAYS_SUSPECT_PROSPECT
                    
            from act_mrkt_lifecycle.AMLH_TEMP_MV_1 as amlh_temp
               -- AMLH_TEMP_V1_6 as amlh_temp
                -- Delta in Days
                LEFT JOIN 
                (SELECT  
                    -- ID's for join
                    amlh_temp.AMLH_ACCOUNT__C,
                    amlh_temp.AMLH_NAME,
                    -- Journey Path
                    amlh_temp.AMLH_ACT_JOURNEY_PATH,
                
                    -- AMLH LIFECYCLE STAGES 
                    amlh_temp.AMLH_COLD_ACCOUNT_DATE_STAMP__C_CAST,
                    amlh_temp.AMLH_MEA_DATE_STAMP__C_CAST,
                    amlh_temp.AMLH_MQA_DATE_STAMP__C_CAST,
                    amlh_temp.AMLH_SUSPECT_DATE_STAMP__C_CAST,
                    amlh_temp.AMLH_PROSPECT_DATE_STAMP__C_CAST,
					
					-- 20250314
					amlh_temp.AMLH_CUSTOMER_DATE_STAMP__C_CAST,
					amlh_temp.AMLH_EFFECTIVE_DATE_STAMP__C_CAST,
					
                    -- DELTAS VIA THEJOINS BELOW 
                    amlh_temp_cold_mea.AMLH_DELTA_DAYS_COLD_MEA,
                    amlh_temp_cold_mqa.AMLH_DELTA_DAYS_COLD_MQA,
                    amlh_temp_cold_suspect.AMLH_DELTA_DAYS_COLD_SUSPECT,
                    amlh_temp_cold_prospect.AMLH_DELTA_DAYS_COLD_PROSPECT,
					--20250314
                    amlh_temp_cold_customer.AMLH_DELTA_DAYS_COLD_CUSTOMER,
                    amlh_temp_cold_effective.AMLH_DELTA_DAYS_COLD_EFFECTIVE,

                    amlh_temp_mea_mqa.AMLH_DELTA_DAYS_MEA_MQA,
                    amlh_temp_mea_suspect.AMLH_DELTA_DAYS_MEA_SUSPECT,
                    amlh_temp_mea_prospect.AMLH_DELTA_DAYS_MEA_PROSPECT,
					--20250314
                    amlh_temp_mea_customer.AMLH_DELTA_DAYS_MEA_CUSTOMER,
                    amlh_temp_mea_effective.AMLH_DELTA_DAYS_MEA_EFFECTIVE,
					
                    amlh_temp_mqa_suspect.AMLH_DELTA_DAYS_MQA_SUSPECT,
                    amlh_temp_mqa_prospect.AMLH_DELTA_DAYS_MQA_PROSPECT,
					--20250314
                    amlh_temp_mqa_customer.AMLH_DELTA_DAYS_MQA_CUSTOMER,
                    amlh_temp_mqa_effective.AMLH_DELTA_DAYS_MQA_EFFECTIVE,
					
                    amlh_temp_suspect_prospect.AMLH_DELTA_DAYS_SUSPECT_PROSPECT,
					--20250314
                    amlh_temp_suspect_customer.AMLH_DELTA_DAYS_SUSPECT_CUSTOMER,
                    amlh_temp_suspect_effective.AMLH_DELTA_DAYS_SUSPECT_EFFECTIVE
                    
                from act_mrkt_lifecycle.AMLH_TEMP_MV_1 as amlh_temp
                -- Delta in Days
                LEFT JOIN amlh_temp_cold_mea
                ON amlh_temp.AMLH_ACCOUNT__C = amlh_temp_cold_mea.AMLH_ACCOUNT__C
                AND amlh_temp.AMLH_NAME = amlh_temp_cold_mea.AMLH_NAME
                
                LEFT join amlh_temp_cold_mqa
                ON amlh_temp.AMLH_ACCOUNT__C = amlh_temp_cold_mqa.AMLH_ACCOUNT__C
                AND amlh_temp.AMLH_NAME = amlh_temp_cold_mqa.AMLH_NAME
                
                LEFT join amlh_temp_cold_suspect
                ON amlh_temp.AMLH_ACCOUNT__C = amlh_temp_cold_suspect.AMLH_ACCOUNT__C
                AND amlh_temp.AMLH_NAME = amlh_temp_cold_suspect.AMLH_NAME
                
                LEFT join amlh_temp_cold_prospect
                ON amlh_temp.AMLH_ACCOUNT__C = amlh_temp_cold_prospect.AMLH_ACCOUNT__C
                AND amlh_temp.AMLH_NAME = amlh_temp_cold_prospect.AMLH_NAME
                
				--20250314
                LEFT join amlh_temp_cold_customer
                ON amlh_temp.AMLH_ACCOUNT__C = amlh_temp_cold_customer.AMLH_ACCOUNT__C
                AND amlh_temp.AMLH_NAME = amlh_temp_cold_customer.AMLH_NAME
                
				--20250314
                LEFT join amlh_temp_cold_effective
                ON amlh_temp.AMLH_ACCOUNT__C = amlh_temp_cold_effective.AMLH_ACCOUNT__C
                AND amlh_temp.AMLH_NAME = amlh_temp_cold_effective.AMLH_NAME
                
                LEFT join amlh_temp_mea_mqa
                ON amlh_temp.AMLH_ACCOUNT__C = amlh_temp_mea_mqa.AMLH_ACCOUNT__C
                AND amlh_temp.AMLH_NAME = amlh_temp_mea_mqa.AMLH_NAME
                
                LEFT JOIN amlh_temp_mea_suspect
                ON amlh_temp.AMLH_ACCOUNT__C = amlh_temp_mea_suspect.AMLH_ACCOUNT__C
                AND amlh_temp.AMLH_NAME = amlh_temp_mea_suspect.AMLH_NAME
                
                LEFT JOIN amlh_temp_mea_prospect
                ON amlh_temp.AMLH_ACCOUNT__C = amlh_temp_mea_prospect.AMLH_ACCOUNT__C
                AND amlh_temp.AMLH_NAME = amlh_temp_mea_prospect.AMLH_NAME
                
				--20250314
                LEFT JOIN amlh_temp_mea_customer
                ON amlh_temp.AMLH_ACCOUNT__C = amlh_temp_mea_customer.AMLH_ACCOUNT__C
                AND amlh_temp.AMLH_NAME = amlh_temp_mea_customer.AMLH_NAME

				--20250314
                LEFT JOIN amlh_temp_mea_effective
                ON amlh_temp.AMLH_ACCOUNT__C = amlh_temp_mea_effective.AMLH_ACCOUNT__C
                AND amlh_temp.AMLH_NAME = amlh_temp_mea_effective.AMLH_NAME
                
                LEFT join amlh_temp_mqa_suspect
                ON amlh_temp.AMLH_ACCOUNT__C = amlh_temp_mqa_suspect.AMLH_ACCOUNT__C
                AND amlh_temp.AMLH_NAME = amlh_temp_mqa_suspect.AMLH_NAME
                
                LEFT join amlh_temp_mqa_prospect
                ON amlh_temp.AMLH_ACCOUNT__C = amlh_temp_mqa_prospect.AMLH_ACCOUNT__C
                AND amlh_temp.AMLH_NAME = amlh_temp_mqa_prospect.AMLH_NAME
				
				--20250314
                LEFT join amlh_temp_mqa_customer
                ON amlh_temp.AMLH_ACCOUNT__C = amlh_temp_mqa_customer.AMLH_ACCOUNT__C
                AND amlh_temp.AMLH_NAME = amlh_temp_mqa_customer.AMLH_NAME

				--20250314
                LEFT join amlh_temp_mqa_effective
                ON amlh_temp.AMLH_ACCOUNT__C = amlh_temp_mqa_effective.AMLH_ACCOUNT__C
                AND amlh_temp.AMLH_NAME = amlh_temp_mqa_effective.AMLH_NAME
                
                LEFT join amlh_temp_suspect_prospect
                ON amlh_temp.AMLH_ACCOUNT__C = amlh_temp_suspect_prospect.AMLH_ACCOUNT__C
                AND amlh_temp.AMLH_NAME = amlh_temp_suspect_prospect.AMLH_NAME

                --20250314
                LEFT join amlh_temp_suspect_customer
                ON amlh_temp.AMLH_ACCOUNT__C = amlh_temp_suspect_customer.AMLH_ACCOUNT__C
                AND amlh_temp.AMLH_NAME = amlh_temp_suspect_customer.AMLH_NAME

                --20250314
                LEFT join amlh_temp_suspect_effective
                ON amlh_temp.AMLH_ACCOUNT__C = amlh_temp_suspect_effective.AMLH_ACCOUNT__C
                AND amlh_temp.AMLH_NAME = amlh_temp_suspect_effective.AMLH_NAME
                
                WHERE amlh_temp.AMLH_ACCOUNT_JOURNEY_PATH_LIFECYCLE_NONLINEAR_FLAG = 'Linear'
                ) as amlh_temp_delta
                ON amlh_temp.AMLH_ACCOUNT__C = amlh_temp_delta.AMLH_ACCOUNT__C
                AND amlh_temp.AMLH_NAME = amlh_temp_delta.AMLH_NAME
        );
RAISE INFO 'step 1b complete';        
    -- Step 02: ACCOUNT MARKETING LIFECYCLE TABLE WITH OPP DATA 
--     DROP TABLE IF EXISTS ACT_MRKT_LIFECYCLE.AMLH_OPPS;
--        CREATE TABLE test.ACT_MRKT_LIFECYCLE.AMLH_OPPS as

     DROP TABLE IF EXISTS ACT_MRKT_LIFECYCLE.AMLH_OPPS CASCADE;    
     CREATE TABLE ACT_MRKT_LIFECYCLE.AMLH_OPPS as
 
    SELECT
        *
    FROM        
 (
SELECT
        *, 
        CASE
                WHEN OPP_STAGE_NAME_CATEGORY = 'No Opp' OR OPP_STAGE_NAME_CATEGORY IS NULL THEN AMLH_UNQUALIFIED_REASON__C
                WHEN OPP_STAGE_NAME_CATEGORY <> 'No Opp' AND OPP_STAGE_NAME_CATEGORY IS NOT NULL THEN
                COALESCE(OPP_LOSS_STALL_REASON__C, 'Missing')
                ELSE NULL
                END AS global_unqualified_Reason, 

        -- global_unqualified_Reason,
        CASE WHEN
                (CASE 
                WHEN OPP_STAGE_NAME_CATEGORY = 'No Opp' OR OPP_STAGE_NAME_CATEGORY IS NULL THEN AMLH_UNQUALIFIED_REASON__C
                WHEN OPP_STAGE_NAME_CATEGORY <> 'No Opp' AND OPP_STAGE_NAME_CATEGORY IS NOT NULL THEN
                COALESCE(OPP_LOSS_STALL_REASON__C, 'Missing')
                ELSE NULL
                end) IS NOT NULL 
            THEN 
                (CASE 
                    WHEN OPP_STAGE_5_DATE is not null THEN 'STAGE_5'
                    WHEN OPP_STAGE_4_DATE is not null THEN 'STAGE_4'
                    WHEN OPP_STAGE_3_DATE is not null THEN 'STAGE_3'
                    WHEN OPP_STAGE_2_DATE is not null THEN 'STAGE_2'
                    WHEN OPP_STAGE_1_DATE is not null THEN 'STAGE_1'
                    WHEN OPP_STAGE_0_DATE is not null THEN 'STAGE_0'
                    WHEN AMLH_SUSPECT_DATE_STAMP__C is not null THEN 'SUSPECT'
                    WHEN AMLH_MQA_DATE_STAMP__C is not null THEN 'MQA'
                    WHEN AMLH_MEA_DATE_STAMP__C is not null THEN 'MEA'
                    WHEN AMLH_COLD_ACCOUNT_DATE_STAMP__C is not null THEN 'COLD' end
                    ) 

                    ELSE 'No Date' END AS OPP_GLOBAL_UNQUALIFIED_DATE_COHORT,

        CASE    WHEN OPP_CLOSE_DATE < OPP_STAGE_1_DATE THEN 'STAGE_0'
                WHEN OPP_CLOSE_DATE between OPP_STAGE_1_DATE AND OPP_STAGE_2_DATE THEN 'STAGE_1'
                WHEN OPP_CLOSE_DATE between OPP_STAGE_2_DATE AND OPP_STAGE_3_DATE THEN 'STAGE_2'
                WHEN OPP_CLOSE_DATE between OPP_STAGE_3_DATE AND OPP_STAGE_4_DATE THEN 'STAGE_3'
                WHEN OPP_CLOSE_DATE between OPP_STAGE_4_DATE AND OPP_STAGE_5_DATE THEN 'STAGE_4'
                WHEN OPP_CLOSE_DATE > OPP_STAGE_5_DATE THEN 'STAGE_5'
                ELSE NULL
                    END AS opp_stage_lost from
        (
            select 
                -- Account Marketing Lifecycle Table
                amlh.*,
    --            --act.buying_stage_at_suspect__c AS ACT_BUYING_STAGE_AT_SUSPECT__C,
    --            -- OPP INFO
                opp.ID AS OPP_ID,
                opp.NAME AS OPP_NAME,
                CAST(opp.CREATEDDATE as DATE) AS OPP_CREATED_DATE,            
                cast(date_trunc('week',opp.CREATEDDATE) + '6 days'::interval as date) as OPP_CREATED_DATE__C_EOW,
                last_day(opp.CREATEDDATE) as OPP_CREATED_DATE__C_EOM,
                cast(dateadd(day, -1, dateadd(QTR,1,DATE_TRUNC('QTR', opp.CREATEDDATE)))as date) as OPP_CREATED_DATE__C_EOQ,
                cast(dateadd(day, -1, dateadd(year, 1, DATE_TRUNC('year', opp.CREATEDDATE)))as date) as OPP_CREATED_DATE__C_EOY,                    
                opp.CLOSEDATE AS OPP_CLOSE_DATE,
                opp.LEADSOURCE AS OPP_LEAD_SOURCE,
                opp.STAGENAME AS OPP_STAGE_NAME,
                opp.SUB_STAGE__C AS OPP_SUB_STAGE__C,
				--20250314
				opp.SALES_REPORTING_OPPORTUNITY_TYPE__C AS OPP_SALES_REPORTING_OPPORTUNITY_TYPE__C,
                opp.COMPETITIVE_INFLUENCE__C AS OPP_COMPETITIVE_INFLUENCE__C,
                opp.PRIMARY_COMPETITOR__C AS OPP_PRIMARY_COMPETITOR__C,
                opp.LOSS_STALL_REASON__C AS OPP_LOSS_STALL_REASON__C,
                opp.LOSS_STALL_REASON_DETAIL__C AS OPP_LOSS_STALL_REASON_DETAIL__C,
                opp.LOST_REASON__C AS OPP_LOST_REASON__C,
              --  opp.UNQUALIFIED_REASON__C AS OPP_UNQUALIFIED_REASON__C,
                opp.LEADING_PRODUCT__C AS OPP_LEADING_PRODUCT__C,
                opp.PRODUCT_INTEREST__C AS OPP_PRODUCT_INTEREST__C,
                PUSHCOUNT AS OPP_PUSH_COUNT,
                CASE WHEN (opp.ID IS NULL 
                    OR opp.STAGENAME IS NULL
                    OR opp.STAGENAME IN
                (
                'Awaiting Auto-Renewal',
                'Cancelled',
                'Churn',
                'Closed - Auto Renewal',
                'Closed - Migrated',
                'Closed - Reduced',
                'Closed - Terminated',
                'Closed - Transfer',
                'Closed / Duplicate',
                'Closed / Invalid',
                'Closed Auto-Renewed',
                'Closed Booked - Cancelled',
                'Paved - Invoice'
                )
                )
                THEN 'No Opp' 
                    WHEN opp.STAGENAME IN
                    (
                    'Closed - Booked',
                    'Closed - Booked (SO)',
                    'Closed - Parent',
                    'Closed - Ready to Book',
                    'Closed Won',
                    'On Hold',
                    'Pending Additional Signature',
                    'Pending Approval',
                    'Pending Client Signature'
                    )
                    THEN 'Closed - Booked' 
                    WHEN opp.STAGENAME IN
                    (
                    'Closed Lost',
                    'Closed Return to CDM',
                    'Closed Stalled',
                    'Closed/Unqualified',
                    'Stalled / At Risk'
                    )
                        THEN 'Closed - Not Booked' 
                    ELSE 'Open' END AS OPP_STAGE_NAME_CATEGORY,
                opp.TYPE AS OPP_TYPE,
                opp.COMMITTED_TERM__C AS OPP_COMMITTED_TERM__C,
                opp.PROBABILITY AS OPP_PROBABILITY,
                opp.ISCLOSED AS OPP_IS_CLOSED,
                opp.ISWON AS OPP_IS_WON,
                -- OPP FINANCIAL METRICS
                opp.CURRENCYISOCODE as OPP_CURRENCY_ISO_CODE,
                opp.CONVERSION_RATE AS OPP_CONVERSION_RATE,
                opp.ACV3__C AS OPP_ACV3__C,
                opp.FORECASTED_ACV__C as OPP_FORECASTED_ACV__C,
                opp.FORECASTED_ARR__C as OPP_FORECASTED_ARR__C,
                opp.SALES_REPORTING_ARR__C AS OPP_SALES_REPORTING_ARR__C,		
                CASE WHEN opp.ID IS NULL THEN NULL WHEN opp.STAGENAME = 'Closed - Booked (SO)' THEN COALESCE(opp.ACV3__C,opp.FORECASTED_ACV__C) ELSE opp.FORECASTED_ACV__C END AS OPP_BOOKEDFORECASTED_ACV3__C,
                CASE WHEN opp.ID IS NULL THEN NULL WHEN opp.STAGENAME = 'Closed - Booked (SO)' THEN COALESCE(opp.ACV3__C,opp.FORECASTED_ACV__C) ELSE opp.FORECASTED_ACV__C END AS OPP_BOOKEDFORECASTED_ACV_QTY3__C,
                CASE WHEN opp.ID IS NULL THEN NULL WHEN opp.STAGENAME = 'Closed - Booked (SO)' THEN COALESCE(opp.REPORTING_ARR__C,opp.FORECASTED_ARR__C) ELSE opp.FORECASTED_ARR__C END AS OPP_BOOKEDFORECASTED_ARR__C,
				--20250314
                opp.REPORTING_ARR__C AS OPP_REPORTING_ARR__C,		
                opp.TOTAL_BOOKING_AMOUNT2__C as OPP_TOTAL_BOOKING_AMOUNT2__C,
                (opp.ACV3__C * opp.CONVERSION_RATE) AS OPP_ACV3__C_CONVERTED,(
                    opp.TOTAL_BOOKING_AMOUNT2__C * opp.CONVERSION_RATE
                ) as OPP_TOTAL_BOOKING_AMOUNT2__C_CONVERTED,
                opp.SUBS_QTY__C as OPP_SUBS_QTY__C,
                opp.BOOKED_SUBS_QTY3__C as OPP_BOOKED_SUBS_QTY3__C,
                opp.FORECASTED_SUBS_QTY__C AS OPP_FORECASTED_SUBS_QTY__C,
                CASE WHEN opp.ID IS NULL THEN NULL WHEN opp.STAGENAME = 'Closed - Booked (SO)' THEN COALESCE(BOOKED_SUBS_QTY3__C,FORECASTED_SUBS_QTY__C) ELSE FORECASTED_SUBS_QTY__C END AS OPP_BOOKEDFORECASTED_SUBS_QTY3__C,
                
                opp.SALES_REPORTING_ACV__C AS OPP_SALES_REPORTING_ACV__C,
                opp.SALES_REPORTING_TOTAL_BOOKING_AMOUNT__C AS OPP_SALES_REPORTING_TOTAL_BOOKING_AMOUNT__C,
                (
                    opp.SALES_REPORTING_ACV__C * opp.CONVERSION_RATE
                ) AS OPP_SALES_REPORTING_ACV__C_CONVERTED,(
                    opp.SALES_REPORTING_TOTAL_BOOKING_AMOUNT__C * opp.CONVERSION_RATE
                ) AS OPP_SALES_REPORTING_TOTAL_BOOKING_AMOUNT__C_CONVERTED,
                opp.SALES_REPORTING_BOOKED_SUBS_QTY__C AS OPP_SALES_REPORTING_BOOKED_SUBS_QTY__C,
                -- OPP OWNER INFO
                opp.OWNER_NAME AS OPP_OWNER_NAME,
                opp.OWNER_USERROLE_NAME AS OPP_OWNER_USERROLE_NAME,
                -- OPP STAGE DATE
                CAST(opp_stage_dates.stage0 as date) AS OPP_STAGE_0_DATE,
                CAST(opp_stage_dates.stage1 as date) AS OPP_STAGE_1_DATE,
                CAST(opp_stage_dates.stage2 as date) AS OPP_STAGE_2_DATE,
                CAST(opp_stage_dates.stage3 as date) AS OPP_STAGE_3_DATE,
                CAST(opp_stage_dates.stage4 as date) AS OPP_STAGE_4_DATE,
                CAST(opp_stage_dates.stage5 as date) AS OPP_STAGE_5_DATE,
--                CAST(opp_stage_dates.stage6 as date) AS OPP_STAGE_6_DATE,
--                CAST(opp_stage_dates.stage7 as date) AS OPP_STAGE_7_DATE,
                CAST(opp_stage_dates.win as date) AS OPP_WIN_DATE,

                -- OPP STAGE VELOCITY
				--20250302
				OPP_STAGE_DELTA_DAYS_OPPCREATION_STAGE_1,
                OPP_STAGE_DELTA_DAYS_STAGE_0_STAGE_1,
                OPP_STAGE_DELTA_DAYS_STAGE_1_STAGE_2,
                OPP_STAGE_DELTA_DAYS_STAGE_2_STAGE_3,
                OPP_STAGE_DELTA_DAYS_STAGE_3_STAGE_4,
                OPP_STAGE_DELTA_DAYS_STAGE_4_STAGE_5,
--                OPP_STAGE_DELTA_DAYS_STAGE_5_STAGE_6,
--                OPP_STAGE_DELTA_DAYS_STAGE_6_STAGE_7,
				--20250302
                OPP_STAGE_DELTA_DAYS_STAGE_5_WIN,
                OPP_STAGE_DELTA_DAYS_STAGE_1_WIN
        
            FROM
                SALESFORCE_BT.ACCOUNT AS act          
                -- ACT Record Type
                INNER JOIN SALESFORCE_BT.RECORDTYPE as rcd_act ON act.RECORDTYPEID = rcd_act.ID
                AND (
                    rcd_act."ID" = '012300000005VEYAA2'
                    OR rcd_act."ID" = '0126R000001UknZQAS'
                ) -- Act Mrkt Lifecycle History
                INNER JOIN ACT_MRKT_LIFECYCLE.AMLH AS amlh on act.ID = amlh.ACT_ID -- OPP
                LEFT JOIN (SELECT 
                opp.*,curr.CONVERSIONRATE AS CONVERSION_RATE, usr.NAME AS OWNER_NAME, usr_role.NAME AS OWNER_USERROLE_NAME 
                FROM SALESFORCE_BT.OPPORTUNITY as opp
                -- OPP RECORD TYPE
                INNER JOIN SALESFORCE_BT.RECORDTYPE as rcd_opp ON opp.RECORDTYPEID = rcd_opp.ID
                AND (
                    rcd_opp.ID = '012800000005wl4AAA'
                    OR rcd_opp.ID = '0121E000000MBF6QAO'
                )
                -- OPP OWNER
                LEFT JOIN SALESFORCE_BT.USER usr ON opp.OWNERID = usr.ID
                AND opp.OWNERID <> '0056R00000C6W2MQAV'
                -- OPP USER ROLE
                LEFT JOIN SALESFORCE_BT.USERROLE usr_role ON usr.USERROLEID = usr_role.ID
                -- OPP CURRENCY
                INNER JOIN SALESFORCE_BT.CURRENCYTYPE curr ON opp.CURRENCYISOCODE = curr.ISOCODE
                AND curr.ISACTIVE = TRUE
                WHERE usr_role.NAME NOT IN ('Scott Rose', 'Rick Walters', 'Micah Rea', 'Compliance', 'ELD Compliance Manager')
                
                ) as opp ON amlh.ACT_ID = opp.ACCOUNTID
                AND amlh.AMLH_OPPORTUNITY__C = opp.ID
                and opp.PARENT_OPPORTUNITY__C IS NULL
                /*-- touchtype_analytics_table as source 
                LEFT JOIN ACT_MRKT_LIFECYCLE.TOUCHTYPE_ANALYTICS as infl_data
                ON act.ID = infl_data.CRM_ACCOUNT_ID
                */
                LEFT JOIN 
                (
                
                select --works from here 2
                    DISTINCT 
                    opp.id AS opportunity_id,
                    opp.CREATEDDATE as stage0,
                    CASE WHEN stage1 IS NOT NULL then stage1
                    WHEN stage1 IS NULL AND stage2 IS NOT NULL THEN stage2
                    WHEN stage1 IS NULL AND stage2 IS NULL AND stage3 IS NOT NULL THEN stage3
                    WHEN stage1 IS NULL AND stage2 IS NULL AND stage3 IS NULL and stage4 IS NOT NULL THEN stage4 
                    WHEN stage1 IS NULL AND stage2 IS NULL AND stage3 IS NULL and stage4 IS NULL and stage5 IS NOT NULL then stage5
--                    WHEN stage1 IS NULL AND stage2 IS NULL AND stage3 IS NULL and stage4 IS NULL and stage5 IS NULL AND stage6 IS NOT NULL THEN stage6
--                    WHEN stage1 IS NULL AND stage2 IS NULL AND stage3 IS NULL and stage4 IS NULL and stage5 IS NULL AND stage6 IS NULL and stage7 is not null THEN stage7
                    WHEN stage1 IS NULL AND stage2 IS NULL AND stage3 IS NULL and stage4 IS NULL and stage5 IS NULL and win is not null then win 
                    END AS stage1,
                    CASE WHEN stage2 IS NOT NULL then stage2
                    WHEN stage2 IS NULL AND stage3 IS NOT NULL THEN stage3
                    WHEN stage2 IS NULL AND stage3 IS NULL and stage4 IS NOT NULL THEN stage4 
                    WHEN stage2 IS NULL AND stage3 IS NULL and stage4 IS NULL and stage5 IS NOT NULL then stage5
--                    WHEN stage2 IS NULL AND stage3 IS NULL and stage4 IS NULL and stage5 IS NULL AND stage6 IS NOT NULL THEN stage6
--                    WHEN stage2 IS NULL AND stage3 IS NULL and stage4 IS NULL and stage5 IS NULL AND stage6 IS NULL and stage7 is not null THEN stage7
                    WHEN stage2 IS NULL AND stage3 IS NULL and stage4 IS NULL and stage5 IS NULL and win is not null then win
                    END AS stage2,                
                    CASE WHEN stage3 IS NOT NULL then stage3
                    WHEN stage3 IS NULL and stage4 IS NOT NULL THEN stage4 
                    WHEN stage3 IS NULL and stage4 IS NULL and stage5 IS NOT NULL then stage5
--                    WHEN stage3 IS NULL and stage4 IS NULL and stage5 IS NULL AND stage6 IS NOT NULL THEN stage6
--                    WHEN stage3 IS NULL and stage4 IS NULL and stage5 IS NULL AND stage6 IS NULL and stage7 is not null THEN stage7
                    WHEN stage3 IS NULL and stage4 IS NULL and stage5 IS NULL and win is not null then win 
                    END AS stage3,  
                    CASE WHEN stage4 IS NOT NULL then stage4
                    WHEN stage4 IS NULL and stage5 IS NOT NULL then stage5
--                    WHEN stage4 IS NULL and stage5 IS NULL AND stage6 IS NOT NULL THEN stage6
--                    WHEN stage4 IS NULL and stage5 IS NULL AND stage6 IS NULL and stage7 is not null THEN stage7
                    WHEN stage4 IS NULL and stage5 IS NULL and win is not null then win
                    END AS stage4,
                    CASE WHEN stage5 IS NOT NULL then stage5
                    WHEN stage5  IS NULL and win is not null then win
                    END AS stage5,   
                    -- remove stage6
                    -- remove stage7
                    win
                FROM
                    SALESFORCE_BT.opportunity opp
                    LEFT JOIN (
                                select distinct 
                                    opportunity_id, 
                                    case when identify < '10-08-2024' then identify
                                        else nurture end as stage0,
                                    case when "analyze" < '10-08-2024' then "analyze"
                                        else "qualify" end as stage1,                               
                                    case when present < '10-08-2024' then present
                                        else discover end as stage2,
                                    case when prove < '10-08-2024' then prove
                                        else propose end as stage3,
                                    case when finalize < '10-08-2024' then finalize
                                        else validate end as stage4,
                                    case when finalize < '10-08-2024' then finalize
                                        else negotiate end as stage5,  
                                        -- remove stage 6
                                        -- remove stage 7
                                    win  

                                FROM
                                    (
                                          select distinct
                                             OPPORTUNITYID AS opportunity_id,
                                             CREATEDDATE as created_date,
                                             newvalue as new_value

                                        FROM
                                            SALESFORCE_BT.OPPORTUNITYFIELDHISTORY
                                        WHERE
                                            field = 'StageName'
                                            
                                            and 
                                              newvalue  in                         
                                            (
                                            'Identify',
                                            'Analyze',
                                            'Present',
                                            'Prove',
                                            'Finalize',
                                            'Nurture',
                                            'Qualify',
                                            'Discover',
                                            'Propose',
                                            'Validate',
                                            'Negotiate'
                                        )                                    
                                            
                                            
                                            union all
                                            
                                            
                                            
                                            
                                           select distinct
                                             OPPORTUNITYID AS opportunity_id,
                                            max(CREATEDDATE) as created_date,
                                            'Win' as new_value

                                        FROM
                                            SALESFORCE_BT.OPPORTUNITYFIELDHISTORY
                                        WHERE
                                            field = 'StageName'
                                            
                                            and 
                                              newvalue in                         
                                                            (
                                            'Closed - Booked',
                                            'Closed - Booked (SO)',
                                            'Closed - Parent',
                                            'Closed - Ready to Book',
                                            'Closed Won',
                                            'On Hold',
                                            'Pending Additional Signature',
                                            'Pending Approval',
                                            'Pending Client Signature')
                                            group by OPPORTUNITYID
                                            
                                    ) PIVOT (
                                        MIN(CREATED_DATE) FOR new_value IN (
                                            'Identify',
                                            'Analyze',
                                            'Present',
                                            'Prove',
                                            'Finalize',
                                            'Nurture',
                                            'Qualify',
                                            'Discover',
                                            'Propose',
                                            'Validate',
                                            'Negotiate',
                                            'Win'
                                        )
                                    ) 
                            ) AS n2 
                            ON opp.id = n2.opportunity_id
                            ) as opp_stage_dates
                            ON amlh.AMLH_OPPORTUNITY__C = opp_stage_dates.OPPORTUNITY_ID

                    LEFT JOIN 
                    (
                    SELECT
                        opp_velocity.id AS OPPORTUNITY_ID,
						--20250302
                        DATEDIFF(day,OPP_CREATED_DATE,OPP_STAGE_1_DATE) AS OPP_STAGE_DELTA_DAYS_OPPCREATION_STAGE_1,
                        DATEDIFF(day,OPP_STAGE_0_DATE,OPP_STAGE_1_DATE) AS OPP_STAGE_DELTA_DAYS_STAGE_0_STAGE_1,
                        DATEDIFF(day,OPP_STAGE_1_DATE,OPP_STAGE_2_DATE) AS OPP_STAGE_DELTA_DAYS_STAGE_1_STAGE_2,
                        DATEDIFF(day,OPP_STAGE_2_DATE,OPP_STAGE_3_DATE) AS OPP_STAGE_DELTA_DAYS_STAGE_2_STAGE_3,
                        DATEDIFF(day,OPP_STAGE_3_DATE,OPP_STAGE_4_DATE) AS OPP_STAGE_DELTA_DAYS_STAGE_3_STAGE_4,
                        DATEDIFF(day,OPP_STAGE_4_DATE,OPP_STAGE_5_DATE) AS OPP_STAGE_DELTA_DAYS_STAGE_4_STAGE_5,                    
--                        DATEDIFF(day,OPP_STAGE_5_DATE,OPP_STAGE_6_DATE) AS OPP_STAGE_DELTA_DAYS_STAGE_5_STAGE_6,
--                        DATEDIFF(day,OPP_STAGE_6_DATE,OPP_STAGE_7_DATE) AS OPP_STAGE_DELTA_DAYS_STAGE_6_STAGE_7,
						--20250302
                        DATEDIFF(day,OPP_STAGE_5_DATE,OPP_WIN_DATE) AS OPP_STAGE_DELTA_DAYS_STAGE_5_WIN, --NEW name,
                        DATEDIFF(day,OPP_STAGE_1_DATE,OPP_WIN_DATE) AS OPP_STAGE_DELTA_DAYS_STAGE_1_WIN
                    FROM
                    (
                    SELECT
                        opp.id,
						--20250302
						CAST(opp.createddate AS date) AS OPP_CREATED_DATE,
                        COALESCE(CAST(n2.stage0 as date), CAST(opp.createddate AS date)) AS OPP_STAGE_0_DATE,
                        CAST(n2.stage1 as date) AS OPP_STAGE_1_DATE,
                        CAST(n2.stage2 as date) AS OPP_STAGE_2_DATE,
                        CAST(n2.stage3 as date) AS OPP_STAGE_3_DATE, 
                        CAST(n2.stage4 as date) AS OPP_STAGE_4_DATE,
                        CAST(n2.stage5 as date) AS OPP_STAGE_5_DATE,
--                        CAST(n2.stage6 as date) AS OPP_STAGE_6_DATE, 
--                        CAST(n2.stage7 as date) AS OPP_STAGE_7_DATE,
                        CAST(n2.win as date) AS OPP_WIN_DATE                    
                    FROM
                        SALESFORCE_BT.opportunity opp
                        LEFT JOIN (
                                select distinct 
                                    opportunity_id, 
                                    case when identify < '10-08-2024' then identify
                                        else nurture end as stage0,
                                    case when "analyze" < '10-08-2024' then "analyze"
                                        else "qualify" end as stage1,                               
                                    case when present < '10-08-2024' then present
                                        else discover end as stage2,
                                    case when prove < '10-08-2024' then prove
                                        else propose end as stage3,
                                    case when finalize < '10-08-2024' then finalize
                                        else validate end as stage4,
                                    case when finalize < '10-08-2024' then finalize
                                        else negotiate end as stage5,  
                                        -- remove stage 6
                                        -- remove stage 7
                                    win  

                                FROM
                                    (
                                          SELECT
                                             OPPORTUNITYID AS opportunity_id,
                                             CREATEDDATE AS created_date,
                                             newvalue as new_value

                                        FROM
                                            SALESFORCE_BT.OPPORTUNITYFIELDHISTORY
                                        WHERE
                                            field = 'StageName'
                                            
                                            and 
                                              newvalue  in                         
                                            (
                                            'Identify',
                                            'Analyze',
                                            'Present',
                                            'Prove',
                                            'Finalize',
                                            'Nurture',
                                            'Qualify',
                                            'Discover',
                                            'Propose',
                                            'Validate',
                                            'Negotiate'
                                        )                                    
                                            
                                            
                                            union all
                                            
                                            
                                            
                                            
                                           SELECT
                                             OPPORTUNITYID AS opportunity_id,
                                            max(CREATEDDATE) as created_date,
                                            'Win' as new_value

                                        FROM
                                            SALESFORCE_BT.OPPORTUNITYFIELDHISTORY
                                        WHERE
                                            field = 'StageName'
                                            
                                            and 
                                              newvalue in                         
                                                            (
                                            'Closed - Booked',
                                            'Closed - Booked (SO)',
                                            'Closed - Parent',
                                            'Closed - Ready to Book',
                                            'Closed Won',
                                            'On Hold',
                                            'Pending Additional Signature',
                                            'Pending Approval',
                                            'Pending Client Signature')
                                            group by OPPORTUNITYID
                                            
                                    ) PIVOT (
                                        MIN(CREATED_DATE) FOR new_value IN (
                                            'Identify',
                                            'Analyze',
                                            'Present',
                                            'Prove',
                                            'Finalize',
                                            'Nurture',
                                            'Qualify',
                                            'Discover',
                                            'Propose',
                                            'Validate',
                                            'Negotiate',
                                            'Win'
                                        )
                                    ) 
                        ) AS n2 ON opp.id = n2.opportunity_id
                        )  as opp_velocity
                    ) as opp_stage_velocity
                    ON amlh.AMLH_OPPORTUNITY__C = opp_stage_velocity.OPPORTUNITY_ID


            WHERE
                act.INTERNAL_TEST_ACCOUNT__C = FALSE
                AND act.ISDELETED = FALSE
                --AND act.ID = '0011E00001lPaVSQA0'
                --AND opp.ID = '0066R00000q8Hw4QAE'
            ORDER BY
                AMLH_ACCOUNT__C,
                AMLH_RECYCLE_COUNTER__C ASC,
                AMLH_ACTIVE_MARKETING_LIFECYCLE_RECORD__C DESC,
                AMLH_CREATED_DATE
        ));   
RAISE INFO 'step 2 complete';

    -- Step 02b: Update ACCOUNT MARKETING LIFECYCLE TABLE WITH OPP DATA to account for Opp Stage 
 
 /*
	--20250605 Commented out by Vishva
		UPDATE ACT_MRKT_LIFECYCLE.AMLH_OPPS
		SET 
			AMLH_ACCOUNT_JOURNEY_PATH_LIFECYCLE_NONLINEAR_FLAG = 'Non-Linear',
			AMLH_ACCOUNT_JOURNEY_PATH_LIFECYCLE_NONLINEAR_FLAG_REASON =
				CASE
				WHEN amlh_suspect_date_stamp__c_cast IS NULL THEN 'Opp 000: Suspect Date is NULL'
				WHEN opp_stage_0_date < amlh_suspect_date_stamp__c_cast THEN 'Opp 00a: Nurture Date before Suspect Date'
				WHEN opp_stage_1_date < opp_stage_0_date THEN 'Opp 01a: Qualify Date before Nurture Date'
				WHEN opp_stage_2_date < opp_stage_1_date THEN 'Opp 02a: Discover Date before Qualify Date'
				WHEN opp_stage_3_date < opp_stage_2_date THEN 'Opp 03a: Propose Date before Discover Date'
				WHEN opp_stage_4_date < opp_stage_3_date THEN 'Opp 04a: Validate Date before Propose Date'
				WHEN opp_stage_5_date < opp_stage_4_date THEN 'Opp 05a: Negotiate Date before Validate Date'
				WHEN opp_stage_5_date IS NOT NULL 
					AND (opp_stage_4_date IS NULL OR opp_stage_3_date IS NULL 
						 OR opp_stage_2_date IS NULL OR opp_stage_1_date IS NULL 
						 OR opp_stage_0_date IS NULL OR amlh_suspect_date_stamp__c_cast IS NULL) 
					THEN 'Opp 05b: Negotiate Date exists but earlier stages are missing'
				WHEN opp_stage_4_date IS NOT NULL 
					AND (opp_stage_3_date IS NULL OR opp_stage_2_date IS NULL 
						 OR opp_stage_1_date IS NULL OR opp_stage_0_date IS NULL 
						 OR amlh_suspect_date_stamp__c_cast IS NULL) 
					THEN 'Opp 04b: Validate Date exists but earlier stages are missing'
				WHEN opp_stage_3_date IS NOT NULL 
					AND (opp_stage_2_date IS NULL OR opp_stage_1_date IS NULL 
						 OR opp_stage_0_date IS NULL OR amlh_suspect_date_stamp__c_cast IS NULL) 
					THEN 'Opp 03b: Propose Date exists but earlier stages are missing'
				WHEN opp_stage_2_date IS NOT NULL 
					AND (opp_stage_1_date IS NULL OR opp_stage_0_date IS NULL 
						 OR amlh_suspect_date_stamp__c_cast IS NULL) 
					THEN 'Opp 02b: Discover Date exists but earlier stages are missing'
				WHEN opp_stage_1_date IS NOT NULL 
					AND (opp_stage_0_date IS NULL OR amlh_suspect_date_stamp__c_cast IS NULL) 
					THEN 'Opp 01b: Qualify Date exists but earlier stages are missing'
				ELSE AMLH_ACCOUNT_JOURNEY_PATH_LIFECYCLE_NONLINEAR_FLAG_REASON -- Keep existing reason if no issue
				END
		
		WHERE AMLH_ACCOUNT_JOURNEY_PATH_LIFECYCLE_NONLINEAR_FLAG = 'Linear'
		AND OPP_ID IS NOT NULL 
		AND (
			AMLH_SUSPECT_DATE_STAMP__C_CAST IS NULL 
			OR OPP_STAGE_0_DATE < AMLH_SUSPECT_DATE_STAMP__C_CAST 
			OR OPP_STAGE_1_DATE < OPP_STAGE_0_DATE 
			OR OPP_STAGE_2_DATE < OPP_STAGE_1_DATE 
			OR OPP_STAGE_3_DATE < OPP_STAGE_2_DATE 
			OR OPP_STAGE_4_DATE < OPP_STAGE_3_DATE 
			OR OPP_STAGE_5_DATE < OPP_STAGE_4_DATE 
			OR (OPP_STAGE_5_DATE IS NOT NULL AND (
				OPP_STAGE_4_DATE IS NULL 
				OR OPP_STAGE_3_DATE IS NULL 
				OR OPP_STAGE_2_DATE IS NULL 
				OR OPP_STAGE_1_DATE IS NULL 
				OR OPP_STAGE_0_DATE IS NULL 
				OR AMLH_SUSPECT_DATE_STAMP__C_CAST IS NULL))
			OR (OPP_STAGE_4_DATE IS NOT NULL AND (
				OPP_STAGE_3_DATE IS NULL 
				OR OPP_STAGE_2_DATE IS NULL 
				OR OPP_STAGE_1_DATE IS NULL 
				OR OPP_STAGE_0_DATE IS NULL 
				OR AMLH_SUSPECT_DATE_STAMP__C_CAST IS NULL))
			OR (OPP_STAGE_3_DATE IS NOT NULL AND (
				OPP_STAGE_2_DATE IS NULL 
				OR OPP_STAGE_1_DATE IS NULL 
				OR OPP_STAGE_0_DATE IS NULL 
				OR AMLH_SUSPECT_DATE_STAMP__C_CAST IS NULL))
			OR (OPP_STAGE_2_DATE IS NOT NULL AND (
				OPP_STAGE_1_DATE IS NULL 
				OR OPP_STAGE_0_DATE IS NULL 
				OR AMLH_SUSPECT_DATE_STAMP__C_CAST IS NULL))
			OR (OPP_STAGE_1_DATE IS NOT NULL AND (
				OPP_STAGE_0_DATE IS NULL 
				OR AMLH_SUSPECT_DATE_STAMP__C_CAST IS NULL))
		);
RAISE INFO 'step 2b complete';

*/      
       
     -- Step 03a: Touchtype 6Sense Paid Media Performance Files

     DROP TABLE IF EXISTS ACT_MRKT_LIFECYCLE.TOUCHTYPE_6SENSE_PAIDMEDIA CASCADE;    
     CREATE TABLE ACT_MRKT_LIFECYCLE.TOUCHTYPE_6SENSE_PAIDMEDIA as

     SELECT
        *
    FROM
        (
            SELECT
                -- 6Sense Paid Media Vendor File
                '6Sense - Paid Media' AS MARKETING_TOUCH_TYPE_DATA_SOURCE,
                abm_pd.CRM_ACCOUNT_ID,
                CAST(abm_pd.DATE as DATE) AS MARKETING_TOUCHPOINT_DATE,
                -- Deriving the Touch Type
                CASE
                    WHEN (
                        abm_pd.IMPRESSIONS > 0
                        AND abm_pd.CLICKS > 0
                    ) THEN 'Impression and Ad Click'
                    WHEN (
                        abm_pd.IMPRESSIONS > 0
                        AND abm_pd.CLICKS = 0
                    ) THEN 'Impression'
                    WHEN (
                        abm_pd.IMPRESSIONS = 0
                        AND abm_pd.CLICKS > 0
                    ) THEN 'Ad Click'
                END AS MARKETING_TOUCH_TYPE,
                -- Deriving the Touch Type Count
                CASE
                    WHEN (
                        abm_pd.IMPRESSIONS > 0
                        AND abm_pd.CLICKS > 0
                    ) THEN (abm_pd.IMPRESSIONS + abm_pd.CLICKS)
                    WHEN (
                        abm_pd.IMPRESSIONS > 0
                        AND abm_pd.CLICKS = 0
                    ) THEN abm_pd.IMPRESSIONS
                    WHEN (
                        abm_pd.IMPRESSIONS = 0
                        AND abm_pd.CLICKS > 0
                    ) THEN abm_pd.CLICKS
                END AS MARKETING_TOUCH_TYPE_COUNT,
				--20250314
				abm_pd.SPEND AS SPEND,
                abm_pd.IMPRESSIONS AS INTERACTIONTYPE_SIXSENSE_PAIDMEDIA_IMPRESSIONS_COUNT,
                abm_pd.CLICKS AS INTERACTIONTYPE_SIXSENSE_PAIDMEDIA_CLICKS_COUNT,
                -- Designating the Acquisition Channel to align with the Bizible Channel Mapping
                CASE
				--20250522 Fix to apply 6Sense LinkedIn Campaigns accurately since Raw Data has it pulled into 6Sense - Media vs. 6Sense - LinkedIn
	                WHEN (AD_VENDOR = '6Sense - Media' AND LOWER(abm_pd.CAMPAIGN_NAME) LIKE 'linkedin%') THEN 'Paid Social.6Sense.LinkedIn'
                    WHEN AD_VENDOR = '6Sense - Media' THEN 'Display.6Sense'
                    WHEN AD_VENDOR = '6Sense - External' THEN 'Display.6Sense.External'
                    WHEN AD_VENDOR = '6Sense - LinkedIn' THEN 'Paid Social.6Sense.LinkedIn'
                END AS INFLUENCE_CHANNEL,
                -- Designating the Acquisition Web Source
                '6sense' AS INFLUENCE_WEB_SOURCE,
                -- Designating the Acquisition Web Medium
                CASE
				--20250522 Fix to apply 6Sense LinkedIn Campaigns accurately since Raw Data has it pulled into 6Sense - Media vs. 6Sense - LinkedIn
	                WHEN (AD_VENDOR = '6Sense - Media' AND LOWER(abm_pd.CAMPAIGN_NAME) LIKE 'linkedin%') THEN 'paidsocial' 
                    WHEN AD_VENDOR = '6Sense - Media' THEN 'display'
                    WHEN AD_VENDOR = '6Sense - External' THEN 'display'
                    WHEN AD_VENDOR = '6Sense - LinkedIn' THEN 'paidsocial'
                END AS INFLUENCE_WEB_MEDIUM,
                -- Designating the Acquisition Campaign
                abm_pd.CAMPAIGN_NAME AS INFLUENCE_CAMPAIGN_NAME,
				
				-- Market Segment
				CASE 
				-- Trucking and Local
					WHEN LOWER(abm_pd.CAMPAIGN_NAME) LIKE '%t&l%' THEN 'Trucking and Local'
					WHEN LOWER(abm_pd.CAMPAIGN_NAME) LIKE '%tl%' THEN 'Trucking and Local'
					WHEN LOWER(abm_pd.CAMPAIGN_NAME) LIKE '%truck%' THEN 'Trucking and Local'
					WHEN LOWER(abm_pd.CAMPAIGN_NAME) LIKE '%trucking%' THEN 'Trucking and Local'
					WHEN LOWER(abm_pd.CAMPAIGN_NAME) LIKE '%local%' THEN 'Trucking and Local'
				-- Field Services
					WHEN LOWER(abm_pd.CAMPAIGN_NAME) LIKE '%fs%' THEN 'Field Services'
					WHEN LOWER(abm_pd.CAMPAIGN_NAME) LIKE '%field%' THEN 'Field Services'
					WHEN LOWER(abm_pd.CAMPAIGN_NAME) LIKE '%service%' THEN 'Field Services'
				-- Government
					WHEN LOWER(abm_pd.CAMPAIGN_NAME) LIKE '%gov%' THEN 'Government'
					ELSE 'Not Categorized'
				END AS INFLUENCE_CAMPAIGN_MARKET_SEGMENT, 

				-- Campaign Type
				CASE 
				-- Opportunity Creation
					WHEN LOWER(abm_pd.CAMPAIGN_NAME) LIKE '%opp creation%' THEN 'Opportunity Creation'
					WHEN LOWER(abm_pd.CAMPAIGN_NAME) LIKE '%opportunity%' THEN 'Opportunity Creation'
					WHEN LOWER(abm_pd.CAMPAIGN_NAME) LIKE '%creation%' THEN 'Opportunity Creation'
				-- Pipeline Acceleration
					WHEN LOWER(abm_pd.CAMPAIGN_NAME) LIKE '%pipeline acceleration%' THEN 'Pipeline Acceleration'
					WHEN LOWER(abm_pd.CAMPAIGN_NAME) LIKE '%pipeline%' THEN 'Pipeline Acceleration'
					WHEN LOWER(abm_pd.CAMPAIGN_NAME) LIKE '%acceleration%' THEN 'Pipeline Acceleration'
				-- Full Funnel
					WHEN LOWER(abm_pd.CAMPAIGN_NAME) LIKE '%full funnel%' THEN 'Full Funnel'
					WHEN LOWER(abm_pd.CAMPAIGN_NAME) LIKE '%funnel%' THEN 'Full Funnel'
					ELSE 'Not Categorized'
				END AS INFLUENCE_CAMPAIGN_TYPE, 
		
                abm_pd.UTM_CAMPAIGN AS INFLUENCE_UTM_CAMPAIGN,
                abm_pd.UTM_CONTENT AS INFLUENCE_UTM_CONTENT,
                abm_pd.UTM_TERM AS INFLUENCE_UTM_TERM,
                abm_pd.AD_NAME AS INFLUENCE_AD_NAME,

                -- Assigning (not set) value to the following fields. Hopefully we can map fields into the below
                '(not set)'::text AS INFLUENCE_CREATIVE_NAME,
                abm_pd.CLICK_URLS AS INFLUENCE_LANDING_PAGE,
                '(not set)'::text AS INFLUENCE_REFERRER,
                -- This is more applicable for the 6Sense Web Visit file where you can go from page 1 to page 2 and the webvisit page would be the page you are on
                '(not set)'::text AS WEBVISIT_PAGE,
                '(not set)'::text AS WEBVISIT_REFERRER
            FROM
                (
                    SELECT
                        CRM_ACCOUNT_ID,
                        AD_VENDOR,
                        CAMPAIGN_ID,
                        CAMPAIGN_NAME,
                        UTM_CAMPAIGN,
						-- Setting to '(not set)' to process faster for interim period
                        '(not set)'::text AS UTM_CONTENT,
                        '(not set)'::text AS UTM_TERM,
                        '(not set)'::text AS AD_NAME,
                        CLICK_URLS,
                        DATE,
                        SUM(COALESCE(IMPRESSIONS,0)) AS IMPRESSIONS,
                        SUM(COALESCE(CLICKS,0)) AS CLICKS,
                        SUM(COALESCE(NEWLY_ENGAGED,0)) AS NEWLY_ENGAGED,
                        SUM(COALESCE(INCREASED_ENGAGEMENT,0)) AS INCREASED_ENGAGEMENT,
                        SUM(COALESCE(SPEND,0)) AS SPEND
                    FROM
                        (
                            SELECT
                                RECORD_CREATION_TS,
                                CRM_ACCOUNT_ID,
                                CRM_ACCOUNT_NAME,
                                CRM_ACCOUNT_COUNTRY,
                                CRM_ACCOUNT_DOMAIN,
                                "6SENSE_MID",
                                "6SENSE_ACCOUNT_NAME",
                                "6SENSE_ACCOUNT_COUNTRY",
                                "6SENSE_ACCOUNT_DOMAIN",
                                AD_ID,
                                AD_NAME,
                                AD_GROUP,
                                '6Sense - Media' AS AD_VENDOR,
                                "6SENSE_CAMPAIGN_ID" AS CAMPAIGN_ID,
                                "6SENSE_CAMPAIGN_NAME" AS CAMPAIGN_NAME,
                                UTM_CAMPAIGN,
                                UTM_CONTENT,
                                CAST(UTM_TERM AS VARCHAR(255)) AS UTM_TERM,
                                CLICK_URLS,
                                CAST(DATE AS DATE) AS DATE,
                                IMPRESSIONS,
                                CLICKS,
                                NEWLY_ENGAGED,
                                INCREASED_ENGAGEMENT,
                                SPEND
                            FROM
                                DP_PROD_DB_SH.SIX_SENSE.SIX_SENSE_MEDIA
                            UNION
                            SELECT
                                RECORD_CREATION_TS,
                                CRM_ACCOUNT_ID,
                                CRM_ACCOUNT_NAME,
                                CRM_ACCOUNT_COUNTRY,
                                CRM_ACCOUNT_DOMAIN,
                                "6SENSE_MID",
                                "6SENSE_ACCOUNT_NAME",
                                "6SENSE_ACCOUNT_COUNTRY",
                                "6SENSE_ACCOUNT_DOMAIN",
                                AD_ID,
                                AD_NAME,
                                AD_GROUP,
                                '6Sense - LinkedIn' AS AD_VENDOR,
                                LINKEDIN_CAMPAIGN_ID AS CAMPAIGN_ID,
                                LINKEDIN_CAMPAIGN_NAME AS CAMPAIGN_NAME,
                                UTM_CAMPAIGN,
                                UTM_CONTENT,
                                CAST(UTM_TERM AS VARCHAR(255)) AS UTM_TERM,
                                CLICK_URLS,
                                CAST(DATE AS DATE) AS DATE,
                                IMPRESSIONS,
                                CLICKS,
                                NEWLY_ENGAGED,
                                INCREASED_ENGAGEMENT,
                                SPEND
                            FROM
                                DP_PROD_DB_SH.SIX_SENSE.LINKEDIN_MEDIA
                            UNION
                            SELECT
                                RECORD_CREATION_TS,
                                CRM_ACCOUNT_ID,
                                CRM_ACCOUNT_NAME,
                                CRM_ACCOUNT_COUNTRY,
                                CRM_ACCOUNT_DOMAIN,
                                "6SENSE_MID",
                                "6SENSE_ACCOUNT_NAME",
                                "6SENSE_ACCOUNT_COUNTRY",
                                "6SENSE_ACCOUNT_DOMAIN",
                                "6SENSE_AD_ID" AS AD_ID,
                                "6SENSE_AD_NAME" AS AD_NAME,
                                AD_GROUP,
                                '6Sense - External' AS AD_VENDOR,
                                "6SENSE_CAMPAIGN_ID" AS CAMPAIGN_ID,
                                "6SENSE_CAMPAIGN_NAME" AS CAMPAIGN_NAME,
                                UTM_CAMPAIGN,
                                UTM_CONTENT,
                                CAST(UTM_TERM AS VARCHAR(255)) AS UTM_TERM,
                                CLICK_URLS,
                                CAST(DATE AS DATE) AS DATE,
                                IMPRESSIONS,
                                CLICKS,
                                NEWLY_ENGAGED,
                                INCREASED_ENGAGEMENT,
                                NULL AS SPEND
                            FROM
                                DP_PROD_DB_SH.SIX_SENSE.EXTERNAL_MEDIA
                        ) AS x
                    GROUP BY
                        CRM_ACCOUNT_ID,
                        AD_VENDOR,
                        CAMPAIGN_ID,
                        CAMPAIGN_NAME,
                        UTM_CAMPAIGN,
                        --UTM_CONTENT,
                        --UTM_TERM,
                        --AD_NAME,
                        CLICK_URLS,
                        DATE
-- 2025-04-05
--                        LAST_DAY(cast("DATE" as DATE)),
--                        cast(dateadd(day, -1, dateadd(QTR,1,DATE_TRUNC('QTR', cast("DATE" as DATE)))) as date)
                    HAVING
                        (
						--20250314
                            SUM(COALESCE(IMPRESSIONS,0)) + SUM(COALESCE(CLICKS,0)) + SUM(COALESCE(SPEND,0))
                        ) > 0
                    ORDER BY
                        LAST_DAY(cast("DATE" as DATE)) DESC
                ) as abm_pd
        );
RAISE INFO 'step 3a complete';



-- Step 03b: Touchtype 6Sense Web Visit Activity Files
DROP TABLE IF EXISTS ACT_MRKT_LIFECYCLE.TOUCHTYPE_6SENSE_WEBVISIT CASCADE;

CREATE TABLE ACT_MRKT_LIFECYCLE.TOUCHTYPE_6SENSE_WEBVISIT AS
WITH webvisit_base AS (
    SELECT
        CRM_ACCOUNT_ID,
        DATE_VISITED,
        UTM_SOURCE,
        UTM_MEDIUM,
        UTM_CAMPAIGN,
		-- Setting to '(not set)' to process faster for interim period
        '(not set)'::text AS UTM_CONTENT,
        '(not set)'::text AS UTM_TERM,
        URL,
        REFERRER_DOMAIN,
        SUM(COALESCE("unclassified", 0)) AS Total_unclassified,
        SUM(COALESCE("a_pageload", 0)) AS Total_a_pageload,
        SUM(COALESCE("play", 0)) AS Total_play,
        SUM(COALESCE("click", 0)) AS Total_click,
        SUM(COALESCE("submit", 0)) AS Total_submit,
        SUM(COALESCE("a_pageload", 0) + COALESCE("play", 0) + COALESCE("click", 0) + COALESCE("submit", 0)) AS Total_interaction
    FROM (
        SELECT * FROM (
            SELECT * FROM DP_PROD_DB_SH.SIX_SENSE.WEB_VISIT --WHERE DATE_VISITED BETWEEN '2025-03-30' AND '2025-03-31' AND CRM_ACCOUNT_ID = '0011E00001iUuUTQA0'
        ) PIVOT(
            SUM(TOTAL) FOR EVENT IN ('unclassified', 'a_pageload', 'play', 'click', 'submit')
        ) p
    ) x
    GROUP BY CRM_ACCOUNT_ID, DATE_VISITED, UTM_SOURCE, UTM_MEDIUM, UTM_CAMPAIGN, 
	--UTM_CONTENT, UTM_TERM, 
	URL, REFERRER_DOMAIN
),

--SELECT * FROM webvisit_base ORDER BY CRM_ACCOUNT_ID

cmp_cleaned AS (
    SELECT DISTINCT
        name,
        REPLACE(LOWER(name), '-', '') AS removehyphen_name
    FROM SALESFORCE_BT.campaign
    WHERE name LIKE '%-%'
),

--SELECT * FROM cmp_cleaned;

webvisit_base_adj AS (
    SELECT
        wb.CRM_ACCOUNT_ID,
        wb.DATE_VISITED,
            CASE
                WHEN wb.UTM_SOURCE IS NULL AND wb.UTM_MEDIUM IS NULL AND wb.REFERRER_DOMAIN LIKE '%google%' THEN 'google'
                WHEN wb.UTM_SOURCE IS NULL AND wb.UTM_MEDIUM IS NULL AND wb.REFERRER_DOMAIN LIKE '%bing%' THEN 'bing'
                WHEN wb.UTM_SOURCE IS NULL AND wb.UTM_MEDIUM IS NULL AND wb.REFERRER_DOMAIN LIKE '%yahoo%' THEN 'yahoo'
                WHEN wb.UTM_SOURCE IS NULL AND wb.UTM_MEDIUM IS NULL AND wb.REFERRER_DOMAIN LIKE '%duckduckgo%' THEN 'duckduckgo'
                WHEN wb.UTM_SOURCE IS NULL AND wb.UTM_MEDIUM IS NULL AND wb.REFERRER_DOMAIN LIKE '%linkedin%' THEN 'linkedin'
                WHEN wb.UTM_SOURCE IS NULL AND wb.UTM_MEDIUM IS NULL AND wb.REFERRER_DOMAIN LIKE '%facebook%' THEN 'facebook'
                WHEN wb.UTM_SOURCE IS NULL AND wb.UTM_MEDIUM IS NULL AND wb.REFERRER_DOMAIN LIKE '%twitter%' THEN 'twitter'
                ELSE COALESCE(NULLIF(wb.UTM_SOURCE, ''),'(not set)')
            END AS UTM_SOURCE,
            CASE
                WHEN wb.UTM_SOURCE IS NULL AND wb.UTM_MEDIUM IS NULL AND wb.REFERRER_DOMAIN LIKE '%google%' THEN 'organic search'
                WHEN wb.UTM_SOURCE IS NULL AND wb.UTM_MEDIUM IS NULL AND wb.REFERRER_DOMAIN LIKE '%bing%' THEN 'organic search'
                WHEN wb.UTM_SOURCE IS NULL AND wb.UTM_MEDIUM IS NULL AND wb.REFERRER_DOMAIN LIKE '%yahoo%' THEN 'organic search'
                WHEN wb.UTM_SOURCE IS NULL AND wb.UTM_MEDIUM IS NULL AND wb.REFERRER_DOMAIN LIKE '%duckduckgo%' THEN 'organic search'
                WHEN wb.UTM_SOURCE IS NULL AND wb.UTM_MEDIUM IS NULL AND wb.REFERRER_DOMAIN LIKE '%linkedin%' THEN 'organic social'
                WHEN wb.UTM_SOURCE IS NULL AND wb.UTM_MEDIUM IS NULL AND wb.REFERRER_DOMAIN LIKE '%facebook%' THEN 'organic social'
                WHEN wb.UTM_SOURCE IS NULL AND wb.UTM_MEDIUM IS NULL AND wb.REFERRER_DOMAIN LIKE '%twitter%' THEN 'organic social'

                ELSE COALESCE(NULLIF(wb.UTM_MEDIUM, ''),'(not set)'::text)
            END AS UTM_MEDIUM,
        COALESCE(c.name, NULLIF(wb.UTM_CAMPAIGN, ''), '(not set)'::text) AS UTM_CAMPAIGN,
        COALESCE(NULLIF(wb.UTM_CONTENT, ''), '(not set)'::text) AS UTM_CONTENT,
        COALESCE(NULLIF(wb.UTM_TERM, ''), '(not set)'::text) AS UTM_TERM,
        COALESCE(NULLIF(wb.URL, ''), '(not set)'::text) AS URL,
        COALESCE(NULLIF(wb.REFERRER_DOMAIN, ''), '(not set)'::text) AS REFERRER_DOMAIN,       
        wb.Total_unclassified,
        wb.Total_a_pageload,
        wb.Total_play,
        wb.Total_click,
        wb.Total_submit,
        wb.Total_interaction
	FROM webvisit_base wb
    LEFT JOIN cmp_cleaned c ON wb.UTM_CAMPAIGN = c.removehyphen_name
),

--SELECT * FROM webvisit_base_adj;

utm_ranked AS (
    SELECT * FROM (
        SELECT
            CRM_ACCOUNT_ID,
            DATE_VISITED,
			UTM_SOURCE,
            UTM_MEDIUM,
            UTM_CAMPAIGN,
            ROW_NUMBER() OVER (
                PARTITION BY CRM_ACCOUNT_ID, DATE_VISITED
                ORDER BY SUM(COALESCE("Total_interaction",0)) DESC, UTM_SOURCE, UTM_MEDIUM, UTM_CAMPAIGN
            ) AS rnk,
            SUM(COALESCE("Total_interaction",0)) AS Total_interaction
        FROM webvisit_base_adj
        GROUP BY CRM_ACCOUNT_ID, DATE_VISITED, UTM_SOURCE, UTM_MEDIUM, UTM_CAMPAIGN
    ) --WHERE rnk = 1
),

--SELECT * FROM utm_ranked;

utm_ranked_filtered AS (
        SELECT
            wba.CRM_ACCOUNT_ID,
            wba.DATE_VISITED,
			wba.UTM_SOURCE,
            wba.UTM_MEDIUM,
            wba.UTM_CAMPAIGN,
            ROW_NUMBER() OVER (
                PARTITION BY wba.CRM_ACCOUNT_ID, wba.DATE_VISITED
                ORDER BY wba.Total_interaction DESC, wba.UTM_SOURCE, wba.UTM_MEDIUM, wba.UTM_CAMPAIGN
            ) AS rnk,
            wba.Total_interaction
        FROM (
				SELECT
	            CRM_ACCOUNT_ID,
	            DATE_VISITED,
				UTM_SOURCE,
	            UTM_MEDIUM,
            	UTM_CAMPAIGN,
        		SUM(COALESCE("Total_interaction",0)) AS Total_interaction
        		FROM webvisit_base_adj
        		WHERE (UTM_SOURCE <> '(not set)' AND UTM_MEDIUM <> '(not set)' )
        		GROUP BY CRM_ACCOUNT_ID, DATE_VISITED, UTM_SOURCE, UTM_MEDIUM, UTM_CAMPAIGN
    		) wba
),

--SELECT * FROM utm_ranked_filtered;

utm_coalesced AS (
    SELECT
        wb.*,
        CASE
            WHEN wb.UTM_SOURCE = '(not set)' AND wb.UTM_MEDIUM = '(not set)' AND (LOWER(wb.REFERRER_DOMAIN) LIKE '%lytx.com%' OR wb.REFERRER_DOMAIN = '(not set)')
                THEN COALESCE(urf.UTM_SOURCE,ur.UTM_SOURCE, wb.UTM_SOURCE)
            ELSE wb.UTM_SOURCE
        END AS COALESCED_SOURCE,
        CASE
            WHEN wb.UTM_SOURCE = '(not set)' AND wb.UTM_MEDIUM = '(not set)' AND (LOWER(wb.REFERRER_DOMAIN) LIKE '%lytx.com%' OR wb.REFERRER_DOMAIN = '(not set)')
                THEN COALESCE(urf.UTM_MEDIUM,ur.UTM_MEDIUM, wb.UTM_MEDIUM)
            ELSE wb.UTM_MEDIUM
        END AS COALESCED_MEDIUM,
        CASE
            WHEN wb.UTM_SOURCE = '(not set)' AND wb.UTM_MEDIUM = '(not set)' AND (LOWER(wb.REFERRER_DOMAIN) LIKE '%lytx.com%' OR wb.REFERRER_DOMAIN = '(not set)')
                THEN COALESCE(urf.UTM_CAMPAIGN,ur.UTM_CAMPAIGN, wb.UTM_CAMPAIGN)
            ELSE wb.UTM_CAMPAIGN
        END AS COALESCED_CAMPAIGN
    FROM webvisit_base_adj wb
    LEFT JOIN utm_ranked ur
        ON wb.CRM_ACCOUNT_ID = ur.CRM_ACCOUNT_ID AND wb.DATE_VISITED = ur.DATE_VISITED AND ur.rnk = 1
    LEFT JOIN utm_ranked_filtered urf
        ON wb.CRM_ACCOUNT_ID = urf.CRM_ACCOUNT_ID AND wb.DATE_VISITED = urf.DATE_VISITED AND urf.rnk = 1
),

--SELECT * FROM utm_coalesced;

channel_mapping AS (
    SELECT DISTINCT 
--        wb.CRM_ACCOUNT_ID,
--        wb.DATE_VISITED,
--        wb.URL,
        wb.REFERRER_DOMAIN,
        wb.COALESCED_SOURCE,
        wb.COALESCED_MEDIUM,
        CASE
            WHEN wb.COALESCED_SOURCE = '(not set)' AND wb.COALESCED_MEDIUM = '(not set)' AND wb.REFERRER_DOMAIN ='(not set)' THEN 'Other.NotDefined'
            WHEN wb.COALESCED_SOURCE = '(not set)' AND wb.COALESCED_MEDIUM = '(not set)' AND (
                wb.REFERRER_DOMAIN LIKE '%app.asana.com%' OR
                wb.REFERRER_DOMAIN LIKE '%app.drift.com%' OR
                wb.REFERRER_DOMAIN LIKE '%app.mutinyhq.com%' OR
                wb.REFERRER_DOMAIN LIKE '%preview.mutinyhq.com%' OR
                wb.REFERRER_DOMAIN LIKE '%app.reactful.com%' OR
                wb.REFERRER_DOMAIN LIKE '%app.uberflip%' OR
                wb.REFERRER_DOMAIN LIKE '%app.%' OR
                wb.REFERRER_DOMAIN LIKE '%abm.6sense.com%' OR
                wb.REFERRER_DOMAIN LIKE '%clicktools.com%' OR
                wb.REFERRER_DOMAIN LIKE '%teams.microsoft.com%' OR
                wb.REFERRER_DOMAIN LIKE '%lightning.force.com%'
            ) THEN 'Other.Misc'
           
            WHEN wb.COALESCED_SOURCE = 'google' AND wb.COALESCED_MEDIUM IN ('organic search','(not set)') THEN 'Organic Search.Google'
            WHEN wb.COALESCED_SOURCE = 'bing' AND wb.COALESCED_MEDIUM IN ('organic search','(not set)') THEN 'Organic Search.Bing'
            WHEN wb.COALESCED_SOURCE = 'yahoo' AND wb.COALESCED_MEDIUM IN ('organic search','(not set)') THEN 'Organic Search.Yahoo'
            WHEN wb.COALESCED_SOURCE = 'duckduckgo' AND wb.COALESCED_MEDIUM IN ('organic search','(not set)') THEN 'Organic Search.DuckDuckGo'

            WHEN wb.COALESCED_SOURCE = 'linkedin' AND wb.COALESCED_MEDIUM = 'organic social' THEN 'Organic Social.LinkedIn'
            WHEN wb.COALESCED_SOURCE = 'facebook' AND wb.COALESCED_MEDIUM = 'organic social' THEN 'Organic Social.Facebook'
            WHEN wb.COALESCED_SOURCE = 'twitter' AND wb.COALESCED_MEDIUM = 'organic social' THEN 'Organic Social.Twitter'

            WHEN wb.COALESCED_SOURCE IN ('lytx','hootsuite','lytxnusnewseventspressrelease2021lytxlaunchesthelytxintegrationnetwork','(not set)') AND wb.COALESCED_MEDIUM IN ('linkedin') THEN 'Organic Social.LinkedIn'
            WHEN wb.COALESCED_SOURCE = 'lytx' AND wb.COALESCED_MEDIUM IN ('facebook','facebooklinkedin') THEN 'Organic Social.Facebook'
            WHEN wb.COALESCED_SOURCE = 'facebookcom' AND wb.COALESCED_MEDIUM IN ('social') THEN 'Organic Social.Facebook'
            WHEN wb.COALESCED_SOURCE IN ('fbads','lytxtxcomblogovercomingbarrierstoadoptionofvideotelematics') AND wb.COALESCED_MEDIUM IN ('facebook') THEN 'Organic Social.Facebook'
			WHEN wb.COALESCED_SOURCE = 'facebookceres' AND wb.COALESCED_MEDIUM IN ('referral') THEN 'Organic Social.Facebook'
            
            WHEN wb.COALESCED_SOURCE = 'lytx' AND wb.COALESCED_MEDIUM IN ('linkedin') THEN 'Organic Social.LinkedIn'
            WHEN wb.COALESCED_SOURCE IN ('lytx','hootsuite') AND wb.COALESCED_MEDIUM IN ('twitter') THEN 'Organic Social.Twitter'
            WHEN wb.COALESCED_SOURCE IN ('twittercom') AND wb.COALESCED_MEDIUM IN ('social') THEN 'Organic Social.Twitter'            
            WHEN wb.COALESCED_SOURCE IN ('lytx') AND wb.COALESCED_MEDIUM IN ('socialnetwork') THEN 'Organic Social.Other'   
            WHEN wb.COALESCED_SOURCE IN ('hootsuite') AND wb.COALESCED_MEDIUM IN ('social') THEN 'Organic Social.Other'            
            
            WHEN wb.COALESCED_SOURCE = '6sense' AND wb.COALESCED_MEDIUM IN ('cpc', 'display', 'ppc') THEN 'Display.6Sense'
            WHEN wb.COALESCED_SOURCE = '6sifiltered' AND wb.COALESCED_MEDIUM IN ('cpc', 'display', 'ppc') THEN 'Display.6Sense'
            WHEN wb.COALESCED_SOURCE = '6senes' AND wb.COALESCED_MEDIUM IN ('cpc', 'display', 'ppc') THEN 'Display.6Sense'
            WHEN wb.COALESCED_SOURCE = '6sense' AND wb.COALESCED_MEDIUM = '(not set)' THEN 'Display.6Sense'
            WHEN wb.COALESCED_SOURCE = 'adlingo' AND wb.COALESCED_MEDIUM IN ('cpc', 'display', 'ppc') THEN 'Display.Adlingo'
            WHEN wb.COALESCED_SOURCE = 'adlingo' AND wb.COALESCED_MEDIUM = '(not set)' THEN 'Display.Adlingo'

            WHEN wb.COALESCED_SOURCE = 'google' AND wb.COALESCED_MEDIUM IN ('cpc', 'ppc', 'cpcignore', 'pc') THEN 'Paid Search.Google'
            WHEN wb.COALESCED_SOURCE = 'google' AND wb.COALESCED_MEDIUM IN ('display', 'banner') THEN 'Display.Google'
            WHEN wb.COALESCED_SOURCE IN ('adwords', 'marketingplatformgooglecom') THEN 'Paid Search.Google'
            WHEN wb.COALESCED_SOURCE = 'youtube' AND wb.COALESCED_MEDIUM IN ('cpc') THEN 'Paid Search.Youtube'
            WHEN wb.COALESCED_SOURCE = 'youtube' AND wb.COALESCED_MEDIUM IN ('paidsocial') THEN 'Paid Social.Youtube'
            WHEN wb.COALESCED_SOURCE = 'youtube' THEN 'Organic Social.Youtube'
            WHEN wb.COALESCED_SOURCE = 'bing' AND wb.COALESCED_MEDIUM IN ('cpc', 'ppc', 'cpcignore', 'pc') THEN 'Paid Search.Bing'
            WHEN wb.COALESCED_SOURCE = 'bing' AND wb.COALESCED_MEDIUM IN ('display', 'banner') THEN 'Display.Bing'
            WHEN wb.COALESCED_SOURCE = 'bing' AND wb.COALESCED_MEDIUM = '(not set)' THEN 'Organic Search.Bing'
            WHEN wb.COALESCED_SOURCE = 'yahoo' AND wb.COALESCED_MEDIUM IN ('cpc', 'ppc', 'cpm') THEN 'Paid Search.Yahoo'            
            WHEN wb.COALESCED_SOURCE = 'yahoo' AND wb.COALESCED_MEDIUM = '(not set)' THEN 'Organic Search.Yahoo'
            WHEN wb.COALESCED_SOURCE = 'capterra' AND wb.COALESCED_MEDIUM IN ('cpc', 'ppc') THEN 'Paid Search.Capterra'
            WHEN wb.COALESCED_SOURCE = 'facebook' AND wb.COALESCED_MEDIUM IN ('paidsocial', 'cpc') THEN 'Paid Social.Facebook'
            WHEN wb.COALESCED_SOURCE = 'facebook' THEN 'Organic Social.Facebook'
            WHEN wb.COALESCED_SOURCE = 'twitter' AND wb.COALESCED_MEDIUM IN ('paidsocial', 'cpc') THEN 'Paid Social.Twitter'
            WHEN wb.COALESCED_SOURCE = 'twitter' THEN 'Organic Social.Twitter'
            WHEN wb.COALESCED_SOURCE = 'linkedin' AND wb.COALESCED_MEDIUM IN ('paidsocial', 'cpc') THEN 'Paid Social.LinkedIn'
            WHEN wb.COALESCED_SOURCE = 'linkedin' THEN 'Organic Social.LinkedIn'
            WHEN wb.COALESCED_SOURCE = 'reachdesk' AND wb.COALESCED_MEDIUM IN ('directmail') THEN 'Direct Mail.Other'
            WHEN wb.COALESCED_SOURCE = 'lytxaccount' AND wb.COALESCED_MEDIUM IN ('walkme') THEN 'Lytx.Product'
            WHEN wb.COALESCED_SOURCE = 'walkme' AND wb.COALESCED_MEDIUM IN ('inproduct') THEN 'Lytx.Product'
            WHEN wb.COALESCED_SOURCE = 'dol' AND wb.COALESCED_MEDIUM IN ('referral') THEN 'Lytx.Product'
            WHEN wb.COALESCED_SOURCE = 'lytx' AND wb.COALESCED_MEDIUM IN ('product') THEN 'Lytx.Product'

            WHEN wb.COALESCED_SOURCE = 'fleetnewsdaily' AND wb.COALESCED_MEDIUM IN ('referral') THEN 'Direct Media Buy.Web Referral'
            WHEN wb.COALESCED_SOURCE = 'bobit' AND wb.COALESCED_MEDIUM IN ('native') THEN 'Direct Media Buy.Print'
            WHEN wb.COALESCED_SOURCE = 'fleetnewsdaily' AND wb.COALESCED_MEDIUM IN ('native') THEN 'Direct Media Buy.Display'
            WHEN wb.COALESCED_SOURCE = 'fleetnewsdaily' AND wb.COALESCED_MEDIUM IN ('social') THEN 'Direct Media Buy.Social'
            
            WHEN wb.COALESCED_SOURCE = 'lytxlogin' AND wb.COALESCED_MEDIUM IN ('referral') THEN 'Lytx.Login'

            WHEN wb.COALESCED_SOURCE = 'thefleet' AND wb.COALESCED_MEDIUM IN ('podcast') THEN 'Podcast'

            WHEN wb.COALESCED_SOURCE IN ('g2review') AND wb.COALESCED_MEDIUM IN ('display') THEN 'Web Referral'
            WHEN wb.COALESCED_SOURCE IN ('trustpilot') AND wb.COALESCED_MEDIUM IN ('companyprofile') THEN 'Web Referral'
            WHEN wb.COALESCED_SOURCE IN ('chatgptcom') AND wb.COALESCED_MEDIUM IN ('(not set)') THEN 'Web Referral'
            
--            WHEN wb.COALESCED_SOURCE IN ('chatbot','lytx') AND wb.COALESCED_MEDIUM IN ('chatbot','ebook') THEN 'Internal' || '.' || COALESCE(wb.COALESCED_MEDIUM,'')

            WHEN wb.COALESCED_SOURCE = 'lytx' AND wb.COALESCED_MEDIUM IN ('esignature','emailfollowup') THEN 'Email.Other'
            WHEN wb.COALESCED_SOURCE IN ('opensense') AND wb.COALESCED_MEDIUM IN ('display') THEN 'Email.Other'
            WHEN wb.COALESCED_SOURCE = 'lytx' AND wb.COALESCED_MEDIUM IN ('outreach') THEN 'Email.Outreach'
            WHEN LOWER(wb.COALESCED_MEDIUM) IN ('email', 'newsletter','emailfollowup','totango') THEN 'Email'

            WHEN wb.COALESCED_SOURCE <> '(not set)' AND wb.COALESCED_MEDIUM IN ('virtualshow','virtualhandout') THEN 'Tradeshow.Virtual'
            WHEN wb.COALESCED_SOURCE <> '(not set)' AND wb.COALESCED_MEDIUM IN ('print') THEN 'Print.Other'
            WHEN wb.COALESCED_SOURCE <> '(not set)' AND wb.COALESCED_MEDIUM IN ('paidcontent','display','displayl','banner','cpm') THEN 'Direct Media Buy.Display'
            WHEN wb.COALESCED_SOURCE <> '(not set)' AND wb.COALESCED_MEDIUM IN ('epromo','sponsoredemail') THEN 'Direct Media Buy.Email'

--            WHEN wb.COALESCED_SOURCE <> '(not set)' AND wb.COALESCED_MEDIUM IN ('cpc', 'ppc') THEN 'Paid Search' || '.' || COALESCE(wb.COALESCED_SOURCE,'')

            
            ELSE 'Other.NotDefined'
        END AS INFLUENCE_CHANNEL
    FROM utm_coalesced wb
),

--SELECT * FROM channel_mapping;

final_data AS (
    SELECT
        '6Sense - Web Visit' AS MARKETING_TOUCH_TYPE_DATA_SOURCE,
        wb.CRM_ACCOUNT_ID,
        CAST(wb.DATE_VISITED AS DATE) AS MARKETING_TOUCHPOINT_DATE,

        -- Deriving the Touch Type
		CASE
		    WHEN 
		        COALESCE(wb.Total_a_pageload, 0) > 0
		        AND (
		            COALESCE(Total_play, 0) 
		            + COALESCE(Total_click, 0) 
		            + COALESCE(Total_submit, 0) > 0
		        )
		    THEN 'Web Visit and Interaction'
		
		    WHEN 
		        COALESCE(wb.Total_a_pageload, 0) = 0
		        AND (
		            COALESCE(Total_play, 0) 
		            + COALESCE(Total_click, 0) 
		            + COALESCE(Total_submit, 0) > 0
		        )
		    THEN 'Interaction'
		
		    WHEN 
		        COALESCE(wb.Total_a_pageload, 0) > 0
		        AND (
		            COALESCE(Total_play, 0) 
		            + COALESCE(Total_click, 0) 
		            + COALESCE(Total_submit, 0) = 0
		        )
		    THEN 'Web Visit'
		
		    WHEN COALESCE(wb.Total_a_pageload, 0) > 0 
		    THEN 'Web Visit'
		
		    WHEN COALESCE(wb.Total_unclassified, 0) > 0 
		    THEN 'Unclassified'
		END AS MARKETING_TOUCH_TYPE,
		
		-- Deriving the Touch Type Count
		CASE
		    WHEN 
		        COALESCE(wb.Total_a_pageload, 0) > 0
		        AND (
		            COALESCE(Total_play, 0) 
		            + COALESCE(Total_click, 0) 
		            + COALESCE(Total_submit, 0) > 0
		        )
		    THEN 
		        COALESCE(wb.Total_a_pageload, 0) 
		        + COALESCE(Total_play, 0) 
		        + COALESCE(Total_click, 0) 
		        + COALESCE(Total_submit, 0)
		
		    WHEN 
		        COALESCE(wb.Total_a_pageload, 0) = 0
		        AND (
		            COALESCE(Total_play, 0) 
		            + COALESCE(Total_click, 0) 
		            + COALESCE(Total_submit, 0) > 0
		        )
		    THEN 
		        COALESCE(Total_play, 0) 
		        + COALESCE(Total_click, 0) 
		        + COALESCE(Total_submit, 0)
		
		    WHEN 
		        COALESCE(wb.Total_a_pageload, 0) > 0
		        AND (
		            COALESCE(Total_play, 0) 
		            + COALESCE(Total_click, 0) 
		            + COALESCE(Total_submit, 0) = 0
		        )
		    THEN wb.Total_a_pageload
		
		    WHEN COALESCE(wb.Total_a_pageload, 0) > 0 
		    THEN wb.Total_a_pageload
		
		    WHEN COALESCE(wb.Total_unclassified, 0) > 0 
		    THEN wb.Total_unclassified
		END AS MARKETING_TOUCH_TYPE_COUNT,

		-- Metrics from 6Sense WebVisit File
		COALESCE(wb.Total_interaction,0) INTERACTIONTYPE_SIXSENSE_WEBVISIT_TOTAL_INTERACTIONS_COUNT,
		COALESCE(wb.Total_a_pageload,0) AS INTERACTIONTYPE_SIXSENSE_WEBVISIT_PAGELOAD_COUNT,
		COALESCE(wb.Total_play,0) AS INTERACTIONTYPE_SIXSENSE_WEBVISIT_PLAY_COUNT,
		COALESCE(wb.Total_click,0) AS INTERACTIONTYPE_SIXSENSE_WEBVISIT_CLICK_COUNT,
		COALESCE(wb.Total_submit,0) AS INTERACTIONTYPE_SIXSENSE_WEBVISIT_SUBMIT_COUNT,
		COALESCE(wb.Total_unclassified,0) AS INTERACTIONTYPE_SIXSENSE_WEBVISIT_UNCLASSIFIED_COUNT,

        wb.COALESCED_SOURCE AS INFLUENCE_WEB_SOURCE,
        wb.COALESCED_MEDIUM AS INFLUENCE_WEB_MEDIUM,
        
        cm.INFLUENCE_CHANNEL,

        wb.COALESCED_CAMPAIGN AS INFLUENCE_CAMPAIGN_NAME,
		
			-- Market Segment
			CASE 
			-- Trucking and Local
				WHEN LOWER(wb.COALESCED_CAMPAIGN) LIKE '%t&l%' THEN 'Trucking and Local'
				WHEN LOWER(wb.COALESCED_CAMPAIGN) LIKE '%tl%' THEN 'Trucking and Local'
				WHEN LOWER(wb.COALESCED_CAMPAIGN) LIKE '%truck%' THEN 'Trucking and Local'
				WHEN LOWER(wb.COALESCED_CAMPAIGN) LIKE '%trucking%' THEN 'Trucking and Local'
				WHEN LOWER(wb.COALESCED_CAMPAIGN) LIKE '%local%' THEN 'Trucking and Local'
				-- Field Services
				WHEN LOWER(wb.COALESCED_CAMPAIGN) LIKE '%fs%' THEN 'Field Services'
				WHEN LOWER(wb.COALESCED_CAMPAIGN) LIKE '%field%' THEN 'Field Services'
				WHEN LOWER(wb.COALESCED_CAMPAIGN) LIKE '%service%' THEN 'Field Services'
				-- Government
				WHEN LOWER(wb.COALESCED_CAMPAIGN) LIKE '%gov%' THEN 'Government'
				ELSE 'Not Categorized'
			END AS INFLUENCE_CAMPAIGN_MARKET_SEGMENT, 

				-- Campaign Type
			CASE 
				-- Opportunity Creation
				WHEN LOWER(wb.COALESCED_CAMPAIGN) LIKE '%opp creation%' THEN 'Opportunity Creation'
				WHEN LOWER(wb.COALESCED_CAMPAIGN) LIKE '%opportunity%' THEN 'Opportunity Creation'
				WHEN LOWER(wb.COALESCED_CAMPAIGN) LIKE '%creation%' THEN 'Opportunity Creation'
				-- Pipeline Acceleration
				WHEN LOWER(wb.COALESCED_CAMPAIGN) LIKE '%pipeline acceleration%' THEN 'Pipeline Acceleration'
				WHEN LOWER(wb.COALESCED_CAMPAIGN) LIKE '%pipeline%' THEN 'Pipeline Acceleration'
				WHEN LOWER(wb.COALESCED_CAMPAIGN) LIKE '%acceleration%' THEN 'Pipeline Acceleration'
				-- Full Funnel
				WHEN LOWER(wb.COALESCED_CAMPAIGN) LIKE '%full funnel%' THEN 'Full Funnel'
				WHEN LOWER(wb.COALESCED_CAMPAIGN) LIKE '%funnel%' THEN 'Full Funnel'
				ELSE 'Not Categorized'
			END AS INFLUENCE_CAMPAIGN_TYPE, 

        wb.COALESCED_CAMPAIGN AS INFLUENCE_UTM_CAMPAIGN,
        wb.UTM_CONTENT AS INFLUENCE_UTM_CONTENT,
        wb.UTM_TERM AS INFLUENCE_UTM_TERM,
        '(not set)'::text AS INFLUENCE_AD_NAME,
        '(not set)'::text AS INFLUENCE_CREATIVE_NAME,
        '(not set)'::text AS INFLUENCE_LANDING_PAGE,
        '(not set)'::text AS INFLUENCE_REFERRER,
        wb.URL AS WEBVISIT_PAGE,
        wb.REFERRER_DOMAIN AS WEBVISIT_REFERRER
    FROM utm_coalesced wb
    LEFT JOIN channel_mapping cm ON wb.COALESCED_SOURCE = cm.COALESCED_SOURCE AND wb.COALESCED_MEDIUM = cm.COALESCED_MEDIUM AND wb.REFERRER_DOMAIN = cm.REFERRER_DOMAIN
)

SELECT * FROM final_data;
RAISE INFO 'step 3b complete';

       
    -- Step 03c: Touchtype Bizible TouchPoints File
--     DROP TABLE IF EXISTS ACT_MRKT_LIFECYCLE.TOUCHTYPE_BIZIBLE_TOUCHPOINTS ;
--        CREATE TABLE ACT_MRKT_LIFECYCLE.TOUCHTYPE_BIZIBLE_TOUCHPOINTS as
     DROP TABLE IF EXISTS ACT_MRKT_LIFECYCLE.TOUCHTYPE_BIZIBLE_TOUCHPOINTS CASCADE; 
    CREATE TABLE ACT_MRKT_LIFECYCLE.TOUCHTYPE_BIZIBLE_TOUCHPOINTS as
        
     SELECT
        *
    FROM
        (
            SELECT
                'Bizible' AS MARKETING_TOUCH_TYPE_DATA_SOURCE,
                biz_touchpoints.ACCOUNT_ID AS CRM_ACCOUNT_ID,
                CAST(biz_touchpoints.TOUCHPOINT_DATE as DATE) AS MARKETING_TOUCHPOINT_DATE,
                biz_touchpoints.MARKETING_TOUCH_TYPE,
                biz_touchpoints.MARKETING_TOUCH_TYPE_COUNT,
                CASE
                    WHEN biz_touchpoints.MARKETING_TOUCH_TYPE = 'Web Visit' THEN MARKETING_TOUCH_TYPE_COUNT
                    ELSE 0
                END AS INTERACTIONTYPE_BIZIBLE_TOUCHPOINT_WEBVISIT_COUNT,
                CASE
                    WHEN biz_touchpoints.MARKETING_TOUCH_TYPE = 'Web Chat' THEN MARKETING_TOUCH_TYPE_COUNT
                    ELSE 0
                END AS INTERACTIONTYPE_BIZIBLE_TOUCHPOINT_WEBCHAT_COUNT,
                CASE
                    WHEN biz_touchpoints.MARKETING_TOUCH_TYPE = 'Web Form' THEN MARKETING_TOUCH_TYPE_COUNT
                    ELSE 0
                END AS INTERACTIONTYPE_BIZIBLE_TOUCHPOINT_WEBFORM_COUNT,
                CASE
                    WHEN biz_touchpoints.MARKETING_TOUCH_TYPE = 'CRM' THEN MARKETING_TOUCH_TYPE_COUNT
                    ELSE 0
                END AS INTERACTIONTYPE_BIZIBLE_TOUCHPOINT_CRM_COUNT,
                CASE
                    WHEN biz_touchpoints.MARKETING_TOUCH_TYPE = 'Connect with DM' THEN MARKETING_TOUCH_TYPE_COUNT
                    ELSE 0
                END AS INTERACTIONTYPE_BIZIBLE_TOUCHPOINT_CONNECTWITHDM_COUNT,
                CASE
                    WHEN biz_touchpoints.MARKETING_TOUCH_TYPE = 'Call - Spoke With' THEN MARKETING_TOUCH_TYPE_COUNT
                    ELSE 0
                END AS INTERACTIONTYPE_BIZIBLE_TOUCHPOINT_CALLSPOKEWITH_COUNT,
                CASE
                    WHEN biz_touchpoints.MARKETING_TOUCH_TYPE = 'Call - Gatekeeper' THEN MARKETING_TOUCH_TYPE_COUNT
                    ELSE 0
                END AS INTERACTIONTYPE_BIZIBLE_TOUCHPOINT_CALLGATEKEEPER_COUNT,
                CASE
                    WHEN biz_touchpoints.MARKETING_TOUCH_TYPE = 'NO_LEAD_TOUCHPOINTS' THEN MARKETING_TOUCH_TYPE_COUNT
                    ELSE 0
                END AS INTERACTIONTYPE_BIZIBLE_TOUCHPOINT_NOLEADTOUCHPOINTS_COUNT,
				--20250302
                CASE
                    WHEN biz_touchpoints.MARKETING_TOUCH_TYPE = 'Marketo' THEN MARKETING_TOUCH_TYPE_COUNT
                    ELSE 0
                END AS INTERACTIONTYPE_BIZIBLE_TOUCHPOINT_MARKETO_COUNT,
				--20250314
                CASE
                    WHEN biz_touchpoints.MARKETING_TOUCH_TYPE = 'Seismic Engagement' THEN MARKETING_TOUCH_TYPE_COUNT
                    ELSE 0
                END AS INTERACTIONTYPE_BIZIBLE_TOUCHPOINT_SEISMICENGAGEMENT_COUNT,
				--20250925
                CASE
                    WHEN biz_touchpoints.MARKETING_TOUCH_TYPE = 'change status in progression' THEN MARKETING_TOUCH_TYPE_COUNT
                    ELSE 0
                END AS INTERACTIONTYPE_BIZIBLE_TOUCHPOINT_CHANGESTATUS_COUNT,	
                CASE
                    WHEN biz_touchpoints.MARKETING_TOUCH_TYPE IS NULL THEN MARKETING_TOUCH_TYPE_COUNT
                    ELSE 0
                END AS INTERACTIONTYPE_BIZIBLE_TOUCHPOINT_UNCLASSIFIED_COUNT,
                CASE
                    -- CRM Actvity
                    --WHEN biz_touchpoints.WEB_SOURCE = 'CRM Activity' THEN CONCAT_WS('.',biz_touchpoints."WEB_SOURCE",biz_touchpoints."MEDIUM")
                    WHEN biz_touchpoints.WEB_SOURCE = 'CRM Activity' THEN 'Sales Engagement' || '.' || COALESCE(biz_touchpoints.MEDIUM,'')
                    -- Web Referral
                    WHEN biz_touchpoints.CHANNEL IN ('Other')
                    AND biz_touchpoints.MEDIUM = 'referral' THEN 'Web Referral'
                    ELSE biz_touchpoints.CHANNEL
                END AS INFLUENCE_CHANNEL,
                biz_touchpoints.WEB_SOURCE AS INFLUENCE_WEB_SOURCE,
                biz_touchpoints.MEDIUM AS INFLUENCE_WEB_MEDIUM,
                biz_touchpoints.CAMPAIGN_NAME AS INFLUENCE_CAMPAIGN_NAME,
				
				-- Market Segment
				CASE 
				-- Trucking and Local
					WHEN LOWER(biz_touchpoints.CAMPAIGN_NAME) LIKE '%t&l%' THEN 'Trucking and Local'
					WHEN LOWER(biz_touchpoints.CAMPAIGN_NAME) LIKE '%tl%' THEN 'Trucking and Local'
					WHEN LOWER(biz_touchpoints.CAMPAIGN_NAME) LIKE '%truck%' THEN 'Trucking and Local'
					WHEN LOWER(biz_touchpoints.CAMPAIGN_NAME) LIKE '%trucking%' THEN 'Trucking and Local'
					WHEN LOWER(biz_touchpoints.CAMPAIGN_NAME) LIKE '%local%' THEN 'Trucking and Local'
				-- Field Services
					WHEN LOWER(biz_touchpoints.CAMPAIGN_NAME) LIKE '%fs%' THEN 'Field Services'
					WHEN LOWER(biz_touchpoints.CAMPAIGN_NAME) LIKE '%field%' THEN 'Field Services'
					WHEN LOWER(biz_touchpoints.CAMPAIGN_NAME) LIKE '%service%' THEN 'Field Services'
				-- Government
					WHEN LOWER(biz_touchpoints.CAMPAIGN_NAME) LIKE '%gov%' THEN 'Government'
					ELSE 'Not Categorized'
				END AS INFLUENCE_CAMPAIGN_MARKET_SEGMENT, 

				-- Campaign Type
				CASE 
				-- Opportunity Creation
					WHEN LOWER(biz_touchpoints.CAMPAIGN_NAME) LIKE '%opp creation%' THEN 'Opportunity Creation'
					WHEN LOWER(biz_touchpoints.CAMPAIGN_NAME) LIKE '%opportunity%' THEN 'Opportunity Creation'
					WHEN LOWER(biz_touchpoints.CAMPAIGN_NAME) LIKE '%creation%' THEN 'Opportunity Creation'
				-- Pipeline Acceleration
					WHEN LOWER(biz_touchpoints.CAMPAIGN_NAME) LIKE '%pipeline acceleration%' THEN 'Pipeline Acceleration'
					WHEN LOWER(biz_touchpoints.CAMPAIGN_NAME) LIKE '%pipeline%' THEN 'Pipeline Acceleration'
					WHEN LOWER(biz_touchpoints.CAMPAIGN_NAME) LIKE '%acceleration%' THEN 'Pipeline Acceleration'
				-- Full Funnel
					WHEN LOWER(biz_touchpoints.CAMPAIGN_NAME) LIKE '%full funnel%' THEN 'Full Funnel'
					WHEN LOWER(biz_touchpoints.CAMPAIGN_NAME) LIKE '%funnel%' THEN 'Full Funnel'
					ELSE 'Not Categorized'
				END AS INFLUENCE_CAMPAIGN_TYPE, 
				
                biz_touchpoints.CAMPAIGN_NAME AS INFLUENCE_UTM_CAMPAIGN,
                '(not set)'::text AS INFLUENCE_UTM_CONTENT,
                biz_touchpoints.KEYWORD_NAME AS INFLUENCE_UTM_TERM,
                biz_touchpoints.AD_NAME AS INFLUENCE_AD_NAME,               
                biz_touchpoints.CREATIVE_NAME AS INFLUENCE_CREATIVE_NAME,
                biz_touchpoints.LANDING_PAGE AS INFLUENCE_LANDING_PAGE,
                biz_touchpoints.REFERRER_PAGE AS INFLUENCE_REFERRER,
                biz_touchpoints.LANDING_PAGE AS WEBVISIT_PAGE,
                biz_touchpoints.REFERRER_PAGE AS WEBVISIT_REFERRER
            FROM
                (
                    SELECT
                        ACCOUNT_ID,
                        TOUCHPOINT_DATE,
                        MARKETING_TOUCH_TYPE,
                        COUNT(ROW_KEY) AS MARKETING_TOUCH_TYPE_COUNT,
                        WEB_SOURCE,
                        CHANNEL,
                        MEDIUM,
                        CAMPAIGN_NAME,
						-- Setting to '(not set)' to process faster for interim period
                        '(not set)'::text AS CREATIVE_NAME,
                        '(not set)'::text AS KEYWORD_NAME,
                        '(not set)'::text AS AD_NAME,
                        LANDING_PAGE,
                        REFERRER_PAGE
                    from DP_PROD_DB_SH.bizible.biz_touchpoints 
                    WHERE
                        ACCOUNT_ID IS NOT NULL
                    GROUP BY
                        ACCOUNT_ID,
                        TOUCHPOINT_DATE,
                        MARKETING_TOUCH_TYPE,
                        WEB_SOURCE,
                        CHANNEL,
                        MEDIUM,
                        CAMPAIGN_NAME,
                        --CREATIVE_NAME,
                        --KEYWORD_NAME,
                        --AD_NAME,
                        LANDING_PAGE,
                        REFERRER_PAGE
                ) AS biz_touchpoints
        );  
     
RAISE INFO 'step 3c complete';



    -- Step 04: Touchtype Analytics Table comprehensive of 6Sense Paid Media + 6Sense Web Visit + Bizible
--    DROP TABLE IF EXISTS ACT_MRKT_LIFECYCLE.TOUCHTYPE_ANALYTICS;

--   CREATE TABLE ACT_MRKT_LIFECYCLE.TOUCHTYPE_ANALYTICS AS
     DROP TABLE IF EXISTS ACT_MRKT_LIFECYCLE.TOUCHTYPE_ANALYTICS CASCADE; 
   CREATE TABLE ACT_MRKT_LIFECYCLE.TOUCHTYPE_ANALYTICS AS

WITH touchtype_union AS (
    SELECT
        MARKETING_TOUCH_TYPE_DATA_SOURCE,
        CRM_ACCOUNT_ID,
        MARKETING_TOUCHPOINT_DATE,
        MARKETING_TOUCH_TYPE,
        MARKETING_TOUCH_TYPE_COUNT,
        --20250314
        SPEND,
        -- SIXSENSE PAID MEDIA IMPRESSIONS
        INTERACTIONTYPE_SIXSENSE_PAIDMEDIA_IMPRESSIONS_COUNT,
        INTERACTIONTYPE_SIXSENSE_PAIDMEDIA_CLICKS_COUNT,
        -- SIXSENSE WEB VISIT ACTIVITY
        NULL AS INTERACTIONTYPE_SIXSENSE_WEBVISIT_TOTAL_INTERACTIONS_COUNT,
        NULL AS INTERACTIONTYPE_SIXSENSE_WEBVISIT_PAGELOAD_COUNT,
        NULL AS INTERACTIONTYPE_SIXSENSE_WEBVISIT_PLAY_COUNT,
        NULL AS INTERACTIONTYPE_SIXSENSE_WEBVISIT_CLICK_COUNT,
        NULL AS INTERACTIONTYPE_SIXSENSE_WEBVISIT_SUBMIT_COUNT,
        NULL AS INTERACTIONTYPE_SIXSENSE_WEBVISIT_UNCLASSIFIED_COUNT,
        -- BIZIBLE TOUCHPOINT
        NULL AS INTERACTIONTYPE_BIZIBLE_TOUCHPOINT_WEBVISIT_COUNT,
        NULL AS INTERACTIONTYPE_BIZIBLE_TOUCHPOINT_WEBCHAT_COUNT,
        NULL AS INTERACTIONTYPE_BIZIBLE_TOUCHPOINT_WEBFORM_COUNT,
        NULL AS INTERACTIONTYPE_BIZIBLE_TOUCHPOINT_CRM_COUNT,
        NULL AS INTERACTIONTYPE_BIZIBLE_TOUCHPOINT_CONNECTWITHDM_COUNT,
        NULL AS INTERACTIONTYPE_BIZIBLE_TOUCHPOINT_CALLSPOKEWITH_COUNT,
        NULL AS INTERACTIONTYPE_BIZIBLE_TOUCHPOINT_CALLGATEKEEPER_COUNT,
        NULL AS INTERACTIONTYPE_BIZIBLE_TOUCHPOINT_NOLEADTOUCHPOINTS_COUNT,
        --20250302
        NULL AS INTERACTIONTYPE_BIZIBLE_TOUCHPOINT_MARKETO_COUNT,
        --20250314
        NULL AS INTERACTIONTYPE_BIZIBLE_TOUCHPOINT_SEISMICENGAGEMENT_COUNT,
        NULL AS INTERACTIONTYPE_BIZIBLE_TOUCHPOINT_CHANGESTATUS_COUNT,
        NULL AS INTERACTIONTYPE_BIZIBLE_TOUCHPOINT_UNCLASSIFIED_COUNT,
        INFLUENCE_CHANNEL,
        INFLUENCE_WEB_SOURCE,
        INFLUENCE_WEB_MEDIUM,
        INFLUENCE_CAMPAIGN_NAME,
        INFLUENCE_CAMPAIGN_MARKET_SEGMENT,
        INFLUENCE_CAMPAIGN_TYPE,
        INFLUENCE_UTM_CAMPAIGN,
        INFLUENCE_UTM_CONTENT,
        INFLUENCE_UTM_TERM,
        INFLUENCE_AD_NAME,
        INFLUENCE_CREATIVE_NAME,
        INFLUENCE_LANDING_PAGE,
        INFLUENCE_REFERRER,
        WEBVISIT_PAGE,
        WEBVISIT_REFERRER
    FROM ACT_MRKT_LIFECYCLE.TOUCHTYPE_6SENSE_PAIDMEDIA

    UNION
    SELECT
        MARKETING_TOUCH_TYPE_DATA_SOURCE,
        CRM_ACCOUNT_ID,
        MARKETING_TOUCHPOINT_DATE,
        MARKETING_TOUCH_TYPE,
        MARKETING_TOUCH_TYPE_COUNT,
        --20250314
        NULL AS SPEND,
        -- SIXSENSE PAID MEDIA IMPRESSIONS
        NULL AS INTERACTIONTYPE_SIXSENSE_PAIDMEDIA_IMPRESSIONS_COUNT,
        NULL AS INTERACTIONTYPE_SIXSENSE_PAIDMEDIA_CLICKS_COUNT,
        -- SIXSENSE WEB VISIT ACTIVITY
        INTERACTIONTYPE_SIXSENSE_WEBVISIT_TOTAL_INTERACTIONS_COUNT,
        INTERACTIONTYPE_SIXSENSE_WEBVISIT_PAGELOAD_COUNT,
        INTERACTIONTYPE_SIXSENSE_WEBVISIT_PLAY_COUNT,
        INTERACTIONTYPE_SIXSENSE_WEBVISIT_CLICK_COUNT,
        INTERACTIONTYPE_SIXSENSE_WEBVISIT_SUBMIT_COUNT,
        INTERACTIONTYPE_SIXSENSE_WEBVISIT_UNCLASSIFIED_COUNT,
        -- BIZIBLE TOUCHPOINT
        NULL AS INTERACTIONTYPE_BIZIBLE_TOUCHPOINT_WEBVISIT_COUNT,
        NULL AS INTERACTIONTYPE_BIZIBLE_TOUCHPOINT_WEBCHAT_COUNT,
        NULL AS INTERACTIONTYPE_BIZIBLE_TOUCHPOINT_WEBFORM_COUNT,
        NULL AS INTERACTIONTYPE_BIZIBLE_TOUCHPOINT_CRM_COUNT,
        NULL AS INTERACTIONTYPE_BIZIBLE_TOUCHPOINT_CONNECTWITHDM_COUNT,
        NULL AS INTERACTIONTYPE_BIZIBLE_TOUCHPOINT_CALLSPOKEWITH_COUNT,
        NULL AS INTERACTIONTYPE_BIZIBLE_TOUCHPOINT_CALLGATEKEEPER_COUNT,
        NULL AS INTERACTIONTYPE_BIZIBLE_TOUCHPOINT_NOLEADTOUCHPOINTS_COUNT,
        --20250302
        NULL AS INTERACTIONTYPE_BIZIBLE_TOUCHPOINT_MARKETO_COUNT,
        --20250314
        NULL AS INTERACTIONTYPE_BIZIBLE_TOUCHPOINT_SEISMICENGAGEMENT_COUNT,
        NULL AS INTERACTIONTYPE_BIZIBLE_TOUCHPOINT_CHANGESTATUS_COUNT,
        NULL AS INTERACTIONTYPE_BIZIBLE_TOUCHPOINT_UNCLASSIFIED_COUNT,
        INFLUENCE_CHANNEL,
        INFLUENCE_WEB_SOURCE,
        INFLUENCE_WEB_MEDIUM,
        INFLUENCE_CAMPAIGN_NAME,
        INFLUENCE_CAMPAIGN_MARKET_SEGMENT,
        INFLUENCE_CAMPAIGN_TYPE,
        INFLUENCE_UTM_CAMPAIGN,
        INFLUENCE_UTM_CONTENT,
        INFLUENCE_UTM_TERM,
        INFLUENCE_AD_NAME,
        INFLUENCE_CREATIVE_NAME,
        INFLUENCE_LANDING_PAGE,
        INFLUENCE_REFERRER,
        WEBVISIT_PAGE,
        WEBVISIT_REFERRER
    FROM ACT_MRKT_LIFECYCLE.TOUCHTYPE_6SENSE_WEBVISIT

    UNION
    SELECT
        MARKETING_TOUCH_TYPE_DATA_SOURCE,
        CRM_ACCOUNT_ID,
        MARKETING_TOUCHPOINT_DATE,
        MARKETING_TOUCH_TYPE,
        MARKETING_TOUCH_TYPE_COUNT,
        --20250314
        NULL AS SPEND,
        -- SIXSENSE PAID MEDIA IMPRESSIONS
        NULL AS INTERACTIONTYPE_SIXSENSE_PAIDMEDIA_IMPRESSIONS_COUNT,
        NULL AS INTERACTIONTYPE_SIXSENSE_PAIDMEDIA_CLICKS_COUNT,
        -- SIXSENSE WEB VISIT ACTIVITY
        NULL AS INTERACTIONTYPE_SIXSENSE_WEBVISIT_TOTAL_INTERACTIONS_COUNT,
        NULL AS INTERACTIONTYPE_SIXSENSE_WEBVISIT_PAGELOAD_COUNT,
        NULL AS INTERACTIONTYPE_SIXSENSE_WEBVISIT_PLAY_COUNT,
        NULL AS INTERACTIONTYPE_SIXSENSE_WEBVISIT_CLICK_COUNT,
        NULL AS INTERACTIONTYPE_SIXSENSE_WEBVISIT_SUBMIT_COUNT,
        NULL AS INTERACTIONTYPE_SIXSENSE_WEBVISIT_UNCLASSIFIED_COUNT,
        -- BIZIBLE TOUCHPOINT
        INTERACTIONTYPE_BIZIBLE_TOUCHPOINT_WEBVISIT_COUNT,
        INTERACTIONTYPE_BIZIBLE_TOUCHPOINT_WEBCHAT_COUNT,
        INTERACTIONTYPE_BIZIBLE_TOUCHPOINT_WEBFORM_COUNT,
        INTERACTIONTYPE_BIZIBLE_TOUCHPOINT_CRM_COUNT,
        INTERACTIONTYPE_BIZIBLE_TOUCHPOINT_CONNECTWITHDM_COUNT,
        INTERACTIONTYPE_BIZIBLE_TOUCHPOINT_CALLSPOKEWITH_COUNT,
        INTERACTIONTYPE_BIZIBLE_TOUCHPOINT_CALLGATEKEEPER_COUNT,
        INTERACTIONTYPE_BIZIBLE_TOUCHPOINT_NOLEADTOUCHPOINTS_COUNT,
        --20250302
        INTERACTIONTYPE_BIZIBLE_TOUCHPOINT_MARKETO_COUNT,
        --20250314
        INTERACTIONTYPE_BIZIBLE_TOUCHPOINT_SEISMICENGAGEMENT_COUNT,
        INTERACTIONTYPE_BIZIBLE_TOUCHPOINT_CHANGESTATUS_COUNT,
        INTERACTIONTYPE_BIZIBLE_TOUCHPOINT_UNCLASSIFIED_COUNT,
        INFLUENCE_CHANNEL,
        INFLUENCE_WEB_SOURCE,
        INFLUENCE_WEB_MEDIUM,
        INFLUENCE_CAMPAIGN_NAME,
        INFLUENCE_CAMPAIGN_MARKET_SEGMENT,
        INFLUENCE_CAMPAIGN_TYPE,
        INFLUENCE_UTM_CAMPAIGN,
        INFLUENCE_UTM_CONTENT,
        INFLUENCE_UTM_TERM,
        INFLUENCE_AD_NAME,
        INFLUENCE_CREATIVE_NAME,
        INFLUENCE_LANDING_PAGE,
        INFLUENCE_REFERRER,
        WEBVISIT_PAGE,
        WEBVISIT_REFERRER
    FROM ACT_MRKT_LIFECYCLE.TOUCHTYPE_BIZIBLE_TOUCHPOINTS
)
SELECT
    		u.*,
            -- Account Info
            act.ID AS ACT_ID,
            -- Account Info
            act.ISDELETED AS ACT_IS_DELETED,
            act.NAME AS ACT_NAME,
            usr.NAME AS ACT_OWNER,
            usr_role.NAME AS ACT_OWNER_ROLE,
            usro.NAME AS ACT_OPENER,
            act.CREATEDDATE AS ACT_CREATED_DATE,
            act.RECORDTYPEID AS ACT_RECORD_TYPE_ID,
            rcd.NAME AS ACT_RECORD_TYPE_ID_NAME,
            act.MARKETING_LIFECYCLE_AT_SUSPECT__C AS ACT_MARKETING_LIFECYCLE_AT_SUSPECT__C,
            act.BUYING_STAGE_AT_SUSPECT__C AS ACT_BUYING_STAGE_AT_SUSPECT__C,
            act.MARKETING_LIFECYCLE__C AS ACT_MARKETING_LIFECYCLE__C,
            act.BUSINESS_UNIT_2020__C AS ACT_BUSINESS_UNIT_2020__C,
            act.BUSINESS_UNIT_DIVISION__C AS ACT_BUSINESS_UNIT_DIVISION__C,
           -- act.BILLING_MODEL__C as ACT_BILLING_MODEL__C,
            act.MARKET__C AS ACT_MARKET__C,
            act.FLEET_SIZE__C AS ACT_FLEET_SIZE__C,
            act.MARKET_SEGMENT__C AS ACT_MARKET_SEGMENT__C,
            CASE 
				WHEN act.MARKET_SEGMENT__C IN ('Trucking','Local') THEN 'Trucking and Local' 
				WHEN act.MARKET_SEGMENT__C IN ('NA') OR act.MARKET_SEGMENT__C IS NULL THEN 'Not Categorized' 
				ELSE act.MARKET_SEGMENT__C END AS ACT_MARKET_SEGMENT__C_GROUP,
            act.INDUSTRY AS ACT_INDUSTRY,
            act.INDUSTRY_DB__C AS ACT_INDUSTRY_DB__C,
            act.INDUSTRY_SECTOR__C AS ACT_INDUSTRY_SECTOR__C,
            act.TERRITORY__C AS ACT_TERRITORY__C,
            act.GEOGRAPHIC_REGION__C AS ACT_GEOGRAPHIC_REGION__C,
            act.STATE_DB__C AS ACT_STATE_DB__C,
            act.FIT_MODEL_TIER__C AS ACT_FIT_MODEL_TIER__C,
            act.ACCOUNTPROFILEFIT6SENSE__C AS ACT_ACCOUNT_PROFILE_FIT6SENSE__C,
            act.ACCOUNTPROFILESCORE6SENSE__C AS ACT_ACCOUNT_PROFILE_SCORE6SENSE__C,
            act.INTERNAL_TEST_ACCOUNT__C AS ACT_INTERNAL_TEST_ACCOUNT__C,
            act.ROUTING_REASON__C AS ACT_ROUTING_REASON__C,
            act.MIGRATION_RETURN_TO_MARKETING_REASON__C AS ACT_MIGRATION_RETURN_TO_MARKETING_REASON__C,
            act.STATUS__C AS ACT_STATUS__C,
            act.BUYER_TYPE__C as ACT_BUYER_TYPE__C,
			-- 20250302
			act.CAMPAIGN_TEXT__C AS ACT_CAMPAIGN_TEXT__C,
            act.BILLING_MODEL__C AS ACT_BILLING_MODEL__C,
            act.REGION__C AS ACT_REGION__C,
            act.BILLINGSTATE AS ACT_BILLING_STATE,
            CASE
                WHEN act.STATUS__C IN (
                    'Data Review',
                    'Initial Trial',
                    'Initial Trial Pending',
                    'Prospect',
                    'Suspect'
                ) THEN 'Active with Sales'
                WHEN act.STATUS__C IN (
                    'Client',
                    'Pending Client',
                    'Pending Client - Contract Signed'
                ) THEN 'Client'
                WHEN act.STATUS__C IN (
                    'Prospect Nuture',
                    'Recycle',
                    'Suspect Nurture',
                    'Suspect Nuture'
                ) THEN 'Marketing Engagement'
                WHEN act.STATUS__C IN (
                    'Active',
                    'Inactive',
                    'Industry Org',
                    'Non-Contractual',
                    'Other'
                ) THEN 'Other/NA'
                WHEN act.STATUS__C IN (
                    'Pending Forward Consent',
                    'Referred to Partner'
                ) THEN 'Referred to Partner'
                WHEN act.STATUS__C IN (
                    'SERVICE SUSPENDED',
                    'SERVICE TERMINATED',
                    'Terminated'
                ) THEN 'Service Terminated'
                WHEN act.STATUS__C IN (
                    'DOA',
                    'Duplicate',
                    'Duplicate - 6Sense',
                    'Out of Business',
                    'Unqualified'
                ) THEN 'Unqualified'
            END AS ACT_STATUS_GROUP,
            act.UNQUALIFIED_REASON__C AS ACT_UNQUALIFIED_REASON__C

FROM touchtype_union u
LEFT JOIN SALESFORCE_BT.ACCOUNT act
    ON act.ID = u.CRM_ACCOUNT_ID
	LEFT JOIN SALESFORCE_BT.USER usr 
		ON act.ownerid = usr.ID
        AND usr.NAME NOT IN ('Scott Rose', 'Rick Walters', 'Micah Rea', 'Compliance', 'ELD Compliance Manager')
        -- ACT OWNER USER ROLE
        LEFT JOIN SALESFORCE_BT.USERROLE usr_role 
        ON usr.USERROLEID = usr_role.ID
        LEFT JOIN SALESFORCE_BT.USER usro
        ON act.OPENER__C = usro.ID 
        AND usro.NAME NOT IN ('Scott Rose', 'Rick Walters', 'Micah Rea', 'Compliance', 'ELD Compliance Manager')              
        -- Record Type
        LEFT JOIN SALESFORCE_BT.RECORDTYPE as rcd ON act.RECORDTYPEID = rcd.ID
        AND (
        rcd.ID = '012300000005VEYAA2'
        OR rcd.ID = '0126R000001UknZQAS'
        );
RAISE INFO 'step 4 complete';
        
    -- Step 05a: Account Marketing Lifecycle History with Opp and Influence Data
--     DROP TABLE IF EXISTS ACT_MRKT_LIFECYCLE.AMLH_INFL_OPP;
--        CREATE TABLE ACT_MRKT_LIFECYCLE.AMLH_INFL_OPP AS


     DROP TABLE IF EXISTS ACT_MRKT_LIFECYCLE.AMLH_INFL_OPP CASCADE;    
     CREATE TABLE ACT_MRKT_LIFECYCLE.AMLH_INFL_OPP as

    SELECT
        *
    FROM
        (
            SELECT
                -- Account Marketing Lifecycle History with Opp Data
                amlh_opp.*,
                -- Influence Data
                infl_data.MARKETING_TOUCHPOINT_DATE,
                row_number() OVER (
                    PARTITION BY amlh_opp.OPP_ID,
                    amlh_opp.ACT_ID
                    ORDER BY
                        infl_data.MARKETING_TOUCHPOINT_DATE ASC
                ) AS MARKETING_TOUCHPOINT_ORDER,
                CASE
                    WHEN infl_data.CRM_ACCOUNT_ID IS NULL THEN 'Salesforce'
                    ELSE infl_data.MARKETING_TOUCH_TYPE_DATA_SOURCE
                END AS MARKETING_TOUCH_TYPE_DATA_SOURCE,
                CASE
                    WHEN infl_data.CRM_ACCOUNT_ID IS NULL THEN 0
                    ELSE 1
                END AS FLAG_MARKETING_TOUCH_TYPE_DATA_SOURCE,
                CASE
                    WHEN infl_data.CRM_ACCOUNT_ID IS NULL THEN 'Salesforce Opportunity'
                    ELSE infl_data.MARKETING_TOUCH_TYPE
                END AS MARKETING_TOUCH_TYPE,
                infl_data.MARKETING_TOUCH_TYPE_COUNT,
                CASE
                    WHEN infl_data.MARKETING_TOUCHPOINT_DATE <= amlh_opp.OPP_CREATED_DATE THEN 1
                    ELSE 0
                END AS MARKETING_TOUCHPOINT_BEFORE_OPP_CREATED,
				--20251002
                CASE
                    WHEN infl_data.MARKETING_TOUCHPOINT_DATE <= amlh_opp.OPP_STAGE_0_DATE THEN 1
                    ELSE 0
                END AS MARKETING_TOUCHPOINT_BEFORE_OPP_STAGE_0,
				--20250302
                CASE
                    WHEN infl_data.MARKETING_TOUCHPOINT_DATE <= amlh_opp.OPP_STAGE_1_DATE THEN 1
                    ELSE 0
                END AS MARKETING_TOUCHPOINT_BEFORE_OPP_STAGE_1,
                CASE
                    WHEN infl_data.MARKETING_TOUCHPOINT_DATE <= amlh_opp.OPP_CLOSE_DATE THEN 1
                    ELSE 0
                END AS MARKETING_TOUCHPOINT_BEFORE_OPP_CLOSE,
                CASE
                    WHEN infl_data.MARKETING_TOUCHPOINT_DATE <= amlh_opp.AMLH_COLD_ACCOUNT_DATE_STAMP__C THEN 1
                    ELSE 0
                END AS MARKETING_TOUCHPOINT_BEFORE_ACT_COLD,
                CASE
                    WHEN infl_data.MARKETING_TOUCHPOINT_DATE <= amlh_opp.AMLH_MEA_DATE_STAMP__C THEN 1
                    ELSE 0
                END AS MARKETING_TOUCHPOINT_BEFORE_ACT_MEA,
                CASE
                    WHEN infl_data.MARKETING_TOUCHPOINT_DATE <= amlh_opp.AMLH_MQA_DATE_STAMP__C THEN 1
                    ELSE 0
                END AS MARKETING_TOUCHPOINT_BEFORE_ACT_MQA,
                CASE
                    WHEN infl_data.MARKETING_TOUCHPOINT_DATE <= amlh_opp.AMLH_SUSPECT_DATE_STAMP__C THEN 1
                    ELSE 0
                END AS MARKETING_TOUCHPOINT_BEFORE_ACT_SUSPECT,
                CASE
                    WHEN infl_data.MARKETING_TOUCHPOINT_DATE <= amlh_opp.AMLH_SUSPECT_WORKING_DATE_STAMP__C THEN 1
                    ELSE 0
                END AS MARKETING_TOUCHPOINT_BEFORE_ACT_SUSPECTWORKING,
                CASE
                    WHEN infl_data.MARKETING_TOUCHPOINT_DATE <= amlh_opp.AMLH_PROSPECT_DATE_STAMP__C THEN 1
                    ELSE 0
                END AS MARKETING_TOUCHPOINT_BEFORE_ACT_PROSPECT,
				--20250314
                CASE
                    WHEN infl_data.MARKETING_TOUCHPOINT_DATE <= amlh_opp.AMLH_CUSTOMER_DATE_STAMP__C THEN 1
                    ELSE 0
                END AS MARKETING_TOUCHPOINT_BEFORE_ACT_CUSTOMER,
                CASE
                    WHEN infl_data.MARKETING_TOUCHPOINT_DATE <= amlh_opp.AMLH_RECYCLED_DATE_STAMP__C THEN 1
                    ELSE 0
                END AS MARKETING_TOUCHPOINT_BEFORE_ACT_RECYCLED,
                CASE
                    WHEN infl_data.MARKETING_TOUCHPOINT_DATE <= amlh_opp.AMLH_UNQUALIFIED_DATE_STAMP__C THEN 1
                    ELSE 0
                END AS MARKETING_TOUCHPOINT_BEFORE_ACT_UNQUALIFIED,
				--20250314
                CASE
                    WHEN infl_data.MARKETING_TOUCHPOINT_DATE <= amlh_opp.AMLH_EFFECTIVE_DATE_STAMP__C THEN 1
                    ELSE 0
                END AS MARKETING_TOUCHPOINT_BEFORE_ACT_EFFECTIVE,
                CASE
                    WHEN infl_data.CRM_ACCOUNT_ID IS NULL THEN 'SALESFORCE_BT.Opportunity'
                    ELSE infl_data.INFLUENCE_CHANNEL
                END AS INFLUENCE_CHANNEL,
                CASE
                    WHEN infl_data.CRM_ACCOUNT_ID IS NULL THEN 'Salesforce'
                    ELSE SPLIT_PART(infl_data.INFLUENCE_CHANNEL, '.', 1)
                END AS INFLUENCE_CHANNEL_TOPLEVEL,
                CASE
                    WHEN infl_data.CRM_ACCOUNT_ID IS NULL THEN 'salesforce'
                    ELSE infl_data.INFLUENCE_WEB_SOURCE
                END AS INFLUENCE_WEB_SOURCE,
                CASE
                    WHEN infl_data.CRM_ACCOUNT_ID IS NULL THEN 'opportunity'
                    ELSE infl_data.INFLUENCE_WEB_MEDIUM
                END AS INFLUENCE_WEB_MEDIUM,
                infl_data.INFLUENCE_CAMPAIGN_NAME,
				infl_data.INFLUENCE_CAMPAIGN_MARKET_SEGMENT,
				infl_data.INFLUENCE_CAMPAIGN_TYPE,
                infl_data.INFLUENCE_UTM_CAMPAIGN,
                infl_data.INFLUENCE_UTM_CONTENT,
                infl_data.INFLUENCE_UTM_TERM,
                infl_data.INFLUENCE_AD_NAME,    
                infl_data.INFLUENCE_CREATIVE_NAME,
                infl_data.INFLUENCE_LANDING_PAGE,
                infl_data.INFLUENCE_REFERRER,
                infl_data.WEBVISIT_PAGE,
                infl_data.WEBVISIT_REFERRER,
				--20250314
				infl_data.SPEND,
                infl_data.INTERACTIONTYPE_SIXSENSE_PAIDMEDIA_IMPRESSIONS_COUNT,
                infl_data.INTERACTIONTYPE_SIXSENSE_PAIDMEDIA_CLICKS_COUNT,
                infl_data.INTERACTIONTYPE_SIXSENSE_WEBVISIT_TOTAL_INTERACTIONS_COUNT,
                infl_data.INTERACTIONTYPE_SIXSENSE_WEBVISIT_PAGELOAD_COUNT,
                infl_data.INTERACTIONTYPE_SIXSENSE_WEBVISIT_PLAY_COUNT,
                infl_data.INTERACTIONTYPE_SIXSENSE_WEBVISIT_CLICK_COUNT,
                infl_data.INTERACTIONTYPE_SIXSENSE_WEBVISIT_SUBMIT_COUNT,
                infl_data.INTERACTIONTYPE_SIXSENSE_WEBVISIT_UNCLASSIFIED_COUNT,
                infl_data.INTERACTIONTYPE_BIZIBLE_TOUCHPOINT_WEBVISIT_COUNT,
                infl_data.INTERACTIONTYPE_BIZIBLE_TOUCHPOINT_WEBCHAT_COUNT,
                infl_data.INTERACTIONTYPE_BIZIBLE_TOUCHPOINT_WEBFORM_COUNT,
                infl_data.INTERACTIONTYPE_BIZIBLE_TOUCHPOINT_CRM_COUNT,
                infl_data.INTERACTIONTYPE_BIZIBLE_TOUCHPOINT_CONNECTWITHDM_COUNT,
                infl_data.INTERACTIONTYPE_BIZIBLE_TOUCHPOINT_CALLSPOKEWITH_COUNT,
                infl_data.INTERACTIONTYPE_BIZIBLE_TOUCHPOINT_CALLGATEKEEPER_COUNT,
                infl_data.INTERACTIONTYPE_BIZIBLE_TOUCHPOINT_NOLEADTOUCHPOINTS_COUNT,
				--20250302
                infl_data.INTERACTIONTYPE_BIZIBLE_TOUCHPOINT_MARKETO_COUNT,
				--20250314
				infl_data.INTERACTIONTYPE_BIZIBLE_TOUCHPOINT_SEISMICENGAGEMENT_COUNT,
				infl_data.INTERACTIONTYPE_BIZIBLE_TOUCHPOINT_CHANGESTATUS_COUNT,
                infl_data.INTERACTIONTYPE_BIZIBLE_TOUCHPOINT_UNCLASSIFIED_COUNT,
                -- Influence based on Bizible or 6Sense or Salesforce
                CASE
                    WHEN (
                        (
                            CASE
                                WHEN infl_data.MARKETING_TOUCHPOINT_DATE <= amlh_opp.OPP_CREATED_DATE THEN 1
                                ELSE 0
                            END
                        ) = 1
                        AND infl_data.MARKETING_TOUCH_TYPE_DATA_SOURCE IN (
                            '6Sense - Paid Media',
                            '6Sense - Web Visit',
                            'Bizible'
                        )
                    ) THEN 1
                    WHEN (
                        (
                            CASE
                                WHEN infl_data.MARKETING_TOUCHPOINT_DATE <= amlh_opp.OPP_CREATED_DATE THEN 1
                                ELSE 0
                            END
                        ) = 0
                        AND infl_data.MARKETING_TOUCH_TYPE_DATA_SOURCE IN (
                            '6Sense - Paid Media',
                            '6Sense - Web Visit',
                            'Bizible'
                        )
                    ) THEN 2
                    ELSE 0
                END AS FLAG_OPPCRT_INFL_TOUCHPOINT_BY_DATASOURCE_BIZIBLEORSIXSENSEORSALESFORCE,
			--20251002
                CASE
                    WHEN (
                        (
                            CASE
                                WHEN infl_data.MARKETING_TOUCHPOINT_DATE <= amlh_opp.OPP_STAGE_0_DATE THEN 1
                                ELSE 0
                            END
                        ) = 1
                        AND infl_data.MARKETING_TOUCH_TYPE_DATA_SOURCE IN (
                            '6Sense - Paid Media',
                            '6Sense - Web Visit',
                            'Bizible'
                        )
                    ) THEN 1
                    WHEN (
                        (
                            CASE
                                WHEN infl_data.MARKETING_TOUCHPOINT_DATE <= amlh_opp.OPP_STAGE_0_DATE THEN 1
                                ELSE 0
                            END
                        ) = 0
                        AND infl_data.MARKETING_TOUCH_TYPE_DATA_SOURCE IN (
                            '6Sense - Paid Media',
                            '6Sense - Web Visit',
                            'Bizible'
                        )
                    ) THEN 2
                    ELSE 0
                END AS FLAG_OPPSTG0_INFL_TOUCHPOINT_BY_DATASOURCE_BIZIBLEORSIXSENSEORSALESFORCE,
				--20250302
                CASE
                    WHEN (
                        (
                            CASE
                                WHEN infl_data.MARKETING_TOUCHPOINT_DATE <= amlh_opp.OPP_STAGE_1_DATE THEN 1
                                ELSE 0
                            END
                        ) = 1
                        AND infl_data.MARKETING_TOUCH_TYPE_DATA_SOURCE IN (
                            '6Sense - Paid Media',
                            '6Sense - Web Visit',
                            'Bizible'
                        )
                    ) THEN 1
                    WHEN (
                        (
                            CASE
                                WHEN infl_data.MARKETING_TOUCHPOINT_DATE <= amlh_opp.OPP_STAGE_1_DATE THEN 1
                                ELSE 0
                            END
                        ) = 0
                        AND infl_data.MARKETING_TOUCH_TYPE_DATA_SOURCE IN (
                            '6Sense - Paid Media',
                            '6Sense - Web Visit',
                            'Bizible'
                        )
                    ) THEN 2
                    ELSE 0
                END AS FLAG_OPPSTG1_INFL_TOUCHPOINT_BY_DATASOURCE_BIZIBLEORSIXSENSEORSALESFORCE,
                CASE
                    WHEN (
                        (
                            CASE
                                WHEN infl_data.MARKETING_TOUCHPOINT_DATE <= amlh_opp.OPP_CLOSE_DATE THEN 1
                                ELSE 0
                            END
                        ) = 1
                        AND infl_data.MARKETING_TOUCH_TYPE_DATA_SOURCE IN (
                            '6Sense - Paid Media',
                            '6Sense - Web Visit',
                            'Bizible'
                        )
                    ) THEN 1
                    WHEN (
                        (
                            CASE
                                WHEN infl_data.MARKETING_TOUCHPOINT_DATE <= amlh_opp.OPP_CLOSE_DATE THEN 1
                                ELSE 0
                            END
                        ) = 0
                        AND infl_data.MARKETING_TOUCH_TYPE_DATA_SOURCE IN (
                            '6Sense - Paid Media',
                            '6Sense - Web Visit',
                            'Bizible'
                        )
                    ) THEN 2
                    ELSE 0
                END AS FLAG_OPPCLS_INFL_TOUCHPOINT_BY_DATASOURCE_BIZIBLEORSIXSENSEORSALESFORCE,
                CASE
                    WHEN (
                        (
                            CASE
                                WHEN infl_data.MARKETING_TOUCHPOINT_DATE <= amlh_opp.AMLH_COLD_ACCOUNT_DATE_STAMP__C THEN 1
                                ELSE 0
                            END
                        ) = 1
                        AND infl_data.MARKETING_TOUCH_TYPE_DATA_SOURCE IN (
                            '6Sense - Paid Media',
                            '6Sense - Web Visit',
                            'Bizible'
                        )
                    ) THEN 1
                    WHEN (
                        (
                            CASE
                                WHEN infl_data.MARKETING_TOUCHPOINT_DATE <= amlh_opp.AMLH_COLD_ACCOUNT_DATE_STAMP__C THEN 1
                                ELSE 0
                            END
                        ) = 0
                        AND infl_data.MARKETING_TOUCH_TYPE_DATA_SOURCE IN (
                            '6Sense - Paid Media',
                            '6Sense - Web Visit',
                            'Bizible'
                        )
                    ) THEN 2
                    ELSE 0
                END AS FLAG_ACTCOLD_INFL_TOUCHPOINT_BY_DATASOURCE_BIZIBLEORSIXSENSEORSALESFORCE,
                CASE
                    WHEN (
                        (
                            CASE
                                WHEN infl_data.MARKETING_TOUCHPOINT_DATE <= amlh_opp.AMLH_MEA_DATE_STAMP__C THEN 1
                                ELSE 0
                            END
                        ) = 1
                        AND infl_data.MARKETING_TOUCH_TYPE_DATA_SOURCE IN (
                            '6Sense - Paid Media',
                            '6Sense - Web Visit',
                            'Bizible'
                        )
                    ) THEN 1
                    WHEN (
                        (
                            CASE
                                WHEN infl_data.MARKETING_TOUCHPOINT_DATE <= amlh_opp.AMLH_MEA_DATE_STAMP__C THEN 1
                                ELSE 0
                            END
                        ) = 0
                        AND infl_data.MARKETING_TOUCH_TYPE_DATA_SOURCE IN (
                            '6Sense - Paid Media',
                            '6Sense - Web Visit',
                            'Bizible'
                        )
                    ) THEN 2
                    ELSE 0
                END AS ACTMEA_INFL_TOUCHPOINT_BY_DATASOURCE_BIZIBLEORSIXSENSEORSALESFORCE,
                CASE
                    WHEN (
                        (
                            CASE
                                WHEN infl_data.MARKETING_TOUCHPOINT_DATE <= amlh_opp.AMLH_MQA_DATE_STAMP__C THEN 1
                                ELSE 0
                            END
                        ) = 1
                        AND infl_data.MARKETING_TOUCH_TYPE_DATA_SOURCE IN (
                            '6Sense - Paid Media',
                            '6Sense - Web Visit',
                            'Bizible'
                        )
                    ) THEN 1
                    WHEN (
                        (
                            CASE
                                WHEN infl_data.MARKETING_TOUCHPOINT_DATE <= amlh_opp.AMLH_MQA_DATE_STAMP__C THEN 1
                                ELSE 0
                            END
                        ) = 0
                        AND infl_data.MARKETING_TOUCH_TYPE_DATA_SOURCE IN (
                            '6Sense - Paid Media',
                            '6Sense - Web Visit',
                            'Bizible'
                        )
                    ) THEN 2
                    ELSE 0
                END AS ACTMQA_INFL_TOUCHPOINT_BY_DATASOURCE_BIZIBLEORSIXSENSEORSALESFORCE,
                CASE
                    WHEN (
                        (
                            CASE
                                WHEN infl_data.MARKETING_TOUCHPOINT_DATE <= amlh_opp.AMLH_SUSPECT_DATE_STAMP__C THEN 1
                                ELSE 0
                            END
                        ) = 1
                        AND infl_data.MARKETING_TOUCH_TYPE_DATA_SOURCE IN (
                            '6Sense - Paid Media',
                            '6Sense - Web Visit',
                            'Bizible'
                        )
                    ) THEN 1
                    WHEN (
                        (
                            CASE
                                WHEN infl_data.MARKETING_TOUCHPOINT_DATE <= amlh_opp.AMLH_SUSPECT_DATE_STAMP__C THEN 1
                                ELSE 0
                            END
                        ) = 0
                        AND infl_data.MARKETING_TOUCH_TYPE_DATA_SOURCE IN (
                            '6Sense - Paid Media',
                            '6Sense - Web Visit',
                            'Bizible'
                        )
                    ) THEN 2
                    ELSE 0
                END AS ACTSUSPECT_INFL_TOUCHPOINT_BY_DATASOURCE_BIZIBLEORSIXSENSEORSALESFORCE,
                CASE
                    WHEN (
                        (
                            CASE
                                WHEN infl_data.MARKETING_TOUCHPOINT_DATE <= amlh_opp.AMLH_PROSPECT_DATE_STAMP__C THEN 1
                                ELSE 0
                            END
                        ) = 1
                        AND infl_data.MARKETING_TOUCH_TYPE_DATA_SOURCE IN (
                            '6Sense - Paid Media',
                            '6Sense - Web Visit',
                            'Bizible'
                        )
                    ) THEN 1
                    WHEN (
                        (
                            CASE
                                WHEN infl_data.MARKETING_TOUCHPOINT_DATE <= amlh_opp.AMLH_PROSPECT_DATE_STAMP__C THEN 1
                                ELSE 0
                            END
                        ) = 0
                        AND infl_data.MARKETING_TOUCH_TYPE_DATA_SOURCE IN (
                            '6Sense - Paid Media',
                            '6Sense - Web Visit',
                            'Bizible'
                        )
                    ) THEN 2
                    ELSE 0
                END AS ACTPROSPECT_INFL_TOUCHPOINT_BY_DATASOURCE_BIZIBLEORSIXSENSEORSALESFORCE,
				--20250314
                CASE
                    WHEN (
                        (
                            CASE
                                WHEN infl_data.MARKETING_TOUCHPOINT_DATE <= amlh_opp.AMLH_CUSTOMER_DATE_STAMP__C THEN 1
                                ELSE 0
                            END
                        ) = 1
                        AND infl_data.MARKETING_TOUCH_TYPE_DATA_SOURCE IN (
                            '6Sense - Paid Media',
                            '6Sense - Web Visit',
                            'Bizible'
                        )
                    ) THEN 1
                    WHEN (
                        (
                            CASE
                                WHEN infl_data.MARKETING_TOUCHPOINT_DATE <= amlh_opp.AMLH_CUSTOMER_DATE_STAMP__C THEN 1
                                ELSE 0
                            END
                        ) = 0
                        AND infl_data.MARKETING_TOUCH_TYPE_DATA_SOURCE IN (
                            '6Sense - Paid Media',
                            '6Sense - Web Visit',
                            'Bizible'
                        )
                    ) THEN 2
                    ELSE 0
                END AS ACTCUSTOMER_INFL_TOUCHPOINT_BY_DATASOURCE_BIZIBLEORSIXSENSEORSALESFORCE,
                CASE
                    WHEN (
                        (
                            CASE
                                WHEN infl_data.MARKETING_TOUCHPOINT_DATE <= amlh_opp.AMLH_EFFECTIVE_DATE_STAMP__C THEN 1
                                ELSE 0
                            END
                        ) = 1
                        AND infl_data.MARKETING_TOUCH_TYPE_DATA_SOURCE IN (
                            '6Sense - Paid Media',
                            '6Sense - Web Visit',
                            'Bizible'
                        )
                    ) THEN 1
                    WHEN (
                        (
                            CASE
                                WHEN infl_data.MARKETING_TOUCHPOINT_DATE <= amlh_opp.AMLH_EFFECTIVE_DATE_STAMP__C THEN 1
                                ELSE 0
                            END
                        ) = 0
                        AND infl_data.MARKETING_TOUCH_TYPE_DATA_SOURCE IN (
                            '6Sense - Paid Media',
                            '6Sense - Web Visit',
                            'Bizible'
                        )
                    ) THEN 2
                    ELSE 0
                END AS ACTEFFECTIVE_INFL_TOUCHPOINT_BY_DATASOURCE_BIZIBLEORSIXSENSEORSALESFORCE,
				
                -- Influence based on Bizible or 6Sense
                CASE
                    WHEN infl_data.MARKETING_TOUCHPOINT_DATE <= amlh_opp.OPP_CREATED_DATE
                    AND infl_data.MARKETING_TOUCH_TYPE_DATA_SOURCE IN (
                        '6Sense - Paid Media',
                        '6Sense - Web Visit',
                        'Bizible'
                    ) THEN 1
                    ELSE 0
                END AS FLAG_OPPCRT_INFL_TOUCHPOINT_BY_DATASOURCE_BIZIBLEORSIXSENSE,
				--20251002
                CASE
                    WHEN infl_data.MARKETING_TOUCHPOINT_DATE <= amlh_opp.OPP_STAGE_0_DATE
                    AND infl_data.MARKETING_TOUCH_TYPE_DATA_SOURCE IN (
                        '6Sense - Paid Media',
                        '6Sense - Web Visit',
                        'Bizible'
                    ) THEN 1
                    ELSE 0
                END AS FLAG_OPPSTG0_INFL_TOUCHPOINT_BY_DATASOURCE_BIZIBLEORSIXSENSE,
				--20250302
                CASE
                    WHEN infl_data.MARKETING_TOUCHPOINT_DATE <= amlh_opp.OPP_STAGE_1_DATE
                    AND infl_data.MARKETING_TOUCH_TYPE_DATA_SOURCE IN (
                        '6Sense - Paid Media',
                        '6Sense - Web Visit',
                        'Bizible'
                    ) THEN 1
                    ELSE 0
                END AS FLAG_OPPSTG1_INFL_TOUCHPOINT_BY_DATASOURCE_BIZIBLEORSIXSENSE,
                CASE
                    WHEN infl_data.MARKETING_TOUCHPOINT_DATE <= amlh_opp.OPP_CLOSE_DATE
                    AND infl_data.MARKETING_TOUCH_TYPE_DATA_SOURCE IN (
                        '6Sense - Paid Media',
                        '6Sense - Web Visit',
                        'Bizible'
                    ) THEN 1
                    else 0
                END AS FLAG_OPPCLS_INFL_TOUCHPOINT_BY_DATASOURCE_BIZIBLEORSIXSENSE,
                CASE
                    WHEN infl_data.MARKETING_TOUCHPOINT_DATE <= amlh_opp.AMLH_COLD_ACCOUNT_DATE_STAMP__C
                    AND infl_data.MARKETING_TOUCH_TYPE_DATA_SOURCE IN (
                        '6Sense - Paid Media',
                        '6Sense - Web Visit',
                        'Bizible'
                    ) THEN 1
                    else 0
                END AS FLAG_ACTCOLD_INFL_TOUCHPOINT_BY_DATASOURCE_BIZIBLEORSIXSENSE,
                CASE
                    WHEN infl_data.MARKETING_TOUCHPOINT_DATE <= amlh_opp.AMLH_MEA_DATE_STAMP__C
                    AND infl_data.MARKETING_TOUCH_TYPE_DATA_SOURCE IN (
                        '6Sense - Paid Media',
                        '6Sense - Web Visit',
                        'Bizible'
                    ) THEN 1
                    else 0
                END AS FLAG_ACTMEA_INFL_TOUCHPOINT_BY_DATASOURCE_BIZIBLEORSIXSENSE,
                CASE
                    WHEN infl_data.MARKETING_TOUCHPOINT_DATE <= amlh_opp.AMLH_MQA_DATE_STAMP__C
                    AND infl_data.MARKETING_TOUCH_TYPE_DATA_SOURCE IN (
                        '6Sense - Paid Media',
                        '6Sense - Web Visit',
                        'Bizible'
                    ) THEN 1
                    else 0
                END AS FLAG_ACTMQA_INFL_TOUCHPOINT_BY_DATASOURCE_BIZIBLEORSIXSENSE,
                CASE
                    WHEN infl_data.MARKETING_TOUCHPOINT_DATE <= amlh_opp.AMLH_SUSPECT_DATE_STAMP__C
                    AND infl_data.MARKETING_TOUCH_TYPE_DATA_SOURCE IN (
                        '6Sense - Paid Media',
                        '6Sense - Web Visit',
                        'Bizible'
                    ) THEN 1
                    else 0
                END AS FLAG_ACTSUSPECT_INFL_TOUCHPOINT_BY_DATASOURCE_BIZIBLEORSIXSENSE,
                CASE
                    WHEN infl_data.MARKETING_TOUCHPOINT_DATE <= amlh_opp.AMLH_PROSPECT_DATE_STAMP__C
                    AND infl_data.MARKETING_TOUCH_TYPE_DATA_SOURCE IN (
                        '6Sense - Paid Media',
                        '6Sense - Web Visit',
                        'Bizible'
                    ) THEN 1
                    else 0
                END AS FLAG_ACTPROSPECT_INFL_TOUCHPOINT_BY_DATASOURCE_BIZIBLEORSIXSENSE,
				--20250314
                CASE
                    WHEN infl_data.MARKETING_TOUCHPOINT_DATE <= amlh_opp.AMLH_CUSTOMER_DATE_STAMP__C
                    AND infl_data.MARKETING_TOUCH_TYPE_DATA_SOURCE IN (
                        '6Sense - Paid Media',
                        '6Sense - Web Visit',
                        'Bizible'
                    ) THEN 1
                    else 0
                END AS FLAG_ACTCUSTOMER_INFL_TOUCHPOINT_BY_DATASOURCE_BIZIBLEORSIXSENSE,
                CASE
                    WHEN infl_data.MARKETING_TOUCHPOINT_DATE <= amlh_opp.AMLH_EFFECTIVE_DATE_STAMP__C
                    AND infl_data.MARKETING_TOUCH_TYPE_DATA_SOURCE IN (
                        '6Sense - Paid Media',
                        '6Sense - Web Visit',
                        'Bizible'
                    ) THEN 1
                    else 0
                END AS FLAG_ACTEFFECTIVE_INFL_TOUCHPOINT_BY_DATASOURCE_BIZIBLEORSIXSENSE,

                -- Influence based on 6Sense Paid Media
                CASE
                    WHEN infl_data.MARKETING_TOUCHPOINT_DATE <= amlh_opp.OPP_CREATED_DATE
                    AND infl_data.MARKETING_TOUCH_TYPE_DATA_SOURCE = '6Sense - Paid Media' THEN 1
                    else 0
                END AS FLAG_OPPCRT_INFL_TOUCHPOINT_BY_DATASOURCE_SIXSENSE_PAIDMEDIA,
				--20251002
                CASE
                    WHEN infl_data.MARKETING_TOUCHPOINT_DATE <= amlh_opp.OPP_STAGE_0_DATE
                    AND infl_data.MARKETING_TOUCH_TYPE_DATA_SOURCE = '6Sense - Paid Media' THEN 1
                    else 0
                END AS FLAG_OPPSTG0_INFL_TOUCHPOINT_BY_DATASOURCE_SIXSENSE_PAIDMEDIA,
				--20250302
                CASE
                    WHEN infl_data.MARKETING_TOUCHPOINT_DATE <= amlh_opp.OPP_STAGE_1_DATE
                    AND infl_data.MARKETING_TOUCH_TYPE_DATA_SOURCE = '6Sense - Paid Media' THEN 1
                    else 0
                END AS FLAG_OPPSTG1_INFL_TOUCHPOINT_BY_DATASOURCE_SIXSENSE_PAIDMEDIA,
                CASE
                    WHEN infl_data.MARKETING_TOUCHPOINT_DATE <= amlh_opp.OPP_CLOSE_DATE
                    AND infl_data.MARKETING_TOUCH_TYPE_DATA_SOURCE = '6Sense - Paid Media' THEN 1
                    else 0
                END AS FLAG_OPPCLS_INFL_TOUCHPOINT_BY_DATASOURCE_SIXSENSE_PAIDMEDIA,
                CASE
                    WHEN infl_data.MARKETING_TOUCHPOINT_DATE <= amlh_opp.AMLH_COLD_ACCOUNT_DATE_STAMP__C
                    AND infl_data.MARKETING_TOUCH_TYPE_DATA_SOURCE = '6Sense - Paid Media' THEN 1
                    else 0
                END AS FLAG_ACTCOLD_INFL_TOUCHPOINT_BY_DATASOURCE_SIXSENSE_PAIDMEDIA,
                CASE
                    WHEN infl_data.MARKETING_TOUCHPOINT_DATE <= amlh_opp.AMLH_MEA_DATE_STAMP__C
                    AND infl_data.MARKETING_TOUCH_TYPE_DATA_SOURCE = '6Sense - Paid Media' THEN 1
                    else 0
                END AS FLAG_ACTMEA_INFL_TOUCHPOINT_BY_DATASOURCE_SIXSENSE_PAIDMEDIA,
                CASE
                    WHEN infl_data.MARKETING_TOUCHPOINT_DATE <= amlh_opp.AMLH_MQA_DATE_STAMP__C
                    AND infl_data.MARKETING_TOUCH_TYPE_DATA_SOURCE = '6Sense - Paid Media' THEN 1
                    else 0
                END AS FLAG_ACTMQA_INFL_TOUCHPOINT_BY_DATASOURCE_SIXSENSE_PAIDMEDIA,
                CASE
                    WHEN infl_data.MARKETING_TOUCHPOINT_DATE <= amlh_opp.AMLH_SUSPECT_DATE_STAMP__C
                    AND infl_data.MARKETING_TOUCH_TYPE_DATA_SOURCE = '6Sense - Paid Media' THEN 1
                    else 0
                END AS FLAG_ACTSUSPECT_INFL_TOUCHPOINT_BY_DATASOURCE_SIXSENSE_PAIDMEDIA,
                CASE
                    WHEN infl_data.MARKETING_TOUCHPOINT_DATE <= amlh_opp.AMLH_PROSPECT_DATE_STAMP__C
                    AND infl_data.MARKETING_TOUCH_TYPE_DATA_SOURCE = '6Sense - Paid Media' THEN 1
                    else 0
                END AS FLAG_ACTPROSPECT_INFL_TOUCHPOINT_BY_DATASOURCE_SIXSENSE_PAIDMEDIA,
				--20250314
              CASE
                    WHEN infl_data.MARKETING_TOUCHPOINT_DATE <= amlh_opp.AMLH_CUSTOMER_DATE_STAMP__C
                    AND infl_data.MARKETING_TOUCH_TYPE_DATA_SOURCE = '6Sense - Paid Media' THEN 1
                    else 0
                END AS FLAG_ACTCUSTOMER_INFL_TOUCHPOINT_BY_DATASOURCE_SIXSENSE_PAIDMEDIA,
              CASE
                    WHEN infl_data.MARKETING_TOUCHPOINT_DATE <= amlh_opp.AMLH_EFFECTIVE_DATE_STAMP__C
                    AND infl_data.MARKETING_TOUCH_TYPE_DATA_SOURCE = '6Sense - Paid Media' THEN 1
                    else 0
                END AS FLAG_ACTEFFECTIVE_INFL_TOUCHPOINT_BY_DATASOURCE_SIXSENSE_PAIDMEDIA,
				
                -- Influence based on 6Sense Web Visit
                CASE
                    WHEN infl_data.MARKETING_TOUCHPOINT_DATE <= amlh_opp.OPP_CREATED_DATE
                    AND infl_data.MARKETING_TOUCH_TYPE_DATA_SOURCE = '6Sense - Web Visit' THEN 1
                    else 0
                END AS FLAG_OPPCRT_INFL_TOUCHPOINT_BY_DATASOURCE_SIXSENSE_WEBVISIT,
				--20251002
                CASE
                    WHEN infl_data.MARKETING_TOUCHPOINT_DATE <= amlh_opp.OPP_STAGE_0_DATE
                    AND infl_data.MARKETING_TOUCH_TYPE_DATA_SOURCE = '6Sense - Web Visit' THEN 1
                    else 0
                END AS FLAG_OPPSTG0_INFL_TOUCHPOINT_BY_DATASOURCE_SIXSENSE_WEBVISIT,
				--20250302
                CASE
                    WHEN infl_data.MARKETING_TOUCHPOINT_DATE <= amlh_opp.OPP_STAGE_1_DATE
                    AND infl_data.MARKETING_TOUCH_TYPE_DATA_SOURCE = '6Sense - Web Visit' THEN 1
                    else 0
                END AS FLAG_OPPSTG1_INFL_TOUCHPOINT_BY_DATASOURCE_SIXSENSE_WEBVISIT,
                CASE
                    WHEN infl_data.MARKETING_TOUCHPOINT_DATE <= amlh_opp.OPP_CLOSE_DATE
                    AND infl_data.MARKETING_TOUCH_TYPE_DATA_SOURCE = '6Sense - Web Visit' THEN 1
                    else 0
                END AS FLAG_OPPCLS_INFL_TOUCHPOINT_BY_DATASOURCE_SIXSENSE_WEBVISIT,
                CASE
                    WHEN infl_data.MARKETING_TOUCHPOINT_DATE <= amlh_opp.AMLH_COLD_ACCOUNT_DATE_STAMP__C
                    AND infl_data.MARKETING_TOUCH_TYPE_DATA_SOURCE = '6Sense - Web Visit' THEN 1
                    else 0
                END AS FLAG_ACTCOLD_INFL_TOUCHPOINT_BY_DATASOURCE_SIXSENSE_WEBVISIT,
                CASE
                    WHEN infl_data.MARKETING_TOUCHPOINT_DATE <= amlh_opp.AMLH_MEA_DATE_STAMP__C
                    AND infl_data.MARKETING_TOUCH_TYPE_DATA_SOURCE = '6Sense - Web Visit' THEN 1
                    else 0
                END AS FLAG_ACTMEA_INFL_TOUCHPOINT_BY_DATASOURCE_SIXSENSE_WEBVISIT,
                CASE
                    WHEN infl_data.MARKETING_TOUCHPOINT_DATE <= amlh_opp.AMLH_MQA_DATE_STAMP__C
                    AND infl_data.MARKETING_TOUCH_TYPE_DATA_SOURCE = '6Sense - Web Visit' THEN 1
                    else 0
                END AS FLAG_ACTMQA_INFL_TOUCHPOINT_BY_DATASOURCE_SIXSENSE_WEBVISIT,
                CASE
                    WHEN infl_data.MARKETING_TOUCHPOINT_DATE <= amlh_opp.AMLH_SUSPECT_DATE_STAMP__C
                    AND infl_data.MARKETING_TOUCH_TYPE_DATA_SOURCE = '6Sense - Web Visit' THEN 1
                    else 0
                END AS FLAG_ACTSUSPECT_INFL_TOUCHPOINT_BY_DATASOURCE_SIXSENSE_WEBVISIT,
                CASE
                    WHEN infl_data.MARKETING_TOUCHPOINT_DATE <= amlh_opp.AMLH_PROSPECT_DATE_STAMP__C
                    AND infl_data.MARKETING_TOUCH_TYPE_DATA_SOURCE = '6Sense - Web Visit' THEN 1
                    else 0
                END AS FLAG_ACTPROSPECT_INFL_TOUCHPOINT_BY_DATASOURCE_SIXSENSE_WEBVISIT,
				--20250314
                CASE
                    WHEN infl_data.MARKETING_TOUCHPOINT_DATE <= amlh_opp.AMLH_CUSTOMER_DATE_STAMP__C
                    AND infl_data.MARKETING_TOUCH_TYPE_DATA_SOURCE = '6Sense - Web Visit' THEN 1
                    else 0
                END AS FLAG_ACTCUSTOMER_INFL_TOUCHPOINT_BY_DATASOURCE_SIXSENSE_WEBVISIT,
                CASE
                    WHEN infl_data.MARKETING_TOUCHPOINT_DATE <= amlh_opp.AMLH_EFFECTIVE_DATE_STAMP__C
                    AND infl_data.MARKETING_TOUCH_TYPE_DATA_SOURCE = '6Sense - Web Visit' THEN 1
                    else 0
                END AS FLAG_ACTEFFECTIVE_INFL_TOUCHPOINT_BY_DATASOURCE_SIXSENSE_WEBVISIT,
				
                -- Influence based on Bizible
                CASE
                    WHEN infl_data.MARKETING_TOUCHPOINT_DATE <= amlh_opp.OPP_CREATED_DATE
                    AND infl_data.MARKETING_TOUCH_TYPE_DATA_SOURCE = 'Bizible' THEN 1
                    else 0
                END AS FLAG_OPPCRT_INFL_TOUCHPOINT_BY_DATASOURCE_BIZIBLE,
				--20251002
                CASE
                    WHEN infl_data.MARKETING_TOUCHPOINT_DATE <= amlh_opp.OPP_STAGE_0_DATE
                    AND infl_data.MARKETING_TOUCH_TYPE_DATA_SOURCE = 'Bizible' THEN 1
                    else 0
                END AS FLAG_OPPSTG0_INFL_TOUCHPOINT_BY_DATASOURCE_BIZIBLE,
				--20250302
                CASE
                    WHEN infl_data.MARKETING_TOUCHPOINT_DATE <= amlh_opp.OPP_STAGE_1_DATE
                    AND infl_data.MARKETING_TOUCH_TYPE_DATA_SOURCE = 'Bizible' THEN 1
                    else 0
                END AS FLAG_OPPSTG1_INFL_TOUCHPOINT_BY_DATASOURCE_BIZIBLE,
                CASE
                    WHEN infl_data.MARKETING_TOUCHPOINT_DATE <= amlh_opp.OPP_CLOSE_DATE
                    AND infl_data.MARKETING_TOUCH_TYPE_DATA_SOURCE = 'Bizible' THEN 1
                    else 0
                END AS FLAG_OPPCLS_INFL_TOUCHPOINT_BY_DATASOURCE_BIZIBLE,
                CASE
                    WHEN infl_data.MARKETING_TOUCHPOINT_DATE <= amlh_opp.AMLH_COLD_ACCOUNT_DATE_STAMP__C
                    AND infl_data.MARKETING_TOUCH_TYPE_DATA_SOURCE = 'Bizible' THEN 1
                    else 0
                END AS FLAG_ACTCOLD_INFL_TOUCHPOINT_BY_DATASOURCE_BIZIBLE,
                CASE
                    WHEN infl_data.MARKETING_TOUCHPOINT_DATE <= amlh_opp.AMLH_MEA_DATE_STAMP__C
                    AND infl_data.MARKETING_TOUCH_TYPE_DATA_SOURCE = 'Bizible' THEN 1
                    else 0
                END AS FLAG_ACTMEA_INFL_TOUCHPOINT_BY_DATASOURCE_BIZIBLE,
                CASE
                    WHEN infl_data.MARKETING_TOUCHPOINT_DATE <= amlh_opp.AMLH_MQA_DATE_STAMP__C
                    AND infl_data.MARKETING_TOUCH_TYPE_DATA_SOURCE = 'Bizible' THEN 1
                    else 0
                END AS FLAG_ACTMQA_INFL_TOUCHPOINT_BY_DATASOURCE_BIZIBLE,
                CASE
                    WHEN infl_data.MARKETING_TOUCHPOINT_DATE <= amlh_opp.AMLH_SUSPECT_DATE_STAMP__C
                    AND infl_data.MARKETING_TOUCH_TYPE_DATA_SOURCE = 'Bizible' THEN 1
                    else 0
                END AS FLAG_ACTSUSPECT_INFL_TOUCHPOINT_BY_DATASOURCE_BIZIBLE,
                CASE
                    WHEN infl_data.MARKETING_TOUCHPOINT_DATE <= amlh_opp.AMLH_PROSPECT_DATE_STAMP__C
                    AND infl_data.MARKETING_TOUCH_TYPE_DATA_SOURCE = 'Bizible' THEN 1
                    else 0
                END AS FLAG_ACTPROSPECT_INFL_TOUCHPOINT_BY_DATASOURCE_BIZIBLE,
				--20250314
                CASE
                    WHEN infl_data.MARKETING_TOUCHPOINT_DATE <= amlh_opp.AMLH_CUSTOMER_DATE_STAMP__C
                    AND infl_data.MARKETING_TOUCH_TYPE_DATA_SOURCE = 'Bizible' THEN 1
                    else 0
                END AS FLAG_ACTCUSTOMER_INFL_TOUCHPOINT_BY_DATASOURCE_BIZIBLE,
                CASE
                    WHEN infl_data.MARKETING_TOUCHPOINT_DATE <= amlh_opp.AMLH_EFFECTIVE_DATE_STAMP__C
                    AND infl_data.MARKETING_TOUCH_TYPE_DATA_SOURCE = 'Bizible' THEN 1
                    else 0
                END AS FLAG_ACTEFFECTIVE_INFL_TOUCHPOINT_BY_DATASOURCE_BIZIBLE,
				
                -- COUNT ONLY IF INFLUENCE
                -- Influenced before Opp Created
                CASE
                    WHEN infl_data.MARKETING_TOUCHPOINT_DATE <= amlh_opp.OPP_CREATED_DATE
                    AND infl_data.INTERACTIONTYPE_SIXSENSE_PAIDMEDIA_IMPRESSIONS_COUNT > 0 THEN 1
                    ELSE 0
                END AS FLAG_OPPCRT_INFL_TOUCHPOINT_BY_INTERACTIONTYPE_SIXSENSE_PAIDMEDIA_IMPRESSION,
                CASE
                    WHEN infl_data.MARKETING_TOUCHPOINT_DATE <= amlh_opp.OPP_CREATED_DATE
                    AND infl_data.INTERACTIONTYPE_SIXSENSE_PAIDMEDIA_CLICKS_COUNT > 0 THEN 1
                    ELSE 0
                END AS FLAG_OPPCRT_INFL_TOUCHPOINT_BY_INTERACTIONTYPE_SIXSENSE_PAIDMEDIA_CLICK,
                CASE
                    WHEN infl_data.MARKETING_TOUCHPOINT_DATE <= amlh_opp.OPP_CREATED_DATE
                    AND infl_data.INTERACTIONTYPE_SIXSENSE_WEBVISIT_TOTAL_INTERACTIONS_COUNT > 0 THEN 1
                    ELSE 0
                END AS FLAG_OPPCRT_INFL_TOUCHPOINT_BY_INTERACTIONTYPE_SIXSENSE_WEBVISIT_TOTAL_INTERACTIONS,
                CASE
                    WHEN infl_data.MARKETING_TOUCHPOINT_DATE <= amlh_opp.OPP_CREATED_DATE
                    AND infl_data.INTERACTIONTYPE_SIXSENSE_WEBVISIT_PAGELOAD_COUNT > 0 THEN 1
                    ELSE 0
                END AS FLAG_OPPCRT_INFL_TOUCHPOINT_BY_INTERACTIONTYPE_SIXSENSE_WEBVISIT_PAGELOAD,
                CASE
                    WHEN infl_data.MARKETING_TOUCHPOINT_DATE <= amlh_opp.OPP_CREATED_DATE
                    AND infl_data.INTERACTIONTYPE_SIXSENSE_WEBVISIT_PLAY_COUNT > 0 THEN 1
                    ELSE 0
                END AS FLAG_OPPCRT_INFL_TOUCHPOINT_BY_INTERACTIONTYPE_SIXSENSE_WEBVISIT_PLAY,
                CASE
                    WHEN infl_data.MARKETING_TOUCHPOINT_DATE <= amlh_opp.OPP_CREATED_DATE
                    AND infl_data.INTERACTIONTYPE_SIXSENSE_WEBVISIT_CLICK_COUNT > 0 THEN 1
                    ELSE 0
                END AS FLAG_OPPCRT_INFL_TOUCHPOINT_BY_INTERACTIONTYPE_SIXSENSE_WEBVISIT_CLICK,
                CASE
                    WHEN infl_data.MARKETING_TOUCHPOINT_DATE <= amlh_opp.OPP_CREATED_DATE
                    AND infl_data.INTERACTIONTYPE_SIXSENSE_WEBVISIT_SUBMIT_COUNT > 0 THEN 1
                    ELSE 0
                END AS FLAG_OPPCRT_INFL_TOUCHPOINT_BY_INTERACTIONTYPE_SIXSENSE_WEBVISIT_SUBMIT,
                CASE
                    WHEN infl_data.MARKETING_TOUCHPOINT_DATE <= amlh_opp.OPP_CREATED_DATE
                    AND infl_data.INTERACTIONTYPE_SIXSENSE_WEBVISIT_UNCLASSIFIED_COUNT > 0 THEN 1
                    ELSE 0
                END AS FLAG_OPPCRT_INFL_TOUCHPOINT_BY_INTERACTIONTYPE_SIXSENSE_WEBVISIT_UNCLASSIFIED,
                CASE
                    WHEN infl_data.MARKETING_TOUCHPOINT_DATE <= amlh_opp.OPP_CREATED_DATE
                    AND infl_data.INTERACTIONTYPE_BIZIBLE_TOUCHPOINT_WEBVISIT_COUNT > 0 THEN 1
                    ELSE 0
                END AS FLAG_OPPCRT_INFL_TOUCHPOINT_BY_INTERACTIONTYPE_BIZIBLE_TOUCHPOINT_WEBVISIT,
                CASE
                    WHEN infl_data.MARKETING_TOUCHPOINT_DATE <= amlh_opp.OPP_CREATED_DATE
                    AND infl_data.INTERACTIONTYPE_BIZIBLE_TOUCHPOINT_WEBCHAT_COUNT > 0 THEN 1
                    ELSE 0
                END AS FLAG_OPPCRT_INFL_TOUCHPOINT_BY_INTERACTIONTYPE_BIZIBLE_TOUCHPOINT_WEBCHAT,
                CASE
                    WHEN infl_data.MARKETING_TOUCHPOINT_DATE <= amlh_opp.OPP_CREATED_DATE
                    AND infl_data.INTERACTIONTYPE_BIZIBLE_TOUCHPOINT_WEBFORM_COUNT > 0 THEN 1
                    ELSE 0
                END AS FLAG_OPPCRT_INFL_TOUCHPOINT_BY_INTERACTIONTYPE_BIZIBLE_TOUCHPOINT_WEBFORM,
                CASE
                    WHEN infl_data.MARKETING_TOUCHPOINT_DATE <= amlh_opp.OPP_CREATED_DATE
                    AND infl_data.INTERACTIONTYPE_BIZIBLE_TOUCHPOINT_CRM_COUNT > 0 THEN 1
                    ELSE 0
                END AS FLAG_OPPCRT_INFL_TOUCHPOINT_BY_INTERACTIONTYPE_BIZIBLE_TOUCHPOINT_CRM,
                CASE
                    WHEN infl_data.MARKETING_TOUCHPOINT_DATE <= amlh_opp.OPP_CREATED_DATE
                    AND infl_data.INTERACTIONTYPE_BIZIBLE_TOUCHPOINT_CONNECTWITHDM_COUNT > 0 THEN 1
                    ELSE 0
                END AS FLAG_OPPCRT_INFL_TOUCHPOINT_BY_INTERACTIONTYPE_BIZIBLE_TOUCHPOINT_CONNECTWITHDM,
                CASE
                    WHEN infl_data.MARKETING_TOUCHPOINT_DATE <= amlh_opp.OPP_CREATED_DATE
                    AND infl_data.INTERACTIONTYPE_BIZIBLE_TOUCHPOINT_CALLSPOKEWITH_COUNT > 0 THEN 1
                    ELSE 0
                END AS FLAG_OPPCRT_INFL_TOUCHPOINT_BY_INTERACTIONTYPE_BIZIBLE_TOUCHPOINT_CALLSPOKEIWTH,
                CASE
                    WHEN infl_data.MARKETING_TOUCHPOINT_DATE <= amlh_opp.OPP_CREATED_DATE
                    AND infl_data.INTERACTIONTYPE_BIZIBLE_TOUCHPOINT_CALLGATEKEEPER_COUNT > 0 THEN 1
                    ELSE 0
                END AS FLAG_OPPCRT_INFL_TOUCHPOINT_BY_INTERACTIONTYPE_BIZIBLE_TOUCHPOINT_GATEKEEPER,
                CASE
                    WHEN infl_data.MARKETING_TOUCHPOINT_DATE <= amlh_opp.OPP_CREATED_DATE
                    AND infl_data.INTERACTIONTYPE_BIZIBLE_TOUCHPOINT_NOLEADTOUCHPOINTS_COUNT > 0 THEN 1
                    ELSE 0
                END AS FLAG_OPPCRT_INFL_TOUCHPOINT_BY_INTERACTIONTYPE_BIZIBLE_TOUCHPOINT_NOLEADTOUCHPOINT,
				--20250302
                CASE
                    WHEN infl_data.MARKETING_TOUCHPOINT_DATE <= amlh_opp.OPP_CREATED_DATE
                    AND infl_data.INTERACTIONTYPE_BIZIBLE_TOUCHPOINT_MARKETO_COUNT > 0 THEN 1
                    ELSE 0
                END AS FLAG_OPPCRT_INFL_TOUCHPOINT_BY_INTERACTIONTYPE_BIZIBLE_TOUCHPOINT_MARKETO,
				--20250314
                CASE
                    WHEN infl_data.MARKETING_TOUCHPOINT_DATE <= amlh_opp.OPP_CREATED_DATE
                    AND infl_data.INTERACTIONTYPE_BIZIBLE_TOUCHPOINT_SEISMICENGAGEMENT_COUNT > 0 THEN 1
                    ELSE 0
                END AS FLAG_OPPCRT_INFL_TOUCHPOINT_BY_INTERACTIONTYPE_BIZIBLE_TOUCHPOINT_SEISMICENGAGEMENT,
                CASE
                    WHEN infl_data.MARKETING_TOUCHPOINT_DATE <= amlh_opp.OPP_CREATED_DATE
                    AND infl_data.INTERACTIONTYPE_BIZIBLE_TOUCHPOINT_CHANGESTATUS_COUNT > 0 THEN 1
                    ELSE 0
                END AS FLAG_OPPCRT_INFL_TOUCHPOINT_BY_INTERACTIONTYPE_BIZIBLE_TOUCHPOINT_CHANGESTATUS,	
                CASE
                    WHEN infl_data.MARKETING_TOUCHPOINT_DATE <= amlh_opp.OPP_CREATED_DATE
                    AND infl_data.INTERACTIONTYPE_BIZIBLE_TOUCHPOINT_UNCLASSIFIED_COUNT > 0 THEN 1
                    ELSE 0
                END AS FLAG_OPPCRT_INFL_TOUCHPOINT_BY_INTERACTIONTYPE_BIZIBLE_TOUCHPOINT_UNCLASSIFIED,
				--20251002
                -- Influenced before Opp Stage Zero
                CASE
                    WHEN infl_data.MARKETING_TOUCHPOINT_DATE <= amlh_opp.OPP_STAGE_0_DATE
                    AND infl_data.INTERACTIONTYPE_SIXSENSE_PAIDMEDIA_IMPRESSIONS_COUNT > 0 THEN 1
                    ELSE 0
                END AS FLAG_OPPSTG0_INFL_TOUCHPOINT_BY_INTERACTIONTYPE_SIXSENSE_PAIDMEDIA_IMPRESSION,
                CASE
                    WHEN infl_data.MARKETING_TOUCHPOINT_DATE <= amlh_opp.OPP_STAGE_0_DATE
                    AND infl_data.INTERACTIONTYPE_SIXSENSE_PAIDMEDIA_CLICKS_COUNT > 0 THEN 1
                    ELSE 0
                END AS FLAG_OPPSTG0_INFL_TOUCHPOINT_BY_INTERACTIONTYPE_SIXSENSE_PAIDMEDIA_CLICK,
                CASE
                    WHEN infl_data.MARKETING_TOUCHPOINT_DATE <= amlh_opp.OPP_STAGE_0_DATE
                    AND infl_data.INTERACTIONTYPE_SIXSENSE_WEBVISIT_TOTAL_INTERACTIONS_COUNT > 0 THEN 1
                    ELSE 0
                END AS FLAG_OPPSTG0_INFL_TOUCHPOINT_BY_INTERACTIONTYPE_SIXSENSE_WEBVISIT_TOTAL_INTERACTIONS,
                CASE
                    WHEN infl_data.MARKETING_TOUCHPOINT_DATE <= amlh_opp.OPP_STAGE_0_DATE
                    AND infl_data.INTERACTIONTYPE_SIXSENSE_WEBVISIT_PAGELOAD_COUNT > 0 THEN 1
                    ELSE 0
                END AS FLAG_OPPSTG0_INFL_TOUCHPOINT_BY_INTERACTIONTYPE_SIXSENSE_WEBVISIT_PAGELOAD,
                CASE
                    WHEN infl_data.MARKETING_TOUCHPOINT_DATE <= amlh_opp.OPP_STAGE_0_DATE
                    AND infl_data.INTERACTIONTYPE_SIXSENSE_WEBVISIT_PLAY_COUNT > 0 THEN 1
                    ELSE 0
                END AS FLAG_OPPSTG0_INFL_TOUCHPOINT_BY_INTERACTIONTYPE_SIXSENSE_WEBVISIT_PLAY,
                CASE
                    WHEN infl_data.MARKETING_TOUCHPOINT_DATE <= amlh_opp.OPP_STAGE_0_DATE
                    AND infl_data.INTERACTIONTYPE_SIXSENSE_WEBVISIT_CLICK_COUNT > 0 THEN 1
                    ELSE 0
                END AS FLAG_OPPSTG0_INFL_TOUCHPOINT_BY_INTERACTIONTYPE_SIXSENSE_WEBVISIT_CLICK,
                CASE
                    WHEN infl_data.MARKETING_TOUCHPOINT_DATE <= amlh_opp.OPP_STAGE_0_DATE
                    AND infl_data.INTERACTIONTYPE_SIXSENSE_WEBVISIT_SUBMIT_COUNT > 0 THEN 1
                    ELSE 0
                END AS FLAG_OPPSTG0_INFL_TOUCHPOINT_BY_INTERACTIONTYPE_SIXSENSE_WEBVISIT_SUBMIT,
                CASE
                    WHEN infl_data.MARKETING_TOUCHPOINT_DATE <= amlh_opp.OPP_STAGE_0_DATE
                    AND infl_data.INTERACTIONTYPE_SIXSENSE_WEBVISIT_UNCLASSIFIED_COUNT > 0 THEN 1
                    ELSE 0
                END AS FLAG_OPPSTG0_INFL_TOUCHPOINT_BY_INTERACTIONTYPE_SIXSENSE_WEBVISIT_UNCLASSIFIED,
                CASE
                    WHEN infl_data.MARKETING_TOUCHPOINT_DATE <= amlh_opp.OPP_STAGE_0_DATE
                    AND infl_data.INTERACTIONTYPE_BIZIBLE_TOUCHPOINT_WEBVISIT_COUNT > 0 THEN 1
                    ELSE 0
                END AS FLAG_OPPSTG0_INFL_TOUCHPOINT_BY_INTERACTIONTYPE_BIZIBLE_TOUCHPOINT_WEBVISIT,
                CASE
                    WHEN infl_data.MARKETING_TOUCHPOINT_DATE <= amlh_opp.OPP_STAGE_0_DATE
                    AND infl_data.INTERACTIONTYPE_BIZIBLE_TOUCHPOINT_WEBCHAT_COUNT > 0 THEN 1
                    ELSE 0
                END AS FLAG_OPPSTG0_INFL_TOUCHPOINT_BY_INTERACTIONTYPE_BIZIBLE_TOUCHPOINT_WEBCHAT,
                CASE
                    WHEN infl_data.MARKETING_TOUCHPOINT_DATE <= amlh_opp.OPP_STAGE_0_DATE
                    AND infl_data.INTERACTIONTYPE_BIZIBLE_TOUCHPOINT_WEBFORM_COUNT > 0 THEN 1
                    ELSE 0
                END AS FLAG_OPPSTG0_INFL_TOUCHPOINT_BY_INTERACTIONTYPE_BIZIBLE_TOUCHPOINT_WEBFORM,
                CASE
                    WHEN infl_data.MARKETING_TOUCHPOINT_DATE <= amlh_opp.OPP_STAGE_0_DATE
                    AND infl_data.INTERACTIONTYPE_BIZIBLE_TOUCHPOINT_CRM_COUNT > 0 THEN 1
                    ELSE 0
                END AS FLAG_OPPSTG0_INFL_TOUCHPOINT_BY_INTERACTIONTYPE_BIZIBLE_TOUCHPOINT_CRM,
                CASE
                    WHEN infl_data.MARKETING_TOUCHPOINT_DATE <= amlh_opp.OPP_STAGE_0_DATE
                    AND infl_data.INTERACTIONTYPE_BIZIBLE_TOUCHPOINT_CONNECTWITHDM_COUNT > 0 THEN 1
                    ELSE 0
                END AS FLAG_OPPSTG0_INFL_TOUCHPOINT_BY_INTERACTIONTYPE_BIZIBLE_TOUCHPOINT_CONNECTWITHDM,
                CASE
                    WHEN infl_data.MARKETING_TOUCHPOINT_DATE <= amlh_opp.OPP_STAGE_0_DATE
                    AND infl_data.INTERACTIONTYPE_BIZIBLE_TOUCHPOINT_CALLSPOKEWITH_COUNT > 0 THEN 1
                    ELSE 0
                END AS FLAG_OPPSTG0_INFL_TOUCHPOINT_BY_INTERACTIONTYPE_BIZIBLE_TOUCHPOINT_CALLSPOKEIWTH,
                CASE
                    WHEN infl_data.MARKETING_TOUCHPOINT_DATE <= amlh_opp.OPP_STAGE_0_DATE
                    AND infl_data.INTERACTIONTYPE_BIZIBLE_TOUCHPOINT_CALLGATEKEEPER_COUNT > 0 THEN 1
                    ELSE 0
                END AS FLAG_OPPSTG0_INFL_TOUCHPOINT_BY_INTERACTIONTYPE_BIZIBLE_TOUCHPOINT_GATEKEEPER,
                CASE
                    WHEN infl_data.MARKETING_TOUCHPOINT_DATE <= amlh_opp.OPP_STAGE_0_DATE
                    AND infl_data.INTERACTIONTYPE_BIZIBLE_TOUCHPOINT_NOLEADTOUCHPOINTS_COUNT > 0 THEN 1
                    ELSE 0
                END AS FLAG_OPPSTG0_INFL_TOUCHPOINT_BY_INTERACTIONTYPE_BIZIBLE_TOUCHPOINT_NOLEADTOUCHPOINT,
				--20250302
                CASE
                    WHEN infl_data.MARKETING_TOUCHPOINT_DATE <= amlh_opp.OPP_STAGE_0_DATE
                    AND infl_data.INTERACTIONTYPE_BIZIBLE_TOUCHPOINT_MARKETO_COUNT > 0 THEN 1
                    ELSE 0
                END AS FLAG_OPPSTG0_INFL_TOUCHPOINT_BY_INTERACTIONTYPE_BIZIBLE_TOUCHPOINT_MARKETO,
				--20250314
                CASE
                    WHEN infl_data.MARKETING_TOUCHPOINT_DATE <= amlh_opp.OPP_STAGE_0_DATE
                    AND infl_data.INTERACTIONTYPE_BIZIBLE_TOUCHPOINT_SEISMICENGAGEMENT_COUNT > 0 THEN 1
                    ELSE 0
                END AS FLAG_OPPSTG0_INFL_TOUCHPOINT_BY_INTERACTIONTYPE_BIZIBLE_TOUCHPOINT_SEISMICENGAGEMENT,
                CASE
                    WHEN infl_data.MARKETING_TOUCHPOINT_DATE <= amlh_opp.OPP_STAGE_0_DATE
                    AND infl_data.INTERACTIONTYPE_BIZIBLE_TOUCHPOINT_CHANGESTATUS_COUNT > 0 THEN 1
                    ELSE 0
                END AS FLAG_OPPSTG0_INFL_TOUCHPOINT_BY_INTERACTIONTYPE_BIZIBLE_TOUCHPOINT_CHANGESTATUS,				
                CASE
                    WHEN infl_data.MARKETING_TOUCHPOINT_DATE <= amlh_opp.OPP_STAGE_0_DATE
                    AND infl_data.INTERACTIONTYPE_BIZIBLE_TOUCHPOINT_UNCLASSIFIED_COUNT > 0 THEN 1
                    ELSE 0
                END AS FLAG_OPPSTG0_INFL_TOUCHPOINT_BY_INTERACTIONTYPE_BIZIBLE_TOUCHPOINT_UNCLASSIFIED,
				--20250302
                -- Influenced before Opp Stage One
                CASE
                    WHEN infl_data.MARKETING_TOUCHPOINT_DATE <= amlh_opp.OPP_STAGE_1_DATE
                    AND infl_data.INTERACTIONTYPE_SIXSENSE_PAIDMEDIA_IMPRESSIONS_COUNT > 0 THEN 1
                    ELSE 0
                END AS FLAG_OPPSTG1_INFL_TOUCHPOINT_BY_INTERACTIONTYPE_SIXSENSE_PAIDMEDIA_IMPRESSION,
                CASE
                    WHEN infl_data.MARKETING_TOUCHPOINT_DATE <= amlh_opp.OPP_STAGE_1_DATE
                    AND infl_data.INTERACTIONTYPE_SIXSENSE_PAIDMEDIA_CLICKS_COUNT > 0 THEN 1
                    ELSE 0
                END AS FLAG_OPPSTG1_INFL_TOUCHPOINT_BY_INTERACTIONTYPE_SIXSENSE_PAIDMEDIA_CLICK,
                CASE
                    WHEN infl_data.MARKETING_TOUCHPOINT_DATE <= amlh_opp.OPP_STAGE_1_DATE
                    AND infl_data.INTERACTIONTYPE_SIXSENSE_WEBVISIT_TOTAL_INTERACTIONS_COUNT > 0 THEN 1
                    ELSE 0
                END AS FLAG_OPPSTG1_INFL_TOUCHPOINT_BY_INTERACTIONTYPE_SIXSENSE_WEBVISIT_TOTAL_INTERACTIONS,
                CASE
                    WHEN infl_data.MARKETING_TOUCHPOINT_DATE <= amlh_opp.OPP_STAGE_1_DATE
                    AND infl_data.INTERACTIONTYPE_SIXSENSE_WEBVISIT_PAGELOAD_COUNT > 0 THEN 1
                    ELSE 0
                END AS FLAG_OPPSTG1_INFL_TOUCHPOINT_BY_INTERACTIONTYPE_SIXSENSE_WEBVISIT_PAGELOAD,
                CASE
                    WHEN infl_data.MARKETING_TOUCHPOINT_DATE <= amlh_opp.OPP_STAGE_1_DATE
                    AND infl_data.INTERACTIONTYPE_SIXSENSE_WEBVISIT_PLAY_COUNT > 0 THEN 1
                    ELSE 0
                END AS FLAG_OPPSTG1_INFL_TOUCHPOINT_BY_INTERACTIONTYPE_SIXSENSE_WEBVISIT_PLAY,
                CASE
                    WHEN infl_data.MARKETING_TOUCHPOINT_DATE <= amlh_opp.OPP_STAGE_1_DATE
                    AND infl_data.INTERACTIONTYPE_SIXSENSE_WEBVISIT_CLICK_COUNT > 0 THEN 1
                    ELSE 0
                END AS FLAG_OPPSTG1_INFL_TOUCHPOINT_BY_INTERACTIONTYPE_SIXSENSE_WEBVISIT_CLICK,
                CASE
                    WHEN infl_data.MARKETING_TOUCHPOINT_DATE <= amlh_opp.OPP_STAGE_1_DATE
                    AND infl_data.INTERACTIONTYPE_SIXSENSE_WEBVISIT_SUBMIT_COUNT > 0 THEN 1
                    ELSE 0
                END AS FLAG_OPPSTG1_INFL_TOUCHPOINT_BY_INTERACTIONTYPE_SIXSENSE_WEBVISIT_SUBMIT,
                CASE
                    WHEN infl_data.MARKETING_TOUCHPOINT_DATE <= amlh_opp.OPP_STAGE_1_DATE
                    AND infl_data.INTERACTIONTYPE_SIXSENSE_WEBVISIT_UNCLASSIFIED_COUNT > 0 THEN 1
                    ELSE 0
                END AS FLAG_OPPSTG1_INFL_TOUCHPOINT_BY_INTERACTIONTYPE_SIXSENSE_WEBVISIT_UNCLASSIFIED,
                CASE
                    WHEN infl_data.MARKETING_TOUCHPOINT_DATE <= amlh_opp.OPP_STAGE_1_DATE
                    AND infl_data.INTERACTIONTYPE_BIZIBLE_TOUCHPOINT_WEBVISIT_COUNT > 0 THEN 1
                    ELSE 0
                END AS FLAG_OPPSTG1_INFL_TOUCHPOINT_BY_INTERACTIONTYPE_BIZIBLE_TOUCHPOINT_WEBVISIT,
                CASE
                    WHEN infl_data.MARKETING_TOUCHPOINT_DATE <= amlh_opp.OPP_STAGE_1_DATE
                    AND infl_data.INTERACTIONTYPE_BIZIBLE_TOUCHPOINT_WEBCHAT_COUNT > 0 THEN 1
                    ELSE 0
                END AS FLAG_OPPSTG1_INFL_TOUCHPOINT_BY_INTERACTIONTYPE_BIZIBLE_TOUCHPOINT_WEBCHAT,
                CASE
                    WHEN infl_data.MARKETING_TOUCHPOINT_DATE <= amlh_opp.OPP_STAGE_1_DATE
                    AND infl_data.INTERACTIONTYPE_BIZIBLE_TOUCHPOINT_WEBFORM_COUNT > 0 THEN 1
                    ELSE 0
                END AS FLAG_OPPSTG1_INFL_TOUCHPOINT_BY_INTERACTIONTYPE_BIZIBLE_TOUCHPOINT_WEBFORM,
                CASE
                    WHEN infl_data.MARKETING_TOUCHPOINT_DATE <= amlh_opp.OPP_STAGE_1_DATE
                    AND infl_data.INTERACTIONTYPE_BIZIBLE_TOUCHPOINT_CRM_COUNT > 0 THEN 1
                    ELSE 0
                END AS FLAG_OPPSTG1_INFL_TOUCHPOINT_BY_INTERACTIONTYPE_BIZIBLE_TOUCHPOINT_CRM,
                CASE
                    WHEN infl_data.MARKETING_TOUCHPOINT_DATE <= amlh_opp.OPP_STAGE_1_DATE
                    AND infl_data.INTERACTIONTYPE_BIZIBLE_TOUCHPOINT_CONNECTWITHDM_COUNT > 0 THEN 1
                    ELSE 0
                END AS FLAG_OPPSTG1_INFL_TOUCHPOINT_BY_INTERACTIONTYPE_BIZIBLE_TOUCHPOINT_CONNECTWITHDM,
                CASE
                    WHEN infl_data.MARKETING_TOUCHPOINT_DATE <= amlh_opp.OPP_STAGE_1_DATE
                    AND infl_data.INTERACTIONTYPE_BIZIBLE_TOUCHPOINT_CALLSPOKEWITH_COUNT > 0 THEN 1
                    ELSE 0
                END AS FLAG_OPPSTG1_INFL_TOUCHPOINT_BY_INTERACTIONTYPE_BIZIBLE_TOUCHPOINT_CALLSPOKEIWTH,
                CASE
                    WHEN infl_data.MARKETING_TOUCHPOINT_DATE <= amlh_opp.OPP_STAGE_1_DATE
                    AND infl_data.INTERACTIONTYPE_BIZIBLE_TOUCHPOINT_CALLGATEKEEPER_COUNT > 0 THEN 1
                    ELSE 0
                END AS FLAG_OPPSTG1_INFL_TOUCHPOINT_BY_INTERACTIONTYPE_BIZIBLE_TOUCHPOINT_GATEKEEPER,
                CASE
                    WHEN infl_data.MARKETING_TOUCHPOINT_DATE <= amlh_opp.OPP_STAGE_1_DATE
                    AND infl_data.INTERACTIONTYPE_BIZIBLE_TOUCHPOINT_NOLEADTOUCHPOINTS_COUNT > 0 THEN 1
                    ELSE 0
                END AS FLAG_OPPSTG1_INFL_TOUCHPOINT_BY_INTERACTIONTYPE_BIZIBLE_TOUCHPOINT_NOLEADTOUCHPOINT,
				--20250302
                CASE
                    WHEN infl_data.MARKETING_TOUCHPOINT_DATE <= amlh_opp.OPP_STAGE_1_DATE
                    AND infl_data.INTERACTIONTYPE_BIZIBLE_TOUCHPOINT_MARKETO_COUNT > 0 THEN 1
                    ELSE 0
                END AS FLAG_OPPSTG1_INFL_TOUCHPOINT_BY_INTERACTIONTYPE_BIZIBLE_TOUCHPOINT_MARKETO,
				--20250314
                CASE
                    WHEN infl_data.MARKETING_TOUCHPOINT_DATE <= amlh_opp.OPP_STAGE_1_DATE
                    AND infl_data.INTERACTIONTYPE_BIZIBLE_TOUCHPOINT_SEISMICENGAGEMENT_COUNT > 0 THEN 1
                    ELSE 0
                END AS FLAG_OPPSTG1_INFL_TOUCHPOINT_BY_INTERACTIONTYPE_BIZIBLE_TOUCHPOINT_SEISMICENGAGEMENT,
                CASE
                    WHEN infl_data.MARKETING_TOUCHPOINT_DATE <= amlh_opp.OPP_STAGE_1_DATE
                    AND infl_data.INTERACTIONTYPE_BIZIBLE_TOUCHPOINT_CHANGESTATUS_COUNT > 0 THEN 1
                    ELSE 0
                END AS FLAG_OPPSTG1_INFL_TOUCHPOINT_BY_INTERACTIONTYPE_BIZIBLE_TOUCHPOINT_CHANGESTATUS,				
                CASE
                    WHEN infl_data.MARKETING_TOUCHPOINT_DATE <= amlh_opp.OPP_STAGE_1_DATE
                    AND infl_data.INTERACTIONTYPE_BIZIBLE_TOUCHPOINT_UNCLASSIFIED_COUNT > 0 THEN 1
                    ELSE 0
                END AS FLAG_OPPSTG1_INFL_TOUCHPOINT_BY_INTERACTIONTYPE_BIZIBLE_TOUCHPOINT_UNCLASSIFIED,
                -- Influenced before Opp Close Date
                CASE
                    WHEN infl_data.MARKETING_TOUCHPOINT_DATE <= amlh_opp.OPP_CLOSE_DATE
                    AND infl_data.INTERACTIONTYPE_SIXSENSE_PAIDMEDIA_IMPRESSIONS_COUNT > 0 THEN 1
                    ELSE 0
                END AS FLAG_OPPCLS_INFL_TOUCHPOINT_BY_INTERACTIONTYPE_SIXSENSE_PAIDMEDIA_IMPRESSION,
                CASE
                    WHEN infl_data.MARKETING_TOUCHPOINT_DATE <= amlh_opp.OPP_CLOSE_DATE
                    AND infl_data.INTERACTIONTYPE_SIXSENSE_PAIDMEDIA_CLICKS_COUNT > 0 THEN 1
                    ELSE 0
                END AS FLAG_OPPCLS_INFL_TOUCHPOINT_BY_INTERACTIONTYPE_SIXSENSE_PAIDMEDIA_CLICK,
                CASE
                    WHEN infl_data.MARKETING_TOUCHPOINT_DATE <= amlh_opp.OPP_CLOSE_DATE
                    AND infl_data.INTERACTIONTYPE_SIXSENSE_WEBVISIT_TOTAL_INTERACTIONS_COUNT > 0 THEN 1
                    ELSE 0
                END AS FLAG_OPPCLS_INFL_TOUCHPOINT_BY_INTERACTIONTYPE_SIXSENSE_WEBVISIT_TOTAL_INTERACTIONS,
                CASE
                    WHEN infl_data.MARKETING_TOUCHPOINT_DATE <= amlh_opp.OPP_CLOSE_DATE
                    AND infl_data.INTERACTIONTYPE_SIXSENSE_WEBVISIT_PAGELOAD_COUNT > 0 THEN 1
                    ELSE 0
                END AS FLAG_OPPCLS_INFL_TOUCHPOINT_BY_INTERACTIONTYPE_SIXSENSE_WEBVISIT_PAGELOAD,
                CASE
                    WHEN infl_data.MARKETING_TOUCHPOINT_DATE <= amlh_opp.OPP_CLOSE_DATE
                    AND infl_data.INTERACTIONTYPE_SIXSENSE_WEBVISIT_PLAY_COUNT > 0 THEN 1
                    ELSE 0
                END AS FLAG_OPPCLS_INFL_TOUCHPOINT_BY_INTERACTIONTYPE_SIXSENSE_WEBVISIT_PLAY,
                CASE
                    WHEN infl_data.MARKETING_TOUCHPOINT_DATE <= amlh_opp.OPP_CLOSE_DATE
                    AND infl_data.INTERACTIONTYPE_SIXSENSE_WEBVISIT_CLICK_COUNT > 0 THEN 1
                    ELSE 0
                END AS FLAG_OPPCLS_INFL_TOUCHPOINT_BY_INTERACTIONTYPE_SIXSENSE_WEBVISIT_CLICK,
                CASE
                    WHEN infl_data.MARKETING_TOUCHPOINT_DATE <= amlh_opp.OPP_CLOSE_DATE
                    AND infl_data.INTERACTIONTYPE_SIXSENSE_WEBVISIT_SUBMIT_COUNT > 0 THEN 1
                    ELSE 0
                END AS FLAG_OPPCLS_INFL_TOUCHPOINT_BY_INTERACTIONTYPE_SIXSENSE_WEBVISIT_SUBMIT,
                CASE
                    WHEN infl_data.MARKETING_TOUCHPOINT_DATE <= amlh_opp.OPP_CLOSE_DATE
                    AND infl_data.INTERACTIONTYPE_SIXSENSE_WEBVISIT_UNCLASSIFIED_COUNT > 0 THEN 1
                    ELSE 0
                END AS FLAG_OPPCLS_INFL_TOUCHPOINT_BY_INTERACTIONTYPE_SIXSENSE_WEBVISIT_UNCLASSIFIED,
                CASE
                    WHEN infl_data.MARKETING_TOUCHPOINT_DATE <= amlh_opp.OPP_CLOSE_DATE
                    AND infl_data.INTERACTIONTYPE_BIZIBLE_TOUCHPOINT_WEBVISIT_COUNT > 0 THEN 1
                    ELSE 0
                END AS FLAG_OPPCLS_INFL_TOUCHPOINT_BY_INTERACTIONTYPE_BIZIBLE_TOUCHPOINT_WEBVISIT,
                CASE
                    WHEN infl_data.MARKETING_TOUCHPOINT_DATE <= amlh_opp.OPP_CLOSE_DATE
                    AND infl_data.INTERACTIONTYPE_BIZIBLE_TOUCHPOINT_WEBCHAT_COUNT > 0 THEN 1
                    ELSE 0
                END AS FLAG_OPPCLS_INFL_TOUCHPOINT_BY_INTERACTIONTYPE_BIZIBLE_TOUCHPOINT_WEBCHAT,
                CASE
                    WHEN infl_data.MARKETING_TOUCHPOINT_DATE <= amlh_opp.OPP_CLOSE_DATE
                    AND infl_data.INTERACTIONTYPE_BIZIBLE_TOUCHPOINT_WEBFORM_COUNT > 0 THEN 1
                    ELSE 0
                END AS FLAG_OPPCLS_INFL_TOUCHPOINT_BY_INTERACTIONTYPE_BIZIBLE_TOUCHPOINT_WEBFORM,
                CASE
                    WHEN infl_data.MARKETING_TOUCHPOINT_DATE <= amlh_opp.OPP_CLOSE_DATE
                    AND infl_data.INTERACTIONTYPE_BIZIBLE_TOUCHPOINT_CRM_COUNT > 0 THEN 1
                    ELSE 0
                END AS FLAG_OPPCLS_INFL_TOUCHPOINT_BY_INTERACTIONTYPE_BIZIBLE_TOUCHPOINT_CRM,
                CASE
                    WHEN infl_data.MARKETING_TOUCHPOINT_DATE <= amlh_opp.OPP_CLOSE_DATE
                    AND infl_data.INTERACTIONTYPE_BIZIBLE_TOUCHPOINT_CONNECTWITHDM_COUNT > 0 THEN 1
                    ELSE 0
                END AS FLAG_OPPCLS_INFL_TOUCHPOINT_BY_INTERACTIONTYPE_BIZIBLE_TOUCHPOINT_CONNECTWITHDM,
                CASE
                    WHEN infl_data.MARKETING_TOUCHPOINT_DATE <= amlh_opp.OPP_CLOSE_DATE
                    AND infl_data.INTERACTIONTYPE_BIZIBLE_TOUCHPOINT_CALLSPOKEWITH_COUNT > 0 THEN 1
                    ELSE 0
                END AS FLAG_OPPCLS_INFL_TOUCHPOINT_BY_INTERACTIONTYPE_BIZIBLE_TOUCHPOINT_CALLSPOKEIWTH,
                CASE
                    WHEN infl_data.MARKETING_TOUCHPOINT_DATE <= amlh_opp.OPP_CLOSE_DATE
                    AND infl_data.INTERACTIONTYPE_BIZIBLE_TOUCHPOINT_CALLGATEKEEPER_COUNT > 0 THEN 1
                    ELSE 0
                END AS FLAG_OPPCLS_INFL_TOUCHPOINT_BY_INTERACTIONTYPE_BIZIBLE_TOUCHPOINT_GATEKEEPER,
                CASE
                    WHEN infl_data.MARKETING_TOUCHPOINT_DATE <= amlh_opp.OPP_CLOSE_DATE
                    AND infl_data.INTERACTIONTYPE_BIZIBLE_TOUCHPOINT_NOLEADTOUCHPOINTS_COUNT > 0 THEN 1
                    ELSE 0
                END AS FLAG_OPPCLS_INFL_TOUCHPOINT_BY_INTERACTIONTYPE_BIZIBLE_TOUCHPOINT_NOLEADTOUCHPOINT,
				--20250302
                CASE
                    WHEN infl_data.MARKETING_TOUCHPOINT_DATE <= amlh_opp.OPP_CLOSE_DATE
                    AND infl_data.INTERACTIONTYPE_BIZIBLE_TOUCHPOINT_MARKETO_COUNT > 0 THEN 1
                    ELSE 0
                END AS FLAG_OPPCLS_INFL_TOUCHPOINT_BY_INTERACTIONTYPE_BIZIBLE_TOUCHPOINT_MARKETO,
				--20250314
                CASE
                    WHEN infl_data.MARKETING_TOUCHPOINT_DATE <= amlh_opp.OPP_CLOSE_DATE
                    AND infl_data.INTERACTIONTYPE_BIZIBLE_TOUCHPOINT_SEISMICENGAGEMENT_COUNT > 0 THEN 1
                    ELSE 0
                END AS FLAG_OPPCLS_INFL_TOUCHPOINT_BY_INTERACTIONTYPE_BIZIBLE_TOUCHPOINT_SEISMICENGAGEMENT,
                CASE
                    WHEN infl_data.MARKETING_TOUCHPOINT_DATE <= amlh_opp.OPP_CLOSE_DATE
                    AND infl_data.INTERACTIONTYPE_BIZIBLE_TOUCHPOINT_CHANGESTATUS_COUNT > 0 THEN 1
                    ELSE 0
                END AS FLAG_OPPCLS_INFL_TOUCHPOINT_BY_INTERACTIONTYPE_BIZIBLE_TOUCHPOINT_CHANGESTATUS,	
                CASE
                    WHEN infl_data.MARKETING_TOUCHPOINT_DATE <= amlh_opp.OPP_CLOSE_DATE
                    AND infl_data.INTERACTIONTYPE_BIZIBLE_TOUCHPOINT_UNCLASSIFIED_COUNT > 0 THEN 1
                    ELSE 0
                END AS FLAG_OPPCLS_INFL_TOUCHPOINT_BY_INTERACTIONTYPE_BIZIBLE_TOUCHPOINT_UNCLASSIFIED,
                -- Influenced before Act Cold
                CASE
                    WHEN infl_data.MARKETING_TOUCHPOINT_DATE <= amlh_opp.AMLH_COLD_ACCOUNT_DATE_STAMP__C
                    AND infl_data.INTERACTIONTYPE_SIXSENSE_PAIDMEDIA_IMPRESSIONS_COUNT > 0 THEN 1
                    ELSE 0
                END AS FLAG_ACTCOLD_INFL_TOUCHPOINT_BY_INTERACTIONTYPE_SIXSENSE_PAIDMEDIA_IMPRESSION,
                CASE
                    WHEN infl_data.MARKETING_TOUCHPOINT_DATE <= amlh_opp.AMLH_COLD_ACCOUNT_DATE_STAMP__C
                    AND infl_data.INTERACTIONTYPE_SIXSENSE_PAIDMEDIA_CLICKS_COUNT > 0 THEN 1
                    ELSE 0
                END AS FLAG_ACTCOLD_INFL_TOUCHPOINT_BY_INTERACTIONTYPE_SIXSENSE_PAIDMEDIA_CLICK,
                CASE
                    WHEN infl_data.MARKETING_TOUCHPOINT_DATE <= amlh_opp.AMLH_COLD_ACCOUNT_DATE_STAMP__C
                    AND infl_data.INTERACTIONTYPE_SIXSENSE_WEBVISIT_TOTAL_INTERACTIONS_COUNT > 0 THEN 1
                    ELSE 0
                END AS FLAG_ACTCOLD_INFL_TOUCHPOINT_BY_INTERACTIONTYPE_SIXSENSE_WEBVISIT_TOTAL_INTERACTIONS,
                CASE
                    WHEN infl_data.MARKETING_TOUCHPOINT_DATE <= amlh_opp.AMLH_COLD_ACCOUNT_DATE_STAMP__C
                    AND infl_data.INTERACTIONTYPE_SIXSENSE_WEBVISIT_PAGELOAD_COUNT > 0 THEN 1
                    ELSE 0
                END AS FLAG_ACTCOLD_INFL_TOUCHPOINT_BY_INTERACTIONTYPE_SIXSENSE_WEBVISIT_PAGELOAD,
                CASE
                    WHEN infl_data.MARKETING_TOUCHPOINT_DATE <= amlh_opp.AMLH_COLD_ACCOUNT_DATE_STAMP__C
                    AND infl_data.INTERACTIONTYPE_SIXSENSE_WEBVISIT_PLAY_COUNT > 0 THEN 1
                    ELSE 0
                END AS FLAG_ACTCOLD_INFL_TOUCHPOINT_BY_INTERACTIONTYPE_SIXSENSE_WEBVISIT_PLAY,
                CASE
                    WHEN infl_data.MARKETING_TOUCHPOINT_DATE <= amlh_opp.AMLH_COLD_ACCOUNT_DATE_STAMP__C
                    AND infl_data.INTERACTIONTYPE_SIXSENSE_WEBVISIT_CLICK_COUNT > 0 THEN 1
                    ELSE 0
                END AS FLAG_ACTCOLD_INFL_TOUCHPOINT_BY_INTERACTIONTYPE_SIXSENSE_WEBVISIT_CLICK,
                CASE
                    WHEN infl_data.MARKETING_TOUCHPOINT_DATE <= amlh_opp.AMLH_COLD_ACCOUNT_DATE_STAMP__C
                    AND infl_data.INTERACTIONTYPE_SIXSENSE_WEBVISIT_SUBMIT_COUNT > 0 THEN 1
                    ELSE 0
                END AS FLAG_ACTCOLD_INFL_TOUCHPOINT_BY_INTERACTIONTYPE_SIXSENSE_WEBVISIT_SUBMIT,
                CASE
                    WHEN infl_data.MARKETING_TOUCHPOINT_DATE <= amlh_opp.AMLH_COLD_ACCOUNT_DATE_STAMP__C
                    AND infl_data.INTERACTIONTYPE_SIXSENSE_WEBVISIT_UNCLASSIFIED_COUNT > 0 THEN 1
                    ELSE 0
                END AS FLAG_ACTCOLD_INFL_TOUCHPOINT_BY_INTERACTIONTYPE_SIXSENSE_WEBVISIT_UNCLASSIFIED,
                CASE
                    WHEN infl_data.MARKETING_TOUCHPOINT_DATE <= amlh_opp.AMLH_COLD_ACCOUNT_DATE_STAMP__C
                    AND infl_data.INTERACTIONTYPE_BIZIBLE_TOUCHPOINT_WEBVISIT_COUNT > 0 THEN 1
                    ELSE 0
                END AS FLAG_ACTCOLD_INFL_TOUCHPOINT_BY_INTERACTIONTYPE_BIZIBLE_TOUCHPOINT_WEBVISIT,
                CASE
                    WHEN infl_data.MARKETING_TOUCHPOINT_DATE <= amlh_opp.AMLH_COLD_ACCOUNT_DATE_STAMP__C
                    AND infl_data.INTERACTIONTYPE_BIZIBLE_TOUCHPOINT_WEBCHAT_COUNT > 0 THEN 1
                    ELSE 0
                END AS FLAG_ACTCOLD_INFL_TOUCHPOINT_BY_INTERACTIONTYPE_BIZIBLE_TOUCHPOINT_WEBCHAT,
                CASE
                    WHEN infl_data.MARKETING_TOUCHPOINT_DATE <= amlh_opp.AMLH_COLD_ACCOUNT_DATE_STAMP__C
                    AND infl_data.INTERACTIONTYPE_BIZIBLE_TOUCHPOINT_WEBFORM_COUNT > 0 THEN 1
                    ELSE 0
                END AS FLAG_ACTCOLD_INFL_TOUCHPOINT_BY_INTERACTIONTYPE_BIZIBLE_TOUCHPOINT_WEBFORM,
                CASE
                    WHEN infl_data.MARKETING_TOUCHPOINT_DATE <= amlh_opp.AMLH_COLD_ACCOUNT_DATE_STAMP__C
                    AND infl_data.INTERACTIONTYPE_BIZIBLE_TOUCHPOINT_CRM_COUNT > 0 THEN 1
                    ELSE 0
                END AS FLAG_ACTCOLD_INFL_TOUCHPOINT_BY_INTERACTIONTYPE_BIZIBLE_TOUCHPOINT_CRM,
                CASE
                    WHEN infl_data.MARKETING_TOUCHPOINT_DATE <= amlh_opp.AMLH_COLD_ACCOUNT_DATE_STAMP__C
                    AND infl_data.INTERACTIONTYPE_BIZIBLE_TOUCHPOINT_CONNECTWITHDM_COUNT > 0 THEN 1
                    ELSE 0
                END AS FLAG_ACTCOLD_INFL_TOUCHPOINT_BY_INTERACTIONTYPE_BIZIBLE_TOUCHPOINT_CONNECTWITHDM,
                CASE
                    WHEN infl_data.MARKETING_TOUCHPOINT_DATE <= amlh_opp.AMLH_COLD_ACCOUNT_DATE_STAMP__C
                    AND infl_data.INTERACTIONTYPE_BIZIBLE_TOUCHPOINT_CALLSPOKEWITH_COUNT > 0 THEN 1
                    ELSE 0
                END AS FLAG_ACTCOLD_INFL_TOUCHPOINT_BY_INTERACTIONTYPE_BIZIBLE_TOUCHPOINT_CALLSPOKEIWTH,
                CASE
                    WHEN infl_data.MARKETING_TOUCHPOINT_DATE <= amlh_opp.AMLH_COLD_ACCOUNT_DATE_STAMP__C
                    AND infl_data.INTERACTIONTYPE_BIZIBLE_TOUCHPOINT_CALLGATEKEEPER_COUNT > 0 THEN 1
                    ELSE 0
                END AS FLAG_ACTCOLD_INFL_TOUCHPOINT_BY_INTERACTIONTYPE_BIZIBLE_TOUCHPOINT_GATEKEEPER,
                CASE
                    WHEN infl_data.MARKETING_TOUCHPOINT_DATE <= amlh_opp.AMLH_COLD_ACCOUNT_DATE_STAMP__C
                    AND infl_data.INTERACTIONTYPE_BIZIBLE_TOUCHPOINT_NOLEADTOUCHPOINTS_COUNT > 0 THEN 1
                    ELSE 0
                END AS FLAG_ACTCOLD_INFL_TOUCHPOINT_BY_INTERACTIONTYPE_BIZIBLE_TOUCHPOINT_NOLEADTOUCHPOINT,
				--20250302
                CASE
                    WHEN infl_data.MARKETING_TOUCHPOINT_DATE <= amlh_opp.AMLH_COLD_ACCOUNT_DATE_STAMP__C
                    AND infl_data.INTERACTIONTYPE_BIZIBLE_TOUCHPOINT_MARKETO_COUNT > 0 THEN 1
                    ELSE 0
                END AS FLAG_ACTCOLD_INFL_TOUCHPOINT_BY_INTERACTIONTYPE_BIZIBLE_TOUCHPOINT_MARKETO,
				--20250314
                CASE
                    WHEN infl_data.MARKETING_TOUCHPOINT_DATE <= amlh_opp.AMLH_COLD_ACCOUNT_DATE_STAMP__C
                    AND infl_data.INTERACTIONTYPE_BIZIBLE_TOUCHPOINT_SEISMICENGAGEMENT_COUNT > 0 THEN 1
                    ELSE 0
                END AS FLAG_ACTCOLD_INFL_TOUCHPOINT_BY_INTERACTIONTYPE_BIZIBLE_TOUCHPOINT_SEISMICENGAGEMENT,
                CASE
                    WHEN infl_data.MARKETING_TOUCHPOINT_DATE <= amlh_opp.AMLH_COLD_ACCOUNT_DATE_STAMP__C
                    AND infl_data.INTERACTIONTYPE_BIZIBLE_TOUCHPOINT_CHANGESTATUS_COUNT > 0 THEN 1
                    ELSE 0
                END AS FLAG_ACTCOLD_INFL_TOUCHPOINT_BY_INTERACTIONTYPE_BIZIBLE_TOUCHPOINT_CHANGESTATUS,
                CASE
                    WHEN infl_data.MARKETING_TOUCHPOINT_DATE <= amlh_opp.AMLH_COLD_ACCOUNT_DATE_STAMP__C
                    AND infl_data.INTERACTIONTYPE_BIZIBLE_TOUCHPOINT_UNCLASSIFIED_COUNT > 0 THEN 1
                    ELSE 0
                END AS FLAG_ACTCOLD_INFL_TOUCHPOINT_BY_INTERACTIONTYPE_BIZIBLE_TOUCHPOINT_UNCLASSIFIED,
                -- Influenced before Act MEA
                CASE
                    WHEN infl_data.MARKETING_TOUCHPOINT_DATE <= amlh_opp.AMLH_MEA_DATE_STAMP__C
                    AND infl_data.INTERACTIONTYPE_SIXSENSE_PAIDMEDIA_IMPRESSIONS_COUNT > 0 THEN 1
                    ELSE 0
                END AS FLAG_ACTMEA_INFL_TOUCHPOINT_BY_INTERACTIONTYPE_SIXSENSE_PAIDMEDIA_IMPRESSION,
                CASE
                    WHEN infl_data.MARKETING_TOUCHPOINT_DATE <= amlh_opp.AMLH_MEA_DATE_STAMP__C
                    AND infl_data.INTERACTIONTYPE_SIXSENSE_PAIDMEDIA_CLICKS_COUNT > 0 THEN 1
                    ELSE 0
                END AS FLAG_ACTMEA_INFL_TOUCHPOINT_BY_INTERACTIONTYPE_SIXSENSE_PAIDMEDIA_CLICK,
                CASE
                    WHEN infl_data.MARKETING_TOUCHPOINT_DATE <= amlh_opp.AMLH_MEA_DATE_STAMP__C
                    AND infl_data.INTERACTIONTYPE_SIXSENSE_WEBVISIT_TOTAL_INTERACTIONS_COUNT > 0 THEN 1
                    ELSE 0
                END AS FLAG_ACTMEA_INFL_TOUCHPOINT_BY_INTERACTIONTYPE_SIXSENSE_WEBVISIT_TOTAL_INTERACTIONS,
                CASE
                    WHEN infl_data.MARKETING_TOUCHPOINT_DATE <= amlh_opp.AMLH_MEA_DATE_STAMP__C
                    AND infl_data.INTERACTIONTYPE_SIXSENSE_WEBVISIT_PAGELOAD_COUNT > 0 THEN 1
                    ELSE 0
                END AS FLAG_ACTMEA_INFL_TOUCHPOINT_BY_INTERACTIONTYPE_SIXSENSE_WEBVISIT_PAGELOAD,
                CASE
                    WHEN infl_data.MARKETING_TOUCHPOINT_DATE <= amlh_opp.AMLH_MEA_DATE_STAMP__C
                    AND infl_data.INTERACTIONTYPE_SIXSENSE_WEBVISIT_PLAY_COUNT > 0 THEN 1
                    ELSE 0
                END AS FLAG_ACTMEA_INFL_TOUCHPOINT_BY_INTERACTIONTYPE_SIXSENSE_WEBVISIT_PLAY,
                CASE
                    WHEN infl_data.MARKETING_TOUCHPOINT_DATE <= amlh_opp.AMLH_MEA_DATE_STAMP__C
                    AND infl_data.INTERACTIONTYPE_SIXSENSE_WEBVISIT_CLICK_COUNT > 0 THEN 1
                    ELSE 0
                END AS FLAG_ACTMEA_INFL_TOUCHPOINT_BY_INTERACTIONTYPE_SIXSENSE_WEBVISIT_CLICK,
                CASE
                    WHEN infl_data.MARKETING_TOUCHPOINT_DATE <= amlh_opp.AMLH_MEA_DATE_STAMP__C
                    AND infl_data.INTERACTIONTYPE_SIXSENSE_WEBVISIT_SUBMIT_COUNT > 0 THEN 1
                    ELSE 0
                END AS FLAG_ACTMEA_INFL_TOUCHPOINT_BY_INTERACTIONTYPE_SIXSENSE_WEBVISIT_SUBMIT,
                CASE
                    WHEN infl_data.MARKETING_TOUCHPOINT_DATE <= amlh_opp.AMLH_MEA_DATE_STAMP__C
                    AND infl_data.INTERACTIONTYPE_SIXSENSE_WEBVISIT_UNCLASSIFIED_COUNT > 0 THEN 1
                    ELSE 0
                END AS FLAG_ACTMEA_INFL_TOUCHPOINT_BY_INTERACTIONTYPE_SIXSENSE_WEBVISIT_UNCLASSIFIED,
                CASE
                    WHEN infl_data.MARKETING_TOUCHPOINT_DATE <= amlh_opp.AMLH_MEA_DATE_STAMP__C
                    AND infl_data.INTERACTIONTYPE_BIZIBLE_TOUCHPOINT_WEBVISIT_COUNT > 0 THEN 1
                    ELSE 0
                END AS FLAG_ACTMEA_INFL_TOUCHPOINT_BY_INTERACTIONTYPE_BIZIBLE_TOUCHPOINT_WEBVISIT,
                CASE
                    WHEN infl_data.MARKETING_TOUCHPOINT_DATE <= amlh_opp.AMLH_MEA_DATE_STAMP__C
                    AND infl_data.INTERACTIONTYPE_BIZIBLE_TOUCHPOINT_WEBCHAT_COUNT > 0 THEN 1
                    ELSE 0
                END AS FLAG_ACTMEA_INFL_TOUCHPOINT_BY_INTERACTIONTYPE_BIZIBLE_TOUCHPOINT_WEBCHAT,
                CASE
                    WHEN infl_data.MARKETING_TOUCHPOINT_DATE <= amlh_opp.AMLH_MEA_DATE_STAMP__C
                    AND infl_data.INTERACTIONTYPE_BIZIBLE_TOUCHPOINT_WEBFORM_COUNT > 0 THEN 1
                    ELSE 0
                END AS FLAG_ACTMEA_INFL_TOUCHPOINT_BY_INTERACTIONTYPE_BIZIBLE_TOUCHPOINT_WEBFORM,
                CASE
                    WHEN infl_data.MARKETING_TOUCHPOINT_DATE <= amlh_opp.AMLH_MEA_DATE_STAMP__C
                    AND infl_data.INTERACTIONTYPE_BIZIBLE_TOUCHPOINT_CRM_COUNT > 0 THEN 1
                    ELSE 0
                END AS FLAG_ACTMEA_INFL_TOUCHPOINT_BY_INTERACTIONTYPE_BIZIBLE_TOUCHPOINT_CRM,
                CASE
                    WHEN infl_data.MARKETING_TOUCHPOINT_DATE <= amlh_opp.AMLH_MEA_DATE_STAMP__C
                    AND infl_data.INTERACTIONTYPE_BIZIBLE_TOUCHPOINT_CONNECTWITHDM_COUNT > 0 THEN 1
                    ELSE 0
                END AS FLAG_ACTMEA_INFL_TOUCHPOINT_BY_INTERACTIONTYPE_BIZIBLE_TOUCHPOINT_CONNECTWITHDM,
                CASE
                    WHEN infl_data.MARKETING_TOUCHPOINT_DATE <= amlh_opp.AMLH_MEA_DATE_STAMP__C
                    AND infl_data.INTERACTIONTYPE_BIZIBLE_TOUCHPOINT_CALLSPOKEWITH_COUNT > 0 THEN 1
                    ELSE 0
                END AS FLAG_ACTMEA_INFL_TOUCHPOINT_BY_INTERACTIONTYPE_BIZIBLE_TOUCHPOINT_CALLSPOKEIWTH,
                CASE
                    WHEN infl_data.MARKETING_TOUCHPOINT_DATE <= amlh_opp.AMLH_MEA_DATE_STAMP__C
                    AND infl_data.INTERACTIONTYPE_BIZIBLE_TOUCHPOINT_CALLGATEKEEPER_COUNT > 0 THEN 1
                    ELSE 0
                END AS FLAG_ACTMEA_INFL_TOUCHPOINT_BY_INTERACTIONTYPE_BIZIBLE_TOUCHPOINT_GATEKEEPER,
                CASE
                    WHEN infl_data.MARKETING_TOUCHPOINT_DATE <= amlh_opp.AMLH_MEA_DATE_STAMP__C
                    AND infl_data.INTERACTIONTYPE_BIZIBLE_TOUCHPOINT_NOLEADTOUCHPOINTS_COUNT > 0 THEN 1
                    ELSE 0
                END AS FLAG_ACTMEA_INFL_TOUCHPOINT_BY_INTERACTIONTYPE_BIZIBLE_TOUCHPOINT_NOLEADTOUCHPOINT,
				--20250302
                CASE
                    WHEN infl_data.MARKETING_TOUCHPOINT_DATE <= amlh_opp.AMLH_MEA_DATE_STAMP__C
                    AND infl_data.INTERACTIONTYPE_BIZIBLE_TOUCHPOINT_MARKETO_COUNT > 0 THEN 1
                    ELSE 0
                END AS FLAG_ACTMEA_INFL_TOUCHPOINT_BY_INTERACTIONTYPE_BIZIBLE_TOUCHPOINT_MARKETO,
				--20250314
                CASE
                    WHEN infl_data.MARKETING_TOUCHPOINT_DATE <= amlh_opp.AMLH_MEA_DATE_STAMP__C
                    AND infl_data.INTERACTIONTYPE_BIZIBLE_TOUCHPOINT_SEISMICENGAGEMENT_COUNT > 0 THEN 1
                    ELSE 0
                END AS FLAG_ACTMEA_INFL_TOUCHPOINT_BY_INTERACTIONTYPE_BIZIBLE_TOUCHPOINT_SEISMICENGAGEMENT,
                CASE
                    WHEN infl_data.MARKETING_TOUCHPOINT_DATE <= amlh_opp.AMLH_MEA_DATE_STAMP__C
                    AND infl_data.INTERACTIONTYPE_BIZIBLE_TOUCHPOINT_CHANGESTATUS_COUNT > 0 THEN 1
                    ELSE 0
                END AS FLAG_ACTMEA_INFL_TOUCHPOINT_BY_INTERACTIONTYPE_BIZIBLE_TOUCHPOINT_CHANGESTATUS,
                CASE
                    WHEN infl_data.MARKETING_TOUCHPOINT_DATE <= amlh_opp.AMLH_MEA_DATE_STAMP__C
                    AND infl_data.INTERACTIONTYPE_BIZIBLE_TOUCHPOINT_UNCLASSIFIED_COUNT > 0 THEN 1
                    ELSE 0
                END AS FLAG_ACTMEA_INFL_TOUCHPOINT_BY_INTERACTIONTYPE_BIZIBLE_TOUCHPOINT_UNCLASSIFIED,
                -- Influenced before Act MQA
                CASE
                    WHEN infl_data.MARKETING_TOUCHPOINT_DATE <= amlh_opp.AMLH_MQA_DATE_STAMP__C
                    AND infl_data.INTERACTIONTYPE_SIXSENSE_PAIDMEDIA_IMPRESSIONS_COUNT > 0 THEN 1
                    ELSE 0
                END AS FLAG_ACTMQA_INFL_TOUCHPOINT_BY_INTERACTIONTYPE_SIXSENSE_PAIDMEDIA_IMPRESSION,
                CASE
                    WHEN infl_data.MARKETING_TOUCHPOINT_DATE <= amlh_opp.AMLH_MQA_DATE_STAMP__C
                    AND infl_data.INTERACTIONTYPE_SIXSENSE_PAIDMEDIA_CLICKS_COUNT > 0 THEN 1
                    ELSE 0
                END AS FLAG_ACTMQA_INFL_TOUCHPOINT_BY_INTERACTIONTYPE_SIXSENSE_PAIDMEDIA_CLICK,
                CASE
                    WHEN infl_data.MARKETING_TOUCHPOINT_DATE <= amlh_opp.AMLH_MQA_DATE_STAMP__C
                    AND infl_data.INTERACTIONTYPE_SIXSENSE_WEBVISIT_TOTAL_INTERACTIONS_COUNT > 0 THEN 1
                    ELSE 0
                END AS FLAG_ACTMQA_INFL_TOUCHPOINT_BY_INTERACTIONTYPE_SIXSENSE_WEBVISIT_TOTAL_INTERACTIONS,
                CASE
                    WHEN infl_data.MARKETING_TOUCHPOINT_DATE <= amlh_opp.AMLH_MQA_DATE_STAMP__C
                    AND infl_data.INTERACTIONTYPE_SIXSENSE_WEBVISIT_PAGELOAD_COUNT > 0 THEN 1
                    ELSE 0
                END AS FLAG_ACTMQA_INFL_TOUCHPOINT_BY_INTERACTIONTYPE_SIXSENSE_WEBVISIT_PAGELOAD,
                CASE
                    WHEN infl_data.MARKETING_TOUCHPOINT_DATE <= amlh_opp.AMLH_MQA_DATE_STAMP__C
                    AND infl_data.INTERACTIONTYPE_SIXSENSE_WEBVISIT_PLAY_COUNT > 0 THEN 1
                    ELSE 0
                END AS FLAG_ACTMQA_INFL_TOUCHPOINT_BY_INTERACTIONTYPE_SIXSENSE_WEBVISIT_PLAY,
                CASE
                    WHEN infl_data.MARKETING_TOUCHPOINT_DATE <= amlh_opp.AMLH_MQA_DATE_STAMP__C
                    AND infl_data.INTERACTIONTYPE_SIXSENSE_WEBVISIT_CLICK_COUNT > 0 THEN 1
                    ELSE 0
                END AS FLAG_ACTMQA_INFL_TOUCHPOINT_BY_INTERACTIONTYPE_SIXSENSE_WEBVISIT_CLICK,
                CASE
                    WHEN infl_data.MARKETING_TOUCHPOINT_DATE <= amlh_opp.AMLH_MQA_DATE_STAMP__C
                    AND infl_data.INTERACTIONTYPE_SIXSENSE_WEBVISIT_SUBMIT_COUNT > 0 THEN 1
                    ELSE 0
                END AS FLAG_ACTMQA_INFL_TOUCHPOINT_BY_INTERACTIONTYPE_SIXSENSE_WEBVISIT_SUBMIT,
                CASE
                    WHEN infl_data.MARKETING_TOUCHPOINT_DATE <= amlh_opp.AMLH_MQA_DATE_STAMP__C
                    AND infl_data.INTERACTIONTYPE_SIXSENSE_WEBVISIT_UNCLASSIFIED_COUNT > 0 THEN 1
                    ELSE 0
                END AS FLAG_ACTMQA_INFL_TOUCHPOINT_BY_INTERACTIONTYPE_SIXSENSE_WEBVISIT_UNCLASSIFIED,
                CASE
                    WHEN infl_data.MARKETING_TOUCHPOINT_DATE <= amlh_opp.AMLH_MQA_DATE_STAMP__C
                    AND infl_data.INTERACTIONTYPE_BIZIBLE_TOUCHPOINT_WEBVISIT_COUNT > 0 THEN 1
                    ELSE 0
                END AS FLAG_ACTMQA_INFL_TOUCHPOINT_BY_INTERACTIONTYPE_BIZIBLE_TOUCHPOINT_WEBVISIT,
                CASE
                    WHEN infl_data.MARKETING_TOUCHPOINT_DATE <= amlh_opp.AMLH_MQA_DATE_STAMP__C
                    AND infl_data.INTERACTIONTYPE_BIZIBLE_TOUCHPOINT_WEBCHAT_COUNT > 0 THEN 1
                    ELSE 0
                END AS FLAG_ACTMQA_INFL_TOUCHPOINT_BY_INTERACTIONTYPE_BIZIBLE_TOUCHPOINT_WEBCHAT,
                CASE
                    WHEN infl_data.MARKETING_TOUCHPOINT_DATE <= amlh_opp.AMLH_MQA_DATE_STAMP__C
                    AND infl_data.INTERACTIONTYPE_BIZIBLE_TOUCHPOINT_WEBFORM_COUNT > 0 THEN 1
                    ELSE 0
                END AS FLAG_ACTMQA_INFL_TOUCHPOINT_BY_INTERACTIONTYPE_BIZIBLE_TOUCHPOINT_WEBFORM,
                CASE
                    WHEN infl_data.MARKETING_TOUCHPOINT_DATE <= amlh_opp.AMLH_MQA_DATE_STAMP__C
                    AND infl_data.INTERACTIONTYPE_BIZIBLE_TOUCHPOINT_CRM_COUNT > 0 THEN 1
                    ELSE 0
                END AS FLAG_ACTMQA_INFL_TOUCHPOINT_BY_INTERACTIONTYPE_BIZIBLE_TOUCHPOINT_CRM,
                CASE
                    WHEN infl_data.MARKETING_TOUCHPOINT_DATE <= amlh_opp.AMLH_MQA_DATE_STAMP__C
                    AND infl_data.INTERACTIONTYPE_BIZIBLE_TOUCHPOINT_CONNECTWITHDM_COUNT > 0 THEN 1
                    ELSE 0
                END AS FLAG_ACTMQA_INFL_TOUCHPOINT_BY_INTERACTIONTYPE_BIZIBLE_TOUCHPOINT_CONNECTWITHDM,
                CASE
                    WHEN infl_data.MARKETING_TOUCHPOINT_DATE <= amlh_opp.AMLH_MQA_DATE_STAMP__C
                    AND infl_data.INTERACTIONTYPE_BIZIBLE_TOUCHPOINT_CALLSPOKEWITH_COUNT > 0 THEN 1
                    ELSE 0
                END AS FLAG_ACTMQA_INFL_TOUCHPOINT_BY_INTERACTIONTYPE_BIZIBLE_TOUCHPOINT_CALLSPOKEIWTH,
                CASE
                    WHEN infl_data.MARKETING_TOUCHPOINT_DATE <= amlh_opp.AMLH_MQA_DATE_STAMP__C
                    AND infl_data.INTERACTIONTYPE_BIZIBLE_TOUCHPOINT_CALLGATEKEEPER_COUNT > 0 THEN 1
                    ELSE 0
                END AS FLAG_ACTMQA_INFL_TOUCHPOINT_BY_INTERACTIONTYPE_BIZIBLE_TOUCHPOINT_GATEKEEPER,
                CASE
                    WHEN infl_data.MARKETING_TOUCHPOINT_DATE <= amlh_opp.AMLH_MQA_DATE_STAMP__C
                    AND infl_data.INTERACTIONTYPE_BIZIBLE_TOUCHPOINT_NOLEADTOUCHPOINTS_COUNT > 0 THEN 1
                    ELSE 0
                END AS FLAG_ACTMQA_INFL_TOUCHPOINT_BY_INTERACTIONTYPE_BIZIBLE_TOUCHPOINT_NOLEADTOUCHPOINT,
				--20250302
                CASE
                    WHEN infl_data.MARKETING_TOUCHPOINT_DATE <= amlh_opp.AMLH_MQA_DATE_STAMP__C
                    AND infl_data.INTERACTIONTYPE_BIZIBLE_TOUCHPOINT_MARKETO_COUNT > 0 THEN 1
                    ELSE 0
                END AS FLAG_ACTMQA_INFL_TOUCHPOINT_BY_INTERACTIONTYPE_BIZIBLE_TOUCHPOINT_MARKETO,
				--20250314
                CASE
                    WHEN infl_data.MARKETING_TOUCHPOINT_DATE <= amlh_opp.AMLH_MQA_DATE_STAMP__C
                    AND infl_data.INTERACTIONTYPE_BIZIBLE_TOUCHPOINT_SEISMICENGAGEMENT_COUNT > 0 THEN 1
                    ELSE 0
                END AS FLAG_ACTMQA_INFL_TOUCHPOINT_BY_INTERACTIONTYPE_BIZIBLE_TOUCHPOINT_SEISMICENGAGEMENT,
                CASE
                    WHEN infl_data.MARKETING_TOUCHPOINT_DATE <= amlh_opp.AMLH_MQA_DATE_STAMP__C
                    AND infl_data.INTERACTIONTYPE_BIZIBLE_TOUCHPOINT_CHANGESTATUS_COUNT > 0 THEN 1
                    ELSE 0
                END AS FLAG_ACTMQA_INFL_TOUCHPOINT_BY_INTERACTIONTYPE_BIZIBLE_TOUCHPOINT_CHANGESTATUS,
                CASE
                    WHEN infl_data.MARKETING_TOUCHPOINT_DATE <= amlh_opp.AMLH_MQA_DATE_STAMP__C
                    AND infl_data.INTERACTIONTYPE_BIZIBLE_TOUCHPOINT_UNCLASSIFIED_COUNT > 0 THEN 1
                    ELSE 0
                END AS FLAG_ACTMQA_INFL_TOUCHPOINT_BY_INTERACTIONTYPE_BIZIBLE_TOUCHPOINT_UNCLASSIFIED,
                -- Influenced before Act Suspect
                CASE
                    WHEN infl_data.MARKETING_TOUCHPOINT_DATE <= amlh_opp.AMLH_SUSPECT_DATE_STAMP__C
                    AND infl_data.INTERACTIONTYPE_SIXSENSE_PAIDMEDIA_IMPRESSIONS_COUNT > 0 THEN 1
                    ELSE 0
                END AS FLAG_ACTSUSPECT_INFL_TOUCHPOINT_BY_INTERACTIONTYPE_SIXSENSE_PAIDMEDIA_IMPRESSION,
                CASE
                    WHEN infl_data.MARKETING_TOUCHPOINT_DATE <= amlh_opp.AMLH_SUSPECT_DATE_STAMP__C
                    AND infl_data.INTERACTIONTYPE_SIXSENSE_PAIDMEDIA_CLICKS_COUNT > 0 THEN 1
                    ELSE 0
                END AS FLAG_ACTSUSPECT_INFL_TOUCHPOINT_BY_INTERACTIONTYPE_SIXSENSE_PAIDMEDIA_CLICK,
                CASE
                    WHEN infl_data.MARKETING_TOUCHPOINT_DATE <= amlh_opp.AMLH_SUSPECT_DATE_STAMP__C
                    AND infl_data.INTERACTIONTYPE_SIXSENSE_WEBVISIT_TOTAL_INTERACTIONS_COUNT > 0 THEN 1
                    ELSE 0
                END AS FLAG_ACTSUSPECT_INFL_TOUCHPOINT_BY_INTERACTIONTYPE_SIXSENSE_WEBVISIT_TOTAL_INTERACTIONS,
                CASE
                    WHEN infl_data.MARKETING_TOUCHPOINT_DATE <= amlh_opp.AMLH_SUSPECT_DATE_STAMP__C
                    AND infl_data.INTERACTIONTYPE_SIXSENSE_WEBVISIT_PAGELOAD_COUNT > 0 THEN 1
                    ELSE 0
                END AS FLAG_ACTSUSPECT_INFL_TOUCHPOINT_BY_INTERACTIONTYPE_SIXSENSE_WEBVISIT_PAGELOAD,
                CASE
                    WHEN infl_data.MARKETING_TOUCHPOINT_DATE <= amlh_opp.AMLH_SUSPECT_DATE_STAMP__C
                    AND infl_data.INTERACTIONTYPE_SIXSENSE_WEBVISIT_PLAY_COUNT > 0 THEN 1
                    ELSE 0
                END AS FLAG_ACTSUSPECT_INFL_TOUCHPOINT_BY_INTERACTIONTYPE_SIXSENSE_WEBVISIT_PLAY,
                CASE
                    WHEN infl_data.MARKETING_TOUCHPOINT_DATE <= amlh_opp.AMLH_SUSPECT_DATE_STAMP__C
                    AND infl_data.INTERACTIONTYPE_SIXSENSE_WEBVISIT_CLICK_COUNT > 0 THEN 1
                    ELSE 0
                END AS FLAG_ACTSUSPECT_INFL_TOUCHPOINT_BY_INTERACTIONTYPE_SIXSENSE_WEBVISIT_CLICK,
                CASE
                    WHEN infl_data.MARKETING_TOUCHPOINT_DATE <= amlh_opp.AMLH_SUSPECT_DATE_STAMP__C
                    AND infl_data.INTERACTIONTYPE_SIXSENSE_WEBVISIT_SUBMIT_COUNT > 0 THEN 1
                    ELSE 0
                END AS FLAG_ACTSUSPECT_INFL_TOUCHPOINT_BY_INTERACTIONTYPE_SIXSENSE_WEBVISIT_SUBMIT,
                CASE
                    WHEN infl_data.MARKETING_TOUCHPOINT_DATE <= amlh_opp.AMLH_SUSPECT_DATE_STAMP__C
                    AND infl_data.INTERACTIONTYPE_SIXSENSE_WEBVISIT_UNCLASSIFIED_COUNT > 0 THEN 1
                    ELSE 0
                END AS FLAG_ACTSUSPECT_INFL_TOUCHPOINT_BY_INTERACTIONTYPE_SIXSENSE_WEBVISIT_UNCLASSIFIED,
                CASE
                    WHEN infl_data.MARKETING_TOUCHPOINT_DATE <= amlh_opp.AMLH_SUSPECT_DATE_STAMP__C
                    AND infl_data.INTERACTIONTYPE_BIZIBLE_TOUCHPOINT_WEBVISIT_COUNT > 0 THEN 1
                    ELSE 0
                END AS FLAG_ACTSUSPECT_INFL_TOUCHPOINT_BY_INTERACTIONTYPE_BIZIBLE_TOUCHPOINT_WEBVISIT,
                CASE
                    WHEN infl_data.MARKETING_TOUCHPOINT_DATE <= amlh_opp.AMLH_SUSPECT_DATE_STAMP__C
                    AND infl_data.INTERACTIONTYPE_BIZIBLE_TOUCHPOINT_WEBCHAT_COUNT > 0 THEN 1
                    ELSE 0
                END AS FLAG_ACTSUSPECT_INFL_TOUCHPOINT_BY_INTERACTIONTYPE_BIZIBLE_TOUCHPOINT_WEBCHAT,
                CASE
                    WHEN infl_data.MARKETING_TOUCHPOINT_DATE <= amlh_opp.AMLH_SUSPECT_DATE_STAMP__C
                    AND infl_data.INTERACTIONTYPE_BIZIBLE_TOUCHPOINT_WEBFORM_COUNT > 0 THEN 1
                    ELSE 0
                END AS FLAG_ACTSUSPECT_INFL_TOUCHPOINT_BY_INTERACTIONTYPE_BIZIBLE_TOUCHPOINT_WEBFORM,
                CASE
                    WHEN infl_data.MARKETING_TOUCHPOINT_DATE <= amlh_opp.AMLH_SUSPECT_DATE_STAMP__C
                    AND infl_data.INTERACTIONTYPE_BIZIBLE_TOUCHPOINT_CRM_COUNT > 0 THEN 1
                    ELSE 0
                END AS FLAG_ACTSUSPECT_INFL_TOUCHPOINT_BY_INTERACTIONTYPE_BIZIBLE_TOUCHPOINT_CRM,
                CASE
                    WHEN infl_data.MARKETING_TOUCHPOINT_DATE <= amlh_opp.AMLH_SUSPECT_DATE_STAMP__C
                    AND infl_data.INTERACTIONTYPE_BIZIBLE_TOUCHPOINT_CONNECTWITHDM_COUNT > 0 THEN 1
                    ELSE 0
                END AS FLAG_ACTSUSPECT_INFL_TOUCHPOINT_BY_INTERACTIONTYPE_BIZIBLE_TOUCHPOINT_CONNECTWITHDM,
                CASE
                    WHEN infl_data.MARKETING_TOUCHPOINT_DATE <= amlh_opp.AMLH_SUSPECT_DATE_STAMP__C
                    AND infl_data.INTERACTIONTYPE_BIZIBLE_TOUCHPOINT_CALLSPOKEWITH_COUNT > 0 THEN 1
                    ELSE 0
                END AS FLAG_ACTSUSPECT_INFL_TOUCHPOINT_BY_INTERACTIONTYPE_BIZIBLE_TOUCHPOINT_CALLSPOKEIWTH,
                CASE
                    WHEN infl_data.MARKETING_TOUCHPOINT_DATE <= amlh_opp.AMLH_SUSPECT_DATE_STAMP__C
                    AND infl_data.INTERACTIONTYPE_BIZIBLE_TOUCHPOINT_CALLGATEKEEPER_COUNT > 0 THEN 1
                    ELSE 0
                END AS FLAG_ACTSUSPECT_INFL_TOUCHPOINT_BY_INTERACTIONTYPE_BIZIBLE_TOUCHPOINT_GATEKEEPER,
                CASE
                    WHEN infl_data.MARKETING_TOUCHPOINT_DATE <= amlh_opp.AMLH_SUSPECT_DATE_STAMP__C
                    AND infl_data.INTERACTIONTYPE_BIZIBLE_TOUCHPOINT_NOLEADTOUCHPOINTS_COUNT > 0 THEN 1
                    ELSE 0
                END AS FLAG_ACTSUSPECT_INFL_TOUCHPOINT_BY_INTERACTIONTYPE_BIZIBLE_TOUCHPOINT_NOLEADTOUCHPOINT,
				--20250302
                CASE
                    WHEN infl_data.MARKETING_TOUCHPOINT_DATE <= amlh_opp.AMLH_SUSPECT_DATE_STAMP__C
                    AND infl_data.INTERACTIONTYPE_BIZIBLE_TOUCHPOINT_MARKETO_COUNT > 0 THEN 1
                    ELSE 0
                END AS FLAG_ACTSUSPECT_INFL_TOUCHPOINT_BY_INTERACTIONTYPE_BIZIBLE_TOUCHPOINT_MARKETO,
				--20250314
                CASE
                    WHEN infl_data.MARKETING_TOUCHPOINT_DATE <= amlh_opp.AMLH_SUSPECT_DATE_STAMP__C
                    AND infl_data.INTERACTIONTYPE_BIZIBLE_TOUCHPOINT_SEISMICENGAGEMENT_COUNT > 0 THEN 1
                    ELSE 0
                END AS FLAG_ACTSUSPECT_INFL_TOUCHPOINT_BY_INTERACTIONTYPE_BIZIBLE_TOUCHPOINT_SEISMICENGAGEMENT,
                CASE
                    WHEN infl_data.MARKETING_TOUCHPOINT_DATE <= amlh_opp.AMLH_SUSPECT_DATE_STAMP__C
                    AND infl_data.INTERACTIONTYPE_BIZIBLE_TOUCHPOINT_CHANGESTATUS_COUNT > 0 THEN 1
                    ELSE 0
                END AS FLAG_ACTSUSPECT_INFL_TOUCHPOINT_BY_INTERACTIONTYPE_BIZIBLE_TOUCHPOINT_CHANGESTATUS,
                CASE
                    WHEN infl_data.MARKETING_TOUCHPOINT_DATE <= amlh_opp.AMLH_SUSPECT_DATE_STAMP__C
                    AND infl_data.INTERACTIONTYPE_BIZIBLE_TOUCHPOINT_UNCLASSIFIED_COUNT > 0 THEN 1
                    ELSE 0
                END AS FLAG_ACTSUSPECT_INFL_TOUCHPOINT_BY_INTERACTIONTYPE_BIZIBLE_TOUCHPOINT_UNCLASSIFIED,
                -- Influenced before Act Prospect
                CASE
                    WHEN infl_data.MARKETING_TOUCHPOINT_DATE <= amlh_opp.AMLH_PROSPECT_DATE_STAMP__C
                    AND infl_data.INTERACTIONTYPE_SIXSENSE_PAIDMEDIA_IMPRESSIONS_COUNT > 0 THEN 1
                    ELSE 0
                END AS FLAG_ACTPROSPECT_INFL_TOUCHPOINT_BY_INTERACTIONTYPE_SIXSENSE_PAIDMEDIA_IMPRESSION,
                CASE
                    WHEN infl_data.MARKETING_TOUCHPOINT_DATE <= amlh_opp.AMLH_PROSPECT_DATE_STAMP__C
                    AND infl_data.INTERACTIONTYPE_SIXSENSE_PAIDMEDIA_CLICKS_COUNT > 0 THEN 1
                    ELSE 0
                END AS FLAG_ACTPROSPECT_INFL_TOUCHPOINT_BY_INTERACTIONTYPE_SIXSENSE_PAIDMEDIA_CLICK,
                CASE
                    WHEN infl_data.MARKETING_TOUCHPOINT_DATE <= amlh_opp.AMLH_PROSPECT_DATE_STAMP__C
                    AND infl_data.INTERACTIONTYPE_SIXSENSE_WEBVISIT_TOTAL_INTERACTIONS_COUNT > 0 THEN 1
                    ELSE 0
                END AS FLAG_ACTPROSPECT_INFL_TOUCHPOINT_BY_INTERACTIONTYPE_SIXSENSE_WEBVISIT_TOTAL_INTERACTIONS,
                CASE
                    WHEN infl_data.MARKETING_TOUCHPOINT_DATE <= amlh_opp.AMLH_PROSPECT_DATE_STAMP__C
                    AND infl_data.INTERACTIONTYPE_SIXSENSE_WEBVISIT_PAGELOAD_COUNT > 0 THEN 1
                    ELSE 0
                END AS FLAG_ACTPROSPECT_INFL_TOUCHPOINT_BY_INTERACTIONTYPE_SIXSENSE_WEBVISIT_PAGELOAD,
                CASE
                    WHEN infl_data.MARKETING_TOUCHPOINT_DATE <= amlh_opp.AMLH_PROSPECT_DATE_STAMP__C
                    AND infl_data.INTERACTIONTYPE_SIXSENSE_WEBVISIT_PLAY_COUNT > 0 THEN 1
                    ELSE 0
                END AS FLAG_ACTPROSPECT_INFL_TOUCHPOINT_BY_INTERACTIONTYPE_SIXSENSE_WEBVISIT_PLAY,
                CASE
                    WHEN infl_data.MARKETING_TOUCHPOINT_DATE <= amlh_opp.AMLH_PROSPECT_DATE_STAMP__C
                    AND infl_data.INTERACTIONTYPE_SIXSENSE_WEBVISIT_CLICK_COUNT > 0 THEN 1
                    ELSE 0
                END AS FLAG_ACTPROSPECT_INFL_TOUCHPOINT_BY_INTERACTIONTYPE_SIXSENSE_WEBVISIT_CLICK,
                CASE
                    WHEN infl_data.MARKETING_TOUCHPOINT_DATE <= amlh_opp.AMLH_PROSPECT_DATE_STAMP__C
                    AND infl_data.INTERACTIONTYPE_SIXSENSE_WEBVISIT_SUBMIT_COUNT > 0 THEN 1
                    ELSE 0
                END AS FLAG_ACTPROSPECT_INFL_TOUCHPOINT_BY_INTERACTIONTYPE_SIXSENSE_WEBVISIT_SUBMIT,
                CASE
                    WHEN infl_data.MARKETING_TOUCHPOINT_DATE <= amlh_opp.AMLH_PROSPECT_DATE_STAMP__C
                    AND infl_data.INTERACTIONTYPE_SIXSENSE_WEBVISIT_UNCLASSIFIED_COUNT > 0 THEN 1
                    ELSE 0
                END AS FLAG_ACTPROSPECT_INFL_TOUCHPOINT_BY_INTERACTIONTYPE_SIXSENSE_WEBVISIT_UNCLASSIFIED,
                CASE
                    WHEN infl_data.MARKETING_TOUCHPOINT_DATE <= amlh_opp.AMLH_PROSPECT_DATE_STAMP__C
                    AND infl_data.INTERACTIONTYPE_BIZIBLE_TOUCHPOINT_WEBVISIT_COUNT > 0 THEN 1
                    ELSE 0
                END AS FLAG_ACTPROSPECT_INFL_TOUCHPOINT_BY_INTERACTIONTYPE_BIZIBLE_TOUCHPOINT_WEBVISIT,
                CASE
                    WHEN infl_data.MARKETING_TOUCHPOINT_DATE <= amlh_opp.AMLH_PROSPECT_DATE_STAMP__C
                    AND infl_data.INTERACTIONTYPE_BIZIBLE_TOUCHPOINT_WEBCHAT_COUNT > 0 THEN 1
                    ELSE 0
                END AS FLAG_ACTPROSPECT_INFL_TOUCHPOINT_BY_INTERACTIONTYPE_BIZIBLE_TOUCHPOINT_WEBCHAT,
                CASE
                    WHEN infl_data.MARKETING_TOUCHPOINT_DATE <= amlh_opp.AMLH_PROSPECT_DATE_STAMP__C
                    AND infl_data.INTERACTIONTYPE_BIZIBLE_TOUCHPOINT_WEBFORM_COUNT > 0 THEN 1
                    ELSE 0
                END AS FLAG_ACTPROSPECT_INFL_TOUCHPOINT_BY_INTERACTIONTYPE_BIZIBLE_TOUCHPOINT_WEBFORM,
                CASE
                    WHEN infl_data.MARKETING_TOUCHPOINT_DATE <= amlh_opp.AMLH_PROSPECT_DATE_STAMP__C
                    AND infl_data.INTERACTIONTYPE_BIZIBLE_TOUCHPOINT_CRM_COUNT > 0 THEN 1
                    ELSE 0
                END AS FLAG_ACTPROSPECT_INFL_TOUCHPOINT_BY_INTERACTIONTYPE_BIZIBLE_TOUCHPOINT_CRM,
                CASE
                    WHEN infl_data.MARKETING_TOUCHPOINT_DATE <= amlh_opp.AMLH_PROSPECT_DATE_STAMP__C
                    AND infl_data.INTERACTIONTYPE_BIZIBLE_TOUCHPOINT_CONNECTWITHDM_COUNT > 0 THEN 1
                    ELSE 0
                END AS FLAG_ACTPROSPECT_INFL_TOUCHPOINT_BY_INTERACTIONTYPE_BIZIBLE_TOUCHPOINT_CONNECTWITHDM,
                CASE
                    WHEN infl_data.MARKETING_TOUCHPOINT_DATE <= amlh_opp.AMLH_PROSPECT_DATE_STAMP__C
                    AND infl_data.INTERACTIONTYPE_BIZIBLE_TOUCHPOINT_CALLSPOKEWITH_COUNT > 0 THEN 1
                    ELSE 0
                END AS FLAG_ACTPROSPECT_INFL_TOUCHPOINT_BY_INTERACTIONTYPE_BIZIBLE_TOUCHPOINT_CALLSPOKEIWTH,
                CASE
                    WHEN infl_data.MARKETING_TOUCHPOINT_DATE <= amlh_opp.AMLH_PROSPECT_DATE_STAMP__C
                    AND infl_data.INTERACTIONTYPE_BIZIBLE_TOUCHPOINT_CALLGATEKEEPER_COUNT > 0 THEN 1
                    ELSE 0
                END AS FLAG_ACTPROSPECT_INFL_TOUCHPOINT_BY_INTERACTIONTYPE_BIZIBLE_TOUCHPOINT_GATEKEEPER,
                CASE
                    WHEN infl_data.MARKETING_TOUCHPOINT_DATE <= amlh_opp.AMLH_PROSPECT_DATE_STAMP__C
                    AND infl_data.INTERACTIONTYPE_BIZIBLE_TOUCHPOINT_NOLEADTOUCHPOINTS_COUNT > 0 THEN 1
                    ELSE 0
                END AS FLAG_ACTPROSPECT_INFL_TOUCHPOINT_BY_INTERACTIONTYPE_BIZIBLE_TOUCHPOINT_NOLEADTOUCHPOINT,
				--20250302
                CASE
                    WHEN infl_data.MARKETING_TOUCHPOINT_DATE <= amlh_opp.AMLH_PROSPECT_DATE_STAMP__C
                    AND infl_data.INTERACTIONTYPE_BIZIBLE_TOUCHPOINT_MARKETO_COUNT > 0 THEN 1
                    ELSE 0
                END AS FLAG_ACTPROSPECT_INFL_TOUCHPOINT_BY_INTERACTIONTYPE_BIZIBLE_TOUCHPOINT_MARKETO,
				--20250314
                CASE
                    WHEN infl_data.MARKETING_TOUCHPOINT_DATE <= amlh_opp.AMLH_PROSPECT_DATE_STAMP__C
                    AND infl_data.INTERACTIONTYPE_BIZIBLE_TOUCHPOINT_SEISMICENGAGEMENT_COUNT > 0 THEN 1
                    ELSE 0
                END AS FLAG_ACTPROSPECT_INFL_TOUCHPOINT_BY_INTERACTIONTYPE_BIZIBLE_TOUCHPOINT_SEISMICENGAGEMENT,
                CASE
                    WHEN infl_data.MARKETING_TOUCHPOINT_DATE <= amlh_opp.AMLH_PROSPECT_DATE_STAMP__C
                    AND infl_data.INTERACTIONTYPE_BIZIBLE_TOUCHPOINT_CHANGESTATUS_COUNT > 0 THEN 1
                    ELSE 0
                END AS FLAG_ACTPROSPECT_INFL_TOUCHPOINT_BY_INTERACTIONTYPE_BIZIBLE_TOUCHPOINT_CHANGESTATUS,
                CASE
                    WHEN infl_data.MARKETING_TOUCHPOINT_DATE <= amlh_opp.AMLH_PROSPECT_DATE_STAMP__C
                    AND infl_data.INTERACTIONTYPE_BIZIBLE_TOUCHPOINT_UNCLASSIFIED_COUNT > 0 THEN 1
                    ELSE 0
                END AS FLAG_ACTPROSPECT_INFL_TOUCHPOINT_BY_INTERACTIONTYPE_BIZIBLE_TOUCHPOINT_UNCLASSIFIED,
				--20250314
                -- Influenced before Act Customer
                CASE
                    WHEN infl_data.MARKETING_TOUCHPOINT_DATE <= amlh_opp.AMLH_CUSTOMER_DATE_STAMP__C
                    AND infl_data.INTERACTIONTYPE_SIXSENSE_PAIDMEDIA_IMPRESSIONS_COUNT > 0 THEN 1
                    ELSE 0
                END AS FLAG_ACTCUSTOMER_INFL_TOUCHPOINT_BY_INTERACTIONTYPE_SIXSENSE_PAIDMEDIA_IMPRESSION,
                CASE
                    WHEN infl_data.MARKETING_TOUCHPOINT_DATE <= amlh_opp.AMLH_CUSTOMER_DATE_STAMP__C
                    AND infl_data.INTERACTIONTYPE_SIXSENSE_PAIDMEDIA_CLICKS_COUNT > 0 THEN 1
                    ELSE 0
                END AS FLAG_ACTCUSTOMER_INFL_TOUCHPOINT_BY_INTERACTIONTYPE_SIXSENSE_PAIDMEDIA_CLICK,
                CASE
                    WHEN infl_data.MARKETING_TOUCHPOINT_DATE <= amlh_opp.AMLH_CUSTOMER_DATE_STAMP__C
                    AND infl_data.INTERACTIONTYPE_SIXSENSE_WEBVISIT_TOTAL_INTERACTIONS_COUNT > 0 THEN 1
                    ELSE 0
                END AS FLAG_ACTCUSTOMER_INFL_TOUCHPOINT_BY_INTERACTIONTYPE_SIXSENSE_WEBVISIT_TOTAL_INTERACTIONS,
                CASE
                    WHEN infl_data.MARKETING_TOUCHPOINT_DATE <= amlh_opp.AMLH_CUSTOMER_DATE_STAMP__C
                    AND infl_data.INTERACTIONTYPE_SIXSENSE_WEBVISIT_PAGELOAD_COUNT > 0 THEN 1
                    ELSE 0
                END AS FLAG_ACTCUSTOMER_INFL_TOUCHPOINT_BY_INTERACTIONTYPE_SIXSENSE_WEBVISIT_PAGELOAD,
                CASE
                    WHEN infl_data.MARKETING_TOUCHPOINT_DATE <= amlh_opp.AMLH_CUSTOMER_DATE_STAMP__C
                    AND infl_data.INTERACTIONTYPE_SIXSENSE_WEBVISIT_PLAY_COUNT > 0 THEN 1
                    ELSE 0
                END AS FLAG_ACTCUSTOMER_INFL_TOUCHPOINT_BY_INTERACTIONTYPE_SIXSENSE_WEBVISIT_PLAY,
                CASE
                    WHEN infl_data.MARKETING_TOUCHPOINT_DATE <= amlh_opp.AMLH_CUSTOMER_DATE_STAMP__C
                    AND infl_data.INTERACTIONTYPE_SIXSENSE_WEBVISIT_CLICK_COUNT > 0 THEN 1
                    ELSE 0
                END AS FLAG_ACTCUSTOMER_INFL_TOUCHPOINT_BY_INTERACTIONTYPE_SIXSENSE_WEBVISIT_CLICK,
                CASE
                    WHEN infl_data.MARKETING_TOUCHPOINT_DATE <= amlh_opp.AMLH_CUSTOMER_DATE_STAMP__C
                    AND infl_data.INTERACTIONTYPE_SIXSENSE_WEBVISIT_SUBMIT_COUNT > 0 THEN 1
                    ELSE 0
                END AS FLAG_ACTCUSTOMER_INFL_TOUCHPOINT_BY_INTERACTIONTYPE_SIXSENSE_WEBVISIT_SUBMIT,
                CASE
                    WHEN infl_data.MARKETING_TOUCHPOINT_DATE <= amlh_opp.AMLH_CUSTOMER_DATE_STAMP__C
                    AND infl_data.INTERACTIONTYPE_SIXSENSE_WEBVISIT_UNCLASSIFIED_COUNT > 0 THEN 1
                    ELSE 0
                END AS FLAG_ACTCUSTOMER_INFL_TOUCHPOINT_BY_INTERACTIONTYPE_SIXSENSE_WEBVISIT_UNCLASSIFIED,
                CASE
                    WHEN infl_data.MARKETING_TOUCHPOINT_DATE <= amlh_opp.AMLH_CUSTOMER_DATE_STAMP__C
                    AND infl_data.INTERACTIONTYPE_BIZIBLE_TOUCHPOINT_WEBVISIT_COUNT > 0 THEN 1
                    ELSE 0
                END AS FLAG_ACTCUSTOMER_INFL_TOUCHPOINT_BY_INTERACTIONTYPE_BIZIBLE_TOUCHPOINT_WEBVISIT,
                CASE
                    WHEN infl_data.MARKETING_TOUCHPOINT_DATE <= amlh_opp.AMLH_CUSTOMER_DATE_STAMP__C
                    AND infl_data.INTERACTIONTYPE_BIZIBLE_TOUCHPOINT_WEBCHAT_COUNT > 0 THEN 1
                    ELSE 0
                END AS FLAG_ACTCUSTOMER_INFL_TOUCHPOINT_BY_INTERACTIONTYPE_BIZIBLE_TOUCHPOINT_WEBCHAT,
                CASE
                    WHEN infl_data.MARKETING_TOUCHPOINT_DATE <= amlh_opp.AMLH_CUSTOMER_DATE_STAMP__C
                    AND infl_data.INTERACTIONTYPE_BIZIBLE_TOUCHPOINT_WEBFORM_COUNT > 0 THEN 1
                    ELSE 0
                END AS FLAG_ACTCUSTOMER_INFL_TOUCHPOINT_BY_INTERACTIONTYPE_BIZIBLE_TOUCHPOINT_WEBFORM,
                CASE
                    WHEN infl_data.MARKETING_TOUCHPOINT_DATE <= amlh_opp.AMLH_CUSTOMER_DATE_STAMP__C
                    AND infl_data.INTERACTIONTYPE_BIZIBLE_TOUCHPOINT_CRM_COUNT > 0 THEN 1
                    ELSE 0
                END AS FLAG_ACTCUSTOMER_INFL_TOUCHPOINT_BY_INTERACTIONTYPE_BIZIBLE_TOUCHPOINT_CRM,
                CASE
                    WHEN infl_data.MARKETING_TOUCHPOINT_DATE <= amlh_opp.AMLH_CUSTOMER_DATE_STAMP__C
                    AND infl_data.INTERACTIONTYPE_BIZIBLE_TOUCHPOINT_CONNECTWITHDM_COUNT > 0 THEN 1
                    ELSE 0
                END AS FLAG_ACTCUSTOMER_INFL_TOUCHPOINT_BY_INTERACTIONTYPE_BIZIBLE_TOUCHPOINT_CONNECTWITHDM,
                CASE
                    WHEN infl_data.MARKETING_TOUCHPOINT_DATE <= amlh_opp.AMLH_CUSTOMER_DATE_STAMP__C
                    AND infl_data.INTERACTIONTYPE_BIZIBLE_TOUCHPOINT_CALLSPOKEWITH_COUNT > 0 THEN 1
                    ELSE 0
                END AS FLAG_ACTCUSTOMER_INFL_TOUCHPOINT_BY_INTERACTIONTYPE_BIZIBLE_TOUCHPOINT_CALLSPOKEIWTH,
                CASE
                    WHEN infl_data.MARKETING_TOUCHPOINT_DATE <= amlh_opp.AMLH_CUSTOMER_DATE_STAMP__C
                    AND infl_data.INTERACTIONTYPE_BIZIBLE_TOUCHPOINT_CALLGATEKEEPER_COUNT > 0 THEN 1
                    ELSE 0
                END AS FLAG_ACTCUSTOMER_INFL_TOUCHPOINT_BY_INTERACTIONTYPE_BIZIBLE_TOUCHPOINT_GATEKEEPER,
                CASE
                    WHEN infl_data.MARKETING_TOUCHPOINT_DATE <= amlh_opp.AMLH_CUSTOMER_DATE_STAMP__C
                    AND infl_data.INTERACTIONTYPE_BIZIBLE_TOUCHPOINT_NOLEADTOUCHPOINTS_COUNT > 0 THEN 1
                    ELSE 0
                END AS FLAG_ACTCUSTOMER_INFL_TOUCHPOINT_BY_INTERACTIONTYPE_BIZIBLE_TOUCHPOINT_NOLEADTOUCHPOINT,
				CASE
                    WHEN infl_data.MARKETING_TOUCHPOINT_DATE <= amlh_opp.AMLH_CUSTOMER_DATE_STAMP__C
                    AND infl_data.INTERACTIONTYPE_BIZIBLE_TOUCHPOINT_MARKETO_COUNT > 0 THEN 1
                    ELSE 0
                END AS FLAG_ACTCUSTOMER_INFL_TOUCHPOINT_BY_INTERACTIONTYPE_BIZIBLE_TOUCHPOINT_MARKETO,
				CASE
                    WHEN infl_data.MARKETING_TOUCHPOINT_DATE <= amlh_opp.AMLH_CUSTOMER_DATE_STAMP__C
                    AND infl_data.INTERACTIONTYPE_BIZIBLE_TOUCHPOINT_SEISMICENGAGEMENT_COUNT > 0 THEN 1
                    ELSE 0
                END AS FLAG_ACTCUSTOMER_INFL_TOUCHPOINT_BY_INTERACTIONTYPE_BIZIBLE_TOUCHPOINT_SEISMICENGAGEMENT,
				CASE
                    WHEN infl_data.MARKETING_TOUCHPOINT_DATE <= amlh_opp.AMLH_CUSTOMER_DATE_STAMP__C
                    AND infl_data.INTERACTIONTYPE_BIZIBLE_TOUCHPOINT_CHANGESTATUS_COUNT > 0 THEN 1
                    ELSE 0
                END AS FLAG_ACTCUSTOMER_INFL_TOUCHPOINT_BY_INTERACTIONTYPE_BIZIBLE_TOUCHPOINT_CHANGESTATUS,
                CASE
                    WHEN infl_data.MARKETING_TOUCHPOINT_DATE <= amlh_opp.AMLH_CUSTOMER_DATE_STAMP__C
                    AND infl_data.INTERACTIONTYPE_BIZIBLE_TOUCHPOINT_UNCLASSIFIED_COUNT > 0 THEN 1
                    ELSE 0
                END AS FLAG_ACTCUSTOMER_INFL_TOUCHPOINT_BY_INTERACTIONTYPE_BIZIBLE_TOUCHPOINT_UNCLASSIFIED,
				--20250314
                -- Influenced before Act Effective
                CASE
                    WHEN infl_data.MARKETING_TOUCHPOINT_DATE <= amlh_opp.AMLH_EFFECTIVE_DATE_STAMP__C
                    AND infl_data.INTERACTIONTYPE_SIXSENSE_PAIDMEDIA_IMPRESSIONS_COUNT > 0 THEN 1
                    ELSE 0
                END AS FLAG_ACTEFFECTIVE_INFL_TOUCHPOINT_BY_INTERACTIONTYPE_SIXSENSE_PAIDMEDIA_IMPRESSION,
                CASE
                    WHEN infl_data.MARKETING_TOUCHPOINT_DATE <= amlh_opp.AMLH_EFFECTIVE_DATE_STAMP__C
                    AND infl_data.INTERACTIONTYPE_SIXSENSE_PAIDMEDIA_CLICKS_COUNT > 0 THEN 1
                    ELSE 0
                END AS FLAG_ACTEFFECTIVE_INFL_TOUCHPOINT_BY_INTERACTIONTYPE_SIXSENSE_PAIDMEDIA_CLICK,
                CASE
                    WHEN infl_data.MARKETING_TOUCHPOINT_DATE <= amlh_opp.AMLH_EFFECTIVE_DATE_STAMP__C
                    AND infl_data.INTERACTIONTYPE_SIXSENSE_WEBVISIT_TOTAL_INTERACTIONS_COUNT > 0 THEN 1
                    ELSE 0
                END AS FLAG_ACTEFFECTIVE_INFL_TOUCHPOINT_BY_INTERACTIONTYPE_SIXSENSE_WEBVISIT_TOTAL_INTERACTIONS,
                CASE
                    WHEN infl_data.MARKETING_TOUCHPOINT_DATE <= amlh_opp.AMLH_EFFECTIVE_DATE_STAMP__C
                    AND infl_data.INTERACTIONTYPE_SIXSENSE_WEBVISIT_PAGELOAD_COUNT > 0 THEN 1
                    ELSE 0
                END AS FLAG_ACTEFFECTIVE_INFL_TOUCHPOINT_BY_INTERACTIONTYPE_SIXSENSE_WEBVISIT_PAGELOAD,
                CASE
                    WHEN infl_data.MARKETING_TOUCHPOINT_DATE <= amlh_opp.AMLH_EFFECTIVE_DATE_STAMP__C
                    AND infl_data.INTERACTIONTYPE_SIXSENSE_WEBVISIT_PLAY_COUNT > 0 THEN 1
                    ELSE 0
                END AS FLAG_ACTEFFECTIVE_INFL_TOUCHPOINT_BY_INTERACTIONTYPE_SIXSENSE_WEBVISIT_PLAY,
                CASE
                    WHEN infl_data.MARKETING_TOUCHPOINT_DATE <= amlh_opp.AMLH_EFFECTIVE_DATE_STAMP__C
                    AND infl_data.INTERACTIONTYPE_SIXSENSE_WEBVISIT_CLICK_COUNT > 0 THEN 1
                    ELSE 0
                END AS FLAG_ACTEFFECTIVE_INFL_TOUCHPOINT_BY_INTERACTIONTYPE_SIXSENSE_WEBVISIT_CLICK,
                CASE
                    WHEN infl_data.MARKETING_TOUCHPOINT_DATE <= amlh_opp.AMLH_EFFECTIVE_DATE_STAMP__C
                    AND infl_data.INTERACTIONTYPE_SIXSENSE_WEBVISIT_SUBMIT_COUNT > 0 THEN 1
                    ELSE 0
                END AS FLAG_ACTEFFECTIVE_INFL_TOUCHPOINT_BY_INTERACTIONTYPE_SIXSENSE_WEBVISIT_SUBMIT,
                CASE
                    WHEN infl_data.MARKETING_TOUCHPOINT_DATE <= amlh_opp.AMLH_EFFECTIVE_DATE_STAMP__C
                    AND infl_data.INTERACTIONTYPE_SIXSENSE_WEBVISIT_UNCLASSIFIED_COUNT > 0 THEN 1
                    ELSE 0
                END AS FLAG_ACTEFFECTIVE_INFL_TOUCHPOINT_BY_INTERACTIONTYPE_SIXSENSE_WEBVISIT_UNCLASSIFIED,
                CASE
                    WHEN infl_data.MARKETING_TOUCHPOINT_DATE <= amlh_opp.AMLH_EFFECTIVE_DATE_STAMP__C
                    AND infl_data.INTERACTIONTYPE_BIZIBLE_TOUCHPOINT_WEBVISIT_COUNT > 0 THEN 1
                    ELSE 0
                END AS FLAG_ACTEFFECTIVE_INFL_TOUCHPOINT_BY_INTERACTIONTYPE_BIZIBLE_TOUCHPOINT_WEBVISIT,
                CASE
                    WHEN infl_data.MARKETING_TOUCHPOINT_DATE <= amlh_opp.AMLH_EFFECTIVE_DATE_STAMP__C
                    AND infl_data.INTERACTIONTYPE_BIZIBLE_TOUCHPOINT_WEBCHAT_COUNT > 0 THEN 1
                    ELSE 0
                END AS FLAG_ACTEFFECTIVE_INFL_TOUCHPOINT_BY_INTERACTIONTYPE_BIZIBLE_TOUCHPOINT_WEBCHAT,
                CASE
                    WHEN infl_data.MARKETING_TOUCHPOINT_DATE <= amlh_opp.AMLH_EFFECTIVE_DATE_STAMP__C
                    AND infl_data.INTERACTIONTYPE_BIZIBLE_TOUCHPOINT_WEBFORM_COUNT > 0 THEN 1
                    ELSE 0
                END AS FLAG_ACTEFFECTIVE_INFL_TOUCHPOINT_BY_INTERACTIONTYPE_BIZIBLE_TOUCHPOINT_WEBFORM,
                CASE
                    WHEN infl_data.MARKETING_TOUCHPOINT_DATE <= amlh_opp.AMLH_EFFECTIVE_DATE_STAMP__C
                    AND infl_data.INTERACTIONTYPE_BIZIBLE_TOUCHPOINT_CRM_COUNT > 0 THEN 1
                    ELSE 0
                END AS FLAG_ACTEFFECTIVE_INFL_TOUCHPOINT_BY_INTERACTIONTYPE_BIZIBLE_TOUCHPOINT_CRM,
                CASE
                    WHEN infl_data.MARKETING_TOUCHPOINT_DATE <= amlh_opp.AMLH_EFFECTIVE_DATE_STAMP__C
                    AND infl_data.INTERACTIONTYPE_BIZIBLE_TOUCHPOINT_CONNECTWITHDM_COUNT > 0 THEN 1
                    ELSE 0
                END AS FLAG_ACTEFFECTIVE_INFL_TOUCHPOINT_BY_INTERACTIONTYPE_BIZIBLE_TOUCHPOINT_CONNECTWITHDM,
                CASE
                    WHEN infl_data.MARKETING_TOUCHPOINT_DATE <= amlh_opp.AMLH_EFFECTIVE_DATE_STAMP__C
                    AND infl_data.INTERACTIONTYPE_BIZIBLE_TOUCHPOINT_CALLSPOKEWITH_COUNT > 0 THEN 1
                    ELSE 0
                END AS FLAG_ACTEFFECTIVE_INFL_TOUCHPOINT_BY_INTERACTIONTYPE_BIZIBLE_TOUCHPOINT_CALLSPOKEIWTH,
                CASE
                    WHEN infl_data.MARKETING_TOUCHPOINT_DATE <= amlh_opp.AMLH_EFFECTIVE_DATE_STAMP__C
                    AND infl_data.INTERACTIONTYPE_BIZIBLE_TOUCHPOINT_CALLGATEKEEPER_COUNT > 0 THEN 1
                    ELSE 0
                END AS FLAG_ACTEFFECTIVE_INFL_TOUCHPOINT_BY_INTERACTIONTYPE_BIZIBLE_TOUCHPOINT_GATEKEEPER,
                CASE
                    WHEN infl_data.MARKETING_TOUCHPOINT_DATE <= amlh_opp.AMLH_EFFECTIVE_DATE_STAMP__C
                    AND infl_data.INTERACTIONTYPE_BIZIBLE_TOUCHPOINT_NOLEADTOUCHPOINTS_COUNT > 0 THEN 1
                    ELSE 0
                END AS FLAG_ACTEFFECTIVE_INFL_TOUCHPOINT_BY_INTERACTIONTYPE_BIZIBLE_TOUCHPOINT_NOLEADTOUCHPOINT,
				CASE
                    WHEN infl_data.MARKETING_TOUCHPOINT_DATE <= amlh_opp.AMLH_EFFECTIVE_DATE_STAMP__C
                    AND infl_data.INTERACTIONTYPE_BIZIBLE_TOUCHPOINT_MARKETO_COUNT > 0 THEN 1
                    ELSE 0
                END AS FLAG_ACTEFFECTIVE_INFL_TOUCHPOINT_BY_INTERACTIONTYPE_BIZIBLE_TOUCHPOINT_MARKETO,
				CASE
                    WHEN infl_data.MARKETING_TOUCHPOINT_DATE <= amlh_opp.AMLH_EFFECTIVE_DATE_STAMP__C
                    AND infl_data.INTERACTIONTYPE_BIZIBLE_TOUCHPOINT_SEISMICENGAGEMENT_COUNT > 0 THEN 1
                    ELSE 0
                END AS FLAG_ACTEFFECTIVE_INFL_TOUCHPOINT_BY_INTERACTIONTYPE_BIZIBLE_TOUCHPOINT_SEISMICENGAGEMENT,
				CASE
                    WHEN infl_data.MARKETING_TOUCHPOINT_DATE <= amlh_opp.AMLH_EFFECTIVE_DATE_STAMP__C
                    AND infl_data.INTERACTIONTYPE_BIZIBLE_TOUCHPOINT_CHANGESTATUS_COUNT > 0 THEN 1
                    ELSE 0
                END AS FLAG_ACTEFFECTIVE_INFL_TOUCHPOINT_BY_INTERACTIONTYPE_BIZIBLE_TOUCHPOINT_CHANGESTATUS,
                CASE
                    WHEN infl_data.MARKETING_TOUCHPOINT_DATE <= amlh_opp.AMLH_EFFECTIVE_DATE_STAMP__C
                    AND infl_data.INTERACTIONTYPE_BIZIBLE_TOUCHPOINT_UNCLASSIFIED_COUNT > 0 THEN 1
                    ELSE 0
                END AS FLAG_ACTEFFECTIVE_INFL_TOUCHPOINT_BY_INTERACTIONTYPE_BIZIBLE_TOUCHPOINT_UNCLASSIFIED,
				
                -- SUM COUNTS INFLUENCE
                -- Influenced Before Opp Created
                CASE
                    WHEN infl_data.MARKETING_TOUCHPOINT_DATE <= amlh_opp.OPP_CREATED_DATE
                    AND infl_data.INTERACTIONTYPE_SIXSENSE_PAIDMEDIA_IMPRESSIONS_COUNT > 0 THEN infl_data.INTERACTIONTYPE_SIXSENSE_PAIDMEDIA_IMPRESSIONS_COUNT
                    ELSE 0
                END AS INTERACTIONTYPE_SIXSENSE_PAIDMEDIA_IMPRESSIONS_COUNT_INFLUENCE_OPPCRT,
                CASE
                    WHEN infl_data.MARKETING_TOUCHPOINT_DATE <= amlh_opp.OPP_CREATED_DATE
                    AND infl_data.INTERACTIONTYPE_SIXSENSE_PAIDMEDIA_CLICKS_COUNT > 0 THEN infl_data.INTERACTIONTYPE_SIXSENSE_PAIDMEDIA_CLICKS_COUNT
                    ELSE 0
                END AS INTERACTIONTYPE_SIXSENSE_PAIDMEDIA_CLICKS_COUNT_INFLUENCE_OPPCRT,
                CASE
                    WHEN infl_data.MARKETING_TOUCHPOINT_DATE <= amlh_opp.OPP_CREATED_DATE
                    AND infl_data.INTERACTIONTYPE_SIXSENSE_WEBVISIT_TOTAL_INTERACTIONS_COUNT > 0 THEN infl_data.INTERACTIONTYPE_SIXSENSE_WEBVISIT_TOTAL_INTERACTIONS_COUNT
                    ELSE 0
                END AS INTERACTIONTYPE_SIXSENSE_WEBVISIT_TOTAL_INTERACTIONS_COUNT_INFLUENCE_OPPCRT,
                CASE
                    WHEN infl_data.MARKETING_TOUCHPOINT_DATE <= amlh_opp.OPP_CREATED_DATE
                    AND infl_data.INTERACTIONTYPE_SIXSENSE_WEBVISIT_PAGELOAD_COUNT > 0 THEN infl_data.INTERACTIONTYPE_SIXSENSE_WEBVISIT_PAGELOAD_COUNT
                    ELSE 0
                END AS INTERACTIONTYPE_SIXSENSE_WEBVISIT_PAGELOAD_COUNT_INFLUENCE_OPPCRT,
                CASE
                    WHEN infl_data.MARKETING_TOUCHPOINT_DATE <= amlh_opp.OPP_CREATED_DATE
                    AND infl_data.INTERACTIONTYPE_SIXSENSE_WEBVISIT_PLAY_COUNT > 0 THEN infl_data.INTERACTIONTYPE_SIXSENSE_WEBVISIT_PLAY_COUNT
                    ELSE 0
                END AS INTERACTIONTYPE_SIXSENSE_WEBVISIT_PLAY_COUNT_INFLUENCE_OPPCRT,
                CASE
                    WHEN infl_data.MARKETING_TOUCHPOINT_DATE <= amlh_opp.OPP_CREATED_DATE
                    AND infl_data.INTERACTIONTYPE_SIXSENSE_WEBVISIT_CLICK_COUNT > 0 THEN infl_data.INTERACTIONTYPE_SIXSENSE_WEBVISIT_CLICK_COUNT
                    ELSE 0
                END AS INTERACTIONTYPE_SIXSENSE_WEBVISIT_CLICK_COUNT_INFLUENCE_OPPCRT,
                CASE
                    WHEN infl_data.MARKETING_TOUCHPOINT_DATE <= amlh_opp.OPP_CREATED_DATE
                    AND infl_data.INTERACTIONTYPE_SIXSENSE_WEBVISIT_SUBMIT_COUNT > 0 THEN infl_data.INTERACTIONTYPE_SIXSENSE_WEBVISIT_SUBMIT_COUNT
                    ELSE 0
                END AS INTERACTIONTYPE_SIXSENSE_WEBVISIT_SUBMIT_COUNT_INFLUENCE_OPPCRT,
                CASE
                    WHEN infl_data.MARKETING_TOUCHPOINT_DATE <= amlh_opp.OPP_CREATED_DATE
                    AND infl_data.INTERACTIONTYPE_SIXSENSE_WEBVISIT_UNCLASSIFIED_COUNT > 0 THEN infl_data.INTERACTIONTYPE_SIXSENSE_WEBVISIT_UNCLASSIFIED_COUNT
                    ELSE 0
                END AS INTERACTIONTYPE_SIXSENSE_WEBVISIT_UNCLASSIFIED_COUNT_INFLUENCE_OPPCRT,
                CASE
                    WHEN infl_data.MARKETING_TOUCHPOINT_DATE <= amlh_opp.OPP_CREATED_DATE
                    AND infl_data.INTERACTIONTYPE_BIZIBLE_TOUCHPOINT_WEBVISIT_COUNT > 0 THEN infl_data.INTERACTIONTYPE_BIZIBLE_TOUCHPOINT_WEBVISIT_COUNT
                    ELSE 0
                END AS INTERACTIONTYPE_BIZIBLE_TOUCHPOINT_WEBVISIT_COUNT_INFLUENCE_OPPCRT,
                CASE
                    WHEN infl_data.MARKETING_TOUCHPOINT_DATE <= amlh_opp.OPP_CREATED_DATE
                    AND infl_data.INTERACTIONTYPE_BIZIBLE_TOUCHPOINT_WEBCHAT_COUNT > 0 THEN infl_data.INTERACTIONTYPE_BIZIBLE_TOUCHPOINT_WEBCHAT_COUNT
                    ELSE 0
                END AS INTERACTIONTYPE_BIZIBLE_TOUCHPOINT_WEBCHAT_COUNT_INFLUENCE_OPPCRT,
                CASE
                    WHEN infl_data.MARKETING_TOUCHPOINT_DATE <= amlh_opp.OPP_CREATED_DATE
                    AND infl_data.INTERACTIONTYPE_BIZIBLE_TOUCHPOINT_WEBFORM_COUNT > 0 THEN infl_data.INTERACTIONTYPE_BIZIBLE_TOUCHPOINT_WEBFORM_COUNT
                    ELSE 0
                END AS INTERACTIONTYPE_BIZIBLE_TOUCHPOINT_WEBFORM_COUNT_INFLUENCE_OPPCRT,
                CASE
                    WHEN infl_data.MARKETING_TOUCHPOINT_DATE <= amlh_opp.OPP_CREATED_DATE
                    AND infl_data.INTERACTIONTYPE_BIZIBLE_TOUCHPOINT_CRM_COUNT > 0 THEN infl_data.INTERACTIONTYPE_BIZIBLE_TOUCHPOINT_CRM_COUNT
                    ELSE 0
                END AS INTERACTIONTYPE_BIZIBLE_TOUCHPOINT_CRM_COUNT_INFLUENCE_OPPCRT,
                CASE
                    WHEN infl_data.MARKETING_TOUCHPOINT_DATE <= amlh_opp.OPP_CREATED_DATE
                    AND infl_data.INTERACTIONTYPE_BIZIBLE_TOUCHPOINT_CONNECTWITHDM_COUNT > 0 THEN infl_data.INTERACTIONTYPE_BIZIBLE_TOUCHPOINT_CONNECTWITHDM_COUNT
                    ELSE 0
                END AS INTERACTIONTYPE_BIZIBLE_TOUCHPOINT_CONNECTWITHDM_COUNT_INFLUENCE_OPPCRT,
                CASE
                    WHEN infl_data.MARKETING_TOUCHPOINT_DATE <= amlh_opp.OPP_CREATED_DATE
                    AND infl_data.INTERACTIONTYPE_BIZIBLE_TOUCHPOINT_CALLSPOKEWITH_COUNT > 0 THEN infl_data.INTERACTIONTYPE_BIZIBLE_TOUCHPOINT_CALLSPOKEWITH_COUNT
                    ELSE 0
                END AS INTERACTIONTYPE_BIZIBLE_TOUCHPOINT_CALLSPOKEWITH_COUNT_INFLUENCE_OPPCRT,
                CASE
                    WHEN infl_data.MARKETING_TOUCHPOINT_DATE <= amlh_opp.OPP_CREATED_DATE
                    AND infl_data.INTERACTIONTYPE_BIZIBLE_TOUCHPOINT_CALLGATEKEEPER_COUNT > 0 THEN infl_data.INTERACTIONTYPE_BIZIBLE_TOUCHPOINT_CALLGATEKEEPER_COUNT
                    ELSE 0
                END AS INTERACTIONTYPE_BIZIBLE_TOUCHPOINT_CALLGATEKEEPER_COUNT_INFLUENCE_OPPCRT,
                CASE
                    WHEN infl_data.MARKETING_TOUCHPOINT_DATE <= amlh_opp.OPP_CREATED_DATE
                    AND infl_data.INTERACTIONTYPE_BIZIBLE_TOUCHPOINT_NOLEADTOUCHPOINTS_COUNT > 0 THEN infl_data.INTERACTIONTYPE_BIZIBLE_TOUCHPOINT_NOLEADTOUCHPOINTS_COUNT
                    ELSE 0
                END AS INTERACTIONTYPE_BIZIBLE_TOUCHPOINT_NOLEADTOUCHPOINTS_COUNT_INFLUENCE_OPPCRT,
				--20250302
                CASE
                    WHEN infl_data.MARKETING_TOUCHPOINT_DATE <= amlh_opp.OPP_CREATED_DATE
                    AND infl_data.INTERACTIONTYPE_BIZIBLE_TOUCHPOINT_MARKETO_COUNT > 0 THEN infl_data.INTERACTIONTYPE_BIZIBLE_TOUCHPOINT_MARKETO_COUNT
                    ELSE 0
                END AS INTERACTIONTYPE_BIZIBLE_TOUCHPOINT_MARKETO_COUNT_INFLUENCE_OPPCRT,
				--20250314
                CASE
                    WHEN infl_data.MARKETING_TOUCHPOINT_DATE <= amlh_opp.OPP_CREATED_DATE
                    AND infl_data.INTERACTIONTYPE_BIZIBLE_TOUCHPOINT_SEISMICENGAGEMENT_COUNT > 0 THEN infl_data.INTERACTIONTYPE_BIZIBLE_TOUCHPOINT_SEISMICENGAGEMENT_COUNT
                    ELSE 0
                END AS INTERACTIONTYPE_BIZIBLE_TOUCHPOINT_SEISMICENGAGEMENT_COUNT_INFLUENCE_OPPCRT,
                CASE
                    WHEN infl_data.MARKETING_TOUCHPOINT_DATE <= amlh_opp.OPP_CREATED_DATE
                    AND infl_data.INTERACTIONTYPE_BIZIBLE_TOUCHPOINT_CHANGESTATUS_COUNT > 0 THEN infl_data.INTERACTIONTYPE_BIZIBLE_TOUCHPOINT_CHANGESTATUS_COUNT
                    ELSE 0
                END AS INTERACTIONTYPE_BIZIBLE_TOUCHPOINT_CHANGESTATUS_COUNT_INFLUENCE_OPPCRT,
                CASE
                    WHEN infl_data.MARKETING_TOUCHPOINT_DATE <= amlh_opp.OPP_CREATED_DATE
                    AND infl_data.INTERACTIONTYPE_BIZIBLE_TOUCHPOINT_UNCLASSIFIED_COUNT > 0 THEN infl_data.INTERACTIONTYPE_BIZIBLE_TOUCHPOINT_UNCLASSIFIED_COUNT
                    ELSE 0
                END AS INTERACTIONTYPE_BIZIBLE_TOUCHPOINT_UNCLASSIFIED_COUNT_INFLUENCE_OPPCRT,
				--20251002
                -- SUM COUNTS INFLUENCE
                -- Influenced Before Opp Stage Zero
                CASE
                    WHEN infl_data.MARKETING_TOUCHPOINT_DATE <= amlh_opp.OPP_STAGE_0_DATE
                    AND infl_data.INTERACTIONTYPE_SIXSENSE_PAIDMEDIA_IMPRESSIONS_COUNT > 0 THEN infl_data.INTERACTIONTYPE_SIXSENSE_PAIDMEDIA_IMPRESSIONS_COUNT
                    ELSE 0
                END AS INTERACTIONTYPE_SIXSENSE_PAIDMEDIA_IMPRESSIONS_COUNT_INFLUENCE_OPPSTG0,
                CASE
                    WHEN infl_data.MARKETING_TOUCHPOINT_DATE <= amlh_opp.OPP_STAGE_0_DATE
                    AND infl_data.INTERACTIONTYPE_SIXSENSE_PAIDMEDIA_CLICKS_COUNT > 0 THEN infl_data.INTERACTIONTYPE_SIXSENSE_PAIDMEDIA_CLICKS_COUNT
                    ELSE 0
                END AS INTERACTIONTYPE_SIXSENSE_PAIDMEDIA_CLICKS_COUNT_INFLUENCE_OPPSTG0,
                CASE
                    WHEN infl_data.MARKETING_TOUCHPOINT_DATE <= amlh_opp.OPP_STAGE_0_DATE
                    AND infl_data.INTERACTIONTYPE_SIXSENSE_WEBVISIT_TOTAL_INTERACTIONS_COUNT > 0 THEN infl_data.INTERACTIONTYPE_SIXSENSE_WEBVISIT_TOTAL_INTERACTIONS_COUNT
                    ELSE 0
                END AS INTERACTIONTYPE_SIXSENSE_WEBVISIT_TOTAL_INTERACTIONS_COUNT_INFLUENCE_OPPSTG0,
                CASE
                    WHEN infl_data.MARKETING_TOUCHPOINT_DATE <= amlh_opp.OPP_STAGE_0_DATE
                    AND infl_data.INTERACTIONTYPE_SIXSENSE_WEBVISIT_PAGELOAD_COUNT > 0 THEN infl_data.INTERACTIONTYPE_SIXSENSE_WEBVISIT_PAGELOAD_COUNT
                    ELSE 0
                END AS INTERACTIONTYPE_SIXSENSE_WEBVISIT_PAGELOAD_COUNT_INFLUENCE_OPPSTG0,
                CASE
                    WHEN infl_data.MARKETING_TOUCHPOINT_DATE <= amlh_opp.OPP_STAGE_0_DATE
                    AND infl_data.INTERACTIONTYPE_SIXSENSE_WEBVISIT_PLAY_COUNT > 0 THEN infl_data.INTERACTIONTYPE_SIXSENSE_WEBVISIT_PLAY_COUNT
                    ELSE 0
                END AS INTERACTIONTYPE_SIXSENSE_WEBVISIT_PLAY_COUNT_INFLUENCE_OPPSTG0,
                CASE
                    WHEN infl_data.MARKETING_TOUCHPOINT_DATE <= amlh_opp.OPP_STAGE_0_DATE
                    AND infl_data.INTERACTIONTYPE_SIXSENSE_WEBVISIT_CLICK_COUNT > 0 THEN infl_data.INTERACTIONTYPE_SIXSENSE_WEBVISIT_CLICK_COUNT
                    ELSE 0
                END AS INTERACTIONTYPE_SIXSENSE_WEBVISIT_CLICK_COUNT_INFLUENCE_OPPSTG0,
                CASE
                    WHEN infl_data.MARKETING_TOUCHPOINT_DATE <= amlh_opp.OPP_STAGE_0_DATE
                    AND infl_data.INTERACTIONTYPE_SIXSENSE_WEBVISIT_SUBMIT_COUNT > 0 THEN infl_data.INTERACTIONTYPE_SIXSENSE_WEBVISIT_SUBMIT_COUNT
                    ELSE 0
                END AS INTERACTIONTYPE_SIXSENSE_WEBVISIT_SUBMIT_COUNT_INFLUENCE_OPPSTG0,
                CASE
                    WHEN infl_data.MARKETING_TOUCHPOINT_DATE <= amlh_opp.OPP_STAGE_0_DATE
                    AND infl_data.INTERACTIONTYPE_SIXSENSE_WEBVISIT_UNCLASSIFIED_COUNT > 0 THEN infl_data.INTERACTIONTYPE_SIXSENSE_WEBVISIT_UNCLASSIFIED_COUNT
                    ELSE 0
                END AS INTERACTIONTYPE_SIXSENSE_WEBVISIT_UNCLASSIFIED_COUNT_INFLUENCE_OPPSTG0,
                CASE
                    WHEN infl_data.MARKETING_TOUCHPOINT_DATE <= amlh_opp.OPP_STAGE_0_DATE
                    AND infl_data.INTERACTIONTYPE_BIZIBLE_TOUCHPOINT_WEBVISIT_COUNT > 0 THEN infl_data.INTERACTIONTYPE_BIZIBLE_TOUCHPOINT_WEBVISIT_COUNT
                    ELSE 0
                END AS INTERACTIONTYPE_BIZIBLE_TOUCHPOINT_WEBVISIT_COUNT_INFLUENCE_OPPSTG0,
                CASE
                    WHEN infl_data.MARKETING_TOUCHPOINT_DATE <= amlh_opp.OPP_STAGE_0_DATE
                    AND infl_data.INTERACTIONTYPE_BIZIBLE_TOUCHPOINT_WEBCHAT_COUNT > 0 THEN infl_data.INTERACTIONTYPE_BIZIBLE_TOUCHPOINT_WEBCHAT_COUNT
                    ELSE 0
                END AS INTERACTIONTYPE_BIZIBLE_TOUCHPOINT_WEBCHAT_COUNT_INFLUENCE_OPPSTG0,
                CASE
                    WHEN infl_data.MARKETING_TOUCHPOINT_DATE <= amlh_opp.OPP_STAGE_0_DATE
                    AND infl_data.INTERACTIONTYPE_BIZIBLE_TOUCHPOINT_WEBFORM_COUNT > 0 THEN infl_data.INTERACTIONTYPE_BIZIBLE_TOUCHPOINT_WEBFORM_COUNT
                    ELSE 0
                END AS INTERACTIONTYPE_BIZIBLE_TOUCHPOINT_WEBFORM_COUNT_INFLUENCE_OPPSTG0,
                CASE
                    WHEN infl_data.MARKETING_TOUCHPOINT_DATE <= amlh_opp.OPP_STAGE_0_DATE
                    AND infl_data.INTERACTIONTYPE_BIZIBLE_TOUCHPOINT_CRM_COUNT > 0 THEN infl_data.INTERACTIONTYPE_BIZIBLE_TOUCHPOINT_CRM_COUNT
                    ELSE 0
                END AS INTERACTIONTYPE_BIZIBLE_TOUCHPOINT_CRM_COUNT_INFLUENCE_OPPSTG0,
                CASE
                    WHEN infl_data.MARKETING_TOUCHPOINT_DATE <= amlh_opp.OPP_STAGE_0_DATE
                    AND infl_data.INTERACTIONTYPE_BIZIBLE_TOUCHPOINT_CONNECTWITHDM_COUNT > 0 THEN infl_data.INTERACTIONTYPE_BIZIBLE_TOUCHPOINT_CONNECTWITHDM_COUNT
                    ELSE 0
                END AS INTERACTIONTYPE_BIZIBLE_TOUCHPOINT_CONNECTWITHDM_COUNT_INFLUENCE_OPPSTG0,
                CASE
                    WHEN infl_data.MARKETING_TOUCHPOINT_DATE <= amlh_opp.OPP_STAGE_0_DATE
                    AND infl_data.INTERACTIONTYPE_BIZIBLE_TOUCHPOINT_CALLSPOKEWITH_COUNT > 0 THEN infl_data.INTERACTIONTYPE_BIZIBLE_TOUCHPOINT_CALLSPOKEWITH_COUNT
                    ELSE 0
                END AS INTERACTIONTYPE_BIZIBLE_TOUCHPOINT_CALLSPOKEWITH_COUNT_INFLUENCE_OPPSTG0,
                CASE
                    WHEN infl_data.MARKETING_TOUCHPOINT_DATE <= amlh_opp.OPP_STAGE_0_DATE
                    AND infl_data.INTERACTIONTYPE_BIZIBLE_TOUCHPOINT_CALLGATEKEEPER_COUNT > 0 THEN infl_data.INTERACTIONTYPE_BIZIBLE_TOUCHPOINT_CALLGATEKEEPER_COUNT
                    ELSE 0
                END AS INTERACTIONTYPE_BIZIBLE_TOUCHPOINT_CALLGATEKEEPER_COUNT_INFLUENCE_OPPSTG0,
                CASE
                    WHEN infl_data.MARKETING_TOUCHPOINT_DATE <= amlh_opp.OPP_STAGE_0_DATE
                    AND infl_data.INTERACTIONTYPE_BIZIBLE_TOUCHPOINT_NOLEADTOUCHPOINTS_COUNT > 0 THEN infl_data.INTERACTIONTYPE_BIZIBLE_TOUCHPOINT_NOLEADTOUCHPOINTS_COUNT
                    ELSE 0
                END AS INTERACTIONTYPE_BIZIBLE_TOUCHPOINT_NOLEADTOUCHPOINTS_COUNT_INFLUENCE_OPPSTG0,
				--20250302
                CASE
                    WHEN infl_data.MARKETING_TOUCHPOINT_DATE <= amlh_opp.OPP_STAGE_0_DATE
                    AND infl_data.INTERACTIONTYPE_BIZIBLE_TOUCHPOINT_MARKETO_COUNT > 0 THEN infl_data.INTERACTIONTYPE_BIZIBLE_TOUCHPOINT_MARKETO_COUNT
                    ELSE 0
                END AS INTERACTIONTYPE_BIZIBLE_TOUCHPOINT_MARKETO_COUNT_INFLUENCE_OPPSTG0,
				--20250314
                CASE
                    WHEN infl_data.MARKETING_TOUCHPOINT_DATE <= amlh_opp.OPP_STAGE_0_DATE
                    AND infl_data.INTERACTIONTYPE_BIZIBLE_TOUCHPOINT_SEISMICENGAGEMENT_COUNT > 0 THEN infl_data.INTERACTIONTYPE_BIZIBLE_TOUCHPOINT_SEISMICENGAGEMENT_COUNT
                    ELSE 0
                END AS INTERACTIONTYPE_BIZIBLE_TOUCHPOINT_SEISMICENGAGEMENT_COUNT_INFLUENCE_OPPSTG0,
                CASE
                    WHEN infl_data.MARKETING_TOUCHPOINT_DATE <= amlh_opp.OPP_STAGE_0_DATE
                    AND infl_data.INTERACTIONTYPE_BIZIBLE_TOUCHPOINT_CHANGESTATUS_COUNT > 0 THEN infl_data.INTERACTIONTYPE_BIZIBLE_TOUCHPOINT_CHANGESTATUS_COUNT
                    ELSE 0
                END AS INTERACTIONTYPE_BIZIBLE_TOUCHPOINT_CHANGESTATUS_COUNT_INFLUENCE_OPPSTG0,
                CASE
                    WHEN infl_data.MARKETING_TOUCHPOINT_DATE <= amlh_opp.OPP_STAGE_0_DATE
                    AND infl_data.INTERACTIONTYPE_BIZIBLE_TOUCHPOINT_UNCLASSIFIED_COUNT > 0 THEN infl_data.INTERACTIONTYPE_BIZIBLE_TOUCHPOINT_UNCLASSIFIED_COUNT
                    ELSE 0
                END AS INTERACTIONTYPE_BIZIBLE_TOUCHPOINT_UNCLASSIFIED_COUNT_INFLUENCE_OPPSTG0,
				--20250302
                -- SUM COUNTS INFLUENCE
                -- Influenced Before Opp Stage One
                CASE
                    WHEN infl_data.MARKETING_TOUCHPOINT_DATE <= amlh_opp.OPP_STAGE_1_DATE
                    AND infl_data.INTERACTIONTYPE_SIXSENSE_PAIDMEDIA_IMPRESSIONS_COUNT > 0 THEN infl_data.INTERACTIONTYPE_SIXSENSE_PAIDMEDIA_IMPRESSIONS_COUNT
                    ELSE 0
                END AS INTERACTIONTYPE_SIXSENSE_PAIDMEDIA_IMPRESSIONS_COUNT_INFLUENCE_OPPSTG1,
                CASE
                    WHEN infl_data.MARKETING_TOUCHPOINT_DATE <= amlh_opp.OPP_STAGE_1_DATE
                    AND infl_data.INTERACTIONTYPE_SIXSENSE_PAIDMEDIA_CLICKS_COUNT > 0 THEN infl_data.INTERACTIONTYPE_SIXSENSE_PAIDMEDIA_CLICKS_COUNT
                    ELSE 0
                END AS INTERACTIONTYPE_SIXSENSE_PAIDMEDIA_CLICKS_COUNT_INFLUENCE_OPPSTG1,
                CASE
                    WHEN infl_data.MARKETING_TOUCHPOINT_DATE <= amlh_opp.OPP_STAGE_1_DATE
                    AND infl_data.INTERACTIONTYPE_SIXSENSE_WEBVISIT_TOTAL_INTERACTIONS_COUNT > 0 THEN infl_data.INTERACTIONTYPE_SIXSENSE_WEBVISIT_TOTAL_INTERACTIONS_COUNT
                    ELSE 0
                END AS INTERACTIONTYPE_SIXSENSE_WEBVISIT_TOTAL_INTERACTIONS_COUNT_INFLUENCE_OPPSTG1,
                CASE
                    WHEN infl_data.MARKETING_TOUCHPOINT_DATE <= amlh_opp.OPP_STAGE_1_DATE
                    AND infl_data.INTERACTIONTYPE_SIXSENSE_WEBVISIT_PAGELOAD_COUNT > 0 THEN infl_data.INTERACTIONTYPE_SIXSENSE_WEBVISIT_PAGELOAD_COUNT
                    ELSE 0
                END AS INTERACTIONTYPE_SIXSENSE_WEBVISIT_PAGELOAD_COUNT_INFLUENCE_OPPSTG1,
                CASE
                    WHEN infl_data.MARKETING_TOUCHPOINT_DATE <= amlh_opp.OPP_STAGE_1_DATE
                    AND infl_data.INTERACTIONTYPE_SIXSENSE_WEBVISIT_PLAY_COUNT > 0 THEN infl_data.INTERACTIONTYPE_SIXSENSE_WEBVISIT_PLAY_COUNT
                    ELSE 0
                END AS INTERACTIONTYPE_SIXSENSE_WEBVISIT_PLAY_COUNT_INFLUENCE_OPPSTG1,
                CASE
                    WHEN infl_data.MARKETING_TOUCHPOINT_DATE <= amlh_opp.OPP_STAGE_1_DATE
                    AND infl_data.INTERACTIONTYPE_SIXSENSE_WEBVISIT_CLICK_COUNT > 0 THEN infl_data.INTERACTIONTYPE_SIXSENSE_WEBVISIT_CLICK_COUNT
                    ELSE 0
                END AS INTERACTIONTYPE_SIXSENSE_WEBVISIT_CLICK_COUNT_INFLUENCE_OPPSTG1,
                CASE
                    WHEN infl_data.MARKETING_TOUCHPOINT_DATE <= amlh_opp.OPP_STAGE_1_DATE
                    AND infl_data.INTERACTIONTYPE_SIXSENSE_WEBVISIT_SUBMIT_COUNT > 0 THEN infl_data.INTERACTIONTYPE_SIXSENSE_WEBVISIT_SUBMIT_COUNT
                    ELSE 0
                END AS INTERACTIONTYPE_SIXSENSE_WEBVISIT_SUBMIT_COUNT_INFLUENCE_OPPSTG1,
                CASE
                    WHEN infl_data.MARKETING_TOUCHPOINT_DATE <= amlh_opp.OPP_STAGE_1_DATE
                    AND infl_data.INTERACTIONTYPE_SIXSENSE_WEBVISIT_UNCLASSIFIED_COUNT > 0 THEN infl_data.INTERACTIONTYPE_SIXSENSE_WEBVISIT_UNCLASSIFIED_COUNT
                    ELSE 0
                END AS INTERACTIONTYPE_SIXSENSE_WEBVISIT_UNCLASSIFIED_COUNT_INFLUENCE_OPPSTG1,
                CASE
                    WHEN infl_data.MARKETING_TOUCHPOINT_DATE <= amlh_opp.OPP_STAGE_1_DATE
                    AND infl_data.INTERACTIONTYPE_BIZIBLE_TOUCHPOINT_WEBVISIT_COUNT > 0 THEN infl_data.INTERACTIONTYPE_BIZIBLE_TOUCHPOINT_WEBVISIT_COUNT
                    ELSE 0
                END AS INTERACTIONTYPE_BIZIBLE_TOUCHPOINT_WEBVISIT_COUNT_INFLUENCE_OPPSTG1,
                CASE
                    WHEN infl_data.MARKETING_TOUCHPOINT_DATE <= amlh_opp.OPP_STAGE_1_DATE
                    AND infl_data.INTERACTIONTYPE_BIZIBLE_TOUCHPOINT_WEBCHAT_COUNT > 0 THEN infl_data.INTERACTIONTYPE_BIZIBLE_TOUCHPOINT_WEBCHAT_COUNT
                    ELSE 0
                END AS INTERACTIONTYPE_BIZIBLE_TOUCHPOINT_WEBCHAT_COUNT_INFLUENCE_OPPSTG1,
                CASE
                    WHEN infl_data.MARKETING_TOUCHPOINT_DATE <= amlh_opp.OPP_STAGE_1_DATE
                    AND infl_data.INTERACTIONTYPE_BIZIBLE_TOUCHPOINT_WEBFORM_COUNT > 0 THEN infl_data.INTERACTIONTYPE_BIZIBLE_TOUCHPOINT_WEBFORM_COUNT
                    ELSE 0
                END AS INTERACTIONTYPE_BIZIBLE_TOUCHPOINT_WEBFORM_COUNT_INFLUENCE_OPPSTG1,
                CASE
                    WHEN infl_data.MARKETING_TOUCHPOINT_DATE <= amlh_opp.OPP_STAGE_1_DATE
                    AND infl_data.INTERACTIONTYPE_BIZIBLE_TOUCHPOINT_CRM_COUNT > 0 THEN infl_data.INTERACTIONTYPE_BIZIBLE_TOUCHPOINT_CRM_COUNT
                    ELSE 0
                END AS INTERACTIONTYPE_BIZIBLE_TOUCHPOINT_CRM_COUNT_INFLUENCE_OPPSTG1,
                CASE
                    WHEN infl_data.MARKETING_TOUCHPOINT_DATE <= amlh_opp.OPP_STAGE_1_DATE
                    AND infl_data.INTERACTIONTYPE_BIZIBLE_TOUCHPOINT_CONNECTWITHDM_COUNT > 0 THEN infl_data.INTERACTIONTYPE_BIZIBLE_TOUCHPOINT_CONNECTWITHDM_COUNT
                    ELSE 0
                END AS INTERACTIONTYPE_BIZIBLE_TOUCHPOINT_CONNECTWITHDM_COUNT_INFLUENCE_OPPSTG1,
                CASE
                    WHEN infl_data.MARKETING_TOUCHPOINT_DATE <= amlh_opp.OPP_STAGE_1_DATE
                    AND infl_data.INTERACTIONTYPE_BIZIBLE_TOUCHPOINT_CALLSPOKEWITH_COUNT > 0 THEN infl_data.INTERACTIONTYPE_BIZIBLE_TOUCHPOINT_CALLSPOKEWITH_COUNT
                    ELSE 0
                END AS INTERACTIONTYPE_BIZIBLE_TOUCHPOINT_CALLSPOKEWITH_COUNT_INFLUENCE_OPPSTG1,
                CASE
                    WHEN infl_data.MARKETING_TOUCHPOINT_DATE <= amlh_opp.OPP_STAGE_1_DATE
                    AND infl_data.INTERACTIONTYPE_BIZIBLE_TOUCHPOINT_CALLGATEKEEPER_COUNT > 0 THEN infl_data.INTERACTIONTYPE_BIZIBLE_TOUCHPOINT_CALLGATEKEEPER_COUNT
                    ELSE 0
                END AS INTERACTIONTYPE_BIZIBLE_TOUCHPOINT_CALLGATEKEEPER_COUNT_INFLUENCE_OPPSTG1,
                CASE
                    WHEN infl_data.MARKETING_TOUCHPOINT_DATE <= amlh_opp.OPP_STAGE_1_DATE
                    AND infl_data.INTERACTIONTYPE_BIZIBLE_TOUCHPOINT_NOLEADTOUCHPOINTS_COUNT > 0 THEN infl_data.INTERACTIONTYPE_BIZIBLE_TOUCHPOINT_NOLEADTOUCHPOINTS_COUNT
                    ELSE 0
                END AS INTERACTIONTYPE_BIZIBLE_TOUCHPOINT_NOLEADTOUCHPOINTS_COUNT_INFLUENCE_OPPSTG1,
				--20250302
                CASE
                    WHEN infl_data.MARKETING_TOUCHPOINT_DATE <= amlh_opp.OPP_STAGE_1_DATE
                    AND infl_data.INTERACTIONTYPE_BIZIBLE_TOUCHPOINT_MARKETO_COUNT > 0 THEN infl_data.INTERACTIONTYPE_BIZIBLE_TOUCHPOINT_MARKETO_COUNT
                    ELSE 0
                END AS INTERACTIONTYPE_BIZIBLE_TOUCHPOINT_MARKETO_COUNT_INFLUENCE_OPPSTG1,
				--20250314
                CASE
                    WHEN infl_data.MARKETING_TOUCHPOINT_DATE <= amlh_opp.OPP_STAGE_1_DATE
                    AND infl_data.INTERACTIONTYPE_BIZIBLE_TOUCHPOINT_SEISMICENGAGEMENT_COUNT > 0 THEN infl_data.INTERACTIONTYPE_BIZIBLE_TOUCHPOINT_SEISMICENGAGEMENT_COUNT
                    ELSE 0
                END AS INTERACTIONTYPE_BIZIBLE_TOUCHPOINT_SEISMICENGAGEMENT_COUNT_INFLUENCE_OPPSTG1,
                CASE
                    WHEN infl_data.MARKETING_TOUCHPOINT_DATE <= amlh_opp.OPP_STAGE_1_DATE
                    AND infl_data.INTERACTIONTYPE_BIZIBLE_TOUCHPOINT_CHANGESTATUS_COUNT > 0 THEN infl_data.INTERACTIONTYPE_BIZIBLE_TOUCHPOINT_CHANGESTATUS_COUNT
                    ELSE 0
                END AS INTERACTIONTYPE_BIZIBLE_TOUCHPOINT_CHANGESTATUS_COUNT_INFLUENCE_OPPSTG1,
                CASE
                    WHEN infl_data.MARKETING_TOUCHPOINT_DATE <= amlh_opp.OPP_STAGE_1_DATE
                    AND infl_data.INTERACTIONTYPE_BIZIBLE_TOUCHPOINT_UNCLASSIFIED_COUNT > 0 THEN infl_data.INTERACTIONTYPE_BIZIBLE_TOUCHPOINT_UNCLASSIFIED_COUNT
                    ELSE 0
                END AS INTERACTIONTYPE_BIZIBLE_TOUCHPOINT_UNCLASSIFIED_COUNT_INFLUENCE_OPPSTG1,
                -- SUM COUNTS INFLUENCE
                -- Influenced Before Opp Closed
                CASE
                    WHEN infl_data.MARKETING_TOUCHPOINT_DATE <= amlh_opp.OPP_CLOSE_DATE
                    AND infl_data.INTERACTIONTYPE_SIXSENSE_PAIDMEDIA_IMPRESSIONS_COUNT > 0 THEN infl_data.INTERACTIONTYPE_SIXSENSE_PAIDMEDIA_IMPRESSIONS_COUNT
                    ELSE 0
                END AS INTERACTIONTYPE_SIXSENSE_PAIDMEDIA_IMPRESSIONS_COUNT_INFLUENCE_OPPCLS,
                CASE
                    WHEN infl_data.MARKETING_TOUCHPOINT_DATE <= amlh_opp.OPP_CLOSE_DATE
                    AND infl_data.INTERACTIONTYPE_SIXSENSE_PAIDMEDIA_CLICKS_COUNT > 0 THEN infl_data.INTERACTIONTYPE_SIXSENSE_PAIDMEDIA_CLICKS_COUNT
                    ELSE 0
                END AS INTERACTIONTYPE_SIXSENSE_PAIDMEDIA_CLICKS_COUNT_INFLUENCE_OPPCLS,
                CASE
                    WHEN infl_data.MARKETING_TOUCHPOINT_DATE <= amlh_opp.OPP_CLOSE_DATE
                    AND infl_data.INTERACTIONTYPE_SIXSENSE_WEBVISIT_TOTAL_INTERACTIONS_COUNT > 0 THEN infl_data.INTERACTIONTYPE_SIXSENSE_WEBVISIT_TOTAL_INTERACTIONS_COUNT
                    ELSE 0
                END AS INTERACTIONTYPE_SIXSENSE_WEBVISIT_TOTAL_INTERACTIONS_COUNT_INFLUENCE_OPPCLS,
                CASE
                    WHEN infl_data.MARKETING_TOUCHPOINT_DATE <= amlh_opp.OPP_CLOSE_DATE
                    AND infl_data.INTERACTIONTYPE_SIXSENSE_WEBVISIT_PAGELOAD_COUNT > 0 THEN infl_data.INTERACTIONTYPE_SIXSENSE_WEBVISIT_PAGELOAD_COUNT
                    ELSE 0
                END AS INTERACTIONTYPE_SIXSENSE_WEBVISIT_PAGELOAD_COUNT_INFLUENCE_OPPCLS,
                CASE
                    WHEN infl_data.MARKETING_TOUCHPOINT_DATE <= amlh_opp.OPP_CLOSE_DATE
                    AND infl_data.INTERACTIONTYPE_SIXSENSE_WEBVISIT_PLAY_COUNT > 0 THEN infl_data.INTERACTIONTYPE_SIXSENSE_WEBVISIT_PLAY_COUNT
                    ELSE 0
                END AS INTERACTIONTYPE_SIXSENSE_WEBVISIT_PLAY_COUNT_INFLUENCE_OPPCLS,
                CASE
                    WHEN infl_data.MARKETING_TOUCHPOINT_DATE <= amlh_opp.OPP_CLOSE_DATE
                    AND infl_data.INTERACTIONTYPE_SIXSENSE_WEBVISIT_CLICK_COUNT > 0 THEN infl_data.INTERACTIONTYPE_SIXSENSE_WEBVISIT_CLICK_COUNT
                    ELSE 0
                END AS INTERACTIONTYPE_SIXSENSE_WEBVISIT_CLICK_COUNT_INFLUENCE_OPPCLS,
                CASE
                    WHEN infl_data.MARKETING_TOUCHPOINT_DATE <= amlh_opp.OPP_CLOSE_DATE
                    AND infl_data.INTERACTIONTYPE_SIXSENSE_WEBVISIT_SUBMIT_COUNT > 0 THEN infl_data.INTERACTIONTYPE_SIXSENSE_WEBVISIT_SUBMIT_COUNT
                    ELSE 0
                END AS INTERACTIONTYPE_SIXSENSE_WEBVISIT_SUBMIT_COUNT_INFLUENCE_OPPCLS,
                CASE
                    WHEN infl_data.MARKETING_TOUCHPOINT_DATE <= amlh_opp.OPP_CLOSE_DATE
                    AND infl_data.INTERACTIONTYPE_SIXSENSE_WEBVISIT_UNCLASSIFIED_COUNT > 0 THEN infl_data.INTERACTIONTYPE_SIXSENSE_WEBVISIT_UNCLASSIFIED_COUNT
                    ELSE 0
                END AS INTERACTIONTYPE_SIXSENSE_WEBVISIT_UNCLASSIFIED_COUNT_INFLUENCE_OPPCLS,
                CASE
                    WHEN infl_data.MARKETING_TOUCHPOINT_DATE <= amlh_opp.OPP_CLOSE_DATE
                    AND infl_data.INTERACTIONTYPE_BIZIBLE_TOUCHPOINT_WEBVISIT_COUNT > 0 THEN infl_data.INTERACTIONTYPE_BIZIBLE_TOUCHPOINT_WEBVISIT_COUNT
                    ELSE 0
                END AS INTERACTIONTYPE_BIZIBLE_TOUCHPOINT_WEBVISIT_COUNT_INFLUENCE_OPPCLS,
                CASE
                    WHEN infl_data.MARKETING_TOUCHPOINT_DATE <= amlh_opp.OPP_CLOSE_DATE
                    AND infl_data.INTERACTIONTYPE_BIZIBLE_TOUCHPOINT_WEBCHAT_COUNT > 0 THEN infl_data.INTERACTIONTYPE_BIZIBLE_TOUCHPOINT_WEBCHAT_COUNT
                    ELSE 0
                END AS INTERACTIONTYPE_BIZIBLE_TOUCHPOINT_WEBCHAT_COUNT_INFLUENCE_OPPCLS,
                CASE
                    WHEN infl_data.MARKETING_TOUCHPOINT_DATE <= amlh_opp.OPP_CLOSE_DATE
                    AND infl_data.INTERACTIONTYPE_BIZIBLE_TOUCHPOINT_WEBFORM_COUNT > 0 THEN infl_data.INTERACTIONTYPE_BIZIBLE_TOUCHPOINT_WEBFORM_COUNT
                    ELSE 0
                END AS INTERACTIONTYPE_BIZIBLE_TOUCHPOINT_WEBFORM_COUNT_INFLUENCE_OPPCLS,
                CASE
                    WHEN infl_data.MARKETING_TOUCHPOINT_DATE <= amlh_opp.OPP_CLOSE_DATE
                    AND infl_data.INTERACTIONTYPE_BIZIBLE_TOUCHPOINT_CRM_COUNT > 0 THEN infl_data.INTERACTIONTYPE_BIZIBLE_TOUCHPOINT_CRM_COUNT
                    ELSE 0
                END AS INTERACTIONTYPE_BIZIBLE_TOUCHPOINT_CRM_COUNT_INFLUENCE_OPPCLS,
                CASE
                    WHEN infl_data.MARKETING_TOUCHPOINT_DATE <= amlh_opp.OPP_CLOSE_DATE
                    AND infl_data.INTERACTIONTYPE_BIZIBLE_TOUCHPOINT_CONNECTWITHDM_COUNT > 0 THEN infl_data.INTERACTIONTYPE_BIZIBLE_TOUCHPOINT_CONNECTWITHDM_COUNT
                    ELSE 0
                END AS INTERACTIONTYPE_BIZIBLE_TOUCHPOINT_CONNECTWITHDM_COUNT_INFLUENCE_OPPCLS,
                CASE
                    WHEN infl_data.MARKETING_TOUCHPOINT_DATE <= amlh_opp.OPP_CLOSE_DATE
                    AND infl_data.INTERACTIONTYPE_BIZIBLE_TOUCHPOINT_CALLSPOKEWITH_COUNT > 0 THEN infl_data.INTERACTIONTYPE_BIZIBLE_TOUCHPOINT_CALLSPOKEWITH_COUNT
                    ELSE 0
                END AS INTERACTIONTYPE_BIZIBLE_TOUCHPOINT_CALLSPOKEWITH_COUNT_INFLUENCE_OPPCLS,
                CASE
                    WHEN infl_data.MARKETING_TOUCHPOINT_DATE <= amlh_opp.OPP_CLOSE_DATE
                    AND infl_data.INTERACTIONTYPE_BIZIBLE_TOUCHPOINT_CALLGATEKEEPER_COUNT > 0 THEN infl_data.INTERACTIONTYPE_BIZIBLE_TOUCHPOINT_CALLGATEKEEPER_COUNT
                    ELSE 0
                END AS INTERACTIONTYPE_BIZIBLE_TOUCHPOINT_CALLGATEKEEPER_COUNT_INFLUENCE_OPPCLS,
                CASE
                    WHEN infl_data.MARKETING_TOUCHPOINT_DATE <= amlh_opp.OPP_CLOSE_DATE
                    AND infl_data.INTERACTIONTYPE_BIZIBLE_TOUCHPOINT_NOLEADTOUCHPOINTS_COUNT > 0 THEN infl_data.INTERACTIONTYPE_BIZIBLE_TOUCHPOINT_NOLEADTOUCHPOINTS_COUNT
                    ELSE 0
                END AS INTERACTIONTYPE_BIZIBLE_TOUCHPOINT_NOLEADTOUCHPOINTS_COUNT_INFLUENCE_OPPCLS,
				--20250302
                CASE
                    WHEN infl_data.MARKETING_TOUCHPOINT_DATE <= amlh_opp.OPP_CLOSE_DATE
                    AND infl_data.INTERACTIONTYPE_BIZIBLE_TOUCHPOINT_MARKETO_COUNT > 0 THEN infl_data.INTERACTIONTYPE_BIZIBLE_TOUCHPOINT_MARKETO_COUNT
                    ELSE 0
                END AS INTERACTIONTYPE_BIZIBLE_TOUCHPOINT_MARKETO_COUNT_INFLUENCE_OPPCLS,
				--20250314
                CASE
                    WHEN infl_data.MARKETING_TOUCHPOINT_DATE <= amlh_opp.OPP_CLOSE_DATE
                    AND infl_data.INTERACTIONTYPE_BIZIBLE_TOUCHPOINT_SEISMICENGAGEMENT_COUNT > 0 THEN infl_data.INTERACTIONTYPE_BIZIBLE_TOUCHPOINT_SEISMICENGAGEMENT_COUNT
                    ELSE 0
                END AS INTERACTIONTYPE_BIZIBLE_TOUCHPOINT_SEISMICENGAGEMENT_COUNT_INFLUENCE_OPPCLS,
                CASE
                    WHEN infl_data.MARKETING_TOUCHPOINT_DATE <= amlh_opp.OPP_CLOSE_DATE
                    AND infl_data.INTERACTIONTYPE_BIZIBLE_TOUCHPOINT_CHANGESTATUS_COUNT > 0 THEN infl_data.INTERACTIONTYPE_BIZIBLE_TOUCHPOINT_CHANGESTATUS_COUNT
                    ELSE 0
                END AS INTERACTIONTYPE_BIZIBLE_TOUCHPOINT_CHANGESTATUS_COUNT_INFLUENCE_OPPCLS,
                CASE
                    WHEN infl_data.MARKETING_TOUCHPOINT_DATE <= amlh_opp.OPP_CLOSE_DATE
                    AND infl_data.INTERACTIONTYPE_BIZIBLE_TOUCHPOINT_UNCLASSIFIED_COUNT > 0 THEN infl_data.INTERACTIONTYPE_BIZIBLE_TOUCHPOINT_UNCLASSIFIED_COUNT
                    ELSE 0
                END AS INTERACTIONTYPE_BIZIBLE_TOUCHPOINT_UNCLASSIFIED_COUNT_INFLUENCE_OPPCLS,
                -- SUM COUNTS INFLUENCE
                -- Influenced Before Account Cold
                CASE
                    WHEN infl_data.MARKETING_TOUCHPOINT_DATE <= amlh_opp.AMLH_COLD_ACCOUNT_DATE_STAMP__C
                    AND infl_data.INTERACTIONTYPE_SIXSENSE_PAIDMEDIA_IMPRESSIONS_COUNT > 0 THEN infl_data.INTERACTIONTYPE_SIXSENSE_PAIDMEDIA_IMPRESSIONS_COUNT
                    ELSE 0
                END AS INTERACTIONTYPE_SIXSENSE_PAIDMEDIA_IMPRESSIONS_COUNT_INFLUENCE_ACTCOLD,
                CASE
                    WHEN infl_data.MARKETING_TOUCHPOINT_DATE <= amlh_opp.AMLH_COLD_ACCOUNT_DATE_STAMP__C
                    AND infl_data.INTERACTIONTYPE_SIXSENSE_PAIDMEDIA_CLICKS_COUNT > 0 THEN infl_data.INTERACTIONTYPE_SIXSENSE_PAIDMEDIA_CLICKS_COUNT
                    ELSE 0
                END AS INTERACTIONTYPE_SIXSENSE_PAIDMEDIA_CLICKS_COUNT_INFLUENCE_ACTCOLD,
                CASE
                    WHEN infl_data.MARKETING_TOUCHPOINT_DATE <= amlh_opp.AMLH_COLD_ACCOUNT_DATE_STAMP__C
                    AND infl_data.INTERACTIONTYPE_SIXSENSE_WEBVISIT_TOTAL_INTERACTIONS_COUNT > 0 THEN infl_data.INTERACTIONTYPE_SIXSENSE_WEBVISIT_TOTAL_INTERACTIONS_COUNT
                    ELSE 0
                END AS INTERACTIONTYPE_SIXSENSE_WEBVISIT_TOTAL_INTERACTIONS_COUNT_INFLUENCE_ACTCOLD,
                CASE
                    WHEN infl_data.MARKETING_TOUCHPOINT_DATE <= amlh_opp.AMLH_COLD_ACCOUNT_DATE_STAMP__C
                    AND infl_data.INTERACTIONTYPE_SIXSENSE_WEBVISIT_PAGELOAD_COUNT > 0 THEN infl_data.INTERACTIONTYPE_SIXSENSE_WEBVISIT_PAGELOAD_COUNT
                    ELSE 0
                END AS INTERACTIONTYPE_SIXSENSE_WEBVISIT_PAGELOAD_COUNT_INFLUENCE_ACTCOLD,
                CASE
                    WHEN infl_data.MARKETING_TOUCHPOINT_DATE <= amlh_opp.AMLH_COLD_ACCOUNT_DATE_STAMP__C
                    AND infl_data.INTERACTIONTYPE_SIXSENSE_WEBVISIT_PLAY_COUNT > 0 THEN infl_data.INTERACTIONTYPE_SIXSENSE_WEBVISIT_PLAY_COUNT
                    ELSE 0
                END AS INTERACTIONTYPE_SIXSENSE_WEBVISIT_PLAY_COUNT_INFLUENCE_ACTCOLD,
                CASE
                    WHEN infl_data.MARKETING_TOUCHPOINT_DATE <= amlh_opp.AMLH_COLD_ACCOUNT_DATE_STAMP__C
                    AND infl_data.INTERACTIONTYPE_SIXSENSE_WEBVISIT_CLICK_COUNT > 0 THEN infl_data.INTERACTIONTYPE_SIXSENSE_WEBVISIT_CLICK_COUNT
                    ELSE 0
                END AS INTERACTIONTYPE_SIXSENSE_WEBVISIT_CLICK_COUNT_INFLUENCE_ACTCOLD,
                CASE
                    WHEN infl_data.MARKETING_TOUCHPOINT_DATE <= amlh_opp.AMLH_COLD_ACCOUNT_DATE_STAMP__C
                    AND infl_data.INTERACTIONTYPE_SIXSENSE_WEBVISIT_SUBMIT_COUNT > 0 THEN infl_data.INTERACTIONTYPE_SIXSENSE_WEBVISIT_SUBMIT_COUNT
                    ELSE 0
                END AS INTERACTIONTYPE_SIXSENSE_WEBVISIT_SUBMIT_COUNT_INFLUENCE_ACTCOLD,
                CASE
                    WHEN infl_data.MARKETING_TOUCHPOINT_DATE <= amlh_opp.AMLH_COLD_ACCOUNT_DATE_STAMP__C
                    AND infl_data.INTERACTIONTYPE_SIXSENSE_WEBVISIT_UNCLASSIFIED_COUNT > 0 THEN infl_data.INTERACTIONTYPE_SIXSENSE_WEBVISIT_UNCLASSIFIED_COUNT
                    ELSE 0
                END AS INTERACTIONTYPE_SIXSENSE_WEBVISIT_UNCLASSIFIED_COUNT_INFLUENCE_ACTCOLD,
                CASE
                    WHEN infl_data.MARKETING_TOUCHPOINT_DATE <= amlh_opp.AMLH_COLD_ACCOUNT_DATE_STAMP__C
                    AND infl_data.INTERACTIONTYPE_BIZIBLE_TOUCHPOINT_WEBVISIT_COUNT > 0 THEN infl_data.INTERACTIONTYPE_BIZIBLE_TOUCHPOINT_WEBVISIT_COUNT
                    ELSE 0
                END AS INTERACTIONTYPE_BIZIBLE_TOUCHPOINT_WEBVISIT_COUNT_INFLUENCE_ACTCOLD,
                CASE
                    WHEN infl_data.MARKETING_TOUCHPOINT_DATE <= amlh_opp.AMLH_COLD_ACCOUNT_DATE_STAMP__C
                    AND infl_data.INTERACTIONTYPE_BIZIBLE_TOUCHPOINT_WEBCHAT_COUNT > 0 THEN infl_data.INTERACTIONTYPE_BIZIBLE_TOUCHPOINT_WEBCHAT_COUNT
                    ELSE 0
                END AS INTERACTIONTYPE_BIZIBLE_TOUCHPOINT_WEBCHAT_COUNT_INFLUENCE_ACTCOLD,
                CASE
                    WHEN infl_data.MARKETING_TOUCHPOINT_DATE <= amlh_opp.AMLH_COLD_ACCOUNT_DATE_STAMP__C
                    AND infl_data.INTERACTIONTYPE_BIZIBLE_TOUCHPOINT_WEBFORM_COUNT > 0 THEN infl_data.INTERACTIONTYPE_BIZIBLE_TOUCHPOINT_WEBFORM_COUNT
                    ELSE 0
                END AS INTERACTIONTYPE_BIZIBLE_TOUCHPOINT_WEBFORM_COUNT_INFLUENCE_ACTCOLD,
                CASE
                    WHEN infl_data.MARKETING_TOUCHPOINT_DATE <= amlh_opp.AMLH_COLD_ACCOUNT_DATE_STAMP__C
                    AND infl_data.INTERACTIONTYPE_BIZIBLE_TOUCHPOINT_CRM_COUNT > 0 THEN infl_data.INTERACTIONTYPE_BIZIBLE_TOUCHPOINT_CRM_COUNT
                    ELSE 0
                END AS INTERACTIONTYPE_BIZIBLE_TOUCHPOINT_CRM_COUNT_INFLUENCE_ACTCOLD,
                CASE
                    WHEN infl_data.MARKETING_TOUCHPOINT_DATE <= amlh_opp.AMLH_COLD_ACCOUNT_DATE_STAMP__C
                    AND infl_data.INTERACTIONTYPE_BIZIBLE_TOUCHPOINT_CONNECTWITHDM_COUNT > 0 THEN infl_data.INTERACTIONTYPE_BIZIBLE_TOUCHPOINT_CONNECTWITHDM_COUNT
                    ELSE 0
                END AS INTERACTIONTYPE_BIZIBLE_TOUCHPOINT_CONNECTWITHDM_COUNT_INFLUENCE_ACTCOLD,
                CASE
                    WHEN infl_data.MARKETING_TOUCHPOINT_DATE <= amlh_opp.AMLH_COLD_ACCOUNT_DATE_STAMP__C
                    AND infl_data.INTERACTIONTYPE_BIZIBLE_TOUCHPOINT_CALLSPOKEWITH_COUNT > 0 THEN infl_data.INTERACTIONTYPE_BIZIBLE_TOUCHPOINT_CALLSPOKEWITH_COUNT
                    ELSE 0
                END AS INTERACTIONTYPE_BIZIBLE_TOUCHPOINT_CALLSPOKEWITH_COUNT_INFLUENCE_ACTCOLD,
                CASE
                    WHEN infl_data.MARKETING_TOUCHPOINT_DATE <= amlh_opp.AMLH_COLD_ACCOUNT_DATE_STAMP__C
                    AND infl_data.INTERACTIONTYPE_BIZIBLE_TOUCHPOINT_CALLGATEKEEPER_COUNT > 0 THEN infl_data.INTERACTIONTYPE_BIZIBLE_TOUCHPOINT_CALLGATEKEEPER_COUNT
                    ELSE 0
                END AS INTERACTIONTYPE_BIZIBLE_TOUCHPOINT_CALLGATEKEEPER_COUNT_INFLUENCE_ACTCOLD,
                CASE
                    WHEN infl_data.MARKETING_TOUCHPOINT_DATE <= amlh_opp.AMLH_COLD_ACCOUNT_DATE_STAMP__C
                    AND infl_data.INTERACTIONTYPE_BIZIBLE_TOUCHPOINT_NOLEADTOUCHPOINTS_COUNT > 0 THEN infl_data.INTERACTIONTYPE_BIZIBLE_TOUCHPOINT_NOLEADTOUCHPOINTS_COUNT
                    ELSE 0
                END AS INTERACTIONTYPE_BIZIBLE_TOUCHPOINT_NOLEADTOUCHPOINTS_COUNT_INFLUENCE_ACTCOLD,
				--20250302
                CASE
                    WHEN infl_data.MARKETING_TOUCHPOINT_DATE <= amlh_opp.AMLH_COLD_ACCOUNT_DATE_STAMP__C
                    AND infl_data.INTERACTIONTYPE_BIZIBLE_TOUCHPOINT_MARKETO_COUNT > 0 THEN infl_data.INTERACTIONTYPE_BIZIBLE_TOUCHPOINT_MARKETO_COUNT
                    ELSE 0
                END AS INTERACTIONTYPE_BIZIBLE_TOUCHPOINT_MARKETO_COUNT_INFLUENCE_ACTCOLD,
				--20250314
                CASE
                    WHEN infl_data.MARKETING_TOUCHPOINT_DATE <= amlh_opp.AMLH_COLD_ACCOUNT_DATE_STAMP__C
                    AND infl_data.INTERACTIONTYPE_BIZIBLE_TOUCHPOINT_SEISMICENGAGEMENT_COUNT > 0 THEN infl_data.INTERACTIONTYPE_BIZIBLE_TOUCHPOINT_SEISMICENGAGEMENT_COUNT
                    ELSE 0
                END AS INTERACTIONTYPE_BIZIBLE_TOUCHPOINT_SEISMICENGAGEMENT_COUNT_INFLUENCE_ACTCOLD,
                CASE
                    WHEN infl_data.MARKETING_TOUCHPOINT_DATE <= amlh_opp.AMLH_COLD_ACCOUNT_DATE_STAMP__C
                    AND infl_data.INTERACTIONTYPE_BIZIBLE_TOUCHPOINT_CHANGESTATUS_COUNT > 0 THEN infl_data.INTERACTIONTYPE_BIZIBLE_TOUCHPOINT_CHANGESTATUS_COUNT
                    ELSE 0
                END AS INTERACTIONTYPE_BIZIBLE_TOUCHPOINT_CHANGESTATUS_COUNT_INFLUENCE_ACTCOLD,
                CASE
                    WHEN infl_data.MARKETING_TOUCHPOINT_DATE <= amlh_opp.AMLH_COLD_ACCOUNT_DATE_STAMP__C
                    AND infl_data.INTERACTIONTYPE_BIZIBLE_TOUCHPOINT_UNCLASSIFIED_COUNT > 0 THEN infl_data.INTERACTIONTYPE_BIZIBLE_TOUCHPOINT_UNCLASSIFIED_COUNT
                    ELSE 0
                END AS INTERACTIONTYPE_BIZIBLE_TOUCHPOINT_UNCLASSIFIED_COUNT_INFLUENCE_ACTCOLD,
                -- SUM COUNTS INFLUENCE
                -- Influenced Before Account MEA
                CASE
                    WHEN infl_data.MARKETING_TOUCHPOINT_DATE <= amlh_opp.AMLH_MEA_DATE_STAMP__C
                    AND infl_data.INTERACTIONTYPE_SIXSENSE_PAIDMEDIA_IMPRESSIONS_COUNT > 0 THEN infl_data.INTERACTIONTYPE_SIXSENSE_PAIDMEDIA_IMPRESSIONS_COUNT
                    ELSE 0
                END AS INTERACTIONTYPE_SIXSENSE_PAIDMEDIA_IMPRESSIONS_COUNT_INFLUENCE_ACTMEA,
                CASE
                    WHEN infl_data.MARKETING_TOUCHPOINT_DATE <= amlh_opp.AMLH_MEA_DATE_STAMP__C
                    AND infl_data.INTERACTIONTYPE_SIXSENSE_PAIDMEDIA_CLICKS_COUNT > 0 THEN infl_data.INTERACTIONTYPE_SIXSENSE_PAIDMEDIA_CLICKS_COUNT
                    ELSE 0
                END AS INTERACTIONTYPE_SIXSENSE_PAIDMEDIA_CLICKS_COUNT_INFLUENCE_ACTMEA,
                CASE
                    WHEN infl_data.MARKETING_TOUCHPOINT_DATE <= amlh_opp.AMLH_MEA_DATE_STAMP__C
                    AND infl_data.INTERACTIONTYPE_SIXSENSE_WEBVISIT_TOTAL_INTERACTIONS_COUNT > 0 THEN infl_data.INTERACTIONTYPE_SIXSENSE_WEBVISIT_TOTAL_INTERACTIONS_COUNT
                    ELSE 0
                END AS INTERACTIONTYPE_SIXSENSE_WEBVISIT_TOTAL_INTERACTIONS_COUNT_INFLUENCE_ACTMEA,
                CASE
                    WHEN infl_data.MARKETING_TOUCHPOINT_DATE <= amlh_opp.AMLH_MEA_DATE_STAMP__C
                    AND infl_data.INTERACTIONTYPE_SIXSENSE_WEBVISIT_PAGELOAD_COUNT > 0 THEN infl_data.INTERACTIONTYPE_SIXSENSE_WEBVISIT_PAGELOAD_COUNT
                    ELSE 0
                END AS INTERACTIONTYPE_SIXSENSE_WEBVISIT_PAGELOAD_COUNT_INFLUENCE_ACTMEA,
                CASE
                    WHEN infl_data.MARKETING_TOUCHPOINT_DATE <= amlh_opp.AMLH_MEA_DATE_STAMP__C
                    AND infl_data.INTERACTIONTYPE_SIXSENSE_WEBVISIT_PLAY_COUNT > 0 THEN infl_data.INTERACTIONTYPE_SIXSENSE_WEBVISIT_PLAY_COUNT
                    ELSE 0
                END AS INTERACTIONTYPE_SIXSENSE_WEBVISIT_PLAY_COUNT_INFLUENCE_ACTMEA,
                CASE
                    WHEN infl_data.MARKETING_TOUCHPOINT_DATE <= amlh_opp.AMLH_MEA_DATE_STAMP__C
                    AND infl_data.INTERACTIONTYPE_SIXSENSE_WEBVISIT_CLICK_COUNT > 0 THEN infl_data.INTERACTIONTYPE_SIXSENSE_WEBVISIT_CLICK_COUNT
                    ELSE 0
                END AS INTERACTIONTYPE_SIXSENSE_WEBVISIT_CLICK_COUNT_INFLUENCE_ACTMEA,
                CASE
                    WHEN infl_data.MARKETING_TOUCHPOINT_DATE <= amlh_opp.AMLH_MEA_DATE_STAMP__C
                    AND infl_data.INTERACTIONTYPE_SIXSENSE_WEBVISIT_SUBMIT_COUNT > 0 THEN infl_data.INTERACTIONTYPE_SIXSENSE_WEBVISIT_SUBMIT_COUNT
                    ELSE 0
                END AS INTERACTIONTYPE_SIXSENSE_WEBVISIT_SUBMIT_COUNT_INFLUENCE_ACTMEA,
                CASE
                    WHEN infl_data.MARKETING_TOUCHPOINT_DATE <= amlh_opp.AMLH_MEA_DATE_STAMP__C
                    AND infl_data.INTERACTIONTYPE_SIXSENSE_WEBVISIT_UNCLASSIFIED_COUNT > 0 THEN infl_data.INTERACTIONTYPE_SIXSENSE_WEBVISIT_UNCLASSIFIED_COUNT
                    ELSE 0
                END AS INTERACTIONTYPE_SIXSENSE_WEBVISIT_UNCLASSIFIED_COUNT_INFLUENCE_ACTMEA,
                CASE
                    WHEN infl_data.MARKETING_TOUCHPOINT_DATE <= amlh_opp.AMLH_MEA_DATE_STAMP__C
                    AND infl_data.INTERACTIONTYPE_BIZIBLE_TOUCHPOINT_WEBVISIT_COUNT > 0 THEN infl_data.INTERACTIONTYPE_BIZIBLE_TOUCHPOINT_WEBVISIT_COUNT
                    ELSE 0
                END AS INTERACTIONTYPE_BIZIBLE_TOUCHPOINT_WEBVISIT_COUNT_INFLUENCE_ACTMEA,
                CASE
                    WHEN infl_data.MARKETING_TOUCHPOINT_DATE <= amlh_opp.AMLH_MEA_DATE_STAMP__C
                    AND infl_data.INTERACTIONTYPE_BIZIBLE_TOUCHPOINT_WEBCHAT_COUNT > 0 THEN infl_data.INTERACTIONTYPE_BIZIBLE_TOUCHPOINT_WEBCHAT_COUNT
                    ELSE 0
                END AS INTERACTIONTYPE_BIZIBLE_TOUCHPOINT_WEBCHAT_COUNT_INFLUENCE_ACTMEA,
                CASE
                    WHEN infl_data.MARKETING_TOUCHPOINT_DATE <= amlh_opp.AMLH_MEA_DATE_STAMP__C
                    AND infl_data.INTERACTIONTYPE_BIZIBLE_TOUCHPOINT_WEBFORM_COUNT > 0 THEN infl_data.INTERACTIONTYPE_BIZIBLE_TOUCHPOINT_WEBFORM_COUNT
                    ELSE 0
                END AS INTERACTIONTYPE_BIZIBLE_TOUCHPOINT_WEBFORM_COUNT_INFLUENCE_ACTMEA,
                CASE
                    WHEN infl_data.MARKETING_TOUCHPOINT_DATE <= amlh_opp.AMLH_MEA_DATE_STAMP__C
                    AND infl_data.INTERACTIONTYPE_BIZIBLE_TOUCHPOINT_CRM_COUNT > 0 THEN infl_data.INTERACTIONTYPE_BIZIBLE_TOUCHPOINT_CRM_COUNT
                    ELSE 0
                END AS INTERACTIONTYPE_BIZIBLE_TOUCHPOINT_CRM_COUNT_INFLUENCE_ACTMEA,
                CASE
                    WHEN infl_data.MARKETING_TOUCHPOINT_DATE <= amlh_opp.AMLH_MEA_DATE_STAMP__C
                    AND infl_data.INTERACTIONTYPE_BIZIBLE_TOUCHPOINT_CONNECTWITHDM_COUNT > 0 THEN infl_data.INTERACTIONTYPE_BIZIBLE_TOUCHPOINT_CONNECTWITHDM_COUNT
                    ELSE 0
                END AS INTERACTIONTYPE_BIZIBLE_TOUCHPOINT_CONNECTWITHDM_COUNT_INFLUENCE_ACTMEA,
                CASE
                    WHEN infl_data.MARKETING_TOUCHPOINT_DATE <= amlh_opp.AMLH_MEA_DATE_STAMP__C
                    AND infl_data.INTERACTIONTYPE_BIZIBLE_TOUCHPOINT_CALLSPOKEWITH_COUNT > 0 THEN infl_data.INTERACTIONTYPE_BIZIBLE_TOUCHPOINT_CALLSPOKEWITH_COUNT
                    ELSE 0
                END AS INTERACTIONTYPE_BIZIBLE_TOUCHPOINT_CALLSPOKEWITH_COUNT_INFLUENCE_ACTMEA,
                CASE
                    WHEN infl_data.MARKETING_TOUCHPOINT_DATE <= amlh_opp.AMLH_MEA_DATE_STAMP__C
                    AND infl_data.INTERACTIONTYPE_BIZIBLE_TOUCHPOINT_CALLGATEKEEPER_COUNT > 0 THEN infl_data.INTERACTIONTYPE_BIZIBLE_TOUCHPOINT_CALLGATEKEEPER_COUNT
                    ELSE 0
                END AS INTERACTIONTYPE_BIZIBLE_TOUCHPOINT_CALLGATEKEEPER_COUNT_INFLUENCE_ACTMEA,
                CASE
                    WHEN infl_data.MARKETING_TOUCHPOINT_DATE <= amlh_opp.AMLH_MEA_DATE_STAMP__C
                    AND infl_data.INTERACTIONTYPE_BIZIBLE_TOUCHPOINT_NOLEADTOUCHPOINTS_COUNT > 0 THEN infl_data.INTERACTIONTYPE_BIZIBLE_TOUCHPOINT_NOLEADTOUCHPOINTS_COUNT
                    ELSE 0
                END AS INTERACTIONTYPE_BIZIBLE_TOUCHPOINT_NOLEADTOUCHPOINTS_COUNT_INFLUENCE_ACTMEA,
				--20250302
                CASE
                    WHEN infl_data.MARKETING_TOUCHPOINT_DATE <= amlh_opp.AMLH_MEA_DATE_STAMP__C
                    AND infl_data.INTERACTIONTYPE_BIZIBLE_TOUCHPOINT_MARKETO_COUNT > 0 THEN infl_data.INTERACTIONTYPE_BIZIBLE_TOUCHPOINT_MARKETO_COUNT
                    ELSE 0
                END AS INTERACTIONTYPE_BIZIBLE_TOUCHPOINT_MARKETO_COUNT_INFLUENCE_ACTMEA,
				--20250302
                CASE
                    WHEN infl_data.MARKETING_TOUCHPOINT_DATE <= amlh_opp.AMLH_MEA_DATE_STAMP__C
                    AND infl_data.INTERACTIONTYPE_BIZIBLE_TOUCHPOINT_SEISMICENGAGEMENT_COUNT > 0 THEN infl_data.INTERACTIONTYPE_BIZIBLE_TOUCHPOINT_SEISMICENGAGEMENT_COUNT
                    ELSE 0
                END AS INTERACTIONTYPE_BIZIBLE_TOUCHPOINT_SEISMICENGAGEMENT_COUNT_INFLUENCE_ACTMEA,
                CASE
                    WHEN infl_data.MARKETING_TOUCHPOINT_DATE <= amlh_opp.AMLH_MEA_DATE_STAMP__C
                    AND infl_data.INTERACTIONTYPE_BIZIBLE_TOUCHPOINT_CHANGESTATUS_COUNT > 0 THEN infl_data.INTERACTIONTYPE_BIZIBLE_TOUCHPOINT_CHANGESTATUS_COUNT
                    ELSE 0
                END AS INTERACTIONTYPE_BIZIBLE_TOUCHPOINT_CHANGESTATUS_COUNT_INFLUENCE_ACTMEA,
                CASE
                    WHEN infl_data.MARKETING_TOUCHPOINT_DATE <= amlh_opp.AMLH_MEA_DATE_STAMP__C
                    AND infl_data.INTERACTIONTYPE_BIZIBLE_TOUCHPOINT_UNCLASSIFIED_COUNT > 0 THEN infl_data.INTERACTIONTYPE_BIZIBLE_TOUCHPOINT_UNCLASSIFIED_COUNT
                    ELSE 0
                END AS INTERACTIONTYPE_BIZIBLE_TOUCHPOINT_UNCLASSIFIED_COUNT_INFLUENCE_ACTMEA,
                -- SUM COUNTS INFLUENCE
                -- Influenced Before Account MQA
                CASE
                    WHEN infl_data.MARKETING_TOUCHPOINT_DATE <= amlh_opp.AMLH_MQA_DATE_STAMP__C
                    AND infl_data.INTERACTIONTYPE_SIXSENSE_PAIDMEDIA_IMPRESSIONS_COUNT > 0 THEN infl_data.INTERACTIONTYPE_SIXSENSE_PAIDMEDIA_IMPRESSIONS_COUNT
                    ELSE 0
                END AS INTERACTIONTYPE_SIXSENSE_PAIDMEDIA_IMPRESSIONS_COUNT_INFLUENCE_ACTMQA,
                CASE
                    WHEN infl_data.MARKETING_TOUCHPOINT_DATE <= amlh_opp.AMLH_MQA_DATE_STAMP__C
                    AND infl_data.INTERACTIONTYPE_SIXSENSE_PAIDMEDIA_CLICKS_COUNT > 0 THEN infl_data.INTERACTIONTYPE_SIXSENSE_PAIDMEDIA_CLICKS_COUNT
                    ELSE 0
                END AS INTERACTIONTYPE_SIXSENSE_PAIDMEDIA_CLICKS_COUNT_INFLUENCE_ACTMQA,
                CASE
                    WHEN infl_data.MARKETING_TOUCHPOINT_DATE <= amlh_opp.AMLH_MQA_DATE_STAMP__C
                    AND infl_data.INTERACTIONTYPE_SIXSENSE_WEBVISIT_TOTAL_INTERACTIONS_COUNT > 0 THEN infl_data.INTERACTIONTYPE_SIXSENSE_WEBVISIT_TOTAL_INTERACTIONS_COUNT
                    ELSE 0
                END AS INTERACTIONTYPE_SIXSENSE_WEBVISIT_TOTAL_INTERACTIONS_COUNT_INFLUENCE_ACTMQA,
                CASE
                    WHEN infl_data.MARKETING_TOUCHPOINT_DATE <= amlh_opp.AMLH_MQA_DATE_STAMP__C
                    AND infl_data.INTERACTIONTYPE_SIXSENSE_WEBVISIT_PAGELOAD_COUNT > 0 THEN infl_data.INTERACTIONTYPE_SIXSENSE_WEBVISIT_PAGELOAD_COUNT
                    ELSE 0
                END AS INTERACTIONTYPE_SIXSENSE_WEBVISIT_PAGELOAD_COUNT_INFLUENCE_ACTMQA,
                CASE
                    WHEN infl_data.MARKETING_TOUCHPOINT_DATE <= amlh_opp.AMLH_MQA_DATE_STAMP__C
                    AND infl_data.INTERACTIONTYPE_SIXSENSE_WEBVISIT_PLAY_COUNT > 0 THEN infl_data.INTERACTIONTYPE_SIXSENSE_WEBVISIT_PLAY_COUNT
                    ELSE 0
                END AS INTERACTIONTYPE_SIXSENSE_WEBVISIT_PLAY_COUNT_INFLUENCE_ACTMQA,
                CASE
                    WHEN infl_data.MARKETING_TOUCHPOINT_DATE <= amlh_opp.AMLH_MQA_DATE_STAMP__C
                    AND infl_data.INTERACTIONTYPE_SIXSENSE_WEBVISIT_CLICK_COUNT > 0 THEN infl_data.INTERACTIONTYPE_SIXSENSE_WEBVISIT_CLICK_COUNT
                    ELSE 0
                END AS INTERACTIONTYPE_SIXSENSE_WEBVISIT_CLICK_COUNT_INFLUENCE_ACTMQA,
                CASE
                    WHEN infl_data.MARKETING_TOUCHPOINT_DATE <= amlh_opp.AMLH_MQA_DATE_STAMP__C
                    AND infl_data.INTERACTIONTYPE_SIXSENSE_WEBVISIT_SUBMIT_COUNT > 0 THEN infl_data.INTERACTIONTYPE_SIXSENSE_WEBVISIT_SUBMIT_COUNT
                    ELSE 0
                END AS INTERACTIONTYPE_SIXSENSE_WEBVISIT_SUBMIT_COUNT_INFLUENCE_ACTMQA,
                CASE
                    WHEN infl_data.MARKETING_TOUCHPOINT_DATE <= amlh_opp.AMLH_MQA_DATE_STAMP__C
                    AND infl_data.INTERACTIONTYPE_SIXSENSE_WEBVISIT_UNCLASSIFIED_COUNT > 0 THEN infl_data.INTERACTIONTYPE_SIXSENSE_WEBVISIT_UNCLASSIFIED_COUNT
                    ELSE 0
                END AS INTERACTIONTYPE_SIXSENSE_WEBVISIT_UNCLASSIFIED_COUNT_INFLUENCE_ACTMQA,
                CASE
                    WHEN infl_data.MARKETING_TOUCHPOINT_DATE <= amlh_opp.AMLH_MQA_DATE_STAMP__C
                    AND infl_data.INTERACTIONTYPE_BIZIBLE_TOUCHPOINT_WEBVISIT_COUNT > 0 THEN infl_data.INTERACTIONTYPE_BIZIBLE_TOUCHPOINT_WEBVISIT_COUNT
                    ELSE 0
                END AS INTERACTIONTYPE_BIZIBLE_TOUCHPOINT_WEBVISIT_COUNT_INFLUENCE_ACTMQA,
                CASE
                    WHEN infl_data.MARKETING_TOUCHPOINT_DATE <= amlh_opp.AMLH_MQA_DATE_STAMP__C
                    AND infl_data.INTERACTIONTYPE_BIZIBLE_TOUCHPOINT_WEBCHAT_COUNT > 0 THEN infl_data.INTERACTIONTYPE_BIZIBLE_TOUCHPOINT_WEBCHAT_COUNT
                    ELSE 0
                END AS INTERACTIONTYPE_BIZIBLE_TOUCHPOINT_WEBCHAT_COUNT_INFLUENCE_ACTMQA,
                CASE
                    WHEN infl_data.MARKETING_TOUCHPOINT_DATE <= amlh_opp.AMLH_MQA_DATE_STAMP__C
                    AND infl_data.INTERACTIONTYPE_BIZIBLE_TOUCHPOINT_WEBFORM_COUNT > 0 THEN infl_data.INTERACTIONTYPE_BIZIBLE_TOUCHPOINT_WEBFORM_COUNT
                    ELSE 0
                END AS INTERACTIONTYPE_BIZIBLE_TOUCHPOINT_WEBFORM_COUNT_INFLUENCE_ACTMQA,
                CASE
                    WHEN infl_data.MARKETING_TOUCHPOINT_DATE <= amlh_opp.AMLH_MQA_DATE_STAMP__C
                    AND infl_data.INTERACTIONTYPE_BIZIBLE_TOUCHPOINT_CRM_COUNT > 0 THEN infl_data.INTERACTIONTYPE_BIZIBLE_TOUCHPOINT_CRM_COUNT
                    ELSE 0
                END AS INTERACTIONTYPE_BIZIBLE_TOUCHPOINT_CRM_COUNT_INFLUENCE_ACTMQA,
                CASE
                    WHEN infl_data.MARKETING_TOUCHPOINT_DATE <= amlh_opp.AMLH_MQA_DATE_STAMP__C
                    AND infl_data.INTERACTIONTYPE_BIZIBLE_TOUCHPOINT_CONNECTWITHDM_COUNT > 0 THEN infl_data.INTERACTIONTYPE_BIZIBLE_TOUCHPOINT_CONNECTWITHDM_COUNT
                    ELSE 0
                END AS INTERACTIONTYPE_BIZIBLE_TOUCHPOINT_CONNECTWITHDM_COUNT_INFLUENCE_ACTMQA,
                CASE
                    WHEN infl_data.MARKETING_TOUCHPOINT_DATE <= amlh_opp.AMLH_MQA_DATE_STAMP__C
                    AND infl_data.INTERACTIONTYPE_BIZIBLE_TOUCHPOINT_CALLSPOKEWITH_COUNT > 0 THEN infl_data.INTERACTIONTYPE_BIZIBLE_TOUCHPOINT_CALLSPOKEWITH_COUNT
                    ELSE 0
                END AS INTERACTIONTYPE_BIZIBLE_TOUCHPOINT_CALLSPOKEWITH_COUNT_INFLUENCE_ACTMQA,
                CASE
                    WHEN infl_data.MARKETING_TOUCHPOINT_DATE <= amlh_opp.AMLH_MQA_DATE_STAMP__C
                    AND infl_data.INTERACTIONTYPE_BIZIBLE_TOUCHPOINT_CALLGATEKEEPER_COUNT > 0 THEN infl_data.INTERACTIONTYPE_BIZIBLE_TOUCHPOINT_CALLGATEKEEPER_COUNT
                    ELSE 0
                END AS INTERACTIONTYPE_BIZIBLE_TOUCHPOINT_CALLGATEKEEPER_COUNT_INFLUENCE_ACTMQA,
                CASE
                    WHEN infl_data.MARKETING_TOUCHPOINT_DATE <= amlh_opp.AMLH_MQA_DATE_STAMP__C
                    AND infl_data.INTERACTIONTYPE_BIZIBLE_TOUCHPOINT_NOLEADTOUCHPOINTS_COUNT > 0 THEN infl_data.INTERACTIONTYPE_BIZIBLE_TOUCHPOINT_NOLEADTOUCHPOINTS_COUNT
                    ELSE 0
                END AS INTERACTIONTYPE_BIZIBLE_TOUCHPOINT_NOLEADTOUCHPOINTS_COUNT_INFLUENCE_ACTMQA,
				--20250302
                CASE
                    WHEN infl_data.MARKETING_TOUCHPOINT_DATE <= amlh_opp.AMLH_MQA_DATE_STAMP__C
                    AND infl_data.INTERACTIONTYPE_BIZIBLE_TOUCHPOINT_MARKETO_COUNT > 0 THEN infl_data.INTERACTIONTYPE_BIZIBLE_TOUCHPOINT_MARKETO_COUNT
                    ELSE 0
                END AS INTERACTIONTYPE_BIZIBLE_TOUCHPOINT_MARKETO_COUNT_INFLUENCE_ACTMQA,
				--20250314
                CASE
                    WHEN infl_data.MARKETING_TOUCHPOINT_DATE <= amlh_opp.AMLH_MQA_DATE_STAMP__C
                    AND infl_data.INTERACTIONTYPE_BIZIBLE_TOUCHPOINT_SEISMICENGAGEMENT_COUNT > 0 THEN infl_data.INTERACTIONTYPE_BIZIBLE_TOUCHPOINT_SEISMICENGAGEMENT_COUNT
                    ELSE 0
                END AS INTERACTIONTYPE_BIZIBLE_TOUCHPOINT_SEISMICENGAGEMENT_COUNT_INFLUENCE_ACTMQA,
                CASE
                    WHEN infl_data.MARKETING_TOUCHPOINT_DATE <= amlh_opp.AMLH_MQA_DATE_STAMP__C
                    AND infl_data.INTERACTIONTYPE_BIZIBLE_TOUCHPOINT_CHANGESTATUS_COUNT > 0 THEN infl_data.INTERACTIONTYPE_BIZIBLE_TOUCHPOINT_CHANGESTATUS_COUNT
                    ELSE 0
                END AS INTERACTIONTYPE_BIZIBLE_TOUCHPOINT_CHANGESTATUS_COUNT_INFLUENCE_ACTMQA,
                CASE
                    WHEN infl_data.MARKETING_TOUCHPOINT_DATE <= amlh_opp.AMLH_MQA_DATE_STAMP__C
                    AND infl_data.INTERACTIONTYPE_BIZIBLE_TOUCHPOINT_UNCLASSIFIED_COUNT > 0 THEN infl_data.INTERACTIONTYPE_BIZIBLE_TOUCHPOINT_UNCLASSIFIED_COUNT
                    ELSE 0
                END AS INTERACTIONTYPE_BIZIBLE_TOUCHPOINT_UNCLASSIFIED_COUNT_INFLUENCE_ACTMQA,
                -- SUM COUNTS INFLUENCE
                -- Influenced Before Account Suspect
                CASE
                    WHEN infl_data.MARKETING_TOUCHPOINT_DATE <= amlh_opp.AMLH_SUSPECT_DATE_STAMP__C
                    AND infl_data.INTERACTIONTYPE_SIXSENSE_PAIDMEDIA_IMPRESSIONS_COUNT > 0 THEN infl_data.INTERACTIONTYPE_SIXSENSE_PAIDMEDIA_IMPRESSIONS_COUNT
                    ELSE 0
                END AS INTERACTIONTYPE_SIXSENSE_PAIDMEDIA_IMPRESSIONS_COUNT_INFLUENCE_ACTSUSPECT,
                CASE
                    WHEN infl_data.MARKETING_TOUCHPOINT_DATE <= amlh_opp.AMLH_SUSPECT_DATE_STAMP__C
                    AND infl_data.INTERACTIONTYPE_SIXSENSE_PAIDMEDIA_CLICKS_COUNT > 0 THEN infl_data.INTERACTIONTYPE_SIXSENSE_PAIDMEDIA_CLICKS_COUNT
                    ELSE 0
                END AS INTERACTIONTYPE_SIXSENSE_PAIDMEDIA_CLICKS_COUNT_INFLUENCE_ACTSUSPECT,
                CASE
                    WHEN infl_data.MARKETING_TOUCHPOINT_DATE <= amlh_opp.AMLH_SUSPECT_DATE_STAMP__C
                    AND infl_data.INTERACTIONTYPE_SIXSENSE_WEBVISIT_TOTAL_INTERACTIONS_COUNT > 0 THEN infl_data.INTERACTIONTYPE_SIXSENSE_WEBVISIT_TOTAL_INTERACTIONS_COUNT
                    ELSE 0
                END AS INTERACTIONTYPE_SIXSENSE_WEBVISIT_TOTAL_INTERACTIONS_COUNT_INFLUENCE_ACTSUSPECT,
                CASE
                    WHEN infl_data.MARKETING_TOUCHPOINT_DATE <= amlh_opp.AMLH_SUSPECT_DATE_STAMP__C
                    AND infl_data.INTERACTIONTYPE_SIXSENSE_WEBVISIT_PAGELOAD_COUNT > 0 THEN infl_data.INTERACTIONTYPE_SIXSENSE_WEBVISIT_PAGELOAD_COUNT
                    ELSE 0
                END AS INTERACTIONTYPE_SIXSENSE_WEBVISIT_PAGELOAD_COUNT_INFLUENCE_ACTSUSPECT,
                CASE
                    WHEN infl_data.MARKETING_TOUCHPOINT_DATE <= amlh_opp.AMLH_SUSPECT_DATE_STAMP__C
                    AND infl_data.INTERACTIONTYPE_SIXSENSE_WEBVISIT_PLAY_COUNT > 0 THEN infl_data.INTERACTIONTYPE_SIXSENSE_WEBVISIT_PLAY_COUNT
                    ELSE 0
                END AS INTERACTIONTYPE_SIXSENSE_WEBVISIT_PLAY_COUNT_INFLUENCE_ACTSUSPECT,
                CASE
                    WHEN infl_data.MARKETING_TOUCHPOINT_DATE <= amlh_opp.AMLH_SUSPECT_DATE_STAMP__C
                    AND infl_data.INTERACTIONTYPE_SIXSENSE_WEBVISIT_CLICK_COUNT > 0 THEN infl_data.INTERACTIONTYPE_SIXSENSE_WEBVISIT_CLICK_COUNT
                    ELSE 0
                END AS INTERACTIONTYPE_SIXSENSE_WEBVISIT_CLICK_COUNT_INFLUENCE_ACTSUSPECT,
                CASE
                    WHEN infl_data.MARKETING_TOUCHPOINT_DATE <= amlh_opp.AMLH_SUSPECT_DATE_STAMP__C
                    AND infl_data.INTERACTIONTYPE_SIXSENSE_WEBVISIT_SUBMIT_COUNT > 0 THEN infl_data.INTERACTIONTYPE_SIXSENSE_WEBVISIT_SUBMIT_COUNT
                    ELSE 0
                END AS INTERACTIONTYPE_SIXSENSE_WEBVISIT_SUBMIT_COUNT_INFLUENCE_ACTSUSPECT,
                CASE
                    WHEN infl_data.MARKETING_TOUCHPOINT_DATE <= amlh_opp.AMLH_SUSPECT_DATE_STAMP__C
                    AND infl_data.INTERACTIONTYPE_SIXSENSE_WEBVISIT_UNCLASSIFIED_COUNT > 0 THEN infl_data.INTERACTIONTYPE_SIXSENSE_WEBVISIT_UNCLASSIFIED_COUNT
                    ELSE 0
                END AS INTERACTIONTYPE_SIXSENSE_WEBVISIT_UNCLASSIFIED_COUNT_INFLUENCE_ACTSUSPECT,
                CASE
                    WHEN infl_data.MARKETING_TOUCHPOINT_DATE <= amlh_opp.AMLH_SUSPECT_DATE_STAMP__C
                    AND infl_data.INTERACTIONTYPE_BIZIBLE_TOUCHPOINT_WEBVISIT_COUNT > 0 THEN infl_data.INTERACTIONTYPE_BIZIBLE_TOUCHPOINT_WEBVISIT_COUNT
                    ELSE 0
                END AS INTERACTIONTYPE_BIZIBLE_TOUCHPOINT_WEBVISIT_COUNT_INFLUENCE_ACTSUSPECT,
                CASE
                    WHEN infl_data.MARKETING_TOUCHPOINT_DATE <= amlh_opp.AMLH_SUSPECT_DATE_STAMP__C
                    AND infl_data.INTERACTIONTYPE_BIZIBLE_TOUCHPOINT_WEBCHAT_COUNT > 0 THEN infl_data.INTERACTIONTYPE_BIZIBLE_TOUCHPOINT_WEBCHAT_COUNT
                    ELSE 0
                END AS INTERACTIONTYPE_BIZIBLE_TOUCHPOINT_WEBCHAT_COUNT_INFLUENCE_ACTSUSPECT,
                CASE
                    WHEN infl_data.MARKETING_TOUCHPOINT_DATE <= amlh_opp.AMLH_SUSPECT_DATE_STAMP__C
                    AND infl_data.INTERACTIONTYPE_BIZIBLE_TOUCHPOINT_WEBFORM_COUNT > 0 THEN infl_data.INTERACTIONTYPE_BIZIBLE_TOUCHPOINT_WEBFORM_COUNT
                    ELSE 0
                END AS INTERACTIONTYPE_BIZIBLE_TOUCHPOINT_WEBFORM_COUNT_INFLUENCE_ACTSUSPECT,
                CASE
                    WHEN infl_data.MARKETING_TOUCHPOINT_DATE <= amlh_opp.AMLH_SUSPECT_DATE_STAMP__C
                    AND infl_data.INTERACTIONTYPE_BIZIBLE_TOUCHPOINT_CRM_COUNT > 0 THEN infl_data.INTERACTIONTYPE_BIZIBLE_TOUCHPOINT_CRM_COUNT
                    ELSE 0
                END AS INTERACTIONTYPE_BIZIBLE_TOUCHPOINT_CRM_COUNT_INFLUENCE_ACTSUSPECT,
                CASE
                    WHEN infl_data.MARKETING_TOUCHPOINT_DATE <= amlh_opp.AMLH_SUSPECT_DATE_STAMP__C
                    AND infl_data.INTERACTIONTYPE_BIZIBLE_TOUCHPOINT_CONNECTWITHDM_COUNT > 0 THEN infl_data.INTERACTIONTYPE_BIZIBLE_TOUCHPOINT_CONNECTWITHDM_COUNT
                    ELSE 0
                END AS INTERACTIONTYPE_BIZIBLE_TOUCHPOINT_CONNECTWITHDM_COUNT_INFLUENCE_ACTSUSPECT,
                CASE
                    WHEN infl_data.MARKETING_TOUCHPOINT_DATE <= amlh_opp.AMLH_SUSPECT_DATE_STAMP__C
                    AND infl_data.INTERACTIONTYPE_BIZIBLE_TOUCHPOINT_CALLSPOKEWITH_COUNT > 0 THEN infl_data.INTERACTIONTYPE_BIZIBLE_TOUCHPOINT_CALLSPOKEWITH_COUNT
                    ELSE 0
                END AS INTERACTIONTYPE_BIZIBLE_TOUCHPOINT_CALLSPOKEWITH_COUNT_INFLUENCE_ACTSUSPECT,
                CASE
                    WHEN infl_data.MARKETING_TOUCHPOINT_DATE <= amlh_opp.AMLH_SUSPECT_DATE_STAMP__C
                    AND infl_data.INTERACTIONTYPE_BIZIBLE_TOUCHPOINT_CALLGATEKEEPER_COUNT > 0 THEN infl_data.INTERACTIONTYPE_BIZIBLE_TOUCHPOINT_CALLGATEKEEPER_COUNT
                    ELSE 0
                END AS INTERACTIONTYPE_BIZIBLE_TOUCHPOINT_CALLGATEKEEPER_COUNT_INFLUENCE_ACTSUSPECT,
                CASE
                    WHEN infl_data.MARKETING_TOUCHPOINT_DATE <= amlh_opp.AMLH_SUSPECT_DATE_STAMP__C
                    AND infl_data.INTERACTIONTYPE_BIZIBLE_TOUCHPOINT_NOLEADTOUCHPOINTS_COUNT > 0 THEN infl_data.INTERACTIONTYPE_BIZIBLE_TOUCHPOINT_NOLEADTOUCHPOINTS_COUNT
                    ELSE 0
                END AS INTERACTIONTYPE_BIZIBLE_TOUCHPOINT_NOLEADTOUCHPOINTS_COUNT_INFLUENCE_ACTSUSPECT,
				--20250302
                CASE
                    WHEN infl_data.MARKETING_TOUCHPOINT_DATE <= amlh_opp.AMLH_SUSPECT_DATE_STAMP__C
                    AND infl_data.INTERACTIONTYPE_BIZIBLE_TOUCHPOINT_MARKETO_COUNT > 0 THEN infl_data.INTERACTIONTYPE_BIZIBLE_TOUCHPOINT_MARKETO_COUNT
                    ELSE 0
                END AS INTERACTIONTYPE_BIZIBLE_TOUCHPOINT_MARKETO_COUNT_INFLUENCE_ACTSUSPECT,
				--20250314
                CASE
                    WHEN infl_data.MARKETING_TOUCHPOINT_DATE <= amlh_opp.AMLH_SUSPECT_DATE_STAMP__C
                    AND infl_data.INTERACTIONTYPE_BIZIBLE_TOUCHPOINT_SEISMICENGAGEMENT_COUNT > 0 THEN infl_data.INTERACTIONTYPE_BIZIBLE_TOUCHPOINT_SEISMICENGAGEMENT_COUNT
                    ELSE 0
                END AS INTERACTIONTYPE_BIZIBLE_TOUCHPOINT_SEISMICENGAGEMENT_COUNT_INFLUENCE_ACTSUSPECT,
                CASE
                    WHEN infl_data.MARKETING_TOUCHPOINT_DATE <= amlh_opp.AMLH_SUSPECT_DATE_STAMP__C
                    AND infl_data.INTERACTIONTYPE_BIZIBLE_TOUCHPOINT_CHANGESTATUS_COUNT > 0 THEN infl_data.INTERACTIONTYPE_BIZIBLE_TOUCHPOINT_CHANGESTATUS_COUNT
                    ELSE 0
                END AS INTERACTIONTYPE_BIZIBLE_TOUCHPOINT_CHANGESTATUS_COUNT_INFLUENCE_ACTSUSPECT,
                CASE
                    WHEN infl_data.MARKETING_TOUCHPOINT_DATE <= amlh_opp.AMLH_SUSPECT_DATE_STAMP__C
                    AND infl_data.INTERACTIONTYPE_BIZIBLE_TOUCHPOINT_UNCLASSIFIED_COUNT > 0 THEN infl_data.INTERACTIONTYPE_BIZIBLE_TOUCHPOINT_UNCLASSIFIED_COUNT
                    ELSE 0
                END AS INTERACTIONTYPE_BIZIBLE_TOUCHPOINT_UNCLASSIFIED_COUNT_INFLUENCE_ACTSUSPECT,
                -- SUM COUNTS INFLUENCE
                -- Influenced Before Account Prospect
                CASE
                    WHEN infl_data.MARKETING_TOUCHPOINT_DATE <= amlh_opp.AMLH_PROSPECT_DATE_STAMP__C
                    AND infl_data.INTERACTIONTYPE_SIXSENSE_PAIDMEDIA_IMPRESSIONS_COUNT > 0 THEN infl_data.INTERACTIONTYPE_SIXSENSE_PAIDMEDIA_IMPRESSIONS_COUNT
                    ELSE 0
                END AS INTERACTIONTYPE_SIXSENSE_PAIDMEDIA_IMPRESSIONS_COUNT_INFLUENCE_ACTPROSPECT,
                CASE
                    WHEN infl_data.MARKETING_TOUCHPOINT_DATE <= amlh_opp.AMLH_PROSPECT_DATE_STAMP__C
                    AND infl_data.INTERACTIONTYPE_SIXSENSE_PAIDMEDIA_CLICKS_COUNT > 0 THEN infl_data.INTERACTIONTYPE_SIXSENSE_PAIDMEDIA_CLICKS_COUNT
                    ELSE 0
                END AS INTERACTIONTYPE_SIXSENSE_PAIDMEDIA_CLICKS_COUNT_INFLUENCE_ACTPROSPECT,
                CASE
                    WHEN infl_data.MARKETING_TOUCHPOINT_DATE <= amlh_opp.AMLH_PROSPECT_DATE_STAMP__C
                    AND infl_data.INTERACTIONTYPE_SIXSENSE_WEBVISIT_TOTAL_INTERACTIONS_COUNT > 0 THEN infl_data.INTERACTIONTYPE_SIXSENSE_WEBVISIT_TOTAL_INTERACTIONS_COUNT
                    ELSE 0
                END AS INTERACTIONTYPE_SIXSENSE_WEBVISIT_TOTAL_INTERACTIONS_COUNT_INFLUENCE_ACTPROSPECT,
                CASE
                    WHEN infl_data.MARKETING_TOUCHPOINT_DATE <= amlh_opp.AMLH_PROSPECT_DATE_STAMP__C
                    AND infl_data.INTERACTIONTYPE_SIXSENSE_WEBVISIT_PAGELOAD_COUNT > 0 THEN infl_data.INTERACTIONTYPE_SIXSENSE_WEBVISIT_PAGELOAD_COUNT
                    ELSE 0
                END AS INTERACTIONTYPE_SIXSENSE_WEBVISIT_PAGELOAD_COUNT_INFLUENCE_ACTPROSPECT,
                CASE
                    WHEN infl_data.MARKETING_TOUCHPOINT_DATE <= amlh_opp.AMLH_PROSPECT_DATE_STAMP__C
                    AND infl_data.INTERACTIONTYPE_SIXSENSE_WEBVISIT_PLAY_COUNT > 0 THEN infl_data.INTERACTIONTYPE_SIXSENSE_WEBVISIT_PLAY_COUNT
                    ELSE 0
                END AS INTERACTIONTYPE_SIXSENSE_WEBVISIT_PLAY_COUNT_INFLUENCE_ACTPROSPECT,
                CASE
                    WHEN infl_data.MARKETING_TOUCHPOINT_DATE <= amlh_opp.AMLH_PROSPECT_DATE_STAMP__C
                    AND infl_data.INTERACTIONTYPE_SIXSENSE_WEBVISIT_CLICK_COUNT > 0 THEN infl_data.INTERACTIONTYPE_SIXSENSE_WEBVISIT_CLICK_COUNT
                    ELSE 0
                END AS INTERACTIONTYPE_SIXSENSE_WEBVISIT_CLICK_COUNT_INFLUENCE_ACTPROSPECT,
                CASE
                    WHEN infl_data.MARKETING_TOUCHPOINT_DATE <= amlh_opp.AMLH_PROSPECT_DATE_STAMP__C
                    AND infl_data.INTERACTIONTYPE_SIXSENSE_WEBVISIT_SUBMIT_COUNT > 0 THEN infl_data.INTERACTIONTYPE_SIXSENSE_WEBVISIT_SUBMIT_COUNT
                    ELSE 0
                END AS INTERACTIONTYPE_SIXSENSE_WEBVISIT_SUBMIT_COUNT_INFLUENCE_ACTPROSPECT,
                CASE
                    WHEN infl_data.MARKETING_TOUCHPOINT_DATE <= amlh_opp.AMLH_PROSPECT_DATE_STAMP__C
                    AND infl_data.INTERACTIONTYPE_SIXSENSE_WEBVISIT_UNCLASSIFIED_COUNT > 0 THEN infl_data.INTERACTIONTYPE_SIXSENSE_WEBVISIT_UNCLASSIFIED_COUNT
                    ELSE 0
                END AS INTERACTIONTYPE_SIXSENSE_WEBVISIT_UNCLASSIFIED_COUNT_INFLUENCE_ACTPROSPECT,
                CASE
                    WHEN infl_data.MARKETING_TOUCHPOINT_DATE <= amlh_opp.AMLH_PROSPECT_DATE_STAMP__C
                    AND infl_data.INTERACTIONTYPE_BIZIBLE_TOUCHPOINT_WEBVISIT_COUNT > 0 THEN infl_data.INTERACTIONTYPE_BIZIBLE_TOUCHPOINT_WEBVISIT_COUNT
                    ELSE 0
                END AS INTERACTIONTYPE_BIZIBLE_TOUCHPOINT_WEBVISIT_COUNT_INFLUENCE_ACTPROSPECT,
                CASE
                    WHEN infl_data.MARKETING_TOUCHPOINT_DATE <= amlh_opp.AMLH_PROSPECT_DATE_STAMP__C
                    AND infl_data.INTERACTIONTYPE_BIZIBLE_TOUCHPOINT_WEBCHAT_COUNT > 0 THEN infl_data.INTERACTIONTYPE_BIZIBLE_TOUCHPOINT_WEBCHAT_COUNT
                    ELSE 0
                END AS INTERACTIONTYPE_BIZIBLE_TOUCHPOINT_WEBCHAT_COUNT_INFLUENCE_ACTPROSPECT,
                CASE
                    WHEN infl_data.MARKETING_TOUCHPOINT_DATE <= amlh_opp.AMLH_PROSPECT_DATE_STAMP__C
                    AND infl_data.INTERACTIONTYPE_BIZIBLE_TOUCHPOINT_WEBFORM_COUNT > 0 THEN infl_data.INTERACTIONTYPE_BIZIBLE_TOUCHPOINT_WEBFORM_COUNT
                    ELSE 0
                END AS INTERACTIONTYPE_BIZIBLE_TOUCHPOINT_WEBFORM_COUNT_INFLUENCE_ACTPROSPECT,
                CASE
                    WHEN infl_data.MARKETING_TOUCHPOINT_DATE <= amlh_opp.AMLH_PROSPECT_DATE_STAMP__C
                    AND infl_data.INTERACTIONTYPE_BIZIBLE_TOUCHPOINT_CRM_COUNT > 0 THEN infl_data.INTERACTIONTYPE_BIZIBLE_TOUCHPOINT_CRM_COUNT
                    ELSE 0
                END AS INTERACTIONTYPE_BIZIBLE_TOUCHPOINT_CRM_COUNT_INFLUENCE_ACTPROSPECT,
                CASE
                    WHEN infl_data.MARKETING_TOUCHPOINT_DATE <= amlh_opp.AMLH_PROSPECT_DATE_STAMP__C
                    AND infl_data.INTERACTIONTYPE_BIZIBLE_TOUCHPOINT_CONNECTWITHDM_COUNT > 0 THEN infl_data.INTERACTIONTYPE_BIZIBLE_TOUCHPOINT_CONNECTWITHDM_COUNT
                    ELSE 0
                END AS INTERACTIONTYPE_BIZIBLE_TOUCHPOINT_CONNECTWITHDM_COUNT_INFLUENCE_ACTPROSPECT,
                CASE
                    WHEN infl_data.MARKETING_TOUCHPOINT_DATE <= amlh_opp.AMLH_PROSPECT_DATE_STAMP__C
                    AND infl_data.INTERACTIONTYPE_BIZIBLE_TOUCHPOINT_CALLSPOKEWITH_COUNT > 0 THEN infl_data.INTERACTIONTYPE_BIZIBLE_TOUCHPOINT_CALLSPOKEWITH_COUNT
                    ELSE 0
                END AS INTERACTIONTYPE_BIZIBLE_TOUCHPOINT_CALLSPOKEWITH_COUNT_INFLUENCE_ACTPROSPECT,
                CASE
                    WHEN infl_data.MARKETING_TOUCHPOINT_DATE <= amlh_opp.AMLH_PROSPECT_DATE_STAMP__C
                    AND infl_data.INTERACTIONTYPE_BIZIBLE_TOUCHPOINT_CALLGATEKEEPER_COUNT > 0 THEN infl_data.INTERACTIONTYPE_BIZIBLE_TOUCHPOINT_CALLGATEKEEPER_COUNT
                    ELSE 0
                END AS INTERACTIONTYPE_BIZIBLE_TOUCHPOINT_CALLGATEKEEPER_COUNT_INFLUENCE_ACTPROSPECT,
                CASE
                    WHEN infl_data.MARKETING_TOUCHPOINT_DATE <= amlh_opp.AMLH_PROSPECT_DATE_STAMP__C
                    AND infl_data.INTERACTIONTYPE_BIZIBLE_TOUCHPOINT_NOLEADTOUCHPOINTS_COUNT > 0 THEN infl_data.INTERACTIONTYPE_BIZIBLE_TOUCHPOINT_NOLEADTOUCHPOINTS_COUNT
                    ELSE 0
                END AS INTERACTIONTYPE_BIZIBLE_TOUCHPOINT_NOLEADTOUCHPOINTS_COUNT_INFLUENCE_ACTPROSPECT,
				--20250302
                CASE
                    WHEN infl_data.MARKETING_TOUCHPOINT_DATE <= amlh_opp.AMLH_PROSPECT_DATE_STAMP__C
                    AND infl_data.INTERACTIONTYPE_BIZIBLE_TOUCHPOINT_MARKETO_COUNT > 0 THEN infl_data.INTERACTIONTYPE_BIZIBLE_TOUCHPOINT_MARKETO_COUNT
                    ELSE 0
                END AS INTERACTIONTYPE_BIZIBLE_TOUCHPOINT_MARKETO_COUNT_INFLUENCE_ACTPROSPECT,
				--20250314
                CASE
                    WHEN infl_data.MARKETING_TOUCHPOINT_DATE <= amlh_opp.AMLH_PROSPECT_DATE_STAMP__C
                    AND infl_data.INTERACTIONTYPE_BIZIBLE_TOUCHPOINT_SEISMICENGAGEMENT_COUNT > 0 THEN infl_data.INTERACTIONTYPE_BIZIBLE_TOUCHPOINT_SEISMICENGAGEMENT_COUNT
                    ELSE 0
                END AS INTERACTIONTYPE_BIZIBLE_TOUCHPOINT_SEISMICENGAGEMENT_COUNT_INFLUENCE_ACTPROSPECT,
                CASE
                    WHEN infl_data.MARKETING_TOUCHPOINT_DATE <= amlh_opp.AMLH_PROSPECT_DATE_STAMP__C
                    AND infl_data.INTERACTIONTYPE_BIZIBLE_TOUCHPOINT_CHANGESTATUS_COUNT > 0 THEN infl_data.INTERACTIONTYPE_BIZIBLE_TOUCHPOINT_CHANGESTATUS_COUNT
                    ELSE 0
                END AS INTERACTIONTYPE_BIZIBLE_TOUCHPOINT_CHANGESTATUS_COUNT_INFLUENCE_ACTPROSPECT,
                CASE
                    WHEN infl_data.MARKETING_TOUCHPOINT_DATE <= amlh_opp.AMLH_PROSPECT_DATE_STAMP__C
                    AND infl_data.INTERACTIONTYPE_BIZIBLE_TOUCHPOINT_UNCLASSIFIED_COUNT > 0 THEN infl_data.INTERACTIONTYPE_BIZIBLE_TOUCHPOINT_UNCLASSIFIED_COUNT
                    ELSE 0
                END AS INTERACTIONTYPE_BIZIBLE_TOUCHPOINT_UNCLASSIFIED_COUNT_INFLUENCE_ACTPROSPECT,
				--20250314
                -- SUM COUNTS INFLUENCE
                -- Influenced Before Account Customer
                CASE
                    WHEN infl_data.MARKETING_TOUCHPOINT_DATE <= amlh_opp.AMLH_CUSTOMER_DATE_STAMP__C
                    AND infl_data.INTERACTIONTYPE_SIXSENSE_PAIDMEDIA_IMPRESSIONS_COUNT > 0 THEN infl_data.INTERACTIONTYPE_SIXSENSE_PAIDMEDIA_IMPRESSIONS_COUNT
                    ELSE 0
                END AS INTERACTIONTYPE_SIXSENSE_PAIDMEDIA_IMPRESSIONS_COUNT_INFLUENCE_ACTCUSTOMER,
                CASE
                    WHEN infl_data.MARKETING_TOUCHPOINT_DATE <= amlh_opp.AMLH_CUSTOMER_DATE_STAMP__C
                    AND infl_data.INTERACTIONTYPE_SIXSENSE_PAIDMEDIA_CLICKS_COUNT > 0 THEN infl_data.INTERACTIONTYPE_SIXSENSE_PAIDMEDIA_CLICKS_COUNT
                    ELSE 0
                END AS INTERACTIONTYPE_SIXSENSE_PAIDMEDIA_CLICKS_COUNT_INFLUENCE_ACTCUSTOMER,
                CASE
                    WHEN infl_data.MARKETING_TOUCHPOINT_DATE <= amlh_opp.AMLH_CUSTOMER_DATE_STAMP__C
                    AND infl_data.INTERACTIONTYPE_SIXSENSE_WEBVISIT_TOTAL_INTERACTIONS_COUNT > 0 THEN infl_data.INTERACTIONTYPE_SIXSENSE_WEBVISIT_TOTAL_INTERACTIONS_COUNT
                    ELSE 0
                END AS INTERACTIONTYPE_SIXSENSE_WEBVISIT_TOTAL_INTERACTIONS_COUNT_INFLUENCE_ACTCUSTOMER,
                CASE
                    WHEN infl_data.MARKETING_TOUCHPOINT_DATE <= amlh_opp.AMLH_CUSTOMER_DATE_STAMP__C
                    AND infl_data.INTERACTIONTYPE_SIXSENSE_WEBVISIT_PAGELOAD_COUNT > 0 THEN infl_data.INTERACTIONTYPE_SIXSENSE_WEBVISIT_PAGELOAD_COUNT
                    ELSE 0
                END AS INTERACTIONTYPE_SIXSENSE_WEBVISIT_PAGELOAD_COUNT_INFLUENCE_ACTCUSTOMER,
                CASE
                    WHEN infl_data.MARKETING_TOUCHPOINT_DATE <= amlh_opp.AMLH_CUSTOMER_DATE_STAMP__C
                    AND infl_data.INTERACTIONTYPE_SIXSENSE_WEBVISIT_PLAY_COUNT > 0 THEN infl_data.INTERACTIONTYPE_SIXSENSE_WEBVISIT_PLAY_COUNT
                    ELSE 0
                END AS INTERACTIONTYPE_SIXSENSE_WEBVISIT_PLAY_COUNT_INFLUENCE_ACTCUSTOMER,
                CASE
                    WHEN infl_data.MARKETING_TOUCHPOINT_DATE <= amlh_opp.AMLH_CUSTOMER_DATE_STAMP__C
                    AND infl_data.INTERACTIONTYPE_SIXSENSE_WEBVISIT_CLICK_COUNT > 0 THEN infl_data.INTERACTIONTYPE_SIXSENSE_WEBVISIT_CLICK_COUNT
                    ELSE 0
                END AS INTERACTIONTYPE_SIXSENSE_WEBVISIT_CLICK_COUNT_INFLUENCE_ACTCUSTOMER,
                CASE
                    WHEN infl_data.MARKETING_TOUCHPOINT_DATE <= amlh_opp.AMLH_CUSTOMER_DATE_STAMP__C
                    AND infl_data.INTERACTIONTYPE_SIXSENSE_WEBVISIT_SUBMIT_COUNT > 0 THEN infl_data.INTERACTIONTYPE_SIXSENSE_WEBVISIT_SUBMIT_COUNT
                    ELSE 0
                END AS INTERACTIONTYPE_SIXSENSE_WEBVISIT_SUBMIT_COUNT_INFLUENCE_ACTCUSTOMER,
                CASE
                    WHEN infl_data.MARKETING_TOUCHPOINT_DATE <= amlh_opp.AMLH_CUSTOMER_DATE_STAMP__C
                    AND infl_data.INTERACTIONTYPE_SIXSENSE_WEBVISIT_UNCLASSIFIED_COUNT > 0 THEN infl_data.INTERACTIONTYPE_SIXSENSE_WEBVISIT_UNCLASSIFIED_COUNT
                    ELSE 0
                END AS INTERACTIONTYPE_SIXSENSE_WEBVISIT_UNCLASSIFIED_COUNT_INFLUENCE_ACTCUSTOMER,
                CASE
                    WHEN infl_data.MARKETING_TOUCHPOINT_DATE <= amlh_opp.AMLH_CUSTOMER_DATE_STAMP__C
                    AND infl_data.INTERACTIONTYPE_BIZIBLE_TOUCHPOINT_WEBVISIT_COUNT > 0 THEN infl_data.INTERACTIONTYPE_BIZIBLE_TOUCHPOINT_WEBVISIT_COUNT
                    ELSE 0
                END AS INTERACTIONTYPE_BIZIBLE_TOUCHPOINT_WEBVISIT_COUNT_INFLUENCE_ACTCUSTOMER,
                CASE
                    WHEN infl_data.MARKETING_TOUCHPOINT_DATE <= amlh_opp.AMLH_CUSTOMER_DATE_STAMP__C
                    AND infl_data.INTERACTIONTYPE_BIZIBLE_TOUCHPOINT_WEBCHAT_COUNT > 0 THEN infl_data.INTERACTIONTYPE_BIZIBLE_TOUCHPOINT_WEBCHAT_COUNT
                    ELSE 0
                END AS INTERACTIONTYPE_BIZIBLE_TOUCHPOINT_WEBCHAT_COUNT_INFLUENCE_ACTCUSTOMER,
                CASE
                    WHEN infl_data.MARKETING_TOUCHPOINT_DATE <= amlh_opp.AMLH_CUSTOMER_DATE_STAMP__C
                    AND infl_data.INTERACTIONTYPE_BIZIBLE_TOUCHPOINT_WEBFORM_COUNT > 0 THEN infl_data.INTERACTIONTYPE_BIZIBLE_TOUCHPOINT_WEBFORM_COUNT
                    ELSE 0
                END AS INTERACTIONTYPE_BIZIBLE_TOUCHPOINT_WEBFORM_COUNT_INFLUENCE_ACTCUSTOMER,
                CASE
                    WHEN infl_data.MARKETING_TOUCHPOINT_DATE <= amlh_opp.AMLH_CUSTOMER_DATE_STAMP__C
                    AND infl_data.INTERACTIONTYPE_BIZIBLE_TOUCHPOINT_CRM_COUNT > 0 THEN infl_data.INTERACTIONTYPE_BIZIBLE_TOUCHPOINT_CRM_COUNT
                    ELSE 0
                END AS INTERACTIONTYPE_BIZIBLE_TOUCHPOINT_CRM_COUNT_INFLUENCE_ACTCUSTOMER,
                CASE
                    WHEN infl_data.MARKETING_TOUCHPOINT_DATE <= amlh_opp.AMLH_CUSTOMER_DATE_STAMP__C
                    AND infl_data.INTERACTIONTYPE_BIZIBLE_TOUCHPOINT_CONNECTWITHDM_COUNT > 0 THEN infl_data.INTERACTIONTYPE_BIZIBLE_TOUCHPOINT_CONNECTWITHDM_COUNT
                    ELSE 0
                END AS INTERACTIONTYPE_BIZIBLE_TOUCHPOINT_CONNECTWITHDM_COUNT_INFLUENCE_ACTCUSTOMER,
                CASE
                    WHEN infl_data.MARKETING_TOUCHPOINT_DATE <= amlh_opp.AMLH_CUSTOMER_DATE_STAMP__C
                    AND infl_data.INTERACTIONTYPE_BIZIBLE_TOUCHPOINT_CALLSPOKEWITH_COUNT > 0 THEN infl_data.INTERACTIONTYPE_BIZIBLE_TOUCHPOINT_CALLSPOKEWITH_COUNT
                    ELSE 0
                END AS INTERACTIONTYPE_BIZIBLE_TOUCHPOINT_CALLSPOKEWITH_COUNT_INFLUENCE_ACTCUSTOMER,
                CASE
                    WHEN infl_data.MARKETING_TOUCHPOINT_DATE <= amlh_opp.AMLH_CUSTOMER_DATE_STAMP__C
                    AND infl_data.INTERACTIONTYPE_BIZIBLE_TOUCHPOINT_CALLGATEKEEPER_COUNT > 0 THEN infl_data.INTERACTIONTYPE_BIZIBLE_TOUCHPOINT_CALLGATEKEEPER_COUNT
                    ELSE 0
                END AS INTERACTIONTYPE_BIZIBLE_TOUCHPOINT_CALLGATEKEEPER_COUNT_INFLUENCE_ACTCUSTOMER,
                CASE
                    WHEN infl_data.MARKETING_TOUCHPOINT_DATE <= amlh_opp.AMLH_CUSTOMER_DATE_STAMP__C
                    AND infl_data.INTERACTIONTYPE_BIZIBLE_TOUCHPOINT_NOLEADTOUCHPOINTS_COUNT > 0 THEN infl_data.INTERACTIONTYPE_BIZIBLE_TOUCHPOINT_NOLEADTOUCHPOINTS_COUNT
                    ELSE 0
                END AS INTERACTIONTYPE_BIZIBLE_TOUCHPOINT_NOLEADTOUCHPOINTS_COUNT_INFLUENCE_ACTCUSTOMER,
				CASE
                    WHEN infl_data.MARKETING_TOUCHPOINT_DATE <= amlh_opp.AMLH_CUSTOMER_DATE_STAMP__C
                    AND infl_data.INTERACTIONTYPE_BIZIBLE_TOUCHPOINT_MARKETO_COUNT > 0 THEN infl_data.INTERACTIONTYPE_BIZIBLE_TOUCHPOINT_MARKETO_COUNT
                    ELSE 0
                END AS INTERACTIONTYPE_BIZIBLE_TOUCHPOINT_MARKETO_COUNT_INFLUENCE_ACTCUSTOMER,
				CASE
                    WHEN infl_data.MARKETING_TOUCHPOINT_DATE <= amlh_opp.AMLH_CUSTOMER_DATE_STAMP__C
                    AND infl_data.INTERACTIONTYPE_BIZIBLE_TOUCHPOINT_SEISMICENGAGEMENT_COUNT > 0 THEN infl_data.INTERACTIONTYPE_BIZIBLE_TOUCHPOINT_SEISMICENGAGEMENT_COUNT
                    ELSE 0
                END AS INTERACTIONTYPE_BIZIBLE_TOUCHPOINT_SEISMICENGAGEMENT_COUNT_INFLUENCE_ACTCUSTOMER,
				CASE
                    WHEN infl_data.MARKETING_TOUCHPOINT_DATE <= amlh_opp.AMLH_CUSTOMER_DATE_STAMP__C
                    AND infl_data.INTERACTIONTYPE_BIZIBLE_TOUCHPOINT_CHANGESTATUS_COUNT > 0 THEN infl_data.INTERACTIONTYPE_BIZIBLE_TOUCHPOINT_CHANGESTATUS_COUNT
                    ELSE 0
                END AS INTERACTIONTYPE_BIZIBLE_TOUCHPOINT_CHANGESTATUS_COUNT_INFLUENCE_ACTCUSTOMER,
                CASE
                    WHEN infl_data.MARKETING_TOUCHPOINT_DATE <= amlh_opp.AMLH_CUSTOMER_DATE_STAMP__C
                    AND infl_data.INTERACTIONTYPE_BIZIBLE_TOUCHPOINT_UNCLASSIFIED_COUNT > 0 THEN infl_data.INTERACTIONTYPE_BIZIBLE_TOUCHPOINT_UNCLASSIFIED_COUNT
                    ELSE 0
                END AS INTERACTIONTYPE_BIZIBLE_TOUCHPOINT_UNCLASSIFIED_COUNT_INFLUENCE_ACTCUSTOMER,
				--20250314
                -- SUM COUNTS INFLUENCE
                -- Influenced Before Account Effective
                CASE
                    WHEN infl_data.MARKETING_TOUCHPOINT_DATE <= amlh_opp.AMLH_EFFECTIVE_DATE_STAMP__C
                    AND infl_data.INTERACTIONTYPE_SIXSENSE_PAIDMEDIA_IMPRESSIONS_COUNT > 0 THEN infl_data.INTERACTIONTYPE_SIXSENSE_PAIDMEDIA_IMPRESSIONS_COUNT
                    ELSE 0
                END AS INTERACTIONTYPE_SIXSENSE_PAIDMEDIA_IMPRESSIONS_COUNT_INFLUENCE_ACTEFFECTIVE,
                CASE
                    WHEN infl_data.MARKETING_TOUCHPOINT_DATE <= amlh_opp.AMLH_EFFECTIVE_DATE_STAMP__C
                    AND infl_data.INTERACTIONTYPE_SIXSENSE_PAIDMEDIA_CLICKS_COUNT > 0 THEN infl_data.INTERACTIONTYPE_SIXSENSE_PAIDMEDIA_CLICKS_COUNT
                    ELSE 0
                END AS INTERACTIONTYPE_SIXSENSE_PAIDMEDIA_CLICKS_COUNT_INFLUENCE_ACTEFFECTIVE,
                CASE
                    WHEN infl_data.MARKETING_TOUCHPOINT_DATE <= amlh_opp.AMLH_EFFECTIVE_DATE_STAMP__C
                    AND infl_data.INTERACTIONTYPE_SIXSENSE_WEBVISIT_TOTAL_INTERACTIONS_COUNT > 0 THEN infl_data.INTERACTIONTYPE_SIXSENSE_WEBVISIT_TOTAL_INTERACTIONS_COUNT
                    ELSE 0
                END AS INTERACTIONTYPE_SIXSENSE_WEBVISIT_TOTAL_INTERACTIONS_COUNT_INFLUENCE_ACTEFFECTIVE,
                CASE
                    WHEN infl_data.MARKETING_TOUCHPOINT_DATE <= amlh_opp.AMLH_EFFECTIVE_DATE_STAMP__C
                    AND infl_data.INTERACTIONTYPE_SIXSENSE_WEBVISIT_PAGELOAD_COUNT > 0 THEN infl_data.INTERACTIONTYPE_SIXSENSE_WEBVISIT_PAGELOAD_COUNT
                    ELSE 0
                END AS INTERACTIONTYPE_SIXSENSE_WEBVISIT_PAGELOAD_COUNT_INFLUENCE_ACTEFFECTIVE,
                CASE
                    WHEN infl_data.MARKETING_TOUCHPOINT_DATE <= amlh_opp.AMLH_EFFECTIVE_DATE_STAMP__C
                    AND infl_data.INTERACTIONTYPE_SIXSENSE_WEBVISIT_PLAY_COUNT > 0 THEN infl_data.INTERACTIONTYPE_SIXSENSE_WEBVISIT_PLAY_COUNT
                    ELSE 0
                END AS INTERACTIONTYPE_SIXSENSE_WEBVISIT_PLAY_COUNT_INFLUENCE_ACTEFFECTIVE,
                CASE
                    WHEN infl_data.MARKETING_TOUCHPOINT_DATE <= amlh_opp.AMLH_EFFECTIVE_DATE_STAMP__C
                    AND infl_data.INTERACTIONTYPE_SIXSENSE_WEBVISIT_CLICK_COUNT > 0 THEN infl_data.INTERACTIONTYPE_SIXSENSE_WEBVISIT_CLICK_COUNT
                    ELSE 0
                END AS INTERACTIONTYPE_SIXSENSE_WEBVISIT_CLICK_COUNT_INFLUENCE_ACTEFFECTIVE,
                CASE
                    WHEN infl_data.MARKETING_TOUCHPOINT_DATE <= amlh_opp.AMLH_EFFECTIVE_DATE_STAMP__C
                    AND infl_data.INTERACTIONTYPE_SIXSENSE_WEBVISIT_SUBMIT_COUNT > 0 THEN infl_data.INTERACTIONTYPE_SIXSENSE_WEBVISIT_SUBMIT_COUNT
                    ELSE 0
                END AS INTERACTIONTYPE_SIXSENSE_WEBVISIT_SUBMIT_COUNT_INFLUENCE_ACTEFFECTIVE,
                CASE
                    WHEN infl_data.MARKETING_TOUCHPOINT_DATE <= amlh_opp.AMLH_EFFECTIVE_DATE_STAMP__C
                    AND infl_data.INTERACTIONTYPE_SIXSENSE_WEBVISIT_UNCLASSIFIED_COUNT > 0 THEN infl_data.INTERACTIONTYPE_SIXSENSE_WEBVISIT_UNCLASSIFIED_COUNT
                    ELSE 0
                END AS INTERACTIONTYPE_SIXSENSE_WEBVISIT_UNCLASSIFIED_COUNT_INFLUENCE_ACTEFFECTIVE,
                CASE
                    WHEN infl_data.MARKETING_TOUCHPOINT_DATE <= amlh_opp.AMLH_EFFECTIVE_DATE_STAMP__C
                    AND infl_data.INTERACTIONTYPE_BIZIBLE_TOUCHPOINT_WEBVISIT_COUNT > 0 THEN infl_data.INTERACTIONTYPE_BIZIBLE_TOUCHPOINT_WEBVISIT_COUNT
                    ELSE 0
                END AS INTERACTIONTYPE_BIZIBLE_TOUCHPOINT_WEBVISIT_COUNT_INFLUENCE_ACTEFFECTIVE,
                CASE
                    WHEN infl_data.MARKETING_TOUCHPOINT_DATE <= amlh_opp.AMLH_EFFECTIVE_DATE_STAMP__C
                    AND infl_data.INTERACTIONTYPE_BIZIBLE_TOUCHPOINT_WEBCHAT_COUNT > 0 THEN infl_data.INTERACTIONTYPE_BIZIBLE_TOUCHPOINT_WEBCHAT_COUNT
                    ELSE 0
                END AS INTERACTIONTYPE_BIZIBLE_TOUCHPOINT_WEBCHAT_COUNT_INFLUENCE_ACTEFFECTIVE,
                CASE
                    WHEN infl_data.MARKETING_TOUCHPOINT_DATE <= amlh_opp.AMLH_EFFECTIVE_DATE_STAMP__C
                    AND infl_data.INTERACTIONTYPE_BIZIBLE_TOUCHPOINT_WEBFORM_COUNT > 0 THEN infl_data.INTERACTIONTYPE_BIZIBLE_TOUCHPOINT_WEBFORM_COUNT
                    ELSE 0
                END AS INTERACTIONTYPE_BIZIBLE_TOUCHPOINT_WEBFORM_COUNT_INFLUENCE_ACTEFFECTIVE,
                CASE
                    WHEN infl_data.MARKETING_TOUCHPOINT_DATE <= amlh_opp.AMLH_EFFECTIVE_DATE_STAMP__C
                    AND infl_data.INTERACTIONTYPE_BIZIBLE_TOUCHPOINT_CRM_COUNT > 0 THEN infl_data.INTERACTIONTYPE_BIZIBLE_TOUCHPOINT_CRM_COUNT
                    ELSE 0
                END AS INTERACTIONTYPE_BIZIBLE_TOUCHPOINT_CRM_COUNT_INFLUENCE_ACTEFFECTIVE,
                CASE
                    WHEN infl_data.MARKETING_TOUCHPOINT_DATE <= amlh_opp.AMLH_EFFECTIVE_DATE_STAMP__C
                    AND infl_data.INTERACTIONTYPE_BIZIBLE_TOUCHPOINT_CONNECTWITHDM_COUNT > 0 THEN infl_data.INTERACTIONTYPE_BIZIBLE_TOUCHPOINT_CONNECTWITHDM_COUNT
                    ELSE 0
                END AS INTERACTIONTYPE_BIZIBLE_TOUCHPOINT_CONNECTWITHDM_COUNT_INFLUENCE_ACTEFFECTIVE,
                CASE
                    WHEN infl_data.MARKETING_TOUCHPOINT_DATE <= amlh_opp.AMLH_EFFECTIVE_DATE_STAMP__C
                    AND infl_data.INTERACTIONTYPE_BIZIBLE_TOUCHPOINT_CALLSPOKEWITH_COUNT > 0 THEN infl_data.INTERACTIONTYPE_BIZIBLE_TOUCHPOINT_CALLSPOKEWITH_COUNT
                    ELSE 0
                END AS INTERACTIONTYPE_BIZIBLE_TOUCHPOINT_CALLSPOKEWITH_COUNT_INFLUENCE_ACTEFFECTIVE,
                CASE
                    WHEN infl_data.MARKETING_TOUCHPOINT_DATE <= amlh_opp.AMLH_EFFECTIVE_DATE_STAMP__C
                    AND infl_data.INTERACTIONTYPE_BIZIBLE_TOUCHPOINT_CALLGATEKEEPER_COUNT > 0 THEN infl_data.INTERACTIONTYPE_BIZIBLE_TOUCHPOINT_CALLGATEKEEPER_COUNT
                    ELSE 0
                END AS INTERACTIONTYPE_BIZIBLE_TOUCHPOINT_CALLGATEKEEPER_COUNT_INFLUENCE_ACTEFFECTIVE,
                CASE
                    WHEN infl_data.MARKETING_TOUCHPOINT_DATE <= amlh_opp.AMLH_EFFECTIVE_DATE_STAMP__C
                    AND infl_data.INTERACTIONTYPE_BIZIBLE_TOUCHPOINT_NOLEADTOUCHPOINTS_COUNT > 0 THEN infl_data.INTERACTIONTYPE_BIZIBLE_TOUCHPOINT_NOLEADTOUCHPOINTS_COUNT
                    ELSE 0
                END AS INTERACTIONTYPE_BIZIBLE_TOUCHPOINT_NOLEADTOUCHPOINTS_COUNT_INFLUENCE_ACTEFFECTIVE,
				CASE
                    WHEN infl_data.MARKETING_TOUCHPOINT_DATE <= amlh_opp.AMLH_EFFECTIVE_DATE_STAMP__C
                    AND infl_data.INTERACTIONTYPE_BIZIBLE_TOUCHPOINT_MARKETO_COUNT > 0 THEN infl_data.INTERACTIONTYPE_BIZIBLE_TOUCHPOINT_MARKETO_COUNT
                    ELSE 0
                END AS INTERACTIONTYPE_BIZIBLE_TOUCHPOINT_MARKETO_COUNT_INFLUENCE_ACTEFFECTIVE,
				CASE
                    WHEN infl_data.MARKETING_TOUCHPOINT_DATE <= amlh_opp.AMLH_EFFECTIVE_DATE_STAMP__C
                    AND infl_data.INTERACTIONTYPE_BIZIBLE_TOUCHPOINT_SEISMICENGAGEMENT_COUNT > 0 THEN infl_data.INTERACTIONTYPE_BIZIBLE_TOUCHPOINT_SEISMICENGAGEMENT_COUNT
                    ELSE 0
                END AS INTERACTIONTYPE_BIZIBLE_TOUCHPOINT_SEISMICENGAGEMENT_COUNT_INFLUENCE_ACTEFFECTIVE,
				CASE
                    WHEN infl_data.MARKETING_TOUCHPOINT_DATE <= amlh_opp.AMLH_EFFECTIVE_DATE_STAMP__C
                    AND infl_data.INTERACTIONTYPE_BIZIBLE_TOUCHPOINT_CHANGESTATUS_COUNT > 0 THEN infl_data.INTERACTIONTYPE_BIZIBLE_TOUCHPOINT_CHANGESTATUS_COUNT
                    ELSE 0
                END AS INTERACTIONTYPE_BIZIBLE_TOUCHPOINT_CHANGESTATUS_COUNT_INFLUENCE_ACTEFFECTIVE,
                CASE
                    WHEN infl_data.MARKETING_TOUCHPOINT_DATE <= amlh_opp.AMLH_EFFECTIVE_DATE_STAMP__C
                    AND infl_data.INTERACTIONTYPE_BIZIBLE_TOUCHPOINT_UNCLASSIFIED_COUNT > 0 THEN infl_data.INTERACTIONTYPE_BIZIBLE_TOUCHPOINT_UNCLASSIFIED_COUNT
                    ELSE 0
                END AS INTERACTIONTYPE_BIZIBLE_TOUCHPOINT_UNCLASSIFIED_COUNT_INFLUENCE_ACTEFFECTIVE,
				
                -- Influence Before Opp Created Date
                CASE
                    WHEN infl_data.MARKETING_TOUCHPOINT_DATE <= amlh_opp.OPP_CREATED_DATE
                    AND SPLIT_PART(infl_data.INFLUENCE_CHANNEL, '.', 1) = 'Channel Referral' THEN 1
                    else 0
                END AS FLAG_OPPCRT_INFL_TOUCHPOINT_BY_ACQTOPLEVELCHANNEL_CHANNELREFERRAL,
                CASE
                    WHEN infl_data.MARKETING_TOUCHPOINT_DATE <= amlh_opp.OPP_CREATED_DATE
                    AND SPLIT_PART(infl_data.INFLUENCE_CHANNEL, '.', 1) = 'Content Syndication' THEN 1
                    else 0
                END AS FLAG_OPPCRT_INFL_TOUCHPOINT_BY_ACQTOPLEVELCHANNEL_CONTENTSYNDICATION,
                CASE
                    WHEN infl_data.MARKETING_TOUCHPOINT_DATE <= amlh_opp.OPP_CREATED_DATE
                    AND SPLIT_PART(infl_data.INFLUENCE_CHANNEL, '.', 1) = 'Sales Engagement' THEN 1
                    else 0
                END AS FLAG_OPPCRT_INFL_TOUCHPOINT_BY_ACQTOPLEVELCHANNEL_SALESENGAGEMENT,
                CASE
                    WHEN infl_data.MARKETING_TOUCHPOINT_DATE <= amlh_opp.OPP_CREATED_DATE
                    AND SPLIT_PART(infl_data.INFLUENCE_CHANNEL, '.', 1) = 'Direct' THEN 1
                    else 0
                END AS FLAG_OPPCRT_INFL_TOUCHPOINT_BY_ACQTOPLEVELCHANNEL_DIRECT,
                CASE
                    WHEN infl_data.MARKETING_TOUCHPOINT_DATE <= amlh_opp.OPP_CREATED_DATE
                    AND SPLIT_PART(infl_data.INFLUENCE_CHANNEL, '.', 1) = 'Direct Mail' THEN 1
                    else 0
                END AS FLAG_OPPCRT_INFL_TOUCHPOINT_BY_ACQTOPLEVELCHANNEL_DIRECTMAIL,
                CASE
                    WHEN infl_data.MARKETING_TOUCHPOINT_DATE <= amlh_opp.OPP_CREATED_DATE
                    AND SPLIT_PART(infl_data.INFLUENCE_CHANNEL, '.', 1) = 'Display' THEN 1
                    else 0
                END AS FLAG_OPPCRT_INFL_TOUCHPOINT_BY_ACQTOPLEVELCHANNEL_DISPLAY,
                CASE
                    WHEN infl_data.MARKETING_TOUCHPOINT_DATE <= amlh_opp.OPP_CREATED_DATE
                    AND SPLIT_PART(infl_data.INFLUENCE_CHANNEL, '.', 1) = 'Email' THEN 1
                    else 0
                END AS FLAG_OPPCRT_INFL_TOUCHPOINT_BY_ACQTOPLEVELCHANNEL_EMAIL,
                CASE
                    WHEN infl_data.MARKETING_TOUCHPOINT_DATE <= amlh_opp.OPP_CREATED_DATE
                    AND SPLIT_PART(infl_data.INFLUENCE_CHANNEL, '.', 1) = 'Lead Referral' THEN 1
                    else 0
                END AS FLAG_OPPCRT_INFL_TOUCHPOINT_BY_ACQTOPLEVELCHANNEL_LEADREFERRAL,
                CASE
                    WHEN infl_data.MARKETING_TOUCHPOINT_DATE <= amlh_opp.OPP_CREATED_DATE
                    AND SPLIT_PART(infl_data.INFLUENCE_CHANNEL, '.', 1) = 'Live Event' THEN 1
                    else 0
                END AS FLAG_OPPCRT_INFL_TOUCHPOINT_BY_ACQTOPLEVELCHANNEL_LIVEEVENT,
                CASE
                    WHEN infl_data.MARKETING_TOUCHPOINT_DATE <= amlh_opp.OPP_CREATED_DATE
                    AND SPLIT_PART(infl_data.INFLUENCE_CHANNEL, '.', 1) = 'Lytx' THEN 1
                    else 0
                END AS FLAG_OPPCRT_INFL_TOUCHPOINT_BY_ACQTOPLEVELCHANNEL_LYTX,
                CASE
                    WHEN infl_data.MARKETING_TOUCHPOINT_DATE <= amlh_opp.OPP_CREATED_DATE
                    AND SPLIT_PART(infl_data.INFLUENCE_CHANNEL, '.', 1) = 'Native' THEN 1
                    else 0
                END AS FLAG_OPPCRT_INFL_TOUCHPOINT_BY_ACQTOPLEVELCHANNEL_NATIVE,
                CASE
                    WHEN infl_data.MARKETING_TOUCHPOINT_DATE <= amlh_opp.OPP_CREATED_DATE
                    AND SPLIT_PART(infl_data.INFLUENCE_CHANNEL, '.', 1) = 'Organic Search' THEN 1
                    else 0
                END AS FLAG_OPPCRT_INFL_TOUCHPOINT_BY_ACQTOPLEVELCHANNEL_ORGANICSEARCH,
                CASE
                    WHEN infl_data.MARKETING_TOUCHPOINT_DATE <= amlh_opp.OPP_CREATED_DATE
                    AND SPLIT_PART(infl_data.INFLUENCE_CHANNEL, '.', 1) = 'Organic Social' THEN 1
                    else 0
                END AS FLAG_OPPCRT_INFL_TOUCHPOINT_BY_ACQTOPLEVELCHANNEL_ORGANICSOCIAL,
                CASE
                    WHEN infl_data.MARKETING_TOUCHPOINT_DATE <= amlh_opp.OPP_CREATED_DATE
                    AND SPLIT_PART(infl_data.INFLUENCE_CHANNEL, '.', 1) = 'Other' THEN 1
                    else 0
                END AS FLAG_OPPCRT_INFL_TOUCHPOINT_BY_ACQTOPLEVELCHANNEL_OTHER,
                CASE
                    WHEN infl_data.MARKETING_TOUCHPOINT_DATE <= amlh_opp.OPP_CREATED_DATE
                    AND SPLIT_PART(infl_data.INFLUENCE_CHANNEL, '.', 1) = 'Paid Media' THEN 1
                    else 0
                END AS FLAG_OPPCRT_INFL_TOUCHPOINT_BY_ACQTOPLEVELCHANNEL_PAIDMEDIA,
                CASE
                    WHEN infl_data.MARKETING_TOUCHPOINT_DATE <= amlh_opp.OPP_CREATED_DATE
                    AND SPLIT_PART(infl_data.INFLUENCE_CHANNEL, '.', 1) = 'Paid Search' THEN 1
                    else 0
                END AS FLAG_OPPCRT_INFL_TOUCHPOINT_BY_ACQTOPLEVELCHANNEL_PAIDSEARCH,
                CASE
                    WHEN infl_data.MARKETING_TOUCHPOINT_DATE <= amlh_opp.OPP_CREATED_DATE
                    AND SPLIT_PART(infl_data.INFLUENCE_CHANNEL, '.', 1) = 'Paid Social' THEN 1
                    else 0
                END AS FLAG_OPPCRT_INFL_TOUCHPOINT_BY_ACQTOPLEVELCHANNEL_PAIDSOCIAL,
                CASE
                    WHEN infl_data.MARKETING_TOUCHPOINT_DATE <= amlh_opp.OPP_CREATED_DATE
                    AND SPLIT_PART(infl_data.INFLUENCE_CHANNEL, '.', 1) = 'Podcast' THEN 1
                    else 0
                END AS FLAG_OPPCRT_INFL_TOUCHPOINT_BY_ACQTOPLEVELCHANNEL_PODCAST,
                CASE
                    WHEN infl_data.MARKETING_TOUCHPOINT_DATE <= amlh_opp.OPP_CREATED_DATE
                    AND SPLIT_PART(infl_data.INFLUENCE_CHANNEL, '.', 1) = 'PPL' THEN 1
                    else 0
                END AS FLAG_OPPCRT_INFL_TOUCHPOINT_BY_ACQTOPLEVELCHANNEL_PPL,
                CASE
                    WHEN infl_data.MARKETING_TOUCHPOINT_DATE <= amlh_opp.OPP_CREATED_DATE
                    AND SPLIT_PART(infl_data.INFLUENCE_CHANNEL, '.', 1) = 'Print' THEN 1
                    else 0
                END AS FLAG_OPPCRT_INFL_TOUCHPOINT_BY_ACQTOPLEVELCHANNEL_PRINT,
                CASE
                    WHEN infl_data.MARKETING_TOUCHPOINT_DATE <= amlh_opp.OPP_CREATED_DATE
                    AND SPLIT_PART(infl_data.INFLUENCE_CHANNEL, '.', 1) = 'Sponsored Email' THEN 1
                    else 0
                END AS FLAG_OPPCRT_INFL_TOUCHPOINT_BY_ACQTOPLEVELCHANNEL_SPONSOREDEMAIL,
                CASE
                    WHEN infl_data.MARKETING_TOUCHPOINT_DATE <= amlh_opp.OPP_CREATED_DATE
                    AND SPLIT_PART(infl_data.INFLUENCE_CHANNEL, '.', 1) = 'Tradeshow' THEN 1
                    else 0
                END AS FLAG_OPPCRT_INFL_TOUCHPOINT_BY_ACQTOPLEVELCHANNEL_TRADESHOW,
                CASE
                    WHEN infl_data.MARKETING_TOUCHPOINT_DATE <= amlh_opp.OPP_CREATED_DATE
                    AND SPLIT_PART(infl_data.INFLUENCE_CHANNEL, '.', 1) = 'Web Referral' THEN 1
                    else 0
                END AS FLAG_OPPCRT_INFL_TOUCHPOINT_BY_ACQTOPLEVELCHANNEL_WEBREFERRAL,
                CASE
                    WHEN infl_data.MARKETING_TOUCHPOINT_DATE <= amlh_opp.OPP_CREATED_DATE
                    AND SPLIT_PART(infl_data.INFLUENCE_CHANNEL, '.', 1) = 'Webinar' THEN 1
                    else 0
                END AS FLAG_OPPCRT_INFL_TOUCHPOINT_BY_ACQTOPLEVELCHANNEL_WEBINAR,
				--20250314
                CASE
                    WHEN infl_data.MARKETING_TOUCHPOINT_DATE <= amlh_opp.OPP_CREATED_DATE
                    AND SPLIT_PART(infl_data.INFLUENCE_CHANNEL, '.', 1) = 'E-Gift' THEN 1
                    else 0
                END AS FLAG_OPPCRT_INFL_TOUCHPOINT_BY_ACQTOPLEVELCHANNEL_EGIFT,	
				
				--20251002
                -- Influence Before Opp Stage One
                CASE
                    WHEN infl_data.MARKETING_TOUCHPOINT_DATE <= amlh_opp.OPP_STAGE_0_DATE
                    AND SPLIT_PART(infl_data.INFLUENCE_CHANNEL, '.', 1) = 'Channel Referral' THEN 1
                    else 0
                END AS FLAG_OPPSTG0_INFL_TOUCHPOINT_BY_ACQTOPLEVELCHANNEL_CHANNELREFERRAL,
                CASE
                    WHEN infl_data.MARKETING_TOUCHPOINT_DATE <= amlh_opp.OPP_STAGE_0_DATE
                    AND SPLIT_PART(infl_data.INFLUENCE_CHANNEL, '.', 1) = 'Content Syndication' THEN 1
                    else 0
                END AS FLAG_OPPSTG0_INFL_TOUCHPOINT_BY_ACQTOPLEVELCHANNEL_CONTENTSYNDICATION,
                CASE
                    WHEN infl_data.MARKETING_TOUCHPOINT_DATE <= amlh_opp.OPP_STAGE_0_DATE
                    AND SPLIT_PART(infl_data.INFLUENCE_CHANNEL, '.', 1) = 'Sales Engagement' THEN 1
                    else 0
                END AS FLAG_OPPSTG0_INFL_TOUCHPOINT_BY_ACQTOPLEVELCHANNEL_SALESENGAGEMENT,
                CASE
                    WHEN infl_data.MARKETING_TOUCHPOINT_DATE <= amlh_opp.OPP_STAGE_0_DATE
                    AND SPLIT_PART(infl_data.INFLUENCE_CHANNEL, '.', 1) = 'Direct' THEN 1
                    else 0
                END AS FLAG_OPPSTG0_INFL_TOUCHPOINT_BY_ACQTOPLEVELCHANNEL_DIRECT,
                CASE
                    WHEN infl_data.MARKETING_TOUCHPOINT_DATE <= amlh_opp.OPP_STAGE_0_DATE
                    AND SPLIT_PART(infl_data.INFLUENCE_CHANNEL, '.', 1) = 'Direct Mail' THEN 1
                    else 0
                END AS FLAG_OPPSTG0_INFL_TOUCHPOINT_BY_ACQTOPLEVELCHANNEL_DIRECTMAIL,
                CASE
                    WHEN infl_data.MARKETING_TOUCHPOINT_DATE <= amlh_opp.OPP_STAGE_0_DATE
                    AND SPLIT_PART(infl_data.INFLUENCE_CHANNEL, '.', 1) = 'Display' THEN 1
                    else 0
                END AS FLAG_OPPSTG0_INFL_TOUCHPOINT_BY_ACQTOPLEVELCHANNEL_DISPLAY,
                CASE
                    WHEN infl_data.MARKETING_TOUCHPOINT_DATE <= amlh_opp.OPP_STAGE_0_DATE
                    AND SPLIT_PART(infl_data.INFLUENCE_CHANNEL, '.', 1) = 'Email' THEN 1
                    else 0
                END AS FLAG_OPPSTG0_INFL_TOUCHPOINT_BY_ACQTOPLEVELCHANNEL_EMAIL,
                CASE
                    WHEN infl_data.MARKETING_TOUCHPOINT_DATE <= amlh_opp.OPP_STAGE_0_DATE
                    AND SPLIT_PART(infl_data.INFLUENCE_CHANNEL, '.', 1) = 'Lead Referral' THEN 1
                    else 0
                END AS FLAG_OPPSTG0_INFL_TOUCHPOINT_BY_ACQTOPLEVELCHANNEL_LEADREFERRAL,
                CASE
                    WHEN infl_data.MARKETING_TOUCHPOINT_DATE <= amlh_opp.OPP_STAGE_0_DATE
                    AND SPLIT_PART(infl_data.INFLUENCE_CHANNEL, '.', 1) = 'Live Event' THEN 1
                    else 0
                END AS FLAG_OPPSTG0_INFL_TOUCHPOINT_BY_ACQTOPLEVELCHANNEL_LIVEEVENT,
                CASE
                    WHEN infl_data.MARKETING_TOUCHPOINT_DATE <= amlh_opp.OPP_STAGE_0_DATE
                    AND SPLIT_PART(infl_data.INFLUENCE_CHANNEL, '.', 1) = 'Lytx' THEN 1
                    else 0
                END AS FLAG_OPPSTG0_INFL_TOUCHPOINT_BY_ACQTOPLEVELCHANNEL_LYTX,
                CASE
                    WHEN infl_data.MARKETING_TOUCHPOINT_DATE <= amlh_opp.OPP_STAGE_0_DATE
                    AND SPLIT_PART(infl_data.INFLUENCE_CHANNEL, '.', 1) = 'Native' THEN 1
                    else 0
                END AS FLAG_OPPSTG0_INFL_TOUCHPOINT_BY_ACQTOPLEVELCHANNEL_NATIVE,
                CASE
                    WHEN infl_data.MARKETING_TOUCHPOINT_DATE <= amlh_opp.OPP_STAGE_0_DATE
                    AND SPLIT_PART(infl_data.INFLUENCE_CHANNEL, '.', 1) = 'Organic Search' THEN 1
                    else 0
                END AS FLAG_OPPSTG0_INFL_TOUCHPOINT_BY_ACQTOPLEVELCHANNEL_ORGANICSEARCH,
                CASE
                    WHEN infl_data.MARKETING_TOUCHPOINT_DATE <= amlh_opp.OPP_STAGE_0_DATE
                    AND SPLIT_PART(infl_data.INFLUENCE_CHANNEL, '.', 1) = 'Organic Social' THEN 1
                    else 0
                END AS FLAG_OPPSTG0_INFL_TOUCHPOINT_BY_ACQTOPLEVELCHANNEL_ORGANICSOCIAL,
                CASE
                    WHEN infl_data.MARKETING_TOUCHPOINT_DATE <= amlh_opp.OPP_STAGE_0_DATE
                    AND SPLIT_PART(infl_data.INFLUENCE_CHANNEL, '.', 1) = 'Other' THEN 1
                    else 0
                END AS FLAG_OPPSTG0_INFL_TOUCHPOINT_BY_ACQTOPLEVELCHANNEL_OTHER,
                CASE
                    WHEN infl_data.MARKETING_TOUCHPOINT_DATE <= amlh_opp.OPP_STAGE_0_DATE
                    AND SPLIT_PART(infl_data.INFLUENCE_CHANNEL, '.', 1) = 'Paid Media' THEN 1
                    else 0
                END AS FLAG_OPPSTG0_INFL_TOUCHPOINT_BY_ACQTOPLEVELCHANNEL_PAIDMEDIA,
                CASE
                    WHEN infl_data.MARKETING_TOUCHPOINT_DATE <= amlh_opp.OPP_STAGE_0_DATE
                    AND SPLIT_PART(infl_data.INFLUENCE_CHANNEL, '.', 1) = 'Paid Search' THEN 1
                    else 0
                END AS FLAG_OPPSTG0_INFL_TOUCHPOINT_BY_ACQTOPLEVELCHANNEL_PAIDSEARCH,
                CASE
                    WHEN infl_data.MARKETING_TOUCHPOINT_DATE <= amlh_opp.OPP_STAGE_0_DATE
                    AND SPLIT_PART(infl_data.INFLUENCE_CHANNEL, '.', 1) = 'Paid Social' THEN 1
                    else 0
                END AS FLAG_OPPSTG0_INFL_TOUCHPOINT_BY_ACQTOPLEVELCHANNEL_PAIDSOCIAL,
                CASE
                    WHEN infl_data.MARKETING_TOUCHPOINT_DATE <= amlh_opp.OPP_STAGE_0_DATE
                    AND SPLIT_PART(infl_data.INFLUENCE_CHANNEL, '.', 1) = 'Podcast' THEN 1
                    else 0
                END AS FLAG_OPPSTG0_INFL_TOUCHPOINT_BY_ACQTOPLEVELCHANNEL_PODCAST,
                CASE
                    WHEN infl_data.MARKETING_TOUCHPOINT_DATE <= amlh_opp.OPP_STAGE_0_DATE
                    AND SPLIT_PART(infl_data.INFLUENCE_CHANNEL, '.', 1) = 'PPL' THEN 1
                    else 0
                END AS FLAG_OPPSTG0_INFL_TOUCHPOINT_BY_ACQTOPLEVELCHANNEL_PPL,
                CASE
                    WHEN infl_data.MARKETING_TOUCHPOINT_DATE <= amlh_opp.OPP_STAGE_0_DATE
                    AND SPLIT_PART(infl_data.INFLUENCE_CHANNEL, '.', 1) = 'Print' THEN 1
                    else 0
                END AS FLAG_OPPSTG0_INFL_TOUCHPOINT_BY_ACQTOPLEVELCHANNEL_PRINT,
                CASE
                    WHEN infl_data.MARKETING_TOUCHPOINT_DATE <= amlh_opp.OPP_STAGE_0_DATE
                    AND SPLIT_PART(infl_data.INFLUENCE_CHANNEL, '.', 1) = 'Sponsored Email' THEN 1
                    else 0
                END AS FLAG_OPPSTG0_INFL_TOUCHPOINT_BY_ACQTOPLEVELCHANNEL_SPONSOREDEMAIL,
                CASE
                    WHEN infl_data.MARKETING_TOUCHPOINT_DATE <= amlh_opp.OPP_STAGE_0_DATE
                    AND SPLIT_PART(infl_data.INFLUENCE_CHANNEL, '.', 1) = 'Tradeshow' THEN 1
                    else 0
                END AS FLAG_OPPSTG0_INFL_TOUCHPOINT_BY_ACQTOPLEVELCHANNEL_TRADESHOW,
                CASE
                    WHEN infl_data.MARKETING_TOUCHPOINT_DATE <= amlh_opp.OPP_STAGE_0_DATE
                    AND SPLIT_PART(infl_data.INFLUENCE_CHANNEL, '.', 1) = 'Web Referral' THEN 1
                    else 0
                END AS FLAG_OPPSTG0_INFL_TOUCHPOINT_BY_ACQTOPLEVELCHANNEL_WEBREFERRAL,
                CASE
                    WHEN infl_data.MARKETING_TOUCHPOINT_DATE <= amlh_opp.OPP_STAGE_0_DATE
                    AND SPLIT_PART(infl_data.INFLUENCE_CHANNEL, '.', 1) = 'Webinar' THEN 1
                    else 0
                END AS FLAG_OPPSTG0_INFL_TOUCHPOINT_BY_ACQTOPLEVELCHANNEL_WEBINAR,
				--20250314
                CASE
                    WHEN infl_data.MARKETING_TOUCHPOINT_DATE <= amlh_opp.OPP_STAGE_0_DATE
                    AND SPLIT_PART(infl_data.INFLUENCE_CHANNEL, '.', 1) = 'E-Gift' THEN 1
                    else 0
                END AS FLAG_OPPSTG0_INFL_TOUCHPOINT_BY_ACQTOPLEVELCHANNEL_EGIFT,
				
				--20250302
                -- Influence Before Opp Stage One
                CASE
                    WHEN infl_data.MARKETING_TOUCHPOINT_DATE <= amlh_opp.OPP_STAGE_1_DATE
                    AND SPLIT_PART(infl_data.INFLUENCE_CHANNEL, '.', 1) = 'Channel Referral' THEN 1
                    else 0
                END AS FLAG_OPPSTG1_INFL_TOUCHPOINT_BY_ACQTOPLEVELCHANNEL_CHANNELREFERRAL,
                CASE
                    WHEN infl_data.MARKETING_TOUCHPOINT_DATE <= amlh_opp.OPP_STAGE_1_DATE
                    AND SPLIT_PART(infl_data.INFLUENCE_CHANNEL, '.', 1) = 'Content Syndication' THEN 1
                    else 0
                END AS FLAG_OPPSTG1_INFL_TOUCHPOINT_BY_ACQTOPLEVELCHANNEL_CONTENTSYNDICATION,
                CASE
                    WHEN infl_data.MARKETING_TOUCHPOINT_DATE <= amlh_opp.OPP_STAGE_1_DATE
                    AND SPLIT_PART(infl_data.INFLUENCE_CHANNEL, '.', 1) = 'Sales Engagement' THEN 1
                    else 0
                END AS FLAG_OPPSTG1_INFL_TOUCHPOINT_BY_ACQTOPLEVELCHANNEL_SALESENGAGEMENT,
                CASE
                    WHEN infl_data.MARKETING_TOUCHPOINT_DATE <= amlh_opp.OPP_STAGE_1_DATE
                    AND SPLIT_PART(infl_data.INFLUENCE_CHANNEL, '.', 1) = 'Direct' THEN 1
                    else 0
                END AS FLAG_OPPSTG1_INFL_TOUCHPOINT_BY_ACQTOPLEVELCHANNEL_DIRECT,
                CASE
                    WHEN infl_data.MARKETING_TOUCHPOINT_DATE <= amlh_opp.OPP_STAGE_1_DATE
                    AND SPLIT_PART(infl_data.INFLUENCE_CHANNEL, '.', 1) = 'Direct Mail' THEN 1
                    else 0
                END AS FLAG_OPPSTG1_INFL_TOUCHPOINT_BY_ACQTOPLEVELCHANNEL_DIRECTMAIL,
                CASE
                    WHEN infl_data.MARKETING_TOUCHPOINT_DATE <= amlh_opp.OPP_STAGE_1_DATE
                    AND SPLIT_PART(infl_data.INFLUENCE_CHANNEL, '.', 1) = 'Display' THEN 1
                    else 0
                END AS FLAG_OPPSTG1_INFL_TOUCHPOINT_BY_ACQTOPLEVELCHANNEL_DISPLAY,
                CASE
                    WHEN infl_data.MARKETING_TOUCHPOINT_DATE <= amlh_opp.OPP_STAGE_1_DATE
                    AND SPLIT_PART(infl_data.INFLUENCE_CHANNEL, '.', 1) = 'Email' THEN 1
                    else 0
                END AS FLAG_OPPSTG1_INFL_TOUCHPOINT_BY_ACQTOPLEVELCHANNEL_EMAIL,
                CASE
                    WHEN infl_data.MARKETING_TOUCHPOINT_DATE <= amlh_opp.OPP_STAGE_1_DATE
                    AND SPLIT_PART(infl_data.INFLUENCE_CHANNEL, '.', 1) = 'Lead Referral' THEN 1
                    else 0
                END AS FLAG_OPPSTG1_INFL_TOUCHPOINT_BY_ACQTOPLEVELCHANNEL_LEADREFERRAL,
                CASE
                    WHEN infl_data.MARKETING_TOUCHPOINT_DATE <= amlh_opp.OPP_STAGE_1_DATE
                    AND SPLIT_PART(infl_data.INFLUENCE_CHANNEL, '.', 1) = 'Live Event' THEN 1
                    else 0
                END AS FLAG_OPPSTG1_INFL_TOUCHPOINT_BY_ACQTOPLEVELCHANNEL_LIVEEVENT,
                CASE
                    WHEN infl_data.MARKETING_TOUCHPOINT_DATE <= amlh_opp.OPP_STAGE_1_DATE
                    AND SPLIT_PART(infl_data.INFLUENCE_CHANNEL, '.', 1) = 'Lytx' THEN 1
                    else 0
                END AS FLAG_OPPSTG1_INFL_TOUCHPOINT_BY_ACQTOPLEVELCHANNEL_LYTX,
                CASE
                    WHEN infl_data.MARKETING_TOUCHPOINT_DATE <= amlh_opp.OPP_STAGE_1_DATE
                    AND SPLIT_PART(infl_data.INFLUENCE_CHANNEL, '.', 1) = 'Native' THEN 1
                    else 0
                END AS FLAG_OPPSTG1_INFL_TOUCHPOINT_BY_ACQTOPLEVELCHANNEL_NATIVE,
                CASE
                    WHEN infl_data.MARKETING_TOUCHPOINT_DATE <= amlh_opp.OPP_STAGE_1_DATE
                    AND SPLIT_PART(infl_data.INFLUENCE_CHANNEL, '.', 1) = 'Organic Search' THEN 1
                    else 0
                END AS FLAG_OPPSTG1_INFL_TOUCHPOINT_BY_ACQTOPLEVELCHANNEL_ORGANICSEARCH,
                CASE
                    WHEN infl_data.MARKETING_TOUCHPOINT_DATE <= amlh_opp.OPP_STAGE_1_DATE
                    AND SPLIT_PART(infl_data.INFLUENCE_CHANNEL, '.', 1) = 'Organic Social' THEN 1
                    else 0
                END AS FLAG_OPPSTG1_INFL_TOUCHPOINT_BY_ACQTOPLEVELCHANNEL_ORGANICSOCIAL,
                CASE
                    WHEN infl_data.MARKETING_TOUCHPOINT_DATE <= amlh_opp.OPP_STAGE_1_DATE
                    AND SPLIT_PART(infl_data.INFLUENCE_CHANNEL, '.', 1) = 'Other' THEN 1
                    else 0
                END AS FLAG_OPPSTG1_INFL_TOUCHPOINT_BY_ACQTOPLEVELCHANNEL_OTHER,
                CASE
                    WHEN infl_data.MARKETING_TOUCHPOINT_DATE <= amlh_opp.OPP_STAGE_1_DATE
                    AND SPLIT_PART(infl_data.INFLUENCE_CHANNEL, '.', 1) = 'Paid Media' THEN 1
                    else 0
                END AS FLAG_OPPSTG1_INFL_TOUCHPOINT_BY_ACQTOPLEVELCHANNEL_PAIDMEDIA,
                CASE
                    WHEN infl_data.MARKETING_TOUCHPOINT_DATE <= amlh_opp.OPP_STAGE_1_DATE
                    AND SPLIT_PART(infl_data.INFLUENCE_CHANNEL, '.', 1) = 'Paid Search' THEN 1
                    else 0
                END AS FLAG_OPPSTG1_INFL_TOUCHPOINT_BY_ACQTOPLEVELCHANNEL_PAIDSEARCH,
                CASE
                    WHEN infl_data.MARKETING_TOUCHPOINT_DATE <= amlh_opp.OPP_STAGE_1_DATE
                    AND SPLIT_PART(infl_data.INFLUENCE_CHANNEL, '.', 1) = 'Paid Social' THEN 1
                    else 0
                END AS FLAG_OPPSTG1_INFL_TOUCHPOINT_BY_ACQTOPLEVELCHANNEL_PAIDSOCIAL,
                CASE
                    WHEN infl_data.MARKETING_TOUCHPOINT_DATE <= amlh_opp.OPP_STAGE_1_DATE
                    AND SPLIT_PART(infl_data.INFLUENCE_CHANNEL, '.', 1) = 'Podcast' THEN 1
                    else 0
                END AS FLAG_OPPSTG1_INFL_TOUCHPOINT_BY_ACQTOPLEVELCHANNEL_PODCAST,
                CASE
                    WHEN infl_data.MARKETING_TOUCHPOINT_DATE <= amlh_opp.OPP_STAGE_1_DATE
                    AND SPLIT_PART(infl_data.INFLUENCE_CHANNEL, '.', 1) = 'PPL' THEN 1
                    else 0
                END AS FLAG_OPPSTG1_INFL_TOUCHPOINT_BY_ACQTOPLEVELCHANNEL_PPL,
                CASE
                    WHEN infl_data.MARKETING_TOUCHPOINT_DATE <= amlh_opp.OPP_STAGE_1_DATE
                    AND SPLIT_PART(infl_data.INFLUENCE_CHANNEL, '.', 1) = 'Print' THEN 1
                    else 0
                END AS FLAG_OPPSTG1_INFL_TOUCHPOINT_BY_ACQTOPLEVELCHANNEL_PRINT,
                CASE
                    WHEN infl_data.MARKETING_TOUCHPOINT_DATE <= amlh_opp.OPP_STAGE_1_DATE
                    AND SPLIT_PART(infl_data.INFLUENCE_CHANNEL, '.', 1) = 'Sponsored Email' THEN 1
                    else 0
                END AS FLAG_OPPSTG1_INFL_TOUCHPOINT_BY_ACQTOPLEVELCHANNEL_SPONSOREDEMAIL,
                CASE
                    WHEN infl_data.MARKETING_TOUCHPOINT_DATE <= amlh_opp.OPP_STAGE_1_DATE
                    AND SPLIT_PART(infl_data.INFLUENCE_CHANNEL, '.', 1) = 'Tradeshow' THEN 1
                    else 0
                END AS FLAG_OPPSTG1_INFL_TOUCHPOINT_BY_ACQTOPLEVELCHANNEL_TRADESHOW,
                CASE
                    WHEN infl_data.MARKETING_TOUCHPOINT_DATE <= amlh_opp.OPP_STAGE_1_DATE
                    AND SPLIT_PART(infl_data.INFLUENCE_CHANNEL, '.', 1) = 'Web Referral' THEN 1
                    else 0
                END AS FLAG_OPPSTG1_INFL_TOUCHPOINT_BY_ACQTOPLEVELCHANNEL_WEBREFERRAL,
                CASE
                    WHEN infl_data.MARKETING_TOUCHPOINT_DATE <= amlh_opp.OPP_STAGE_1_DATE
                    AND SPLIT_PART(infl_data.INFLUENCE_CHANNEL, '.', 1) = 'Webinar' THEN 1
                    else 0
                END AS FLAG_OPPSTG1_INFL_TOUCHPOINT_BY_ACQTOPLEVELCHANNEL_WEBINAR,
				--20250314
                CASE
                    WHEN infl_data.MARKETING_TOUCHPOINT_DATE <= amlh_opp.OPP_STAGE_1_DATE
                    AND SPLIT_PART(infl_data.INFLUENCE_CHANNEL, '.', 1) = 'E-Gift' THEN 1
                    else 0
                END AS FLAG_OPPSTG1_INFL_TOUCHPOINT_BY_ACQTOPLEVELCHANNEL_EGIFT,

                -- Influence Before Opp Close Date
                CASE
                    WHEN infl_data.MARKETING_TOUCHPOINT_DATE <= amlh_opp.OPP_CLOSE_DATE
                    AND SPLIT_PART(infl_data.INFLUENCE_CHANNEL, '.', 1) = 'Channel Referral' THEN 1
                    else 0
                END AS FLAG_OPPCLS_INFL_TOUCHPOINT_BY_ACQTOPLEVELCHANNEL_CHANNELREFERRAL,
                CASE
                    WHEN infl_data.MARKETING_TOUCHPOINT_DATE <= amlh_opp.OPP_CLOSE_DATE
                    AND SPLIT_PART(infl_data.INFLUENCE_CHANNEL, '.', 1) = 'Content Syndication' THEN 1
                    else 0
                END AS FLAG_OPPCLS_INFL_TOUCHPOINT_BY_ACQTOPLEVELCHANNEL_CONTENTSYNDICATION,
                CASE
                    WHEN infl_data.MARKETING_TOUCHPOINT_DATE <= amlh_opp.OPP_CLOSE_DATE
                    AND SPLIT_PART(infl_data.INFLUENCE_CHANNEL, '.', 1) = 'Sales Engagement' THEN 1
                    else 0
                END AS FLAG_OPPCLS_INFL_TOUCHPOINT_BY_ACQTOPLEVELCHANNEL_SALESENGAGEMENT,
                CASE
                    WHEN infl_data.MARKETING_TOUCHPOINT_DATE <= amlh_opp.OPP_CLOSE_DATE
                    AND SPLIT_PART(infl_data.INFLUENCE_CHANNEL, '.', 1) = 'Direct' THEN 1
                    else 0
                END AS FLAG_OPPCLS_INFL_TOUCHPOINT_BY_ACQTOPLEVELCHANNEL_DIRECT,
                CASE
                    WHEN infl_data.MARKETING_TOUCHPOINT_DATE <= amlh_opp.OPP_CLOSE_DATE
                    AND SPLIT_PART(infl_data.INFLUENCE_CHANNEL, '.', 1) = 'Direct Mail' THEN 1
                    else 0
                END AS FLAG_OPPCLS_INFL_TOUCHPOINT_BY_ACQTOPLEVELCHANNEL_DIRECTMAIL,
                CASE
                    WHEN infl_data.MARKETING_TOUCHPOINT_DATE <= amlh_opp.OPP_CLOSE_DATE
                    AND SPLIT_PART(infl_data.INFLUENCE_CHANNEL, '.', 1) = 'Display' THEN 1
                    else 0
                END AS FLAG_OPPCLS_INFL_TOUCHPOINT_BY_ACQTOPLEVELCHANNEL_DISPLAY,
                CASE
                    WHEN infl_data.MARKETING_TOUCHPOINT_DATE <= amlh_opp.OPP_CLOSE_DATE
                    AND SPLIT_PART(infl_data.INFLUENCE_CHANNEL, '.', 1) = 'Email' THEN 1
                    else 0
                END AS FLAG_OPPCLS_INFL_TOUCHPOINT_BY_ACQTOPLEVELCHANNEL_EMAIL,
                CASE
                    WHEN infl_data.MARKETING_TOUCHPOINT_DATE <= amlh_opp.OPP_CLOSE_DATE
                    AND SPLIT_PART(infl_data.INFLUENCE_CHANNEL, '.', 1) = 'Lead Referral' THEN 1
                    else 0
                END AS FLAG_OPPCLS_INFL_TOUCHPOINT_BY_ACQTOPLEVELCHANNEL_LEADREFERRAL,
                CASE
                    WHEN infl_data.MARKETING_TOUCHPOINT_DATE <= amlh_opp.OPP_CLOSE_DATE
                    AND SPLIT_PART(infl_data.INFLUENCE_CHANNEL, '.', 1) = 'Live Event' THEN 1
                    else 0
                END AS FLAG_OPPCLS_INFL_TOUCHPOINT_BY_ACQTOPLEVELCHANNEL_LIVEEVENT,
                CASE
                    WHEN infl_data.MARKETING_TOUCHPOINT_DATE <= amlh_opp.OPP_CLOSE_DATE
                    AND SPLIT_PART(infl_data.INFLUENCE_CHANNEL, '.', 1) = 'Lytx' THEN 1
                    else 0
                END AS FLAG_OPPCLS_INFL_TOUCHPOINT_BY_ACQTOPLEVELCHANNEL_LYTX,
                CASE
                    WHEN infl_data.MARKETING_TOUCHPOINT_DATE <= amlh_opp.OPP_CLOSE_DATE
                    AND SPLIT_PART(infl_data.INFLUENCE_CHANNEL, '.', 1) = 'Native' THEN 1
                    else 0
                END AS FLAG_OPPCLS_INFL_TOUCHPOINT_BY_ACQTOPLEVELCHANNEL_NATIVE,
                CASE
                    WHEN infl_data.MARKETING_TOUCHPOINT_DATE <= amlh_opp.OPP_CLOSE_DATE
                    AND SPLIT_PART(infl_data.INFLUENCE_CHANNEL, '.', 1) = 'Organic Search' THEN 1
                    else 0
                END AS FLAG_OPPCLS_INFL_TOUCHPOINT_BY_ACQTOPLEVELCHANNEL_ORGANICSEARCH,
                CASE
                    WHEN infl_data.MARKETING_TOUCHPOINT_DATE <= amlh_opp.OPP_CLOSE_DATE
                    AND SPLIT_PART(infl_data.INFLUENCE_CHANNEL, '.', 1) = 'Organic Social' THEN 1
                    else 0
                END AS FLAG_OPPCLS_INFL_TOUCHPOINT_BY_ACQTOPLEVELCHANNEL_ORGANICSOCIAL,
                CASE
                    WHEN infl_data.MARKETING_TOUCHPOINT_DATE <= amlh_opp.OPP_CLOSE_DATE
                    AND SPLIT_PART(infl_data.INFLUENCE_CHANNEL, '.', 1) = 'Other' THEN 1
                    else 0
                END AS FLAG_OPPCLS_INFL_TOUCHPOINT_BY_ACQTOPLEVELCHANNEL_OTHER,
                CASE
                    WHEN infl_data.MARKETING_TOUCHPOINT_DATE <= amlh_opp.OPP_CLOSE_DATE
                    AND SPLIT_PART(infl_data.INFLUENCE_CHANNEL, '.', 1) = 'Paid Media' THEN 1
                    else 0
                END AS FLAG_OPPCLS_INFL_TOUCHPOINT_BY_ACQTOPLEVELCHANNEL_PAIDMEDIA,
                CASE
                    WHEN infl_data.MARKETING_TOUCHPOINT_DATE <= amlh_opp.OPP_CLOSE_DATE
                    AND SPLIT_PART(infl_data.INFLUENCE_CHANNEL, '.', 1) = 'Paid Search' THEN 1
                    else 0
                END AS FLAG_OPPCLS_INFL_TOUCHPOINT_BY_ACQTOPLEVELCHANNEL_PAIDSEARCH,
                CASE
                    WHEN infl_data.MARKETING_TOUCHPOINT_DATE <= amlh_opp.OPP_CLOSE_DATE
                    AND SPLIT_PART(infl_data.INFLUENCE_CHANNEL, '.', 1) = 'Paid Social' THEN 1
                    else 0
                END AS FLAG_OPPCLS_INFL_TOUCHPOINT_BY_ACQTOPLEVELCHANNEL_PAIDSOCIAL,
                CASE
                    WHEN infl_data.MARKETING_TOUCHPOINT_DATE <= amlh_opp.OPP_CLOSE_DATE
                    AND SPLIT_PART(infl_data.INFLUENCE_CHANNEL, '.', 1) = 'Podcast' THEN 1
                    else 0
                END AS FLAG_OPPCLS_INFL_TOUCHPOINT_BY_ACQTOPLEVELCHANNEL_PODCAST,
                CASE
                    WHEN infl_data.MARKETING_TOUCHPOINT_DATE <= amlh_opp.OPP_CLOSE_DATE
                    AND SPLIT_PART(infl_data.INFLUENCE_CHANNEL, '.', 1) = 'PPL' THEN 1
                    else 0
                END AS FLAG_OPPCLS_INFL_TOUCHPOINT_BY_ACQTOPLEVELCHANNEL_PPL,
                CASE
                    WHEN infl_data.MARKETING_TOUCHPOINT_DATE <= amlh_opp.OPP_CLOSE_DATE
                    AND SPLIT_PART(infl_data.INFLUENCE_CHANNEL, '.', 1) = 'Print' THEN 1
                    else 0
                END AS FLAG_OPPCLS_INFL_TOUCHPOINT_BY_ACQTOPLEVELCHANNEL_PRINT,
                CASE
                    WHEN infl_data.MARKETING_TOUCHPOINT_DATE <= amlh_opp.OPP_CLOSE_DATE
                    AND SPLIT_PART(infl_data.INFLUENCE_CHANNEL, '.', 1) = 'Sponsored Email' THEN 1
                    else 0
                END AS FLAG_OPPCLS_INFL_TOUCHPOINT_BY_ACQTOPLEVELCHANNEL_SPONSOREDEMAIL,
                CASE
                    WHEN infl_data.MARKETING_TOUCHPOINT_DATE <= amlh_opp.OPP_CLOSE_DATE
                    AND SPLIT_PART(infl_data.INFLUENCE_CHANNEL, '.', 1) = 'Tradeshow' THEN 1
                    else 0
                END AS FLAG_OPPCLS_INFL_TOUCHPOINT_BY_ACQTOPLEVELCHANNEL_TRADESHOW,
                CASE
                    WHEN infl_data.MARKETING_TOUCHPOINT_DATE <= amlh_opp.OPP_CLOSE_DATE
                    AND SPLIT_PART(infl_data.INFLUENCE_CHANNEL, '.', 1) = 'Web Referral' THEN 1
                    else 0
                END AS FLAG_OPPCLS_INFL_TOUCHPOINT_BY_ACQTOPLEVELCHANNEL_WEBREFERRAL,
                CASE
                    WHEN infl_data.MARKETING_TOUCHPOINT_DATE <= amlh_opp.OPP_CLOSE_DATE
                    AND SPLIT_PART(infl_data.INFLUENCE_CHANNEL, '.', 1) = 'Webinar' THEN 1
                    else 0
                END AS FLAG_OPPCLS_INFL_TOUCHPOINT_BY_ACQTOPLEVELCHANNEL_WEBINAR,
				--20250314
                CASE
                    WHEN infl_data.MARKETING_TOUCHPOINT_DATE <= amlh_opp.OPP_CLOSE_DATE
                    AND SPLIT_PART(infl_data.INFLUENCE_CHANNEL, '.', 1) = 'E-Gift' THEN 1
                    else 0
                END AS FLAG_OPPCLS_INFL_TOUCHPOINT_BY_ACQTOPLEVELCHANNEL_EGIFT,

                -- Influence Before Act Cold
                CASE
                    WHEN infl_data.MARKETING_TOUCHPOINT_DATE <= amlh_opp.AMLH_COLD_ACCOUNT_DATE_STAMP__C
                    AND SPLIT_PART(infl_data.INFLUENCE_CHANNEL, '.', 1) = 'Channel Referral' THEN 1
                    else 0
                END AS FLAG_ACTCOLD_INFL_TOUCHPOINT_BY_ACQTOPLEVELCHANNEL_CHANNELREFERRAL,
                CASE
                    WHEN infl_data.MARKETING_TOUCHPOINT_DATE <= amlh_opp.AMLH_COLD_ACCOUNT_DATE_STAMP__C
                    AND SPLIT_PART(infl_data.INFLUENCE_CHANNEL, '.', 1) = 'Content Syndication' THEN 1
                    else 0
                END AS FLAG_ACTCOLD_INFL_TOUCHPOINT_BY_ACQTOPLEVELCHANNEL_CONTENTSYNDICATION,
                CASE
                    WHEN infl_data.MARKETING_TOUCHPOINT_DATE <= amlh_opp.AMLH_COLD_ACCOUNT_DATE_STAMP__C
                    AND SPLIT_PART(infl_data.INFLUENCE_CHANNEL, '.', 1) = 'Sales Engagement' THEN 1
                    else 0
                END AS FLAG_ACTCOLD_INFL_TOUCHPOINT_BY_ACQTOPLEVELCHANNEL_SALESENGAGEMENT,
                CASE
                    WHEN infl_data.MARKETING_TOUCHPOINT_DATE <= amlh_opp.AMLH_COLD_ACCOUNT_DATE_STAMP__C
                    AND SPLIT_PART(infl_data.INFLUENCE_CHANNEL, '.', 1) = 'Direct' THEN 1
                    else 0
                END AS FLAG_ACTCOLD_INFL_TOUCHPOINT_BY_ACQTOPLEVELCHANNEL_DIRECT,
                CASE
                    WHEN infl_data.MARKETING_TOUCHPOINT_DATE <= amlh_opp.AMLH_COLD_ACCOUNT_DATE_STAMP__C
                    AND SPLIT_PART(infl_data.INFLUENCE_CHANNEL, '.', 1) = 'Direct Mail' THEN 1
                    else 0
                END AS FLAG_ACTCOLD_INFL_TOUCHPOINT_BY_ACQTOPLEVELCHANNEL_DIRECTMAIL,
                CASE
                    WHEN infl_data.MARKETING_TOUCHPOINT_DATE <= amlh_opp.AMLH_COLD_ACCOUNT_DATE_STAMP__C
                    AND SPLIT_PART(infl_data.INFLUENCE_CHANNEL, '.', 1) = 'Display' THEN 1
                    else 0
                END AS FLAG_ACTCOLD_INFL_TOUCHPOINT_BY_ACQTOPLEVELCHANNEL_DISPLAY,
                CASE
                    WHEN infl_data.MARKETING_TOUCHPOINT_DATE <= amlh_opp.AMLH_COLD_ACCOUNT_DATE_STAMP__C
                    AND SPLIT_PART(infl_data.INFLUENCE_CHANNEL, '.', 1) = 'Email' THEN 1
                    else 0
                END AS FLAG_ACTCOLD_INFL_TOUCHPOINT_BY_ACQTOPLEVELCHANNEL_EMAIL,
                CASE
                    WHEN infl_data.MARKETING_TOUCHPOINT_DATE <= amlh_opp.AMLH_COLD_ACCOUNT_DATE_STAMP__C
                    AND SPLIT_PART(infl_data.INFLUENCE_CHANNEL, '.', 1) = 'Lead Referral' THEN 1
                    else 0
                END AS FLAG_ACTCOLD_INFL_TOUCHPOINT_BY_ACQTOPLEVELCHANNEL_LEADREFERRAL,
                CASE
                    WHEN infl_data.MARKETING_TOUCHPOINT_DATE <= amlh_opp.AMLH_COLD_ACCOUNT_DATE_STAMP__C
                    AND SPLIT_PART(infl_data.INFLUENCE_CHANNEL, '.', 1) = 'Live Event' THEN 1
                    else 0
                END AS FLAG_ACTCOLD_INFL_TOUCHPOINT_BY_ACQTOPLEVELCHANNEL_LIVEEVENT,
                CASE
                    WHEN infl_data.MARKETING_TOUCHPOINT_DATE <= amlh_opp.AMLH_COLD_ACCOUNT_DATE_STAMP__C
                    AND SPLIT_PART(infl_data.INFLUENCE_CHANNEL, '.', 1) = 'Lytx' THEN 1
                    else 0
                END AS FLAG_ACTCOLD_INFL_TOUCHPOINT_BY_ACQTOPLEVELCHANNEL_LYTX,
                CASE
                    WHEN infl_data.MARKETING_TOUCHPOINT_DATE <= amlh_opp.AMLH_COLD_ACCOUNT_DATE_STAMP__C
                    AND SPLIT_PART(infl_data.INFLUENCE_CHANNEL, '.', 1) = 'Native' THEN 1
                    else 0
                END AS FLAG_ACTCOLD_INFL_TOUCHPOINT_BY_ACQTOPLEVELCHANNEL_NATIVE,
                CASE
                    WHEN infl_data.MARKETING_TOUCHPOINT_DATE <= amlh_opp.AMLH_COLD_ACCOUNT_DATE_STAMP__C
                    AND SPLIT_PART(infl_data.INFLUENCE_CHANNEL, '.', 1) = 'Organic Search' THEN 1
                    else 0
                END AS FLAG_ACTCOLD_INFL_TOUCHPOINT_BY_ACQTOPLEVELCHANNEL_ORGANICSEARCH,
                CASE
                    WHEN infl_data.MARKETING_TOUCHPOINT_DATE <= amlh_opp.AMLH_COLD_ACCOUNT_DATE_STAMP__C
                    AND SPLIT_PART(infl_data.INFLUENCE_CHANNEL, '.', 1) = 'Organic Social' THEN 1
                    else 0
                END AS FLAG_ACTCOLD_INFL_TOUCHPOINT_BY_ACQTOPLEVELCHANNEL_ORGANICSOCIAL,
                CASE
                    WHEN infl_data.MARKETING_TOUCHPOINT_DATE <= amlh_opp.AMLH_COLD_ACCOUNT_DATE_STAMP__C
                    AND SPLIT_PART(infl_data.INFLUENCE_CHANNEL, '.', 1) = 'Other' THEN 1
                    else 0
                END AS FLAG_ACTCOLD_INFL_TOUCHPOINT_BY_ACQTOPLEVELCHANNEL_OTHER,
                CASE
                    WHEN infl_data.MARKETING_TOUCHPOINT_DATE <= amlh_opp.AMLH_COLD_ACCOUNT_DATE_STAMP__C
                    AND SPLIT_PART(infl_data.INFLUENCE_CHANNEL, '.', 1) = 'Paid Media' THEN 1
                    else 0
                END AS FLAG_ACTCOLD_INFL_TOUCHPOINT_BY_ACQTOPLEVELCHANNEL_PAIDMEDIA,
                CASE
                    WHEN infl_data.MARKETING_TOUCHPOINT_DATE <= amlh_opp.AMLH_COLD_ACCOUNT_DATE_STAMP__C
                    AND SPLIT_PART(infl_data.INFLUENCE_CHANNEL, '.', 1) = 'Paid Search' THEN 1
                    else 0
                END AS FLAG_ACTCOLD_INFL_TOUCHPOINT_BY_ACQTOPLEVELCHANNEL_PAIDSEARCH,
                CASE
                    WHEN infl_data.MARKETING_TOUCHPOINT_DATE <= amlh_opp.AMLH_COLD_ACCOUNT_DATE_STAMP__C
                    AND SPLIT_PART(infl_data.INFLUENCE_CHANNEL, '.', 1) = 'Paid Social' THEN 1
                    else 0
                END AS FLAG_ACTCOLD_INFL_TOUCHPOINT_BY_ACQTOPLEVELCHANNEL_PAIDSOCIAL,
                CASE
                    WHEN infl_data.MARKETING_TOUCHPOINT_DATE <= amlh_opp.AMLH_COLD_ACCOUNT_DATE_STAMP__C
                    AND SPLIT_PART(infl_data.INFLUENCE_CHANNEL, '.', 1) = 'Podcast' THEN 1
                    else 0
                END AS FLAG_ACTCOLD_INFL_TOUCHPOINT_BY_ACQTOPLEVELCHANNEL_PODCAST,
                CASE
                    WHEN infl_data.MARKETING_TOUCHPOINT_DATE <= amlh_opp.AMLH_COLD_ACCOUNT_DATE_STAMP__C
                    AND SPLIT_PART(infl_data.INFLUENCE_CHANNEL, '.', 1) = 'PPL' THEN 1
                    else 0
                END AS FLAG_ACTCOLD_INFL_TOUCHPOINT_BY_ACQTOPLEVELCHANNEL_PPL,
                CASE
                    WHEN infl_data.MARKETING_TOUCHPOINT_DATE <= amlh_opp.AMLH_COLD_ACCOUNT_DATE_STAMP__C
                    AND SPLIT_PART(infl_data.INFLUENCE_CHANNEL, '.', 1) = 'Print' THEN 1
                    else 0
                END AS FLAG_ACTCOLD_INFL_TOUCHPOINT_BY_ACQTOPLEVELCHANNEL_PRINT,
                CASE
                    WHEN infl_data.MARKETING_TOUCHPOINT_DATE <= amlh_opp.AMLH_COLD_ACCOUNT_DATE_STAMP__C
                    AND SPLIT_PART(infl_data.INFLUENCE_CHANNEL, '.', 1) = 'Sponsored Email' THEN 1
                    else 0
                END AS FLAG_ACTCOLD_INFL_TOUCHPOINT_BY_ACQTOPLEVELCHANNEL_SPONSOREDEMAIL,
                CASE
                    WHEN infl_data.MARKETING_TOUCHPOINT_DATE <= amlh_opp.AMLH_COLD_ACCOUNT_DATE_STAMP__C
                    AND SPLIT_PART(infl_data.INFLUENCE_CHANNEL, '.', 1) = 'Tradeshow' THEN 1
                    else 0
                END AS FLAG_ACTCOLD_INFL_TOUCHPOINT_BY_ACQTOPLEVELCHANNEL_TRADESHOW,
                CASE
                    WHEN infl_data.MARKETING_TOUCHPOINT_DATE <= amlh_opp.AMLH_COLD_ACCOUNT_DATE_STAMP__C
                    AND SPLIT_PART(infl_data.INFLUENCE_CHANNEL, '.', 1) = 'Web Referral' THEN 1
                    else 0
                END AS FLAG_ACTCOLD_INFL_TOUCHPOINT_BY_ACQTOPLEVELCHANNEL_WEBREFERRAL,
                CASE
                    WHEN infl_data.MARKETING_TOUCHPOINT_DATE <= amlh_opp.AMLH_COLD_ACCOUNT_DATE_STAMP__C
                    AND SPLIT_PART(infl_data.INFLUENCE_CHANNEL, '.', 1) = 'Webinar' THEN 1
                    else 0
                END AS FLAG_ACTCOLD_INFL_TOUCHPOINT_BY_ACQTOPLEVELCHANNEL_WEBINAR,
				--20250314
                CASE
                    WHEN infl_data.MARKETING_TOUCHPOINT_DATE <= amlh_opp.AMLH_COLD_ACCOUNT_DATE_STAMP__C
                    AND SPLIT_PART(infl_data.INFLUENCE_CHANNEL, '.', 1) = 'E-Gift' THEN 1
                    else 0
                END AS FLAG_ACTCOLD_INFL_TOUCHPOINT_BY_ACQTOPLEVELCHANNEL_EGIFT,
				
                -- Influence Before Act MEA
                CASE
                    WHEN infl_data.MARKETING_TOUCHPOINT_DATE <= amlh_opp.AMLH_MEA_DATE_STAMP__C
                    AND SPLIT_PART(infl_data.INFLUENCE_CHANNEL, '.', 1) = 'Channel Referral' THEN 1
                    else 0
                END AS FLAG_ACTMEA_INFL_TOUCHPOINT_BY_ACQTOPLEVELCHANNEL_CHANNELREFERRAL,
                CASE
                    WHEN infl_data.MARKETING_TOUCHPOINT_DATE <= amlh_opp.AMLH_MEA_DATE_STAMP__C
                    AND SPLIT_PART(infl_data.INFLUENCE_CHANNEL, '.', 1) = 'Content Syndication' THEN 1
                    else 0
                END AS FLAG_ACTMEA_INFL_TOUCHPOINT_BY_ACQTOPLEVELCHANNEL_CONTENTSYNDICATION,
                CASE
                    WHEN infl_data.MARKETING_TOUCHPOINT_DATE <= amlh_opp.AMLH_MEA_DATE_STAMP__C
                    AND SPLIT_PART(infl_data.INFLUENCE_CHANNEL, '.', 1) = 'Sales Engagement' THEN 1
                    else 0
                END AS FLAG_ACTMEA_INFL_TOUCHPOINT_BY_ACQTOPLEVELCHANNEL_SALESENGAGEMENT,
                CASE
                    WHEN infl_data.MARKETING_TOUCHPOINT_DATE <= amlh_opp.AMLH_MEA_DATE_STAMP__C
                    AND SPLIT_PART(infl_data.INFLUENCE_CHANNEL, '.', 1) = 'Direct' THEN 1
                    else 0
                END AS FLAG_ACTMEA_INFL_TOUCHPOINT_BY_ACQTOPLEVELCHANNEL_DIRECT,
                CASE
                    WHEN infl_data.MARKETING_TOUCHPOINT_DATE <= amlh_opp.AMLH_MEA_DATE_STAMP__C
                    AND SPLIT_PART(infl_data.INFLUENCE_CHANNEL, '.', 1) = 'Direct Mail' THEN 1
                    else 0
                END AS FLAG_ACTMEA_INFL_TOUCHPOINT_BY_ACQTOPLEVELCHANNEL_DIRECTMAIL,
                CASE
                    WHEN infl_data.MARKETING_TOUCHPOINT_DATE <= amlh_opp.AMLH_MEA_DATE_STAMP__C
                    AND SPLIT_PART(infl_data.INFLUENCE_CHANNEL, '.', 1) = 'Display' THEN 1
                    else 0
                END AS FLAG_ACTMEA_INFL_TOUCHPOINT_BY_ACQTOPLEVELCHANNEL_DISPLAY,
                CASE
                    WHEN infl_data.MARKETING_TOUCHPOINT_DATE <= amlh_opp.AMLH_MEA_DATE_STAMP__C
                    AND SPLIT_PART(infl_data.INFLUENCE_CHANNEL, '.', 1) = 'Email' THEN 1
                    else 0
                END AS FLAG_ACTMEA_INFL_TOUCHPOINT_BY_ACQTOPLEVELCHANNEL_EMAIL,
                CASE
                    WHEN infl_data.MARKETING_TOUCHPOINT_DATE <= amlh_opp.AMLH_MEA_DATE_STAMP__C
                    AND SPLIT_PART(infl_data.INFLUENCE_CHANNEL, '.', 1) = 'Lead Referral' THEN 1
                    else 0
                END AS FLAG_ACTMEA_INFL_TOUCHPOINT_BY_ACQTOPLEVELCHANNEL_LEADREFERRAL,
                CASE
                    WHEN infl_data.MARKETING_TOUCHPOINT_DATE <= amlh_opp.AMLH_MEA_DATE_STAMP__C
                    AND SPLIT_PART(infl_data.INFLUENCE_CHANNEL, '.', 1) = 'Live Event' THEN 1
                    else 0
                END AS FLAG_ACTMEA_INFL_TOUCHPOINT_BY_ACQTOPLEVELCHANNEL_LIVEEVENT,
                CASE
                    WHEN infl_data.MARKETING_TOUCHPOINT_DATE <= amlh_opp.AMLH_MEA_DATE_STAMP__C
                    AND SPLIT_PART(infl_data.INFLUENCE_CHANNEL, '.', 1) = 'Lytx' THEN 1
                    else 0
                END AS FLAG_ACTMEA_INFL_TOUCHPOINT_BY_ACQTOPLEVELCHANNEL_LYTX,
                CASE
                    WHEN infl_data.MARKETING_TOUCHPOINT_DATE <= amlh_opp.AMLH_MEA_DATE_STAMP__C
                    AND SPLIT_PART(infl_data.INFLUENCE_CHANNEL, '.', 1) = 'Native' THEN 1
                    else 0
                END AS FLAG_ACTMEA_INFL_TOUCHPOINT_BY_ACQTOPLEVELCHANNEL_NATIVE,
                CASE
                    WHEN infl_data.MARKETING_TOUCHPOINT_DATE <= amlh_opp.AMLH_MEA_DATE_STAMP__C
                    AND SPLIT_PART(infl_data.INFLUENCE_CHANNEL, '.', 1) = 'Organic Search' THEN 1
                    else 0
                END AS FLAG_ACTMEA_INFL_TOUCHPOINT_BY_ACQTOPLEVELCHANNEL_ORGANICSEARCH,
                CASE
                    WHEN infl_data.MARKETING_TOUCHPOINT_DATE <= amlh_opp.AMLH_MEA_DATE_STAMP__C
                    AND SPLIT_PART(infl_data.INFLUENCE_CHANNEL, '.', 1) = 'Organic Social' THEN 1
                    else 0
                END AS FLAG_ACTMEA_INFL_TOUCHPOINT_BY_ACQTOPLEVELCHANNEL_ORGANICSOCIAL,
                CASE
                    WHEN infl_data.MARKETING_TOUCHPOINT_DATE <= amlh_opp.AMLH_MEA_DATE_STAMP__C
                    AND SPLIT_PART(infl_data.INFLUENCE_CHANNEL, '.', 1) = 'Other' THEN 1
                    else 0
                END AS FLAG_ACTMEA_INFL_TOUCHPOINT_BY_ACQTOPLEVELCHANNEL_OTHER,
                CASE
                    WHEN infl_data.MARKETING_TOUCHPOINT_DATE <= amlh_opp.AMLH_MEA_DATE_STAMP__C
                    AND SPLIT_PART(infl_data.INFLUENCE_CHANNEL, '.', 1) = 'Paid Media' THEN 1
                    else 0
                END AS FLAG_ACTMEA_INFL_TOUCHPOINT_BY_ACQTOPLEVELCHANNEL_PAIDMEDIA,
                CASE
                    WHEN infl_data.MARKETING_TOUCHPOINT_DATE <= amlh_opp.AMLH_MEA_DATE_STAMP__C
                    AND SPLIT_PART(infl_data.INFLUENCE_CHANNEL, '.', 1) = 'Paid Search' THEN 1
                    else 0
                END AS FLAG_ACTMEA_INFL_TOUCHPOINT_BY_ACQTOPLEVELCHANNEL_PAIDSEARCH,
                CASE
                    WHEN infl_data.MARKETING_TOUCHPOINT_DATE <= amlh_opp.AMLH_MEA_DATE_STAMP__C
                    AND SPLIT_PART(infl_data.INFLUENCE_CHANNEL, '.', 1) = 'Paid Social' THEN 1
                    else 0
                END AS FLAG_ACTMEA_INFL_TOUCHPOINT_BY_ACQTOPLEVELCHANNEL_PAIDSOCIAL,
                CASE
                    WHEN infl_data.MARKETING_TOUCHPOINT_DATE <= amlh_opp.AMLH_MEA_DATE_STAMP__C
                    AND SPLIT_PART(infl_data.INFLUENCE_CHANNEL, '.', 1) = 'Podcast' THEN 1
                    else 0
                END AS FLAG_ACTMEA_INFL_TOUCHPOINT_BY_ACQTOPLEVELCHANNEL_PODCAST,
                CASE
                    WHEN infl_data.MARKETING_TOUCHPOINT_DATE <= amlh_opp.AMLH_MEA_DATE_STAMP__C
                    AND SPLIT_PART(infl_data.INFLUENCE_CHANNEL, '.', 1) = 'PPL' THEN 1
                    else 0
                END AS FLAG_ACTMEA_INFL_TOUCHPOINT_BY_ACQTOPLEVELCHANNEL_PPL,
                CASE
                    WHEN infl_data.MARKETING_TOUCHPOINT_DATE <= amlh_opp.AMLH_MEA_DATE_STAMP__C
                    AND SPLIT_PART(infl_data.INFLUENCE_CHANNEL, '.', 1) = 'Print' THEN 1
                    else 0
                END AS FLAG_ACTMEA_INFL_TOUCHPOINT_BY_ACQTOPLEVELCHANNEL_PRINT,
                CASE
                    WHEN infl_data.MARKETING_TOUCHPOINT_DATE <= amlh_opp.AMLH_MEA_DATE_STAMP__C
                    AND SPLIT_PART(infl_data.INFLUENCE_CHANNEL, '.', 1) = 'Sponsored Email' THEN 1
                    else 0
                END AS FLAG_ACTMEA_INFL_TOUCHPOINT_BY_ACQTOPLEVELCHANNEL_SPONSOREDEMAIL,
                CASE
                    WHEN infl_data.MARKETING_TOUCHPOINT_DATE <= amlh_opp.AMLH_MEA_DATE_STAMP__C
                    AND SPLIT_PART(infl_data.INFLUENCE_CHANNEL, '.', 1) = 'Tradeshow' THEN 1
                    else 0
                END AS FLAG_ACTMEA_INFL_TOUCHPOINT_BY_ACQTOPLEVELCHANNEL_TRADESHOW,
                CASE
                    WHEN infl_data.MARKETING_TOUCHPOINT_DATE <= amlh_opp.AMLH_MEA_DATE_STAMP__C
                    AND SPLIT_PART(infl_data.INFLUENCE_CHANNEL, '.', 1) = 'Web Referral' THEN 1
                    else 0
                END AS FLAG_ACTMEA_INFL_TOUCHPOINT_BY_ACQTOPLEVELCHANNEL_WEBREFERRAL,
                CASE
                    WHEN infl_data.MARKETING_TOUCHPOINT_DATE <= amlh_opp.AMLH_MEA_DATE_STAMP__C
                    AND SPLIT_PART(infl_data.INFLUENCE_CHANNEL, '.', 1) = 'Webinar' THEN 1
                    else 0
                END AS FLAG_ACTMEA_INFL_TOUCHPOINT_BY_ACQTOPLEVELCHANNEL_WEBINAR,
				--20250314
                CASE
                    WHEN infl_data.MARKETING_TOUCHPOINT_DATE <= amlh_opp.AMLH_MEA_DATE_STAMP__C
                    AND SPLIT_PART(infl_data.INFLUENCE_CHANNEL, '.', 1) = 'E-Gift' THEN 1
                    else 0
                END AS FLAG_ACTMEA_INFL_TOUCHPOINT_BY_ACQTOPLEVELCHANNEL_EGIFT,
				
                -- Influence Before Act MQA
                CASE
                    WHEN infl_data.MARKETING_TOUCHPOINT_DATE <= amlh_opp.AMLH_MQA_DATE_STAMP__C
                    AND SPLIT_PART(infl_data.INFLUENCE_CHANNEL, '.', 1) = 'Channel Referral' THEN 1
                    else 0
                END AS FLAG_ACTMQA_INFL_TOUCHPOINT_BY_ACQTOPLEVELCHANNEL_CHANNELREFERRAL,
                CASE
                    WHEN infl_data.MARKETING_TOUCHPOINT_DATE <= amlh_opp.AMLH_MQA_DATE_STAMP__C
                    AND SPLIT_PART(infl_data.INFLUENCE_CHANNEL, '.', 1) = 'Content Syndication' THEN 1
                    else 0
                END AS FLAG_ACTMQA_INFL_TOUCHPOINT_BY_ACQTOPLEVELCHANNEL_CONTENTSYNDICATION,
                CASE
                    WHEN infl_data.MARKETING_TOUCHPOINT_DATE <= amlh_opp.AMLH_MQA_DATE_STAMP__C
                    AND SPLIT_PART(infl_data.INFLUENCE_CHANNEL, '.', 1) = 'Sales Engagement' THEN 1
                    else 0
                END AS FLAG_ACTMQA_INFL_TOUCHPOINT_BY_ACQTOPLEVELCHANNEL_SALESENGAGEMENT,
                CASE
                    WHEN infl_data.MARKETING_TOUCHPOINT_DATE <= amlh_opp.AMLH_MQA_DATE_STAMP__C
                    AND SPLIT_PART(infl_data.INFLUENCE_CHANNEL, '.', 1) = 'Direct' THEN 1
                    else 0
                END AS FLAG_ACTMQA_INFL_TOUCHPOINT_BY_ACQTOPLEVELCHANNEL_DIRECT,
                CASE
                    WHEN infl_data.MARKETING_TOUCHPOINT_DATE <= amlh_opp.AMLH_MQA_DATE_STAMP__C
                    AND SPLIT_PART(infl_data.INFLUENCE_CHANNEL, '.', 1) = 'Direct Mail' THEN 1
                    else 0
                END AS FLAG_ACTMQA_INFL_TOUCHPOINT_BY_ACQTOPLEVELCHANNEL_DIRECTMAIL,
                CASE
                    WHEN infl_data.MARKETING_TOUCHPOINT_DATE <= amlh_opp.AMLH_MQA_DATE_STAMP__C
                    AND SPLIT_PART(infl_data.INFLUENCE_CHANNEL, '.', 1) = 'Display' THEN 1
                    else 0
                END AS FLAG_ACTMQA_INFL_TOUCHPOINT_BY_ACQTOPLEVELCHANNEL_DISPLAY,
                CASE
                    WHEN infl_data.MARKETING_TOUCHPOINT_DATE <= amlh_opp.AMLH_MQA_DATE_STAMP__C
                    AND SPLIT_PART(infl_data.INFLUENCE_CHANNEL, '.', 1) = 'Email' THEN 1
                    else 0
                END AS FLAG_ACTMQA_INFL_TOUCHPOINT_BY_ACQTOPLEVELCHANNEL_EMAIL,
                CASE
                    WHEN infl_data.MARKETING_TOUCHPOINT_DATE <= amlh_opp.AMLH_MQA_DATE_STAMP__C
                    AND SPLIT_PART(infl_data.INFLUENCE_CHANNEL, '.', 1) = 'Lead Referral' THEN 1
                    else 0
                END AS FLAG_ACTMQA_INFL_TOUCHPOINT_BY_ACQTOPLEVELCHANNEL_LEADREFERRAL,
                CASE
                    WHEN infl_data.MARKETING_TOUCHPOINT_DATE <= amlh_opp.AMLH_MQA_DATE_STAMP__C
                    AND SPLIT_PART(infl_data.INFLUENCE_CHANNEL, '.', 1) = 'Live Event' THEN 1
                    else 0
                END AS FLAG_ACTMQA_INFL_TOUCHPOINT_BY_ACQTOPLEVELCHANNEL_LIVEEVENT,
                CASE
                    WHEN infl_data.MARKETING_TOUCHPOINT_DATE <= amlh_opp.AMLH_MQA_DATE_STAMP__C
                    AND SPLIT_PART(infl_data.INFLUENCE_CHANNEL, '.', 1) = 'Lytx' THEN 1
                    else 0
                END AS FLAG_ACTMQA_INFL_TOUCHPOINT_BY_ACQTOPLEVELCHANNEL_LYTX,
                CASE
                    WHEN infl_data.MARKETING_TOUCHPOINT_DATE <= amlh_opp.AMLH_MQA_DATE_STAMP__C
                    AND SPLIT_PART(infl_data.INFLUENCE_CHANNEL, '.', 1) = 'Native' THEN 1
                    else 0
                END AS FLAG_ACTMQA_INFL_TOUCHPOINT_BY_ACQTOPLEVELCHANNEL_NATIVE,
                CASE
                    WHEN infl_data.MARKETING_TOUCHPOINT_DATE <= amlh_opp.AMLH_MQA_DATE_STAMP__C
                    AND SPLIT_PART(infl_data.INFLUENCE_CHANNEL, '.', 1) = 'Organic Search' THEN 1
                    else 0
                END AS FLAG_ACTMQA_INFL_TOUCHPOINT_BY_ACQTOPLEVELCHANNEL_ORGANICSEARCH,
                CASE
                    WHEN infl_data.MARKETING_TOUCHPOINT_DATE <= amlh_opp.AMLH_MQA_DATE_STAMP__C
                    AND SPLIT_PART(infl_data.INFLUENCE_CHANNEL, '.', 1) = 'Organic Social' THEN 1
                    else 0
                END AS FLAG_ACTMQA_INFL_TOUCHPOINT_BY_ACQTOPLEVELCHANNEL_ORGANICSOCIAL,
                CASE
                    WHEN infl_data.MARKETING_TOUCHPOINT_DATE <= amlh_opp.AMLH_MQA_DATE_STAMP__C
                    AND SPLIT_PART(infl_data.INFLUENCE_CHANNEL, '.', 1) = 'Other' THEN 1
                    else 0
                END AS FLAG_ACTMQA_INFL_TOUCHPOINT_BY_ACQTOPLEVELCHANNEL_OTHER,
                CASE
                    WHEN infl_data.MARKETING_TOUCHPOINT_DATE <= amlh_opp.AMLH_MQA_DATE_STAMP__C
                    AND SPLIT_PART(infl_data.INFLUENCE_CHANNEL, '.', 1) = 'Paid Media' THEN 1
                    else 0
                END AS FLAG_ACTMQA_INFL_TOUCHPOINT_BY_ACQTOPLEVELCHANNEL_PAIDMEDIA,
                CASE
                    WHEN infl_data.MARKETING_TOUCHPOINT_DATE <= amlh_opp.AMLH_MQA_DATE_STAMP__C
                    AND SPLIT_PART(infl_data.INFLUENCE_CHANNEL, '.', 1) = 'Paid Search' THEN 1
                    else 0
                END AS FLAG_ACTMQA_INFL_TOUCHPOINT_BY_ACQTOPLEVELCHANNEL_PAIDSEARCH,
                CASE
                    WHEN infl_data.MARKETING_TOUCHPOINT_DATE <= amlh_opp.AMLH_MQA_DATE_STAMP__C
                    AND SPLIT_PART(infl_data.INFLUENCE_CHANNEL, '.', 1) = 'Paid Social' THEN 1
                    else 0
                END AS FLAG_ACTMQA_INFL_TOUCHPOINT_BY_ACQTOPLEVELCHANNEL_PAIDSOCIAL,
                CASE
                    WHEN infl_data.MARKETING_TOUCHPOINT_DATE <= amlh_opp.AMLH_MQA_DATE_STAMP__C
                    AND SPLIT_PART(infl_data.INFLUENCE_CHANNEL, '.', 1) = 'Podcast' THEN 1
                    else 0
                END AS FLAG_ACTMQA_INFL_TOUCHPOINT_BY_ACQTOPLEVELCHANNEL_PODCAST,
                CASE
                    WHEN infl_data.MARKETING_TOUCHPOINT_DATE <= amlh_opp.AMLH_MQA_DATE_STAMP__C
                    AND SPLIT_PART(infl_data.INFLUENCE_CHANNEL, '.', 1) = 'PPL' THEN 1
                    else 0
                END AS FLAG_ACTMQA_INFL_TOUCHPOINT_BY_ACQTOPLEVELCHANNEL_PPL,
                CASE
                    WHEN infl_data.MARKETING_TOUCHPOINT_DATE <= amlh_opp.AMLH_MQA_DATE_STAMP__C
                    AND SPLIT_PART(infl_data.INFLUENCE_CHANNEL, '.', 1) = 'Print' THEN 1
                    else 0
                END AS FLAG_ACTMQA_INFL_TOUCHPOINT_BY_ACQTOPLEVELCHANNEL_PRINT,
                CASE
                    WHEN infl_data.MARKETING_TOUCHPOINT_DATE <= amlh_opp.AMLH_MQA_DATE_STAMP__C
                    AND SPLIT_PART(infl_data.INFLUENCE_CHANNEL, '.', 1) = 'Sponsored Email' THEN 1
                    else 0
                END AS FLAG_ACTMQA_INFL_TOUCHPOINT_BY_ACQTOPLEVELCHANNEL_SPONSOREDEMAIL,
                CASE
                    WHEN infl_data.MARKETING_TOUCHPOINT_DATE <= amlh_opp.AMLH_MQA_DATE_STAMP__C
                    AND SPLIT_PART(infl_data.INFLUENCE_CHANNEL, '.', 1) = 'Tradeshow' THEN 1
                    else 0
                END AS FLAG_ACTMQA_INFL_TOUCHPOINT_BY_ACQTOPLEVELCHANNEL_TRADESHOW,
                CASE
                    WHEN infl_data.MARKETING_TOUCHPOINT_DATE <= amlh_opp.AMLH_MQA_DATE_STAMP__C
                    AND SPLIT_PART(infl_data.INFLUENCE_CHANNEL, '.', 1) = 'Web Referral' THEN 1
                    else 0
                END AS FLAG_ACTMQA_INFL_TOUCHPOINT_BY_ACQTOPLEVELCHANNEL_WEBREFERRAL,
                CASE
                    WHEN infl_data.MARKETING_TOUCHPOINT_DATE <= amlh_opp.AMLH_MQA_DATE_STAMP__C
                    AND SPLIT_PART(infl_data.INFLUENCE_CHANNEL, '.', 1) = 'Webinar' THEN 1
                    else 0
                END AS FLAG_ACTMQA_INFL_TOUCHPOINT_BY_ACQTOPLEVELCHANNEL_WEBINAR,
				--20250314
                CASE
                    WHEN infl_data.MARKETING_TOUCHPOINT_DATE <= amlh_opp.AMLH_MQA_DATE_STAMP__C
                    AND SPLIT_PART(infl_data.INFLUENCE_CHANNEL, '.', 1) = 'E-Gift' THEN 1
                    else 0
                END AS FLAG_ACTMQA_INFL_TOUCHPOINT_BY_ACQTOPLEVELCHANNEL_EGIFT,
				
                -- Influence Before Act SUSPECT
                CASE
                    WHEN infl_data.MARKETING_TOUCHPOINT_DATE <= amlh_opp.AMLH_SUSPECT_DATE_STAMP__C
                    AND SPLIT_PART(infl_data.INFLUENCE_CHANNEL, '.', 1) = 'Channel Referral' THEN 1
                    else 0
                END AS FLAG_ACTSUSPECT_INFL_TOUCHPOINT_BY_ACQTOPLEVELCHANNEL_CHANNELREFERRAL,
                CASE
                    WHEN infl_data.MARKETING_TOUCHPOINT_DATE <= amlh_opp.AMLH_SUSPECT_DATE_STAMP__C
                    AND SPLIT_PART(infl_data.INFLUENCE_CHANNEL, '.', 1) = 'Content Syndication' THEN 1
                    else 0
                END AS FLAG_ACTSUSPECT_INFL_TOUCHPOINT_BY_ACQTOPLEVELCHANNEL_CONTENTSYNDICATION,
                CASE
                    WHEN infl_data.MARKETING_TOUCHPOINT_DATE <= amlh_opp.AMLH_SUSPECT_DATE_STAMP__C
                    AND SPLIT_PART(infl_data.INFLUENCE_CHANNEL, '.', 1) = 'Sales Engagement' THEN 1
                    else 0
                END AS FLAG_ACTSUSPECT_INFL_TOUCHPOINT_BY_ACQTOPLEVELCHANNEL_SALESENGAGEMENT,
                CASE
                    WHEN infl_data.MARKETING_TOUCHPOINT_DATE <= amlh_opp.AMLH_SUSPECT_DATE_STAMP__C
                    AND SPLIT_PART(infl_data.INFLUENCE_CHANNEL, '.', 1) = 'Direct' THEN 1
                    else 0
                END AS FLAG_ACTSUSPECT_INFL_TOUCHPOINT_BY_ACQTOPLEVELCHANNEL_DIRECT,
                CASE
                    WHEN infl_data.MARKETING_TOUCHPOINT_DATE <= amlh_opp.AMLH_SUSPECT_DATE_STAMP__C
                    AND SPLIT_PART(infl_data.INFLUENCE_CHANNEL, '.', 1) = 'Direct Mail' THEN 1
                    else 0
                END AS FLAG_ACTSUSPECT_INFL_TOUCHPOINT_BY_ACQTOPLEVELCHANNEL_DIRECTMAIL,
                CASE
                    WHEN infl_data.MARKETING_TOUCHPOINT_DATE <= amlh_opp.AMLH_SUSPECT_DATE_STAMP__C
                    AND SPLIT_PART(infl_data.INFLUENCE_CHANNEL, '.', 1) = 'Display' THEN 1
                    else 0
                END AS FLAG_ACTSUSPECT_INFL_TOUCHPOINT_BY_ACQTOPLEVELCHANNEL_DISPLAY,
                CASE
                    WHEN infl_data.MARKETING_TOUCHPOINT_DATE <= amlh_opp.AMLH_SUSPECT_DATE_STAMP__C
                    AND SPLIT_PART(infl_data.INFLUENCE_CHANNEL, '.', 1) = 'Email' THEN 1
                    else 0
                END AS FLAG_ACTSUSPECT_INFL_TOUCHPOINT_BY_ACQTOPLEVELCHANNEL_EMAIL,
                CASE
                    WHEN infl_data.MARKETING_TOUCHPOINT_DATE <= amlh_opp.AMLH_SUSPECT_DATE_STAMP__C
                    AND SPLIT_PART(infl_data.INFLUENCE_CHANNEL, '.', 1) = 'Lead Referral' THEN 1
                    else 0
                END AS FLAG_ACTSUSPECT_INFL_TOUCHPOINT_BY_ACQTOPLEVELCHANNEL_LEADREFERRAL,
                CASE
                    WHEN infl_data.MARKETING_TOUCHPOINT_DATE <= amlh_opp.AMLH_SUSPECT_DATE_STAMP__C
                    AND SPLIT_PART(infl_data.INFLUENCE_CHANNEL, '.', 1) = 'Live Event' THEN 1
                    else 0
                END AS FLAG_ACTSUSPECT_INFL_TOUCHPOINT_BY_ACQTOPLEVELCHANNEL_LIVEEVENT,
                CASE
                    WHEN infl_data.MARKETING_TOUCHPOINT_DATE <= amlh_opp.AMLH_SUSPECT_DATE_STAMP__C
                    AND SPLIT_PART(infl_data.INFLUENCE_CHANNEL, '.', 1) = 'Lytx' THEN 1
                    else 0
                END AS FLAG_ACTSUSPECT_INFL_TOUCHPOINT_BY_ACQTOPLEVELCHANNEL_LYTX,
                CASE
                    WHEN infl_data.MARKETING_TOUCHPOINT_DATE <= amlh_opp.AMLH_SUSPECT_DATE_STAMP__C
                    AND SPLIT_PART(infl_data.INFLUENCE_CHANNEL, '.', 1) = 'Native' THEN 1
                    else 0
                END AS FLAG_ACTSUSPECT_INFL_TOUCHPOINT_BY_ACQTOPLEVELCHANNEL_NATIVE,
                CASE
                    WHEN infl_data.MARKETING_TOUCHPOINT_DATE <= amlh_opp.AMLH_SUSPECT_DATE_STAMP__C
                    AND SPLIT_PART(infl_data.INFLUENCE_CHANNEL, '.', 1) = 'Organic Search' THEN 1
                    else 0
                END AS FLAG_ACTSUSPECT_INFL_TOUCHPOINT_BY_ACQTOPLEVELCHANNEL_ORGANICSEARCH,
                CASE
                    WHEN infl_data.MARKETING_TOUCHPOINT_DATE <= amlh_opp.AMLH_SUSPECT_DATE_STAMP__C
                    AND SPLIT_PART(infl_data.INFLUENCE_CHANNEL, '.', 1) = 'Organic Social' THEN 1
                    else 0
                END AS FLAG_ACTSUSPECT_INFL_TOUCHPOINT_BY_ACQTOPLEVELCHANNEL_ORGANICSOCIAL,
                CASE
                    WHEN infl_data.MARKETING_TOUCHPOINT_DATE <= amlh_opp.AMLH_SUSPECT_DATE_STAMP__C
                    AND SPLIT_PART(infl_data.INFLUENCE_CHANNEL, '.', 1) = 'Other' THEN 1
                    else 0
                END AS FLAG_ACTSUSPECT_INFL_TOUCHPOINT_BY_ACQTOPLEVELCHANNEL_OTHER,
                CASE
                    WHEN infl_data.MARKETING_TOUCHPOINT_DATE <= amlh_opp.AMLH_SUSPECT_DATE_STAMP__C
                    AND SPLIT_PART(infl_data.INFLUENCE_CHANNEL, '.', 1) = 'Paid Media' THEN 1
                    else 0
                END AS FLAG_ACTSUSPECT_INFL_TOUCHPOINT_BY_ACQTOPLEVELCHANNEL_PAIDMEDIA,
                CASE
                    WHEN infl_data.MARKETING_TOUCHPOINT_DATE <= amlh_opp.AMLH_SUSPECT_DATE_STAMP__C
                    AND SPLIT_PART(infl_data.INFLUENCE_CHANNEL, '.', 1) = 'Paid Search' THEN 1
                    else 0
                END AS FLAG_ACTSUSPECT_INFL_TOUCHPOINT_BY_ACQTOPLEVELCHANNEL_PAIDSEARCH,
                CASE
                    WHEN infl_data.MARKETING_TOUCHPOINT_DATE <= amlh_opp.AMLH_SUSPECT_DATE_STAMP__C
                    AND SPLIT_PART(infl_data.INFLUENCE_CHANNEL, '.', 1) = 'Paid Social' THEN 1
                    else 0
                END AS FLAG_ACTSUSPECT_INFL_TOUCHPOINT_BY_ACQTOPLEVELCHANNEL_PAIDSOCIAL,
                CASE
                    WHEN infl_data.MARKETING_TOUCHPOINT_DATE <= amlh_opp.AMLH_SUSPECT_DATE_STAMP__C
                    AND SPLIT_PART(infl_data.INFLUENCE_CHANNEL, '.', 1) = 'Podcast' THEN 1
                    else 0
                END AS FLAG_ACTSUSPECT_INFL_TOUCHPOINT_BY_ACQTOPLEVELCHANNEL_PODCAST,
                CASE
                    WHEN infl_data.MARKETING_TOUCHPOINT_DATE <= amlh_opp.AMLH_SUSPECT_DATE_STAMP__C
                    AND SPLIT_PART(infl_data.INFLUENCE_CHANNEL, '.', 1) = 'PPL' THEN 1
                    else 0
                END AS FLAG_ACTSUSPECT_INFL_TOUCHPOINT_BY_ACQTOPLEVELCHANNEL_PPL,
                CASE
                    WHEN infl_data.MARKETING_TOUCHPOINT_DATE <= amlh_opp.AMLH_SUSPECT_DATE_STAMP__C
                    AND SPLIT_PART(infl_data.INFLUENCE_CHANNEL, '.', 1) = 'Print' THEN 1
                    else 0
                END AS FLAG_ACTSUSPECT_INFL_TOUCHPOINT_BY_ACQTOPLEVELCHANNEL_PRINT,
                CASE
                    WHEN infl_data.MARKETING_TOUCHPOINT_DATE <= amlh_opp.AMLH_SUSPECT_DATE_STAMP__C
                    AND SPLIT_PART(infl_data.INFLUENCE_CHANNEL, '.', 1) = 'Sponsored Email' THEN 1
                    else 0
                END AS FLAG_ACTSUSPECT_INFL_TOUCHPOINT_BY_ACQTOPLEVELCHANNEL_SPONSOREDEMAIL,
                CASE
                    WHEN infl_data.MARKETING_TOUCHPOINT_DATE <= amlh_opp.AMLH_SUSPECT_DATE_STAMP__C
                    AND SPLIT_PART(infl_data.INFLUENCE_CHANNEL, '.', 1) = 'Tradeshow' THEN 1
                    else 0
                END AS FLAG_ACTSUSPECT_INFL_TOUCHPOINT_BY_ACQTOPLEVELCHANNEL_TRADESHOW,
                CASE
                    WHEN infl_data.MARKETING_TOUCHPOINT_DATE <= amlh_opp.AMLH_SUSPECT_DATE_STAMP__C
                    AND SPLIT_PART(infl_data.INFLUENCE_CHANNEL, '.', 1) = 'Web Referral' THEN 1
                    else 0
                END AS FLAG_ACTSUSPECT_INFL_TOUCHPOINT_BY_ACQTOPLEVELCHANNEL_WEBREFERRAL,
                CASE
                    WHEN infl_data.MARKETING_TOUCHPOINT_DATE <= amlh_opp.AMLH_SUSPECT_DATE_STAMP__C
                    AND SPLIT_PART(infl_data.INFLUENCE_CHANNEL, '.', 1) = 'Webinar' THEN 1
                    else 0
                END AS FLAG_ACTSUSPECT_INFL_TOUCHPOINT_BY_ACQTOPLEVELCHANNEL_WEBINAR,
				--20250314
                CASE
                    WHEN infl_data.MARKETING_TOUCHPOINT_DATE <= amlh_opp.AMLH_SUSPECT_DATE_STAMP__C
                    AND SPLIT_PART(infl_data.INFLUENCE_CHANNEL, '.', 1) = 'E-Gift' THEN 1
                    else 0
                END AS FLAG_ACTSUSPECT_INFL_TOUCHPOINT_BY_ACQTOPLEVELCHANNEL_EGIFT,
				
                -- Influence Before Act PROSPECT
                CASE
                    WHEN infl_data.MARKETING_TOUCHPOINT_DATE <= amlh_opp.AMLH_PROSPECT_DATE_STAMP__C
                    AND SPLIT_PART(infl_data.INFLUENCE_CHANNEL, '.', 1) = 'Channel Referral' THEN 1
                    else 0
                END AS FLAG_ACTPROSPECT_INFL_TOUCHPOINT_BY_ACQTOPLEVELCHANNEL_CHANNELREFERRAL,
                CASE
                    WHEN infl_data.MARKETING_TOUCHPOINT_DATE <= amlh_opp.AMLH_PROSPECT_DATE_STAMP__C
                    AND SPLIT_PART(infl_data.INFLUENCE_CHANNEL, '.', 1) = 'Content Syndication' THEN 1
                    else 0
                END AS FLAG_ACTPROSPECT_INFL_TOUCHPOINT_BY_ACQTOPLEVELCHANNEL_CONTENTSYNDICATION,
                CASE
                    WHEN infl_data.MARKETING_TOUCHPOINT_DATE <= amlh_opp.AMLH_PROSPECT_DATE_STAMP__C
                    AND SPLIT_PART(infl_data.INFLUENCE_CHANNEL, '.', 1) = 'Sales Engagement' THEN 1
                    else 0
                END AS FLAG_ACTPROSPECT_INFL_TOUCHPOINT_BY_ACQTOPLEVELCHANNEL_SALESENGAGEMENT,
                CASE
                    WHEN infl_data.MARKETING_TOUCHPOINT_DATE <= amlh_opp.AMLH_PROSPECT_DATE_STAMP__C
                    AND SPLIT_PART(infl_data.INFLUENCE_CHANNEL, '.', 1) = 'Direct' THEN 1
                    else 0
                END AS FLAG_ACTPROSPECT_INFL_TOUCHPOINT_BY_ACQTOPLEVELCHANNEL_DIRECT,
                CASE
                    WHEN infl_data.MARKETING_TOUCHPOINT_DATE <= amlh_opp.AMLH_PROSPECT_DATE_STAMP__C
                    AND SPLIT_PART(infl_data.INFLUENCE_CHANNEL, '.', 1) = 'Direct Mail' THEN 1
                    else 0
                END AS FLAG_ACTPROSPECT_INFL_TOUCHPOINT_BY_ACQTOPLEVELCHANNEL_DIRECTMAIL,
                CASE
                    WHEN infl_data.MARKETING_TOUCHPOINT_DATE <= amlh_opp.AMLH_PROSPECT_DATE_STAMP__C
                    AND SPLIT_PART(infl_data.INFLUENCE_CHANNEL, '.', 1) = 'Display' THEN 1
                    else 0
                END AS FLAG_ACTPROSPECT_INFL_TOUCHPOINT_BY_ACQTOPLEVELCHANNEL_DISPLAY,
                CASE
                    WHEN infl_data.MARKETING_TOUCHPOINT_DATE <= amlh_opp.AMLH_PROSPECT_DATE_STAMP__C
                    AND SPLIT_PART(infl_data.INFLUENCE_CHANNEL, '.', 1) = 'Email' THEN 1
                    else 0
                END AS FLAG_ACTPROSPECT_INFL_TOUCHPOINT_BY_ACQTOPLEVELCHANNEL_EMAIL,
                CASE
                    WHEN infl_data.MARKETING_TOUCHPOINT_DATE <= amlh_opp.AMLH_PROSPECT_DATE_STAMP__C
                    AND SPLIT_PART(infl_data.INFLUENCE_CHANNEL, '.', 1) = 'Lead Referral' THEN 1
                    else 0
                END AS FLAG_ACTPROSPECT_INFL_TOUCHPOINT_BY_ACQTOPLEVELCHANNEL_LEADREFERRAL,
                CASE
                    WHEN infl_data.MARKETING_TOUCHPOINT_DATE <= amlh_opp.AMLH_PROSPECT_DATE_STAMP__C
                    AND SPLIT_PART(infl_data.INFLUENCE_CHANNEL, '.', 1) = 'Live Event' THEN 1
                    else 0
                END AS FLAG_ACTPROSPECT_INFL_TOUCHPOINT_BY_ACQTOPLEVELCHANNEL_LIVEEVENT,
                CASE
                    WHEN infl_data.MARKETING_TOUCHPOINT_DATE <= amlh_opp.AMLH_PROSPECT_DATE_STAMP__C
                    AND SPLIT_PART(infl_data.INFLUENCE_CHANNEL, '.', 1) = 'Lytx' THEN 1
                    else 0
                END AS FLAG_ACTPROSPECT_INFL_TOUCHPOINT_BY_ACQTOPLEVELCHANNEL_LYTX,
                CASE
                    WHEN infl_data.MARKETING_TOUCHPOINT_DATE <= amlh_opp.AMLH_PROSPECT_DATE_STAMP__C
                    AND SPLIT_PART(infl_data.INFLUENCE_CHANNEL, '.', 1) = 'Native' THEN 1
                    else 0
                END AS FLAG_ACTPROSPECT_INFL_TOUCHPOINT_BY_ACQTOPLEVELCHANNEL_NATIVE,
                CASE
                    WHEN infl_data.MARKETING_TOUCHPOINT_DATE <= amlh_opp.AMLH_PROSPECT_DATE_STAMP__C
                    AND SPLIT_PART(infl_data.INFLUENCE_CHANNEL, '.', 1) = 'Organic Search' THEN 1
                    else 0
                END AS FLAG_ACTPROSPECT_INFL_TOUCHPOINT_BY_ACQTOPLEVELCHANNEL_ORGANICSEARCH,
                CASE
                    WHEN infl_data.MARKETING_TOUCHPOINT_DATE <= amlh_opp.AMLH_PROSPECT_DATE_STAMP__C
                    AND SPLIT_PART(infl_data.INFLUENCE_CHANNEL, '.', 1) = 'Organic Social' THEN 1
                    else 0
                END AS FLAG_ACTPROSPECT_INFL_TOUCHPOINT_BY_ACQTOPLEVELCHANNEL_ORGANICSOCIAL,
                CASE
                    WHEN infl_data.MARKETING_TOUCHPOINT_DATE <= amlh_opp.AMLH_PROSPECT_DATE_STAMP__C
                    AND SPLIT_PART(infl_data.INFLUENCE_CHANNEL, '.', 1) = 'Other' THEN 1
                    else 0
                END AS FLAG_ACTPROSPECT_INFL_TOUCHPOINT_BY_ACQTOPLEVELCHANNEL_OTHER,
                CASE
                    WHEN infl_data.MARKETING_TOUCHPOINT_DATE <= amlh_opp.AMLH_PROSPECT_DATE_STAMP__C
                    AND SPLIT_PART(infl_data.INFLUENCE_CHANNEL, '.', 1) = 'Paid Media' THEN 1
                    else 0
                END AS FLAG_ACTPROSPECT_INFL_TOUCHPOINT_BY_ACQTOPLEVELCHANNEL_PAIDMEDIA,
                CASE
                    WHEN infl_data.MARKETING_TOUCHPOINT_DATE <= amlh_opp.AMLH_PROSPECT_DATE_STAMP__C
                    AND SPLIT_PART(infl_data.INFLUENCE_CHANNEL, '.', 1) = 'Paid Search' THEN 1
                    else 0
                END AS FLAG_ACTPROSPECT_INFL_TOUCHPOINT_BY_ACQTOPLEVELCHANNEL_PAIDSEARCH,
                CASE
                    WHEN infl_data.MARKETING_TOUCHPOINT_DATE <= amlh_opp.AMLH_PROSPECT_DATE_STAMP__C
                    AND SPLIT_PART(infl_data.INFLUENCE_CHANNEL, '.', 1) = 'Paid Social' THEN 1
                    else 0
                END AS FLAG_ACTPROSPECT_INFL_TOUCHPOINT_BY_ACQTOPLEVELCHANNEL_PAIDSOCIAL,
                CASE
                    WHEN infl_data.MARKETING_TOUCHPOINT_DATE <= amlh_opp.AMLH_PROSPECT_DATE_STAMP__C
                    AND SPLIT_PART(infl_data.INFLUENCE_CHANNEL, '.', 1) = 'Podcast' THEN 1
                    else 0
                END AS FLAG_ACTPROSPECT_INFL_TOUCHPOINT_BY_ACQTOPLEVELCHANNEL_PODCAST,
                CASE
                    WHEN infl_data.MARKETING_TOUCHPOINT_DATE <= amlh_opp.AMLH_PROSPECT_DATE_STAMP__C
                    AND SPLIT_PART(infl_data.INFLUENCE_CHANNEL, '.', 1) = 'PPL' THEN 1
                    else 0
                END AS FLAG_ACTPROSPECT_INFL_TOUCHPOINT_BY_ACQTOPLEVELCHANNEL_PPL,
                CASE
                    WHEN infl_data.MARKETING_TOUCHPOINT_DATE <= amlh_opp.AMLH_PROSPECT_DATE_STAMP__C
                    AND SPLIT_PART(infl_data.INFLUENCE_CHANNEL, '.', 1) = 'Print' THEN 1
                    else 0
                END AS FLAG_ACTPROSPECT_INFL_TOUCHPOINT_BY_ACQTOPLEVELCHANNEL_PRINT,
                CASE
                    WHEN infl_data.MARKETING_TOUCHPOINT_DATE <= amlh_opp.AMLH_PROSPECT_DATE_STAMP__C
                    AND SPLIT_PART(infl_data.INFLUENCE_CHANNEL, '.', 1) = 'Sponsored Email' THEN 1
                    else 0
                END AS FLAG_ACTPROSPECT_INFL_TOUCHPOINT_BY_ACQTOPLEVELCHANNEL_SPONSOREDEMAIL,
                CASE
                    WHEN infl_data.MARKETING_TOUCHPOINT_DATE <= amlh_opp.AMLH_PROSPECT_DATE_STAMP__C
                    AND SPLIT_PART(infl_data.INFLUENCE_CHANNEL, '.', 1) = 'Tradeshow' THEN 1
                    else 0
                END AS FLAG_ACTPROSPECT_INFL_TOUCHPOINT_BY_ACQTOPLEVELCHANNEL_TRADESHOW,
                CASE
                    WHEN infl_data.MARKETING_TOUCHPOINT_DATE <= amlh_opp.AMLH_PROSPECT_DATE_STAMP__C
                    AND SPLIT_PART(infl_data.INFLUENCE_CHANNEL, '.', 1) = 'Web Referral' THEN 1
                    else 0
                END AS FLAG_ACTPROSPECT_INFL_TOUCHPOINT_BY_ACQTOPLEVELCHANNEL_WEBREFERRAL,
                CASE
                    WHEN infl_data.MARKETING_TOUCHPOINT_DATE <= amlh_opp.AMLH_PROSPECT_DATE_STAMP__C
                    AND SPLIT_PART(infl_data.INFLUENCE_CHANNEL, '.', 1) = 'Webinar' THEN 1
                    else 0
                END AS FLAG_ACTPROSPECT_INFL_TOUCHPOINT_BY_ACQTOPLEVELCHANNEL_WEBINAR,
				--20250314
                CASE
                    WHEN infl_data.MARKETING_TOUCHPOINT_DATE <= amlh_opp.AMLH_PROSPECT_DATE_STAMP__C
                    AND SPLIT_PART(infl_data.INFLUENCE_CHANNEL, '.', 1) = 'E-Gift' THEN 1
                    else 0
                END AS FLAG_ACTPROSPECT_INFL_TOUCHPOINT_BY_ACQTOPLEVELCHANNEL_EGIFT,

				--20250314
                -- Influence Before Act CUSTOMER
                CASE
                    WHEN infl_data.MARKETING_TOUCHPOINT_DATE <= amlh_opp.AMLH_CUSTOMER_DATE_STAMP__C
                    AND SPLIT_PART(infl_data.INFLUENCE_CHANNEL, '.', 1) = 'Channel Referral' THEN 1
                    else 0
                END AS FLAG_ACTCUSTOMER_INFL_TOUCHPOINT_BY_ACQTOPLEVELCHANNEL_CHANNELREFERRAL,
                CASE
                    WHEN infl_data.MARKETING_TOUCHPOINT_DATE <= amlh_opp.AMLH_CUSTOMER_DATE_STAMP__C
                    AND SPLIT_PART(infl_data.INFLUENCE_CHANNEL, '.', 1) = 'Content Syndication' THEN 1
                    else 0
                END AS FLAG_ACTCUSTOMER_INFL_TOUCHPOINT_BY_ACQTOPLEVELCHANNEL_CONTENTSYNDICATION,
                CASE
                    WHEN infl_data.MARKETING_TOUCHPOINT_DATE <= amlh_opp.AMLH_CUSTOMER_DATE_STAMP__C
                    AND SPLIT_PART(infl_data.INFLUENCE_CHANNEL, '.', 1) = 'Sales Engagement' THEN 1
                    else 0
                END AS FLAG_ACTCUSTOMER_INFL_TOUCHPOINT_BY_ACQTOPLEVELCHANNEL_SALESENGAGEMENT,
                CASE
                    WHEN infl_data.MARKETING_TOUCHPOINT_DATE <= amlh_opp.AMLH_CUSTOMER_DATE_STAMP__C
                    AND SPLIT_PART(infl_data.INFLUENCE_CHANNEL, '.', 1) = 'Direct' THEN 1
                    else 0
                END AS FLAG_ACTCUSTOMER_INFL_TOUCHPOINT_BY_ACQTOPLEVELCHANNEL_DIRECT,
                CASE
                    WHEN infl_data.MARKETING_TOUCHPOINT_DATE <= amlh_opp.AMLH_CUSTOMER_DATE_STAMP__C
                    AND SPLIT_PART(infl_data.INFLUENCE_CHANNEL, '.', 1) = 'Direct Mail' THEN 1
                    else 0
                END AS FLAG_ACTCUSTOMER_INFL_TOUCHPOINT_BY_ACQTOPLEVELCHANNEL_DIRECTMAIL,
                CASE
                    WHEN infl_data.MARKETING_TOUCHPOINT_DATE <= amlh_opp.AMLH_CUSTOMER_DATE_STAMP__C
                    AND SPLIT_PART(infl_data.INFLUENCE_CHANNEL, '.', 1) = 'Display' THEN 1
                    else 0
                END AS FLAG_ACTCUSTOMER_INFL_TOUCHPOINT_BY_ACQTOPLEVELCHANNEL_DISPLAY,
                CASE
                    WHEN infl_data.MARKETING_TOUCHPOINT_DATE <= amlh_opp.AMLH_CUSTOMER_DATE_STAMP__C
                    AND SPLIT_PART(infl_data.INFLUENCE_CHANNEL, '.', 1) = 'Email' THEN 1
                    else 0
                END AS FLAG_ACTCUSTOMER_INFL_TOUCHPOINT_BY_ACQTOPLEVELCHANNEL_EMAIL,
                CASE
                    WHEN infl_data.MARKETING_TOUCHPOINT_DATE <= amlh_opp.AMLH_CUSTOMER_DATE_STAMP__C
                    AND SPLIT_PART(infl_data.INFLUENCE_CHANNEL, '.', 1) = 'Lead Referral' THEN 1
                    else 0
                END AS FLAG_ACTCUSTOMER_INFL_TOUCHPOINT_BY_ACQTOPLEVELCHANNEL_LEADREFERRAL,
                CASE
                    WHEN infl_data.MARKETING_TOUCHPOINT_DATE <= amlh_opp.AMLH_CUSTOMER_DATE_STAMP__C
                    AND SPLIT_PART(infl_data.INFLUENCE_CHANNEL, '.', 1) = 'Live Event' THEN 1
                    else 0
                END AS FLAG_ACTCUSTOMER_INFL_TOUCHPOINT_BY_ACQTOPLEVELCHANNEL_LIVEEVENT,
                CASE
                    WHEN infl_data.MARKETING_TOUCHPOINT_DATE <= amlh_opp.AMLH_CUSTOMER_DATE_STAMP__C
                    AND SPLIT_PART(infl_data.INFLUENCE_CHANNEL, '.', 1) = 'Lytx' THEN 1
                    else 0
                END AS FLAG_ACTCUSTOMER_INFL_TOUCHPOINT_BY_ACQTOPLEVELCHANNEL_LYTX,
                CASE
                    WHEN infl_data.MARKETING_TOUCHPOINT_DATE <= amlh_opp.AMLH_CUSTOMER_DATE_STAMP__C
                    AND SPLIT_PART(infl_data.INFLUENCE_CHANNEL, '.', 1) = 'Native' THEN 1
                    else 0
                END AS FLAG_ACTCUSTOMER_INFL_TOUCHPOINT_BY_ACQTOPLEVELCHANNEL_NATIVE,
                CASE
                    WHEN infl_data.MARKETING_TOUCHPOINT_DATE <= amlh_opp.AMLH_CUSTOMER_DATE_STAMP__C
                    AND SPLIT_PART(infl_data.INFLUENCE_CHANNEL, '.', 1) = 'Organic Search' THEN 1
                    else 0
                END AS FLAG_ACTCUSTOMER_INFL_TOUCHPOINT_BY_ACQTOPLEVELCHANNEL_ORGANICSEARCH,
                CASE
                    WHEN infl_data.MARKETING_TOUCHPOINT_DATE <= amlh_opp.AMLH_CUSTOMER_DATE_STAMP__C
                    AND SPLIT_PART(infl_data.INFLUENCE_CHANNEL, '.', 1) = 'Organic Social' THEN 1
                    else 0
                END AS FLAG_ACTCUSTOMER_INFL_TOUCHPOINT_BY_ACQTOPLEVELCHANNEL_ORGANICSOCIAL,
                CASE
                    WHEN infl_data.MARKETING_TOUCHPOINT_DATE <= amlh_opp.AMLH_CUSTOMER_DATE_STAMP__C
                    AND SPLIT_PART(infl_data.INFLUENCE_CHANNEL, '.', 1) = 'Other' THEN 1
                    else 0
                END AS FLAG_ACTCUSTOMER_INFL_TOUCHPOINT_BY_ACQTOPLEVELCHANNEL_OTHER,
                CASE
                    WHEN infl_data.MARKETING_TOUCHPOINT_DATE <= amlh_opp.AMLH_CUSTOMER_DATE_STAMP__C
                    AND SPLIT_PART(infl_data.INFLUENCE_CHANNEL, '.', 1) = 'Paid Media' THEN 1
                    else 0
                END AS FLAG_ACTCUSTOMER_INFL_TOUCHPOINT_BY_ACQTOPLEVELCHANNEL_PAIDMEDIA,
                CASE
                    WHEN infl_data.MARKETING_TOUCHPOINT_DATE <= amlh_opp.AMLH_CUSTOMER_DATE_STAMP__C
                    AND SPLIT_PART(infl_data.INFLUENCE_CHANNEL, '.', 1) = 'Paid Search' THEN 1
                    else 0
                END AS FLAG_ACTCUSTOMER_INFL_TOUCHPOINT_BY_ACQTOPLEVELCHANNEL_PAIDSEARCH,
                CASE
                    WHEN infl_data.MARKETING_TOUCHPOINT_DATE <= amlh_opp.AMLH_CUSTOMER_DATE_STAMP__C
                    AND SPLIT_PART(infl_data.INFLUENCE_CHANNEL, '.', 1) = 'Paid Social' THEN 1
                    else 0
                END AS FLAG_ACTCUSTOMER_INFL_TOUCHPOINT_BY_ACQTOPLEVELCHANNEL_PAIDSOCIAL,
                CASE
                    WHEN infl_data.MARKETING_TOUCHPOINT_DATE <= amlh_opp.AMLH_CUSTOMER_DATE_STAMP__C
                    AND SPLIT_PART(infl_data.INFLUENCE_CHANNEL, '.', 1) = 'Podcast' THEN 1
                    else 0
                END AS FLAG_ACTCUSTOMER_INFL_TOUCHPOINT_BY_ACQTOPLEVELCHANNEL_PODCAST,
                CASE
                    WHEN infl_data.MARKETING_TOUCHPOINT_DATE <= amlh_opp.AMLH_CUSTOMER_DATE_STAMP__C
                    AND SPLIT_PART(infl_data.INFLUENCE_CHANNEL, '.', 1) = 'PPL' THEN 1
                    else 0
                END AS FLAG_ACTCUSTOMER_INFL_TOUCHPOINT_BY_ACQTOPLEVELCHANNEL_PPL,
                CASE
                    WHEN infl_data.MARKETING_TOUCHPOINT_DATE <= amlh_opp.AMLH_CUSTOMER_DATE_STAMP__C
                    AND SPLIT_PART(infl_data.INFLUENCE_CHANNEL, '.', 1) = 'Print' THEN 1
                    else 0
                END AS FLAG_ACTCUSTOMER_INFL_TOUCHPOINT_BY_ACQTOPLEVELCHANNEL_PRINT,
                CASE
                    WHEN infl_data.MARKETING_TOUCHPOINT_DATE <= amlh_opp.AMLH_CUSTOMER_DATE_STAMP__C
                    AND SPLIT_PART(infl_data.INFLUENCE_CHANNEL, '.', 1) = 'Sponsored Email' THEN 1
                    else 0
                END AS FLAG_ACTCUSTOMER_INFL_TOUCHPOINT_BY_ACQTOPLEVELCHANNEL_SPONSOREDEMAIL,
                CASE
                    WHEN infl_data.MARKETING_TOUCHPOINT_DATE <= amlh_opp.AMLH_CUSTOMER_DATE_STAMP__C
                    AND SPLIT_PART(infl_data.INFLUENCE_CHANNEL, '.', 1) = 'Tradeshow' THEN 1
                    else 0
                END AS FLAG_ACTCUSTOMER_INFL_TOUCHPOINT_BY_ACQTOPLEVELCHANNEL_TRADESHOW,
                CASE
                    WHEN infl_data.MARKETING_TOUCHPOINT_DATE <= amlh_opp.AMLH_CUSTOMER_DATE_STAMP__C
                    AND SPLIT_PART(infl_data.INFLUENCE_CHANNEL, '.', 1) = 'Web Referral' THEN 1
                    else 0
                END AS FLAG_ACTCUSTOMER_INFL_TOUCHPOINT_BY_ACQTOPLEVELCHANNEL_WEBREFERRAL,
                CASE
                    WHEN infl_data.MARKETING_TOUCHPOINT_DATE <= amlh_opp.AMLH_CUSTOMER_DATE_STAMP__C
                    AND SPLIT_PART(infl_data.INFLUENCE_CHANNEL, '.', 1) = 'Webinar' THEN 1
                    else 0
                END AS FLAG_ACTCUSTOMER_INFL_TOUCHPOINT_BY_ACQTOPLEVELCHANNEL_WEBINAR,
                CASE
                    WHEN infl_data.MARKETING_TOUCHPOINT_DATE <= amlh_opp.AMLH_CUSTOMER_DATE_STAMP__C
                    AND SPLIT_PART(infl_data.INFLUENCE_CHANNEL, '.', 1) = 'E-Gift' THEN 1
                    else 0
                END AS FLAG_ACTCUSTOMER_INFL_TOUCHPOINT_BY_ACQTOPLEVELCHANNEL_EGIFT,
				
				--20250314
				-- Influence Before Act EFFECTIVE
                CASE
                    WHEN infl_data.MARKETING_TOUCHPOINT_DATE <= amlh_opp.AMLH_EFFECTIVE_DATE_STAMP__C
                    AND SPLIT_PART(infl_data.INFLUENCE_CHANNEL, '.', 1) = 'Channel Referral' THEN 1
                    else 0
                END AS FLAG_ACTEFFECTIVE_INFL_TOUCHPOINT_BY_ACQTOPLEVELCHANNEL_CHANNELREFERRAL,
                CASE
                    WHEN infl_data.MARKETING_TOUCHPOINT_DATE <= amlh_opp.AMLH_EFFECTIVE_DATE_STAMP__C
                    AND SPLIT_PART(infl_data.INFLUENCE_CHANNEL, '.', 1) = 'Content Syndication' THEN 1
                    else 0
                END AS FLAG_ACTEFFECTIVE_INFL_TOUCHPOINT_BY_ACQTOPLEVELCHANNEL_CONTENTSYNDICATION,
                CASE
                    WHEN infl_data.MARKETING_TOUCHPOINT_DATE <= amlh_opp.AMLH_EFFECTIVE_DATE_STAMP__C
                    AND SPLIT_PART(infl_data.INFLUENCE_CHANNEL, '.', 1) = 'Sales Engagement' THEN 1
                    else 0
                END AS FLAG_ACTEFFECTIVE_INFL_TOUCHPOINT_BY_ACQTOPLEVELCHANNEL_SALESENGAGEMENT,
                CASE
                    WHEN infl_data.MARKETING_TOUCHPOINT_DATE <= amlh_opp.AMLH_EFFECTIVE_DATE_STAMP__C
                    AND SPLIT_PART(infl_data.INFLUENCE_CHANNEL, '.', 1) = 'Direct' THEN 1
                    else 0
                END AS FLAG_ACTEFFECTIVE_INFL_TOUCHPOINT_BY_ACQTOPLEVELCHANNEL_DIRECT,
                CASE
                    WHEN infl_data.MARKETING_TOUCHPOINT_DATE <= amlh_opp.AMLH_EFFECTIVE_DATE_STAMP__C
                    AND SPLIT_PART(infl_data.INFLUENCE_CHANNEL, '.', 1) = 'Direct Mail' THEN 1
                    else 0
                END AS FLAG_ACTEFFECTIVE_INFL_TOUCHPOINT_BY_ACQTOPLEVELCHANNEL_DIRECTMAIL,
                CASE
                    WHEN infl_data.MARKETING_TOUCHPOINT_DATE <= amlh_opp.AMLH_EFFECTIVE_DATE_STAMP__C
                    AND SPLIT_PART(infl_data.INFLUENCE_CHANNEL, '.', 1) = 'Display' THEN 1
                    else 0
                END AS FLAG_ACTEFFECTIVE_INFL_TOUCHPOINT_BY_ACQTOPLEVELCHANNEL_DISPLAY,
                CASE
                    WHEN infl_data.MARKETING_TOUCHPOINT_DATE <= amlh_opp.AMLH_EFFECTIVE_DATE_STAMP__C
                    AND SPLIT_PART(infl_data.INFLUENCE_CHANNEL, '.', 1) = 'Email' THEN 1
                    else 0
                END AS FLAG_ACTEFFECTIVE_INFL_TOUCHPOINT_BY_ACQTOPLEVELCHANNEL_EMAIL,
                CASE
                    WHEN infl_data.MARKETING_TOUCHPOINT_DATE <= amlh_opp.AMLH_EFFECTIVE_DATE_STAMP__C
                    AND SPLIT_PART(infl_data.INFLUENCE_CHANNEL, '.', 1) = 'Lead Referral' THEN 1
                    else 0
                END AS FLAG_ACTEFFECTIVE_INFL_TOUCHPOINT_BY_ACQTOPLEVELCHANNEL_LEADREFERRAL,
                CASE
                    WHEN infl_data.MARKETING_TOUCHPOINT_DATE <= amlh_opp.AMLH_EFFECTIVE_DATE_STAMP__C
                    AND SPLIT_PART(infl_data.INFLUENCE_CHANNEL, '.', 1) = 'Live Event' THEN 1
                    else 0
                END AS FLAG_ACTEFFECTIVE_INFL_TOUCHPOINT_BY_ACQTOPLEVELCHANNEL_LIVEEVENT,
                CASE
                    WHEN infl_data.MARKETING_TOUCHPOINT_DATE <= amlh_opp.AMLH_EFFECTIVE_DATE_STAMP__C
                    AND SPLIT_PART(infl_data.INFLUENCE_CHANNEL, '.', 1) = 'Lytx' THEN 1
                    else 0
                END AS FLAG_ACTEFFECTIVE_INFL_TOUCHPOINT_BY_ACQTOPLEVELCHANNEL_LYTX,
                CASE
                    WHEN infl_data.MARKETING_TOUCHPOINT_DATE <= amlh_opp.AMLH_EFFECTIVE_DATE_STAMP__C
                    AND SPLIT_PART(infl_data.INFLUENCE_CHANNEL, '.', 1) = 'Native' THEN 1
                    else 0
                END AS FLAG_ACTEFFECTIVE_INFL_TOUCHPOINT_BY_ACQTOPLEVELCHANNEL_NATIVE,
                CASE
                    WHEN infl_data.MARKETING_TOUCHPOINT_DATE <= amlh_opp.AMLH_EFFECTIVE_DATE_STAMP__C
                    AND SPLIT_PART(infl_data.INFLUENCE_CHANNEL, '.', 1) = 'Organic Search' THEN 1
                    else 0
                END AS FLAG_ACTEFFECTIVE_INFL_TOUCHPOINT_BY_ACQTOPLEVELCHANNEL_ORGANICSEARCH,
                CASE
                    WHEN infl_data.MARKETING_TOUCHPOINT_DATE <= amlh_opp.AMLH_EFFECTIVE_DATE_STAMP__C
                    AND SPLIT_PART(infl_data.INFLUENCE_CHANNEL, '.', 1) = 'Organic Social' THEN 1
                    else 0
                END AS FLAG_ACTEFFECTIVE_INFL_TOUCHPOINT_BY_ACQTOPLEVELCHANNEL_ORGANICSOCIAL,
                CASE
                    WHEN infl_data.MARKETING_TOUCHPOINT_DATE <= amlh_opp.AMLH_EFFECTIVE_DATE_STAMP__C
                    AND SPLIT_PART(infl_data.INFLUENCE_CHANNEL, '.', 1) = 'Other' THEN 1
                    else 0
                END AS FLAG_ACTEFFECTIVE_INFL_TOUCHPOINT_BY_ACQTOPLEVELCHANNEL_OTHER,
                CASE
                    WHEN infl_data.MARKETING_TOUCHPOINT_DATE <= amlh_opp.AMLH_EFFECTIVE_DATE_STAMP__C
                    AND SPLIT_PART(infl_data.INFLUENCE_CHANNEL, '.', 1) = 'Paid Media' THEN 1
                    else 0
                END AS FLAG_ACTEFFECTIVE_INFL_TOUCHPOINT_BY_ACQTOPLEVELCHANNEL_PAIDMEDIA,
                CASE
                    WHEN infl_data.MARKETING_TOUCHPOINT_DATE <= amlh_opp.AMLH_EFFECTIVE_DATE_STAMP__C
                    AND SPLIT_PART(infl_data.INFLUENCE_CHANNEL, '.', 1) = 'Paid Search' THEN 1
                    else 0
                END AS FLAG_ACTEFFECTIVE_INFL_TOUCHPOINT_BY_ACQTOPLEVELCHANNEL_PAIDSEARCH,
                CASE
                    WHEN infl_data.MARKETING_TOUCHPOINT_DATE <= amlh_opp.AMLH_EFFECTIVE_DATE_STAMP__C
                    AND SPLIT_PART(infl_data.INFLUENCE_CHANNEL, '.', 1) = 'Paid Social' THEN 1
                    else 0
                END AS FLAG_ACTEFFECTIVE_INFL_TOUCHPOINT_BY_ACQTOPLEVELCHANNEL_PAIDSOCIAL,
                CASE
                    WHEN infl_data.MARKETING_TOUCHPOINT_DATE <= amlh_opp.AMLH_EFFECTIVE_DATE_STAMP__C
                    AND SPLIT_PART(infl_data.INFLUENCE_CHANNEL, '.', 1) = 'Podcast' THEN 1
                    else 0
                END AS FLAG_ACTEFFECTIVE_INFL_TOUCHPOINT_BY_ACQTOPLEVELCHANNEL_PODCAST,
                CASE
                    WHEN infl_data.MARKETING_TOUCHPOINT_DATE <= amlh_opp.AMLH_EFFECTIVE_DATE_STAMP__C
                    AND SPLIT_PART(infl_data.INFLUENCE_CHANNEL, '.', 1) = 'PPL' THEN 1
                    else 0
                END AS FLAG_ACTEFFECTIVE_INFL_TOUCHPOINT_BY_ACQTOPLEVELCHANNEL_PPL,
                CASE
                    WHEN infl_data.MARKETING_TOUCHPOINT_DATE <= amlh_opp.AMLH_EFFECTIVE_DATE_STAMP__C
                    AND SPLIT_PART(infl_data.INFLUENCE_CHANNEL, '.', 1) = 'Print' THEN 1
                    else 0
                END AS FLAG_ACTEFFECTIVE_INFL_TOUCHPOINT_BY_ACQTOPLEVELCHANNEL_PRINT,
                CASE
                    WHEN infl_data.MARKETING_TOUCHPOINT_DATE <= amlh_opp.AMLH_EFFECTIVE_DATE_STAMP__C
                    AND SPLIT_PART(infl_data.INFLUENCE_CHANNEL, '.', 1) = 'Sponsored Email' THEN 1
                    else 0
                END AS FLAG_ACTEFFECTIVE_INFL_TOUCHPOINT_BY_ACQTOPLEVELCHANNEL_SPONSOREDEMAIL,
                CASE
                    WHEN infl_data.MARKETING_TOUCHPOINT_DATE <= amlh_opp.AMLH_EFFECTIVE_DATE_STAMP__C
                    AND SPLIT_PART(infl_data.INFLUENCE_CHANNEL, '.', 1) = 'Tradeshow' THEN 1
                    else 0
                END AS FLAG_ACTEFFECTIVE_INFL_TOUCHPOINT_BY_ACQTOPLEVELCHANNEL_TRADESHOW,
                CASE
                    WHEN infl_data.MARKETING_TOUCHPOINT_DATE <= amlh_opp.AMLH_EFFECTIVE_DATE_STAMP__C
                    AND SPLIT_PART(infl_data.INFLUENCE_CHANNEL, '.', 1) = 'Web Referral' THEN 1
                    else 0
                END AS FLAG_ACTEFFECTIVE_INFL_TOUCHPOINT_BY_ACQTOPLEVELCHANNEL_WEBREFERRAL,
                CASE
                    WHEN infl_data.MARKETING_TOUCHPOINT_DATE <= amlh_opp.AMLH_EFFECTIVE_DATE_STAMP__C
                    AND SPLIT_PART(infl_data.INFLUENCE_CHANNEL, '.', 1) = 'Webinar' THEN 1
                    else 0
                END AS FLAG_ACTEFFECTIVE_INFL_TOUCHPOINT_BY_ACQTOPLEVELCHANNEL_WEBINAR,
                CASE
                    WHEN infl_data.MARKETING_TOUCHPOINT_DATE <= amlh_opp.AMLH_EFFECTIVE_DATE_STAMP__C
                    AND SPLIT_PART(infl_data.INFLUENCE_CHANNEL, '.', 1) = 'E-Gift' THEN 1
                    else 0
                END AS FLAG_ACTEFFECTIVE_INFL_TOUCHPOINT_BY_ACQTOPLEVELCHANNEL_EGIFT,
				
                CASE
                    WHEN SPLIT_PART(infl_data.INFLUENCE_CHANNEL, '.', 1) = 'Channel Referral' THEN 1
                    else 0
                END AS FLAG_HAS_TOUCHPOINT_BY_ACQTOPLEVELCHANNEL_CHANNELREFERRAL,
                CASE
                    WHEN SPLIT_PART(infl_data.INFLUENCE_CHANNEL, '.', 1) = 'Content Syndication' THEN 1
                    else 0
                END AS FLAG_HAS_TOUCHPOINT_BY_ACQTOPLEVELCHANNEL_CONTENTSYNDICATION,
                CASE
                    WHEN SPLIT_PART(infl_data.INFLUENCE_CHANNEL, '.', 1) = 'Sales Engagement' THEN 1
                    else 0
                END AS FLAG_HAS_TOUCHPOINT_BY_ACQTOPLEVELCHANNEL_SALESENGAGEMENT,
                CASE
                    WHEN SPLIT_PART(infl_data.INFLUENCE_CHANNEL, '.', 1) = 'Direct' THEN 1
                    else 0
                END AS FLAG_HAS_TOUCHPOINT_BY_ACQTOPLEVELCHANNEL_DIRECT,
                CASE
                    WHEN SPLIT_PART(infl_data.INFLUENCE_CHANNEL, '.', 1) = 'Direct Mail' THEN 1
                    else 0
                END AS FLAG_HAS_TOUCHPOINT_BY_ACQTOPLEVELCHANNEL_DIRECTMAIL,
                CASE
                    WHEN SPLIT_PART(infl_data.INFLUENCE_CHANNEL, '.', 1) = 'Display' THEN 1
                    else 0
                END AS FLAG_HAS_TOUCHPOINT_BY_ACQTOPLEVELCHANNEL_DISPLAY,
                CASE
                    WHEN SPLIT_PART(infl_data.INFLUENCE_CHANNEL, '.', 1) = 'Email' THEN 1
                    else 0
                END AS FLAG_HAS_TOUCHPOINT_BY_ACQTOPLEVELCHANNEL_EMAIL,
                CASE
                    WHEN SPLIT_PART(infl_data.INFLUENCE_CHANNEL, '.', 1) = 'Lead Referral' THEN 1
                    else 0
                END AS FLAG_HAS_TOUCHPOINT_BY_ACQTOPLEVELCHANNEL_LEADREFERRAL,
                CASE
                    WHEN SPLIT_PART(infl_data.INFLUENCE_CHANNEL, '.', 1) = 'Live Event' THEN 1
                    else 0
                END AS FLAG_HAS_TOUCHPOINT_BY_ACQTOPLEVELCHANNEL_LIVEEVENT,
                CASE
                    WHEN SPLIT_PART(infl_data.INFLUENCE_CHANNEL, '.', 1) = 'Lytx' THEN 1
                    else 0
                END AS FLAG_HAS_TOUCHPOINT_BY_ACQTOPLEVELCHANNEL_LYTX,
                CASE
                    WHEN SPLIT_PART(infl_data.INFLUENCE_CHANNEL, '.', 1) = 'Native' THEN 1
                    else 0
                END AS FLAG_HAS_TOUCHPOINT_BY_ACQTOPLEVELCHANNEL_NATIVE,
                CASE
                    WHEN SPLIT_PART(infl_data.INFLUENCE_CHANNEL, '.', 1) = 'Organic Search' THEN 1
                    else 0
                END AS FLAG_HAS_TOUCHPOINT_BY_ACQTOPLEVELCHANNEL_ORGANICSEARCH,
                CASE
                    WHEN SPLIT_PART(infl_data.INFLUENCE_CHANNEL, '.', 1) = 'Organic Social' THEN 1
                    else 0
                END AS FLAG_HAS_TOUCHPOINT_BY_ACQTOPLEVELCHANNEL_ORGANICSOCIAL,
                CASE
                    WHEN SPLIT_PART(infl_data.INFLUENCE_CHANNEL, '.', 1) = 'Other' THEN 1
                    else 0
                END AS FLAG_HAS_TOUCHPOINT_BY_ACQTOPLEVELCHANNEL_OTHER,
                CASE
                    WHEN SPLIT_PART(infl_data.INFLUENCE_CHANNEL, '.', 1) = 'Paid Media' THEN 1
                    else 0
                END AS FLAG_HAS_TOUCHPOINT_BY_ACQTOPLEVELCHANNEL_PAIDMEDIA,
                CASE
                    WHEN SPLIT_PART(infl_data.INFLUENCE_CHANNEL, '.', 1) = 'Paid Search' THEN 1
                    else 0
                END AS FLAG_HAS_TOUCHPOINT_BY_ACQTOPLEVELCHANNEL_PAIDSEARCH,
                CASE
                    WHEN SPLIT_PART(infl_data.INFLUENCE_CHANNEL, '.', 1) = 'Paid Social' THEN 1
                    else 0
                END AS FLAG_HAS_TOUCHPOINT_BY_ACQTOPLEVELCHANNEL_PAIDSOCIAL,
                CASE
                    WHEN SPLIT_PART(infl_data.INFLUENCE_CHANNEL, '.', 1) = 'Podcast' THEN 1
                    else 0
                END AS FLAG_HAS_TOUCHPOINT_BY_ACQTOPLEVELCHANNEL_PODCAST,
                CASE
                    WHEN SPLIT_PART(infl_data.INFLUENCE_CHANNEL, '.', 1) = 'PPL' THEN 1
                    else 0
                END AS FLAG_HAS_TOUCHPOINT_BY_ACQTOPLEVELCHANNEL_PPL,
                CASE
                    WHEN SPLIT_PART(infl_data.INFLUENCE_CHANNEL, '.', 1) = 'Print' THEN 1
                    else 0
                END AS FLAG_HAS_TOUCHPOINT_BY_ACQTOPLEVELCHANNEL_PRINT,
                CASE
                    WHEN SPLIT_PART(infl_data.INFLUENCE_CHANNEL, '.', 1) = 'Sponsored Email' THEN 1
                    else 0
                END AS FLAG_HAS_TOUCHPOINT_BY_ACQTOPLEVELCHANNEL_SPONSOREDEMAIL,
                CASE
                    WHEN SPLIT_PART(infl_data.INFLUENCE_CHANNEL, '.', 1) = 'Tradeshow' THEN 1
                    else 0
                END AS FLAG_HAS_TOUCHPOINT_BY_ACQTOPLEVELCHANNEL_TRADESHOW,
                CASE
                    WHEN SPLIT_PART(infl_data.INFLUENCE_CHANNEL, '.', 1) = 'Web Referral' THEN 1
                    else 0
                END AS FLAG_HAS_TOUCHPOINT_BY_ACQTOPLEVELCHANNEL_WEBREFERRAL,
                CASE
                    WHEN SPLIT_PART(infl_data.INFLUENCE_CHANNEL, '.', 1) = 'Webinar' THEN 1
                    else 0
                END AS FLAG_HAS_TOUCHPOINT_BY_ACQTOPLEVELCHANNEL_WEBINAR,
				--20250314
                CASE
                    WHEN SPLIT_PART(infl_data.INFLUENCE_CHANNEL, '.', 1) = 'E-Gift' THEN 1
                    else 0
                END AS FLAG_HAS_TOUCHPOINT_BY_ACQTOPLEVELCHANNEL_EGIFT
            FROM
                ACT_MRKT_LIFECYCLE.AMLH_OPPS as amlh_opp
                -- touchtype_analytics_table as source
                LEFT JOIN ACT_MRKT_LIFECYCLE.TOUCHTYPE_ANALYTICS as infl_data ON amlh_opp.ACT_ID = infl_data.CRM_ACCOUNT_ID
            ORDER BY
                amlh_opp.AMLH_ACCOUNT__C,
                amlh_opp.AMLH_RECYCLE_COUNTER__C ASC,
                amlh_opp.AMLH_ACTIVE_MARKETING_LIFECYCLE_RECORD__C DESC,
                amlh_opp.AMLH_CREATED_DATE,
                infl_data.MARKETING_TOUCHPOINT_DATE
        );
RAISE INFO 'step 5a complete';

       
    -- Step 05b: Account Marketing Lifecycle History with Opp and Influence Data Aggregated
       
--     DROP TABLE IF EXISTS ACT_MRKT_LIFECYCLE.amlh_opp_infl_milestones;
--        CREATE TABLE ACT_MRKT_LIFECYCLE.amlh_opp_infl_milestones as

     DROP TABLE IF EXISTS ACT_MRKT_LIFECYCLE.amlh_opp_infl_milestones CASCADE;    
     CREATE TABLE ACT_MRKT_LIFECYCLE.amlh_opp_infl_milestones as


    SELECT y.* 

    FROM

    (
    SELECT
    x.AMLH_NAME,
    --x.AMLH_ACT_COUNTER_ID,
    x.ACT_ID,
    x.AMLH_RECYCLE_COUNTER__C,
    x.AMLH_MUTUALLY_EXCLUSIVE_PRE_SUSPECT_DESIGNATION,
    x.AMLH_MUTUALLY_EXCLUSIVE_PRE_SUSPECT_DESIGNATION_DATE,
    x.AMLH_SUSPECT_DATE_STAMP__C_CAST,
	x.AMLH_EFFECTIVE_DATE_STAMP__C_CAST,
    x.MARKETING_TOUCHPOINT_BEFORE_MILESTONE,
    x.MARKETING_TOUCHPOINT_BEFORE_ACT,
    x.MARKETING_TOUCHPOINT_BEFORE_ACT_DATE_MILESTONE_FIELD,
    x.MARKETING_TOUCHPOINT_BEFORE_ACT_DATE_MILESTONE,
    LAST_DAY(x.MARKETING_TOUCHPOINT_BEFORE_ACT_DATE_MILESTONE) as MARKETING_TOUCHPOINT_BEFORE_ACT_DATE_MILESTONE_EOM,
    cast(dateadd(day, -1, dateadd(QTR,1,DATE_TRUNC('QTR', x.MARKETING_TOUCHPOINT_BEFORE_ACT_DATE_MILESTONE)))as date) as MARKETING_TOUCHPOINT_BEFORE_ACT_DATE_MILESTONE_EOQ,
    DATE_PART_YEAR(x.MARKETING_TOUCHPOINT_BEFORE_ACT_DATE_MILESTONE) as MARKETING_TOUCHPOINT_BEFORE_ACT_DATE_MILESTONE_YEAR,
    x.MARKETING_TOUCHPOINT_DATE,
    LAST_DAY(x.MARKETING_TOUCHPOINT_DATE) as MARKETING_TOUCHPOINT_DATE_EOM,
    cast(dateadd(day, -1, dateadd(QTR,1,DATE_TRUNC('QTR', x.MARKETING_TOUCHPOINT_DATE)))as date) as MARKETING_TOUCHPOINT_DATE_EOQ,
    DATE_PART_YEAR(x.MARKETING_TOUCHPOINT_DATE) as MARKETING_TOUCHPOINT_DATE_EOY,   
    x.ACT_MARKET_SEGMENT__C,
	x.ACT_MARKET_SEGMENT__C_GROUP,
    x.ACT_MARKET__C,
    x.ACT_BUSINESS_UNIT_DIVISION__C,
	x.ACT_CAMPAIGN_TEXT__C,
	X.ACT_FIT_MODEL_TIER__C,
    x.INFLUENCE_CHANNEL,
    x.INFLUENCE_CHANNEL_TOPLEVEL,
    x.INFLUENCE_WEB_SOURCE,
    x.INFLUENCE_WEB_MEDIUM,
    x.INFLUENCE_CAMPAIGN_NAME,
    x.INFLUENCE_CAMPAIGN_MARKET_SEGMENT,
	x.INFLUENCE_CAMPAIGN_TYPE,
    x.INFLUENCE_UTM_CAMPAIGN,
    x.INFLUENCE_UTM_CONTENT,
    x.INFLUENCE_UTM_TERM,
    x.INFLUENCE_AD_NAME,                    
    x.INFLUENCE_CREATIVE_NAME,
    x.INFLUENCE_LANDING_PAGE,
    x.INFLUENCE_REFERRER,
    x.WEBVISIT_PAGE,
    x.WEBVISIT_REFERRER,
    x.OPP_ID,       
    x.OPP_CREATED_DATE,
    x.OPP_STAGE_NAME_CATEGORY,
    x.OPP_STAGE_NAME,
    x.OPP_IS_CLOSED,
    x.OPP_IS_WON,
    x.OPP_CLOSE_DATE,
    x.OPP_GLOBAL_UNQUALIFIED_DATE_COHORT,
    x.OPP_STAGE_0_DATE,
    x.OPP_STAGE_1_DATE,
    -- Financial Metrics
    x.OPP_CURRENCY_ISO_CODE,
    x.OPP_CONVERSION_RATE,
    x.OPP_ACV3__C,
    x.OPP_TOTAL_BOOKING_AMOUNT2__C,
    x.OPP_TOTAL_BOOKING_AMOUNT2__C_CONVERTED,
    x.OPP_SUBS_QTY__C,
    x.OPP_BOOKED_SUBS_QTY3__C,
    x.OPP_FORECASTED_SUBS_QTY__C,
    x.OPP_BOOKEDFORECASTED_SUBS_QTY3__C,
    x.OPP_SALES_REPORTING_ACV__C,
    x.OPP_FORECASTED_ACV__C,
    x.OPP_FORECASTED_ARR__C,
    x.OPP_SALES_REPORTING_ARR__C,
    x.OPP_BOOKEDFORECASTED_ACV3__C,
    x.OPP_BOOKEDFORECASTED_ACV_QTY3__C,
    x.OPP_BOOKEDFORECASTED_ARR__C,
	--20250314
	x.OPP_REPORTING_ARR__C,
    x.OPP_SALES_REPORTING_TOTAL_BOOKING_AMOUNT__C,
    x.OPP_SALES_REPORTING_ACV__C_CONVERTED,
    x.OPP_SALES_REPORTING_TOTAL_BOOKING_AMOUNT__C_CONVERTED,
    x.OPP_SALES_REPORTING_BOOKED_SUBS_QTY__C,

    CASE WHEN MARKETING_TOUCHPOINT_BEFORE_ACT = 1 AND
    (
    COALESCE(x.INTERACTIONTYPE_SIXSENSE_PAIDMEDIA_IMPRESSIONS_COUNT_INFLUENCE_ACT,0) +
    COALESCE(x.INTERACTIONTYPE_SIXSENSE_PAIDMEDIA_CLICKS_COUNT_INFLUENCE_ACT,0) +

    COALESCE(x.INTERACTIONTYPE_SIXSENSE_WEBVISIT_PAGELOAD_COUNT_INFLUENCE_ACT,0) +
    COALESCE(x.INTERACTIONTYPE_SIXSENSE_WEBVISIT_PLAY_COUNT_INFLUENCE_ACT,0) +
    COALESCE(x.INTERACTIONTYPE_SIXSENSE_WEBVISIT_CLICK_COUNT_INFLUENCE_ACT,0) +
    COALESCE(x.INTERACTIONTYPE_SIXSENSE_WEBVISIT_SUBMIT_COUNT_INFLUENCE_ACT,0) +

    COALESCE(x.INTERACTIONTYPE_BIZIBLE_TOUCHPOINT_WEBVISIT_COUNT_INFLUENCE_ACT,0) +
    COALESCE(x.INTERACTIONTYPE_BIZIBLE_TOUCHPOINT_WEBCHAT_COUNT_INFLUENCE_ACT,0) +
    COALESCE(x.INTERACTIONTYPE_BIZIBLE_TOUCHPOINT_WEBFORM_COUNT_INFLUENCE_ACT,0) +
    COALESCE(x.INTERACTIONTYPE_BIZIBLE_TOUCHPOINT_CRM_COUNT_INFLUENCE_ACT,0) +
    COALESCE(x.INTERACTIONTYPE_BIZIBLE_TOUCHPOINT_CONNECTWITHDM_COUNT_INFLUENCE_ACT,0) +
    COALESCE(x.INTERACTIONTYPE_BIZIBLE_TOUCHPOINT_CALLSPOKEWITH_COUNT_INFLUENCE_ACT,0) +
    COALESCE(x.INTERACTIONTYPE_BIZIBLE_TOUCHPOINT_CALLGATEKEEPER_COUNT_INFLUENCE_ACT,0) +
    COALESCE(x.INTERACTIONTYPE_BIZIBLE_TOUCHPOINT_NOLEADTOUCHPOINTS_COUNT_INFLUENCE_ACT,0) +
	--20250302
    COALESCE(x.INTERACTIONTYPE_BIZIBLE_TOUCHPOINT_MARKETO_COUNT_INFLUENCE_ACT,0) +
	--20250314
    COALESCE(x.INTERACTIONTYPE_BIZIBLE_TOUCHPOINT_SEISMICENGAGEMENT_COUNT_INFLUENCE_ACT,0) +
    COALESCE(x.INTERACTIONTYPE_BIZIBLE_TOUCHPOINT_CHANGESTATUS_COUNT_INFLUENCE_ACT,0)
	--COALESCE(x.INTERACTIONTYPE_BIZIBLE_TOUCHPOINT_UNCLASSIFIED_COUNT_INFLUENCE_ACT,0)
	
    ) > 0 THEN 1 ELSE 0 END AS INTERACTIONTYPE_INTERACTION_IMPRESSION_BEFORE_MILESTONE_FLAG,

    CASE WHEN 
    (
    COALESCE(x.INTERACTIONTYPE_SIXSENSE_PAIDMEDIA_IMPRESSIONS_COUNT_INFLUENCE_ACT,0) +
    COALESCE(x.INTERACTIONTYPE_SIXSENSE_PAIDMEDIA_CLICKS_COUNT_INFLUENCE_ACT,0) +

    COALESCE(x.INTERACTIONTYPE_SIXSENSE_WEBVISIT_PAGELOAD_COUNT_INFLUENCE_ACT,0) +
    COALESCE(x.INTERACTIONTYPE_SIXSENSE_WEBVISIT_PLAY_COUNT_INFLUENCE_ACT,0) +
    COALESCE(x.INTERACTIONTYPE_SIXSENSE_WEBVISIT_CLICK_COUNT_INFLUENCE_ACT,0) +
    COALESCE(x.INTERACTIONTYPE_SIXSENSE_WEBVISIT_SUBMIT_COUNT_INFLUENCE_ACT,0) +

    COALESCE(x.INTERACTIONTYPE_BIZIBLE_TOUCHPOINT_WEBVISIT_COUNT_INFLUENCE_ACT,0) +
    COALESCE(x.INTERACTIONTYPE_BIZIBLE_TOUCHPOINT_WEBCHAT_COUNT_INFLUENCE_ACT,0) +
    COALESCE(x.INTERACTIONTYPE_BIZIBLE_TOUCHPOINT_WEBFORM_COUNT_INFLUENCE_ACT,0) +
    COALESCE(x.INTERACTIONTYPE_BIZIBLE_TOUCHPOINT_CRM_COUNT_INFLUENCE_ACT,0) +
    COALESCE(x.INTERACTIONTYPE_BIZIBLE_TOUCHPOINT_CONNECTWITHDM_COUNT_INFLUENCE_ACT,0) +
    COALESCE(x.INTERACTIONTYPE_BIZIBLE_TOUCHPOINT_CALLSPOKEWITH_COUNT_INFLUENCE_ACT,0) +
    COALESCE(x.INTERACTIONTYPE_BIZIBLE_TOUCHPOINT_CALLGATEKEEPER_COUNT_INFLUENCE_ACT,0) +
    COALESCE(x.INTERACTIONTYPE_BIZIBLE_TOUCHPOINT_NOLEADTOUCHPOINTS_COUNT_INFLUENCE_ACT,0) +
	--20250302
    COALESCE(x.INTERACTIONTYPE_BIZIBLE_TOUCHPOINT_MARKETO_COUNT_INFLUENCE_ACT,0) +
	--20250314
    COALESCE(x.INTERACTIONTYPE_BIZIBLE_TOUCHPOINT_SEISMICENGAGEMENT_COUNT_INFLUENCE_ACT,0) +
    COALESCE(x.INTERACTIONTYPE_BIZIBLE_TOUCHPOINT_CHANGESTATUS_COUNT_INFLUENCE_ACT,0)
	--COALESCE(x.INTERACTIONTYPE_BIZIBLE_TOUCHPOINT_UNCLASSIFIED_COUNT_INFLUENCE_ACT,0)

    ) > 0 THEN 1 ELSE 0 END AS INTERACTIONTYPE_INTERACTION_IMPRESSION_FLAG,

    CASE WHEN MARKETING_TOUCHPOINT_BEFORE_ACT = 1 AND
    (
    --COALESCE(x.INTERACTIONTYPE_SIXSENSE_PAIDMEDIA_IMPRESSIONS_COUNT_INFLUENCE_ACT,0) +
    COALESCE(x.INTERACTIONTYPE_SIXSENSE_PAIDMEDIA_CLICKS_COUNT_INFLUENCE_ACT,0) +

    COALESCE(x.INTERACTIONTYPE_SIXSENSE_WEBVISIT_PAGELOAD_COUNT_INFLUENCE_ACT,0) +
    COALESCE(x.INTERACTIONTYPE_SIXSENSE_WEBVISIT_PLAY_COUNT_INFLUENCE_ACT,0) +
    COALESCE(x.INTERACTIONTYPE_SIXSENSE_WEBVISIT_CLICK_COUNT_INFLUENCE_ACT,0) +
    COALESCE(x.INTERACTIONTYPE_SIXSENSE_WEBVISIT_SUBMIT_COUNT_INFLUENCE_ACT,0) +

    COALESCE(x.INTERACTIONTYPE_BIZIBLE_TOUCHPOINT_WEBVISIT_COUNT_INFLUENCE_ACT,0) +
    COALESCE(x.INTERACTIONTYPE_BIZIBLE_TOUCHPOINT_WEBCHAT_COUNT_INFLUENCE_ACT,0) +
    COALESCE(x.INTERACTIONTYPE_BIZIBLE_TOUCHPOINT_WEBFORM_COUNT_INFLUENCE_ACT,0) +
    COALESCE(x.INTERACTIONTYPE_BIZIBLE_TOUCHPOINT_CRM_COUNT_INFLUENCE_ACT,0) +
    COALESCE(x.INTERACTIONTYPE_BIZIBLE_TOUCHPOINT_CONNECTWITHDM_COUNT_INFLUENCE_ACT,0) +
    COALESCE(x.INTERACTIONTYPE_BIZIBLE_TOUCHPOINT_CALLSPOKEWITH_COUNT_INFLUENCE_ACT,0) +
    COALESCE(x.INTERACTIONTYPE_BIZIBLE_TOUCHPOINT_CALLGATEKEEPER_COUNT_INFLUENCE_ACT,0) +
    COALESCE(x.INTERACTIONTYPE_BIZIBLE_TOUCHPOINT_NOLEADTOUCHPOINTS_COUNT_INFLUENCE_ACT,0) +
	--20250302
    COALESCE(x.INTERACTIONTYPE_BIZIBLE_TOUCHPOINT_MARKETO_COUNT_INFLUENCE_ACT,0) +
	--20250314
    COALESCE(x.INTERACTIONTYPE_BIZIBLE_TOUCHPOINT_SEISMICENGAGEMENT_COUNT_INFLUENCE_ACT,0) + 
    COALESCE(x.INTERACTIONTYPE_BIZIBLE_TOUCHPOINT_CHANGESTATUS_COUNT_INFLUENCE_ACT,0)
	--COALESCE(x.INTERACTIONTYPE_BIZIBLE_TOUCHPOINT_UNCLASSIFIED_COUNT_INFLUENCE_ACT,0)

    ) > 0 THEN 1 ELSE 0 END AS INTERACTIONTYPE_INTERACTION_ONLY_BEFORE_MILESTONE_FLAG,

    CASE WHEN 
    (
    --COALESCE(x.INTERACTIONTYPE_SIXSENSE_PAIDMEDIA_IMPRESSIONS_COUNT_INFLUENCE_ACT,0) +
    COALESCE(x.INTERACTIONTYPE_SIXSENSE_PAIDMEDIA_CLICKS_COUNT_INFLUENCE_ACT,0) +

    COALESCE(x.INTERACTIONTYPE_SIXSENSE_WEBVISIT_PAGELOAD_COUNT_INFLUENCE_ACT,0) +
    COALESCE(x.INTERACTIONTYPE_SIXSENSE_WEBVISIT_PLAY_COUNT_INFLUENCE_ACT,0) +
    COALESCE(x.INTERACTIONTYPE_SIXSENSE_WEBVISIT_CLICK_COUNT_INFLUENCE_ACT,0) +
    COALESCE(x.INTERACTIONTYPE_SIXSENSE_WEBVISIT_SUBMIT_COUNT_INFLUENCE_ACT,0) +

    COALESCE(x.INTERACTIONTYPE_BIZIBLE_TOUCHPOINT_WEBVISIT_COUNT_INFLUENCE_ACT,0) +
    COALESCE(x.INTERACTIONTYPE_BIZIBLE_TOUCHPOINT_WEBCHAT_COUNT_INFLUENCE_ACT,0) +
    COALESCE(x.INTERACTIONTYPE_BIZIBLE_TOUCHPOINT_WEBFORM_COUNT_INFLUENCE_ACT,0) +
    COALESCE(x.INTERACTIONTYPE_BIZIBLE_TOUCHPOINT_CRM_COUNT_INFLUENCE_ACT,0) +
    COALESCE(x.INTERACTIONTYPE_BIZIBLE_TOUCHPOINT_CONNECTWITHDM_COUNT_INFLUENCE_ACT,0) +
    COALESCE(x.INTERACTIONTYPE_BIZIBLE_TOUCHPOINT_CALLSPOKEWITH_COUNT_INFLUENCE_ACT,0) +
    COALESCE(x.INTERACTIONTYPE_BIZIBLE_TOUCHPOINT_CALLGATEKEEPER_COUNT_INFLUENCE_ACT,0) +
    COALESCE(x.INTERACTIONTYPE_BIZIBLE_TOUCHPOINT_NOLEADTOUCHPOINTS_COUNT_INFLUENCE_ACT,0) +
	--20250302
    COALESCE(x.INTERACTIONTYPE_BIZIBLE_TOUCHPOINT_MARKETO_COUNT_INFLUENCE_ACT,0) +
	--20250314
    COALESCE(x.INTERACTIONTYPE_BIZIBLE_TOUCHPOINT_SEISMICENGAGEMENT_COUNT_INFLUENCE_ACT,0) + 
    COALESCE(x.INTERACTIONTYPE_BIZIBLE_TOUCHPOINT_CHANGESTATUS_COUNT_INFLUENCE_ACT,0)
	--COALESCE(x.INTERACTIONTYPE_BIZIBLE_TOUCHPOINT_UNCLASSIFIED_COUNT_INFLUENCE_ACT,0)

    ) > 0 THEN 1 ELSE 0 END AS INTERACTIONTYPE_INTERACTION_ONLY_FLAG,

    -- Individual Breakout Sums

    COALESCE(x.INTERACTIONTYPE_SIXSENSE_PAIDMEDIA_IMPRESSIONS_COUNT_INFLUENCE_ACT,0) AS INTERACTIONTYPE_SIXSENSE_PAIDMEDIA_IMPRESSIONS_COUNT_INFLUENCE_ACT,
    COALESCE(x.INTERACTIONTYPE_SIXSENSE_PAIDMEDIA_CLICKS_COUNT_INFLUENCE_ACT,0) AS INTERACTIONTYPE_SIXSENSE_PAIDMEDIA_CLICKS_COUNT_INFLUENCE_ACT,

    COALESCE(x.INTERACTIONTYPE_SIXSENSE_WEBVISIT_TOTAL_INTERACTIONS_COUNT_INFLUENCE_ACT,0) AS INTERACTIONTYPE_SIXSENSE_WEBVISIT_TOTAL_INTERACTIONS_COUNT_INFLUENCE_ACT,
    COALESCE(x.INTERACTIONTYPE_SIXSENSE_WEBVISIT_PAGELOAD_COUNT_INFLUENCE_ACT,0) AS INTERACTIONTYPE_SIXSENSE_WEBVISIT_PAGELOAD_COUNT_INFLUENCE_ACT,
    COALESCE(x.INTERACTIONTYPE_SIXSENSE_WEBVISIT_PLAY_COUNT_INFLUENCE_ACT,0) AS INTERACTIONTYPE_SIXSENSE_WEBVISIT_PLAY_COUNT_INFLUENCE_ACT,
    COALESCE(x.INTERACTIONTYPE_SIXSENSE_WEBVISIT_CLICK_COUNT_INFLUENCE_ACT,0) AS INTERACTIONTYPE_SIXSENSE_WEBVISIT_CLICK_COUNT_INFLUENCE_ACT,
    COALESCE(x.INTERACTIONTYPE_SIXSENSE_WEBVISIT_SUBMIT_COUNT_INFLUENCE_ACT,0) AS INTERACTIONTYPE_SIXSENSE_WEBVISIT_SUBMIT_COUNT_INFLUENCE_ACT,
    COALESCE(x.INTERACTIONTYPE_SIXSENSE_WEBVISIT_UNCLASSIFIED_COUNT_INFLUENCE_ACT,0) AS INTERACTIONTYPE_SIXSENSE_WEBVISIT_UNCLASSIFIED_COUNT_INFLUENCE_ACT,

    COALESCE(x.INTERACTIONTYPE_BIZIBLE_TOUCHPOINT_WEBVISIT_COUNT_INFLUENCE_ACT,0) AS INTERACTIONTYPE_BIZIBLE_TOUCHPOINT_WEBVISIT_COUNT_INFLUENCE_ACT,
    COALESCE(x.INTERACTIONTYPE_BIZIBLE_TOUCHPOINT_WEBCHAT_COUNT_INFLUENCE_ACT,0) AS INTERACTIONTYPE_BIZIBLE_TOUCHPOINT_WEBCHAT_COUNT_INFLUENCE_ACT,
    COALESCE(x.INTERACTIONTYPE_BIZIBLE_TOUCHPOINT_WEBFORM_COUNT_INFLUENCE_ACT,0) AS INTERACTIONTYPE_BIZIBLE_TOUCHPOINT_WEBFORM_COUNT_INFLUENCE_ACT,
    COALESCE(x.INTERACTIONTYPE_BIZIBLE_TOUCHPOINT_CRM_COUNT_INFLUENCE_ACT,0) AS INTERACTIONTYPE_BIZIBLE_TOUCHPOINT_CRM_COUNT_INFLUENCE_ACT,
    COALESCE(x.INTERACTIONTYPE_BIZIBLE_TOUCHPOINT_CONNECTWITHDM_COUNT_INFLUENCE_ACT,0) AS INTERACTIONTYPE_BIZIBLE_TOUCHPOINT_CONNECTWITHDM_COUNT_INFLUENCE_ACT,
    COALESCE(x.INTERACTIONTYPE_BIZIBLE_TOUCHPOINT_CALLSPOKEWITH_COUNT_INFLUENCE_ACT,0) AS INTERACTIONTYPE_BIZIBLE_TOUCHPOINT_CALLSPOKEWITH_COUNT_INFLUENCE_ACT,
    COALESCE(x.INTERACTIONTYPE_BIZIBLE_TOUCHPOINT_CALLGATEKEEPER_COUNT_INFLUENCE_ACT,0) AS INTERACTIONTYPE_BIZIBLE_TOUCHPOINT_CALLGATEKEEPER_COUNT_INFLUENCE_ACT,
    COALESCE(x.INTERACTIONTYPE_BIZIBLE_TOUCHPOINT_NOLEADTOUCHPOINTS_COUNT_INFLUENCE_ACT,0) AS INTERACTIONTYPE_BIZIBLE_TOUCHPOINT_NOLEADTOUCHPOINTS_COUNT_INFLUENCE_ACT,
	--20250302
    COALESCE(x.INTERACTIONTYPE_BIZIBLE_TOUCHPOINT_MARKETO_COUNT_INFLUENCE_ACT,0) AS INTERACTIONTYPE_BIZIBLE_TOUCHPOINT_MARKETO_COUNT_INFLUENCE_ACT,
	--20250314
    COALESCE(x.INTERACTIONTYPE_BIZIBLE_TOUCHPOINT_SEISMICENGAGEMENT_COUNT_INFLUENCE_ACT,0) AS INTERACTIONTYPE_BIZIBLE_TOUCHPOINT_SEISMICENGAGEMENT_COUNT_INFLUENCE_ACT,
    COALESCE(x.INTERACTIONTYPE_BIZIBLE_TOUCHPOINT_CHANGESTATUS_COUNT_INFLUENCE_ACT,0) AS INTERACTIONTYPE_BIZIBLE_TOUCHPOINT_CHANGESTATUS_COUNT_INFLUENCE_ACT,
    COALESCE(x.INTERACTIONTYPE_BIZIBLE_TOUCHPOINT_UNCLASSIFIED_COUNT_INFLUENCE_ACT,0) AS INTERACTIONTYPE_BIZIBLE_TOUCHPOINT_UNCLASSIFIED_COUNT_INFLUENCE_ACT

    FROM

    (
    -- Touchpoints before MQA Routed
    SELECT
    -- ids
    AMLH_NAME, ACT_ID, AMLH_RECYCLE_COUNTER__C,
    AMLH_MUTUALLY_EXCLUSIVE_PRE_SUSPECT_DESIGNATION,
    AMLH_MUTUALLY_EXCLUSIVE_PRE_SUSPECT_DESIGNATION_DATE,
    AMLH_SUSPECT_DATE_STAMP__C_CAST,
	AMLH_EFFECTIVE_DATE_STAMP__C_CAST,

    'MQA - Routed' AS MARKETING_TOUCHPOINT_BEFORE_MILESTONE,
    MARKETING_TOUCHPOINT_BEFORE_ACT_SUSPECT AS MARKETING_TOUCHPOINT_BEFORE_ACT,
    'AMLH_SUSPECT_DATE_STAMP__C_CAST' AS MARKETING_TOUCHPOINT_BEFORE_ACT_DATE_MILESTONE_FIELD, 
    AMLH_SUSPECT_DATE_STAMP__C_CAST AS MARKETING_TOUCHPOINT_BEFORE_ACT_DATE_MILESTONE,
    MARKETING_TOUCHPOINT_DATE,
    -- attributes
    ACT_MARKET_SEGMENT__C,
    ACT_MARKET_SEGMENT__C_GROUP,
    ACT_MARKET__C,
    ACT_BUSINESS_UNIT_DIVISION__C,
	ACT_CAMPAIGN_TEXT__C,
	ACT_FIT_MODEL_TIER__C,
    INFLUENCE_CHANNEL,
    INFLUENCE_CHANNEL_TOPLEVEL,
    INFLUENCE_WEB_SOURCE,
    INFLUENCE_WEB_MEDIUM,
    INFLUENCE_CAMPAIGN_NAME,
	INFLUENCE_CAMPAIGN_MARKET_SEGMENT,
	INFLUENCE_CAMPAIGN_TYPE,
    INFLUENCE_UTM_CAMPAIGN,
    INFLUENCE_UTM_CONTENT,
    INFLUENCE_UTM_TERM,
    INFLUENCE_AD_NAME,  
    INFLUENCE_CREATIVE_NAME,
    INFLUENCE_LANDING_PAGE,
    INFLUENCE_REFERRER,
    WEBVISIT_PAGE,
    WEBVISIT_REFERRER,
    OPP_ID,
    OPP_CREATED_DATE,
    OPP_STAGE_NAME_CATEGORY,
    OPP_STAGE_NAME,
    OPP_IS_CLOSED,
    OPP_IS_WON,
    OPP_CLOSE_DATE,
    OPP_GLOBAL_UNQUALIFIED_DATE_COHORT,
    OPP_STAGE_0_DATE,
    OPP_STAGE_1_DATE,
    -- Financial Metrics
    OPP_CURRENCY_ISO_CODE,
    OPP_CONVERSION_RATE,
    OPP_ACV3__C,
    OPP_TOTAL_BOOKING_AMOUNT2__C,
    OPP_TOTAL_BOOKING_AMOUNT2__C_CONVERTED,
    OPP_SUBS_QTY__C,
    OPP_BOOKED_SUBS_QTY3__C,
    OPP_FORECASTED_SUBS_QTY__C,
    OPP_BOOKEDFORECASTED_SUBS_QTY3__C,
    OPP_FORECASTED_ACV__C,
    OPP_BOOKEDFORECASTED_ACV3__C,
    OPP_BOOKEDFORECASTED_ACV_QTY3__C,
    OPP_FORECASTED_ARR__C,
    OPP_BOOKEDFORECASTED_ARR__C,
    OPP_SALES_REPORTING_ARR__C,
	--20250314
	OPP_REPORTING_ARR__C,
    OPP_SALES_REPORTING_ACV__C,
    OPP_SALES_REPORTING_TOTAL_BOOKING_AMOUNT__C,
    OPP_SALES_REPORTING_ACV__C_CONVERTED,
    OPP_SALES_REPORTING_TOTAL_BOOKING_AMOUNT__C_CONVERTED,
    OPP_SALES_REPORTING_BOOKED_SUBS_QTY__C,
	--20250314
	SUM(SPEND) AS SPEND,
    -- metrics
    SUM(INTERACTIONTYPE_SIXSENSE_PAIDMEDIA_IMPRESSIONS_COUNT_INFLUENCE_ACTMQA) AS INTERACTIONTYPE_SIXSENSE_PAIDMEDIA_IMPRESSIONS_COUNT_INFLUENCE_ACT,
    SUM(INTERACTIONTYPE_SIXSENSE_PAIDMEDIA_CLICKS_COUNT_INFLUENCE_ACTMQA) AS INTERACTIONTYPE_SIXSENSE_PAIDMEDIA_CLICKS_COUNT_INFLUENCE_ACT,
    SUM(INTERACTIONTYPE_SIXSENSE_WEBVISIT_TOTAL_INTERACTIONS_COUNT_INFLUENCE_ACTMQA) AS INTERACTIONTYPE_SIXSENSE_WEBVISIT_TOTAL_INTERACTIONS_COUNT_INFLUENCE_ACT,
    SUM(INTERACTIONTYPE_SIXSENSE_WEBVISIT_PAGELOAD_COUNT_INFLUENCE_ACTMQA) AS INTERACTIONTYPE_SIXSENSE_WEBVISIT_PAGELOAD_COUNT_INFLUENCE_ACT,
    SUM(INTERACTIONTYPE_SIXSENSE_WEBVISIT_PLAY_COUNT_INFLUENCE_ACTMQA) AS INTERACTIONTYPE_SIXSENSE_WEBVISIT_PLAY_COUNT_INFLUENCE_ACT,
    SUM(INTERACTIONTYPE_SIXSENSE_WEBVISIT_CLICK_COUNT_INFLUENCE_ACTMQA) AS INTERACTIONTYPE_SIXSENSE_WEBVISIT_CLICK_COUNT_INFLUENCE_ACT,
    SUM(INTERACTIONTYPE_SIXSENSE_WEBVISIT_SUBMIT_COUNT_INFLUENCE_ACTMQA) AS INTERACTIONTYPE_SIXSENSE_WEBVISIT_SUBMIT_COUNT_INFLUENCE_ACT,
    SUM(INTERACTIONTYPE_SIXSENSE_WEBVISIT_UNCLASSIFIED_COUNT_INFLUENCE_ACTMQA) AS INTERACTIONTYPE_SIXSENSE_WEBVISIT_UNCLASSIFIED_COUNT_INFLUENCE_ACT,
    SUM(INTERACTIONTYPE_BIZIBLE_TOUCHPOINT_WEBVISIT_COUNT_INFLUENCE_ACTMQA) AS INTERACTIONTYPE_BIZIBLE_TOUCHPOINT_WEBVISIT_COUNT_INFLUENCE_ACT,
    SUM(INTERACTIONTYPE_BIZIBLE_TOUCHPOINT_WEBCHAT_COUNT_INFLUENCE_ACTMQA) AS INTERACTIONTYPE_BIZIBLE_TOUCHPOINT_WEBCHAT_COUNT_INFLUENCE_ACT,
    SUM(INTERACTIONTYPE_BIZIBLE_TOUCHPOINT_WEBFORM_COUNT_INFLUENCE_ACTMQA) AS INTERACTIONTYPE_BIZIBLE_TOUCHPOINT_WEBFORM_COUNT_INFLUENCE_ACT,
    SUM(INTERACTIONTYPE_BIZIBLE_TOUCHPOINT_CRM_COUNT_INFLUENCE_ACTMQA) AS INTERACTIONTYPE_BIZIBLE_TOUCHPOINT_CRM_COUNT_INFLUENCE_ACT,
    SUM(INTERACTIONTYPE_BIZIBLE_TOUCHPOINT_CONNECTWITHDM_COUNT_INFLUENCE_ACTMQA) AS INTERACTIONTYPE_BIZIBLE_TOUCHPOINT_CONNECTWITHDM_COUNT_INFLUENCE_ACT,
    SUM(INTERACTIONTYPE_BIZIBLE_TOUCHPOINT_CALLSPOKEWITH_COUNT_INFLUENCE_ACTMQA) AS INTERACTIONTYPE_BIZIBLE_TOUCHPOINT_CALLSPOKEWITH_COUNT_INFLUENCE_ACT,
    SUM(INTERACTIONTYPE_BIZIBLE_TOUCHPOINT_CALLGATEKEEPER_COUNT_INFLUENCE_ACTMQA) AS INTERACTIONTYPE_BIZIBLE_TOUCHPOINT_CALLGATEKEEPER_COUNT_INFLUENCE_ACT,
    SUM(INTERACTIONTYPE_BIZIBLE_TOUCHPOINT_NOLEADTOUCHPOINTS_COUNT_INFLUENCE_ACTMQA) AS INTERACTIONTYPE_BIZIBLE_TOUCHPOINT_NOLEADTOUCHPOINTS_COUNT_INFLUENCE_ACT,
	--20250302
    SUM(INTERACTIONTYPE_BIZIBLE_TOUCHPOINT_MARKETO_COUNT_INFLUENCE_ACTMQA) AS INTERACTIONTYPE_BIZIBLE_TOUCHPOINT_MARKETO_COUNT_INFLUENCE_ACT,
	--20250314
    SUM(INTERACTIONTYPE_BIZIBLE_TOUCHPOINT_SEISMICENGAGEMENT_COUNT_INFLUENCE_ACTMQA) AS INTERACTIONTYPE_BIZIBLE_TOUCHPOINT_SEISMICENGAGEMENT_COUNT_INFLUENCE_ACT,
    SUM(INTERACTIONTYPE_BIZIBLE_TOUCHPOINT_CHANGESTATUS_COUNT_INFLUENCE_ACTMQA) AS INTERACTIONTYPE_BIZIBLE_TOUCHPOINT_CHANGESTATUS_COUNT_INFLUENCE_ACT,
    SUM(INTERACTIONTYPE_BIZIBLE_TOUCHPOINT_UNCLASSIFIED_COUNT_INFLUENCE_ACTMQA) AS INTERACTIONTYPE_BIZIBLE_TOUCHPOINT_UNCLASSIFIED_COUNT_INFLUENCE_ACT

    FROM ACT_MRKT_LIFECYCLE.AMLH_INFL_OPP

    WHERE AMLH_ACCOUNT_JOURNEY_PATH_LIFECYCLE_NONLINEAR_FLAG = 'Linear' 
    -- Period Filter based on paramater
    AND (AMLH_MUTUALLY_EXCLUSIVE_PRE_SUSPECT_DESIGNATION ='Pre-Suspect MQA - Routed')
    AND (AMLH_SUSPECT_DATE_STAMP__C_CAST BETWEEN '10-01-2023' and '12-31-2025')
    GROUP BY 
    -- ids
    AMLH_NAME, ACT_ID, AMLH_RECYCLE_COUNTER__C,
    AMLH_MUTUALLY_EXCLUSIVE_PRE_SUSPECT_DESIGNATION,
    AMLH_MUTUALLY_EXCLUSIVE_PRE_SUSPECT_DESIGNATION_DATE,
    AMLH_SUSPECT_DATE_STAMP__C_CAST,
	AMLH_EFFECTIVE_DATE_STAMP__C_CAST,
    MARKETING_TOUCHPOINT_DATE,
    --MARKETING_TOUCHPOINT_BEFORE_ACT_MQA,
    MARKETING_TOUCHPOINT_BEFORE_ACT_SUSPECT,

    -- attributes
    ACT_MARKET_SEGMENT__C,
	ACT_MARKET_SEGMENT__C_GROUP,
    ACT_MARKET__C,
    ACT_BUSINESS_UNIT_DIVISION__C,
	ACT_CAMPAIGN_TEXT__C,
	ACT_FIT_MODEL_TIER__C,
    INFLUENCE_CHANNEL,
    INFLUENCE_CHANNEL_TOPLEVEL,
    INFLUENCE_WEB_SOURCE,
    INFLUENCE_WEB_MEDIUM,
    INFLUENCE_CAMPAIGN_NAME,
	INFLUENCE_CAMPAIGN_MARKET_SEGMENT,
	INFLUENCE_CAMPAIGN_TYPE,
    INFLUENCE_UTM_CAMPAIGN,
    INFLUENCE_UTM_CONTENT,
    INFLUENCE_UTM_TERM,
    INFLUENCE_AD_NAME,  
    INFLUENCE_CREATIVE_NAME,
    INFLUENCE_LANDING_PAGE,
    INFLUENCE_REFERRER,
    WEBVISIT_PAGE,
    WEBVISIT_REFERRER,
    OPP_ID,
    OPP_CREATED_DATE,
    OPP_STAGE_NAME_CATEGORY,
    OPP_STAGE_NAME,
    OPP_IS_CLOSED,
    OPP_IS_WON,
    OPP_CLOSE_DATE,
    OPP_GLOBAL_UNQUALIFIED_DATE_COHORT,
    OPP_STAGE_0_DATE,
    OPP_STAGE_1_DATE,
    -- Financial Metrics
    OPP_CURRENCY_ISO_CODE,
    OPP_CONVERSION_RATE,
    OPP_ACV3__C,
    OPP_TOTAL_BOOKING_AMOUNT2__C,
    OPP_TOTAL_BOOKING_AMOUNT2__C_CONVERTED,
    OPP_SUBS_QTY__C,
    OPP_BOOKED_SUBS_QTY3__C,
    OPP_FORECASTED_SUBS_QTY__C,
    OPP_BOOKEDFORECASTED_SUBS_QTY3__C,
    OPP_FORECASTED_ACV__C,
    OPP_BOOKEDFORECASTED_ACV3__C,
    OPP_BOOKEDFORECASTED_ACV_QTY3__C,
    OPP_FORECASTED_ARR__C,
    OPP_BOOKEDFORECASTED_ARR__C,
    OPP_SALES_REPORTING_ARR__C,
	--20250314
	OPP_REPORTING_ARR__C,
    OPP_SALES_REPORTING_ACV__C,
    OPP_SALES_REPORTING_TOTAL_BOOKING_AMOUNT__C,
    OPP_SALES_REPORTING_ACV__C_CONVERTED,
    OPP_SALES_REPORTING_TOTAL_BOOKING_AMOUNT__C_CONVERTED,
    OPP_SALES_REPORTING_BOOKED_SUBS_QTY__C
    -- ORDER BY ACT_ID, AMLH_RECYCLE_COUNTER__C

    UNION ALL

    -- Touchpoints before MEA Routed
    SELECT 
    -- ids
    AMLH_NAME, ACT_ID, AMLH_RECYCLE_COUNTER__C,
    AMLH_MUTUALLY_EXCLUSIVE_PRE_SUSPECT_DESIGNATION,
    AMLH_MUTUALLY_EXCLUSIVE_PRE_SUSPECT_DESIGNATION_DATE,
    AMLH_SUSPECT_DATE_STAMP__C_CAST,
	AMLH_EFFECTIVE_DATE_STAMP__C_CAST,

    'MEA - Routed' AS MARKETING_TOUCHPOINT_BEFORE_MILESTONE,
    MARKETING_TOUCHPOINT_BEFORE_ACT_SUSPECT AS MARKETING_TOUCHPOINT_BEFORE_ACT,
    'AMLH_SUSPECT_DATE_STAMP__C_CAST' AS MARKETING_TOUCHPOINT_BEFORE_ACT_DATE_MILESTONE_FIELD, 
    AMLH_SUSPECT_DATE_STAMP__C_CAST AS MARKETING_TOUCHPOINT_BEFORE_ACT_DATE_MILESTONE,
    MARKETING_TOUCHPOINT_DATE,
    -- attributes
    ACT_MARKET_SEGMENT__C,
	ACT_MARKET_SEGMENT__C_GROUP,
    ACT_MARKET__C,
    ACT_BUSINESS_UNIT_DIVISION__C,
	ACT_CAMPAIGN_TEXT__C,
	ACT_FIT_MODEL_TIER__C,
    INFLUENCE_CHANNEL,
    INFLUENCE_CHANNEL_TOPLEVEL,
    INFLUENCE_WEB_SOURCE,
    INFLUENCE_WEB_MEDIUM,
    INFLUENCE_CAMPAIGN_NAME,
	INFLUENCE_CAMPAIGN_MARKET_SEGMENT,
	INFLUENCE_CAMPAIGN_TYPE,
    INFLUENCE_UTM_CAMPAIGN,
    INFLUENCE_UTM_CONTENT,
    INFLUENCE_UTM_TERM,
    INFLUENCE_AD_NAME,  
    INFLUENCE_CREATIVE_NAME,
    INFLUENCE_LANDING_PAGE,
    INFLUENCE_REFERRER,
    WEBVISIT_PAGE,
    WEBVISIT_REFERRER,
    OPP_ID,
    OPP_CREATED_DATE,
    OPP_STAGE_NAME_CATEGORY,
    OPP_STAGE_NAME,
    OPP_IS_CLOSED,
    OPP_IS_WON,
    OPP_CLOSE_DATE,
    OPP_GLOBAL_UNQUALIFIED_DATE_COHORT,
    OPP_STAGE_0_DATE,
    OPP_STAGE_1_DATE,
    -- Financial Metrics
    OPP_CURRENCY_ISO_CODE,
    OPP_CONVERSION_RATE,
    OPP_ACV3__C,
    OPP_TOTAL_BOOKING_AMOUNT2__C,
    OPP_TOTAL_BOOKING_AMOUNT2__C_CONVERTED,
    OPP_SUBS_QTY__C,
    OPP_BOOKED_SUBS_QTY3__C,
    OPP_FORECASTED_SUBS_QTY__C,
    OPP_BOOKEDFORECASTED_SUBS_QTY3__C,
    OPP_FORECASTED_ACV__C,
    OPP_BOOKEDFORECASTED_ACV3__C,
    OPP_BOOKEDFORECASTED_ACV_QTY3__C,
    OPP_FORECASTED_ARR__C,
    OPP_BOOKEDFORECASTED_ARR__C,
    OPP_SALES_REPORTING_ARR__C,
	--20250314
	OPP_REPORTING_ARR__C,
    OPP_SALES_REPORTING_ACV__C,
    OPP_SALES_REPORTING_TOTAL_BOOKING_AMOUNT__C,
    OPP_SALES_REPORTING_ACV__C_CONVERTED,
    OPP_SALES_REPORTING_TOTAL_BOOKING_AMOUNT__C_CONVERTED,
    OPP_SALES_REPORTING_BOOKED_SUBS_QTY__C,
	--20250314
	SUM(SPEND) AS SPEND,
    -- metrics
    SUM(INTERACTIONTYPE_SIXSENSE_PAIDMEDIA_IMPRESSIONS_COUNT_INFLUENCE_ACTMEA) AS INTERACTIONTYPE_SIXSENSE_PAIDMEDIA_IMPRESSIONS_COUNT_INFLUENCE_ACT,
    SUM(INTERACTIONTYPE_SIXSENSE_PAIDMEDIA_CLICKS_COUNT_INFLUENCE_ACTMEA) AS INTERACTIONTYPE_SIXSENSE_PAIDMEDIA_CLICKS_COUNT_INFLUENCE_ACT,
    SUM(INTERACTIONTYPE_SIXSENSE_WEBVISIT_TOTAL_INTERACTIONS_COUNT_INFLUENCE_ACTMEA) AS INTERACTIONTYPE_SIXSENSE_WEBVISIT_TOTAL_INTERACTIONS_COUNT_INFLUENCE_ACT,
    SUM(INTERACTIONTYPE_SIXSENSE_WEBVISIT_PAGELOAD_COUNT_INFLUENCE_ACTMEA) AS INTERACTIONTYPE_SIXSENSE_WEBVISIT_PAGELOAD_COUNT_INFLUENCE_ACT,
    SUM(INTERACTIONTYPE_SIXSENSE_WEBVISIT_PLAY_COUNT_INFLUENCE_ACTMEA) AS INTERACTIONTYPE_SIXSENSE_WEBVISIT_PLAY_COUNT_INFLUENCE_ACT,
    SUM(INTERACTIONTYPE_SIXSENSE_WEBVISIT_CLICK_COUNT_INFLUENCE_ACTMEA) AS INTERACTIONTYPE_SIXSENSE_WEBVISIT_CLICK_COUNT_INFLUENCE_ACT,
    SUM(INTERACTIONTYPE_SIXSENSE_WEBVISIT_SUBMIT_COUNT_INFLUENCE_ACTMEA) AS INTERACTIONTYPE_SIXSENSE_WEBVISIT_SUBMIT_COUNT_INFLUENCE_ACT,
    SUM(INTERACTIONTYPE_SIXSENSE_WEBVISIT_UNCLASSIFIED_COUNT_INFLUENCE_ACTMEA) AS INTERACTIONTYPE_SIXSENSE_WEBVISIT_UNCLASSIFIED_COUNT_INFLUENCE_ACT,
    SUM(INTERACTIONTYPE_BIZIBLE_TOUCHPOINT_WEBVISIT_COUNT_INFLUENCE_ACTMEA) AS INTERACTIONTYPE_BIZIBLE_TOUCHPOINT_WEBVISIT_COUNT_INFLUENCE_ACT,
    SUM(INTERACTIONTYPE_BIZIBLE_TOUCHPOINT_WEBCHAT_COUNT_INFLUENCE_ACTMEA) AS INTERACTIONTYPE_BIZIBLE_TOUCHPOINT_WEBCHAT_COUNT_INFLUENCE_ACT,
    SUM(INTERACTIONTYPE_BIZIBLE_TOUCHPOINT_WEBFORM_COUNT_INFLUENCE_ACTMEA) AS INTERACTIONTYPE_BIZIBLE_TOUCHPOINT_WEBFORM_COUNT_INFLUENCE_ACT,
    SUM(INTERACTIONTYPE_BIZIBLE_TOUCHPOINT_CRM_COUNT_INFLUENCE_ACTMEA) AS INTERACTIONTYPE_BIZIBLE_TOUCHPOINT_CRM_COUNT_INFLUENCE_ACT,
    SUM(INTERACTIONTYPE_BIZIBLE_TOUCHPOINT_CONNECTWITHDM_COUNT_INFLUENCE_ACTMEA) AS INTERACTIONTYPE_BIZIBLE_TOUCHPOINT_CONNECTWITHDM_COUNT_INFLUENCE_ACT,
    SUM(INTERACTIONTYPE_BIZIBLE_TOUCHPOINT_CALLSPOKEWITH_COUNT_INFLUENCE_ACTMEA) AS INTERACTIONTYPE_BIZIBLE_TOUCHPOINT_CALLSPOKEWITH_COUNT_INFLUENCE_ACT,
    SUM(INTERACTIONTYPE_BIZIBLE_TOUCHPOINT_CALLGATEKEEPER_COUNT_INFLUENCE_ACTMEA) AS INTERACTIONTYPE_BIZIBLE_TOUCHPOINT_CALLGATEKEEPER_COUNT_INFLUENCE_ACT,
    SUM(INTERACTIONTYPE_BIZIBLE_TOUCHPOINT_NOLEADTOUCHPOINTS_COUNT_INFLUENCE_ACTMEA) AS INTERACTIONTYPE_BIZIBLE_TOUCHPOINT_NOLEADTOUCHPOINTS_COUNT_INFLUENCE_ACT,
	--20250302
    SUM(INTERACTIONTYPE_BIZIBLE_TOUCHPOINT_MARKETO_COUNT_INFLUENCE_ACTMEA) AS INTERACTIONTYPE_BIZIBLE_TOUCHPOINT_MARKETO_COUNT_INFLUENCE_ACT,
	--20250314
    SUM(INTERACTIONTYPE_BIZIBLE_TOUCHPOINT_SEISMICENGAGEMENT_COUNT_INFLUENCE_ACTMEA) AS INTERACTIONTYPE_BIZIBLE_TOUCHPOINT_SEISMICENGAGEMENT_COUNT_INFLUENCE_ACT,
    SUM(INTERACTIONTYPE_BIZIBLE_TOUCHPOINT_CHANGESTATUS_COUNT_INFLUENCE_ACTMEA) AS INTERACTIONTYPE_BIZIBLE_TOUCHPOINT_CHANGESTATUS_COUNT_INFLUENCE_ACT,
    SUM(INTERACTIONTYPE_BIZIBLE_TOUCHPOINT_UNCLASSIFIED_COUNT_INFLUENCE_ACTMEA) AS INTERACTIONTYPE_BIZIBLE_TOUCHPOINT_UNCLASSIFIED_COUNT_INFLUENCE_ACT

    FROM ACT_MRKT_LIFECYCLE.AMLH_INFL_OPP

    WHERE AMLH_ACCOUNT_JOURNEY_PATH_LIFECYCLE_NONLINEAR_FLAG = 'Linear' 
    -- Period Filter based on paramater
    AND (AMLH_MUTUALLY_EXCLUSIVE_PRE_SUSPECT_DESIGNATION ='Pre-Suspect MEA - Routed')
    AND (AMLH_SUSPECT_DATE_STAMP__C_CAST BETWEEN '10-01-2023' and '12-31-2025')
    GROUP BY 
    -- ids
    AMLH_NAME, ACT_ID, AMLH_RECYCLE_COUNTER__C,
    AMLH_MUTUALLY_EXCLUSIVE_PRE_SUSPECT_DESIGNATION,
    AMLH_MUTUALLY_EXCLUSIVE_PRE_SUSPECT_DESIGNATION_DATE,
    AMLH_SUSPECT_DATE_STAMP__C_CAST,
	AMLH_EFFECTIVE_DATE_STAMP__C_CAST,
    MARKETING_TOUCHPOINT_DATE,
    MARKETING_TOUCHPOINT_BEFORE_ACT_SUSPECT,

    -- attributes
    ACT_MARKET_SEGMENT__C,
	ACT_MARKET_SEGMENT__C_GROUP,
    ACT_MARKET__C,
    ACT_BUSINESS_UNIT_DIVISION__C,
	ACT_CAMPAIGN_TEXT__C,
	ACT_FIT_MODEL_TIER__C,
    INFLUENCE_CHANNEL,
    INFLUENCE_CHANNEL_TOPLEVEL,
    INFLUENCE_WEB_SOURCE,
    INFLUENCE_WEB_MEDIUM,
    INFLUENCE_CAMPAIGN_NAME,
	INFLUENCE_CAMPAIGN_MARKET_SEGMENT,
	INFLUENCE_CAMPAIGN_TYPE,
    INFLUENCE_UTM_CAMPAIGN,
    INFLUENCE_UTM_CONTENT,
    INFLUENCE_UTM_TERM,
    INFLUENCE_AD_NAME,  
    INFLUENCE_CREATIVE_NAME,
    INFLUENCE_LANDING_PAGE,
    INFLUENCE_REFERRER,
    WEBVISIT_PAGE,
    WEBVISIT_REFERRER,
    OPP_ID,
    OPP_CREATED_DATE,
    OPP_STAGE_NAME_CATEGORY,
    OPP_STAGE_NAME,
    OPP_IS_CLOSED,
    OPP_IS_WON,
    OPP_CLOSE_DATE,
    OPP_GLOBAL_UNQUALIFIED_DATE_COHORT,
    OPP_STAGE_0_DATE,
    OPP_STAGE_1_DATE,
    -- Financial Metrics
    OPP_CURRENCY_ISO_CODE,
    OPP_CONVERSION_RATE,
    OPP_ACV3__C,
    OPP_TOTAL_BOOKING_AMOUNT2__C,
    OPP_TOTAL_BOOKING_AMOUNT2__C_CONVERTED,
    OPP_SUBS_QTY__C,
    OPP_BOOKED_SUBS_QTY3__C,
    OPP_FORECASTED_SUBS_QTY__C,
    OPP_BOOKEDFORECASTED_SUBS_QTY3__C,
    OPP_FORECASTED_ACV__C,
    OPP_BOOKEDFORECASTED_ACV3__C,
    OPP_BOOKEDFORECASTED_ACV_QTY3__C,
    OPP_FORECASTED_ARR__C,
    OPP_BOOKEDFORECASTED_ARR__C,
    OPP_SALES_REPORTING_ARR__C,
	--20250314
	OPP_REPORTING_ARR__C,
    OPP_SALES_REPORTING_ACV__C,
    OPP_SALES_REPORTING_TOTAL_BOOKING_AMOUNT__C,
    OPP_SALES_REPORTING_ACV__C_CONVERTED,
    OPP_SALES_REPORTING_TOTAL_BOOKING_AMOUNT__C_CONVERTED,
    OPP_SALES_REPORTING_BOOKED_SUBS_QTY__C
    -- ORDER BY ACT_ID, AMLH_RECYCLE_COUNTER__C

    UNION ALL

    -- Touchpoints before Opp Created
    SELECT 
    -- ids
    AMLH_NAME, ACT_ID, AMLH_RECYCLE_COUNTER__C,
    AMLH_MUTUALLY_EXCLUSIVE_PRE_SUSPECT_DESIGNATION,
    AMLH_MUTUALLY_EXCLUSIVE_PRE_SUSPECT_DESIGNATION_DATE,
    AMLH_SUSPECT_DATE_STAMP__C_CAST,
	AMLH_EFFECTIVE_DATE_STAMP__C_CAST,
    'Opportunity Created' AS MARKETING_TOUCHPOINT_BEFORE_MILESTONE,
    MARKETING_TOUCHPOINT_BEFORE_OPP_CREATED AS MARKETING_TOUCHPOINT_BEFORE_ACT,
    'OPP_CREATED_DATE' AS MARKETING_TOUCHPOINT_BEFORE_ACT_DATE_MILESTONE_FIELD, 
    OPP_CREATED_DATE AS MARKETING_TOUCHPOINT_BEFORE_ACT_DATE_MILESTONE,
    MARKETING_TOUCHPOINT_DATE,
    -- attributes
    ACT_MARKET_SEGMENT__C,
	ACT_MARKET_SEGMENT__C_GROUP,
    ACT_MARKET__C,
    ACT_BUSINESS_UNIT_DIVISION__C,
	ACT_CAMPAIGN_TEXT__C,
	ACT_FIT_MODEL_TIER__C,
    INFLUENCE_CHANNEL,
    INFLUENCE_CHANNEL_TOPLEVEL,
    INFLUENCE_WEB_SOURCE,
    INFLUENCE_WEB_MEDIUM,
    INFLUENCE_CAMPAIGN_NAME,
	INFLUENCE_CAMPAIGN_MARKET_SEGMENT,
	INFLUENCE_CAMPAIGN_TYPE,
    INFLUENCE_UTM_CAMPAIGN,
    INFLUENCE_UTM_CONTENT,
    INFLUENCE_UTM_TERM,
    INFLUENCE_AD_NAME,
    INFLUENCE_CREATIVE_NAME,
    INFLUENCE_LANDING_PAGE,
    INFLUENCE_REFERRER,
    WEBVISIT_PAGE,
    WEBVISIT_REFERRER,
    OPP_ID,
    OPP_CREATED_DATE,
    OPP_STAGE_NAME_CATEGORY,
    OPP_STAGE_NAME,
    OPP_IS_CLOSED,
    OPP_IS_WON,
    OPP_CLOSE_DATE,
    OPP_GLOBAL_UNQUALIFIED_DATE_COHORT,
    OPP_STAGE_0_DATE,
    OPP_STAGE_1_DATE,
    -- Financial Metrics
    OPP_CURRENCY_ISO_CODE,
    OPP_CONVERSION_RATE,
    OPP_ACV3__C,
    OPP_TOTAL_BOOKING_AMOUNT2__C,
    OPP_TOTAL_BOOKING_AMOUNT2__C_CONVERTED,
    OPP_SUBS_QTY__C,
    OPP_BOOKED_SUBS_QTY3__C,
    OPP_FORECASTED_SUBS_QTY__C,
    OPP_BOOKEDFORECASTED_SUBS_QTY3__C,
    OPP_FORECASTED_ACV__C,
    OPP_BOOKEDFORECASTED_ACV3__C,
    OPP_BOOKEDFORECASTED_ACV_QTY3__C,
    OPP_FORECASTED_ARR__C,
    OPP_BOOKEDFORECASTED_ARR__C,
    OPP_SALES_REPORTING_ARR__C,
	--20250314
	OPP_REPORTING_ARR__C,
    OPP_SALES_REPORTING_ACV__C,
    OPP_SALES_REPORTING_TOTAL_BOOKING_AMOUNT__C,
    OPP_SALES_REPORTING_ACV__C_CONVERTED,
    OPP_SALES_REPORTING_TOTAL_BOOKING_AMOUNT__C_CONVERTED,
    OPP_SALES_REPORTING_BOOKED_SUBS_QTY__C,
	--20250314
	SUM(SPEND) AS SPEND,
    -- metrics
    SUM(INTERACTIONTYPE_SIXSENSE_PAIDMEDIA_IMPRESSIONS_COUNT_INFLUENCE_OPPCRT) AS INTERACTIONTYPE_SIXSENSE_PAIDMEDIA_IMPRESSIONS_COUNT_INFLUENCE_ACT,
    SUM(INTERACTIONTYPE_SIXSENSE_PAIDMEDIA_CLICKS_COUNT_INFLUENCE_OPPCRT) AS INTERACTIONTYPE_SIXSENSE_PAIDMEDIA_CLICKS_COUNT_INFLUENCE_ACT,
    SUM(INTERACTIONTYPE_SIXSENSE_WEBVISIT_TOTAL_INTERACTIONS_COUNT_INFLUENCE_OPPCRT) AS INTERACTIONTYPE_SIXSENSE_WEBVISIT_TOTAL_INTERACTIONS_COUNT_INFLUENCE_ACT,
    SUM(INTERACTIONTYPE_SIXSENSE_WEBVISIT_PAGELOAD_COUNT_INFLUENCE_OPPCRT) AS INTERACTIONTYPE_SIXSENSE_WEBVISIT_PAGELOAD_COUNT_INFLUENCE_ACT,
    SUM(INTERACTIONTYPE_SIXSENSE_WEBVISIT_PLAY_COUNT_INFLUENCE_OPPCRT) AS INTERACTIONTYPE_SIXSENSE_WEBVISIT_PLAY_COUNT_INFLUENCE_ACT,
    SUM(INTERACTIONTYPE_SIXSENSE_WEBVISIT_CLICK_COUNT_INFLUENCE_OPPCRT) AS INTERACTIONTYPE_SIXSENSE_WEBVISIT_CLICK_COUNT_INFLUENCE_ACT,
    SUM(INTERACTIONTYPE_SIXSENSE_WEBVISIT_SUBMIT_COUNT_INFLUENCE_OPPCRT) AS INTERACTIONTYPE_SIXSENSE_WEBVISIT_SUBMIT_COUNT_INFLUENCE_ACT,
    SUM(INTERACTIONTYPE_SIXSENSE_WEBVISIT_UNCLASSIFIED_COUNT_INFLUENCE_OPPCRT) AS INTERACTIONTYPE_SIXSENSE_WEBVISIT_UNCLASSIFIED_COUNT_INFLUENCE_ACT,
    SUM(INTERACTIONTYPE_BIZIBLE_TOUCHPOINT_WEBVISIT_COUNT_INFLUENCE_OPPCRT) AS INTERACTIONTYPE_BIZIBLE_TOUCHPOINT_WEBVISIT_COUNT_INFLUENCE_ACT,
    SUM(INTERACTIONTYPE_BIZIBLE_TOUCHPOINT_WEBCHAT_COUNT_INFLUENCE_OPPCRT) AS INTERACTIONTYPE_BIZIBLE_TOUCHPOINT_WEBCHAT_COUNT_INFLUENCE_ACT,
    SUM(INTERACTIONTYPE_BIZIBLE_TOUCHPOINT_WEBFORM_COUNT_INFLUENCE_OPPCRT) AS INTERACTIONTYPE_BIZIBLE_TOUCHPOINT_WEBFORM_COUNT_INFLUENCE_ACT,
    SUM(INTERACTIONTYPE_BIZIBLE_TOUCHPOINT_CRM_COUNT_INFLUENCE_OPPCRT) AS INTERACTIONTYPE_BIZIBLE_TOUCHPOINT_CRM_COUNT_INFLUENCE_ACT,
    SUM(INTERACTIONTYPE_BIZIBLE_TOUCHPOINT_CONNECTWITHDM_COUNT_INFLUENCE_OPPCRT) AS INTERACTIONTYPE_BIZIBLE_TOUCHPOINT_CONNECTWITHDM_COUNT_INFLUENCE_ACT,
    SUM(INTERACTIONTYPE_BIZIBLE_TOUCHPOINT_CALLSPOKEWITH_COUNT_INFLUENCE_OPPCRT) AS INTERACTIONTYPE_BIZIBLE_TOUCHPOINT_CALLSPOKEWITH_COUNT_INFLUENCE_ACT,
    SUM(INTERACTIONTYPE_BIZIBLE_TOUCHPOINT_CALLGATEKEEPER_COUNT_INFLUENCE_OPPCRT) AS INTERACTIONTYPE_BIZIBLE_TOUCHPOINT_CALLGATEKEEPER_COUNT_INFLUENCE_ACT,
    SUM(INTERACTIONTYPE_BIZIBLE_TOUCHPOINT_NOLEADTOUCHPOINTS_COUNT_INFLUENCE_OPPCRT) AS INTERACTIONTYPE_BIZIBLE_TOUCHPOINT_NOLEADTOUCHPOINTS_COUNT_INFLUENCE_ACT,
	--20250302
    SUM(INTERACTIONTYPE_BIZIBLE_TOUCHPOINT_MARKETO_COUNT_INFLUENCE_OPPCRT) AS INTERACTIONTYPE_BIZIBLE_TOUCHPOINT_MARKETO_COUNT_INFLUENCE_ACT,
	--20250314
    SUM(INTERACTIONTYPE_BIZIBLE_TOUCHPOINT_SEISMICENGAGEMENT_COUNT_INFLUENCE_OPPCRT) AS INTERACTIONTYPE_BIZIBLE_TOUCHPOINT_SEISMICENGAGEMENT_COUNT_INFLUENCE_ACT,
    SUM(INTERACTIONTYPE_BIZIBLE_TOUCHPOINT_CHANGESTATUS_COUNT_INFLUENCE_OPPCRT) AS INTERACTIONTYPE_BIZIBLE_TOUCHPOINT_CHANGESTATUS_COUNT_INFLUENCE_ACT,
    SUM(INTERACTIONTYPE_BIZIBLE_TOUCHPOINT_UNCLASSIFIED_COUNT_INFLUENCE_OPPCRT) AS INTERACTIONTYPE_BIZIBLE_TOUCHPOINT_UNCLASSIFIED_COUNT_INFLUENCE_ACT

    FROM ACT_MRKT_LIFECYCLE.AMLH_INFL_OPP

    WHERE AMLH_ACCOUNT_JOURNEY_PATH_LIFECYCLE_NONLINEAR_FLAG = 'Linear' 
    -- Period Filter based on paramater
    and (OPP_CREATED_DATE BETWEEN '10-01-2023' and '12-31-2025')
    GROUP BY 
    -- ids
    AMLH_NAME, ACT_ID, AMLH_RECYCLE_COUNTER__C,
    AMLH_MUTUALLY_EXCLUSIVE_PRE_SUSPECT_DESIGNATION,
    AMLH_MUTUALLY_EXCLUSIVE_PRE_SUSPECT_DESIGNATION_DATE,
    AMLH_SUSPECT_DATE_STAMP__C_CAST,
	AMLH_EFFECTIVE_DATE_STAMP__C_CAST,
    MARKETING_TOUCHPOINT_DATE,
    MARKETING_TOUCHPOINT_BEFORE_OPP_CREATED,

    -- attributes
    ACT_MARKET_SEGMENT__C,
	ACT_MARKET_SEGMENT__C_GROUP,
    ACT_MARKET__C,
    ACT_BUSINESS_UNIT_DIVISION__C,
	ACT_CAMPAIGN_TEXT__C,
	ACT_FIT_MODEL_TIER__C,
    INFLUENCE_CHANNEL,
    INFLUENCE_CHANNEL_TOPLEVEL,
    INFLUENCE_WEB_SOURCE,
    INFLUENCE_WEB_MEDIUM,
    INFLUENCE_CAMPAIGN_NAME,
	INFLUENCE_CAMPAIGN_MARKET_SEGMENT,
	INFLUENCE_CAMPAIGN_TYPE,
    INFLUENCE_UTM_CAMPAIGN,
    INFLUENCE_UTM_CONTENT,
    INFLUENCE_UTM_TERM,
    INFLUENCE_AD_NAME,
    INFLUENCE_CREATIVE_NAME,
    INFLUENCE_LANDING_PAGE,
    INFLUENCE_REFERRER,
    WEBVISIT_PAGE,
    WEBVISIT_REFERRER,
    OPP_ID,
    OPP_CREATED_DATE,
    OPP_STAGE_NAME_CATEGORY,
    OPP_STAGE_NAME,
    OPP_IS_CLOSED,
    OPP_IS_WON,
    OPP_CLOSE_DATE,
    OPP_GLOBAL_UNQUALIFIED_DATE_COHORT,
    OPP_STAGE_0_DATE,
    OPP_STAGE_1_DATE,
    -- Financial Metrics
    OPP_CURRENCY_ISO_CODE,
    OPP_CONVERSION_RATE,
    OPP_ACV3__C,
    OPP_TOTAL_BOOKING_AMOUNT2__C,
    OPP_TOTAL_BOOKING_AMOUNT2__C_CONVERTED,
    OPP_SUBS_QTY__C,
    OPP_BOOKED_SUBS_QTY3__C,
    OPP_FORECASTED_SUBS_QTY__C,
    OPP_BOOKEDFORECASTED_SUBS_QTY3__C,
    OPP_FORECASTED_ACV__C,
    OPP_BOOKEDFORECASTED_ACV3__C,
    OPP_BOOKEDFORECASTED_ACV_QTY3__C,
    OPP_FORECASTED_ARR__C,
    OPP_BOOKEDFORECASTED_ARR__C,
    OPP_SALES_REPORTING_ARR__C,
    OPP_SALES_REPORTING_ACV__C,
	--20250314
	OPP_REPORTING_ARR__C,
    OPP_SALES_REPORTING_TOTAL_BOOKING_AMOUNT__C,
    OPP_SALES_REPORTING_ACV__C_CONVERTED,
    OPP_SALES_REPORTING_TOTAL_BOOKING_AMOUNT__C_CONVERTED,
    OPP_SALES_REPORTING_BOOKED_SUBS_QTY__C
    -- ORDER BY ACT_ID, AMLH_RECYCLE_COUNTER__C

    UNION ALL
    
        -- Touchpoints before Stage Zero
    SELECT 
    -- ids
    AMLH_NAME, ACT_ID, AMLH_RECYCLE_COUNTER__C,
    AMLH_MUTUALLY_EXCLUSIVE_PRE_SUSPECT_DESIGNATION,
    AMLH_MUTUALLY_EXCLUSIVE_PRE_SUSPECT_DESIGNATION_DATE,
    AMLH_SUSPECT_DATE_STAMP__C_CAST,
	AMLH_EFFECTIVE_DATE_STAMP__C_CAST,
    'Opportunity Stage Zero' AS MARKETING_TOUCHPOINT_BEFORE_MILESTONE,
	--20250302
    MARKETING_TOUCHPOINT_BEFORE_OPP_STAGE_0 AS MARKETING_TOUCHPOINT_BEFORE_ACT,
    'OPP_STAGE_ZERO_DATE' AS MARKETING_TOUCHPOINT_BEFORE_ACT_DATE_MILESTONE_FIELD, 
    OPP_STAGE_0_DATE  AS MARKETING_TOUCHPOINT_BEFORE_ACT_DATE_MILESTONE,
    MARKETING_TOUCHPOINT_DATE,
    -- attributes
    ACT_MARKET_SEGMENT__C,
	ACT_MARKET_SEGMENT__C_GROUP,
    ACT_MARKET__C,
    ACT_BUSINESS_UNIT_DIVISION__C,
	ACT_CAMPAIGN_TEXT__C,
	ACT_FIT_MODEL_TIER__C,
    INFLUENCE_CHANNEL,
    INFLUENCE_CHANNEL_TOPLEVEL,
    INFLUENCE_WEB_SOURCE,
    INFLUENCE_WEB_MEDIUM,
    INFLUENCE_CAMPAIGN_NAME,
	INFLUENCE_CAMPAIGN_MARKET_SEGMENT,
	INFLUENCE_CAMPAIGN_TYPE,
    INFLUENCE_UTM_CAMPAIGN,
    INFLUENCE_UTM_CONTENT,
    INFLUENCE_UTM_TERM,
    INFLUENCE_AD_NAME,
    INFLUENCE_CREATIVE_NAME,
    INFLUENCE_LANDING_PAGE,
    INFLUENCE_REFERRER,
    WEBVISIT_PAGE,
    WEBVISIT_REFERRER,
    OPP_ID,
    OPP_CREATED_DATE,
    OPP_STAGE_NAME_CATEGORY,
    OPP_STAGE_NAME,
    OPP_IS_CLOSED,
    OPP_IS_WON,
    OPP_CLOSE_DATE,
    OPP_GLOBAL_UNQUALIFIED_DATE_COHORT,
    OPP_STAGE_0_DATE,
    OPP_STAGE_1_DATE,
    -- Financial Metrics
    OPP_CURRENCY_ISO_CODE,
    OPP_CONVERSION_RATE,
    OPP_ACV3__C,
    OPP_TOTAL_BOOKING_AMOUNT2__C,
    OPP_TOTAL_BOOKING_AMOUNT2__C_CONVERTED,
    OPP_SUBS_QTY__C,
    OPP_BOOKED_SUBS_QTY3__C,
    OPP_FORECASTED_SUBS_QTY__C,
    OPP_BOOKEDFORECASTED_SUBS_QTY3__C,
    OPP_FORECASTED_ACV__C,
    OPP_BOOKEDFORECASTED_ACV3__C,
    OPP_BOOKEDFORECASTED_ACV_QTY3__C,
    OPP_FORECASTED_ARR__C,
    OPP_BOOKEDFORECASTED_ARR__C,
    OPP_SALES_REPORTING_ARR__C,
	--20250314
	OPP_REPORTING_ARR__C,
    OPP_SALES_REPORTING_ACV__C,
    OPP_SALES_REPORTING_TOTAL_BOOKING_AMOUNT__C,
    OPP_SALES_REPORTING_ACV__C_CONVERTED,
    OPP_SALES_REPORTING_TOTAL_BOOKING_AMOUNT__C_CONVERTED,
    OPP_SALES_REPORTING_BOOKED_SUBS_QTY__C,
	--20250314
	SUM(SPEND) AS SPEND,
    -- metrics
    SUM(INTERACTIONTYPE_SIXSENSE_PAIDMEDIA_IMPRESSIONS_COUNT_INFLUENCE_OPPSTG0) AS INTERACTIONTYPE_SIXSENSE_PAIDMEDIA_IMPRESSIONS_COUNT_INFLUENCE_ACT,
    SUM(INTERACTIONTYPE_SIXSENSE_PAIDMEDIA_CLICKS_COUNT_INFLUENCE_OPPSTG0) AS INTERACTIONTYPE_SIXSENSE_PAIDMEDIA_CLICKS_COUNT_INFLUENCE_ACT,
    SUM(INTERACTIONTYPE_SIXSENSE_WEBVISIT_TOTAL_INTERACTIONS_COUNT_INFLUENCE_OPPSTG0) AS INTERACTIONTYPE_SIXSENSE_WEBVISIT_TOTAL_INTERACTIONS_COUNT_INFLUENCE_ACT,
    SUM(INTERACTIONTYPE_SIXSENSE_WEBVISIT_PAGELOAD_COUNT_INFLUENCE_OPPSTG0) AS INTERACTIONTYPE_SIXSENSE_WEBVISIT_PAGELOAD_COUNT_INFLUENCE_ACT,
    SUM(INTERACTIONTYPE_SIXSENSE_WEBVISIT_PLAY_COUNT_INFLUENCE_OPPSTG0) AS INTERACTIONTYPE_SIXSENSE_WEBVISIT_PLAY_COUNT_INFLUENCE_ACT,
    SUM(INTERACTIONTYPE_SIXSENSE_WEBVISIT_CLICK_COUNT_INFLUENCE_OPPSTG0) AS INTERACTIONTYPE_SIXSENSE_WEBVISIT_CLICK_COUNT_INFLUENCE_ACT,
    SUM(INTERACTIONTYPE_SIXSENSE_WEBVISIT_SUBMIT_COUNT_INFLUENCE_OPPSTG0) AS INTERACTIONTYPE_SIXSENSE_WEBVISIT_SUBMIT_COUNT_INFLUENCE_ACT,
    SUM(INTERACTIONTYPE_SIXSENSE_WEBVISIT_UNCLASSIFIED_COUNT_INFLUENCE_OPPSTG0) AS INTERACTIONTYPE_SIXSENSE_WEBVISIT_UNCLASSIFIED_COUNT_INFLUENCE_ACT,
    SUM(INTERACTIONTYPE_BIZIBLE_TOUCHPOINT_WEBVISIT_COUNT_INFLUENCE_OPPSTG0) AS INTERACTIONTYPE_BIZIBLE_TOUCHPOINT_WEBVISIT_COUNT_INFLUENCE_ACT,
    SUM(INTERACTIONTYPE_BIZIBLE_TOUCHPOINT_WEBCHAT_COUNT_INFLUENCE_OPPSTG0) AS INTERACTIONTYPE_BIZIBLE_TOUCHPOINT_WEBCHAT_COUNT_INFLUENCE_ACT,
    SUM(INTERACTIONTYPE_BIZIBLE_TOUCHPOINT_WEBFORM_COUNT_INFLUENCE_OPPSTG0) AS INTERACTIONTYPE_BIZIBLE_TOUCHPOINT_WEBFORM_COUNT_INFLUENCE_ACT,
    SUM(INTERACTIONTYPE_BIZIBLE_TOUCHPOINT_CRM_COUNT_INFLUENCE_OPPSTG0) AS INTERACTIONTYPE_BIZIBLE_TOUCHPOINT_CRM_COUNT_INFLUENCE_ACT,
    SUM(INTERACTIONTYPE_BIZIBLE_TOUCHPOINT_CONNECTWITHDM_COUNT_INFLUENCE_OPPSTG0) AS INTERACTIONTYPE_BIZIBLE_TOUCHPOINT_CONNECTWITHDM_COUNT_INFLUENCE_ACT,
    SUM(INTERACTIONTYPE_BIZIBLE_TOUCHPOINT_CALLSPOKEWITH_COUNT_INFLUENCE_OPPSTG0) AS INTERACTIONTYPE_BIZIBLE_TOUCHPOINT_CALLSPOKEWITH_COUNT_INFLUENCE_ACT,
    SUM(INTERACTIONTYPE_BIZIBLE_TOUCHPOINT_CALLGATEKEEPER_COUNT_INFLUENCE_OPPSTG0) AS INTERACTIONTYPE_BIZIBLE_TOUCHPOINT_CALLGATEKEEPER_COUNT_INFLUENCE_ACT,
    SUM(INTERACTIONTYPE_BIZIBLE_TOUCHPOINT_NOLEADTOUCHPOINTS_COUNT_INFLUENCE_OPPSTG0) AS INTERACTIONTYPE_BIZIBLE_TOUCHPOINT_NOLEADTOUCHPOINTS_COUNT_INFLUENCE_ACT,
	--20250302
    SUM(INTERACTIONTYPE_BIZIBLE_TOUCHPOINT_MARKETO_COUNT_INFLUENCE_OPPSTG0) AS INTERACTIONTYPE_BIZIBLE_TOUCHPOINT_MARKETO_COUNT_INFLUENCE_ACT,
	--20250314
    SUM(INTERACTIONTYPE_BIZIBLE_TOUCHPOINT_SEISMICENGAGEMENT_COUNT_INFLUENCE_OPPSTG0) AS INTERACTIONTYPE_BIZIBLE_TOUCHPOINT_SEISMICENGAGEMENT_COUNT_INFLUENCE_ACT,
    SUM(INTERACTIONTYPE_BIZIBLE_TOUCHPOINT_CHANGESTATUS_COUNT_INFLUENCE_OPPSTG0) AS INTERACTIONTYPE_BIZIBLE_TOUCHPOINT_CHANGESTATUS_COUNT_INFLUENCE_ACT,
    SUM(INTERACTIONTYPE_BIZIBLE_TOUCHPOINT_UNCLASSIFIED_COUNT_INFLUENCE_OPPSTG0) AS INTERACTIONTYPE_BIZIBLE_TOUCHPOINT_UNCLASSIFIED_COUNT_INFLUENCE_ACT

    FROM ACT_MRKT_LIFECYCLE.AMLH_INFL_OPP

    WHERE AMLH_ACCOUNT_JOURNEY_PATH_LIFECYCLE_NONLINEAR_FLAG = 'Linear' 
    -- Period Filter based on paramater
    and (OPP_STAGE_0_DATE BETWEEN '10-01-2023' and '12-31-2025')
    GROUP BY 
    -- ids
    AMLH_NAME, ACT_ID, AMLH_RECYCLE_COUNTER__C,
    AMLH_MUTUALLY_EXCLUSIVE_PRE_SUSPECT_DESIGNATION,
    AMLH_MUTUALLY_EXCLUSIVE_PRE_SUSPECT_DESIGNATION_DATE,
    AMLH_SUSPECT_DATE_STAMP__C_CAST,
	AMLH_EFFECTIVE_DATE_STAMP__C_CAST,
    MARKETING_TOUCHPOINT_DATE,
	--20250302
    MARKETING_TOUCHPOINT_BEFORE_OPP_STAGE_0,

    -- attributes
    ACT_MARKET_SEGMENT__C,
	ACT_MARKET_SEGMENT__C_GROUP,
    ACT_MARKET__C,
    ACT_BUSINESS_UNIT_DIVISION__C,
	ACT_CAMPAIGN_TEXT__C,
	ACT_FIT_MODEL_TIER__C,
    INFLUENCE_CHANNEL,
    INFLUENCE_CHANNEL_TOPLEVEL,
    INFLUENCE_WEB_SOURCE,
    INFLUENCE_WEB_MEDIUM,
    INFLUENCE_CAMPAIGN_NAME,
	INFLUENCE_CAMPAIGN_MARKET_SEGMENT,
	INFLUENCE_CAMPAIGN_TYPE,
    INFLUENCE_UTM_CAMPAIGN,
    INFLUENCE_UTM_CONTENT,
    INFLUENCE_UTM_TERM,
    INFLUENCE_AD_NAME,
    INFLUENCE_CREATIVE_NAME,
    INFLUENCE_LANDING_PAGE,
    INFLUENCE_REFERRER,
    WEBVISIT_PAGE,
    WEBVISIT_REFERRER,
    OPP_ID,
    OPP_CREATED_DATE,
    OPP_STAGE_NAME_CATEGORY,
    OPP_STAGE_NAME,
    OPP_IS_CLOSED,
    OPP_IS_WON,
    OPP_CLOSE_DATE,
    OPP_GLOBAL_UNQUALIFIED_DATE_COHORT,
    OPP_STAGE_0_DATE, -- this was the initial one where it was unexpected that wasnt in the others
    OPP_STAGE_1_DATE,
    -- Financial Metrics
    OPP_CURRENCY_ISO_CODE,
    OPP_CONVERSION_RATE,
    OPP_ACV3__C,
    OPP_TOTAL_BOOKING_AMOUNT2__C,
    OPP_TOTAL_BOOKING_AMOUNT2__C_CONVERTED,
    OPP_SUBS_QTY__C,
    OPP_BOOKED_SUBS_QTY3__C,
    OPP_FORECASTED_SUBS_QTY__C,
    OPP_BOOKEDFORECASTED_SUBS_QTY3__C,
    OPP_FORECASTED_ACV__C,
    OPP_BOOKEDFORECASTED_ACV3__C,
    OPP_BOOKEDFORECASTED_ACV_QTY3__C,
    OPP_FORECASTED_ARR__C,
    OPP_BOOKEDFORECASTED_ARR__C,
    OPP_SALES_REPORTING_ARR__C,
	--20250314
	OPP_REPORTING_ARR__C,
    OPP_SALES_REPORTING_ACV__C,
    OPP_SALES_REPORTING_TOTAL_BOOKING_AMOUNT__C,
    OPP_SALES_REPORTING_ACV__C_CONVERTED,
    OPP_SALES_REPORTING_TOTAL_BOOKING_AMOUNT__C_CONVERTED,
    OPP_SALES_REPORTING_BOOKED_SUBS_QTY__C
    -- ORDER BY ACT_ID, AMLH_RECYCLE_COUNTER__C
    
    UNION ALL
    
        -- Touchpoints before Stage One
    SELECT 
    -- ids
    AMLH_NAME, ACT_ID, AMLH_RECYCLE_COUNTER__C,
    AMLH_MUTUALLY_EXCLUSIVE_PRE_SUSPECT_DESIGNATION,
    AMLH_MUTUALLY_EXCLUSIVE_PRE_SUSPECT_DESIGNATION_DATE,
    AMLH_SUSPECT_DATE_STAMP__C_CAST,
	AMLH_EFFECTIVE_DATE_STAMP__C_CAST,
    'Opportunity Stage One' AS MARKETING_TOUCHPOINT_BEFORE_MILESTONE,
	--20250302
    MARKETING_TOUCHPOINT_BEFORE_OPP_STAGE_1 AS MARKETING_TOUCHPOINT_BEFORE_ACT,
    'OPP_STAGE_ONE_DATE' AS MARKETING_TOUCHPOINT_BEFORE_ACT_DATE_MILESTONE_FIELD, 
    OPP_STAGE_1_DATE  AS MARKETING_TOUCHPOINT_BEFORE_ACT_DATE_MILESTONE,
    MARKETING_TOUCHPOINT_DATE,
    -- attributes
    ACT_MARKET_SEGMENT__C,
	ACT_MARKET_SEGMENT__C_GROUP,
    ACT_MARKET__C,
    ACT_BUSINESS_UNIT_DIVISION__C,
	ACT_CAMPAIGN_TEXT__C,
	ACT_FIT_MODEL_TIER__C,
    INFLUENCE_CHANNEL,
    INFLUENCE_CHANNEL_TOPLEVEL,
    INFLUENCE_WEB_SOURCE,
    INFLUENCE_WEB_MEDIUM,
    INFLUENCE_CAMPAIGN_NAME,
	INFLUENCE_CAMPAIGN_MARKET_SEGMENT,
	INFLUENCE_CAMPAIGN_TYPE,
    INFLUENCE_UTM_CAMPAIGN,
    INFLUENCE_UTM_CONTENT,
    INFLUENCE_UTM_TERM,
    INFLUENCE_AD_NAME,
    INFLUENCE_CREATIVE_NAME,
    INFLUENCE_LANDING_PAGE,
    INFLUENCE_REFERRER,
    WEBVISIT_PAGE,
    WEBVISIT_REFERRER,
    OPP_ID,
    OPP_CREATED_DATE,
    OPP_STAGE_NAME_CATEGORY,
    OPP_STAGE_NAME,
    OPP_IS_CLOSED,
    OPP_IS_WON,
    OPP_CLOSE_DATE,
    OPP_GLOBAL_UNQUALIFIED_DATE_COHORT,
    OPP_STAGE_0_DATE,
    OPP_STAGE_1_DATE,
    -- Financial Metrics
    OPP_CURRENCY_ISO_CODE,
    OPP_CONVERSION_RATE,
    OPP_ACV3__C,
    OPP_TOTAL_BOOKING_AMOUNT2__C,
    OPP_TOTAL_BOOKING_AMOUNT2__C_CONVERTED,
    OPP_SUBS_QTY__C,
    OPP_BOOKED_SUBS_QTY3__C,
    OPP_FORECASTED_SUBS_QTY__C,
    OPP_BOOKEDFORECASTED_SUBS_QTY3__C,
    OPP_FORECASTED_ACV__C,
    OPP_BOOKEDFORECASTED_ACV3__C,
    OPP_BOOKEDFORECASTED_ACV_QTY3__C,
    OPP_FORECASTED_ARR__C,
    OPP_BOOKEDFORECASTED_ARR__C,
    OPP_SALES_REPORTING_ARR__C,
	--20250314
	OPP_REPORTING_ARR__C,
    OPP_SALES_REPORTING_ACV__C,
    OPP_SALES_REPORTING_TOTAL_BOOKING_AMOUNT__C,
    OPP_SALES_REPORTING_ACV__C_CONVERTED,
    OPP_SALES_REPORTING_TOTAL_BOOKING_AMOUNT__C_CONVERTED,
    OPP_SALES_REPORTING_BOOKED_SUBS_QTY__C,
	--20250314
	SUM(SPEND) AS SPEND,
    -- metrics
    SUM(INTERACTIONTYPE_SIXSENSE_PAIDMEDIA_IMPRESSIONS_COUNT_INFLUENCE_OPPSTG1) AS INTERACTIONTYPE_SIXSENSE_PAIDMEDIA_IMPRESSIONS_COUNT_INFLUENCE_ACT,
    SUM(INTERACTIONTYPE_SIXSENSE_PAIDMEDIA_CLICKS_COUNT_INFLUENCE_OPPSTG1) AS INTERACTIONTYPE_SIXSENSE_PAIDMEDIA_CLICKS_COUNT_INFLUENCE_ACT,
    SUM(INTERACTIONTYPE_SIXSENSE_WEBVISIT_TOTAL_INTERACTIONS_COUNT_INFLUENCE_OPPSTG1) AS INTERACTIONTYPE_SIXSENSE_WEBVISIT_TOTAL_INTERACTIONS_COUNT_INFLUENCE_ACT,
    SUM(INTERACTIONTYPE_SIXSENSE_WEBVISIT_PAGELOAD_COUNT_INFLUENCE_OPPSTG1) AS INTERACTIONTYPE_SIXSENSE_WEBVISIT_PAGELOAD_COUNT_INFLUENCE_ACT,
    SUM(INTERACTIONTYPE_SIXSENSE_WEBVISIT_PLAY_COUNT_INFLUENCE_OPPSTG1) AS INTERACTIONTYPE_SIXSENSE_WEBVISIT_PLAY_COUNT_INFLUENCE_ACT,
    SUM(INTERACTIONTYPE_SIXSENSE_WEBVISIT_CLICK_COUNT_INFLUENCE_OPPSTG1) AS INTERACTIONTYPE_SIXSENSE_WEBVISIT_CLICK_COUNT_INFLUENCE_ACT,
    SUM(INTERACTIONTYPE_SIXSENSE_WEBVISIT_SUBMIT_COUNT_INFLUENCE_OPPSTG1) AS INTERACTIONTYPE_SIXSENSE_WEBVISIT_SUBMIT_COUNT_INFLUENCE_ACT,
    SUM(INTERACTIONTYPE_SIXSENSE_WEBVISIT_UNCLASSIFIED_COUNT_INFLUENCE_OPPSTG1) AS INTERACTIONTYPE_SIXSENSE_WEBVISIT_UNCLASSIFIED_COUNT_INFLUENCE_ACT,
    SUM(INTERACTIONTYPE_BIZIBLE_TOUCHPOINT_WEBVISIT_COUNT_INFLUENCE_OPPSTG1) AS INTERACTIONTYPE_BIZIBLE_TOUCHPOINT_WEBVISIT_COUNT_INFLUENCE_ACT,
    SUM(INTERACTIONTYPE_BIZIBLE_TOUCHPOINT_WEBCHAT_COUNT_INFLUENCE_OPPSTG1) AS INTERACTIONTYPE_BIZIBLE_TOUCHPOINT_WEBCHAT_COUNT_INFLUENCE_ACT,
    SUM(INTERACTIONTYPE_BIZIBLE_TOUCHPOINT_WEBFORM_COUNT_INFLUENCE_OPPSTG1) AS INTERACTIONTYPE_BIZIBLE_TOUCHPOINT_WEBFORM_COUNT_INFLUENCE_ACT,
    SUM(INTERACTIONTYPE_BIZIBLE_TOUCHPOINT_CRM_COUNT_INFLUENCE_OPPSTG1) AS INTERACTIONTYPE_BIZIBLE_TOUCHPOINT_CRM_COUNT_INFLUENCE_ACT,
    SUM(INTERACTIONTYPE_BIZIBLE_TOUCHPOINT_CONNECTWITHDM_COUNT_INFLUENCE_OPPSTG1) AS INTERACTIONTYPE_BIZIBLE_TOUCHPOINT_CONNECTWITHDM_COUNT_INFLUENCE_ACT,
    SUM(INTERACTIONTYPE_BIZIBLE_TOUCHPOINT_CALLSPOKEWITH_COUNT_INFLUENCE_OPPSTG1) AS INTERACTIONTYPE_BIZIBLE_TOUCHPOINT_CALLSPOKEWITH_COUNT_INFLUENCE_ACT,
    SUM(INTERACTIONTYPE_BIZIBLE_TOUCHPOINT_CALLGATEKEEPER_COUNT_INFLUENCE_OPPSTG1) AS INTERACTIONTYPE_BIZIBLE_TOUCHPOINT_CALLGATEKEEPER_COUNT_INFLUENCE_ACT,
    SUM(INTERACTIONTYPE_BIZIBLE_TOUCHPOINT_NOLEADTOUCHPOINTS_COUNT_INFLUENCE_OPPSTG1) AS INTERACTIONTYPE_BIZIBLE_TOUCHPOINT_NOLEADTOUCHPOINTS_COUNT_INFLUENCE_ACT,
	--20250302
    SUM(INTERACTIONTYPE_BIZIBLE_TOUCHPOINT_MARKETO_COUNT_INFLUENCE_OPPSTG1) AS INTERACTIONTYPE_BIZIBLE_TOUCHPOINT_MARKETO_COUNT_INFLUENCE_ACT,
	--20250314
    SUM(INTERACTIONTYPE_BIZIBLE_TOUCHPOINT_SEISMICENGAGEMENT_COUNT_INFLUENCE_OPPSTG1) AS INTERACTIONTYPE_BIZIBLE_TOUCHPOINT_SEISMICENGAGEMENT_COUNT_INFLUENCE_ACT,
    SUM(INTERACTIONTYPE_BIZIBLE_TOUCHPOINT_CHANGESTATUS_COUNT_INFLUENCE_OPPSTG1) AS INTERACTIONTYPE_BIZIBLE_TOUCHPOINT_CHANGESTATUS_COUNT_INFLUENCE_ACT,
    SUM(INTERACTIONTYPE_BIZIBLE_TOUCHPOINT_UNCLASSIFIED_COUNT_INFLUENCE_OPPSTG1) AS INTERACTIONTYPE_BIZIBLE_TOUCHPOINT_UNCLASSIFIED_COUNT_INFLUENCE_ACT

    FROM ACT_MRKT_LIFECYCLE.AMLH_INFL_OPP

    WHERE AMLH_ACCOUNT_JOURNEY_PATH_LIFECYCLE_NONLINEAR_FLAG = 'Linear' 
    -- Period Filter based on paramater
    and (OPP_STAGE_1_DATE BETWEEN '10-01-2023' and '12-31-2025')
    GROUP BY 
    -- ids
    AMLH_NAME, ACT_ID, AMLH_RECYCLE_COUNTER__C,
    AMLH_MUTUALLY_EXCLUSIVE_PRE_SUSPECT_DESIGNATION,
    AMLH_MUTUALLY_EXCLUSIVE_PRE_SUSPECT_DESIGNATION_DATE,
    AMLH_SUSPECT_DATE_STAMP__C_CAST,
	AMLH_EFFECTIVE_DATE_STAMP__C_CAST,
    MARKETING_TOUCHPOINT_DATE,
	--20250302
    MARKETING_TOUCHPOINT_BEFORE_OPP_STAGE_1,

    -- attributes
    ACT_MARKET_SEGMENT__C,
	ACT_MARKET_SEGMENT__C_GROUP,
    ACT_MARKET__C,
    ACT_BUSINESS_UNIT_DIVISION__C,
	ACT_CAMPAIGN_TEXT__C,
	ACT_FIT_MODEL_TIER__C,
    INFLUENCE_CHANNEL,
    INFLUENCE_CHANNEL_TOPLEVEL,
    INFLUENCE_WEB_SOURCE,
    INFLUENCE_WEB_MEDIUM,
    INFLUENCE_CAMPAIGN_NAME,
	INFLUENCE_CAMPAIGN_MARKET_SEGMENT,
	INFLUENCE_CAMPAIGN_TYPE,
    INFLUENCE_UTM_CAMPAIGN,
    INFLUENCE_UTM_CONTENT,
    INFLUENCE_UTM_TERM,
    INFLUENCE_AD_NAME,
    INFLUENCE_CREATIVE_NAME,
    INFLUENCE_LANDING_PAGE,
    INFLUENCE_REFERRER,
    WEBVISIT_PAGE,
    WEBVISIT_REFERRER,
    OPP_ID,
    OPP_CREATED_DATE,
    OPP_STAGE_NAME_CATEGORY,
    OPP_STAGE_NAME,
    OPP_IS_CLOSED,
    OPP_IS_WON,
    OPP_CLOSE_DATE,
    OPP_GLOBAL_UNQUALIFIED_DATE_COHORT,
    OPP_STAGE_0_DATE,
    OPP_STAGE_1_DATE, -- this was the initial one where it was unexpected that wasnt in the others
    -- Financial Metrics
    OPP_CURRENCY_ISO_CODE,
    OPP_CONVERSION_RATE,
    OPP_ACV3__C,
    OPP_TOTAL_BOOKING_AMOUNT2__C,
    OPP_TOTAL_BOOKING_AMOUNT2__C_CONVERTED,
    OPP_SUBS_QTY__C,
    OPP_BOOKED_SUBS_QTY3__C,
    OPP_FORECASTED_SUBS_QTY__C,
    OPP_BOOKEDFORECASTED_SUBS_QTY3__C,
    OPP_FORECASTED_ACV__C,
    OPP_BOOKEDFORECASTED_ACV3__C,
    OPP_BOOKEDFORECASTED_ACV_QTY3__C,
    OPP_FORECASTED_ARR__C,
    OPP_BOOKEDFORECASTED_ARR__C,
    OPP_SALES_REPORTING_ARR__C,
	--20250314
	OPP_REPORTING_ARR__C,
    OPP_SALES_REPORTING_ACV__C,
    OPP_SALES_REPORTING_TOTAL_BOOKING_AMOUNT__C,
    OPP_SALES_REPORTING_ACV__C_CONVERTED,
    OPP_SALES_REPORTING_TOTAL_BOOKING_AMOUNT__C_CONVERTED,
    OPP_SALES_REPORTING_BOOKED_SUBS_QTY__C
    -- ORDER BY ACT_ID, AMLH_RECYCLE_COUNTER__C
    
    UNION ALL

    -- Touchpoints before Opp Closed Won
    SELECT 
    -- ids
    AMLH_NAME, ACT_ID, AMLH_RECYCLE_COUNTER__C,
    AMLH_MUTUALLY_EXCLUSIVE_PRE_SUSPECT_DESIGNATION,
    AMLH_MUTUALLY_EXCLUSIVE_PRE_SUSPECT_DESIGNATION_DATE,
    AMLH_SUSPECT_DATE_STAMP__C_CAST,
	AMLH_EFFECTIVE_DATE_STAMP__C_CAST,
    'Opportunity Closed Won' AS MARKETING_TOUCHPOINT_BEFORE_MILESTONE,
    MARKETING_TOUCHPOINT_BEFORE_OPP_CLOSE AS MARKETING_TOUCHPOINT_BEFORE_ACT,
    'OPP_CLOSE_DATE' AS MARKETING_TOUCHPOINT_BEFORE_ACT_DATE_MILESTONE_FIELD, 
    OPP_CLOSE_DATE AS MARKETING_TOUCHPOINT_BEFORE_ACT_DATE_MILESTONE,
    MARKETING_TOUCHPOINT_DATE,
    -- attributes
    ACT_MARKET_SEGMENT__C,
	ACT_MARKET_SEGMENT__C_GROUP,
    ACT_MARKET__C,
    ACT_BUSINESS_UNIT_DIVISION__C,
	ACT_CAMPAIGN_TEXT__C,
	ACT_FIT_MODEL_TIER__C,
    INFLUENCE_CHANNEL,
    INFLUENCE_CHANNEL_TOPLEVEL,
    INFLUENCE_WEB_SOURCE,
    INFLUENCE_WEB_MEDIUM,
    INFLUENCE_CAMPAIGN_NAME,
	INFLUENCE_CAMPAIGN_MARKET_SEGMENT,
	INFLUENCE_CAMPAIGN_TYPE,
    INFLUENCE_UTM_CAMPAIGN,
    INFLUENCE_UTM_CONTENT,
    INFLUENCE_UTM_TERM,
    INFLUENCE_AD_NAME,
    INFLUENCE_CREATIVE_NAME,
    INFLUENCE_LANDING_PAGE,
    INFLUENCE_REFERRER,
    WEBVISIT_PAGE,
    WEBVISIT_REFERRER,
    OPP_ID,
    OPP_CREATED_DATE,
    OPP_STAGE_NAME_CATEGORY,
    OPP_STAGE_NAME,
    OPP_IS_CLOSED,
    OPP_IS_WON,
    OPP_CLOSE_DATE,
    OPP_GLOBAL_UNQUALIFIED_DATE_COHORT,
    OPP_STAGE_0_DATE,
    OPP_STAGE_1_DATE,
    -- Financial Metrics
    OPP_CURRENCY_ISO_CODE,
    OPP_CONVERSION_RATE,
    OPP_ACV3__C,
    OPP_TOTAL_BOOKING_AMOUNT2__C,
    OPP_TOTAL_BOOKING_AMOUNT2__C_CONVERTED,
    OPP_SUBS_QTY__C,
    OPP_BOOKED_SUBS_QTY3__C,
    OPP_FORECASTED_SUBS_QTY__C,
    OPP_BOOKEDFORECASTED_SUBS_QTY3__C,
    OPP_FORECASTED_ACV__C,
    OPP_BOOKEDFORECASTED_ACV3__C,
    OPP_BOOKEDFORECASTED_ACV_QTY3__C,
    OPP_FORECASTED_ARR__C,
    OPP_BOOKEDFORECASTED_ARR__C,
    OPP_SALES_REPORTING_ARR__C,
	--20250314
	OPP_REPORTING_ARR__C,
    OPP_SALES_REPORTING_ACV__C,
    OPP_SALES_REPORTING_TOTAL_BOOKING_AMOUNT__C,
    OPP_SALES_REPORTING_ACV__C_CONVERTED,
    OPP_SALES_REPORTING_TOTAL_BOOKING_AMOUNT__C_CONVERTED,
    OPP_SALES_REPORTING_BOOKED_SUBS_QTY__C,
	--20250314
	SUM(SPEND) AS SPEND,
    -- metrics
    SUM(INTERACTIONTYPE_SIXSENSE_PAIDMEDIA_IMPRESSIONS_COUNT_INFLUENCE_OPPCLS) AS INTERACTIONTYPE_SIXSENSE_PAIDMEDIA_IMPRESSIONS_COUNT_INFLUENCE_ACT,
    SUM(INTERACTIONTYPE_SIXSENSE_PAIDMEDIA_CLICKS_COUNT_INFLUENCE_OPPCLS) AS INTERACTIONTYPE_SIXSENSE_PAIDMEDIA_CLICKS_COUNT_INFLUENCE_ACT,
    SUM(INTERACTIONTYPE_SIXSENSE_WEBVISIT_TOTAL_INTERACTIONS_COUNT_INFLUENCE_OPPCLS) AS INTERACTIONTYPE_SIXSENSE_WEBVISIT_TOTAL_INTERACTIONS_COUNT_INFLUENCE_ACT,
    SUM(INTERACTIONTYPE_SIXSENSE_WEBVISIT_PAGELOAD_COUNT_INFLUENCE_OPPCLS) AS INTERACTIONTYPE_SIXSENSE_WEBVISIT_PAGELOAD_COUNT_INFLUENCE_ACT,
    SUM(INTERACTIONTYPE_SIXSENSE_WEBVISIT_PLAY_COUNT_INFLUENCE_OPPCLS) AS INTERACTIONTYPE_SIXSENSE_WEBVISIT_PLAY_COUNT_INFLUENCE_ACT,
    SUM(INTERACTIONTYPE_SIXSENSE_WEBVISIT_CLICK_COUNT_INFLUENCE_OPPCLS) AS INTERACTIONTYPE_SIXSENSE_WEBVISIT_CLICK_COUNT_INFLUENCE_ACT,
    SUM(INTERACTIONTYPE_SIXSENSE_WEBVISIT_SUBMIT_COUNT_INFLUENCE_OPPCLS) AS INTERACTIONTYPE_SIXSENSE_WEBVISIT_SUBMIT_COUNT_INFLUENCE_ACT,
    SUM(INTERACTIONTYPE_SIXSENSE_WEBVISIT_UNCLASSIFIED_COUNT_INFLUENCE_OPPCLS) AS INTERACTIONTYPE_SIXSENSE_WEBVISIT_UNCLASSIFIED_COUNT_INFLUENCE_ACT,
    SUM(INTERACTIONTYPE_BIZIBLE_TOUCHPOINT_WEBVISIT_COUNT_INFLUENCE_OPPCLS) AS INTERACTIONTYPE_BIZIBLE_TOUCHPOINT_WEBVISIT_COUNT_INFLUENCE_ACT,
    SUM(INTERACTIONTYPE_BIZIBLE_TOUCHPOINT_WEBCHAT_COUNT_INFLUENCE_OPPCLS) AS INTERACTIONTYPE_BIZIBLE_TOUCHPOINT_WEBCHAT_COUNT_INFLUENCE_ACT,
    SUM(INTERACTIONTYPE_BIZIBLE_TOUCHPOINT_WEBFORM_COUNT_INFLUENCE_OPPCLS) AS INTERACTIONTYPE_BIZIBLE_TOUCHPOINT_WEBFORM_COUNT_INFLUENCE_ACT,
    SUM(INTERACTIONTYPE_BIZIBLE_TOUCHPOINT_CRM_COUNT_INFLUENCE_OPPCLS) AS INTERACTIONTYPE_BIZIBLE_TOUCHPOINT_CRM_COUNT_INFLUENCE_ACT,
    SUM(INTERACTIONTYPE_BIZIBLE_TOUCHPOINT_CONNECTWITHDM_COUNT_INFLUENCE_OPPCLS) AS INTERACTIONTYPE_BIZIBLE_TOUCHPOINT_CONNECTWITHDM_COUNT_INFLUENCE_ACT,
    SUM(INTERACTIONTYPE_BIZIBLE_TOUCHPOINT_CALLSPOKEWITH_COUNT_INFLUENCE_OPPCLS) AS INTERACTIONTYPE_BIZIBLE_TOUCHPOINT_CALLSPOKEWITH_COUNT_INFLUENCE_ACT,
    SUM(INTERACTIONTYPE_BIZIBLE_TOUCHPOINT_CALLGATEKEEPER_COUNT_INFLUENCE_OPPCLS) AS INTERACTIONTYPE_BIZIBLE_TOUCHPOINT_CALLGATEKEEPER_COUNT_INFLUENCE_ACT,
    SUM(INTERACTIONTYPE_BIZIBLE_TOUCHPOINT_NOLEADTOUCHPOINTS_COUNT_INFLUENCE_OPPCLS) AS INTERACTIONTYPE_BIZIBLE_TOUCHPOINT_NOLEADTOUCHPOINTS_COUNT_INFLUENCE_ACT,
	--20250302
    SUM(INTERACTIONTYPE_BIZIBLE_TOUCHPOINT_MARKETO_COUNT_INFLUENCE_OPPCLS) AS INTERACTIONTYPE_BIZIBLE_TOUCHPOINT_MARKETO_COUNT_INFLUENCE_ACT,
	--20250314
    SUM(INTERACTIONTYPE_BIZIBLE_TOUCHPOINT_SEISMICENGAGEMENT_COUNT_INFLUENCE_OPPCLS) AS INTERACTIONTYPE_BIZIBLE_TOUCHPOINT_SEISMICENGAGEMENT_COUNT_INFLUENCE_ACT,
    SUM(INTERACTIONTYPE_BIZIBLE_TOUCHPOINT_CHANGESTATUS_COUNT_INFLUENCE_OPPCLS) AS INTERACTIONTYPE_BIZIBLE_TOUCHPOINT_CHANGESTATUS_COUNT_INFLUENCE_ACT,
    SUM(INTERACTIONTYPE_BIZIBLE_TOUCHPOINT_UNCLASSIFIED_COUNT_INFLUENCE_OPPCLS) AS INTERACTIONTYPE_BIZIBLE_TOUCHPOINT_UNCLASSIFIED_COUNT_INFLUENCE_ACT

    FROM ACT_MRKT_LIFECYCLE.AMLH_INFL_OPP

    WHERE AMLH_ACCOUNT_JOURNEY_PATH_LIFECYCLE_NONLINEAR_FLAG = 'Linear' 
    -- Period Filter based on paramater
    and (OPP_CLOSE_DATE BETWEEN '10-01-2023' and '12-31-2025')
    and OPP_STAGE_NAME_CATEGORY = 'Closed - Booked'
    GROUP BY 
    -- ids
    AMLH_NAME, ACT_ID, AMLH_RECYCLE_COUNTER__C,
    AMLH_MUTUALLY_EXCLUSIVE_PRE_SUSPECT_DESIGNATION,
    AMLH_MUTUALLY_EXCLUSIVE_PRE_SUSPECT_DESIGNATION_DATE ,
    AMLH_SUSPECT_DATE_STAMP__C_CAST,
	AMLH_EFFECTIVE_DATE_STAMP__C_CAST,
    MARKETING_TOUCHPOINT_DATE,
    MARKETING_TOUCHPOINT_BEFORE_OPP_CLOSE,

    -- attributes
    ACT_MARKET_SEGMENT__C,
	ACT_MARKET_SEGMENT__C_GROUP,
    ACT_MARKET__C,
    ACT_BUSINESS_UNIT_DIVISION__C,
	ACT_CAMPAIGN_TEXT__C,
	ACT_FIT_MODEL_TIER__C,
    INFLUENCE_CHANNEL,
    INFLUENCE_CHANNEL_TOPLEVEL,
    INFLUENCE_WEB_SOURCE,
    INFLUENCE_WEB_MEDIUM,
    INFLUENCE_CAMPAIGN_NAME,
	INFLUENCE_CAMPAIGN_MARKET_SEGMENT,
	INFLUENCE_CAMPAIGN_TYPE,
    INFLUENCE_UTM_CAMPAIGN,
    INFLUENCE_UTM_CONTENT,
    INFLUENCE_UTM_TERM,
    INFLUENCE_AD_NAME,
    INFLUENCE_CREATIVE_NAME,
    INFLUENCE_LANDING_PAGE,
    INFLUENCE_REFERRER,
    WEBVISIT_PAGE,
    WEBVISIT_REFERRER,
    OPP_ID,
    OPP_CREATED_DATE,
    OPP_STAGE_NAME_CATEGORY,
    OPP_STAGE_NAME,
    OPP_IS_CLOSED,
    OPP_IS_WON,
    OPP_CLOSE_DATE,
    OPP_GLOBAL_UNQUALIFIED_DATE_COHORT,
    OPP_STAGE_0_DATE,
    OPP_STAGE_1_DATE,
    -- Financial Metrics
    OPP_CURRENCY_ISO_CODE,
    OPP_CONVERSION_RATE,
    OPP_ACV3__C,
    OPP_TOTAL_BOOKING_AMOUNT2__C,
    OPP_TOTAL_BOOKING_AMOUNT2__C_CONVERTED,
    OPP_SUBS_QTY__C,
    OPP_BOOKED_SUBS_QTY3__C,
    OPP_FORECASTED_SUBS_QTY__C,
    OPP_BOOKEDFORECASTED_SUBS_QTY3__C,
    OPP_FORECASTED_ACV__C,
    OPP_BOOKEDFORECASTED_ACV3__C,
    OPP_BOOKEDFORECASTED_ACV_QTY3__C,
    OPP_FORECASTED_ARR__C,
    OPP_BOOKEDFORECASTED_ARR__C,
    OPP_SALES_REPORTING_ARR__C,
	--20250314
	OPP_REPORTING_ARR__C,
    OPP_SALES_REPORTING_ACV__C,
    OPP_SALES_REPORTING_TOTAL_BOOKING_AMOUNT__C,
    OPP_SALES_REPORTING_ACV__C_CONVERTED,
    OPP_SALES_REPORTING_TOTAL_BOOKING_AMOUNT__C_CONVERTED,
    OPP_SALES_REPORTING_BOOKED_SUBS_QTY__C
    -- ORDER BY ACT_ID, AMLH_RECYCLE_COUNTER__C
	--20250302
    UNION ALL

    -- Touchpoints before Opp Closed Won or Lost
    SELECT 
    -- ids
    AMLH_NAME, ACT_ID, AMLH_RECYCLE_COUNTER__C,
    AMLH_MUTUALLY_EXCLUSIVE_PRE_SUSPECT_DESIGNATION,
    AMLH_MUTUALLY_EXCLUSIVE_PRE_SUSPECT_DESIGNATION_DATE,
    AMLH_SUSPECT_DATE_STAMP__C_CAST,
	AMLH_EFFECTIVE_DATE_STAMP__C_CAST,
    'Opportunity Closed' AS MARKETING_TOUCHPOINT_BEFORE_MILESTONE,
    MARKETING_TOUCHPOINT_BEFORE_OPP_CLOSE AS MARKETING_TOUCHPOINT_BEFORE_ACT,
    'OPP_CLOSE_DATE' AS MARKETING_TOUCHPOINT_BEFORE_ACT_DATE_MILESTONE_FIELD, 
    OPP_CLOSE_DATE AS MARKETING_TOUCHPOINT_BEFORE_ACT_DATE_MILESTONE,
    MARKETING_TOUCHPOINT_DATE,
    -- attributes
    ACT_MARKET_SEGMENT__C,
	ACT_MARKET_SEGMENT__C_GROUP,
    ACT_MARKET__C,
    ACT_BUSINESS_UNIT_DIVISION__C,
	ACT_CAMPAIGN_TEXT__C,
	ACT_FIT_MODEL_TIER__C,
    INFLUENCE_CHANNEL,
    INFLUENCE_CHANNEL_TOPLEVEL,
    INFLUENCE_WEB_SOURCE,
    INFLUENCE_WEB_MEDIUM,
    INFLUENCE_CAMPAIGN_NAME,
	INFLUENCE_CAMPAIGN_MARKET_SEGMENT,
	INFLUENCE_CAMPAIGN_TYPE,
    INFLUENCE_UTM_CAMPAIGN,
    INFLUENCE_UTM_CONTENT,
    INFLUENCE_UTM_TERM,
    INFLUENCE_AD_NAME,
    INFLUENCE_CREATIVE_NAME,
    INFLUENCE_LANDING_PAGE,
    INFLUENCE_REFERRER,
    WEBVISIT_PAGE,
    WEBVISIT_REFERRER,
    OPP_ID,
    OPP_CREATED_DATE,
    OPP_STAGE_NAME_CATEGORY,
    OPP_STAGE_NAME,
    OPP_IS_CLOSED,
    OPP_IS_WON,
    OPP_CLOSE_DATE,
    OPP_GLOBAL_UNQUALIFIED_DATE_COHORT,
    OPP_STAGE_0_DATE,
    OPP_STAGE_1_DATE,
    -- Financial Metrics
    OPP_CURRENCY_ISO_CODE,
    OPP_CONVERSION_RATE,
    OPP_ACV3__C,
    OPP_TOTAL_BOOKING_AMOUNT2__C,
    OPP_TOTAL_BOOKING_AMOUNT2__C_CONVERTED,
    OPP_SUBS_QTY__C,
    OPP_BOOKED_SUBS_QTY3__C,
    OPP_FORECASTED_SUBS_QTY__C,
    OPP_BOOKEDFORECASTED_SUBS_QTY3__C,
    OPP_FORECASTED_ACV__C,
    OPP_BOOKEDFORECASTED_ACV3__C,
    OPP_BOOKEDFORECASTED_ACV_QTY3__C,
    OPP_FORECASTED_ARR__C,
    OPP_BOOKEDFORECASTED_ARR__C,
    OPP_SALES_REPORTING_ARR__C,
	--20250314
	OPP_REPORTING_ARR__C,
    OPP_SALES_REPORTING_ACV__C,
    OPP_SALES_REPORTING_TOTAL_BOOKING_AMOUNT__C,
    OPP_SALES_REPORTING_ACV__C_CONVERTED,
    OPP_SALES_REPORTING_TOTAL_BOOKING_AMOUNT__C_CONVERTED,
    OPP_SALES_REPORTING_BOOKED_SUBS_QTY__C,
	--20250314
	SUM(SPEND) AS SPEND,
    -- metrics
    SUM(INTERACTIONTYPE_SIXSENSE_PAIDMEDIA_IMPRESSIONS_COUNT_INFLUENCE_OPPCLS) AS INTERACTIONTYPE_SIXSENSE_PAIDMEDIA_IMPRESSIONS_COUNT_INFLUENCE_ACT,
    SUM(INTERACTIONTYPE_SIXSENSE_PAIDMEDIA_CLICKS_COUNT_INFLUENCE_OPPCLS) AS INTERACTIONTYPE_SIXSENSE_PAIDMEDIA_CLICKS_COUNT_INFLUENCE_ACT,
    SUM(INTERACTIONTYPE_SIXSENSE_WEBVISIT_TOTAL_INTERACTIONS_COUNT_INFLUENCE_OPPCLS) AS INTERACTIONTYPE_SIXSENSE_WEBVISIT_TOTAL_INTERACTIONS_COUNT_INFLUENCE_ACT,
    SUM(INTERACTIONTYPE_SIXSENSE_WEBVISIT_PAGELOAD_COUNT_INFLUENCE_OPPCLS) AS INTERACTIONTYPE_SIXSENSE_WEBVISIT_PAGELOAD_COUNT_INFLUENCE_ACT,
    SUM(INTERACTIONTYPE_SIXSENSE_WEBVISIT_PLAY_COUNT_INFLUENCE_OPPCLS) AS INTERACTIONTYPE_SIXSENSE_WEBVISIT_PLAY_COUNT_INFLUENCE_ACT,
    SUM(INTERACTIONTYPE_SIXSENSE_WEBVISIT_CLICK_COUNT_INFLUENCE_OPPCLS) AS INTERACTIONTYPE_SIXSENSE_WEBVISIT_CLICK_COUNT_INFLUENCE_ACT,
    SUM(INTERACTIONTYPE_SIXSENSE_WEBVISIT_SUBMIT_COUNT_INFLUENCE_OPPCLS) AS INTERACTIONTYPE_SIXSENSE_WEBVISIT_SUBMIT_COUNT_INFLUENCE_ACT,
    SUM(INTERACTIONTYPE_SIXSENSE_WEBVISIT_UNCLASSIFIED_COUNT_INFLUENCE_OPPCLS) AS INTERACTIONTYPE_SIXSENSE_WEBVISIT_UNCLASSIFIED_COUNT_INFLUENCE_ACT,
    SUM(INTERACTIONTYPE_BIZIBLE_TOUCHPOINT_WEBVISIT_COUNT_INFLUENCE_OPPCLS) AS INTERACTIONTYPE_BIZIBLE_TOUCHPOINT_WEBVISIT_COUNT_INFLUENCE_ACT,
    SUM(INTERACTIONTYPE_BIZIBLE_TOUCHPOINT_WEBCHAT_COUNT_INFLUENCE_OPPCLS) AS INTERACTIONTYPE_BIZIBLE_TOUCHPOINT_WEBCHAT_COUNT_INFLUENCE_ACT,
    SUM(INTERACTIONTYPE_BIZIBLE_TOUCHPOINT_WEBFORM_COUNT_INFLUENCE_OPPCLS) AS INTERACTIONTYPE_BIZIBLE_TOUCHPOINT_WEBFORM_COUNT_INFLUENCE_ACT,
    SUM(INTERACTIONTYPE_BIZIBLE_TOUCHPOINT_CRM_COUNT_INFLUENCE_OPPCLS) AS INTERACTIONTYPE_BIZIBLE_TOUCHPOINT_CRM_COUNT_INFLUENCE_ACT,
    SUM(INTERACTIONTYPE_BIZIBLE_TOUCHPOINT_CONNECTWITHDM_COUNT_INFLUENCE_OPPCLS) AS INTERACTIONTYPE_BIZIBLE_TOUCHPOINT_CONNECTWITHDM_COUNT_INFLUENCE_ACT,
    SUM(INTERACTIONTYPE_BIZIBLE_TOUCHPOINT_CALLSPOKEWITH_COUNT_INFLUENCE_OPPCLS) AS INTERACTIONTYPE_BIZIBLE_TOUCHPOINT_CALLSPOKEWITH_COUNT_INFLUENCE_ACT,
    SUM(INTERACTIONTYPE_BIZIBLE_TOUCHPOINT_CALLGATEKEEPER_COUNT_INFLUENCE_OPPCLS) AS INTERACTIONTYPE_BIZIBLE_TOUCHPOINT_CALLGATEKEEPER_COUNT_INFLUENCE_ACT,
    SUM(INTERACTIONTYPE_BIZIBLE_TOUCHPOINT_NOLEADTOUCHPOINTS_COUNT_INFLUENCE_OPPCLS) AS INTERACTIONTYPE_BIZIBLE_TOUCHPOINT_NOLEADTOUCHPOINTS_COUNT_INFLUENCE_ACT,
	--20250302
    SUM(INTERACTIONTYPE_BIZIBLE_TOUCHPOINT_MARKETO_COUNT_INFLUENCE_OPPCLS) AS INTERACTIONTYPE_BIZIBLE_TOUCHPOINT_MARKETO_COUNT_INFLUENCE_ACT,
	--20250314
    SUM(INTERACTIONTYPE_BIZIBLE_TOUCHPOINT_SEISMICENGAGEMENT_COUNT_INFLUENCE_OPPCLS) AS INTERACTIONTYPE_BIZIBLE_TOUCHPOINT_SEISMICENGAGEMENT_COUNT_INFLUENCE_ACT,
    SUM(INTERACTIONTYPE_BIZIBLE_TOUCHPOINT_CHANGESTATUS_COUNT_INFLUENCE_OPPCLS) AS INTERACTIONTYPE_BIZIBLE_TOUCHPOINT_CHANGESTATUS_COUNT_INFLUENCE_ACT,
    SUM(INTERACTIONTYPE_BIZIBLE_TOUCHPOINT_UNCLASSIFIED_COUNT_INFLUENCE_OPPCLS) AS INTERACTIONTYPE_BIZIBLE_TOUCHPOINT_UNCLASSIFIED_COUNT_INFLUENCE_ACT

    FROM ACT_MRKT_LIFECYCLE.AMLH_INFL_OPP

    WHERE AMLH_ACCOUNT_JOURNEY_PATH_LIFECYCLE_NONLINEAR_FLAG = 'Linear' 
    -- Period Filter based on paramater
    and (OPP_CLOSE_DATE BETWEEN '10-01-2023' and '12-31-2025')
    and OPP_STAGE_NAME_CATEGORY IN ('Closed - Booked', 'Closed - Not Booked')
    GROUP BY 
    -- ids
    AMLH_NAME, ACT_ID, AMLH_RECYCLE_COUNTER__C,
    AMLH_MUTUALLY_EXCLUSIVE_PRE_SUSPECT_DESIGNATION,
    AMLH_MUTUALLY_EXCLUSIVE_PRE_SUSPECT_DESIGNATION_DATE ,
    AMLH_SUSPECT_DATE_STAMP__C_CAST,
	AMLH_EFFECTIVE_DATE_STAMP__C_CAST,
    MARKETING_TOUCHPOINT_DATE,
    MARKETING_TOUCHPOINT_BEFORE_OPP_CLOSE,

    -- attributes
    ACT_MARKET_SEGMENT__C,
	ACT_MARKET_SEGMENT__C_GROUP,
    ACT_MARKET__C,
    ACT_BUSINESS_UNIT_DIVISION__C,
	ACT_CAMPAIGN_TEXT__C,
	ACT_FIT_MODEL_TIER__C,
    INFLUENCE_CHANNEL,
    INFLUENCE_CHANNEL_TOPLEVEL,
    INFLUENCE_WEB_SOURCE,
    INFLUENCE_WEB_MEDIUM,
    INFLUENCE_CAMPAIGN_NAME,
	INFLUENCE_CAMPAIGN_MARKET_SEGMENT,
	INFLUENCE_CAMPAIGN_TYPE,
    INFLUENCE_UTM_CAMPAIGN,
    INFLUENCE_UTM_CONTENT,
    INFLUENCE_UTM_TERM,
    INFLUENCE_AD_NAME,
    INFLUENCE_CREATIVE_NAME,
    INFLUENCE_LANDING_PAGE,
    INFLUENCE_REFERRER,
    WEBVISIT_PAGE,
    WEBVISIT_REFERRER,
    OPP_ID,
    OPP_CREATED_DATE,
    OPP_STAGE_NAME_CATEGORY,
    OPP_STAGE_NAME,
    OPP_IS_CLOSED,
    OPP_IS_WON,
    OPP_CLOSE_DATE,
    OPP_GLOBAL_UNQUALIFIED_DATE_COHORT,
    OPP_STAGE_0_DATE,
    OPP_STAGE_1_DATE,
    -- Financial Metrics
    OPP_CURRENCY_ISO_CODE,
    OPP_CONVERSION_RATE,
    OPP_ACV3__C,
    OPP_TOTAL_BOOKING_AMOUNT2__C,
    OPP_TOTAL_BOOKING_AMOUNT2__C_CONVERTED,
    OPP_SUBS_QTY__C,
    OPP_BOOKED_SUBS_QTY3__C,
    OPP_FORECASTED_SUBS_QTY__C,
    OPP_BOOKEDFORECASTED_SUBS_QTY3__C,
    OPP_FORECASTED_ACV__C,
    OPP_BOOKEDFORECASTED_ACV3__C,
    OPP_BOOKEDFORECASTED_ACV_QTY3__C,
    OPP_FORECASTED_ARR__C,
    OPP_BOOKEDFORECASTED_ARR__C,
    OPP_SALES_REPORTING_ARR__C,
	--20250314
	OPP_REPORTING_ARR__C,
    OPP_SALES_REPORTING_ACV__C,
    OPP_SALES_REPORTING_TOTAL_BOOKING_AMOUNT__C,
    OPP_SALES_REPORTING_ACV__C_CONVERTED,
    OPP_SALES_REPORTING_TOTAL_BOOKING_AMOUNT__C_CONVERTED,
    OPP_SALES_REPORTING_BOOKED_SUBS_QTY__C
    -- ORDER BY ACT_ID, AMLH_RECYCLE_COUNTER__C
UNION ALL

-- Effective All Accounts
    SELECT 
    -- ids
    AMLH_NAME, ACT_ID, AMLH_RECYCLE_COUNTER__C,
    AMLH_MUTUALLY_EXCLUSIVE_PRE_SUSPECT_DESIGNATION,
    AMLH_MUTUALLY_EXCLUSIVE_PRE_SUSPECT_DESIGNATION_DATE,
    AMLH_SUSPECT_DATE_STAMP__C_CAST,
	AMLH_EFFECTIVE_DATE_STAMP__C_CAST,
    'Effective' AS MARKETING_TOUCHPOINT_BEFORE_MILESTONE,
    MARKETING_TOUCHPOINT_BEFORE_ACT_EFFECTIVE AS MARKETING_TOUCHPOINT_BEFORE_ACT,
    'AMLH_EFFECTIVE_DATE_STAMP__C_CAST' AS MARKETING_TOUCHPOINT_BEFORE_ACT_DATE_MILESTONE_FIELD, 
    AMLH_EFFECTIVE_DATE_STAMP__C_CAST AS MARKETING_TOUCHPOINT_BEFORE_ACT_DATE_MILESTONE,
    MARKETING_TOUCHPOINT_DATE,
    -- attributes
    ACT_MARKET_SEGMENT__C,
	ACT_MARKET_SEGMENT__C_GROUP,
    ACT_MARKET__C,
    ACT_BUSINESS_UNIT_DIVISION__C,
	ACT_CAMPAIGN_TEXT__C,
	ACT_FIT_MODEL_TIER__C,
    INFLUENCE_CHANNEL,
    INFLUENCE_CHANNEL_TOPLEVEL,
    INFLUENCE_WEB_SOURCE,
    INFLUENCE_WEB_MEDIUM,
    INFLUENCE_CAMPAIGN_NAME,
	INFLUENCE_CAMPAIGN_MARKET_SEGMENT,
	INFLUENCE_CAMPAIGN_TYPE,
    INFLUENCE_UTM_CAMPAIGN,
    INFLUENCE_UTM_CONTENT,
    INFLUENCE_UTM_TERM,
    INFLUENCE_AD_NAME,
    INFLUENCE_CREATIVE_NAME,
    INFLUENCE_LANDING_PAGE,
    INFLUENCE_REFERRER,
    WEBVISIT_PAGE,
    WEBVISIT_REFERRER,
    OPP_ID,
    OPP_CREATED_DATE,
    OPP_STAGE_NAME_CATEGORY,
    OPP_STAGE_NAME,
    OPP_IS_CLOSED,
    OPP_IS_WON,
    OPP_CLOSE_DATE,
    OPP_GLOBAL_UNQUALIFIED_DATE_COHORT,
    OPP_STAGE_0_DATE,
    OPP_STAGE_1_DATE,
    -- Financial Metrics
    OPP_CURRENCY_ISO_CODE,
    OPP_CONVERSION_RATE,
    OPP_ACV3__C,
    OPP_TOTAL_BOOKING_AMOUNT2__C,
    OPP_TOTAL_BOOKING_AMOUNT2__C_CONVERTED,
    OPP_SUBS_QTY__C,
    OPP_BOOKED_SUBS_QTY3__C,
    OPP_FORECASTED_SUBS_QTY__C,
    OPP_BOOKEDFORECASTED_SUBS_QTY3__C,
    OPP_FORECASTED_ACV__C,
    OPP_BOOKEDFORECASTED_ACV3__C,
    OPP_BOOKEDFORECASTED_ACV_QTY3__C,
    OPP_FORECASTED_ARR__C,
    OPP_BOOKEDFORECASTED_ARR__C,
    OPP_SALES_REPORTING_ARR__C,
	--20250314
	OPP_REPORTING_ARR__C,
    OPP_SALES_REPORTING_ACV__C,
    OPP_SALES_REPORTING_TOTAL_BOOKING_AMOUNT__C,
    OPP_SALES_REPORTING_ACV__C_CONVERTED,
    OPP_SALES_REPORTING_TOTAL_BOOKING_AMOUNT__C_CONVERTED,
    OPP_SALES_REPORTING_BOOKED_SUBS_QTY__C,
	--20250314
	SUM(SPEND) AS SPEND,
    -- metrics
    SUM(INTERACTIONTYPE_SIXSENSE_PAIDMEDIA_IMPRESSIONS_COUNT_INFLUENCE_ACTEFFECTIVE) AS INTERACTIONTYPE_SIXSENSE_PAIDMEDIA_IMPRESSIONS_COUNT_INFLUENCE_ACT,
    SUM(INTERACTIONTYPE_SIXSENSE_PAIDMEDIA_CLICKS_COUNT_INFLUENCE_ACTEFFECTIVE) AS INTERACTIONTYPE_SIXSENSE_PAIDMEDIA_CLICKS_COUNT_INFLUENCE_ACT,
    SUM(INTERACTIONTYPE_SIXSENSE_WEBVISIT_TOTAL_INTERACTIONS_COUNT_INFLUENCE_ACTEFFECTIVE) AS INTERACTIONTYPE_SIXSENSE_WEBVISIT_TOTAL_INTERACTIONS_COUNT_INFLUENCE_ACT,
    SUM(INTERACTIONTYPE_SIXSENSE_WEBVISIT_PAGELOAD_COUNT_INFLUENCE_ACTEFFECTIVE) AS INTERACTIONTYPE_SIXSENSE_WEBVISIT_PAGELOAD_COUNT_INFLUENCE_ACT,
    SUM(INTERACTIONTYPE_SIXSENSE_WEBVISIT_PLAY_COUNT_INFLUENCE_ACTEFFECTIVE) AS INTERACTIONTYPE_SIXSENSE_WEBVISIT_PLAY_COUNT_INFLUENCE_ACT,
    SUM(INTERACTIONTYPE_SIXSENSE_WEBVISIT_CLICK_COUNT_INFLUENCE_ACTEFFECTIVE) AS INTERACTIONTYPE_SIXSENSE_WEBVISIT_CLICK_COUNT_INFLUENCE_ACT,
    SUM(INTERACTIONTYPE_SIXSENSE_WEBVISIT_SUBMIT_COUNT_INFLUENCE_ACTEFFECTIVE) AS INTERACTIONTYPE_SIXSENSE_WEBVISIT_SUBMIT_COUNT_INFLUENCE_ACT,
    SUM(INTERACTIONTYPE_SIXSENSE_WEBVISIT_UNCLASSIFIED_COUNT_INFLUENCE_ACTEFFECTIVE) AS INTERACTIONTYPE_SIXSENSE_WEBVISIT_UNCLASSIFIED_COUNT_INFLUENCE_ACT,
    SUM(INTERACTIONTYPE_BIZIBLE_TOUCHPOINT_WEBVISIT_COUNT_INFLUENCE_ACTEFFECTIVE) AS INTERACTIONTYPE_BIZIBLE_TOUCHPOINT_WEBVISIT_COUNT_INFLUENCE_ACT,
    SUM(INTERACTIONTYPE_BIZIBLE_TOUCHPOINT_WEBCHAT_COUNT_INFLUENCE_ACTEFFECTIVE) AS INTERACTIONTYPE_BIZIBLE_TOUCHPOINT_WEBCHAT_COUNT_INFLUENCE_ACT,
    SUM(INTERACTIONTYPE_BIZIBLE_TOUCHPOINT_WEBFORM_COUNT_INFLUENCE_ACTEFFECTIVE) AS INTERACTIONTYPE_BIZIBLE_TOUCHPOINT_WEBFORM_COUNT_INFLUENCE_ACT,
    SUM(INTERACTIONTYPE_BIZIBLE_TOUCHPOINT_CRM_COUNT_INFLUENCE_ACTEFFECTIVE) AS INTERACTIONTYPE_BIZIBLE_TOUCHPOINT_CRM_COUNT_INFLUENCE_ACT,
    SUM(INTERACTIONTYPE_BIZIBLE_TOUCHPOINT_CONNECTWITHDM_COUNT_INFLUENCE_ACTEFFECTIVE) AS INTERACTIONTYPE_BIZIBLE_TOUCHPOINT_CONNECTWITHDM_COUNT_INFLUENCE_ACT,
    SUM(INTERACTIONTYPE_BIZIBLE_TOUCHPOINT_CALLSPOKEWITH_COUNT_INFLUENCE_ACTEFFECTIVE) AS INTERACTIONTYPE_BIZIBLE_TOUCHPOINT_CALLSPOKEWITH_COUNT_INFLUENCE_ACT,
    SUM(INTERACTIONTYPE_BIZIBLE_TOUCHPOINT_CALLGATEKEEPER_COUNT_INFLUENCE_ACTEFFECTIVE) AS INTERACTIONTYPE_BIZIBLE_TOUCHPOINT_CALLGATEKEEPER_COUNT_INFLUENCE_ACT,
    SUM(INTERACTIONTYPE_BIZIBLE_TOUCHPOINT_NOLEADTOUCHPOINTS_COUNT_INFLUENCE_ACTEFFECTIVE) AS INTERACTIONTYPE_BIZIBLE_TOUCHPOINT_NOLEADTOUCHPOINTS_COUNT_INFLUENCE_ACT,
	--20250302
    SUM(INTERACTIONTYPE_BIZIBLE_TOUCHPOINT_MARKETO_COUNT_INFLUENCE_ACTEFFECTIVE) AS INTERACTIONTYPE_BIZIBLE_TOUCHPOINT_MARKETO_COUNT_INFLUENCE_ACT,
	--20250314
    SUM(INTERACTIONTYPE_BIZIBLE_TOUCHPOINT_SEISMICENGAGEMENT_COUNT_INFLUENCE_ACTEFFECTIVE) AS INTERACTIONTYPE_BIZIBLE_TOUCHPOINT_SEISMICENGAGEMENT_COUNT_INFLUENCE_ACT,
    SUM(INTERACTIONTYPE_BIZIBLE_TOUCHPOINT_CHANGESTATUS_COUNT_INFLUENCE_ACTEFFECTIVE) AS INTERACTIONTYPE_BIZIBLE_TOUCHPOINT_CHANGESTATUS_COUNT_INFLUENCE_ACT,
    SUM(INTERACTIONTYPE_BIZIBLE_TOUCHPOINT_UNCLASSIFIED_COUNT_INFLUENCE_ACTEFFECTIVE) AS INTERACTIONTYPE_BIZIBLE_TOUCHPOINT_UNCLASSIFIED_COUNT_INFLUENCE_ACT

    FROM ACT_MRKT_LIFECYCLE.AMLH_INFL_OPP

    WHERE AMLH_ACCOUNT_JOURNEY_PATH_LIFECYCLE_NONLINEAR_FLAG = 'Linear' 
    -- Period Filter based on paramater
    and (AMLH_EFFECTIVE_DATE_STAMP__C_CAST BETWEEN '01-01-2023' and '01-01-2222')
    
    GROUP BY 
    -- ids
    AMLH_NAME, ACT_ID, AMLH_RECYCLE_COUNTER__C,
    AMLH_MUTUALLY_EXCLUSIVE_PRE_SUSPECT_DESIGNATION,
    AMLH_MUTUALLY_EXCLUSIVE_PRE_SUSPECT_DESIGNATION_DATE ,
    AMLH_SUSPECT_DATE_STAMP__C_CAST,
	AMLH_EFFECTIVE_DATE_STAMP__C_CAST,
    MARKETING_TOUCHPOINT_DATE,
    MARKETING_TOUCHPOINT_BEFORE_ACT_EFFECTIVE,
	
    -- attributes
    ACT_MARKET_SEGMENT__C,
	ACT_MARKET_SEGMENT__C_GROUP,
    ACT_MARKET__C,
    ACT_BUSINESS_UNIT_DIVISION__C,
	ACT_CAMPAIGN_TEXT__C,
	ACT_FIT_MODEL_TIER__C,
    INFLUENCE_CHANNEL,
    INFLUENCE_CHANNEL_TOPLEVEL,
    INFLUENCE_WEB_SOURCE,
    INFLUENCE_WEB_MEDIUM,
    INFLUENCE_CAMPAIGN_NAME,
	INFLUENCE_CAMPAIGN_MARKET_SEGMENT,
	INFLUENCE_CAMPAIGN_TYPE,
    INFLUENCE_UTM_CAMPAIGN,
    INFLUENCE_UTM_CONTENT,
    INFLUENCE_UTM_TERM,
    INFLUENCE_AD_NAME,
    INFLUENCE_CREATIVE_NAME,
    INFLUENCE_LANDING_PAGE,
    INFLUENCE_REFERRER,
    WEBVISIT_PAGE,
    WEBVISIT_REFERRER,
    OPP_ID,
    OPP_CREATED_DATE,
    OPP_STAGE_NAME_CATEGORY,
    OPP_STAGE_NAME,
    OPP_IS_CLOSED,
    OPP_IS_WON,
    OPP_CLOSE_DATE,
    OPP_GLOBAL_UNQUALIFIED_DATE_COHORT,
    OPP_STAGE_0_DATE,
    OPP_STAGE_1_DATE,
    -- Financial Metrics
    OPP_CURRENCY_ISO_CODE,
    OPP_CONVERSION_RATE,
    OPP_ACV3__C,
    OPP_TOTAL_BOOKING_AMOUNT2__C,
    OPP_TOTAL_BOOKING_AMOUNT2__C_CONVERTED,
    OPP_SUBS_QTY__C,
    OPP_BOOKED_SUBS_QTY3__C,
    OPP_FORECASTED_SUBS_QTY__C,
    OPP_BOOKEDFORECASTED_SUBS_QTY3__C,
    OPP_FORECASTED_ACV__C,
    OPP_BOOKEDFORECASTED_ACV3__C,OPP_BOOKEDFORECASTED_ACV_QTY3__C,
    OPP_FORECASTED_ARR__C,
    OPP_BOOKEDFORECASTED_ARR__C,
    OPP_SALES_REPORTING_ARR__C,
	--20250314
	OPP_REPORTING_ARR__C,
    OPP_SALES_REPORTING_ACV__C,
    OPP_SALES_REPORTING_TOTAL_BOOKING_AMOUNT__C,
    OPP_SALES_REPORTING_ACV__C_CONVERTED,
    OPP_SALES_REPORTING_TOTAL_BOOKING_AMOUNT__C_CONVERTED,
    OPP_SALES_REPORTING_BOOKED_SUBS_QTY__C
    -- ORDER BY ACT_ID, AMLH_RECYCLE_COUNTER__C
    ) as x
    ) as y
    ; 
RAISE INFO 'step 5b complete';



    -- Step 05c: Account Marketing Lifecycle History with Opp and Influence Data Aggregated with Granular Level (Marketing Touchpoint date)
       
	DROP TABLE IF EXISTS ACT_MRKT_LIFECYCLE.amlh_opp_infl_milestones_agg_granular CASCADE;
	CREATE TABLE ACT_MRKT_LIFECYCLE.amlh_opp_infl_milestones_agg_granular as

    SELECT y.*
FROM
(
SELECT
pvt.*,
CASE WHEN TOUCHPOINT_NEVER = 1 THEN 1 ELSE 0 END AS TOUCHPOINT_NEVER_ONLY,
CASE WHEN TOUCHPOINT_BEFORE = 1 AND TOUCHPOINT_AFTER = 0 THEN 1 ELSE 0 END AS TOUCHPOINT_BEFORE_ONLY,
CASE WHEN TOUCHPOINT_BEFORE = 0 AND TOUCHPOINT_AFTER = 1 THEN 1 ELSE 0 END AS TOUCHPOINT_AFTER_ONLY,
CASE WHEN TOUCHPOINT_BEFORE = 1 AND TOUCHPOINT_AFTER = 1 THEN 1 ELSE 0 END AS TOUCHPOINT_BEFORE_AND_AFTER,
1 AS TOUCHPOINT_TOTAL
FROM
(
SELECT
  amlh_opp_influence_milestones.AMLH_NAME,
  amlh_opp_influence_milestones.ACT_ID,
  amlh_opp_influence_milestones.AMLH_RECYCLE_COUNTER__C,
  amlh_opp_influence_milestones.AMLH_MUTUALLY_EXCLUSIVE_PRE_SUSPECT_DESIGNATION,
  amlh_opp_influence_milestones.AMLH_MUTUALLY_EXCLUSIVE_PRE_SUSPECT_DESIGNATION_DATE,
  amlh_opp_influence_milestones.AMLH_SUSPECT_DATE_STAMP__C_CAST,
  amlh_opp_influence_milestones.AMLH_EFFECTIVE_DATE_STAMP__C_CAST,
  amlh_opp_influence_milestones.MARKETING_TOUCHPOINT_DATE,
  amlh_opp_influence_milestones.MARKETING_TOUCHPOINT_DATE_EOM,
  amlh_opp_influence_milestones.MARKETING_TOUCHPOINT_DATE_EOQ,
  amlh_opp_influence_milestones.MARKETING_TOUCHPOINT_DATE_EOY,
  amlh_opp_influence_milestones.MARKETING_TOUCHPOINT_BEFORE_MILESTONE,
  amlh_opp_influence_milestones.MARKETING_TOUCHPOINT_BEFORE_ACT_DATE_MILESTONE,
  amlh_opp_influence_milestones.MARKETING_TOUCHPOINT_BEFORE_ACT_DATE_MILESTONE_EOM,
  amlh_opp_influence_milestones.MARKETING_TOUCHPOINT_BEFORE_ACT_DATE_MILESTONE_EOQ,
  amlh_opp_influence_milestones.MARKETING_TOUCHPOINT_BEFORE_ACT_DATE_MILESTONE_YEAR,
  amlh_opp_influence_milestones.ACT_MARKET_SEGMENT__C,
  amlh_opp_influence_milestones.ACT_MARKET_SEGMENT__C_GROUP,
  amlh_opp_influence_milestones.ACT_MARKET__C,
  amlh_opp_influence_milestones.ACT_BUSINESS_UNIT_DIVISION__C,
  amlh_opp_influence_milestones.ACT_CAMPAIGN_TEXT__C,
  amlh_opp_influence_milestones.ACT_FIT_MODEL_TIER__C,
  amlh_opp_influence_milestones.INFLUENCE_CHANNEL,
  amlh_opp_influence_milestones.INFLUENCE_CAMPAIGN_NAME,
  amlh_opp_influence_milestones.INFLUENCE_CAMPAIGN_MARKET_SEGMENT,
  amlh_opp_influence_milestones.INFLUENCE_CAMPAIGN_TYPE,
  amlh_opp_influence_milestones.INFLUENCE_UTM_CAMPAIGN,
  amlh_opp_influence_milestones.INFLUENCE_UTM_CONTENT,
  amlh_opp_influence_milestones.INFLUENCE_UTM_TERM,
  amlh_opp_influence_milestones.INFLUENCE_AD_NAME,                    
  amlh_opp_influence_milestones.OPP_ID,     
  amlh_opp_influence_milestones.OPP_CREATED_DATE,
  amlh_opp_influence_milestones.OPP_STAGE_NAME_CATEGORY,
  amlh_opp_influence_milestones.OPP_STAGE_NAME,
  amlh_opp_influence_milestones.OPP_IS_CLOSED,
  amlh_opp_influence_milestones.OPP_IS_WON,
  amlh_opp_influence_milestones.OPP_CLOSE_DATE,
  amlh_opp_influence_milestones.OPP_GLOBAL_UNQUALIFIED_DATE_COHORT,
  amlh_opp_influence_milestones.OPP_STAGE_0_DATE,
  amlh_opp_influence_milestones.OPP_STAGE_1_DATE,
  amlh_opp_influence_milestones.OPP_CURRENCY_ISO_CODE,
  amlh_opp_influence_milestones.OPP_CONVERSION_RATE,
  amlh_opp_influence_milestones.OPP_ACV3__C,
  amlh_opp_influence_milestones.OPP_TOTAL_BOOKING_AMOUNT2__C,
  amlh_opp_influence_milestones.OPP_TOTAL_BOOKING_AMOUNT2__C_CONVERTED,
  amlh_opp_influence_milestones.OPP_SUBS_QTY__C,
  amlh_opp_influence_milestones.OPP_BOOKED_SUBS_QTY3__C,
  amlh_opp_influence_milestones.OPP_FORECASTED_SUBS_QTY__C,
  amlh_opp_influence_milestones.OPP_BOOKEDFORECASTED_SUBS_QTY3__C,
  amlh_opp_influence_milestones.OPP_FORECASTED_ACV__C,
  amlh_opp_influence_milestones.OPP_BOOKEDFORECASTED_ACV3__C,
  amlh_opp_influence_milestones.OPP_BOOKEDFORECASTED_ACV_QTY3__C,
  amlh_opp_influence_milestones.OPP_FORECASTED_ARR__C,
  amlh_opp_influence_milestones.OPP_BOOKEDFORECASTED_ARR__C,
  amlh_opp_influence_milestones.OPP_SALES_REPORTING_ARR__C,
  --20250314
  amlh_opp_influence_milestones.OPP_REPORTING_ARR__C,
  amlh_opp_influence_milestones.OPP_SALES_REPORTING_ACV__C,
  amlh_opp_influence_milestones.OPP_SALES_REPORTING_TOTAL_BOOKING_AMOUNT__C,
  amlh_opp_influence_milestones.OPP_SALES_REPORTING_ACV__C_CONVERTED,
  amlh_opp_influence_milestones.OPP_SALES_REPORTING_TOTAL_BOOKING_AMOUNT__C_CONVERTED,
  amlh_opp_influence_milestones.OPP_SALES_REPORTING_BOOKED_SUBS_QTY__C,
  COUNT(
    DISTINCT CASE
      WHEN amlh_opp_influence_milestones.MARKETING_TOUCHPOINT_DATE IS NULL THEN AMLH_NAME
    END
  ) AS TOUCHPOINT_NEVER,  
    COUNT(
    DISTINCT CASE
      WHEN amlh_opp_influence_milestones.MARKETING_TOUCHPOINT_BEFORE_ACT = 1 THEN AMLH_NAME
    END
  ) AS TOUCHPOINT_BEFORE,
  COUNT(
    DISTINCT CASE
      WHEN amlh_opp_influence_milestones.MARKETING_TOUCHPOINT_DATE IS NOT NULL AND amlh_opp_influence_milestones.MARKETING_TOUCHPOINT_BEFORE_ACT = 0 THEN AMLH_NAME
    END
  ) AS TOUCHPOINT_AFTER,
    COUNT(
    DISTINCT CASE
      WHEN amlh_opp_influence_milestones.INTERACTIONTYPE_INTERACTION_IMPRESSION_BEFORE_MILESTONE_FLAG = 1 THEN AMLH_NAME
    END
  ) AS INTERACTIONTYPE_INTERACTION_IMPRESSION_BEFORE_MILESTONE_FLAG,
    COUNT(
    DISTINCT CASE
      WHEN amlh_opp_influence_milestones.INTERACTIONTYPE_INTERACTION_ONLY_BEFORE_MILESTONE_FLAG = 1 THEN AMLH_NAME
    END
  ) AS INTERACTIONTYPE_INTERACTION_ONLY_BEFORE_MILESTONE_FLAG
FROM
  ACT_MRKT_LIFECYCLE.amlh_opp_infl_milestones AS amlh_opp_influence_milestones
-- WHERE amlh_opp_influence_milestones.MARKETING_TOUCHPOINT_BEFORE_MILESTONE = 'MQA' AND INFLUENCE_CAMPAIGN_NAME = 'OA-22-09-Display-6Sense-Trucking-Local-MEA-Fleet-Safety-without-SF'
GROUP BY
  1,
  2,3,4,5,6,
  7,
  8,
  9,10,11,12,13,14,15,16,17,18,19,20,21,22,23,24,25,26,27,28,29,30,31,32,33,34,35,36,37, 38, 39, 40,41 ,42, 43, 44, 45, 46,47,48,49,50,51,52,53,54,55,56,57,58,59,60,61
ORDER BY
  1,
  2,3,4,5,6,
  7,
  8,
  9,10,11,12,13,14,15,16,17,18,19,20,21,22,23,24,25,26,27,28,29,30,31,32,33,34,35,36,37,38, 39 , 40, 41,42,43,44, 45, 46, 47,48,49,50,51,52,53,54,55,56,57,58,59,60,61
) AS pvt
) as y
  ;
RAISE INFO 'step 5c complete';

    -- Step 05d: Account Marketing Lifecycle History with Opp and Influence Data Aggregated (Excluding Marketing Touchpoint Date)
       

--    DROP TABLE IF EXISTS ACT_MRKT_LIFECYCLE.amlh_opp_infl_milestones_agg;
--    CREATE TABLE ACT_MRKT_LIFECYCLE.amlh_opp_infl_milestones_agg AS 


     DROP TABLE IF EXISTS ACT_MRKT_LIFECYCLE.amlh_opp_infl_milestones_agg CASCADE;    
     CREATE TABLE ACT_MRKT_LIFECYCLE.amlh_opp_infl_milestones_agg as

    SELECT y.*
FROM
(
SELECT
pvt.*,
CASE WHEN TOUCHPOINT_NEVER = 1 THEN 1 ELSE 0 END AS TOUCHPOINT_NEVER_ONLY,
CASE WHEN TOUCHPOINT_BEFORE = 1 AND TOUCHPOINT_AFTER = 0 THEN 1 ELSE 0 END AS TOUCHPOINT_BEFORE_ONLY,
CASE WHEN TOUCHPOINT_BEFORE = 0 AND TOUCHPOINT_AFTER = 1 THEN 1 ELSE 0 END AS TOUCHPOINT_AFTER_ONLY,
CASE WHEN TOUCHPOINT_BEFORE = 1 AND TOUCHPOINT_AFTER = 1 THEN 1 ELSE 0 END AS TOUCHPOINT_BEFORE_AND_AFTER,
1 AS TOUCHPOINT_TOTAL
FROM
(
SELECT
  amlh_opp_influence_milestones.AMLH_NAME,
  amlh_opp_influence_milestones.ACT_ID,
  amlh_opp_influence_milestones.AMLH_RECYCLE_COUNTER__C,
  amlh_opp_influence_milestones.AMLH_MUTUALLY_EXCLUSIVE_PRE_SUSPECT_DESIGNATION,
  amlh_opp_influence_milestones.AMLH_MUTUALLY_EXCLUSIVE_PRE_SUSPECT_DESIGNATION_DATE,
  amlh_opp_influence_milestones.AMLH_SUSPECT_DATE_STAMP__C_CAST,
  amlh_opp_influence_milestones.AMLH_EFFECTIVE_DATE_STAMP__C_CAST,
--  amlh_opp_influence_milestones.MARKETING_TOUCHPOINT_DATE,
--  amlh_opp_influence_milestones.MARKETING_TOUCHPOINT_DATE_EOM,
--  amlh_opp_influence_milestones.MARKETING_TOUCHPOINT_DATE_EOQ,
--  amlh_opp_influence_milestones.MARKETING_TOUCHPOINT_DATE_EOY,
  amlh_opp_influence_milestones.MARKETING_TOUCHPOINT_BEFORE_MILESTONE,
  amlh_opp_influence_milestones.MARKETING_TOUCHPOINT_BEFORE_ACT_DATE_MILESTONE,
  amlh_opp_influence_milestones.MARKETING_TOUCHPOINT_BEFORE_ACT_DATE_MILESTONE_EOM,
  amlh_opp_influence_milestones.MARKETING_TOUCHPOINT_BEFORE_ACT_DATE_MILESTONE_EOQ,
  amlh_opp_influence_milestones.MARKETING_TOUCHPOINT_BEFORE_ACT_DATE_MILESTONE_YEAR,
  amlh_opp_influence_milestones.ACT_MARKET_SEGMENT__C,
  amlh_opp_influence_milestones.ACT_MARKET_SEGMENT__C_GROUP,
  amlh_opp_influence_milestones.ACT_MARKET__C,
  amlh_opp_influence_milestones.ACT_BUSINESS_UNIT_DIVISION__C,
  amlh_opp_influence_milestones.ACT_CAMPAIGN_TEXT__C,
  amlh_opp_influence_milestones.ACT_FIT_MODEL_TIER__C,
  amlh_opp_influence_milestones.INFLUENCE_CHANNEL,
  amlh_opp_influence_milestones.INFLUENCE_CAMPAIGN_NAME,
  amlh_opp_influence_milestones.INFLUENCE_CAMPAIGN_MARKET_SEGMENT,
  amlh_opp_influence_milestones.INFLUENCE_CAMPAIGN_TYPE,
  amlh_opp_influence_milestones.INFLUENCE_UTM_CAMPAIGN,
  amlh_opp_influence_milestones.INFLUENCE_UTM_CONTENT,
  amlh_opp_influence_milestones.INFLUENCE_UTM_TERM,
  amlh_opp_influence_milestones.INFLUENCE_AD_NAME,                    
  amlh_opp_influence_milestones.OPP_ID,     
  amlh_opp_influence_milestones.OPP_CREATED_DATE,
  amlh_opp_influence_milestones.OPP_STAGE_NAME_CATEGORY,
  amlh_opp_influence_milestones.OPP_STAGE_NAME,
  amlh_opp_influence_milestones.OPP_IS_CLOSED,
  amlh_opp_influence_milestones.OPP_IS_WON,
  amlh_opp_influence_milestones.OPP_CLOSE_DATE,
  amlh_opp_influence_milestones.OPP_GLOBAL_UNQUALIFIED_DATE_COHORT,
  amlh_opp_influence_milestones.OPP_STAGE_0_DATE,
  amlh_opp_influence_milestones.OPP_STAGE_1_DATE,
  amlh_opp_influence_milestones.OPP_CURRENCY_ISO_CODE,
  amlh_opp_influence_milestones.OPP_CONVERSION_RATE,
  amlh_opp_influence_milestones.OPP_ACV3__C,
  amlh_opp_influence_milestones.OPP_TOTAL_BOOKING_AMOUNT2__C,
  amlh_opp_influence_milestones.OPP_TOTAL_BOOKING_AMOUNT2__C_CONVERTED,
  amlh_opp_influence_milestones.OPP_SUBS_QTY__C,
  amlh_opp_influence_milestones.OPP_BOOKED_SUBS_QTY3__C,
  amlh_opp_influence_milestones.OPP_FORECASTED_SUBS_QTY__C,
  amlh_opp_influence_milestones.OPP_BOOKEDFORECASTED_SUBS_QTY3__C,
  amlh_opp_influence_milestones.OPP_FORECASTED_ACV__C,
  amlh_opp_influence_milestones.OPP_BOOKEDFORECASTED_ACV3__C,
  amlh_opp_influence_milestones.OPP_BOOKEDFORECASTED_ACV_QTY3__C,
  amlh_opp_influence_milestones.OPP_FORECASTED_ARR__C,
  amlh_opp_influence_milestones.OPP_BOOKEDFORECASTED_ARR__C,
  amlh_opp_influence_milestones.OPP_SALES_REPORTING_ARR__C,
  --20250314
  amlh_opp_influence_milestones.OPP_REPORTING_ARR__C,
  amlh_opp_influence_milestones.OPP_SALES_REPORTING_ACV__C,
  amlh_opp_influence_milestones.OPP_SALES_REPORTING_TOTAL_BOOKING_AMOUNT__C,
  amlh_opp_influence_milestones.OPP_SALES_REPORTING_ACV__C_CONVERTED,
  amlh_opp_influence_milestones.OPP_SALES_REPORTING_TOTAL_BOOKING_AMOUNT__C_CONVERTED,
  amlh_opp_influence_milestones.OPP_SALES_REPORTING_BOOKED_SUBS_QTY__C,
  COUNT(
    DISTINCT CASE
      WHEN amlh_opp_influence_milestones.MARKETING_TOUCHPOINT_DATE IS NULL THEN AMLH_NAME
    END
  ) AS TOUCHPOINT_NEVER,  
    COUNT(
    DISTINCT CASE
      WHEN amlh_opp_influence_milestones.MARKETING_TOUCHPOINT_BEFORE_ACT = 1 THEN AMLH_NAME
    END
  ) AS TOUCHPOINT_BEFORE,
  COUNT(
    DISTINCT CASE
      WHEN amlh_opp_influence_milestones.MARKETING_TOUCHPOINT_DATE IS NOT NULL AND amlh_opp_influence_milestones.MARKETING_TOUCHPOINT_BEFORE_ACT = 0 THEN AMLH_NAME
    END
  ) AS TOUCHPOINT_AFTER,
    COUNT(
    DISTINCT CASE
      WHEN amlh_opp_influence_milestones.INTERACTIONTYPE_INTERACTION_IMPRESSION_BEFORE_MILESTONE_FLAG = 1 THEN AMLH_NAME
    END
  ) AS INTERACTIONTYPE_INTERACTION_IMPRESSION_BEFORE_MILESTONE_FLAG,
    COUNT(
    DISTINCT CASE
      WHEN amlh_opp_influence_milestones.INTERACTIONTYPE_INTERACTION_ONLY_BEFORE_MILESTONE_FLAG = 1 THEN AMLH_NAME
    END
  ) AS INTERACTIONTYPE_INTERACTION_ONLY_BEFORE_MILESTONE_FLAG
FROM
  ACT_MRKT_LIFECYCLE.amlh_opp_infl_milestones AS amlh_opp_influence_milestones
-- WHERE amlh_opp_influence_milestones.MARKETING_TOUCHPOINT_BEFORE_MILESTONE = 'MQA' AND INFLUENCE_CAMPAIGN_NAME = 'OA-22-09-Display-6Sense-Trucking-Local-MEA-Fleet-Safety-without-SF'
GROUP BY
  1,
  2,3,4,5,6,
  7,
  8,
  9,10,11,12,13,14,15,16,17,18,19,20,21,22,23,24,25,26,27,28,29,30,31,32,33,34,35,36,37, 38, 39, 40,41 ,42, 43, 44, 45, 46,47,48,49,50,51,52,53,54,55,56,57
ORDER BY
  1,
  2,3,4,5,6,
  7,
  8,
  9,10,11,12,13,14,15,16,17,18,19,20,21,22,23,24,25,26,27,28,29,30,31,32,33,34,35,36,37,38, 39 , 40, 41,42,43,44, 45, 46, 47,48,49,50,51,52,53,54,55,56,57
) AS pvt
) as y
  ;
RAISE INFO 'step 5d complete';

--- 06: Mixed Media Marketing Spend

--- MMM -01. Opportunity Metrics CTE
     DROP TABLE IF EXISTS ACT_MRKT_LIFECYCLE.mmm_opportunity_metrics CASCADE;    
     CREATE TABLE ACT_MRKT_LIFECYCLE.mmm_opportunity_metrics as

WITH oppid 
AS (
    SELECT 
        amlhopps.OPP_ID,
        amlhopps.OPP_CREATED_DATE,    
        amlhopps.OPP_STAGE_NAME_CATEGORY,
        amlhopps.OPP_IS_WON,
        COALESCE(oppmilestones.INTERACTION_ONLY_BEFORE_CREATED_FLAG,0) AS INTERACTION_ONLY_BEFORE_CREATED_FLAG,
        COALESCE(oppmilestones.INTERACTION_ONLY_BEFORE_STAGE_ONE_FLAG,0) AS INTERACTION_ONLY_BEFORE_STAGE_ONE_FLAG,
        COALESCE(oppmilestones.INTERACTION_ONLY_BEFORE_CLOSED_WON_FLAG ,0) AS INTERACTION_ONLY_BEFORE_CLOSED_WON_FLAG,
        amlhopps.OPP_STAGE_0_DATE,
        amlhopps.OPP_STAGE_1_DATE,
        amlhopps.OPP_CLOSE_DATE,

        amlhopps.ACT_MARKET_SEGMENT__C,
        amlhopps.ACT_MARKET_SEGMENT__C_GROUP,		
        amlhopps.ACT_MARKET__C,
        amlhopps.OPP_COUNT,
        amlhopps.OPP_WON_COUNT,
        amlhopps.OPP_CURRENCY_ISO_CODE,
        amlhopps.OPP_SALES_REPORTING_ACV__C_CONVERTED,
        amlhopps.OPP_FORECASTED_ACV__C,
        amlhopps.OPP_SALES_REPORTING_BOOKED_SUBS_QTY__C,
        amlhopps.OPP_FORECASTED_SUBS_QTY__C,
        amlhopps.OPP_SALES_REPORTING_ARR__C,
        amlhopps.OPP_FORECASTED_ARR__C,
        amlhopps.OPP_BOOKEDFORECASTED_SUBS_QTY3__C,
        amlhopps.OPP_BOOKEDFORECASTED_ACV_QTY3__C,
        amlhopps.OPP_BOOKEDFORECASTED_ARR__C
    FROM
    (
        SELECT DISTINCT 
            OPP_ID,
            OPP_CREATED_DATE,
            OPP_STAGE_NAME_CATEGORY,
            OPP_IS_WON,
            OPP_STAGE_0_DATE,
            OPP_STAGE_1_DATE,
            OPP_CLOSE_DATE,
            ACT_MARKET_SEGMENT__C,
            ACT_MARKET_SEGMENT__C_GROUP,
            ACT_MARKET__C,
            1 AS OPP_COUNT,
            CASE WHEN OPP_IS_WON = TRUE THEN 1 ELSE 0 END AS OPP_WON_COUNT,
            OPP_CURRENCY_ISO_CODE,
            OPP_SALES_REPORTING_ACV__C_CONVERTED,
            OPP_FORECASTED_ACV__C,
            OPP_SALES_REPORTING_BOOKED_SUBS_QTY__C,
            OPP_FORECASTED_SUBS_QTY__C,
            OPP_SALES_REPORTING_ARR__C,
            OPP_FORECASTED_ARR__C,
            OPP_BOOKEDFORECASTED_SUBS_QTY3__C,
            OPP_BOOKEDFORECASTED_ACV_QTY3__C,
            OPP_BOOKEDFORECASTED_ARR__C
        FROM act_mrkt_lifecycle.amlh_opps
        WHERE amlh_account_journey_path_lifecycle_nonlinear_flag = 'Linear'
        AND OPP_ID IS NOT NULL
    ) AS amlhopps
    LEFT JOIN
    (
        SELECT 
            OPP_ID,
            COALESCE(MAX(CASE WHEN MARKETING_TOUCHPOINT_BEFORE_MILESTONE = 'Opportunity Created' 
                    THEN interactiontype_interaction_only_before_milestone_flag END), 0) 
                AS interaction_only_before_created_flag,
            COALESCE(MAX(CASE WHEN MARKETING_TOUCHPOINT_BEFORE_MILESTONE = 'Opportunity Stage One' 
                    THEN interactiontype_interaction_only_before_milestone_flag END), 0)
                AS interaction_only_before_stage_one_flag,
            COALESCE(MAX(CASE WHEN MARKETING_TOUCHPOINT_BEFORE_MILESTONE = 'Opportunity Closed Won' 
                    THEN interactiontype_interaction_only_before_milestone_flag END), 0) 
                AS interaction_only_before_closed_won_flag
        FROM ACT_MRKT_LIFECYCLE.amlh_opp_infl_milestones_agg
        WHERE OPP_ID IS NOT NULL 
        AND MARKETING_TOUCHPOINT_BEFORE_MILESTONE IN 
        ('Opportunity Created', 'Opportunity Stage One', 'Opportunity Closed Won')
        GROUP BY OPP_ID
    ) AS oppmilestones
    ON amlhopps.OPP_ID = oppmilestones.OPP_ID
)
,
--------- Opportunity Created
oppcreated 
AS (
	SELECT 
	'opp_created_date' AS date_field,
	opp_created_date AS date,
	ACT_MARKET_SEGMENT__C_GROUP,
	ACT_MARKET_SEGMENT__C,
    	ACT_MARKET__C,
	'Opportunity Volume' AS metric_group,
	'Non-Sales Outcome Metric' AS metric_outcome,
	'Created Opp Volume' AS metric,
	SUM(OPP_COUNT) AS value,
	SUM(INTERACTION_ONLY_BEFORE_CREATED_FLAG) AS interaction_before_milestone,
	SUM(OPP_BOOKEDFORECASTED_SUBS_QTY3__C) AS bookedforecasted_subs,
--	SUM(OPP_BOOKEDFORECASTED_ACV_QTY3__C) AS bookedforecasted_acv,
	SUM(OPP_BOOKEDFORECASTED_ARR__C) AS bookedforecasted_arr
	FROM oppid
	GROUP BY opp_created_date, ACT_MARKET_SEGMENT__C_GROUP, ACT_MARKET_SEGMENT__C, ACT_MARKET__C
	HAVING SUM(OPP_COUNT) > 0
	)
,
--------- Opportunity Stage Zero
oppstagezero
AS (
	SELECT 
	'opp_stage_0_date' AS date_field,
	opp_stage_0_date AS date,
	ACT_MARKET_SEGMENT__C_GROUP,
	ACT_MARKET_SEGMENT__C,
    	ACT_MARKET__C,
    'Opportunity Volume' AS metric_group,
    'Sales Outcome Metric' AS metric_outcome,
    'Qualify Opp Volume - Stage 1' AS metric,
	SUM(OPP_COUNT) AS value,
	SUM(INTERACTION_ONLY_BEFORE_STAGE_ONE_FLAG) AS interaction_before_milestone,
	SUM(OPP_BOOKEDFORECASTED_SUBS_QTY3__C) AS bookedforecasted_subs,
--	SUM(OPP_BOOKEDFORECASTED_ACV_QTY3__C) AS bookedforecasted_acv,
	SUM(OPP_BOOKEDFORECASTED_ARR__C) AS bookedforecasted_arr
	FROM oppid
	WHERE OPP_STAGE_0_DATE IS NOT NULL
	GROUP BY opp_stage_0_date, ACT_MARKET_SEGMENT__C_GROUP, ACT_MARKET_SEGMENT__C, ACT_MARKET__C
	HAVING SUM(OPP_COUNT) > 0 
	)	    
,
--------- Opportunity Stage One
oppstageone
AS (
	SELECT 
	'opp_stage_1_date' AS date_field,
	opp_stage_1_date AS date,
	ACT_MARKET_SEGMENT__C_GROUP,
	ACT_MARKET_SEGMENT__C,
    	ACT_MARKET__C,
    'Opportunity Volume' AS metric_group,
    'Sales Outcome Metric' AS metric_outcome,
    'Qualify Opp Volume - Stage 1' AS metric,
	SUM(OPP_COUNT) AS value,
	SUM(INTERACTION_ONLY_BEFORE_STAGE_ONE_FLAG) AS interaction_before_milestone,
	SUM(OPP_BOOKEDFORECASTED_SUBS_QTY3__C) AS bookedforecasted_subs,
--	SUM(OPP_BOOKEDFORECASTED_ACV_QTY3__C) AS bookedforecasted_acv,
	SUM(OPP_BOOKEDFORECASTED_ARR__C) AS bookedforecasted_arr
	FROM oppid
	WHERE OPP_STAGE_1_DATE IS NOT NULL
	GROUP BY opp_stage_1_date, ACT_MARKET_SEGMENT__C_GROUP, ACT_MARKET_SEGMENT__C, ACT_MARKET__C
	HAVING SUM(OPP_COUNT) > 0 
	)	    
,
--------- Opportunity Closed Won
oppclosedwon
AS (
	SELECT 
	'opp_close_date' AS date_field,
	opp_close_date AS date,
	ACT_MARKET_SEGMENT__C_GROUP,
	ACT_MARKET_SEGMENT__C,
    	ACT_MARKET__C,
	'Opportunity Volume' AS metric_group,
	'Sales Outcome Metric' AS metric_outcome,
	'CW Opp Volume' AS metric,
	SUM(OPP_WON_COUNT) AS value,
	SUM(INTERACTION_ONLY_BEFORE_CLOSED_WON_FLAG) AS interaction_before_milestone,
	SUM(OPP_BOOKEDFORECASTED_SUBS_QTY3__C) AS bookedforecasted_subs,
--	SUM(OPP_BOOKEDFORECASTED_ACV_QTY3__C) AS bookedforecasted_acv,
	SUM(OPP_BOOKEDFORECASTED_ARR__C) AS bookedforecasted_arr
	FROM oppid
	WHERE OPP_IS_WON = TRUE
	GROUP BY opp_close_date, ACT_MARKET_SEGMENT__C_GROUP, ACT_MARKET_SEGMENT__C, ACT_MARKET__C
	HAVING SUM(OPP_WON_COUNT) >0
	)
	
SELECT * FROM oppcreated
UNION 
SELECT * FROM oppstagezero
UNION 
SELECT * FROM oppstageone
UNION
SELECT * FROM oppclosedwon
;
RAISE INFO 'step 6a complete';


--- MMM - 02. Marketing TouchPoint CTE

DROP TABLE IF EXISTS ACT_MRKT_LIFECYCLE.mmm_marketing_touchpoint CASCADE;    
CREATE TABLE ACT_MRKT_LIFECYCLE.mmm_marketing_touchpoint as

WITH mrktgtouchpoint 
AS (
    SELECT 
		touchpoint.MARKETING_TOUCHPOINT_DATE,
		touchpoint.ACT_MARKET_SEGMENT__C AS ACT_MARKET_SEGMENT__C,
		touchpoint.ACT_MARKET_SEGMENT__C_GROUP AS ACT_MARKET_SEGMENT__C_GROUP,
		touchpoint.INFLUENCE_CHANNEL AS CHANNEL,
		touchpoint.INFLUENCE_CAMPAIGN_NAME AS CAMPAIGN_NAME,
		touchpoint.INFLUENCE_CAMPAIGN_MARKET_SEGMENT AS CAMPAIGN_MARKET_SEGMENT_GROUP,
		touchpoint.INFLUENCE_CAMPAIGN_TYPE AS CAMPAIGN_TYPE,
	
		touchpoint.MARKETING_TOUCH_TYPE_COUNT,
		touchpoint.INTERACTIONTYPE_SIXSENSE_PAIDMEDIA_IMPRESSIONS_COUNT,
		touchpoint.INTERACTIONTYPE_INTERACTION_COUNT,
		touchpoint.INTERACTIONTYPE_SIXSENSE_PAIDMEDIA_CLICKS_COUNT,
		touchpoint.INTERACTIONTYPE_SIXSENSE_WEBVISIT_TOTAL_INTERACTIONS_COUNT,
		touchpoint.INTERACTIONTYPE_SIXSENSE_WEBVISIT_PAGELOAD_COUNT,
		touchpoint.INTERACTIONTYPE_SIXSENSE_WEBVISIT_PLAY_COUNT,
		touchpoint.INTERACTIONTYPE_SIXSENSE_WEBVISIT_CLICK_COUNT,
		touchpoint.INTERACTIONTYPE_SIXSENSE_WEBVISIT_SUBMIT_COUNT,
		touchpoint.INTERACTIONTYPE_SIXSENSE_WEBVISIT_UNCLASSIFIED_COUNT,
		touchpoint.INTERACTIONTYPE_BIZIBLE_TOUCHPOINT_WEBVISIT_COUNT,
		touchpoint.INTERACTIONTYPE_BIZIBLE_TOUCHPOINT_WEBCHAT_COUNT,
		touchpoint.INTERACTIONTYPE_BIZIBLE_TOUCHPOINT_WEBFORM_COUNT,
		touchpoint.INTERACTIONTYPE_BIZIBLE_TOUCHPOINT_CRM_COUNT,
		touchpoint.INTERACTIONTYPE_BIZIBLE_TOUCHPOINT_CONNECTWITHDM_COUNT,
		touchpoint.INTERACTIONTYPE_BIZIBLE_TOUCHPOINT_CALLSPOKEWITH_COUNT,
		touchpoint.INTERACTIONTYPE_BIZIBLE_TOUCHPOINT_CALLGATEKEEPER_COUNT,
		touchpoint.INTERACTIONTYPE_BIZIBLE_TOUCHPOINT_NOLEADTOUCHPOINTS_COUNT,
		touchpoint.INTERACTIONTYPE_BIZIBLE_TOUCHPOINT_MARKETO_COUNT,
		touchpoint.INTERACTIONTYPE_BIZIBLE_TOUCHPOINT_SEISMICENGAGEMENT_COUNT,
		touchpoint.INTERACTIONTYPE_BIZIBLE_TOUCHPOINT_CHANGESTATUS_COUNT,
		touchpoint.INTERACTIONTYPE_BIZIBLE_TOUCHPOINT_UNCLASSIFIED_COUNT

    FROM
    (
        SELECT     
			marketing_touchpoint_date,
			ACT_MARKET_SEGMENT__C,
			ACT_MARKET_SEGMENT__C_GROUP,
            influence_channel,
            influence_campaign_name,
			INFLUENCE_CAMPAIGN_MARKET_SEGMENT,
			INFLUENCE_CAMPAIGN_TYPE,
                        
            -- Metrics
			COALESCE(SUM(MARKETING_TOUCH_TYPE_COUNT),0) AS MARKETING_TOUCH_TYPE_COUNT,

			-- Impressions
            COALESCE(SUM(INTERACTIONTYPE_SIXSENSE_PAIDMEDIA_IMPRESSIONS_COUNT),0) AS INTERACTIONTYPE_SIXSENSE_PAIDMEDIA_IMPRESSIONS_COUNT,
            
            -- Interactions
            (
            --COALESCE(SUM(INTERACTIONTYPE_SIXSENSE_PAIDMEDIA_IMPRESSIONS_COUNT),0) +

            COALESCE(SUM(INTERACTIONTYPE_SIXSENSE_PAIDMEDIA_CLICKS_COUNT),0) +
            
            --COALESCE(SUM(INTERACTIONTYPE_SIXSENSE_WEBVISIT_TOTAL_INTERACTIONS_COUNT),0) +
			COALESCE(SUM(INTERACTIONTYPE_SIXSENSE_WEBVISIT_PAGELOAD_COUNT),0) +
	        COALESCE(SUM(INTERACTIONTYPE_SIXSENSE_WEBVISIT_PLAY_COUNT),0) +
	        COALESCE(SUM(INTERACTIONTYPE_SIXSENSE_WEBVISIT_CLICK_COUNT),0) +
	        COALESCE(SUM(INTERACTIONTYPE_SIXSENSE_WEBVISIT_SUBMIT_COUNT),0) +
	       	COALESCE(SUM(INTERACTIONTYPE_BIZIBLE_TOUCHPOINT_WEBVISIT_COUNT),0) +
	       	COALESCE(SUM(INTERACTIONTYPE_BIZIBLE_TOUCHPOINT_WEBCHAT_COUNT),0) +
	       	COALESCE(SUM(INTERACTIONTYPE_BIZIBLE_TOUCHPOINT_WEBFORM_COUNT),0) +
	       	COALESCE(SUM(INTERACTIONTYPE_BIZIBLE_TOUCHPOINT_CRM_COUNT),0) +
	       	COALESCE(SUM(INTERACTIONTYPE_BIZIBLE_TOUCHPOINT_CONNECTWITHDM_COUNT),0) +
	       	COALESCE(SUM(INTERACTIONTYPE_BIZIBLE_TOUCHPOINT_CALLSPOKEWITH_COUNT),0) +
	       	COALESCE(SUM(INTERACTIONTYPE_BIZIBLE_TOUCHPOINT_CALLGATEKEEPER_COUNT),0) +
	       	COALESCE(SUM(INTERACTIONTYPE_BIZIBLE_TOUCHPOINT_NOLEADTOUCHPOINTS_COUNT),0) +
	       	COALESCE(SUM(INTERACTIONTYPE_BIZIBLE_TOUCHPOINT_MARKETO_COUNT),0) +
	       	COALESCE(SUM(INTERACTIONTYPE_BIZIBLE_TOUCHPOINT_SEISMICENGAGEMENT_COUNT),0) +
	       	COALESCE(SUM(INTERACTIONTYPE_BIZIBLE_TOUCHPOINT_CHANGESTATUS_COUNT),0)			
	       	--COALESCE(SUM(INTERACTIONTYPE_BIZIBLE_TOUCHPOINT_UNCLASSIFIED_COUNT),0)
	       	)	AS interactiontype_interaction_count,

            -- Breakout
            COALESCE(SUM(INTERACTIONTYPE_SIXSENSE_PAIDMEDIA_CLICKS_COUNT),0) AS INTERACTIONTYPE_SIXSENSE_PAIDMEDIA_CLICKS_COUNT,
            
            COALESCE(SUM(INTERACTIONTYPE_SIXSENSE_WEBVISIT_TOTAL_INTERACTIONS_COUNT),0) AS INTERACTIONTYPE_SIXSENSE_WEBVISIT_TOTAL_INTERACTIONS_COUNT,
	            COALESCE(SUM(INTERACTIONTYPE_SIXSENSE_WEBVISIT_PAGELOAD_COUNT),0) AS INTERACTIONTYPE_SIXSENSE_WEBVISIT_PAGELOAD_COUNT,
	            COALESCE(SUM(INTERACTIONTYPE_SIXSENSE_WEBVISIT_PLAY_COUNT),0) AS INTERACTIONTYPE_SIXSENSE_WEBVISIT_PLAY_COUNT,
	            COALESCE(SUM(INTERACTIONTYPE_SIXSENSE_WEBVISIT_CLICK_COUNT),0) AS INTERACTIONTYPE_SIXSENSE_WEBVISIT_CLICK_COUNT,
	            COALESCE(SUM(INTERACTIONTYPE_SIXSENSE_WEBVISIT_SUBMIT_COUNT),0) AS INTERACTIONTYPE_SIXSENSE_WEBVISIT_SUBMIT_COUNT,
	       COALESCE(SUM(INTERACTIONTYPE_SIXSENSE_WEBVISIT_UNCLASSIFIED_COUNT),0) AS INTERACTIONTYPE_SIXSENSE_WEBVISIT_UNCLASSIFIED_COUNT,

	       COALESCE(SUM(INTERACTIONTYPE_BIZIBLE_TOUCHPOINT_WEBVISIT_COUNT),0) AS INTERACTIONTYPE_BIZIBLE_TOUCHPOINT_WEBVISIT_COUNT,
	       COALESCE(SUM(INTERACTIONTYPE_BIZIBLE_TOUCHPOINT_WEBCHAT_COUNT),0) AS INTERACTIONTYPE_BIZIBLE_TOUCHPOINT_WEBCHAT_COUNT,
	       COALESCE(SUM(INTERACTIONTYPE_BIZIBLE_TOUCHPOINT_WEBFORM_COUNT),0) AS INTERACTIONTYPE_BIZIBLE_TOUCHPOINT_WEBFORM_COUNT,
	       COALESCE(SUM(INTERACTIONTYPE_BIZIBLE_TOUCHPOINT_CRM_COUNT),0) AS INTERACTIONTYPE_BIZIBLE_TOUCHPOINT_CRM_COUNT,
	       COALESCE(SUM(INTERACTIONTYPE_BIZIBLE_TOUCHPOINT_CONNECTWITHDM_COUNT),0) AS INTERACTIONTYPE_BIZIBLE_TOUCHPOINT_CONNECTWITHDM_COUNT,
	       COALESCE(SUM(INTERACTIONTYPE_BIZIBLE_TOUCHPOINT_CALLSPOKEWITH_COUNT),0) AS INTERACTIONTYPE_BIZIBLE_TOUCHPOINT_CALLSPOKEWITH_COUNT,
	       COALESCE(SUM(INTERACTIONTYPE_BIZIBLE_TOUCHPOINT_CALLGATEKEEPER_COUNT),0) AS INTERACTIONTYPE_BIZIBLE_TOUCHPOINT_CALLGATEKEEPER_COUNT,
	       COALESCE(SUM(INTERACTIONTYPE_BIZIBLE_TOUCHPOINT_NOLEADTOUCHPOINTS_COUNT),0) AS INTERACTIONTYPE_BIZIBLE_TOUCHPOINT_NOLEADTOUCHPOINTS_COUNT,
	       COALESCE(SUM(INTERACTIONTYPE_BIZIBLE_TOUCHPOINT_MARKETO_COUNT),0) AS INTERACTIONTYPE_BIZIBLE_TOUCHPOINT_MARKETO_COUNT,
	       COALESCE(SUM(INTERACTIONTYPE_BIZIBLE_TOUCHPOINT_SEISMICENGAGEMENT_COUNT),0) AS INTERACTIONTYPE_BIZIBLE_TOUCHPOINT_SEISMICENGAGEMENT_COUNT,
	       COALESCE(SUM(INTERACTIONTYPE_BIZIBLE_TOUCHPOINT_CHANGESTATUS_COUNT),0) AS INTERACTIONTYPE_BIZIBLE_TOUCHPOINT_CHANGESTATUS_COUNT,   
		   
	       COALESCE(SUM(INTERACTIONTYPE_BIZIBLE_TOUCHPOINT_UNCLASSIFIED_COUNT),0) AS INTERACTIONTYPE_BIZIBLE_TOUCHPOINT_UNCLASSIFIED_COUNT
        FROM act_mrkt_lifecycle.touchtype_analytics
        WHERE CRM_ACCOUNT_ID IS NOT NULL
        GROUP BY        
			marketing_touchpoint_date,
			ACT_MARKET_SEGMENT__C,
			ACT_MARKET_SEGMENT__C_GROUP,
            influence_channel,
            influence_campaign_name,
			INFLUENCE_CAMPAIGN_MARKET_SEGMENT,
			INFLUENCE_CAMPAIGN_TYPE
        
    ) AS touchpoint
    )
,
--------- Marketing Touch Type Count
alltouches
AS (
	SELECT 
	'marketing_touchpoint_date' AS date_field,
	marketing_touchpoint_date AS date,
	ACT_MARKET_SEGMENT__C,
	ACT_MARKET_SEGMENT__C_GROUP,
	channel,
	campaign_market_segment_group,
	campaign_type,
	campaign_name,
	'Touch Volume' AS metric_group,
	'Marketing Outcome Metric' AS metric_outcome,
	'All Touches' AS metric,
	SUM(MARKETING_TOUCH_TYPE_COUNT) AS value
	FROM mrktgtouchpoint
	GROUP BY marketing_touchpoint_date, ACT_MARKET_SEGMENT__C, ACT_MARKET_SEGMENT__C_GROUP, channel, campaign_market_segment_group, campaign_type, campaign_name
	HAVING SUM(MARKETING_TOUCH_TYPE_COUNT) > 0
	)
,
--------- Impressions
impressions
AS (
	SELECT 
	'marketing_touchpoint_date' AS date_field,
	marketing_touchpoint_date AS date,
	ACT_MARKET_SEGMENT__C,
	ACT_MARKET_SEGMENT__C_GROUP,
	channel,
	campaign_market_segment_group,
	campaign_type,
	campaign_name,
	'Touch Volume' AS metric_group,
	'Marketing Outcome Metric' AS metric_outcome,
	'Impressions' AS metric,
	SUM(INTERACTIONTYPE_SIXSENSE_PAIDMEDIA_IMPRESSIONS_COUNT) AS value
	FROM mrktgtouchpoint
	GROUP BY marketing_touchpoint_date, ACT_MARKET_SEGMENT__C, ACT_MARKET_SEGMENT__C_GROUP, channel, campaign_market_segment_group, campaign_type, campaign_name
	HAVING SUM(INTERACTIONTYPE_SIXSENSE_PAIDMEDIA_IMPRESSIONS_COUNT) > 0
	)
,
--------- Interactions
interactions
AS (
	SELECT 
	'marketing_touchpoint_date' AS date_field,
	marketing_touchpoint_date AS date,
	ACT_MARKET_SEGMENT__C,
	ACT_MARKET_SEGMENT__C_GROUP,
	channel,
	campaign_market_segment_group,
	campaign_type,
	campaign_name,
	'Touch Volume' AS metric_group,
	'Marketing Outcome Metric' AS metric_outcome,
	'Interactions' AS metric,
	SUM(INTERACTIONTYPE_INTERACTION_COUNT) AS value
	FROM mrktgtouchpoint
	GROUP BY marketing_touchpoint_date, ACT_MARKET_SEGMENT__C, ACT_MARKET_SEGMENT__C_GROUP, channel, campaign_market_segment_group, campaign_type, campaign_name
	HAVING SUM(INTERACTIONTYPE_INTERACTION_COUNT) > 0
	)

SELECT * FROM alltouches
UNION
SELECT * FROM impressions
UNION
SELECT * FROM interactions
;
RAISE INFO 'step 6b complete';

-- If it reaches here, log success
INSERT INTO bt_config.procedure_error_log (proc_name, status, message)
VALUES ('mqa_report_tables_v1_11', 'SUCCESS', 'Procedure completed');

COMMIT;

EXCEPTION
    WHEN OTHERS THEN
        -- Log the failure
		ROLLBACK;
        INSERT INTO bt_config.procedure_error_log (proc_name, status, message)
        VALUES ('mqa_report_tables_v1_11', 'FAILED', SQLERRM);
END;


$$
;
