CREATE OR REPLACE PROCEDURE config.copy_data_and_log(redshift_table character varying(65535), column_names character varying(65535), manifest_file_path character varying(65535), "iam_role" character varying(65535), files_list character varying(65535), copy_options character varying(65535))
 NONATOMIC
 LANGUAGE plpgsql
AS $$
DECLARE
retry_count INT :=0;
    max_retries INT:=2 ;
    status BOOLEAN := FALSE ;
    sql_command CHARACTER VARYING(65535);
    file_format CHARACTER VARYING(1000):=' format as parquet '; -- use parquet as the default format
    column_list CHARACTER VARYING(65535):=' ';
BEGIN

-- inspect input copy options for an overriding format
IF CHARINDEX('format', LOWER(copy_options)) > 0 THEN
   -- if the copy options provides its own specific format ( i.e. FORMAT AS JSON 'auto' )
   -- then empty the default file_format variable to allow for the input override
  file_format := '';
END IF;

-- some pipelines may not provide column names
-- if column names are provided, then build the column mapping list 
IF LEN(BTRIM(column_names)) > 0 THEN
  column_list := ' (' || column_names || ') ';
END IF;

    -- Loop to retry copy command in case of failure
    WHILE retry_count < max_retries AND NOT status
    LOOP

BEGIN
            -- Execute COPY command
            sql_command := 'COPY ' || redshift_table || column_list || ' FROM ''' || manifest_file_path || ''' IAM_ROLE ''' || iam_role || ''' MANIFEST ' || file_format || copy_options ;
            RAISE INFO 'retry_count: %', retry_count;
            RAISE INFO 'sql_command: %', sql_command;
EXECUTE sql_command;

-- If COPY command executed successfully
status := TRUE;

            -- Log success
INSERT INTO config.copy_log(table_name, manifest_file, column_names_seq, success,files, timestamp)
VALUES (redshift_table, manifest_file_path, column_names, TRUE,files_list, CURRENT_TIMESTAMP);
--EXIT;

EXCEPTION
            -- Catch exception if COPY command fails

            WHEN OTHERS THEN
                RAISE INFO 'This is a message from my procedure.';
                -- Increment retry count
                retry_count := retry_count + 1;
                RAISE INFO 'retry_count: %', retry_count;
                RAISE INFO 'status: %',status;

                -- Log failure
INSERT INTO config.copy_log (table_name, manifest_file, column_names_seq, success, error_message,files,timestamp)
VALUES (redshift_table, manifest_file_path, column_names, FALSE, SQLERRM, files_list,CURRENT_TIMESTAMP);


-- Wait for some time before retrying (optional)
--PERFORM pg_sleep(5); -- Uncomment this line if you want to introduce a delay between retries
END;


END LOOP;

    -- If after all retries, the copy command still fails, log failure
    IF NOT status THEN
        INSERT INTO config.copy_log (table_name, manifest_file, column_names_seq, success, error_message, files,timestamp)
        VALUES (redshift_table, manifest_file_path, column_names, FALSE, 'Maximum retries reached',files_list, CURRENT_TIMESTAMP);
        RAISE EXCEPTION 'Not able to execute procedure after max retries as well';
END IF;
END;
$$