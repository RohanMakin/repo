import json
import os
import logging
import paramiko
import boto3
from datetime import datetime, timedelta
import fnmatch

ssm = boto3.client("ssm")
s3 = boto3.client("s3")
rds_client = boto3.client("rds-data")
sm = boto3.client("secretsmanager")

# Set up logging to print only error from other python logging
logger = logging.getLogger()
logger.setLevel(logging.INFO)


def populate_db_parameters():
    logger.debug("BEGIN populate_db_parameters")
    global database_name
    global db_cluster_arn
    global db_secrets_arn
    database_name = ssm.get_parameter(
        Name="/services/rds/aurora-postgresql/dp_admin/database", WithDecryption=False
    )["Parameter"]["Value"]
    db_cluster_arn = ssm.get_parameter(
        Name="/services/rds/aurora-postgresql/dp_admin/cluster_arn",
        WithDecryption=False,
    )["Parameter"]["Value"]
    db_secrets_arn = ssm.get_parameter(
        Name="/services/sm/rds/db_admin/arn", WithDecryption=False
    )["Parameter"]["Value"]
    logger.debug(
        "END populate_db_parameters. database_name={}, db_cluster_arn={}, db_secrets_arn={}".format(
            database_name, db_cluster_arn, db_secrets_arn
        )
    )


def connect_sftp(connection_key_prefix):
    logger.info(
        "BEGIN connect_sftp. connection_key_prefix={}".format(connection_key_prefix)
    )
    try:
        host = ssm.get_parameter(
            Name=f"{connection_key_prefix}-host", WithDecryption=True
        )["Parameter"]["Value"]
        port = ssm.get_parameter(
            Name=f"{connection_key_prefix}-port", WithDecryption=True
        )["Parameter"]["Value"]
        username = ssm.get_parameter(
            Name=f"{connection_key_prefix}-username", WithDecryption=True
        )["Parameter"]["Value"]

        sftp_password_response = sm.get_secret_value(
            SecretId=f"{connection_key_prefix}-password"
        )
        password = json.loads(sftp_password_response["SecretString"])[
            f"{connection_key_prefix}-password"
        ]

        logger.info(
            "connect_sftp. host={}, port={}, username={}".format(host, port, username)
        )
        # Create a Transport object
        transport = paramiko.Transport((host, int(port)))
        # Connect to a Transport server
        transport.connect(username=username, password=password)
        return paramiko.SFTPClient.from_transport(transport)
    except Exception as e:
        logger.error("ERROR::connect_sftp while connecting with sftp. e={}".format(e))
        raise Exception("Exception in connect_sftp while connecting with sftp: %s" % e)


def execute_statement(sql, sql_parameters=[]):
    logger.debug("BEGIN execute_statement. sql={}".format(sql))
    try:
        response = rds_client.execute_statement(
            secretArn=db_secrets_arn,
            database=database_name,
            resourceArn=db_cluster_arn,
            sql=sql,
            parameters=sql_parameters,
        )
        logger.debug("END execute_statement. response={}".format(response))
        return response
    except Exception as e:
        logger.error(
            "ERROR::execute_statement while executing sql statement. e={}".format(e)
        )
        raise Exception(
            "Exception in execute_statement while executing sql statement: %s" % e
        )


def fetch_source_target_dirs():
    logger.info("BEGIN fetch_source_target_dirs.")
    sql = (
        'select "SOURCE_DIR", "TARGET_DIR" from admin_schema.job_master_data where "DATA_SOURCE"=:ds '
        "AND \"JOB_STEP\"='INGEST' AND \"IS_ACTIVE\"='Y'"
    )
    sql_response = execute_statements(sql)
    if not sql_response:
        raise ValueError(
            "ERROR::fetch_source_target_dirs. API response returns 0 records from the database select query"
        )
    sql_response = sql_response[0]
    logger.debug("fetch_source_target_dirs. sql_response={}".format(sql_response))
    db_result = []
    for x in sql_response:
        for y in x.values():
            db_result.append(y)
    logger.info(
        "END fetch_source_target_dirs. source_dir, target_dir={}".format(db_result)
    )
    return db_result


def execute_statements(sql):
    logger.debug("BEGIN execute_statements. sql={}".format(sql))
    sql_parameters = [{"name": "ds", "value": {"stringValue": f"{data_source}"}}]
    response = execute_statement(sql, sql_parameters)
    logger.debug("END execute_statements.")
    return response["records"]


def fetch_executed_date():
    logger.info("BEGIN fetch_executed_date.")
    sql = (
        'SELECT MAX(CAST("DATE" as int) ) FROM admin_schema.job_details where "DATASOURCE_NAME"=:ds '
        "AND \"STEP_NAME\"='INGEST' AND \"STEP_STATUS\"='SUCCESS'"
    )
    sql_response = execute_statements(sql)
    last_executed_date = None
    if sql_response:
        sql_response = sql_response[0]
        db_result = []
        for x in sql_response:
            for y in x.values():
                if type(y) is not bool:
                    db_result.append(y)
                    last_executed_date = db_result[0]
    logger.info(
        "END fetch_executed_date. last_executed_date{}".format(last_executed_date)
    )
    return last_executed_date


def start_job(source_dir, target_dir, max_date_time, comments):
    logger.debug(
        "BEGIN start_job. source_dir={}, target_dir={}, max_date_time={}".format(
            source_dir, target_dir, max_date_time
        )
    )
    sql = (
        'INSERT INTO admin_Schema.job_details ("JOB_ID", "DATASOURCE_NAME", "SOURCE", "TARGET","STEP_NAME", '
        '"STEP_STATUS", "DATE", "COMMENT") '
        "VALUES (:job_id, :ds, :source_dir, :target_dir,:job_step, :status, :action_dt, :comments)"
    )
    sql_parameters = [
        {"name": "job_id", "value": {"stringValue": "1"}},
        {"name": "ds", "value": {"stringValue": f"{data_source}"}},
        {"name": "source_dir", "value": {"stringValue": f"{source_dir}"}},
        {"name": "target_dir", "value": {"stringValue": f"{target_dir}"}},
        {"name": "job_step", "value": {"stringValue": "INGEST"}},
        {"name": "status", "value": {"stringValue": "START"}},
        {
            "name": "action_dt",
            "value": {"stringValue": f"{max_date_time}"},
        },
        {"name": "comments", "value": {"stringValue": f"{comments}"}},
    ]
    logger.debug("start_job. Insert record in job_details sql={}".format(sql))
    response = execute_statement(sql, sql_parameters)
    logger.debug(
        "start_job. Insert record in job_details SQL response={}".format(response)
    )
    sql_response = response["ResponseMetadata"]["HTTPStatusCode"]
    logger.debug(
        "start_job. Insert record in job_details sql_response={}".format(sql_response)
    )
    if sql_response != 200:
        logger.error(
            "ERROR:start_job API response returns 0 records from the database insert query"
        )
        raise ValueError(
            "ERROR:start_job API response returns 0 records from the database insert query."
        )
    logger.debug("END start_job.")


def update_job_detail(status, comments, max_date_time):
    logger.debug(
        "BEGIN update_job_detail. status={},comments = {}, max_date_time={}".format(status, comments,max_date_time)
    )
    sql = (
        'UPDATE admin_Schema.job_details SET "STEP_STATUS"= :status, "DATE"=:action_dt, '
        '"COMMENT"=:comments WHERE "DATASOURCE_NAME" = :ds AND "STEP_NAME"=:cond_step AND '
        '"STEP_STATUS"=:cond_status'
    )
    logger.debug("update_job_detail. Update status in job_details sql={}".format(sql))
    sql_parameters = [
        {"name": "status", "value": {"stringValue": f"{status}"}},
        {"name": "comments", "value": {"stringValue": f"{comments}"}},
        {"name": "ds", "value": {"stringValue": f"{data_source}"}},
        {"name": "cond_step", "value": {"stringValue": "INGEST"}},
        {"name": "cond_status", "value": {"stringValue": "START"}},
        {
            "name": "action_dt",
            "value": {"stringValue": f"{max_date_time}"},
        },
    ]
    response = execute_statement(sql, sql_parameters)
    logger.debug(
        "update_job_detail. Update Status in Job_Details response={}".format(response)
    )
    sql_response = response["ResponseMetadata"]["HTTPStatusCode"]
    logger.debug(
        "update_job_detail. Update Status in Job_Details sql_response={}".format(
            sql_response
        )
    )
    if sql_response != 200:
        raise ValueError(
            "error:API response returns 0 records from the database update query"
        )
    logger.debug("END update_job_detail.")


def copy_files(conn_key_prefix, source_dir, target_dir, last_executed_date, batch_size,files_list_manual =[]):
    logger.debug(
        "BEGIN copy_files. conn_key_prefix={}, source_dir={}, target_dir={}, last_executed_date={}, batch_size={}".format(
            conn_key_prefix, source_dir, target_dir, last_executed_date, batch_size
        )
    )
    sftp = connect_sftp(conn_key_prefix)
    logger.debug("copy_files. stp connected successfully.")
    if not last_executed_date:
        logger.debug("copy_files. Execution started for batch load.")
        copy_all_files(sftp, source_dir, target_dir, batch_size)
    
    elif len(files_list_manual)>0:
        logger.debug("copy_files. Execution started for manual reprocess.")
        copy_files_manually(sftp, source_dir, target_dir, last_executed_date, batch_size,files_list_manual)
    
    else:
        #file_date = datetime.strptime(last_executed_date, "%Y%m%d") + timedelta(days=1)
        logger.debug("copy_files. last_executed_date={}".format(last_executed_date))
        copy_incremental_load_files(
            sftp, source_dir, target_dir, last_executed_date, batch_size
        )


def copy_all_files(sftp, source_dir, target_dir, batch_size):
    logger.debug(
        "BEGIN copy_all_files. source_dir={}, target_dir={}, batch_size={}".format(
            source_dir, target_dir, batch_size
        )
    )
    file_date_str = 0 #get_initial_file_dt(sftp, source_dir)
    logger.info("copy_all_files. file_date_str={}".format(file_date_str))
    copy_incremental_load_files(sftp, source_dir, target_dir, file_date_str, batch_size)
    logger.debug("END copy_all_files.")


def copy_incremental_load_files(
    sftp, source_dir, target_dir, last_executed_date, batch_size
):
    logger.debug(
        "BEGIN copy_incremental_load_files. source_dir={}, target_dir={}, last_executed_date{}, batch_size={}".format(
            source_dir, target_dir, last_executed_date, batch_size
        )
    )
    try:
        files_transferred = 0
        file_transfer = True
        files_list = []
        files_list , max_date_time = fetch_files(sftp, source_dir,batch_size,last_executed_date)
        logger.info(
            "copy_incremental_load_files. files_transferred={}, files_list={}".format(
                files_transferred, files_list
            )
        )
        files_transferred = files_transferred + len(files_list)
        logger.info(
            "copy_incremental_load_files. files_transferred={}".format(
                files_transferred
            )
        )
        if len(files_list) > 0:
            start_job(
                source_dir,
                target_dir,
                max_date_time,
                f"Execution Date:: {datetime.now():%Y-%m-%dT%H:%M:%SZ} | STARTED | Files:{files_list}",
            )
            for file in files_list:
            
                file_date_prefix = datetime.strptime(file[:8], "%Y%m%d")
                copy_file(file, sftp, source_dir, target_dir, file_date_prefix)
            update_job_detail(
                "SUCCESS",
                f"Execution Date:: {datetime.now():%Y-%m-%dT%H:%M:%SZ} | STARTED | Files:{files_list} | COMPLETED",
                max_date_time,
            )
        #file_date = file_date + timedelta(days=1)
        logger.debug("copy_incremental_load_files. max_date_time={}".format(max_date_time))
    except Exception as e:
        logger.error(f"ERROR::copy_incremental_load_files while copying files. {e}")
        update_job_detail(
            "FAILED",
            f"Execution Date:: {datetime.now():%Y-%m-%dT%H:%M:%SZ} | STARTED | Files:{files_list} | FAILED | Error:{e}",
            max_date_time,
        )
        raise Exception(
            "Exception in copy_incremental_load_files while copying file: %s" % e
        )

def copy_files_manually(
    sftp, source_dir, target_dir, last_executed_date, batch_size,file_list_manual
):
    logger.debug(
        "BEGIN copy_files_manually. source_dir={}, target_dir={}, last_executed_date{}, batch_size={}, file_list = {}".format(
            source_dir, target_dir, last_executed_date, batch_size,file_list_manual
        )
    )
    try:
        files_transferred = 0
        file_transfer = True
        files_list = file_list_manual
        max_date_time = last_executed_date
        #files_list , max_date_time = fetch_files(sftp, source_dir,batch_size,last_executed_date)
        logger.info(
            "copy_incremental_load_files. files_transferred={}, files_list={}".format(
                files_transferred, files_list
            )
        )
        files_transferred = files_transferred + len(files_list)
        logger.debug(
            "copy_incremental_load_files. files_transferred={}".format(
                files_transferred
            )
        )
        if len(files_list) > 0:
            start_job(
                source_dir,
                target_dir,
                max_date_time,
                f"Execution Date:: {datetime.now():%Y-%m-%dT%H:%M:%SZ} | STARTED | Files:{files_list}",
            )
            for file in files_list:
            
                file_date_prefix = datetime.strptime(file[:8], "%Y%m%d")
                copy_file(file, sftp, source_dir, target_dir, file_date_prefix)
            update_job_detail(
                "SUCCESS",
                f"Execution Date:: {datetime.now():%Y-%m-%dT%H:%M:%SZ} | STARTED | Files:{files_list} | COMPLETED",
                max_date_time,
            )
        #file_date = file_date + timedelta(days=1)
        logger.debug("copy_incremental_load_files. max_date_time={}".format(max_date_time))
    except Exception as e:
        logger.error(f"ERROR::copy_files_manually while copying files. {e}")
        update_job_detail(
            "FAILED",
            f"Execution Date:: {datetime.now():%Y-%m-%dT%H:%M:%SZ} | STARTED | Files:{files_list} | FAILED | Error:{e}",
            max_date_time,
        )
        raise Exception(
            "Exception in copy_files_manually while copying file: %s" % e
        )


def copy_file(file, sftp, source_dir, target_dir, dt):
    logger.debug(
        "BEGIN copy_file. source_dir={}, target_dir={}, dt={}".format(
            source_dir, target_dir, dt
        )
    )
    local_file = f"/tmp/{file}"
    sftp.get(f"{source_dir}/{file}", local_file)
    logger.debug("copy_file. File copied on local machine")
    bucket = target_dir[: target_dir.find("/")]
    key_prefix = target_dir[(target_dir.find("/") + 1) :]
    key = (
        f"{key_prefix[:key_prefix.find('/')]}/{file[(file.rindex('_') + 1):file.rindex('.')]}"
        f"/{key_prefix[(key_prefix.find('/') + 1):]}/year={dt.year}/month={dt.month}/day={dt.day}/{file}"
    )
    logger.debug("copy_file. bucket={}, key={}".format(bucket, key))
    result = s3.list_objects_v2(Bucket=bucket, Prefix=key)
    if "Contents" not in result:
        logger.debug("copy_file. key={} doesn't exists in s3.".format(key))
        s3.upload_file(Filename=local_file, Bucket=bucket, Key=key)
    os.remove(local_file)
    logger.debug("copy_file. File removed from local machine")


def fetch_files(sftp, source_dir,batch_size,last_modified_dt):
    logger.debug(
        "BEGIN fetch_files. source_dir={}, last_modified_dt={}".format(source_dir, last_modified_dt)
    )
   # prepare list of file with timestamp greater than last modified datetime 
    File_list=[]
    max_Date_Time = last_modified_dt
    last_update_dt = last_modified_dt
    for fileattr in sftp.listdir_attr(source_dir):
        if fileattr.st_mtime > last_update_dt:
            File_list.append([fileattr.filename,fileattr.st_mtime])
    
    #sorted file list based on timestamp
    srt_file_lst =  sorted(File_list,key=lambda l:l[1], reverse=False)
    
    if(len(srt_file_lst)<batch_size):
        batch_size = len(srt_file_lst)
    
    files = []
    if batch_size >0 : 
        for i in range(batch_size) :
            #print(srt_file_lst[i][0])
            filename = srt_file_lst[i][0]
            if filename.find("_") == 8 and "_mid" not in filename:
                files.append(srt_file_lst[i][0])
            if srt_file_lst[i][1] > max_Date_Time:
                max_Date_Time = srt_file_lst[i][1]
    logger.debug("END fetch_files. files_list={} , max_modified_datetime = {}".format(files,max_Date_Time))
    return files,max_Date_Time



def get_initial_file_dt(sftp, source_dir):
    logger.debug("BEGIN get_initial_file_dt. source_dir={}".format(source_dir))
    files = sftp.listdir(source_dir)
    files.sort(key=lambda x: x.split('_')[0])
    file_date = None
    for file in files:
        index = file.find("_")
        if index == 8 and file_date is None:
            file_dt = file[:index]
            try:
                datetime.strptime(file_dt, "%Y%m%d")
                file_date = file_dt
                break
            except Exception as e:
                print("Error", e, "occurred.")
    logger.debug("END get_initial_file_dt. file_date={}".format(file_date))
    return file_date


def lambda_handler(event, context):
    logger.info("BEGIN lambda_handler")
    try:
        populate_db_parameters()
        global data_source
        data_source = event["dataSource"]
        logger.info("lambda_handler:: data_source={}".format(data_source))
        source_dir, target_dir = fetch_source_target_dirs()
        logger.info(
            "lambda_handler:: source_dir={}, target_dir={}".format(source_dir, target_dir)
        )
        last_executed_date = fetch_executed_date()
        logger.info(f"lambda_handler:: last_executed_date={last_executed_date}")
        batch_size = event["batch_size"]
        
        if event.get("file_list_reprocess") is not None:
            #file_list_manual = event["file_list_reprocess"][1:-1].replace("'","").split(",")
            file_list_manual = event["file_list_reprocess"]
            logger.info(f"lambda_handler:: file_list_manual={file_list_manual}")
            copy_files(
                event["connection_key_prefix"],
                source_dir,
                target_dir,
                last_executed_date,
                batch_size,
                file_list_manual
            )
        else: 
            logger.info(f"lambda_handler:: batch_size={batch_size}")
            copy_files(
                event["connection_key_prefix"],
                source_dir,
                target_dir,
                last_executed_date,
                batch_size,
            )
            logger.info("lambda_handler:: Copying file end here.")
    except Exception as e:
        logger.error(f"ERROR::lambda_handler while copying files. {e}")
        raise Exception("Exception in lambda_handler while copying file: %s" % e)
    logger.info("END lambda_handler")