import boto3
from datetime import datetime, timedelta
import json
from boto3.dynamodb.conditions import Attr
from lytxlogger.lytx_logger import LytxLogger
import math
import os
import time
import uuid
from botocore.exceptions import ClientError
import datetime as dt

# Initialize DynamoDB client
dynamodb = boto3.resource('dynamodb')

# Initialize S3 client
s3 = boto3.client('s3')

# Initialize Redshift data Client
# redshift_data = boto3.client('redshift-data',region_name='us-west)
redshift_data = boto3.client('redshift-data')

# Define DynamoDB table name

table_name = os.environ['REDSHIFT_DYNAMODB_FILE_DETAILS_TABLE']

# Define S3 bucket for manifest files
manifest_bucket_name = os.environ['REDSHIFT_AUTOLOADER_MANIFEST_BUCKET']

# Retrieve environment variables containing Redshift connection details
database = os.environ['DATABASE']
secret_arn = os.environ['SECRET_ARN']
print(secret_arn)
resource_arn = os.environ['RESOURCE_ARN']
iam_role = os.environ['IAM_ROLE']
sns_topic_job_fail = os.environ['FAILURE_SNS_TOPIC']
gsi_name = os.environ['REDSHIFT_DYNAMODB_FILE_DETAILS_GSI_NAME']

lytxLogger = LytxLogger.create("logger_" + __name__)


def get_env_name(resourceName):
    if '-dev-' in resourceName:
        return "dev"
    elif '-stg-' in resourceName:
        return "stg"
    elif '-prod-' in resourceName:
        return "prod"


def update_dynamodb_table(table_name, file_path, status, manifest_file=None, redshift_proc_status=None):
    """
    Update the DynamoDB table with the status and manifest file name.

    Args:
        table_name (str): The name of the DynamoDB table.
        file_path (str): The primary key of the item to update.
        status (str): The status value to update.
        manifest_file (str): The manifest file name value to update.
    """
    table = dynamodb.Table(table_name)
    manifest_file = manifest_file if manifest_file is not None else "NA"
    redshift_proc_status = redshift_proc_status if redshift_proc_status is not None else "NA"

    try:
        response = table.update_item(
            Key={'filePath': file_path},
            UpdateExpression='SET #status = :status, #manifest_file = :manifest_file, #redshift_proc_status = :redshift_proc_status',
            ExpressionAttributeNames={'#status': 'status', '#manifest_file': 'manifestFileName',
                                      '#redshift_proc_status': 'redshiftStatus'},
            ExpressionAttributeValues={':status': status, ':manifest_file': manifest_file,
                                       ':redshift_proc_status': redshift_proc_status}
        )
        lytxLogger.info(
            f"Updated item: {file_path} - Status: {status}, Manifest File: {manifest_file} , Redshift Proc Status : {redshift_proc_status}")
    except Exception as e:
        lytxLogger.error(
            f'Failed to update dynamodb table for file: {file_path} with Status: {status}, Manifest File: {manifest_file} , Redshift Proc Status : {redshift_proc_status} , error = {str(e)}',
            domain=file_path,
            metadata={"file_path": file_path},
            error_code="FAILED_UPDATE_DYNAMODB_TABLE")
        publish_message(sns_topic_job_fail,
                        f"Error occurred in update_dynamodb_table ,Failed to update dynamodb table for file: {file_path} with Status: {status}, Manifest File: {manifest_file} , Redshift Proc Status : {redshift_proc_status} with error : {str(e)}")
        raise e


def publish_message(sns_topic_arn, comment):
    """
    Publishes a message to a SNS topic.
    """
    sns_client = boto3.client('sns')
    sns_message = comment
    sns_subject = 'Warning!Alert : Create manifest file lambda failed'
    try:

        response = sns_client.publish(
            TopicArn=sns_topic_arn,
            Message=sns_message,
            Subject=sns_subject,
        )['MessageId']

    except ClientError:
        lytxLogger.error("Could not publish message to the topic", error_code="SnsClientError")
        raise
    else:
        lytxLogger.info("Published message to SNS ")
        # return response


def redshift_execute_stored_procedure(table_name, column_order_list, manifest_s3_path, iam_role, file_list_param,
                                      copy_options):
    retry_count = 0
    max_retry = 3
    status = 'FAILURE'
    redshift_proc_status = 'FAILURE'
    sql = ''

    while retry_count < max_retry and status == 'FAILURE':

        try:

            # sql = f"call public.load_data_from_manifest_and_log('{table_name}', '{column_order_list}', '{manifest_s3_path}', '{iam_role}' ,'{file_list_param}')"
            sql = f"call config.copy_data_and_log('{table_name}', '{column_order_list}', '{manifest_s3_path}', '{iam_role}' ,'{file_list_param}', '{copy_options}')"

            print(sql)

            # Execute the SQL statement using the Redshift Data API
            response = redshift_data.execute_statement(
                ClusterIdentifier=resource_arn,
                Database=database,
                Sql=sql,
                SecretArn=secret_arn,
                WithEvent=True
            )

            time.sleep(10)

            query_id = response['Id']
            query_details = redshift_data.describe_statement(Id=query_id)
            query_status = query_details["Status"]
            lytxLogger.info(f'Stored procedure executed successfully. StatementId: = {query_id}')
            if query_status.lower() != "failed":
                status = 'Success'
                errorMsg = 'None'
                redshift_proc_status = query_status
            else:
                errorMsg = query_details["Error"] if "Error" in query_details else "Redshift Unknown Error"

                raise Exception(
                    f"current status: {query_status} and error message: {errorMsg} for manifest file: {manifest_s3_path} and files: {file_list_param}")

        except Exception as e:
            lytxLogger.error(
                f'Error Executing the RS stored Procedure for copy with retry count = {retry_count} , error = {str(e)}',
                domain=manifest_s3_path,
                metadata={"manifest_s3_path": manifest_s3_path},
                error_code="FAILED_EXECUTING_REDSHIFT_COPY_SP")
            errorMsg = f'Failed running sql command: "{sql}" with error {str(e)} '
            retry_count += 1
            if retry_count == 3:
                redshift_proc_status = "FAILURE"

    return redshift_proc_status, errorMsg


def query_dynamo_for_status(table_name, gsi_name, status_name):
    try:
        table = dynamodb.Table(table_name)
        query_params = {
            'IndexName': gsi_name,
            'KeyConditionExpression': '#status = :status_val',
            'ExpressionAttributeNames': {'#status': 'status'},
            'ExpressionAttributeValues': {':status_val': status_name},
            'Limit': 400
        }

        # Query the GSI
        response = table.query(**query_params)
        items = response.get('Items', [])
        return items
    except Exception as e:
        lytxLogger.error(f'Failed while querying dynamodb table/gsi for provided status, error = {str(e)}',
                         error_code='Gsi_Query_dynamo_for_Status')
        publish_message(sns_topic_job_fail,
                        f"Error occurred in query_dynamo_for_status: {status_name} with error : {str(e)}")
        raise e


def lambda_handler(event, context):
    # Step 1: Fetch records where status = 'landed in s3'
    # table = dynamodb.Table(table_name)
    # response = table.scan(FilterExpression=Attr('status').eq('file landed in s3'))
    # # response = table.scan(FilterExpression=Attr('status').eq('manifest created'))
    # items = response['Items']
    try:
        tracking_id = str(uuid.uuid4())
        created_date_time_temp = ''
        lytxLogger.init_logger(get_env_name(context.function_name), 'REDSHIFT_AUTOLOADER_MANIFEST', "lambda",
                               context.function_name,
                               context.aws_request_id, tracking_id)
        lytxLogger.info(f"msgbody : {event}")
        items = query_dynamo_for_status(table_name, gsi_name, 'FILE_LANDED')

        # Step 2: For each data source, check count of files retrieved and min createdDateTime & max batchSize
        data_sources = {}
        for item in items:
            data_source = item['dataSource']
            lytxLogger.info(f"data_source : {data_source}")
            file_count = 1
            # data_sources[data_source] = data_sources.get(data_source, 0)
            # print(data_sources.get(data_source, 0))

            # print(item)
            # print(data_sources)

            if 'createdTimestamp' in item:
                created_date_time_temp =  item['createdTimestamp'] + '.000001' if '.' not in item['createdTimestamp'] else item['createdTimestamp']
                created_datetime = datetime.strptime(created_date_time_temp, '%Y-%m-%d %H:%M:%S.%f')
                copyOptionParam = 'FILLRECORD' if 'copyOptions' not in item else str(item['copyOptions'])
                if data_source not in data_sources:
                    data_sources[data_source] = {'min_created_datetime': created_datetime,
                                                 'max_batchsize': item['batchSize'],
                                                 'column_order_list': str(item['columnList']),
                                                 'redshift_table_name': str(item['redshiftTableName']),
                                                 'copy_options': copyOptionParam
                        , "files": []}
                    # data_sources[data_source]["files"].append(item['filePath'])
                    data_sources[data_source]["files"].append(
                        {"filePath": item['filePath'], "contentSize": str(item['contentSize'])})

                else:
                    data_sources[data_source]["files"].append(
                        {"filePath": item['filePath'], "contentSize": str(item['contentSize'])})
                    if created_datetime < data_sources[data_source]['min_created_datetime']:
                        data_sources[data_source]['min_created_datetime'] = created_datetime
                    if item['batchSize'] > data_sources[data_source]['max_batchsize']:
                        data_sources[data_source]['max_batchsize'] = item['batchSize']
                    data_sources[data_source]['column_order_list'] = item['columnList']
                    data_sources[data_source]['redshift_table_name'] = item['redshiftTableName']
                    if 'copyOptions' not in item:
                        data_sources[data_source]['copy_options'] = 'FILLRECORD'
                    else:
                        data_sources[data_source]['copy_options'] = item['copyOptions']

        lytxLogger.info(f"data_sources : {data_sources}")

        current_time = datetime.now()

        # Step 3: Check conditions for each data source

        for data_source, info in data_sources.items():
            file_count = len(info['files'])
            min_created_datetime = info['min_created_datetime']
            max_batchsize = info['max_batchsize']
            files_list = info['files']
            time_elapsed = current_time - min_created_datetime
            if file_count > max_batchsize or time_elapsed > timedelta(seconds=60):
                for index in range(0, len(files_list)):
                    update_dynamodb_table(table_name, files_list[index]["filePath"], 'FILE_IN_PROCESS')
    except Exception as e:
        lytxLogger.error(f'Failed in the initial block = {str(e)}',
                         error_code='Files consolidation per datasource failed')
        publish_message(sns_topic_job_fail,
                        f"Error occurred in initial consolidation with error : {str(e)}")
        raise e

    for data_source, info in data_sources.items():
        try:
            # print(f"data_source=== {data_source} info ==={info}")
            lytxLogger.info(f"data_source : {data_source} , info ==={info} ")
            file_count = len(info['files'])
            min_created_datetime = info['min_created_datetime']
            max_batchsize = info['max_batchsize']
            files = info['files']
            files_list = info['files']
            column_order_list = info['column_order_list']
            redshift_table_name = info['redshift_table_name']
            copy_options = info['copy_options']

            time_elapsed = current_time - min_created_datetime
            if file_count > max_batchsize or time_elapsed > timedelta(seconds=60):
                # Prepare manifest files for copy command to S3
                batch_count = math.ceil(file_count / max_batchsize)
                lytxLogger.info(f"batchcount : {batch_count}")

                remaining_files = file_count
                for i in range(batch_count):
                    # Put try except here so that raise exception will be handled by this try except for loop of batches to continue instead of break afetr outer exception
                    try:
                        manifest_content = {"entries": []}
                        batch_size = min(max_batchsize, remaining_files)
                        lytxLogger.info(f"batchSize : {batch_size}")
                        # print(f"batchSize === {batch_size}")
                        for j in range(int(batch_size)):
                            # manifest_content += files.pop(0) + "\n"
                            # print(f"datasource ==== {data_source}")
                            # ind = int((i * batch_size) + j)
                            # print(f"ind===={ind}")
                            # manifest_content += files[ind] + "\n"
                            manifest_content["entries"].append(
                                {"url": files_list[j]["filePath"],
                                 "meta": {"content_length": int(files_list[j]["contentSize"])}})
                            # print(f"manifest_content====={manifest_content}")
                        remaining_files -= batch_size
                        date = dt.date.today()
                        yyyy_mm_ddpathstr = '' + str(date.year) + '/' + str(date.month) + '/' + str(date.day) + '/'
                        # Upload manifest file to S3
                        manifest_key = f"manifest_folder/{yyyy_mm_ddpathstr}{data_source}_manifest_{current_time.strftime('%Y%m%d%H%M%S')}_{i}.manifest"
                        s3.put_object(Bucket=manifest_bucket_name, Key=manifest_key,
                                      Body=json.dumps(manifest_content).encode('utf-8'))
                        # s3.put_object(Bucket=manifest_bucket_name, Key=manifest_key, Body=manifest_content)
                        manifest_file_path = "s3://" + manifest_bucket_name + "/" + manifest_key

                        # Update DynamoDB table
                        # Update each file path with the manifest file name
                        # print(f"files_list ======{files_list}")
                        lytxLogger.info(f"files_list : {files_list}")
                        file_list_param = ''
                        for file_path in files_list[:int(batch_size)]:
                            # print(f"filePath ==== {file_path}")
                            lytxLogger.info(f"filePath : {file_path}")
                            update_dynamodb_table(table_name, file_path['filePath'], 'MANIFEST_CREATED',
                                                  manifest_file_path)
                            file_list_param = file_list_param + ',' + file_path['filePath']
                            # update_dynamodb_table(table_name, file_path, 'file landed in s3', '')

                        redshift_proc_status, errorMsg = redshift_execute_stored_procedure(redshift_table_name,
                                                                                           column_order_list,
                                                                                           manifest_file_path, iam_role,
                                                                                           file_list_param,
                                                                                           copy_options)
                        # print(f"redshift_proc_status is :{redshift_proc_status} ,  errorMsg is {errorMsg}")
                        lytxLogger.info(f"redshift_proc_status is :{redshift_proc_status} ,  errorMsg is {errorMsg}")

                        for file_path in files_list[:int(batch_size)]:
                            update_dynamodb_table(table_name, file_path['filePath'], 'MANIFEST_CREATED',
                                                  manifest_file_path,
                                                  redshift_proc_status)

                        if files_list:
                            files_list = files_list[int(batch_size):]

                        if redshift_proc_status == 'FAILURE':
                            raise Exception(f"retried 3 times : failed with error {errorMsg}")
                    except Exception as e:
                        lytxLogger.error(f'Failed to execute  , error = {str(e)}', error_code='code_error')
                        publish_message(sns_topic_job_fail,
                                        f"Error occurred for datasource: {data_source} with error : {str(e)}")

                    # update file list for the next iteration


        except Exception as e:
            lytxLogger.error(f'Failed to execute lambda , error = {str(e)}', error_code='unknown_error')
            # print(f"Failed for datasource {data_source} with error {str(e)}")
            publish_message(sns_topic_job_fail, f"Error occurred for datasource: {data_source} with error : {str(e)}")

