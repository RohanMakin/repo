--VRBO PROD OR STAGE (INTEGRATION)
--IF IN THE OFFICE, NEED TO BE ON VPN IN ORDER TO CONNECT

--BOOKING WITH PARTNER FEES
select b.*, pf.PartnerFeeAmount from lodgingtax.TaxBooking b
left join lodgingtax.PartnerFees pf on b.TaxBookingID=pf.TaxBookingID
where b.itinerary in (
'HA-9F6HM3'
)

--LODGING TAX BY IMPOSITION
select b.itinerary, lt.*
from lodgingtax.LodgingTax lt
inner join lodgingtax.TaxBooking b on lt.TaxBookingID=b.TaxBookingID
where b.itinerary in (
'HA-9F6HM3'
);

--VALIDATE TAX CALCULATIONS
--CHECK BEARDSLEY FOR THE RATES: https://bui.prod.beardsley.expedia.com/gts/taxRateLookups
	--USE EITHER ADDRESS OR PROPERTY ID LOOKUP.  SOURCE=BTCS, SELLER=HOMEAWAY
--TAX BASE REFERENCE: https://confluence.expedia.biz/pages/viewpage.action?spaceKey=TT&title=Tax+Models+and+Capabilities
--MULTIPLY RATE BY THE APPROPRIATE TAX BASE AND COMPARE TO LODGING TAX BY IMPOSITION DETAILS