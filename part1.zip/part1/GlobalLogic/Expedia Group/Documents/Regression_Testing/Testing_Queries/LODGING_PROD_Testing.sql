--CREATE USE CASE LOOKUP TABLE 
drop table use_case;
 
create volatile table use_case
(use_case varchar(10), txn_identifier varchar(55))
on commit preserve rows;
 
 insert into use_case values (1,790469221);
 insert into use_case values (2,790469568);
 insert into use_case values (3,790470204);
 insert into use_case values (4,790491232);
 insert into use_case values (5,790471440);
 insert into use_case values (6,790473500);
 
-- select * from use_case;
 
--LODG_RM_TRANS_FACT 
select 
u.use_case,
ORDER_NBR, TF.BKG_ITM_ID, tf.BKG_ID, tf.ITIN_NBR, tf.ORDER_CONF_NBR, tf.POS_ORDER_REF_NBR, tf.TPID, tf.TRL, tf.SUPPL_BKG_CONF_CODE,
tt.TRANS_TYP_NAME,pl.PKG_IND, tf.TRANS_DATE_KEY, tf.BK_DATE_KEY, tf.BEGIN_USE_DATE_KEY, tf.END_USE_DATE_KEY,
p.EXPE_LODG_PROPERTY_ID, p.LODG_PROPERTY_NAME, p.PROPERTY_CITY_NAME, p.PROPERTY_STATE_PROVNC_NAME, p.PROPERTY_CNTRY_CODE, p.PROPERTY_TYP_NAME,
pl.Product_LN_NAME, pl.Business_Model_Name, pl.Business_Model_subtyp_NAME, tp.TPID_NAME, lgl.LGL_ENTITY_CODE, lgl.LGL_ENTITY_NAME, mu.MGMT_UNIT_CODE, mu.MGMT_UNIT_NAME,
ogl.ORACLE_GL_PRODUCT_CODE, ogl.ORACLE_GL_PRODUCT_DESC, gl.GL_PRODUCT_ID, ou.OPER_UNIT_ID,
pc.PRICE_CURRN_CODE,
cc.COST_CURRN_CODE,
tc.TPID_CURRN_CODE,
pl.PKG_IND,
rp.LODG_RATE_PLN_TYP_NAME,
pc.PRICE_CURRN_CODE, 
tf.RM_NIGHT_CNT,
tf.GROSS_BKG_AMT_USD,
tf.GROSS_BKG_AMT_LOCAL,
tf.BASE_PRICE_AMT_USD,
tf.BASE_PRICE_AMT_LOCAL,
tf.TOTL_PRICE_ADJ_AMT_USD,
tf.TOTL_PRICE_ADJ_AMT_LOCAL,
tf.TOTL_FEE_PRICE_AMT_USD,
tf.TOTL_FEE_PRICE_AMT_LOCAL,
tf.TOTL_TAX_PRICE_AMT_USD,
tf.TOTL_TAX_PRICE_AMT_LOCAL,
tf.TOTL_COST_AMT_USD,
tf.TOTL_COST_AMT_LOCAL,
tf.BASE_COST_AMT_USD,
tf.BASE_COST_AMT_LOCAL,
tf.TOTL_COST_ADJ_AMT_USD,
tf.TOTL_COST_ADJ_AMT_LOCAL,
tf.TOTL_FEE_COST_AMT_USD,
tf.TOTL_FEE_COST_AMT_LOCAL,
tf.TOTL_TAX_COST_AMT_USD,
tf.TOTL_TAX_COST_AMT_LOCAL,
tf.MARGN_AMT_USD,
tf.Frnt_End_Cmsn_Amt_Usd,
tf.FRNT_END_CMSN_AMT_COST_CURRN,
tf.SVC_FEE_PRICE_AMT_USD,
tf.COUPN_PRICE_AMT_USD
--  tf.GENRIC_COUPN_PRICE_AMT_USD

from P_DM_bkg_lodg.lodg_rm_trans_fact tf
left join P_DM_LODG_PROPERTY.LODG_PROPERTY_DIM p ON (p.LODG_PROPERTY_KEY=tf.LODG_PROPERTY_KEY)
left join P_DM_COMMON.MGMT_UNIT_DIM mu on tf.MGMT_UNIT_KEY=mu.MGMT_UNIT_KEY
left join P_DM_COMMON.TPID_DIM tp on tf.tpid=tp.tpid
left join P_DM_COMMON.LGL_ENTITY_DIM lgl on tf.LGL_ENTITY_KEY=lgl.LGL_ENTITY_KEY 
left join P_DM_COMMON.PRODUCT_LN_DIM pl on tf.PRODUCT_LN_KEY=pl.PRODUCT_LN_KEY
left join P_DM_COMMON.TRANS_TYP_DIM tt ON tf.TRANS_TYP_KEY=tt.TRANS_TYP_KEY
left join P_DM_COMMON.PRICE_CURRN_DIM pc ON tf.PRICE_CURRN_KEY=pc.PRICE_CURRN_KEY
left join P_DM_COMMON.OPER_UNIT_DIM ou ON tf.OPER_UNIT_KEY=ou.OPER_UNIT_KEY
left join P_DM_COMMON.GL_PRODUCT_DIM gl ON tf.GL_PRODUCT_KEY=gl.GL_PRODUCT_KEY
left join P_DM_COMMON.ORACLE_GL_PRODUCT_DIM ogl on tf.ORACLE_GL_PRODUCT_KEY=ogl.ORACLE_GL_PRODUCT_KEY
INNER JOIN P_DM_BKG_LODG.TPID_CURRN_DIM tc ON (tc.TPID_CURRN_KEY=tf.TPID_CURRN_KEY)
INNER JOIN P_DM_BKG_LODG.COST_CURRN_DIM cc ON (cc.COST_CURRN_KEY=tf.COST_CURRN_KEY)
INNER JOIN P_DM_LODG_PROPERTY.LODG_RATE_PLN_DIM rp ON (tf.LODG_RATE_PLN_KEY=rp.LODG_RATE_PLN_KEY)
inner join use_case u on tf.bkg_itm_id = u.txn_identifier
where tf.trans_date_key >= '2024-03-01' 


 
--BOOKING AMOUNT TABLE QUERY
--TRL_QUERY_FILTER column provides filter to use in TaxRateLog query on NRT database.  Includes both TRL ID and SkuGroupID to eliminate false matches.
select u.use_case, cls.MONETARY_CLASS_NAME,CLS.MONETARY_CLASS_DESC, 
CALC.MONETARY_CALC_SYS_NAME, CALC.MONETARY_CALC_SYS_DESC,
tf.ORDER_NBR, tf.POS_ORDER_REF_NBR, tf.EXPE_LODG_PROPERTY_ID,
ba.* , 
tf.BK_DATE_KEY bk_date, fxc.EXCH_RATE, (ba.COST_AMT_LOCAL*fxc.EXCH_RATE) COST_AMT_PRICE_CURRN,
(PRICE_AMT_LOCAL-(ba.COST_AMT_LOCAL*fxc.EXCH_RATE)) MRGN_AMT_PRICE_CURRN
from P_ADS_bkg.bkg_amt ba
LEFT join P_ADS_BKG.MONETARY_CLASS cls ON CLS.MONETARY_CLASS_ID=ba.MONETARY_CLASS_ID
LEFT JOIN P_ADS_BKG.MONETARY_CALC_SYS CALC ON CALC.MONETARY_CALC_SYS_ID=ba.MONETARY_CALC_SYS_ID
JOIN (SELECT DISTINCT BKG_ITM_ID,ORDER_NBR,POS_ORDER_REF_NBR,TPID, BK_DATE_KEY,EXPE_LODG_PROPERTY_ID 
	from P_DM_bkg_lodg.lodg_rm_trans_fact tf
	left join P_DM_LODG_PROPERTY.LODG_PROPERTY_DIM p ON (p.LODG_PROPERTY_KEY=tf.LODG_PROPERTY_KEY)
	)tf on ba.BKG_ITM_ID=tf.BKG_ITM_ID and ba.TPID=tf.TPID
JOIN P_ADS_COMMON.DAILY_EXCH_RATE fxc on ba.LOCAL_COST_CURRN_CODE=fxc.FROM_CURRN_CODE and tf.BK_DATE_KEY=fxc.exch_rate_date and fxc.TO_CURRN_CODE=ba.LOCAL_PRICE_CURRN_CODE
inner join use_case u on tf.bkg_itm_id = u.txn_identifier
where ba.CREATE_DATETM>='2024-03-01 00:00:00'


--PAYMENT
with tf as 
(select distinct use_case, tpid, trl from P_DM_bkg_lodg.lodg_rm_trans_fact tf
	inner join use_case u on tf.bkg_itm_id = u.txn_identifier)
select tf.use_case, fp.FORM_OF_PAYMNT_NAME, 
py.PAYMNT_ID,
py.PAYMNT_DESC,
py.PAYMNT_CURRN_CODE,
py.PAYMNT_AMT
--py.* 
from P_ADS_PAYMNT.PAYMNT py
join P_ADS_PAYMNT.FORM_OF_PAYMNT fp on py.FORM_OF_PAYMNT_ID=fp.FORM_OF_PAYMNT_ID
inner join tf on tf.trl=py.trl and tf.tpid=py.tpid