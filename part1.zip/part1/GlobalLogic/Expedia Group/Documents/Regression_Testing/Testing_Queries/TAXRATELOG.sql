--TAX RATE LOG QUERIES
--PROD
TRL: https://querybook.expedia.biz/egdp/query_execution/4815387/

--MAUI
TRL: https://querybook-test.expedia.biz/egdp/query_execution/192735/
ROOM RATE: https://querybook-test.expedia.biz/egdp/query_execution/197600/



-------------------------------------------------------------------------------------------------------------------------------
--ALL OF THE BELOW HAS BEEN DEPRECATED, TRL IS NOW ONLY AVAILABLE IN EGAP
-------------------------------------------------------------------------------------------------------------------------------

--PROD
--MOPOPS: USE FOLLOWING TO PULL FROM LINKED SERVER

select * from  [CHWXSQLNRT107.DATAWAREHOUSE.EXPECN.COM].[LodgingInventoryImp].[dbo].[TaxRateLog] 
where TaxRateLogID in (

)

--MAUI
--LOGIN TO chelsqldsplz002

select * from  [LodgingInventoryImp].[dbo].[TaxRateLog] (nolock)
where (TaxRateLogID= 276162537 and SkuGroupID= 35782716)
OR (TaxRateLogID= 276162538 and SkuGroupID= 35782716)
OR (TaxRateLogID= 276162539 and SkuGroupID= 35782716)
OR (TaxRateLogID= 276162540 and SkuGroupID= 35782716)
OR (TaxRateLogID= 234062509 and SkuGroupID= 20976)
OR (TaxRateLogID= 234062512 and SkuGroupID= 20976)
OR (TaxRateLogID= 234062508 and SkuGroupID= 20976)
OR (TaxRateLogID= 234062511 and SkuGroupID= 20976)
OR (TaxRateLogID= 234062507 and SkuGroupID= 20976)
OR (TaxRateLogID= 234062508 and SkuGroupID= 20976)
OR (TaxRateLogID= 234062511 and SkuGroupID= 20976)
OR (TaxRateLogID= 234062512 and SkuGroupID= 20976)
OR (TaxRateLogID= 234062510 and SkuGroupID= 20976)
OR (TaxRateLogID= 234062507 and SkuGroupID= 20976)
OR (TaxRateLogID= 203525501 and SkuGroupID= 41917)
OR (TaxRateLogID= 203525500 and SkuGroupID= 41917)
OR (TaxRateLogID= 203525502 and SkuGroupID= 41917)
OR (TaxRateLogID= 203525502 and SkuGroupID= 41917)
OR (TaxRateLogID= 203525501 and SkuGroupID= 41917)
OR (TaxRateLogID= 203525500 and SkuGroupID= 41917)
OR (TaxRateLogID= 324985055 and SkuGroupID= 35787579)
OR (TaxRateLogID= 324985055 and SkuGroupID= 35787579)
OR (TaxRateLogID= 324985054 and SkuGroupID= 35787579)
OR (TaxRateLogID= 324985055 and SkuGroupID= 35787579)
OR (TaxRateLogID= 324985054 and SkuGroupID= 35787579)
OR (TaxRateLogID= 324985055 and SkuGroupID= 35787579)
OR (TaxRateLogID= 276162540 and SkuGroupID= 35782716)
OR (TaxRateLogID= 324985055 and SkuGroupID= 35787579)
OR (TaxRateLogID= 324985054 and SkuGroupID= 35787579)
OR (TaxRateLogID= 234062509 and SkuGroupID= 20976)
OR (TaxRateLogID= 276162537 and SkuGroupID= 35782716)
OR (TaxRateLogID= 276162538 and SkuGroupID= 35782716)
OR (TaxRateLogID= 324985055 and SkuGroupID= 35787579)
OR (TaxRateLogID= 324985054 and SkuGroupID= 35787579)
OR (TaxRateLogID= 324985054 and SkuGroupID= 35787579)
OR (TaxRateLogID= 234062510 and SkuGroupID= 20976)
OR (TaxRateLogID= 276162536 and SkuGroupID= 35782716)
OR (TaxRateLogID= 276162539 and SkuGroupID= 35782716)
OR (TaxRateLogID= 276162536 and SkuGroupID= 35782716)
OR (TaxRateLogID= 324985054 and SkuGroupID= 35787579)



--MAUI TRL REFRESH ISSUES
--check the refresh metadata
select top 10 *
from lodginginventoryimp..dssimporthistory (nolock)
where objectname = 'taxratelog'
order by createddate desc
--Check with #daps-etl-support if data needs to be refreshed (per Quin Arnold)
--let them know this is maui LLZ, they should know that this runs on https://emsbuctst