 --CAR RENTAL TRANS FACT
 SELECT                                                                                         
tf.*,
lg.LGL_ENTITY_NAME,
lg.LGL_ENTITY_CODE,
 t.tpid_name,
 t.tpid_cntry_name,                                                                                                                                                                  
 p.BUSINESS_MODEL_NAME,
 p.BUSINESS_MODEL_SUBTYP_NAME,
  pu.CAR_PICK_UP_LOC_CNTRY_CODE, 
		 pu.CAR_PICK_UP_LOC_STATE_PROVNC_NAME,
		 pu.CAR_PICK_UP_LOC_CITY_NAME,
		 cvd.CAR_VNDR_NAME
                                                                                                
       FROM P_DM_BKG_CAR.CAR_RENTL_TRANS_FACT tf                                                                                            
          INNER JOIN P_DM_COMMON.BKG_IND_DIM b ON (b.BKG_IND_KEY=tf.BKG_IND_KEY)                                                                                     
          INNER JOIN P_DM_COMMON.PRODUCT_LN_DIM p ON (p.PRODUCT_LN_KEY=tf.PRODUCT_LN_KEY)                                                                                  
          INNER JOIN P_DM_BKG_CAR.CAR_PICK_UP_LOC_DIM pu ON (pu.CAR_PICK_UP_LOC_KEY=tf.CAR_PICK_UP_LOC_KEY)                                                                                   
          INNER JOIN P_DM_COMMON.TPID_DIM t on t.tpid=tf.tpid   
		 INNER JOIN P_DM_COMMON.LGL_ENTITY_DIM lg ON (tf.LGL_ENTITY_KEY=lg.LGL_ENTITY_KEY)
		 JOIN P_DM_BKG_CAR.CAR_VNDR_DIM cvd	ON (tf.CAR_VNDR_KEY = cvd.CAR_VNDR_KEY)
		  
	 WHERE                                                                                   
          bkg_itm_id in (143006220,143006551)
			and trans_date_key >='2022-04-01'  
			
--BOOKING AMOUNT TABLE
select cls.MONETARY_CLASS_NAME,CLS.MONETARY_CLASS_DESC, 
CALC.MONETARY_CALC_SYS_NAME, CALC.MONETARY_CALC_SYS_DESC,ba.* 
from P_ads_bkg.bkg_amt ba
LEFT join P_ADS_BKG.MONETARY_CLASS cls ON CLS.MONETARY_CLASS_ID=ba.MONETARY_CLASS_ID
LEFT JOIN P_ADS_BKG.MONETARY_CALC_SYS CALC ON CALC.MONETARY_CALC_SYS_ID=ba.MONETARY_CALC_SYS_ID
where CREATE_DATETM>='2022-03-01 00:00:00'
and bkg_itm_id in (674340,674346,674349,674343,674344,674342)