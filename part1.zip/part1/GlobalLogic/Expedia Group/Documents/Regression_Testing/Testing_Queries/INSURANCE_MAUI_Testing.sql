--INSURANCE
	SELECT 		
	itf.BKG_ITM_ID,
	itf.BKG_ID,
	itf.ITIN_NBR,
	itf.ORDER_NBR,
	itf.TRANS_DATE_KEY,
	itf.BK_DATE_KEY,
	itf.BEGIN_USE_DATE_KEY,
	itf.END_USE_DATE_KEY,
	itf.TPID,
	itf.TRL,
	itf.INS_ITM_CNT,
	tt.TRANS_TYP_NAME,
	lg.LGL_ENTITY_NAME,
	     lg.LGL_ENTITY_CODE, 
		 tpid.tpid_name,
         tpid.tpid_cntry_name,                                                                  
         pld.BUSINESS_MODEL_NAME,                                                               
          rd.ORIGN_REGN_NAME,
          ov.INS_OFFRNG_VNDR_NAME,
          oi.INS_OFFRNG_ITM_NAME,
          oid.INS_OFFRNG_VNDR_BRNCH_CNTRY_CODE,
          oid.INS_OFFRNG_VNDR_BRNCH_STATE_PROVNC_NAME,
          oid.INS_OFFRNG_VNDR_BRNCH_CITY_NAME,
          itf.GROSS_BKG_AMT_USD,
itf.GROSS_BKG_AMT_LOCAL,
itf.BASE_PRICE_AMT_USD,
itf.BASE_PRICE_AMT_LOCAL,
itf.TOTL_PRICE_ADJ_AMT_USD,
itf.TOTL_PRICE_ADJ_AMT_LOCAL,
itf.TOTL_FEE_PRICE_AMT_USD,
itf.TOTL_FEE_PRICE_AMT_LOCAL,
itf.TOTL_TAX_PRICE_AMT_USD,
itf.TOTL_TAX_PRICE_AMT_LOCAL,
itf.TOTL_COST_AMT_USD,
itf.TOTL_COST_AMT_LOCAL,
itf.BASE_COST_AMT_USD,
itf.BASE_COST_AMT_LOCAL,
itf.TOTL_COST_ADJ_AMT_USD,
itf.TOTL_COST_ADJ_AMT_LOCAL,
itf.TOTL_FEE_COST_AMT_USD,
itf.TOTL_FEE_COST_AMT_LOCAL,
itf.TOTL_TAX_COST_AMT_USD,
itf.TOTL_TAX_COST_AMT_LOCAL,
itf.MARGN_AMT_USD
          --io.INS_OFFRNG_VNDR_NAME,
          --io.INS_OFFRNG_VNDR_BRNCH_CNTRY_CODE,
          --io.INS_OFFRNG_VNDR_BRNCH_STATE_PROVNC_NAME,
          --io.INS_OFFRNG_VNDR_BRNCH_CITY_NAME
	
       FROM I_DM_COMMON.ORIGN_REGN_DIM rd                                                              
       INNER JOIN I_DM_BKG_INS.INS_ITM_TRANS_FACT itf       ON(rd.ORIGN_REGN_KEY=itf.ORIGN_REGN_KEY)                                                                     
       INNER JOIN I_DM_COMMON.PRODUCT_LN_DIM pld ON (pld.PRODUCT_LN_KEY=itf.PRODUCT_LN_KEY)                                                                
       INNER JOIN I_DM_COMMON.TPID_DIM tpid ON (tpid.TPID=itf.TPID)                                                                   
	   INNER JOIN I_DM_COMMON.LGL_ENTITY_DIM lg ON (itf.LGL_ENTITY_KEY=lg.LGL_ENTITY_KEY)
	   INNER JOIN I_DM_COMMON.TRANS_TYP_DIM tt ON itf.TRANS_TYP_KEY = tt.TRANS_TYP_KEY
	   left join i_dm_common.dest_regn_dim dr ON itf.DEST_REGN_KEY = dr.DEST_REGN_KEY
	   LEFT JOIN I_ADS_BKG.INS_BKG_ITM ii ON itf.BKG_ITM_ID = ii.BKG_ITM_ID
	   LEFT JOIN I_ADS_BKG.INS_OFFRNG_ITM oi ON ii.OFFRNG_ID = oi.INS_OFFRNG_ITM_ID
	   LEFT JOIN I_ADS_BKG.INS_OFFRNG_VNDR ov ON oi.INS_OFFRNG_VNDR_ID = ov.INS_OFFRNG_VNDR_ID
	   LEFT JOIN I_DM_BKG_INS.INS_OFFRNG_ITM_DIM oid ON oi.INS_OFFRNG_ITM_ID = oid.INS_OFFRNG_ITM_ID

       --JOIN I_DM_BKG_INS.INS_OFFRNG_ITM_DIM io on itf.INS_OFFRNG_ITM_KEY=io.INS_OFFRNG_ITM_KEY  --NO DATA

		                                                                    
       WHERE                                                                      
        itf.TRANS_DATE_KEY  BETWEEN '2023-07-01' AND '2023-12-31'     
        AND ITIN_NBR IN 
        (
        7605756219099
        );