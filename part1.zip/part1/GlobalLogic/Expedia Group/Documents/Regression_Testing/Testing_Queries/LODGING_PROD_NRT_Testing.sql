--BOOKING DATA FROM NRT ENVIRONMENT

--How to find BKG_ITM_ID and other information from splunk logs
--1. Use Alfred-Prod app in Slack (add app if needed)
	--a. Message the app: /alfred-prod to invoke the app
	--b. Select one of the buttons, based on the available identifier 
	--c. Enter the identifier, which will return the splunk log.  
	--d. Download and open with Notepad++ or other to text search the info, such as BookingItemID.  Note: basic Notepad cannot search the Splunk format.

--LOG INTO MOPOPS AND USE BELOW LINKED SERVER FOR NRT BOOKING DATA

select *   FROM [LodgingBooking_DNRT.DATAWAREHOUSE.EXPECN.COM].[LodgingBooking].[dbo].[BookingAmount]
  Where BookingItemID in ()

select *   FROM [LodgingBooking_DNRT.DATAWAREHOUSE.EXPECN.COM].[LodgingBooking].[dbo].[BookingItem]
  Where BookingItemID in ()
  
  