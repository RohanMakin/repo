package com.expediagroup.platform.taxcompliance.trigger

import com.expediagroup.platform.taxcompliance.util.DataUtil
import com.expediagroup.platform.taxcompliance.sql.SQLColumnHelper
import org.apache.spark.sql.{DataFrame, SparkSession, functions}
import org.slf4j.LoggerFactory

class DataSyncStatusCheckerOperationImpl(var tableName: String = "", var replicationTableName: String = "") extends DataSyncStatusCheckerOperation {

    private val LOGGER = LoggerFactory.getLogger(this.getClass)

    val federatedDailyExchangeRateTable: String = "egdp_classic_booking.daily_exch_rate"
    val VrboBookingEventsProperty: String = "egdp_apiary_payments.vrbo_entity_event_booking_event_topic_v2"

    override def checkIfUpstreamSyncIsComplete(replicationDate: String, sqlc: SparkSession, productLineName:String) = {
        val dfToWrite = getReplicationDF(sqlc, replicationTableName, replicationDate)
        if(dfToWrite == null || dfToWrite.count()  == 0 ) {
            throw new Exception("Latest Replication status not Available from table property");
        }
        val replicationEndTime = dfToWrite.first().getAs(SQLColumnHelper.REPLICATION_END_TIME).asInstanceOf[String]
        if (replicationEndTime == null) {
            throw new Exception("Latest Replication status not Available from table property");
        }
        var replicationDateFromTable = ""
        var replicationDateToCompare = ""
        if(tableName.equals(federatedDailyExchangeRateTable)){
            replicationDateFromTable = replicationEndTime
            replicationDateToCompare = DataUtil.getPreviousDayDate(replicationDate)
        } else{
            replicationDateFromTable = DataUtil.convertDateTimeToPstDate(replicationEndTime);
            replicationDateToCompare = replicationDate
        }

        if (replicationDateToCompare.compareTo(replicationDateFromTable) > 0) {
            val exceptionMessage =
                new StringBuilder(replicationDateToCompare)
                    .append(" provided is greater  than the latest replication date found in table property")
                    .append(replicationDateFromTable)
                    .append(": This means sync is not completed for given replication date: ")
                    .append(replicationDateToCompare)
                    .append(" for table ")
                    .append(tableName).toString()
            throw new Exception(exceptionMessage);
        }
        else if (replicationDateToCompare.compareTo(replicationDateFromTable) == 0) {
            val message =
                new StringBuilder(replicationDateToCompare)
                    .append(" provided is equal to latest replication date found in table property")
                    .append(replicationDateFromTable)
                    .append(": This means sync is completed for given replication date: ")
                    .append(replicationDateToCompare)
                    .append(" for table ")
                    .append(tableName).toString()
            LOGGER.info(message)
        }
        else {
            val message =
                new StringBuilder(replicationDateToCompare)
                    .append(" provided is less than the latest replication date found in table property")
                    .append(replicationDateFromTable)
                    .append(": This means sync is completed for given replication date: ")
                    .append(replicationDateToCompare)
                    .append(" for table ")
                    .append(tableName).toString()
            LOGGER.info(message)
        }
        if(!tableName.equals(federatedDailyExchangeRateTable)){
            dfToWrite.createOrReplaceTempView("tblProperty")
        }
    }

    private def getReplicationDF( sqlc: SparkSession, replicationTable: String, replicationDate:String):DataFrame= {
        if(federatedDailyExchangeRateTable.nonEmpty && tableName.nonEmpty
            && tableName.equals(federatedDailyExchangeRateTable)) {
            sqlc.sql(raw"""
                select
                    MAX(exch_rate_date) as `${SQLColumnHelper.REPLICATION_END_TIME}`,
                    count(*) AS `${SQLColumnHelper.REPLICATION_COUNT}`,
                    'FULL' as `${SQLColumnHelper.REPLICATION_MODE}`
                from ${tableName}
                where to_currn_code = 'USD'
                and exch_rate_date = CAST(date_sub('${replicationDate}', 1) AS Date)
        """)
        } else if (VrboBookingEventsProperty.nonEmpty && tableName.nonEmpty
            && tableName.equals(VrboBookingEventsProperty)) {
            sqlc.sql(raw"""
                    select
                        MAX(acquisition_date) as `${SQLColumnHelper.REPLICATION_END_TIME}`,
                        count(*) AS `${SQLColumnHelper.REPLICATION_COUNT}`,
                        'FULL' as `${SQLColumnHelper.REPLICATION_MODE}`
                    from ${tableName}
                """)
        }
        else{
            sqlc.sql(raw"""
	            select
                    MAX(time_of_completion) as `${SQLColumnHelper.REPLICATION_END_TIME}`,
                    count(*) AS `${SQLColumnHelper.REPLICATION_COUNT}`,
                    'FULL' as `${SQLColumnHelper.REPLICATION_MODE}`,
                    table_name
                from ${replicationTable}
                WHERE  CAST(time_of_completion AS Date) = CAST('${replicationDate}' AS Date)
                AND table_name LIKE '${tableName.split("\\.")(1)}'
                GROUP BY table_name
	     """)
        }

    }

}
