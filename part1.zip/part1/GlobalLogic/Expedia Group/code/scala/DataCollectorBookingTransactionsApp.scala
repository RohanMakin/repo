package com.expediagroup.platform.taxcompliance.td_connect

import com.expediagroup.platform.taxcompliance.DataCollectorApp.readHqlFile
import com.expediagroup.platform.taxcompliance.aws.secret.DataCollectorConfigAWS
import com.expediagroup.platform.taxcompliance.config.ExceptionLogger
import com.expediagroup.platform.taxcompliance.constants.AppConstants
import com.expediagroup.platform.taxcompliance.constants.AppConstants._
import com.expediagroup.platform.taxcompliance.sql._
import com.expediagrouplatform.taxcompliance.sql.SQLColumnHelperPostStayTransactionsLodging
import org.apache.spark.sql.SparkSession.setActiveSession
import org.apache.spark.sql.functions.{col, lit, struct}
import org.apache.spark.sql.{DataFrame, SparkSession}
import org.slf4j.LoggerFactory
import org.springframework.beans.factory.annotation.{Autowired, Value}
import org.springframework.stereotype.Component
import com.expediagroup.platform.taxcompliance.sql.{SQLBuilder, SQLColumnHelper}

import java.util

@Component
class DataCollectorBookingTransactionsApp {

    private val LOGGER = LoggerFactory.getLogger(this.getClass)

    var sqlBuilder = new SQLBuilder()

    @Value("${com.expediagroup.platform.taxcompliance.url.prod}")
    val prodUrl: String = null

    @Value("${com.expediagroup.platform.taxcompliance.url.nonprod}")
    val nonProdUrl: String = null

    @Value("${com.expediagroup.platform.taxcompliance.lodg_rate_pln_dim_legacy.table}")
    val lodgRatePlnDimLegacy: String = null

    def TeradataSparkConnection(args: Array[String]): Unit = {
        LOGGER.info("Starting main....")

        val run_env = args(0)
        val run_id = args(1)
        val transaction_start_date = args(2)
        val transaction_end_date = args(3)
        val product_line = args(4).toString().toLowerCase().replaceAll("_", " ")
        val script_name = args(5)
        val s3_bucket = args(6)
        val url = if (s3_bucket == AppConstants.S3_DATA_BUCKET) prodUrl else nonProdUrl
        val script_path = if (s3_bucket == AppConstants.S3_DATA_BUCKET) RESOURCE_SCRIPT_COMMON_PATH + AppConstants.GTP_PROD else RESOURCE_SCRIPT_COMMON_PATH + run_env
        val lodg_rate_pln_dim_legacy = if (s3_bucket == AppConstants.S3_DATA_BUCKET) AppConstants.BEXG_PROD_DM + lodgRatePlnDimLegacy else AppConstants.BEXG_TEST_DM + lodgRatePlnDimLegacy

        LOGGER.info("Run Environment: " + run_env)
        LOGGER.info("Run ID: " + run_id)
        LOGGER.info("Transaction Start Date: " + transaction_start_date)
        LOGGER.info("Transaction End Date: " + transaction_end_date)
        LOGGER.info("Product Line Name: " + product_line)
        LOGGER.info("Script Name: " + script_name)
        LOGGER.info("URL: " + url)
        LOGGER.info("scriptPath: " + script_path)
        LOGGER.info("s3_bucket: " + s3_bucket)
        LOGGER.info("lodg_rate_pln_dim_legacy: " + lodg_rate_pln_dim_legacy)

        LOGGER.info("Creating TeradataSparkConnection")

        val sparkSession = getSparkSession()
        LOGGER.isInfoEnabled
        LOGGER.trace("Spark Session Created....")
        setActiveSession(sparkSession)

        LOGGER.info("Secret Manager execution started")
        val dataCollectorSecrets = new DataCollectorConfigAWS()
        val userCredentials: java.util.List[String] = new util.ArrayList[String]
        fetchCredentials(userCredentials, dataCollectorSecrets.populateDataCollectorConfigAWS())
        executeReadDataCollectorTransactionQuery(sparkSession, url, userCredentials.get(0), userCredentials.get(1),
            run_id, transaction_start_date, transaction_end_date, product_line, script_path, script_name, lodg_rate_pln_dim_legacy)

        //stop spark session
        sparkSession.stop()
    }


    def createTeradataJDBCConnectionWithSpark(spark: SparkSession, url: String, userName: String, userPassword: String, query_args: String): DataFrame = {

        LOGGER.info("Starting Again createTeradataJDBCConnectionWithSpark!!!")
        LOGGER.info("data-collector Script Execution Started...")
        val startTime: Long = System.currentTimeMillis()
        LOGGER.info("createTeradataJDBCConnectionWithSpark startTime == " + startTime)

        val td_conn_read_df = spark.read.format("jdbc")
            .option("url", url)
            .option("query", query_args)
            .option("user", userName)
            .option("password", userPassword)
            .option("driver", "com.teradata.jdbc.TeraDriver")
            .load()
        LOGGER.info("SPARK-jdbc Connection Created with Teradata Instance!!!")
        LOGGER.info("createTeradataJDBCConnectionWithSpark Total Time taken  == " + (System.currentTimeMillis() - startTime))

        td_conn_read_df
    }

    /**
     * this method is used for loading the data from Teradata and doing the require operation for inserting the data for (LX,Car,Lodging)
     */
    def executeReadDataCollectorTransactionQuery(spark: SparkSession, url: String, userName: String, userPassword: String,
                                                 run_id: String, transaction_start_date: String, transaction_end_date: String,
                                                 product_line: String, script_path: String, script_name: String, lodg_rate_pln_dim_legacy: String): Unit = {

        if (product_line.equalsIgnoreCase(AppConstants.PRODUCT_LINE_NAME_LX) && script_name == AppConstants.STAGED_BOOKING_TRANSACTIONS) {

            val query_stg_bkg_fact_lx = readHqlFile(script_path + STAGED_BOOKING_TRANSACTIONS_TD_LX).format(transaction_start_date)
            LOGGER.info("STAGED_BOOKING_TRANSACTIONS_TD_LX" + " " + script_path + STAGED_BOOKING_TRANSACTIONS_TD_LX)
            LOGGER.info("++++++++++++++++ Read Query Script: query_stg_bkg_fact_lx ++++++++++++++++ \n" + query_stg_bkg_fact_lx)

            try {
                //Teradata JDBC connection
                val df_stg_bkg_fact_lx = createTeradataJDBCConnectionWithSpark(spark, url, userName, userPassword, query_stg_bkg_fact_lx)
                df_stg_bkg_fact_lx.createOrReplaceTempView("temp_stg_bkg_fact_lx_view")
                LOGGER.info("Read Query Script: query_stg_bkg_fact_lx execution completed....")
            }

            catch {
                case e: Exception =>
                    ExceptionLogger.logException("df_stg_bkg_fact_lx", e)
                    throw e
            }

            val query_stg_bkg_pos_dim_td_lx = readHqlFile(script_path + STAGED_BOOKING_TRANSACTIONS_POS_DIM_TD_LX)
            LOGGER.info("STAGED_BOOKING_TRANSACTIONS_POS_DIM_TD_LX" + " " + script_path + STAGED_BOOKING_TRANSACTIONS_POS_DIM_TD_LX)
            LOGGER.info("++++++++++++++++ Read Query Script: query_stg_bkg_pos_dim_td_lx ++++++++++++++++ \n" + query_stg_bkg_pos_dim_td_lx)

            try {
                //Teradata JDBC connection
                val df_td_pos_dim_tbl = createTeradataJDBCConnectionWithSpark(spark, url, userName, userPassword, query_stg_bkg_pos_dim_td_lx)
                df_td_pos_dim_tbl.createOrReplaceTempView("temp_pos_dim_tbl_view")
                LOGGER.info("Read Query Script: query_stg_bkg_pos_dim_td_lx execution completed ....")
            }

            catch {
                case e: Exception =>
                    ExceptionLogger.logException("df_td_pos_dim_tbl", e)
                    throw e
            }

            val query_stg_bkg_egdp_apiary_lx = readHqlFile(script_path + STAGED_BOOKING_TRANSACTIONS_DATALAKE_LX)
            LOGGER.info("STAGED_BOOKING_TRANSACTIONS_DATALAKE_LX" + " " + script_path + STAGED_BOOKING_TRANSACTIONS_DATALAKE_LX)
            LOGGER.info("++++++++++++++++ Read Query Script: query_stg_bkg_egdp_apiary_lx ++++++++++++++++ \n" + query_stg_bkg_egdp_apiary_lx)

            func_egdp_apiary_datalake_tbl_lx_1(spark, query_stg_bkg_egdp_apiary_lx)

            try {
                val df_apiary_datalake_pos = sqlBuilder.get_apiary_datalake_view_data(spark)
                df_apiary_datalake_pos.createOrReplaceTempView("temp_apiary_datalake_pos_view")
            }

            catch {
                case e: Exception =>
                    ExceptionLogger.logException("df_apiary_datalake_pos", e)
                    throw e
            }

            try {
                val df_lx_join_query = sqlBuilder.fetch_bkg_lx_apiary_datalake_view_data(spark)

                LOGGER.info("Dataframe: df_lx_join_query created")
                df_lx_join_query.createOrReplaceTempView("temp_df_lx_view")
            }

            catch {
                case e: Exception =>
                    ExceptionLogger.logException("df_lx_join_query", e)
                    throw e
            }

            //Read Query
            try {
                LOGGER.info("--------------LX_STAGE_BOOKING_READ_QUERY--------------\n"
                    + SQLColumnHelperBookingTransactionsLx.LX_STAGE_BOOKING_READ_QUERY)
                val df_lx_read_query = sqlBuilder.get_df_lx_view_data(spark)
                LOGGER.info("Dataframe: df_lx_read_query created")

                val df_updated_run_id_struct: DataFrame = generate_run_id(run_id, df_lx_read_query)

                df_updated_run_id_struct.createOrReplaceTempView("temp_df_updated_run_id_struct")

                executeInsertIntoDataCollectorTransactionQuery(spark, product_line, script_name, transaction_start_date)
            }

            catch {
                case ex: Exception =>
                    ExceptionLogger.logException("df_lx_read_query", ex)
                    throw ex

            }

        }

        else if (product_line.equalsIgnoreCase(AppConstants.PRODUCT_LINE_NAME_LX) && script_name == AppConstants.POST_USE_TRANSACTIONS) {

            //Code logic - POST_USE_TRANSACTIONS_STAGE_BOOKING_TD_LX
            val query_post_use_fact_lx = readHqlFile(script_path + POST_USE_TRANSACTIONS_STAGE_BOOKING_TD_LX).format(transaction_start_date, transaction_end_date)
            LOGGER.info("+++++++++++POST_USE_TRANSACTIONS_STAGE_BOOKING_TD_LX" + " " + script_path + POST_USE_TRANSACTIONS_STAGE_BOOKING_TD_LX)
            LOGGER.info("++++++++++++++++ Read Query Script: query_post_use_fact_lx ++++++++++++++++ \n" + query_post_use_fact_lx)
            try {
                //Teradata JDBC connection
                val df_post_use_fact_lx = createTeradataJDBCConnectionWithSpark(spark, url, userName, userPassword, query_post_use_fact_lx)
                df_post_use_fact_lx.createOrReplaceTempView("temp_post_use_fact_lx_view")
                LOGGER.info("Read Query Script: query_post_use_fact_lx execution completed....")
                LOGGER.info("Debug check 1")
                System.out.println("Debug check 1")
                val tmp = spark.sql("select * from temp_post_use_fact_lx_view f " +
                    "where f.bkg_itm_id IN (93192116,93192117,93269003,93269004,93337563,93337564)")
                tmp.show(truncate = false)
            }
            catch {
                case e: Exception =>
                    ExceptionLogger.logException("df_post_use_fact_lx", e)
                    throw e
            }

            val query_post_use_pos_dim_td_lx = readHqlFile(script_path + POST_USE_TRANSACTIONS_POS_DIM_TD_LX)
            LOGGER.info("POST_USE_TRANSACTIONS_POS_DIM_TD_LX" + script_path + POST_USE_TRANSACTIONS_POS_DIM_TD_LX)
            LOGGER.info("++++++++++++++++ Read Query Script: query_post_use_pos_dim_td_lx ++++++++++++++++ \n" + query_post_use_pos_dim_td_lx)
            try {
                //Teradata JDBC connection
                val df_td_pos_dim_tbl = createTeradataJDBCConnectionWithSpark(spark, url, userName, userPassword, query_post_use_pos_dim_td_lx)
                df_td_pos_dim_tbl.createOrReplaceTempView("temp_pos_dim_tbl_view")
                LOGGER.info("Read Query Script: query_post_use_pos_dim_td_lx execution completed ....")
            }
            catch {
                case e: Exception =>
                    ExceptionLogger.logException("df_td_pos_dim_tbl", e)
                    throw e
            }

            val query_post_use_egdp_apiary_lx = readHqlFile(script_path + POST_USE_TRANSACTIONS_DATALAKE_LX)
            LOGGER.info("POST_USE_TRANSACTIONS_DATALAKE_LX" + script_path + POST_USE_TRANSACTIONS_DATALAKE_LX)
            LOGGER.info("++++++++++++++++ Read Query Script: query_post_use_egdp_apiary_lx ++++++++++++++++ \n" + query_post_use_egdp_apiary_lx)
            func_egdp_apiary_datalake_tbl_lx_2(spark, query_post_use_egdp_apiary_lx)
            try {
                val df_apiary_datalake_pos = sqlBuilder.get_apiary_datalake_view_data(spark)
                df_apiary_datalake_pos.createOrReplaceTempView("temp_apiary_datalake_pos_view")
            }
            catch {
                case e: Exception =>
                    ExceptionLogger.logException("df_apiary_datalake_pos", e)
                    throw e
            }

            try {
                val df_lx_join_query = sqlBuilder.get_post_use_lx_join_view_data(spark)

                LOGGER.info("Dataframe: df_lx_join_query created")
                df_lx_join_query.createOrReplaceTempView("temp_df_lx_view")
                LOGGER.info("Debug check 2")
                System.out.println("Debug check 2")
                val tmp = spark.sql("select * from temp_df_lx_view f " +
                    "where f.bkg_itm_id IN (93192116,93192117,93269003,93269004,93337563,93337564)")
                tmp.show(truncate = false)
            }
            catch {
                case e: Exception =>
                    ExceptionLogger.logException("df_lx_join_query", e)
                    throw e
            }

            //Read Query - LX_STAGE_BOOKING_POST_USE_READ_QUERY
            try {
                LOGGER.info("--------------LX_STAGE_BOOKING_POST_USE_READ_QUERY--------------\n"
                    + SQLColumnHelperPostUseTransactionsLx.LX_STAGE_BOOKING_POST_USE_READ_QUERY)
                val df_lx_read_query = sqlBuilder.get_lx_stage_booking_post_use_data(spark)
                LOGGER.info("Dataframe: df_lx_read_query created")

                val df_updated_run_id_struct: DataFrame = generate_run_id(run_id, df_lx_read_query)

                df_updated_run_id_struct.createOrReplaceTempView("temp_df_post_use_stage_updated_run_id_struct")
                LOGGER.info("Debug check 3")
                System.out.println("Debug check 3")
                val tmp = spark.sql("select * from temp_df_post_use_stage_updated_run_id_struct f " +
                    "where f.booking_item_id IN (93192116,93192117,93269003,93269004,93337563,93337564)")
                tmp.show(truncate = false)
            }
            catch {
                case ex: Exception =>
                    ExceptionLogger.logException("df_lx_post_use_read_query", ex)
                    throw ex

            }

            //Code logic - POST_USE_TRANSACTIONS_PURCHASE_BOOKING_TD_LX
            val query_post_use_purchase_fact_lx = readHqlFile(script_path + POST_USE_TRANSACTIONS_PURCHASE_BOOKING_TD_LX).format(transaction_start_date)
            LOGGER.info("POST_USE_TRANSACTIONS_PURCHASE_BOOKING_TD_LX" + " " + script_path + POST_USE_TRANSACTIONS_PURCHASE_BOOKING_TD_LX)
            LOGGER.info("++++++++++++++++ Read Query Script: query_post_use_purchase_fact_lx ++++++++++++++++ \n" + query_post_use_purchase_fact_lx)
            try {
                //Teradata JDBC connection
                val df_post_use_purchase_fact_lx = createTeradataJDBCConnectionWithSpark(spark, url, userName, userPassword, query_post_use_purchase_fact_lx)
                df_post_use_purchase_fact_lx.createOrReplaceTempView("temp_post_use_purchase_fact_lx_view")
                LOGGER.info("Read Query Script: query_post_use_purchase_fact_lx execution completed....")
            }
            catch {
                case e: Exception =>
                    ExceptionLogger.logException("df_post_use_purchase_fact_lx", e)
                    throw e
            }

            //Read Query - LX_PURCHASE_BOOKING_POST_USE_READ_QUERY
            try {
                LOGGER.info("--------------LX_PURCHASE_BOOKING_POST_USE_READ_QUERY--------------\n"
                    + SQLColumnHelperPostUseTransactionsLx.LX_PURCHASE_BOOKING_POST_USE_READ_QUERY)
                val df_lx_purchase_read_query = sqlBuilder.get_lx_post_use_purchase_view_data(spark)
                LOGGER.info("Dataframe: df_lx_purchase_read_query created")

                df_lx_purchase_read_query.createOrReplaceTempView("temp_post_use_purchase_lx_view")

                executeInsertIntoDataCollectorTransactionQuery(spark, product_line, script_name, transaction_start_date)
            }
            catch {
                case ex: Exception =>
                    ExceptionLogger.logException("df_lx_purchase_read_query", ex)
                    throw ex

            }

        }

        else if (product_line.equalsIgnoreCase(AppConstants.PRODUCT_LINE_NAME_LX) && script_name == AppConstants.STAGED_BOOKING_TRANSACTIONS_BACKFILL) {

            val query_stg_bkg_backfill_fact_lx = readHqlFile(script_path + STAGED_BOOKING_TRANSACTIONS_BACKFILL_TD_LX).format(transaction_start_date, transaction_end_date)
            LOGGER.info("STAGED_BOOKING_TRANSACTIONS_BACKFILL_TD_LX" + " " + script_path + STAGED_BOOKING_TRANSACTIONS_BACKFILL_TD_LX)
            LOGGER.info("++++++++++++++++ Read Query Script: query_stg_bkg_backfill_fact_lx ++++++++++++++++ \n" + query_stg_bkg_backfill_fact_lx)

            try {
                //Teradata JDBC connection
                val df_stg_bkg_backfill_fact_lx = createTeradataJDBCConnectionWithSpark(spark, url, userName, userPassword, query_stg_bkg_backfill_fact_lx)
                df_stg_bkg_backfill_fact_lx.createOrReplaceTempView("temp_stg_bkg_backfill_fact_lx_view")
                LOGGER.info("Read Query Script: query_stg_bkg_backfill_fact_lx execution completed....")
            }

            catch {
                case e: Exception =>
                    ExceptionLogger.logException("df_stg_bkg_backfill_fact_lx", e)
                    throw e
            }

            val query_stg_bkg_backfill_pos_dim_td_lx = readHqlFile(script_path + STAGED_BOOKING_TRANSACTIONS_BACKFILL_POS_DIM_TD_LX)
            LOGGER.info("STAGED_BOOKING_TRANSACTIONS_BACKFILL_POS_DIM_TD_LX" + " " + script_path + STAGED_BOOKING_TRANSACTIONS_BACKFILL_POS_DIM_TD_LX)
            LOGGER.info("++++++++++++++++ Read Query Script: query_stg_bkg_backfill_pos_dim_td_lx ++++++++++++++++ \n" + query_stg_bkg_backfill_pos_dim_td_lx)

            try {
                //Teradata JDBC connection
                val df_td_pos_dim_tbl = createTeradataJDBCConnectionWithSpark(spark, url, userName, userPassword, query_stg_bkg_backfill_pos_dim_td_lx)
                df_td_pos_dim_tbl.createOrReplaceTempView("temp_pos_dim_tbl_view")
                LOGGER.info("Read Query Script: query_stg_bkg_backfill_pos_dim_td_lx execution completed ....")
            }

            catch {
                case e: Exception =>
                    ExceptionLogger.logException("df_td_pos_dim_tbl", e)
                    throw e

            }

            val query_stg_bkg_backfill_egdp_apiary_lx = readHqlFile(script_path + STAGED_BOOKING_TRANSACTIONS_BACKFILL_DATALAKE_LX)
            LOGGER.info("STAGED_BOOKING_TRANSACTIONS_BACKFILL_DATALAKE_LX" + " " + script_path + STAGED_BOOKING_TRANSACTIONS_BACKFILL_DATALAKE_LX)
            LOGGER.info("++++++++++++++++ Read Query Script: query_stg_bkg_backfill_egdp_apiary_lx ++++++++++++++++ \n" + query_stg_bkg_backfill_egdp_apiary_lx)

            func_egdp_apiary_datalake_tbl_lx_3(spark, query_stg_bkg_backfill_egdp_apiary_lx)

            try {
                val df_apiary_datalake_pos = sqlBuilder.get_apiary_datalake_view_data(spark)
                df_apiary_datalake_pos.createOrReplaceTempView("temp_apiary_datalake_pos_view")
            }

            catch {
                case e: Exception =>
                    ExceptionLogger.logException("df_apiary_datalake_pos", e)
                    throw e
            }

            try {
                val df_lx_join_query = sqlBuilder.get_lx_stg_bkg_join_view_data(spark)

                LOGGER.info("Dataframe: df_lx_join_query created")
                df_lx_join_query.createOrReplaceTempView("temp_df_lx_view")
            }

            catch {
                case e: Exception =>
                    ExceptionLogger.logException("df_lx_join_query", e)
                    throw e
            }

            //Read Query
            try {
                LOGGER.info("--------------LX_STAGE_BOOKING_BACKFILL_READ_QUERY--------------\n"
                    + SQLColumnHelperBookingTransactionsBackfillLx.LX_STAGE_BOOKING_BACKFILL_READ_QUERY)
                val df_lx_read_query = sqlBuilder.get_lx_stg_bkg_backfill_data(spark)
                LOGGER.info("Dataframe: df_lx_read_query created")

                val df_updated_run_id_struct: DataFrame = generate_run_id(run_id, df_lx_read_query)

                df_updated_run_id_struct.createOrReplaceTempView("temp_df_updated_run_id_struct")

                executeInsertIntoDataCollectorTransactionQuery(spark, product_line, script_name, transaction_start_date)
            }

            catch {
                case ex: Exception =>
                    ExceptionLogger.logException("df_lx_read_query", ex)
                    throw ex

            }

        }

        else if (product_line.equalsIgnoreCase(AppConstants.PRODUCT_LINE_NAME_CAR) && script_name == AppConstants.STAGED_BOOKING_TRANSACTIONS) {
            val query_stg_bkg_fact_car = readHqlFile(script_path + AppConstants.STAGED_BOOKING_TRANSACTIONS_TD_CARS).format(transaction_start_date)
            LOGGER.info("++++++++++++++++ Read Query Script: query_stg_bkg_fact_car ++++++++++++++++ \n" + query_stg_bkg_fact_car)

            try {
                //Teradata JDBC connection
                val df_stg_bkg_fact_car = createTeradataJDBCConnectionWithSpark(spark, url, userName, userPassword, query_stg_bkg_fact_car)
                df_stg_bkg_fact_car.createOrReplaceTempView("temp_stg_bkg_fact_car_view")
                LOGGER.info("Read Query Script: query_stg_bkg_fact_car execution completed....")
            }

            catch {
                case e: Exception =>
                    ExceptionLogger.logException("df_stg_bkg_fact_car", e)
                    throw e
            }


            /**
             * read query for car stage
             */
            try {
                LOGGER.info("--------------Car_STAGE_BOOKING_READ_QUERY--------------\n"
                    + SQLColumnHelperBookingTransactionsCar.Car_STAGE_BOOKING_READ_QUERY)
                val df_car_read_query = sqlBuilder.get_car_stg_bkg_data(spark)
                LOGGER.info("Dataframe: df_car_read_query created")

                df_car_read_query.select(col("event_info"), col("event_info.run_id"),
                    col("event_info.published_timestamp"), col("event_info.event_uuid"),
                    lit(run_id).alias("run_id")).show(1)

                df_car_read_query.select("event_info").show(1)

                val df_updated_run_id_struct = df_car_read_query.withColumn(SQLColumnHelperBookingTransactionsCar.EVENT_INFO_COLUMN,
                    struct(lit(run_id).alias("run_id"),
                        col(SQLColumnHelperBookingTransactionsCar.EVENT_INFO_COLUMN + ".published_timestamp").alias("published_timestamp"),
                        col(SQLColumnHelperBookingTransactionsCar.EVENT_INFO_COLUMN + ".event_uuid").alias("event_uuid")))

                df_updated_run_id_struct.select(col("event_info"), col("event_info.run_id"),
                    col("event_info.published_timestamp"), col("event_info.event_uuid"),
                    lit(run_id).alias("run_id")).show(1)

                df_updated_run_id_struct.createOrReplaceTempView("temp_df_updated_run_id_struct")

                executeInsertIntoDataCollectorTransactionQuery(spark, product_line, script_name, transaction_start_date)
            }

            catch {
                case ex: Exception =>
                    ExceptionLogger.logException("df_car_read_query", ex)
                    throw ex
            }

        }

        else if (product_line.equalsIgnoreCase(AppConstants.PRODUCT_LINE_NAME_CAR) && script_name == AppConstants.POST_USE_TRANSACTIONS) {
            //Reading data from Teradata directly from spark job for post_use_transaction_staged_booking_cars

             val query_post_use_transaction_staged_booking_cars =  readHqlFile(script_path+AppConstants.POST_USE_TRANSACTIONS_STAGING_PURCHASE_BOOKING_TD_CARS).format(transaction_start_date, transaction_end_date,transaction_start_date)

            LOGGER.info("++++++++++++++++ Read Query Script: query_post_use_transaction_staged_booking_cars ++++++++++++++++ \n" + query_post_use_transaction_staged_booking_cars)

            try {
                //Teradata JDBC connection
                val df_post_use_transaction_staged_booking_cars = createTeradataJDBCConnectionWithSpark(spark, url, userName, userPassword, query_post_use_transaction_staged_booking_cars)
                df_post_use_transaction_staged_booking_cars.createOrReplaceTempView("temp_post_use_transaction_staged_booking_purchase_cars_view")
                spark.sql(raw"""
                               | SELECT DISTINCT ${SQLColumnHelperPostUseTransactionsCar.Car_POST_USE_STAGE_BOOKING_READ_QUERY_TD}
                               | FROM temp_post_use_transaction_staged_booking_purchase_cars_view sb
                               | """.stripMargin).createOrReplaceTempView("temp_post_use_transaction_staged_booking_cars_view")

                LOGGER.info("Read Query Script: query_post_use_transaction_staged_booking_cars execution completed....")
            }

            catch {
                case e: Exception =>
                    ExceptionLogger.logException("query_post_use_transaction_staged_booking_cars", e)
                    throw e
            }

            //Reading data from teradata view   for post_use_transaction_purchase_booking_cars
          LOGGER.info("++++++++++++++++ Read Query Script: query_post_use_transaction_purchase_booking_cars ++++++++++++++++ \n"+SQLColumnHelperPostUseTransactionsCar.Car_POST_USE_PURCHASE_BOOKING_READ_QUERY_TD)

            try {
                //fetching purchase  view
                spark.sql(raw"""
                               | SELECT DISTINCT ${SQLColumnHelperPostUseTransactionsCar.Car_POST_USE_PURCHASE_BOOKING_READ_QUERY_TD}
                               | FROM temp_post_use_transaction_staged_booking_purchase_cars_view
                               | """.stripMargin).createOrReplaceTempView("temp_post_use_transaction_purchase_booking_cars_view")

                LOGGER.info("Read Query Script: query_post_use_transaction_purchase_booking_cars execution completed....")
            }

            catch {
                case e: Exception =>
                    ExceptionLogger.logException("query_post_use_transaction_purchase_booking_cars", e)
                    throw e
            }

            try {
                //Updating the read query after reading data from Teradata using spark job for post_use_stage_booking_read_query
                LOGGER.info("--------------Car_POST_USE_STAGE_BOOKING_READ_QUERY--------------\n"
                    + SQLColumnHelperPostUseTransactionsCar.Car_POST_USE_STAGE_BOOKING_READ_QUERY)
                val df_post_use_stage_booking_read_query = sqlBuilder.get_car_post_use_stg_bkg_view_data(spark)
                LOGGER.info("Dataframe: df_post_use_stage_booking_read_query created")

                val df_updated_run_id_struct: DataFrame = generate_run_id(run_id, df_post_use_stage_booking_read_query)

                df_updated_run_id_struct.createOrReplaceTempView("temp_df_post_use_stage_booking_cars_updated_run_id_struct")
            }

            catch {
                case ex: Exception =>
                    ExceptionLogger.logException("df_post_use_stage_booking_read_query", ex)
                    throw ex
            }

            try {
                //Updating the read query after reading data from Teradata using spark job for post_use_purchase_booking_read_query
                LOGGER.info("--------------Car_POST_USE_PURCHASE_BOOKING_READ_QUERY--------------\n"
                    + SQLColumnHelperPostUseTransactionsCar.Car_POST_USE_PURCHASE_BOOKING_READ_QUERY)
                val df_post_use_purchase_booking_read_query = sqlBuilder.get_cars_post_use_purchase_booking(spark)
                LOGGER.info("Dataframe: df_post_use_purchase_booking_read_query created")

                df_post_use_purchase_booking_read_query.createOrReplaceTempView("temp_df_post_use_purchase_booking_cars_view")
                executeInsertIntoDataCollectorTransactionQuery(spark, product_line, script_name, transaction_start_date)
            }

            catch {
                case ex: Exception =>
                    ExceptionLogger.logException("df_post_use_purchase_booking_read_query", ex)
                    throw ex
            }
        }

        else if (product_line.equalsIgnoreCase(AppConstants.PRODUCT_LINE_NAME_CAR) && script_name == AppConstants.STAGED_BOOKING_TRANSACTIONS_BACKFILL) {
            val query_stg_bkg_backfill_fact_car = readHqlFile(script_path + AppConstants.STAGED_BOOKING_TRANSACTIONS_BACKFILL_TD_CARS).format(transaction_start_date, transaction_end_date)
            LOGGER.info("++++++++++++++++ Read Query Script: query_stg_bkg_fact_backfill_car ++++++++++++++++ \n" + query_stg_bkg_backfill_fact_car)

            try {
                //Teradata JDBC connection
                val df_stg_bkg_backfill_fact_car = createTeradataJDBCConnectionWithSpark(spark, url, userName, userPassword, query_stg_bkg_backfill_fact_car)
                df_stg_bkg_backfill_fact_car.createOrReplaceTempView("temp_stg_bkg_backfill_fact_car_view")
                LOGGER.info("Read Query Script: query_stg_bkg_backfill_fact_car execution completed....")
            }

            catch {
                case e: Exception =>
                    ExceptionLogger.logException("df_stg_bkg_backfill_fact_car", e)
                    throw e
            }


            /**
             * read query for car stage
             */
            try {
                LOGGER.info("--------------Car_STAGE_BOOKING_BACKFILL_READ_QUERY--------------\n"
                    + SQLColumnHelperBookingTransactionsBackfillCars.CARS_STAGE_BOOKING_BACKFILL_READ_QUERY)
                val df_car_read_query = sqlBuilder.get_cars_stage_booking_backfill_data(spark)
                LOGGER.info("Dataframe: df_car_read_query created")

                df_car_read_query.select(col("event_info"), col("event_info.run_id"),
                    col("event_info.published_timestamp"), col("event_info.event_uuid"),
                    lit(run_id).alias("run_id")).show(1)

                df_car_read_query.select("event_info").show(1)

                val df_updated_run_id_struct = df_car_read_query.withColumn(SQLColumnHelperBookingTransactionsCar.EVENT_INFO_COLUMN,
                    struct(lit(run_id).alias("run_id"),
                        col(SQLColumnHelperBookingTransactionsCar.EVENT_INFO_COLUMN + ".published_timestamp").alias("published_timestamp"),
                        col(SQLColumnHelperBookingTransactionsCar.EVENT_INFO_COLUMN + ".event_uuid").alias("event_uuid")))

                df_updated_run_id_struct.select(col("event_info"), col("event_info.run_id"),
                    col("event_info.published_timestamp"), col("event_info.event_uuid"),
                    lit(run_id).alias("run_id")).show(1)

                df_updated_run_id_struct.createOrReplaceTempView("temp_df_updated_run_id_struct")

                executeInsertIntoDataCollectorTransactionQuery(spark, product_line, script_name, transaction_start_date)
            }

            catch {
                case ex: Exception =>
                    ExceptionLogger.logException("df_car_read_query", ex)
                    throw ex
            }

        }

        else if (product_line.equalsIgnoreCase(AppConstants.PRODUCT_LINE_NAME_LODGING) && script_name == AppConstants.STAGED_BOOKING_TRANSACTIONS) {

            val query_stg_bkg_fact_lodging = readHqlFile(script_path + STAGED_BOOKING_TRANSACTIONS_TD_LODGING).format(transaction_start_date)
            LOGGER.info("++++++++++++++++ Read Query Script: query_stg_bkg_fact_lodging ++++++++++++++++ \n" + query_stg_bkg_fact_lodging)

            try {
                //Teradata JDBC connection
                val df_stg_bkg_fact_lodging = createTeradataJDBCConnectionWithSpark(spark, url, userName, userPassword, query_stg_bkg_fact_lodging)
                df_stg_bkg_fact_lodging.createOrReplaceTempView("temp_stg_bkg_fact_lodging_view")
                LOGGER.info("Read Query Script: query_stg_bkg_fact_lodging execution completed....")

            }

            catch {
                case e: Exception =>
                    ExceptionLogger.logException("df_stg_bkg_fact_lodging", e)
                    throw e
            }
            try {
                val df_lodging_join_query = sqlBuilder.get_lodging_joined_data(spark, lodg_rate_pln_dim_legacy)

                LOGGER.info("Dataframe: df_lodging_join_query created")
                df_lodging_join_query.createOrReplaceTempView("temp_df_lodging_view")
            }

            catch {
                case e: Exception =>
                    ExceptionLogger.logException("df_lodging_join_query", e)
                    throw e
            }

            //Read Query
            try {
                LOGGER.info("--------------Lodging_STAGE_BOOKING_READ_QUERY--------------\n"
                    + SQLColumnHelperBookingTransactionsLodging.LODGING_STAGE_BOOKING_READ_QUERY)
                val df_lodging_read_query = sqlBuilder.get_lodging_stage_booking_data(spark)

                LOGGER.info("Dataframe: df_lodging_read_query created")

                val df_updated_run_id_struct: DataFrame = generate_run_id(run_id, df_lodging_read_query)
                df_updated_run_id_struct.createOrReplaceTempView("temp_view_stg_booking_lodging")

                executeInsertIntoDataCollectorTransactionQuery(spark, product_line, script_name, transaction_start_date)
            }

            catch {
                case ex: Exception =>
                    ExceptionLogger.logException("df_lodging_read_query", ex)
                    throw ex
            }

        }

        else if (product_line.equalsIgnoreCase(AppConstants.PRODUCT_LINE_NAME_LODGING) && script_name == AppConstants.POST_STAY_TRANSACTIONS) {
            val overallStartTime = System.currentTimeMillis() // Start time for the entire process
            LOGGER.info("Lodging post-stay transactions processing started.")

            val query_post_bkg_fact_lodging = readHqlFile(script_path + AppConstants.POST_USE_TRANSACTIONS_STAGING_PURCHASE_BOOKING_TD_LODGING).format(transaction_start_date, transaction_end_date,transaction_start_date)
            LOGGER.info("++++++++++++++++ Read Query Script: query_post_bkg_fact_lodging ++++++++++++++++ \n" + query_post_bkg_fact_lodging)

            try {
                //Teradata JDBC connection
                val df_post_bkg_fact_lodging = createTeradataJDBCConnectionWithSpark(spark, url, userName, userPassword, query_post_bkg_fact_lodging)
                val startTime1: Long = System.currentTimeMillis()
                df_post_bkg_fact_lodging.createOrReplaceTempView("temp_post_bkg_fact_lodging_bkg_purchase_view")

                spark.sql(raw"""
                               | SELECT DISTINCT ${SQLColumnHelperBookingTransactionsLodging.LODGING_STAGE_BOOKING_SELECT_TD}
                               | FROM temp_post_bkg_fact_lodging_bkg_purchase_view sb
                               | """.stripMargin).createOrReplaceTempView("temp_post_bkg_fact_lodging_view")
                //df_post_bkg_fact_lodging.createOrReplaceTempView("temp_post_bkg_fact_lodging_view")

                LOGGER.info("df_post_bkg_fact_lodging.createOrReplaceTempView Total Time taken  == " + (System.currentTimeMillis() - startTime1))
                LOGGER.info("Read Query Script: query_post_bkg_fact_lodging execution completed....")
            }

            catch {
                case e: Exception =>
                    ExceptionLogger.logException("df_post_bkg_fact_lodging", e)
                    throw e
            }
            try {
                val df_lodging_join_query = sqlBuilder.get_lodging_post_bkg_data(spark, lodg_rate_pln_dim_legacy)

                LOGGER.info("Dataframe: df_lodging_join_post_query created")
                val startTime2: Long = System.currentTimeMillis()
                df_lodging_join_query.createOrReplaceTempView("temp_df_post_lodging_view")
                LOGGER.info("df_lodging_join_query.createOrReplaceTempView Total Time taken  == " + (System.currentTimeMillis() - startTime2))
            }

            catch {
                case e: Exception =>
                    ExceptionLogger.logException("df_lodging_join_query", e)
                    throw e
            }

            //Read Query lodging post stay
            try {
                LOGGER.info("--------------Lodging_POST_BOOKING_READ_QUERY--------------\n"
                    + SQLColumnHelperPostStayTransactionsLodging.LODGING_BOOKING_POST_STAY_READ_QUERY)
                val df_lodging_read_query = sqlBuilder.get_lodging_post_stay_data(spark)
                LOGGER.info("Dataframe: df_lodging_post_stay_read_query created")

                val df_updated_run_id_struct: DataFrame = generate_run_id(run_id, df_lodging_read_query)
                val startTime3: Long = System.currentTimeMillis()
                df_updated_run_id_struct.createOrReplaceTempView("temp_df_updated_post_stay_run_id_struct")
                LOGGER.info("df_updated_run_id_struct.createOrReplaceTempView Total Time taken  == " + (System.currentTimeMillis() - startTime3))
            }

            catch {
                case ex: Exception =>
                    ExceptionLogger.logException("df_lodging_post_stay_read_query", ex)
                    throw ex
            }


            //Code logic - POST_STAY_TRANSACTIONS_PURCHASE_LODGING
            //val query_post_stay_purchase_fact_lodging = readHqlFile(script_path + AppConstants.POST_STAY_TRANSACTIONS_PURCHASE_LODGING).format(transaction_start_date)
            LOGGER.info("++++++++++++++++ Read Query Script: query_post_stay_purchase_fact_lodging ++++++++++++++++ \n" + SQLColumnHelperBookingTransactionsLodging.LODGING_PURCHASE_SELECT_TD)

            try {
                //Teradata JDBC connection
                //val df_post_stay_purchase_fact_lodging = createTeradataJDBCConnectionWithSpark(spark, url, userName, userPassword, query_post_stay_purchase_fact_lodging)
                val startTime4: Long = System.currentTimeMillis()
                spark.sql(raw"""
                               | SELECT DISTINCT ${SQLColumnHelperBookingTransactionsLodging.LODGING_PURCHASE_SELECT_TD}
                               | FROM temp_post_bkg_fact_lodging_bkg_purchase_view sb
                               | """.stripMargin).createOrReplaceTempView("temp_post_stay_purchase_fact_lodging_view")

                //df_post_stay_purchase_fact_lodging.createOrReplaceTempView("temp_post_stay_purchase_fact_lodging_view")
                LOGGER.info("df_post_stay_purchase_fact_lodging.createOrReplaceTempView Total Time taken  == " + (System.currentTimeMillis() - startTime4))
                LOGGER.info("Read Query Script: query_post_stay_purchase_fact_lodging execution completed....")

            }

            catch {
                case e: Exception =>
                    ExceptionLogger.logException("df_post_stay_purchase_fact_lodging", e)
                    throw e
            }
            val overallEndTime = System.currentTimeMillis()
            LOGGER.info("Lodging post-stay transactions processing completed in " + (overallEndTime - overallStartTime) + "ms")

            //Read Query - LODGING_PURCHASE_BOOKING_POST_USE_READ_QUERY
            try {
                LOGGER.info("--------------Lodging_PURCHASE_BOOKING_POST_STAY_READ_QUERY--------------\n"
                    + SQLColumnHelperPostStayTransactionsLodging.LODGING_PURCHASE_BOOKING_POST_STAY_READ_QUERY)
                val df_lodging_purchase_read_query = sqlBuilder.get_lodging_purchase_booking_post_stay_data(spark)
                LOGGER.info("Dataframe: df_lodging_purchase_read_query created")

                val startTime5: Long = System.currentTimeMillis()
                df_lodging_purchase_read_query.createOrReplaceTempView("temp_post_stay_purchase_lodging_view")
                LOGGER.info("df_lodging_purchase_read_query.createOrReplaceTempView Total Time taken  == " + (System.currentTimeMillis() - startTime5))

                executeInsertIntoDataCollectorTransactionQuery(spark, product_line, script_name, transaction_start_date)
            }

            catch {
                case ex: Exception =>
                    ExceptionLogger.logException("df_lodging_purchase_read_query", ex)
                    throw ex

            }

        }

        else if (product_line.equalsIgnoreCase(AppConstants.PRODUCT_LINE_NAME_LODGING) && script_name == AppConstants.STAGED_BOOKING_TRANSACTIONS_BACKFILL) {

            val query_stg_bkg_fact_backfill_lodging = readHqlFile(script_path + STAGED_BOOKING_TRANSACTIONS_BACKFILL_TD_LODGING).format(transaction_start_date, transaction_end_date)
            LOGGER.info("++++++++++++++++ Read Query Script: query_stg_bkg_fact_backfill_lodging ++++++++++++++++ \n" + query_stg_bkg_fact_backfill_lodging)

            try {
                //Teradata JDBC connection
                val df_stg_bkg_backfill_fact_lodging = createTeradataJDBCConnectionWithSpark(spark, url, userName, userPassword, query_stg_bkg_fact_backfill_lodging)
               df_stg_bkg_backfill_fact_lodging.createOrReplaceTempView("temp_stg_bkg_fact_lodging_view")
                LOGGER.info("Read Query Script: query_stg_bkg_fact_backfill_lodging execution completed....")
            }

            catch {
                case e: Exception =>
                    ExceptionLogger.logException("df_stg_bkg_backfill_fact_lodging", e)
                    throw e
            }
            try {
                val df_lodging_backfill_join_query = sqlBuilder.get_lodging_joined_data(spark, lodg_rate_pln_dim_legacy)
                LOGGER.info("Dataframe: df_lodging_backfill_join_query created")
                df_lodging_backfill_join_query.createOrReplaceTempView("temp_df_lodging_view")
            }

            catch {
                case e: Exception =>
                    ExceptionLogger.logException("df_lodging_join_query", e)
                    throw e
            }

            //Read Query
            try {
                LOGGER.info("--------------Lodging_STAGE_BOOKING_BACKFILL_READ_QUERY--------------\n"
                    + SQLColumnHelperBookingTransactionsBackfillLodging.LODGING_STAGE_BOOKING_BACKFILL_READ_QUERY)
                val df_lodging_read_query = sqlBuilder.get_loging_stg_bkg_backfill_data(spark)
                LOGGER.info("Dataframe: df_lodging_read_query created")
                val df_updated_run_id_struct: DataFrame = generate_run_id(run_id, df_lodging_read_query)
                df_updated_run_id_struct.createOrReplaceTempView("temp_view_stg_booking_lodging")
                executeInsertIntoDataCollectorTransactionQuery(spark, product_line, script_name, transaction_start_date)
            }

            catch {
                case ex: Exception =>
                    ExceptionLogger.logException("df_lodging_read_query", ex)
                    throw ex
            }
        }

        else {
            LOGGER.info("Invalid or Null Product Line and Script Name")
        }

    }

    /**
     * this method is used for inserting the data in to stage booking table (LX,Car,Lodging)
     */
    def executeInsertIntoDataCollectorTransactionQuery(spark: SparkSession, product_line: String, script_name: String, transaction_start_date: String) = {

        LOGGER.info("Inside Method: executeInsertIntoDataCollectorTransactionQuery")

        val startTime: Long = System.currentTimeMillis()
        LOGGER.info("Data Ingestion started for table: commerce.tax_compliance_eg_booking_transactions " + startTime)

        try {
            LOGGER.info("--------------DUMMY_BOOKING_TRANSACTION_QUERY--------------\n"
                + SQLColumnHelper.DUMMY_BOOKING_TRANSACTION_QUERY)
            val df_dummy_booking_transaction = sqlBuilder.get_dummy_booking_data(spark)

            LOGGER.info("Dataframe: df_dummy_booking_transaction created")
            df_dummy_booking_transaction.createOrReplaceTempView("temp_df_dummy_booking_transaction")
        }
        catch {
            case e: Exception =>
                ExceptionLogger.logException("df_dummy_booking_transaction", e)
                throw e
        }

        if (product_line.equalsIgnoreCase(AppConstants.PRODUCT_LINE_NAME_LX) && script_name == AppConstants.STAGED_BOOKING_TRANSACTIONS) {
            //Insert Query
            try {

                LOGGER.info("--------------LX_STAGE_BOOKING_INSERT_STATEMENT--------------\n"
                    + SQLColumnHelperBookingTransactionsLx.LX_STAGE_BOOKING_INSERT_STATEMENT)
                LOGGER.info("--------------LX_STAGE_BOOKING_INSERT_QUERY--------------\n"
                    + SQLColumnHelperBookingTransactionsLx.LX_STAGE_BOOKING_INSERT_QUERY)

                sqlBuilder.insert_lx_stage_booking_data(spark)
            }

            catch {
                case ex: Exception =>
                    ExceptionLogger.logException("df_lx_insert_query", ex)
                    throw ex

            }

        }

        else if (product_line.equalsIgnoreCase(AppConstants.PRODUCT_LINE_NAME_LX) && script_name == AppConstants.POST_USE_TRANSACTIONS) {
            //Insert Query
            try {


                LOGGER.info("--------------LX_POST_BOOKING_INSERT_STATEMENT--------------\n"
                    + SQLColumnHelperPostUseTransactionsLx.LX_POST_USE_INSERT_STATEMENT)
                LOGGER.info("--------------LX_POST_BOOKING__INSERT_QUERY--------------\n"
                    + SQLColumnHelperPostUseTransactionsLx.LX_POST_USE_INSERT_QUERY)

                LOGGER.info("Debug check 4")
                System.out.println("Debug check 4")
                sqlBuilder.insert_post_use_lx_data(spark)
            }

            catch {
                case ex: Exception =>
                    ExceptionLogger.logException("df_lx_insert_query", ex)
                    throw ex

            }

        }

        else if (product_line.equalsIgnoreCase(AppConstants.PRODUCT_LINE_NAME_LX) && script_name == AppConstants.STAGED_BOOKING_TRANSACTIONS_BACKFILL) {
            //Insert Query
            try {


                LOGGER.info("--------------LX_STAGE_BOOKING_BACKFILL_INSERT_STATEMENT--------------\n"
                    + SQLColumnHelperBookingTransactionsBackfillLx.LX_STAGE_BOOKING_BACKFILL_INSERT_STATEMENT)
                LOGGER.info("--------------LX_STAGE_BOOKING_BACKFILL_INSERT_QUERY--------------\n"
                    + SQLColumnHelperBookingTransactionsBackfillLx.LX_STAGE_BOOKING_BACKFILL_INSERT_QUERY)


                sqlBuilder.insert_stg_bkg_backfill_lx_data(spark)
            }

            catch {
                case ex: Exception =>
                    ExceptionLogger.logException("df_lx_insert_query", ex)
                    throw ex

            }

        }

        else if (product_line.equalsIgnoreCase(AppConstants.PRODUCT_LINE_NAME_CAR) && script_name == AppConstants.STAGED_BOOKING_TRANSACTIONS) {
            //Insert Query for car
            try {

                LOGGER.info("--------------Car_STAGE_BOOKING_INSERT_STATEMENT--------------\n"
                    + SQLColumnHelperBookingTransactionsCar.Car_STAGE_BOOKING_INSERT_STATEMENT)
                LOGGER.info("--------------Car_STAGE_BOOKING_INSERT_QUERY--------------\n"
                    + SQLColumnHelperBookingTransactionsCar.Car_STAGE_BOOKING_INSERT_QUERY)


                sqlBuilder.insert_car_stage_booking_data(spark)
            }

            catch {
                case ex: Exception =>
                    ExceptionLogger.logException("df_car_insert_query", ex)
                    throw ex
            }
        }

        else if (product_line.equalsIgnoreCase(AppConstants.PRODUCT_LINE_NAME_CAR) && script_name == AppConstants.POST_USE_TRANSACTIONS) {
            val startTime = System.currentTimeMillis()  // Capture start time

            //Insert Query for car post use
            try {


                LOGGER.info("--------------Car_POST_USE_INSERT_STATEMENT--------------\n"
                    + SQLColumnHelperPostUseTransactionsCar.Car_POST_USE_INSERT_STATEMENT)
                LOGGER.info("--------------Car_STAGE_BOOKING_INSERT_QUERY--------------\n"
                    + SQLColumnHelperPostUseTransactionsCar.Car_POST_USE_INSERT_QUERY)

                sqlBuilder.insert_car_post_use_data(spark)

            }

            catch {
                case ex: Exception =>
                    val endTime = System.currentTimeMillis() // Capture end time
                    val duration = endTime - startTime // Calculate time taken
                    ExceptionLogger.logException("df_car_post_use_insert_query", ex)
                    LOGGER.error(s"Car post-use transactions processing failed after ${duration}ms due to exception: ${ex.getMessage}")
                    throw ex
            }

        }

        else if (product_line.equalsIgnoreCase(AppConstants.PRODUCT_LINE_NAME_CAR) && script_name == AppConstants.STAGED_BOOKING_TRANSACTIONS_BACKFILL) {
            //Insert Query for car
            try {

                LOGGER.info("--------------CAR_STAGE_BOOKING_BACKFILL_INSERT_STATEMENT--------------\n"
                    + SQLColumnHelperBookingTransactionsBackfillCars.CARS_STAGE_BOOKING_BACKFILL_INSERT_STATEMENT)
                LOGGER.info("--------------CAR_STAGE_BOOKING_BACKFILL_INSERT_QUERY--------------\n"
                    + SQLColumnHelperBookingTransactionsBackfillCars.CARS_STAGE_BOOKING_BACKFILL_INSERT_QUERY)


                sqlBuilder.insert_cars_stg_booking_backfill_data(spark)
            }

            catch {
                case ex: Exception =>
                    ExceptionLogger.logException("df_car_insert_query", ex)
                    throw ex
            }

        }

        else if (product_line.equalsIgnoreCase(AppConstants.PRODUCT_LINE_NAME_LODGING) && script_name == AppConstants.STAGED_BOOKING_TRANSACTIONS) {
            try {

                LOGGER.info("--------------Lodging_STAGE_BOOKING_INSERT_STATEMENT--------------\n"
                    + SQLColumnHelperBookingTransactionsLodging.LODGING_STAGE_BOOKING_INSERT_STATEMENT)

                val startTime: Long = System.currentTimeMillis()
                sqlBuilder.insert_lodging_stage_booking_data(spark)
                LOGGER.info("Record inserted Total Time taken  = " + (System.currentTimeMillis() - startTime))

            }
            catch {
                case ex: Exception =>
                    ExceptionLogger.logException("df_lodging_insert_query", ex)
                    throw ex
            }

        }

        else if (product_line.equalsIgnoreCase(AppConstants.PRODUCT_LINE_NAME_LODGING) && script_name == AppConstants.POST_STAY_TRANSACTIONS) {

            try {

                LOGGER.info("--------------LODGING_POST_BOOKING_INSERT_STATEMENT--------------\n"
                    + SQLColumnHelperPostStayTransactionsLodging.LODGING_POST_STAY_INSERT_STATEMENT)
                LOGGER.info("--------------LODGING_POST_BOOKING__INSERT_QUERY--------------\n"
                    + SQLColumnHelperPostStayTransactionsLodging.LODGING_POST_USE_INSERT_QUERY)

                val startTime7: Long = System.currentTimeMillis()
                sqlBuilder.insert_lodging_post_stay_data(spark)
                LOGGER.info("Record inserted Total Time taken  == " + (System.currentTimeMillis() - startTime7))
            }
            catch {
                case ex: Exception =>
                    ExceptionLogger.logException("df_lodging_insert_query", ex)
                    throw ex

            }

        }

        else if (product_line.equalsIgnoreCase(AppConstants.PRODUCT_LINE_NAME_LODGING) && script_name == AppConstants.STAGED_BOOKING_TRANSACTIONS_BACKFILL) {
            try {
                LOGGER.info("--------------Lodging_STAGE_BOOKING_BACKFILL_INSERT_STATEMENT--------------\n"
                    + SQLColumnHelperBookingTransactionsBackfillLodging.LODGING_STAGE_BOOKING_BACK_FILL_INSERT_STATEMENT)

                val startTime: Long = System.currentTimeMillis()
                sqlBuilder.insert_lodging_stage_booking_backfill_data(spark)
                LOGGER.info("Record inserted Total Time taken  = " + (System.currentTimeMillis() - startTime))
            }
            catch {
                case ex: Exception =>
                    ExceptionLogger.logException("df_lodging_insert_query", ex)
                    throw ex
            }

        }

        else {
            LOGGER.info("Invalid or Null Product Line and Script Name")
        }
        LOGGER.info("Total Time taken  == " + (System.currentTimeMillis() - startTime))

    }

    def getSparkSession(): SparkSession = {
        val spark = SparkSession
            .builder()
            .config("spark.sql.crossJoin.enabled", true)
            .config("hive.exec.dynamic.partition.mode", "nonstrict")
            .config("hive.enforce.bucketing", "true")
            .appName("Spark SQL TeradataJDBC Connection")
            .enableHiveSupport()
            .getOrCreate()

        spark
    }

    def generate_run_id(run_id: String, df: DataFrame) = {


        val df_updated_run_id_struct = df.withColumn(SQLColumnHelper.EVENT_INFO,
            struct(lit(run_id).alias("run_id"),
                col(SQLColumnHelper.EVENT_INFO + ".published_timestamp").alias("published_timestamp"),
                col(SQLColumnHelper.EVENT_INFO + ".event_uuid").alias("event_uuid")))

        df_updated_run_id_struct
    }

    def fetchCredentials(userCredentials: util.List[String], clientApiTokensMap: util.Map[String, String]) = {
        userCredentials.addAll(clientApiTokensMap.values)
        LOGGER.info("Secret Manager execution completed")
    }

    def func_egdp_apiary_datalake_tbl_lx_1(spark: SparkSession, query_stg_bkg_egdp_apiary_lx: String): Unit = {
        try {
            val df_egdp_apiary_datalake_tbl_lx = sqlBuilder.run_query(spark, query_stg_bkg_egdp_apiary_lx)
            df_egdp_apiary_datalake_tbl_lx.createOrReplaceTempView("temp_egdp_apiary_datalake_tbl_view")
            LOGGER.info("Read Query Script: query_stg_bkg_egdp_apiary_lx execution completed ....")
            LOGGER.info("Record Count of df_egdp_apiary_datalake_tbl_lx: " + df_egdp_apiary_datalake_tbl_lx.count())
        }

        catch {
            case e: Exception =>
                ExceptionLogger.logException("df_lx_joindf_egdp_apiary_datalake_tbl_lx_query", e)
                throw e
        }

    }

    def func_egdp_apiary_datalake_tbl_lx_2(spark: SparkSession, query_post_use_egdp_apiary_lx: String): Unit = {
        try {
            val df_egdp_apiary_datalake_tbl_lx = sqlBuilder.run_query(spark, query_post_use_egdp_apiary_lx)
            df_egdp_apiary_datalake_tbl_lx.createOrReplaceTempView("temp_egdp_apiary_datalake_tbl_view")
            LOGGER.info("Read Query Script: query_post_use_egdp_apiary_lx execution completed ....")
            LOGGER.info("Record Count of df_egdp_apiary_datalake_tbl_lx: " + df_egdp_apiary_datalake_tbl_lx.count())
        }

        catch {
            case e: Exception =>
                ExceptionLogger.logException("df_egdp_apiary_datalake_tbl_lx", e)
                throw e
        }
    }

    def func_egdp_apiary_datalake_tbl_lx_3(spark: SparkSession, query_stg_bkg_backfill_egdp_apiary_lx: String): Unit = {
        try {
            val df_egdp_apiary_datalake_tbl_lx = sqlBuilder.run_query(spark, query_stg_bkg_backfill_egdp_apiary_lx)
            df_egdp_apiary_datalake_tbl_lx.createOrReplaceTempView("temp_egdp_apiary_datalake_tbl_view")
            LOGGER.info("Read Query Script: query_stg_bkg_backfill_egdp_apiary_lx execution completed ....")
            LOGGER.info("Record Count of df_egdp_apiary_datalake_tbl_lx: " + df_egdp_apiary_datalake_tbl_lx.count())
        }

        catch {
            case e: Exception =>
                ExceptionLogger.logException("df_egdp_apiary_datalake_tbl_lx", e)
                throw e
        }
    }


}
