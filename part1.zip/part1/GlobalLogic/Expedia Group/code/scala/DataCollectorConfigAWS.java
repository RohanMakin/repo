package com.expediagroup.platform.taxcompliance.aws.secret;

import com.amazonaws.services.secretsmanager.AWSSecretsManager;
import com.amazonaws.services.secretsmanager.AWSSecretsManagerClientBuilder;
import com.amazonaws.services.secretsmanager.model.GetSecretValueRequest;
import com.amazonaws.services.secretsmanager.model.GetSecretValueResult;
import com.fasterxml.jackson.databind.ObjectMapper;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import java.io.Serializable;
import java.util.HashMap;
import java.util.Map;
import com.google.common.base.Strings;
import com.fasterxml.jackson.core.type.TypeReference;
import com.fasterxml.jackson.core.JsonProcessingException;

public class DataCollectorConfigAWS implements Serializable {

    private static final Logger LOGGER = LoggerFactory.getLogger(DataCollectorConfigAWS.class.getName());
    private Map<String, String> clientApiTokensMap = new HashMap<String,String>();
    private static TypeReference<HashMap<String,String>> typeReference = new TypeReference<HashMap<String,String>>() {};
    private static final String TAX_DATA_PRODUCTS_TD_CONNECTIVITY_CREDENTIALS = "tax-data-products-td-connectivity-credentials";
    private GetSecretValueResult getSecretValueResult;
    private Map<String, String> secretMap = new HashMap<String,String>();
    private String secretValue=new String();
    private static final String DIGITAL_SERVICE_WEBHOOK_SECRET = "digitalService.webhook-secret";


    public Map<String, String>  populateDataCollectorConfigAWS() throws Exception {
        getSecretValueResult = getAwsSecretValueResult();
        return fetchClientApiTokensMap(getSecretValueResult);
    }

    private GetSecretValueResult getAwsSecretValueResult() {

        LOGGER.info("Inside getAwsSecretValueResult ::::::::::Start retrieving secrets.");
        AWSSecretsManager secretsManager = AWSSecretsManagerClientBuilder.standard().withRegion("us-east-1").build();
        GetSecretValueRequest getSecretValueRequest = new GetSecretValueRequest().withSecretId(TAX_DATA_PRODUCTS_TD_CONNECTIVITY_CREDENTIALS);
        GetSecretValueResult getSecretValueResult = secretsManager.getSecretValue(getSecretValueRequest);
        return getSecretValueResult;
    }

    private Map<String, String> fetchClientApiTokensMap(GetSecretValueResult getSecretValueResult) {
        LOGGER.info("Execution started for fetchClientApiTokensMap");
        ObjectMapper objectMapper = new ObjectMapper();
        try {
            if (getSecretValueResult != null && !Strings.isNullOrEmpty(getSecretValueResult.getSecretString())) {
                clientApiTokensMap = objectMapper.readValue(getSecretValueResult.getSecretString(), typeReference);
            }
        } catch (Exception ex) {
            LOGGER.info("Inside catch");
            throw new RuntimeException("Cannot get the secret from SecretsManager", ex);
        }
        return clientApiTokensMap;
    }
    public String populateDataCollectorConfigAWS(String secretKey) {
        return getAwsSecretValueResult(secretKey);
    }
    private String getAwsSecretValueResult(String secretKey) {
        LOGGER.info("Starting to retrieve secrets from AWS Secrets Manager.");
        ObjectMapper objectMapperSecret = new ObjectMapper();


        try {
            AWSSecretsManager secretsManager = AWSSecretsManagerClientBuilder.standard()
                .withRegion("us-east-1")
                .build();

            GetSecretValueResult getSecretValueResult = secretsManager.getSecretValue(
                new GetSecretValueRequest().withSecretId(DIGITAL_SERVICE_WEBHOOK_SECRET)
            );

            if (getSecretValueResult != null && !Strings.isNullOrEmpty(getSecretValueResult.getSecretString())) {
                secretMap= objectMapperSecret.readValue(getSecretValueResult.getSecretString(), typeReference);
                secretValue = secretMap.get(secretKey);
            }
        } catch (Exception ex) {
            LOGGER.error("Error retrieving the secret from AWS Secrets Manager: {}", ex.getMessage(), ex);
            throw new RuntimeException("Cannot get the secret from Secrets Manager", ex);
        }

        return secretValue;
    }




}
