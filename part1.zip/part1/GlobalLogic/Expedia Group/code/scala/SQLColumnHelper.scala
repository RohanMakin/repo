package com.expediagroup.platform.taxcompliance.sql

object SQLColumnHelper extends Serializable {
    val LODGING = "lodging"
    val CAR = "car"
    val NOT_AVAILABLE = "Not Available"
    val STAY_DATE = "stay_date"
    val BOOK_DATE = "book_date"
    val BK_DATE_KEY = "bk_date_key"
    val BEGIN_USE_DATE = "begin_use_date"
    val BEGIN_USE_DATE_KEY = "begin_use_date_key"
    val LIABILITY_DATE = "liability_date"
    val TRANSACTION_LIABILITY_DATE = "transaction_liability_date"
    val TRANSACTION_LIABILITY_DATE_TYPE = "transaction_liability_date_type"
    val TRANSACTION_LIABILITY_DATE_TYPE_STAY_DATE = "stayDate"
    val TRANSACTION_LIABILITY_DATE_TYPE_BKG_EVENT_DATE = "bookingEventDate"
    val TRANSACTION_DATE_TIME = "transaction_date_time"
    val ACTION_DATE = "action_date"

    val BOOKING_ITEM = "booking_item"
    val ITEM_AMOUNT = "item_amount"
    val BOOKING_DETAIL = "booking_detail"
    val PROPERTY_ITEM = "property_item"
    val CAR_ITEM = "car_item"
    val LX_ITEM = "lx_item"
    val LOCAL_AMOUNTS = "local_amounts"
    val LOCAL_AMOUNTS_UPDATED = "local_amounts_updated"
    val PARTNER_FEE_AMOUNTS_UPDATED = "partner_fee_amounts_updated"
    val CONVERTED_AMOUNTS = "converted_amounts"
    val CONVERTED_AMOUNTS_HISTORY = "converted_amounts_history"
    val PARTNER_ITEM = "partner_item"
    val LOCAL_AMOUNT = "local_amount"
    val MESO_ITEM = "meso_item"
    val NON_TRAVEL_ITEM = "non_travel_item"

    val MONEY = "money"
    val MONETARY_CLASSIFICATION = "monetary_classification"
    val MONETARY_COMPUTATIONAL_REFERENCE = "monetary_computational_reference"
    val MONETARY_COMPUTATIONAL_SOURCE = "monetary_computational_source"
    val CREATE_DATE_TIME = "create_date_time"
    val APPLY_DATE = "apply_date"
    val CATEGORY = "category"
    val SUB_CATEGORY_1 = "sub_category_1"
    val SUB_CATEGORY_2 = "sub_category_2"
    val CURRENCY_COD = "currency_code"
    val CURRENCY_TYPE = "currency_type"
    val AMOUNT = "amount"
    val DECIMAL_PLACES = "decimal_places"
    val FILING = "filing"
    val DEBIT = "DEBIT"
    val CREDIT = "CREDIT"

    // VRBO Columns
    val VRBO_BOOKING_EVENT_STREAM = "Vrbo Booking Event Stream"
    val FINANCIAL_AMOUNTS = "financial_amounts"
    val OFFER_PRICE_DETAIL_ATTRIBUTES = "offer_price_detail_attributes"
    val FEE_DISPLAY_BREAKDOWN_DTO = "feebreakdowntaxdisplaydto"
    val DESCRIPTION = "description"
    val DISTRIBUTION_BREAKDOWN = "distributionbreakdown"
    val CURRENCY = "currency"
    val AMOUNT_TYPE = "amounttype"
    val IMPOSITION_TYPE = "impositiontype"
    val VRBO_JURISDICTION_NAME = "jurisdictionname"
    val VRBO_JURISDICTION_LEVEL = "jurisdictionlevel"
    val LOCAL = "local"
    val UNKNOWN = "unknown"
    val CREATE_DATE = "create_date"
    val MAPPING_TYPE = "mappingtype"
    val VRBO_PRODUCT_LINE_NAME = "VacationRentals"
    val TRANSACTION_DATE = "transaction_date"
    val RESERVATION_UUID = "reservation_uuid"
    val UPDATED_RESERVATION_UUID = "updated_reservation_uuid"
    val RESERVATION_STATE = "reservation_state"
    val RESERVATION_STATUS = "reservation_status"
    val SUPPLIER_MASTER_BRAND = "supplier_master_brand"
    val TRAVELER_BOOKING_SITE = "traveler_booking_site"
    val EXTERNAL_SOR = "EXTERNAL_SOR"
    val VRBO_MOR = "Vrbo MOR"
    val MERCHANT_OF_RECORD_TYPE = "merchant_of_record_type"
    val HAMOR = "HAMOR"
    val SUPPLIER = "SUPPLIER"
    val VRBO_LEGAL_ENTITY_NAME = "HomeAway.com, Inc."
    val EG_VACATION_RENTALS_IRELAND_LIMITED = "EG Vacation Rentals Ireland Limited"
    val STAYZ_PTY_LTD = "Stayz Pty Ltd"
    val BOOKABACH_LTD = "Bookabach Ltd"
    val HOMEAWAY_SARL_IRISH_BRANCH = "HomeAway SARL Irish branch"
    val HOMEAWAY_EMERGING_MARKETS = "HomeAway Emerging Markets Pte. Ltd."
    val VRBO_LEGAL_ENTITY_CODE = "41101"
    val AMOUNT_IMPOSITION_TYPE = "imposition_type"
    val AMOUNT_JURISDICTION_LEVEL = "jurisdiction_level"
    val AMOUNT_JURISDICTION_NAME = "jurisdiction_name"
    val BKG_AMOUNTS_STRUCT = "bkgAmountsStruct"
    val VRBO_UPDATED_BEGIN_USE_DATE = "updated_begin_use_date"
    val VRBO_RESERVATION_REFERENCE_NUMBER = "reservation_reference_number"
    val VRBO_UPDATED_RESERVATION_REFERENCE_NUMBER = "updated_reservation_reference_number"
    val VRBO_TRANSACTION_DATETIME = "transaction_date_time"
    val VRBO_TRANSACTION_DATE = "vrbo_transaction_date"
    val VRBO_EVENT_TYPE = "event_type"
    val VRBO_INITIAL_BOOKING = "INITIAL_BOOKING"
    val VRBO_MAX_TXN_DATETIME = "max_transaction_date"
    val VRBO_ACQUISITION_DATE = "acquisition_date"
    val VRBO_MAX_ACQUISITION_DATE = "max_acquisition_date"
    val BOOKING_HISTORY = "booking_history"
    val STAGING_BOOKING_HISTORY = "staging_booking_history"
    val BOOKING_HISTORY_EVENT = "booking_history_event"

    val MOR_PROCESSING_FEE = "MOR_PROCESSING_FEE"
    val BRAND_SERVICE_FEE = "BRAND_SERVICE_FEE"
    val UPDATED_TRAVELER_FEE = "UPDATED_TRAVELER_FEE"
    val UPDATED_BRAND_SERVICE_FEE = "UPDATED_BRAND_SERVICE_FEE"
    val SUPPLIER_SERVICE_FEE = "SUPPLIER_SERVICE_FEE"
    val RENT_EXCLUSIVE_PARTNER_FEE = "RENT_EXCL_PARTNER_FEES"
    val CANCELLATION_PENALTY_RENT = "CANCELATION_PENALTY_RENT"
    val CANCELLATION_PENALTY_TRAVELER_FEE = "CANCELATION_PENALTY_TRAVELLER_FEE"
    val OWNER_RENT = "OWNER_RENT"
    val OWNER_RENT_PROJECTED = "OWNER_RENT_PROJECTED"
    val SUM_OF_TAXES = "SUM_OF_TAXES"
    val SUM_OF_VAT = "SUM_OF_VAT"
    val TRAVELER_FEE = "TRAVELER_FEE"
    val TRAVELER_FEE_HISTORY = "TRAVELER_FEE_HISTORY"
    val EDN_SERVICE_FEE = "EDN_SERVICE_FEE"
    val EDN_PARTNER_TRAVELER_FEE = "EDN_PARTNER_TRAVELER_FEE"
    val EDN_PARTNER_TRAVELER_FEE_HISTORY = "EDN_PARTNER_TRAVELER_FEE_HISTORY"
    val CONVERTED_AMOUNTS_UPDATED = "converted_amounts_updated"
    val COMBINED_AMOUNTS_HISTORY = "combined_amounts_history"

    val PARTNER_FEE_TYPE = "partnerfeetype"
    val PARTNER_FEE_AMOUNT = "partnerfeeamount"
    val PARTNER_FEE_CURRENCY = "feecurrency"
    val PARTNER_FEE = "PARTNER_FEE"
    val CLEANING_FEE = "CLEANING"
    val PET_FEE = "PET"
    val GUEST_FEE = "GUEST"
    val TAX = "TAX"
    val VAT = "VAT"

    val END_USE_DATE = "end_use_date"
    val END_USE_DATE_KEY = "end_use_date_key"

    val LODG_ROOM_TYPE_ID = "lodg_rm_typ_id"
    val ROOM_NIGHT_COUNT = "room_night_count"
    val RM_NIGHT_CNT = "rm_night_cnt"
    val BOOKING_ITEM_ID = "booking_item_id"
    val ITIN_NBR = "itin_nbr"
    val BKG_ITM_ID = "bkg_itm_id"
    val BOOKING_ID = "booking_id"
    val BKG_ID = "bkg_id"
    val TRANS_DATE_KEY = "trans_date_key"
    val TRANS_DATETIME = "trans_datetm"
    val TOTAL_ROOM_NIGHT_COUNT = "total_room_night_count"
    val NIGHT_NUMBER = "night_number"
    val NET_PRICE_TRANSACTION = "net_price_transaction"
    val NET_PRICE_BOOKING = "net_price_booking"
    val IS_CANCEL_PRESENT = "is_cancel_present"
    val PENALTY_AMOUNT_LOCAL = "penalty_amount_local"
    val POST_TO_TAX_ENGINE = "post_to_tax_engine"
    val TAX_RATE_BOOK_DATE = "tax_rate_book_date"
    val TAX_RATE_BOOK_DATE_COST = "tax_rate_book_date_cost"
    val NET_COST_BOOKING = "net_cost_booking"
    val PKG_IND = "package_indicator"
    val CAR_RATE_INDICATOR = "car_rate_indicator"

    val SOURCE_SYSTEM_ID = "source_system_id"
    val SRC_SYS_ID = "src_sys_id"
    val BOOKING_EVENT_DATE = "booking_event_date"
    val BOOKING_EVENT_DATETIME = "booking_event_datetime"
    val TRANSACTION_TYPE_NAME = "transaction_type_name"
    val TRANSACTION_TYPE_NAME_UPDATED = "transaction_type_name_updated"
    val TRANS_TYP_NAME = "transaction_type_name"
    val BUSINESS_MODEL_NAME = "business_model_name"
    val ORIGINAL_BUSINESS_MODEL_NAME = "original_business_model_name"
    val BUSINESS_MODEL_SUBTYPE_NAME = "business_model_subtype_name"
    val BUSINESS_MODEL_SUBTYP_NAME = "business_model_subtyp_name"
    val PRODUCT_LINE_NAME = "product_line_name"
    val PRODUCT_LN_NAME = "product_ln_name"
    val PRODUCT_LN_KEY = "product_ln_key"
    val TRAVEL_PRODUCT_ID = "travel_product_id"
    val TOTAL_TRAVELER_COUNT = "total_traveler_count"
    val TRANSACTION_TYPE_KEY = "transaction_type_key"
    val TRANS_TYP_KEY = "trans_typ_key"
    val MIN_TRANS_TYP_KEY = "min_trans_typ_key"
    val TRANS_TYP_NAME_COL = "trans_typ_name"
    val TPID = "tpid"
    val TOTL_PERSN_CNT = "totl_persn_cnt"
    val OTHR_FEE_PRICE_AMT_LOCAL = "other_fee_price_amount_local"
    val AGNT_ASST_PURCH_FEE_AMT_LOCAL = "agent_assisted_purchase_fee_amount_local"
    val USE_DATE_KEY = "use_date_key"
    val TRAVEL_RECORD_LOCATOR = "travel_record_locator"

    val BASE_PRICE_AMT_LOCAL = "base_price_amount_local"
    val OTHR_PRICE_ADJ_AMT_LOCAL = "other_price_adjustment_amount_local"
    val PNLTY_PRICE_ADJ_AMT_LOCAL = "penalty_price_adjustment_amount_local"
    val EXPE_PNLTY_PRICE_ADJ_AMT_LOCAL = "expedia_penalty_price_adjustment_amount_local"
    val TOTL_PRICE_ADJ_AMT_LOCAL = "total_price_adjustment_amount_local"
    val SVC_FEE_PRICE_AMT_LOCAL = "service_fee_price_amount_local"
    val TOTL_FEE_PRICE_AMT_LOCAL = "total_fee_price_amount_local"
    val TOTL_TAX_PRICE_AMT_LOCAL = "total_tax_price_amount_local"
    val SVC_CHRG_PRICE_AMT_LOCAL = "service_charge_price_amount_local"
    val CNCL_CHG_FEE_PRICE_AMT_LOCAL = "cancel_change_fee_price_amount_local"
    val BASE_COST_AMT_USD = "base_cost_amount_usd"
    val OTHR_COST_ADJ_AMT_USD = "other_cost_adjustment_amount_usd"
    val SUPPL_COST_ADJ_AMT_USD = "supplier_cost_adjustment_amount_usd"
    val TOTL_COST_ADJ_AMT_USD = "total_cost_adjustment_amount_usd"
    val TOTL_COST_AMT_USD = "total_cost_amount_usd"
    val TOTL_FEE_COST_AMT_USD = "total_fee_cost_amount_usd"
    val TOTL_TAX_COST_AMT_USD = "total_tax_cost_amount_usd"
    val GROSS_BKG_AMT_LOCAL = "gross_booking_amount_local"
    val PRICE_CURRENCY_CODE = "price_currency_code"
    val COST_CURRENCY_CODE = "cost_currency_code"
    val PRICE_CURRENCY_KEY = "price_currn_key"
    val COST_CURRENCY_KEY = "cost_currn_key"
    val CURRENCY_KEY = "currn_key"
    val CURRENCY_CODE = "currn_code"
    val GROSS_BOOKING_AMOUNT_USD = "gross_booking_amount_usd"
    val OTHER_FEE_PRICE_AMOUNT_LOCAL = "other_fee_price_amount_local"
    val AGENT_ASSISTED_PURCHASE_FEE_AMOUNT_LOCAL = "agent_assisted_purchase_fee_amount_local"
    val PROPERTY_ID = "property_id"
    val EXCHANGE_RATE_BOOK_DATE = "exchange_rate_book_date"
    val EXCHANGE_RATE_STAY_DATE = "exchange_rate_stay_date"
    val EXCHANGE_RATE_STAY_DATE_COST = "exchange_rate_stay_date_cost"
    val FRONT_END_COMMISSION_AMOUNT_USD = "front_end_commission_amount_usd"
    val COUPN_PRICE_AMT_LOCAL = "coupon_price_amount_local"
    val EXPE_GDWLL_PRICE_ADJ_AMT_LOCAL = "expedia_goodwill_price_adjustment_amount_local"
    val GDWLL_PRICE_ADJ_AMT_LOCAL = "goodwill_price_adjustment_amount_local"
    val GENRIC_COUPN_PRICE_AMT_LOCAL = "generic_coupon_price_amount_local"
    val REFUND_PRICE_ADJ_AMT_LOCAL = "refund_price_adjustment_amount_local"
    val REBATE_PRICE_AMT_LOCAL = "rebate_price_amount_local"
    val TCM_PRICE_ADJ_AMT_LOCAL = "tcm_price_adjustment_amount_local"
    val CNCL_PNLTY_WAIVR_PRICE_ADJ_AMT_LOCAL = "cancel_penalty_waiver_price_adjustment_amount_local"
    val LOYLTY_POINT_PRICE_ADJ_AMT_LOCAL = "loyalty_point_price_adjustment_amount_local"
    val EMP_DISC_PRICE_ADJ_AMT_LOCAL = "employee_discount_price_adjustment_amount_local"
    val SUPPL_RECON_PRICE_ADJ_AMT_LOCAL = "supplier_reconciliation_price_adjustment_amount_local"
    val PURCHASE_BASE_PRICE_AMOUNT_LOCAL = "purchase_base_price_amount_local"
    val PURCHASE_BASE_PRICE_AMT_LOCAL = "purchase_base_price_amount_local"
    val PURCHASE_TOTL_PRICE_ADJ_AMT_LOCAL = "purchase_total_price_adjustment_amount_local"
    val PURCHASE_TOTL_FEE_PRICE_AMT_LOCAL = "purchase_total_fee_price_amount_local"
    val PURCHASE_TOTL_TAX_PRICE_AMT_LOCAL = "purchase_total_tax_price_amount_local"
    val CANCEL_CHANGE_FEE_PRICE_AMOUNT_TAX_EXCLUSIVE_LOCAL = "cancel_change_fee_price_amount_tax_exclusive_local"
    val BKG_ATTRIBUTES_STRUCT = "bkgAttributesStruct"
    val PURCHASE_PRICE_CURRENCY_CODE = "purchase_price_currency_code"
    val UPDATED_PRICE_CURRENCY_CODE = "updated_price_currency_code"
    val PURCHASE_COST_CURRENCY_CODE = "purchase_cost_currency_code"
    val UPDATED_COST_CURRENCY_CODE = "updated_cost_currency_code"
    val TOTL_COST_AMT_LOCAL = "total_cost_amount_local";
    val BASE_COST_AMT_LOCAL = "base_cost_amount_local";
    val TOTL_COST_ADJ_AMT_LOCAL = "total_cost_adjustment_amount_local";
    val SUPPL_COST_ADJ_AMT_LOCAL = "supplier_cost_adjustment_amount_local";
    val ECA_COST_ADJ_AMT_LOCAL = "eca_cost_adjustment_amount_local";
    val OTHR_COST_ADJ_AMT_LOCAL = "other_cost_adjustment_amount_local";
    val VAR_MARGN_COST_ADJ_LOCAL = "variable_margin_cost_adjustment_amount_local";
    val SUPPL_RECON_COST_ADJ_AMT_LOCAL = "supplier_reconciliation_cost_adjustment_local";
    val TOTL_FEE_COST_AMT_LOCAL = "total_fee_cost_amount_local";
    val SVC_CHRG_COST_AMT_LOCAL = "service_charge_cost_amount_local";
    val OTHR_FEE_COST_AMT_LOCAL = "other_fee_cost_amount_local";
    val ECA_FEE_COST_AMT_LOCAL = "eca_fee_cost_amount_local";
    val TOTL_TAX_COST_AMT_LOCAL = "total_tax_cost_amount_local";
    val VAR_MARGN_CREDT_LOCAL = "variable_margin_credit_local";
    val MARGN_AMT_USD = "margin_amount_usd";
    val PURE_MARGN_AMT_USD = "pure_margin_amount_usd";
    val EXTRA_PERSN_COST_AMT_LOCAL = "extra_person_cost_amount_local";
    val RATE_PLN_RESTR_COST_AMT_LOCAL = "rate_plan_restriction_cost_amount_local";
    val SNGL_SUPPLMNT_COST_AMT_LOCAL = "single_supplement_cost_amount_local";
    val DYN_RATE_RULE_COST_AMT_LOCAL = "dynamic_rate_rule_cost_amount_local";
    val PENALTY_COST_AMOUNT_LOCAL = "penalty_cost_amount_local";
    val PURCHASE_TOTL_COST_AMT_LOCAL = "purchase_total_cost_amount_local";
    val PURCHASE_TOTL_COST_ADJ_AMT_LOCAL = "purchase_total_cost_adjustment_amount_local";
    val PURCHASE_TOTL_TAX_COST_AMT_LOCAL = "purchase_total_tax_cost_amount_local";
    val PURCHASE_TOTAL_PRICE_ADJUSTMENT_AMOUNT_LOCAL = "purchase_total_price_adjustment_amount_local"
    val PURCHASE_TOTAL_FEE_PRICE_AMOUNT_LOCAL = "purchase_total_fee_price_amount_local"
    val PURCHASE_TOTAL_TAX_PRICE_AMOUNT_LOCAL = "purchase_total_tax_price_amount_local"
    val PURCHASE_TOTAL_COST_AMOUNT_LOCAL = "purchase_total_cost_amount_local";
    val PURCHASE_TOTAL_COST_ADJUSTMENT_AMOUNT_LOCAL = "purchase_total_cost_adjustment_amount_local";
    val PURCHASE_TOTAL_TAX_COST_AMOUNT_LOCAL = "purchase_total_tax_cost_amount_local";
    val EXTRA_PERSON_COST_AMOUNT_LOCAL = "extra_person_cost_amount_local"
    val RATE_PLAN_RESTRICTION_COST_AMOUNT_LOCAL = "rate_plan_restriction_cost_amount_local"
    val SINGLE_SUPPLEMENT_COST_AMOUNT_LOCAL = "single_supplement_cost_amount_local"
    val DYNAMIC_RATE_RULE_COST_AMOUNT_LOCAL = "dynamic_rate_rule_cost_amount_local"
    val PURCHASE_TOTAL_PRICE_ADJUSTMENT_AMOUNT = "purchase_total_price_adjustment_amount"
    val PURCHASE_TOTAL_FEE_PRICE_AMOUNT = "purchase_total_fee_price_amount"
    val PURCHASE_TOTAL_TAX_PRICE_AMOUNT = "purchase_total_tax_price_amount"
    val PURCHASE_TOTAL_COST_AMOUNT = "purchase_total_cost_amount";
    val PURCHASE_TOTAL_COST_ADJUSTMENT_AMOUNT = "purchase_total_cost_adjustment_amount";
    val PURCHASE_TOTAL_TAX_COST_AMOUNT = "purchase_total_tax_cost_amount";
    val TRANSACTION_LIABILITY_TYPE = "transaction_liability_type"

    val PENALTY_PRICE_AMOUNT = "penalty_price_amount"
    val FILING_CURRENCY_CODE = "filing_currency_code"
    val CANCEL_PENALTY_WAIVER_PRICE_ADJUSTMENT_AMOUNT_LOCAL = "cancel_penalty_waiver_price_adjustment_amount_local"
    val EMPLOYEE_DISCOUNT_PRICE_ADJUSTMENT_AMOUNT_LOCAL = "employee_discount_price_adjustment_amount_local"
    val EXPEDIA_GOODWILL_PRICE_ADJUSTMENT_AMOUNT_LOCAL = "expedia_goodwill_price_adjustment_amount_local"
    val EXPEDIA_PENALTY_PRICE_ADJUSTMENT_AMOUNT_LOCAL = "expedia_penalty_price_adjustment_amount_local"
    val GOODWILL_PRICE_ADJUSTMENT_AMOUNT_LOCAL = "goodwill_price_adjustment_amount_local"
    val GENERIC_COUPON_PRICE_AMOUNT_LOCAL = "generic_coupon_price_amount_local"
    val LOYALTY_POINT_PRICE_ADJUSTMENT_AMOUNT_LOCAL = "loyalty_point_price_adjustment_amount_local"
    val PENALTY_PRICE_ADJUSTMENT_AMOUNT_LOCAL = "penalty_price_adjustment_amount_local"
    val REBATE_PRICE_AMOUNT_LOCAL = "rebate_price_amount_local"
    val REFUND_PRICE_ADJUSTMENT_AMOUNT_LOCAL = "refund_price_adjustment_amount_local"
    val SERVICE_FEE_PRICE_AMOUNT_LOCAL = "service_fee_price_amount_local"
    val SERVICE_CHARGE_PRICE_AMOUNT_LOCAL = "service_charge_price_amount_local"
    val SUPPLIER_RECONCILIATION_PRICE_ADJUSTMENT_AMOUNT_LOCAL = "supplier_reconciliation_price_adjustment_amount_local"
    val SUPPLIER_RECONCILIATION_COST_ADJUSTMENT_LOCAL = "supplier_reconciliation_cost_adjustment_local"
    val TCM_PRICE_ADJUSTMENT_AMOUNT_LOCAL = "tcm_price_adjustment_amount_local"
    val SUPPLIER_COST_ADJUSTMENT_AMOUNT_LOCAL = "supplier_cost_adjustment_amount_local"
    val ECA_COST_ADJUSTMENT_AMOUNT_LOCAL = "eca_cost_adjustment_amount_local"
    val OTHER_COST_ADJUSTMENT_AMOUNT_LOCAL = "other_cost_adjustment_amount_local"
    val VARIABLE_MARGIN_COST_ADJUSTMENT_AMOUNT_LOCAL = "variable_margin_cost_adjustment_amount_local"
    val SERVICE_CHARGE_COST_AMOUNT_LOCAL = "service_charge_cost_amount_local"
    val ECA_FEE_COST_AMOUNT_LOCAL = "eca_fee_cost_amount_local"
    val VARIABLE_MARGIN_CREDIT_LOCAL = "variable_margin_credit_local"
    val PENALTY_COST_AMOUNT = "penalty_cost_amount";
    val PRE_TAX_ENGINE_PRICE_AMOUNT = "pre_tax_engine_price_amount"
    val PRE_TAX_ENGINE_COST_AMOUNT = "pre_tax_engine_cost_amount"
    val PRE_TAX_ENGINE_MARGIN_AMOUNT = "pre_tax_engine_margin_amount"
    val BASE_PRICE_AMOUNT = "base_price_amount"
    val OTHER_PRICE_ADJUSTMENT_AMOUNT = "other_price_adjustment_amount"
    val TOTAL_PRICE_ADJUSTMENT_AMOUNT = "total_price_adjustment_amount"
    val TOTAL_FEE_PRICE_AMOUNT = "total_fee_price_amount"
    val TOTAL_TAX_PRICE_AMOUNT = "total_tax_price_amount"
    val CANCEL_CHANGE_FEE_PRICE_AMOUNT = "cancel_change_fee_price_amount"
    val GROSS_BOOKING_AMOUNT = "gross_booking_amount"
    val COUPON_PRICE_AMOUNT = "coupon_price_amount"
    val CANCEL_PENALTY_WAIVER_PRICE_ADJUSTMENT_AMOUNT = "cancel_penalty_waiver_price_adjustment_amount"
    val EMPLOYEE_DISCOUNT_PRICE_ADJUSTMENT_AMOUNT = "employee_discount_price_adjustment_amount"
    val EXPEDIA_GOODWILL_PRICE_ADJUSTMENT_AMOUNT = "expedia_goodwill_price_adjustment_amount"
    val EXPEDIA_PENALTY_PRICE_ADJUSTMENT_AMOUNT = "expedia_penalty_price_adjustment_amount"
    val GOODWILL_PRICE_ADJUSTMENT_AMOUNT = "goodwill_price_adjustment_amount"
    val GENERIC_COUPON_PRICE_AMOUNT = "generic_coupon_price_amount"
    val LOYALTY_POINT_PRICE_ADJUSTMENT_AMOUNT = "loyalty_point_price_adjustment_amount"
    val PENALTY_PRICE_ADJUSTMENT_AMOUNT = "penalty_price_adjustment_amount"
    val REBATE_PRICE_AMOUNT = "rebate_price_amount"
    val REFUND_PRICE_ADJUSTMENT_AMOUNT = "refund_price_adjustment_amount"
    val SERVICE_FEE_PRICE_AMOUNT = "service_fee_price_amount"
    val SERVICE_CHARGE_PRICE_AMOUNT = "service_charge_price_amount"
    val SUPPLIER_RECONCILIATION_PRICE_ADJUSTMENT_AMOUNT = "supplier_reconciliation_price_adjustment_amount"
    val SUPPLIER_RECONCILIATION_COST_ADJUSTMENT = "supplier_reconciliation_cost_adjustment"
    val TCM_PRICE_ADJUSTMENT_AMOUNT = "tcm_price_adjustment_amount"
    val SUPPLIER_COST_ADJUSTMENT_AMOUNT = "supplier_cost_adjustment_amount"
    val ECA_COST_ADJUSTMENT_AMOUNT = "eca_cost_adjustment_amount"
    val OTHER_COST_ADJUSTMENT_AMOUNT = "other_cost_adjustment_amount"
    val VARIABLE_MARGIN_COST_ADJUSTMENT_AMOUNT = "variable_margin_cost_adjustment_amount"
    val SERVICE_CHARGE_COST_AMOUNT = "service_charge_cost_amount"
    val ECA_FEE_COST_AMOUNT = "eca_fee_cost_amount"
    val VARIABLE_MARGIN_CREDIT = "variable_margin_credit"
    val BASE_COST_AMOUNT = "base_cost_amount"
    val TOTAL_COST_ADJUSTMENT_AMOUNT = "total_cost_adjustment_amount"
    val TOTAL_FEE_COST_AMOUNT = "total_fee_cost_amount"
    val OTHER_FEE_COST_AMOUNT = "other_fee_cost_amount"
    val TOTAL_TAX_COST_AMOUNT = "total_tax_cost_amount"
    val TOTAL_COST_AMOUNT = "total_cost_amount"
    val PURCHASE_BASE_PRICE_AMOUNT = "purchase_base_price_amount"
    val TOTAL_PRICE_ADJUSTMENT_AMOUNT_TAX_EXCLUSIVE = "total_price_adjustment_amount_tax_exclusive"
    val TOTAL_COST_ADJUSTMENT_AMOUNT_TAX_EXCLUSIVE = "total_cost_adjustment_amount_tax_exclusive"
    val TOTAL_FEE_PRICE_AMOUNT_TAX_EXCLUSIVE = "total_fee_price_amount_tax_exclusive"
    val TOTAL_FEE_COST_AMOUNT_TAX_EXCLUSIVE = "total_fee_cost_amount_tax_exclusive"

    val LGL_ENTITY_CODE = "legal_entity_code"
    val LGL_ENTITY_NAME = "legal_entity_name"
    val LGL_ENTITY_KEY = "lgl_entity_key"
    val LGL_ENTITY_CODE_COL = "lgl_entity_code"
    val LGL_ENTITY_NAME_COL = "lgl_entity_name"
    val GENERAL_LEDGER_ACCOUNT = "general_ledger_account"
    val GENERAL_LEDGER_LIABILITY_ACCOUNT = "general_ledger_liability_account"
    val POINT_OF_SALE_KEY = "point_of_sale_key";
    val POINT_OF_SALE_BRAND_NAME = "point_of_sale_brand_name";
    val POINT_OF_SALE_NAME = "point_of_sale_name";
    val MANAGEMENT_UNIT_KEY = "management_unit_key";
    val MANAGEMENT_UNIT_CODE = "management_unit_code";
    val MANAGEMENT_UNIT_NAME = "management_unit_name";
    val MANAGEMENT_UNIT_LEVEL_6_NAME = "management_unit_level_6_name";
    val ORACLE_GL_PRODUCT_KEY = "oracle_gl_product_key";
    val TRAVEL_SERVICE_PROVIDER_NAME = "travel_service_provider_name"
    val LEGAL_ENTITY_INFO = "legal_entity_info"
    val LEGAL_ENTITY_INFO_1 = "legal_entity_info._1"
    val LEGAL_ENTITY_INFO_2 = "legal_entity_info._2"

    val POS_KEY = "pos_key";
    val BRAND_NAME = "brand_name";
    val POS_NAME = "pos_name";
    val MGMT_UNIT_KEY = "mgmt_unit_key";
    val MGMT_UNIT_CODE = "mgmt_unit_code";
    val MGMT_UNIT_NAME = "mgmt_unit_name";
    val MGMT_UNIT_LVL_6_NAME = "mgmt_unit_lvl_6_name";

    val EG_PROPERTY_ID = "eg_property_id"
    val LODG_PROPERTY_KEY = "lodg_property_key"
    val EXPE_LODG_PROPERTY_ID = "expe_lodg_property_id"
    val PROPERTY_NAME = "property_name"
    val PROPERTY_ADDRESS_LINE_1 = "property_address_line_1"
    val PROPERTY_ADDRESS_LINE_2 = "property_address_line_2"
    val FIRST_ADDRESS_LINE = "first_address_line"
    val SECOND_ADDRESS_LINE = "second_address_line"
    val PROPERTY_CITY_NAME = "city_name"
    val PROPERTY_STATE_PROVINCE_NAME = "state_province_name"
    val PROPERTY_COUNTRY_NAME = "country_name"
    val PROPERTY_COUNTRY_CODE = "country_code"
    val NON_CLEANSED_COUNTRY_CODE = "non_cleansed_country_code"
    val PROPERTY_POSTAL_CODE = "postal_code"
    val PROPERTY_LONGITUDE = "longitude"
    val PROPERTY_LATITUDE = "latitude"
    val PROPERTY_TYPE_NAME = "structure_type_name"
    val PROPERTY_TOTAL_NUMBER_OF_UNITS = "property_total_number_of_units"
    val PROPERTY_BRAND_ID = "brand_id"
    val PROPERTY_BRAND_NAME = "brand_name"
    val PROPERTY_PARENT_CHAIN_ID = "parent_chain_id"
    val PROPERTY_PARENT_CHAIN_NAME = "parent_chain_name"
    val DEFAULT_PROPERTY_PARENT_CHAIN_ID = 0
    val DEFAULT_PROPERTY_PARENT_CHAIN_NAME = "Not Available"
    val UPDATED_COUNTRY_CODE = "updated_country_code"
    val UPDATED_STATE_PROVINCE_NAME = "updated_state_province_name"
    val UPDATED_TAX_AREA_ID = "updated_tax_area_id"

    val LISTING_NUMBER = "listing_number"
    val LISTING_PRODUCT_TYPE = "listing_product_type"

    val EXCH_RATE = "exch_rate"
    val EXCH_RATE_BOOK_DATE = "exch_rate_book_date"
    val EXCH_RATE_STAY_DATE = "exch_rate_stay_date"
    val UPDATED_EXCH_RATE_STAY_DATE = "updated_exch_rate_stay_date"
    val EXCH_RATE_DATE = "exch_rate_date"
    val FROM_CURRN_CODE = "from_currn_code"
    val TO_CURRN_CODE = "to_currn_code"
    val EXCH_RATE_STAY_DATE_COST = "exch_rate_stay_date_cost"
    val UPDATED_BOOK_DATE = "updated_book_date"

    val EXCEPTIONS = "exceptions"
    val EXCEPTION_CODE = "exception_code"
    val EXCEPTION_TYPE = "exception_type"
    val EXCEPTION_DESCRIPTION = "exception_description"
    val IS_CRITICAL_EXCEPTION = "is_critical_exception"
    val STG_BKG_EXCEPTIONS = "stg_bkg_exceptions"

    val RUN_ID = "run_id"
    val ETL_TIMESTAMP = "etl_timestamp"

    val EVENT_INFO = "event_info"
    val EVENT_UUID = "event_uuid"
    val HASH_EVENT_UUID = "hash_event_uuid"
    val STAGE_EVENT_UUID = "stage_event_uuid"
    val PUBLISHED_TIMESTAMP = "published_timestamp"
    val EVENT_SOURCE_SYSTEM_NAME = "event_source_system_name"
    val STAY_DATE_RESERVATION = "StayDateReservation"
    val GTP_LEGACY = "GTP legacy"
    val TRANS_DATE_RESERVATION = "TransDateReservation"
    val EVENT_INFO_PUBLISHED_TIMESTAMP = "event_info.published_timestamp"

    val EVENT_INFO_HASH_EVENT_UUID = "event_info.event_uuid"

    val JOB_NAME = "job_name"
    val STAY_DATES = "stay_dates"
    val TRANSACTION_LIABILITY_DATES = "transaction_liability_date"

    val BEARDSLEY_PROPERTY_ID = "beardsley_property_id"
    val PROPERTY_SOURCE_ID = "property_source_id"
    val PROPERTY_STATUS = "property_status"
    val SELLER_ID = "seller_id"
    val TAX_AREA_ID = "tax_area_id"
    val CONTENT_SOURCE = "content_source"
    val GEOCODE_OVERRIDE = "geocode_override"
    val GEOCODE_OVERRIDE_CONTENT_SOURCE = "geocode_override_content_source"
    val STREET_ADDRESS1 = "street_address1"
    val STREET_ADDRESS2 = "street_address2"
    val CITY = "city"
    val STATE = "state"
    val COUNTRY_CODE = "country_code"
    val COUNTRY = "country"
    val PRODUCT_CATALOG_ATTRIBUTES = "attributes"
    val PD_COUNTRY_CODE = "pd_country_code"
    val POSTAL_CODE = "postal_code"
    val COUNTY = "county"
    val PD_POSTAL_CODE = "pd_postal_code"
    val JURISDICTION_NAME = "Jurisdiction_Name"
    val JURISDICTION_LEVEL = "Jurisdiction_Level"
    val PUBLISHED_DATE = "published_date"
    val TENANT = "tenant"

    val START_DATE = "start_date"
    val END_DATE = "end_date"

    val CRITERIA_REPROCESS = "criteria-reprocess"
    val POST_STAY_CRITERIA_REPROCESS = "post-stay-criteria-reprocess"

    val REPLICATION_END_DATETIME_FIELD_NAME = "com.hotels.bdp.circustrain.last.replicated"
    val REPLICATION_MODE_FIELD_NAME = "com.hotels.bdp.circustrain.replication.mode"
    val REPLICATION_END_TIME = "replication_end_time"
    val REPLICATION_MODE = "replication_mode"
    val REPLICATION_DATE = "replication_date"
    val WORKFLOW_TO_BE_TRIGGERED = "workflow_to_be_triggered"
    val ETL_DATE_TIME = "etl_date_time"
    val REPLICATION_COUNT = "replication_count"

    val LODG_RM_NIGHT_TRANS_FACT = "lodg_rm_night_trans_fact"
    val CAR_RENTL_DAY_TRANS_FACT = "car_rentl_day_trans_fact"

    val CAR_VENDOR_NAME = "car_vendor_name"
    val CAR_VENDOR_CODE = "car_vendor_code"
    val CAR_PICK_UP_LOCATION_NAME = "car_pick_up_location_name"
    val CAR_PICK_UP_LOCATION_CITY_NAME = "car_pick_up_location_city_name"
    val CAR_PICK_UP_LOCATION_STREET_ADDRESS1 = "car_pick_up_location_street_address1"
    val CAR_PICK_UP_LOCATION_STREET_ADDRESS2 = "car_pick_up_location_street_address2"
    val CAR_PICK_UP_LOCATION_POSTAL_CODE = "car_pick_up_location_postal_code"
    val CAR_PICK_UP_LOCATION_LATITUDE = "car_pick_up_location_latitude"
    val CAR_PICK_UP_LOCATION_LONGITUDE = "car_pick_up_location_longitude"
    val CAR_PICK_UP_LOCATION_STATE_PROVINCE_NAME = "car_pick_up_location_state_province_name"
    val CAR_PICK_UP_LOCATION_COUNTRY_CODE = "car_pick_up_location_country_code"
    val CAR_DROP_OFF_LOCATION_NAME = "car_drop_off_location_name"
    val CAR_DROP_OFF_LOCATION_CITY_NAME = "car_drop_off_location_city_name"
    val CAR_DROP_OFF_LOCATION_STATE_PROVINCE_NAME = "car_drop_off_location_state_province_name"
    val CAR_DROP_OFF_LOCATION_COUNTRY_CODE = "car_drop_off_location_country_code"
    val CAR_TAX_AREA_ID = "car_tax_area_id"
    val PRODUCT_CAR_TAX_AREA_ID = "product_car_tax_area_id"
    val PRODUCT_CATALOG_COUNTRY_CODE = "product_catalog_country_code"
    val PRODUCT_CATALOG_TAX_AREA_ID = "product_catalog_tax_area_id"
    val CAR_ADDRESS_RESPONSE = "car_address_response"
    val CAR_LOCATION_ID = "car_location_id"
    val CAR_PICKUP_LOCAL_LOCATION_ID = "car_pickup_local_location_id"
    val CAR_LOCAL_LOCATION_PROD_ID = "car_local_location_prod_id"
    val DISPLAY_NUMBER = "q_car_purch_hw_conf_num"
    val DAY_CODE = "day_code"
    val RENTAL_DAY_COUNT = "rental_day_count"
    val TOTAL_RENTAL_DAY_COUNT = "total_rental_day_count"
    val BOOKING_EVENT_TYPE_NAME = "booking_event_type_name"
    val PRODUCT_CATALOG_LATITUDE = "product_catalog_latitude"
    val PRODUCT_CATALOG_LONGITUDE = "product_catalog_longitude"
    val PRODUCT_CATALOG_POSTAL_CODE = "product_catalog_postal_code"
    val PRODUCT_CATALOG_STATE = "product_catalog_state"
    val PRODUCT_CATALOG_CITY = "product_catalog_city"
    val PRODUCT_CATALOG_STREET_ADDRESS1 = "product_catalog_street_address1"
    val PRODUCT_CATALOG_STREET_ADDRESS2 = "product_catalog_street_address2"
    val PRODUCT_CATALOG_SUPPLIER_ID = "product_catalog_supplier_id"
    val PRODUCT_CATALOG_SUPPLIER_NAME = "product_catalog_supplier_name"
    var PRODUCT_CATALOG_COUNTY = "product_catalog_county"



    val BASE_PRICE_AMOUNT_LOCAL = "base_price_amount_local"
    val OTHER_PRICE_ADJUSTMENT_AMOUNT_LOCAL = "other_price_adjustment_amount_local"
    val TOTAL_PRICE_ADJUSTMENT_AMOUNT_LOCAL = "total_price_adjustment_amount_local"
    val TOTAL_FEE_PRICE_AMOUNT_LOCAL = "total_fee_price_amount_local"
    val TOTAL_TAX_PRICE_AMOUNT_LOCAL = "total_tax_price_amount_local"
    val CANCEL_CHANGE_FEE_PRICE_AMOUNT_LOCAL = "cancel_change_fee_price_amount_local"
    val GROSS_BOOKING_AMOUNT_LOCAL = "gross_booking_amount_local"
    val INVOICE_LEGAL_ENTITY_CODE = "invoice_legal_entity_code"
    val INVOICE_LEGAL_ENTITY_NAME = "invoice_legal_entity_name"
    val LEGAL_ENTITY_CODE = "legal_entity_code"
    val LEGAL_ENTITY_NAME = "legal_entity_name"
    val BOOKING_EVENT_TYPE_KEY = "booking_event_type_key"
    val COUPON_PRICE_AMOUNT_LOCAL = "coupon_price_amount_local"

    val MARGIN_AMOUNT_USD = "margin_amount_usd"
    val PURE_MARGIN_AMOUNT_USD = "pure_margin_amount_usd"
    val BASE_COST_AMOUNT_LOCAL = "base_cost_amount_local"
    val TOTAL_COST_ADJUSTMENT_AMOUNT_LOCAL = "total_cost_adjustment_amount_local"
    val TOTAL_FEE_COST_AMOUNT_LOCAL = "total_fee_cost_amount_local"
    val OTHER_FEE_COST_AMOUNT_LOCAL = "other_fee_cost_amount_local"
    val TOTAL_TAX_COST_AMOUNT_LOCAL = "total_tax_cost_amount_local"
    val TOTAL_COST_AMOUNT_LOCAL = "total_cost_amount_local"
    val USE_DATE = "use_date"

    val PARTNER_ID = "partner_id"
    val PARTNER_NAME = "partner_name"
    val PARTNER_ADDRESS = "partner_address"
    val PARTNER_ADDRESS_LINE_1 = "address_line_1"
    val PARTNER_ADDRESS_LINE_2 = "address_line_2"
    val PARTNER_CITY = "city"
    val PARTNER_STATE = "state"
    val PARTNER_POSTAL_CODE = "postal_code"
    val PARTNER_COUNTRY_CODE = "country_code"
    val PARTNER_DISTRICT = "district"
    val PARTNER_COUNTY = "county"
    val PARTNER_ADDRESS_TYPE = "address_type"
    val PARTNER_LATITUDE = "latitude"
    val PARTNER_LONGITUDE = "longitude"
    val PARTNER_ATTRIBUTES = "partner_attributes"

    val EVENT_HEADER_PUBLISHED_TIMESTAMP = "event_header.published_timestamp"
    val SUPPLIER_ID = "supplier_id"
    val SUPPLIER_NAME = "supplier_name"
    val LINE_OF_BUSINESS = "line_of_business"
    val SELLER = "seller"
    val ATTRIBUTES = "attributes"

    val PROPERTY_TYPE = "property_type"
    val CERTIFICATE_ID = "certificate_id"
    val MULTIPROPERTY_FLAG = "multiproperty_flag"

    var CLEANSED_COUNTRY_CODE = "cleansed_country_code"
    var CLEANSED_STATE = "cleansed_state"
    var CLEANSED_CITY = "cleansed_city"
    var CLEANSED_STREET_ADDRESS1 = "cleansed_street_address1"
    var CLEANSED_STREET_ADDRESS2 = "cleansed_street_address2"
    var CLEANSED_COUNTY = "cleansed_county"
    var CLEANSED_POSTAL_CODE = "cleansed_postal_code"
    var CLEANSED_LATITUDE = "cleansed_latitude"
    var CLEANSED_LONGITUDE = "cleansed_longitude"

    val ACTIVITY_ID = "activity_id"
    val INTERNAL_CATEGORY_NAME = "internal_category_name"
    val OFFERING_VENDOR_NAME = "offering_vendor_name"
    val OFFERING_VENDOR_BRANCH_STATE_PROVINCE_NAME = "offering_vendor_branch_state_province_name"
    val OFFERING_VENDOR_BRANCH_NAME = "offering_vendor_branch_name"
    val OFFERING_VENDOR_BRANCH_COUNTRY_NAME = "offering_vendor_branch_country_name"
    val OFFERING_NAME = "offering_name"
    val OFFERING_ITEM_NAME = "offering_item_name"
    val OFFERING_CATEGORY_NAME = "offering_category_name"
    val VERTEX_COUNTY = "vertex_county"
    val VERTEX_CITY = "vertex_city"
    val ACTIVITY_REDEMPTION_STATE_PROVINCE_NAME = "activity_redemption_state_province_name"
    val ACTIVITY_REDEMPTION_LATITUDE = "activity_redemption_latitude"
    val ACTIVITY_REDEMPTION_LONGITUDE = "activity_redemption_longitude"
    val ACTIVITY_REDEMPTION_COUNTRY = "activity_redemption_country"
    val ACTIVITY_REDEMPTION_CITY = "activity_redemption_city"
    val ACTIVITY_REDEMPTION_ADDRESS = "activity_redemption_address"
    val TICKET_COUNT = "ticket_count"

    //LX Product Catalog columns
    val PC_SUPPLIER_ID = "pc_supplier_id"
    val PC_STATE = "pc_state"
    val PC_CITY = "pc_city"
    val PC_POSTAL_CODE = "pc_postal_code"
    val PC_STREET_ADDRESS_1 = "pc_street_address1"
    val PC_STREET_ADDRESS_2 = "pc_street_address2"
    val PC_COUNTY = "pc_county"
    val PC_COUNTRY_CODE = "pc_country_code"
    val PC_CLEANSED_STATE = "pc_cleansed_state"
    val PC_CLEANSED_CITY = "pc_cleansed_city"
    val PC_CLEANSED_POSTAL_CODE = "pc_cleansed_postal_code"
    val PC_CLEANSED_STREET_ADDRESS_1 = "pc_cleansed_street_address1"
    val PC_CLEANSED_STREET_ADDRESS_2 = "pc_cleansed_street_address2"
    val PC_CLEANSED_COUNTRY_CODE = "pc_cleansed_country_code"
    val PC_CLEANSED_COUNTY = "pc_cleansed_county"
    val PC_LATITUDE = "pc_latitude"
    val PC_LONGITUDE = "pc_longitude"
    val PC_CLEANSED_LATITUDE = "pc_cleansed_latitude"
    val PC_CLEANSED_LONGITUDE = "pc_cleansed_longitude"
    val PC_TAX_AREA_ID = "pc_tax_area_id"
    val PC_PUBLISHED_TIMESTAMP = "pc_published_timestamp"

    var HOTWIRE_LEGAL_ENTITY_CODE = "75110"
    var OPAQUE_MERCHANT = "Opaque Merchant"

    var EXPEDIA_LEGAL_ENTITY_CODE = "11105"
    var AGENCY = "Agency"
    var HOTWIRE = "Hotwire"

    val INVOICE_NUMBER = "invoice_number"
    val INVOICE_DATE = "invoice_date"
    val INVOICE_TYPE = "invoice_type"
    val INVOICE_LINES = "invoice_lines"
    val INVOICE_LINE_NUMBER = "invoice_line_number"
    val ADDITIONAL_ATTRIBUTES = "additional_attributes"
    val PRODUCT_TYPE = "product_type"

    //File Upload
    val POSTING_DATE = "posting_date"
    val PRODUCT_LINE = "product_line"
    val TAX_BASE_OPTION = "tax_base_option"
    val PRE_TAX_ENGINE_PRICE_AMOUNT_USD = "pre_tax_engine_price_amount_usd"
    val PRE_TAX_ENGINE_COST_AMOUNT_USD = "pre_tax_engine_cost_amount_usd"
    val PRE_TAX_ENGINE_MARGIN_AMOUNT_USD = "pre_tax_engine_margin_amount_usd"
    val SERVICE_PROVIDER_NAME = "service_provider_name"
    val ORACLE_GL_PRODUCT_CODE = "oracle_gl_product_code"
    val LOCATION_ID = "location_id"
    val TAX_BASE_OPTION_A = "A"
    val TAX_BASE_OPTION_B = "B"
    val TAX_BASE_OPTION_C = "C"
    val GTP_FILE_UPLOAD = "GTP file upload"
    val TAX_DUE_AMOUNT = "tax_due_amount"
    val ACTIVITY_ID_V5 = "activityid"
    val LEGACY_VOUCHER = "legacy_voucher"
    val OFFER_ID_V5 = "offerid"
    val SERVICE_ADDRESS_LINE_1 = "service_address_line_1"
    val SERVICE_CITY_NAME = "service_city_name"
    val SERVICE_STATE_NAME = "service_state_name"
    val SERVICE_POSTAL_CODE = "service_postal_code"
    val SERVICE_COUNTRY_CODE = "service_country_code"

    // United tax profile table
    val SUPPLIER_DIM = "supplier_dim"
    val TAX_PROFILE_SUPPLIER_ID = "supplier_id"
    val TAX_PROFILE_COUNTRY = "country"
    val TAX_PROFILE_STATE = "state"

    val TAX_DEFINED_ATTRIBUTES_ACCURACY = "tax_defined_attributes_accuracy"
    val TAX_DEFINED_ATTRIBUTES_FILING = "tax_defined_attributes_filing"
    val SUPPLIER_ATTRIBUTES_ACCURACY = "supplier_attributes_accuracy"
    val SUPPLIER_ATTRIBUTES_FILING = "supplier_attributes_filing"
    val ATTRIBUTES_SET = Set(TAX_DEFINED_ATTRIBUTES_ACCURACY, TAX_DEFINED_ATTRIBUTES_FILING, SUPPLIER_ATTRIBUTES_ACCURACY, SUPPLIER_ATTRIBUTES_FILING)

    val TAX_PROFILE_KEY = "key"
    val TAX_PROFILE_VALUES = "values"
    val TAX_PROFILE_START_DATE = "start_effective_date"
    val TAX_PROFILE_END_DATE = "end_effective_date"
    val TAX_PROFILE_ATTRIBUTES = "tax_profile_attributes"

    val LISTING_ID = "Listing_ID"
    val LISTING_IDENTIFIER = "listing_identifier"
    val UNIT_URI = "unit_uri"
    val BOOKING_HISTORY_COLUMN = "booking_history"

    val bookingItemColumns = "named_struct("
        .concat("\"" + STAY_DATE + "\",  cast(stay_date as string), ")
        .concat("\"" + BOOK_DATE + "\", cast(book_date as string), ")
        .concat("\"" + BEGIN_USE_DATE + "\", cast(begin_use_date as string), ")
        .concat("\"" + END_USE_DATE + "\", cast(end_use_date as string), ")
        .concat("\"" + ROOM_NIGHT_COUNT + "\", room_night_count, ")
        .concat("\"" + BOOKING_ITEM_ID + "\", cast(booking_item_id as string), ")
        .concat("\"" + BOOKING_ID + "\", booking_id, ")
        .concat("\"" + SOURCE_SYSTEM_ID + "\", source_system_id, ")
        .concat("\"" + BOOKING_EVENT_DATE + "\", cast(booking_event_date as string), ")
        .concat("\"" + BOOKING_EVENT_DATETIME + "\", cast(booking_event_datetime as string), ")
        .concat("\"" + TRANSACTION_TYPE_NAME + "\", cast(transaction_type_name as string), ")
        .concat("\"" + BUSINESS_MODEL_NAME + "\", business_model_name, ")
        .concat("\"" + BUSINESS_MODEL_SUBTYPE_NAME + "\", business_model_subtype_name, ")
        .concat("\"" + PRODUCT_LINE_NAME + "\", product_line_name, ")
        .concat("\"" + TRAVEL_PRODUCT_ID + "\", travel_product_id, ")
        .concat("\"" + TOTAL_TRAVELER_COUNT + "\", total_traveler_count, ")
        .concat("\"" + TRANSACTION_TYPE_KEY + "\", transaction_type_key, ")
        .concat("\"" + TOTAL_ROOM_NIGHT_COUNT + "\", total_room_night_count, ")
        .concat("\"" + NIGHT_NUMBER + "\", night_number, ")
        .concat("\"" + TRAVEL_RECORD_LOCATOR + "\", travel_record_locator, ")
        .concat("\"" + LODG_ROOM_TYPE_ID + "\", lodg_rm_typ_id,")
        .concat("\"" + PKG_IND + "\", package_indicator,")
        .concat("\"" + RESERVATION_UUID + "\", NULL, ")
        .concat("\"" + RESERVATION_STATE + "\", NULL, ")
        .concat("\"" + RESERVATION_STATUS + "\", NULL,")
        .concat("\"" + SUPPLIER_MASTER_BRAND + "\", NULL,")
        .concat("\"" + TRAVELER_BOOKING_SITE + "\", NULL,")
        .concat("\"" + MERCHANT_OF_RECORD_TYPE + "\", NULL")
        .concat(") as booking_item")

    val bookingItemColumnsVrbo = "named_struct("
        .concat("\"" + STAY_DATE + "\",  cast(stay_date as string), ")
        .concat("\"" + BOOK_DATE + "\", coalesce(cast(book_date as string), cast(booking_event_date as string)), ")
        .concat("\"" + BEGIN_USE_DATE + "\", cast(begin_use_date as string), ")
        .concat("\"" + END_USE_DATE + "\", cast(end_use_date as string), ")
        .concat("\"" + ROOM_NIGHT_COUNT + "\", room_night_count, ")
        .concat("\"" + BOOKING_ITEM_ID + "\", cast(booking_item_id as string), ")
        .concat("\"" + BOOKING_ID + "\", booking_id, ")
        .concat("\"" + SOURCE_SYSTEM_ID + "\", NULL, ")
        .concat("\"" + BOOKING_EVENT_DATE + "\", cast(booking_event_date as string), ")
        .concat("\"" + BOOKING_EVENT_DATETIME + "\", cast(booking_event_datetime as string), ")
        .concat("\"" + TRANSACTION_TYPE_NAME + "\", cast(transaction_type_name as string), ")
        .concat("\"" + BUSINESS_MODEL_NAME + "\", business_model_name, ")
        .concat("\"" + BUSINESS_MODEL_SUBTYPE_NAME + "\", business_model_subtype_name, ")
        .concat("\"" + PRODUCT_LINE_NAME + "\", product_line_name, ")
        .concat("\"" + TRAVEL_PRODUCT_ID + "\", NULL, ")
        .concat("\"" + TOTAL_TRAVELER_COUNT + "\", NULL, ")
        .concat("\"" + TRANSACTION_TYPE_KEY + "\", NULL, ")
        .concat("\"" + TOTAL_ROOM_NIGHT_COUNT + "\", room_night_count, ")
        .concat("\"" + NIGHT_NUMBER + "\", NULL, ")
        .concat("\"" + TRAVEL_RECORD_LOCATOR + "\", NULL, ")
        .concat("\"" + LODG_ROOM_TYPE_ID + "\", NULL,")
        .concat("\"" + PKG_IND + "\", NULL,")
        .concat("\"" + RESERVATION_UUID + "\", reservation_uuid, ")
        .concat("\"" + RESERVATION_STATE + "\", reservation_state, ")
        .concat("\"" + RESERVATION_STATUS + "\", reservation_status,")
        .concat("\"" + SUPPLIER_MASTER_BRAND + "\", supplier_master_brand,")
        .concat("\"" + TRAVELER_BOOKING_SITE + "\", traveler_booking_site,")
        .concat("\"" + MERCHANT_OF_RECORD_TYPE + "\", merchant_of_record_type")
        .concat(") as booking_item")

    val stageBookingItemColumns = "named_struct("
        .concat("\"" + USE_DATE + "\",  cast(begin_use_date as string), ")
        .concat("\"" + BOOK_DATE + "\", cast(book_date as string), ")
        .concat("\"" + BEGIN_USE_DATE + "\", cast(begin_use_date as string), ")
        .concat("\"" + END_USE_DATE + "\", cast(end_use_date as string), ")
        .concat("\"" + ROOM_NIGHT_COUNT + "\", NULL, ")
        .concat("\"" + BOOKING_ITEM_ID + "\", cast(reservation_reference_number as string), ")
        .concat("\"" + BOOKING_ID + "\", NULL, ")
        .concat("\"" + SOURCE_SYSTEM_ID + "\", NULL, ")
        .concat("\"" + BOOKING_EVENT_DATE + "\", cast(transaction_date as string), ")
        .concat("\"" + BOOKING_EVENT_DATETIME + "\", cast(transaction_date_time as string), ")
        .concat("\"" + TRANSACTION_TYPE_NAME + "\", cast(event_type as string), ")
        .concat("\"" + BUSINESS_MODEL_NAME + "\", business_model_name, ")
        .concat("\"" + BUSINESS_MODEL_SUBTYPE_NAME + "\", NULL, ")
        .concat("\"" + PRODUCT_LINE_NAME + "\", product_line_name, ")
        .concat("\"" + TRAVEL_PRODUCT_ID + "\", NULL, ")
        .concat("\"" + TOTAL_TRAVELER_COUNT + "\", NULL, ")
        .concat("\"" + TRANSACTION_TYPE_KEY + "\", NULL, ")
        .concat("\"" + TRAVEL_RECORD_LOCATOR + "\", NULL, ")
        .concat("\"" + LODG_ROOM_TYPE_ID + "\", NULL, ")
        .concat("\"" + ITIN_NBR + "\", NULL, ")
        .concat("\"" + PKG_IND + "\", NULL, ")
        .concat("\"" + RESERVATION_UUID + "\", reservation_uuid, ")
        .concat("\"" + RESERVATION_STATE + "\", reservation_state, ")
        .concat("\"" + RESERVATION_STATUS + "\", reservation_status,")
        .concat("\"" + SUPPLIER_MASTER_BRAND + "\", supplier_master_brand,")
        .concat("\"" + TRAVELER_BOOKING_SITE + "\", traveler_booking_site,")
        .concat("\"" + MERCHANT_OF_RECORD_TYPE + "\", merchant_of_record_type")
        .concat(") as booking_item")

    val itemAmountColumns = "named_struct("
        .concat("\"base_price_amount_local\"," + BASE_PRICE_AMT_LOCAL + ",")
        .concat("\"other_price_adjustment_amount_local\"," + OTHR_PRICE_ADJ_AMT_LOCAL + ",")
        .concat("\"penalty_price_adjustment_amount_local\"," + PNLTY_PRICE_ADJ_AMT_LOCAL + ",")
        .concat("\"expedia_penalty_price_adjustment_amount_local\"," + EXPE_PNLTY_PRICE_ADJ_AMT_LOCAL + ",")
        .concat("\"total_price_adjustment_amount_local\"," + TOTL_PRICE_ADJ_AMT_LOCAL + ",")
        .concat("\"service_fee_price_amount_local\"," + SVC_FEE_PRICE_AMT_LOCAL + ",")
        .concat("\"total_fee_price_amount_local\"," + TOTL_FEE_PRICE_AMT_LOCAL + ",")
        .concat("\"total_tax_price_amount_local\"," + TOTL_TAX_PRICE_AMT_LOCAL + ",")
        .concat("\"service_charge_price_amount_local\"," + SVC_CHRG_PRICE_AMT_LOCAL + ",")
        .concat("\"cancel_change_fee_price_amount_local\"," + CNCL_CHG_FEE_PRICE_AMT_LOCAL + ",")
        .concat("\"base_cost_amount_usd\"," + BASE_COST_AMT_USD + ",")
        .concat("\"other_cost_adjustment_amount_usd\"," + OTHR_COST_ADJ_AMT_USD + ",")
        .concat("\"supplier_cost_adjustment_amount_usd\"," + SUPPL_COST_ADJ_AMT_USD + ",")
        .concat("\"total_cost_adjustment_amount_usd\"," + TOTL_COST_ADJ_AMT_USD + ",")
        .concat("\"total_cost_amount_usd\"," + TOTL_COST_AMT_USD + ",")
        .concat("\"total_fee_cost_amount_usd\"," + TOTL_FEE_COST_AMT_USD + ",")
        .concat("\"total_tax_cost_amount_usd\"," + TOTL_TAX_COST_AMT_USD + ",")
        .concat("\"gross_booking_amount_local\"," + GROSS_BKG_AMT_LOCAL + ",")
        .concat("\"other_fee_price_amount_local\"," + OTHER_FEE_PRICE_AMOUNT_LOCAL + ",")
        .concat("\"agent_assisted_purchase_fee_amount_local\"," + AGENT_ASSISTED_PURCHASE_FEE_AMOUNT_LOCAL + ",")
        .concat("\"" + PRICE_CURRENCY_CODE + "\", cast(updated_price_currency_code as string),")
        .concat("\"" + COST_CURRENCY_CODE + "\", cast(updated_cost_currency_code as string),")
        .concat("\"" + GROSS_BOOKING_AMOUNT_USD + "\", cast(0 as decimal(18,4)),")
        .concat("\"" + EXCHANGE_RATE_BOOK_DATE + "\", cast(CASE WHEN exch_rate_book_date IS NULL THEN 0 ELSE exch_rate_book_date END as decimal(24,15)),")
        .concat("\"" + EXCHANGE_RATE_STAY_DATE + "\", cast(CASE WHEN exch_rate_stay_date IS NULL THEN 0 ELSE exch_rate_stay_date END as decimal(24,15)),")
        .concat("\"coupon_price_amount_local\"," + COUPN_PRICE_AMT_LOCAL + ",")
        .concat("\"expedia_goodwill_price_adjustment_amount_local\"," + EXPE_GDWLL_PRICE_ADJ_AMT_LOCAL + ",")
        .concat("\"goodwill_price_adjustment_amount_local\"," + GDWLL_PRICE_ADJ_AMT_LOCAL + ",")
        .concat("\"generic_coupon_price_amount_local\"," + GENRIC_COUPN_PRICE_AMT_LOCAL + ",")
        .concat("\"refund_price_adjustment_amount_local\"," + REFUND_PRICE_ADJ_AMT_LOCAL + ",")
        .concat("\"rebate_price_amount_local\"," + REBATE_PRICE_AMT_LOCAL + ",")
        .concat("\"tcm_price_adjustment_amount_local\"," + TCM_PRICE_ADJ_AMT_LOCAL + ",")
        .concat("\"cancel_penalty_waiver_price_adjustment_amount_local\"," + CNCL_PNLTY_WAIVR_PRICE_ADJ_AMT_LOCAL + ",")
        .concat("\"loyalty_point_price_adjustment_amount_local\"," + LOYLTY_POINT_PRICE_ADJ_AMT_LOCAL + ",")
        .concat("\"employee_discount_price_adjustment_amount_local\"," + EMP_DISC_PRICE_ADJ_AMT_LOCAL + ",")
        .concat("\"supplier_reconciliation_price_adjustment_amount_local\"," + SUPPL_RECON_PRICE_ADJ_AMT_LOCAL + ",")
        .concat("\"penalty_amount_local\"," + PENALTY_AMOUNT_LOCAL + ",")
        .concat("\"tax_rate_book_date\"," + TAX_RATE_BOOK_DATE + ",")
        .concat("\"purchase_base_price_amount_local\"," + "CASE WHEN purchase_base_price_amount_local IS NULL THEN 0 ELSE purchase_base_price_amount_local END" + ",")
        .concat("\"total_cost_amount_local\"," + TOTL_COST_AMT_LOCAL + ",")
        .concat("\"base_cost_amount_local\"," + BASE_COST_AMT_LOCAL + ",")
        .concat("\"total_cost_adjustment_amount_local\"," + TOTL_COST_ADJ_AMT_LOCAL + ",")
        .concat("\"supplier_cost_adjustment_amount_local\"," + SUPPL_COST_ADJ_AMT_LOCAL + ",")
        .concat("\"eca_cost_adjustment_amount_local\"," + ECA_COST_ADJ_AMT_LOCAL + ",")
        .concat("\"other_cost_adjustment_amount_local\"," + OTHR_COST_ADJ_AMT_LOCAL + ",")
        .concat("\"variable_margin_cost_adjustment_amount_local\"," + VAR_MARGN_COST_ADJ_LOCAL + ",")
        .concat("\"supplier_reconciliation_cost_adjustment_local\"," + SUPPL_RECON_COST_ADJ_AMT_LOCAL + ",")
        .concat("\"total_fee_cost_amount_local\"," + TOTL_FEE_COST_AMT_LOCAL + ",")
        .concat("\"service_charge_cost_amount_local\"," + SVC_CHRG_COST_AMT_LOCAL + ",")
        .concat("\"other_fee_cost_amount_local\"," + OTHR_FEE_COST_AMT_LOCAL + ",")
        .concat("\"eca_fee_cost_amount_local\"," + ECA_FEE_COST_AMT_LOCAL + ",")
        .concat("\"total_tax_cost_amount_local\"," + TOTL_TAX_COST_AMT_LOCAL + ",")
        .concat("\"variable_margin_credit_local\"," + VAR_MARGN_CREDT_LOCAL + ",")
        .concat("\"margin_amount_usd\"," + MARGN_AMT_USD + ",")
        .concat("\"pure_margin_amount_usd\"," + PURE_MARGN_AMT_USD + ",")
        .concat("\"extra_person_cost_amount_local\"," + EXTRA_PERSN_COST_AMT_LOCAL + ",")
        .concat("\"rate_plan_restriction_cost_amount_local\"," + RATE_PLN_RESTR_COST_AMT_LOCAL + ",")
        .concat("\"single_supplement_cost_amount_local\"," + SNGL_SUPPLMNT_COST_AMT_LOCAL + ",")
        .concat("\"dynamic_rate_rule_cost_amount_local\"," + DYN_RATE_RULE_COST_AMT_LOCAL + ",")
        .concat("\"penalty_cost_amount_local\"," + PENALTY_COST_AMOUNT_LOCAL + ",")
        .concat("\"tax_rate_book_date_cost\"," + TAX_RATE_BOOK_DATE_COST + ",")
        .concat("\"" + EXCHANGE_RATE_STAY_DATE_COST + "\", cast(CASE WHEN exch_rate_stay_date_cost IS NULL THEN 0 ELSE exch_rate_stay_date_cost END as decimal(24,15)),")
        .concat("\"front_end_commission_amount_usd\"," + FRONT_END_COMMISSION_AMOUNT_USD)
        .concat(") as item_amount")

    val itemAmountColumnsVrbo = "named_struct("
        .concat("\"base_price_amount_local\", NULL,")
        .concat("\"other_price_adjustment_amount_local\", NULL,")
        .concat("\"penalty_price_adjustment_amount_local\", NULL,")
        .concat("\"expedia_penalty_price_adjustment_amount_local\", NULL,")
        .concat("\"total_price_adjustment_amount_local\", NULL,")
        .concat("\"service_fee_price_amount_local\", NULL,")
        .concat("\"total_fee_price_amount_local\", NULL,")
        .concat("\"total_tax_price_amount_local\", NULL,")
        .concat("\"service_charge_price_amount_local\", NULL,")
        .concat("\"cancel_change_fee_price_amount_local\", NULL,")
        .concat("\"base_cost_amount_usd\", NULL,")
        .concat("\"other_cost_adjustment_amount_usd\", NULL,")
        .concat("\"supplier_cost_adjustment_amount_usd\", NULL,")
        .concat("\"total_cost_adjustment_amount_usd\", NULL,")
        .concat("\"total_cost_amount_usd\", NULL,")
        .concat("\"total_fee_cost_amount_usd\", NULL,")
        .concat("\"total_tax_cost_amount_usd\", NULL,")
        .concat("\"gross_booking_amount_local\", NULL,")
        .concat("\"other_fee_price_amount_local\", NULL,")
        .concat("\"agent_assisted_purchase_fee_amount_local\", NULL,")
        .concat("\"" + PRICE_CURRENCY_CODE + "\", cast(price_currency_code as string),")
        .concat("\"" + COST_CURRENCY_CODE + "\", cast(cost_currency_code as string),")
        .concat("\"" + GROSS_BOOKING_AMOUNT_USD + "\", NULL,")
        .concat("\"" + EXCHANGE_RATE_BOOK_DATE + "\", NULL,")
        .concat("\"" + EXCHANGE_RATE_STAY_DATE + "\", cast(CASE WHEN exch_rate_stay_date IS NULL THEN 0 ELSE exch_rate_stay_date END as decimal(24,15)),")
        .concat("\"coupon_price_amount_local\", NULL,")
        .concat("\"expedia_goodwill_price_adjustment_amount_local\", NULL,")
        .concat("\"goodwill_price_adjustment_amount_local\",NULL,")
        .concat("\"generic_coupon_price_amount_local\", NULL,")
        .concat("\"refund_price_adjustment_amount_local\", NULL,")
        .concat("\"rebate_price_amount_local\", NULL,")
        .concat("\"tcm_price_adjustment_amount_local\", NULL,")
        .concat("\"cancel_penalty_waiver_price_adjustment_amount_local\", NULL,")
        .concat("\"loyalty_point_price_adjustment_amount_local\", NULL,")
        .concat("\"employee_discount_price_adjustment_amount_local\", NULL,")
        .concat("\"supplier_reconciliation_price_adjustment_amount_local\", NULL,")
        .concat("\"penalty_amount_local\", NULL,")
        .concat("\"tax_rate_book_date\", NULL,")
        .concat("\"purchase_base_price_amount_local\", NULL,")
        .concat("\"total_cost_amount_local\", NULL,")
        .concat("\"base_cost_amount_local\", NULL,")
        .concat("\"total_cost_adjustment_amount_local\", NULL,")
        .concat("\"supplier_cost_adjustment_amount_local\", NULL,")
        .concat("\"eca_cost_adjustment_amount_local\", NULL,")
        .concat("\"other_cost_adjustment_amount_local\", NULL,")
        .concat("\"variable_margin_cost_adjustment_amount_local\", NULL,")
        .concat("\"supplier_reconciliation_cost_adjustment_local\", NULL,")
        .concat("\"total_fee_cost_amount_local\", NULL,")
        .concat("\"service_charge_cost_amount_local\", NULL,")
        .concat("\"other_fee_cost_amount_local\", NULL,")
        .concat("\"eca_fee_cost_amount_local\", NULL,")
        .concat("\"total_tax_cost_amount_local\", NULL,")
        .concat("\"variable_margin_credit_local\", NULL,")
        .concat("\"margin_amount_usd\", NULL,")
        .concat("\"pure_margin_amount_usd\", NULL,")
        .concat("\"extra_person_cost_amount_local\", NULL,")
        .concat("\"rate_plan_restriction_cost_amount_local\", NULL,")
        .concat("\"single_supplement_cost_amount_local\", NULL,")
        .concat("\"dynamic_rate_rule_cost_amount_local\", NULL,")
        .concat("\"penalty_cost_amount_local\", NULL,")
        .concat("\"tax_rate_book_date_cost\", NULL,")
        .concat("\"" + EXCHANGE_RATE_STAY_DATE_COST + "\", NULL,")
        .concat("\"front_end_commission_amount_usd\", NULL")
        .concat(") as item_amount")

    val bookingDetailsColumn = "named_struct("
        .concat("\"legal_entity_name\"," + LGL_ENTITY_NAME + ", ")
        .concat("\"legal_entity_code\"," + LGL_ENTITY_CODE + ", ")
        .concat("\"" + GENERAL_LEDGER_ACCOUNT + "\", '" + NOT_AVAILABLE + "',  ")
        .concat("\"" + GENERAL_LEDGER_LIABILITY_ACCOUNT + "\", '" + NOT_AVAILABLE + "',  ")
        .concat("\"point_of_sale_key\"," + POINT_OF_SALE_KEY + ",  ")
        .concat("\"point_of_sale_brand_name\"," + POINT_OF_SALE_BRAND_NAME + ",  ")
        .concat("\"point_of_sale_name\"," + POINT_OF_SALE_NAME + ",  ")
        .concat("\"management_unit_key\"," + MANAGEMENT_UNIT_KEY + ",  ")
        .concat("\"management_unit_code\"," + MANAGEMENT_UNIT_CODE + ",  ")
        .concat("\"management_unit_name\"," + MANAGEMENT_UNIT_NAME + ",  ")
        .concat("\"management_unit_level_6_name\"," + MANAGEMENT_UNIT_LEVEL_6_NAME + ",  ")
        .concat("\"oracle_gl_product_key\"," + ORACLE_GL_PRODUCT_KEY + ", ")
        .concat("\"travel_service_provider_name\"," + TRAVEL_SERVICE_PROVIDER_NAME + ", ")
        .concat("\"oracle_gl_product_code\", null")
        .concat(") as booking_detail")

    val bookingDetailsColumnVrbo = "named_struct("
        .concat("\"legal_entity_name\"," + LGL_ENTITY_NAME + ", ")
        .concat("\"legal_entity_code\"," + LGL_ENTITY_CODE + ", ")
        .concat("\"" + GENERAL_LEDGER_ACCOUNT + "\", '" + NOT_AVAILABLE + "',  ")
        .concat("\"" + GENERAL_LEDGER_LIABILITY_ACCOUNT + "\", '" + NOT_AVAILABLE + "',  ")
        .concat("\"point_of_sale_key\",NULL, ")
        .concat("\"point_of_sale_brand_name\", NULL,  ")
        .concat("\"point_of_sale_name\", NULL,  ")
        .concat("\"management_unit_key\", NULL,  ")
        .concat("\"management_unit_code\", NULL,  ")
        .concat("\"management_unit_name\", NULL,  ")
        .concat("\"management_unit_level_6_name\", NULL,  ")
        .concat("\"oracle_gl_product_key\", NULL, ")
        .concat("\"travel_service_provider_name\", NULL, ")
        .concat("\"oracle_gl_product_code\", null")
        .concat(") as booking_detail")

    val bookingDetailsColumnFileUpload = "named_struct("
        .concat("\"legal_entity_name\"," + LGL_ENTITY_NAME + ", ")
        .concat("\"legal_entity_code\"," + LGL_ENTITY_CODE + ", ")
        .concat("\"" + GENERAL_LEDGER_ACCOUNT + "\", '" + NOT_AVAILABLE + "',  ")
        .concat("\"" + GENERAL_LEDGER_LIABILITY_ACCOUNT + "\", '" + NOT_AVAILABLE + "',  ")
        .concat("\"point_of_sale_key\"," + POINT_OF_SALE_KEY + ",  ")
        .concat("\"point_of_sale_brand_name\"," + POINT_OF_SALE_BRAND_NAME + ",  ")
        .concat("\"point_of_sale_name\"," + POINT_OF_SALE_NAME + ",  ")
        .concat("\"management_unit_key\"," + MANAGEMENT_UNIT_KEY + ",  ")
        .concat("\"management_unit_code\"," + MANAGEMENT_UNIT_CODE + ",  ")
        .concat("\"management_unit_name\"," + MANAGEMENT_UNIT_NAME + ",  ")
        .concat("\"management_unit_level_6_name\"," + MANAGEMENT_UNIT_LEVEL_6_NAME + ",  ")
        .concat("\"oracle_gl_product_key\"," + ORACLE_GL_PRODUCT_KEY + ", ")
        .concat("\"travel_service_provider_name\"," + TRAVEL_SERVICE_PROVIDER_NAME + ", ")
        .concat("\"oracle_gl_product_code\"," + ORACLE_GL_PRODUCT_CODE)
        .concat(") as booking_detail")

    val eventInfoColumns = "named_struct("
        .concat("\"run_id\"," + RUN_ID + ",")
        .concat("\"published_timestamp\"," + PUBLISHED_TIMESTAMP + ",")
        .concat("\"event_uuid\"," + EVENT_UUID + ",")
        .concat("\"post_to_tax_engine\"," + POST_TO_TAX_ENGINE + ",")
        .concat("\"event_source_system_name\"," + EVENT_SOURCE_SYSTEM_NAME + "," )
        .concat("\"hash_event_uuid\"," + HASH_EVENT_UUID )
        .concat(") as event_info")

    val eventInfoColumnsVrbo = "named_struct("
        .concat("\"run_id\"," + RUN_ID + ",")
        .concat("\"published_timestamp\"," + PUBLISHED_TIMESTAMP + ",")
        .concat("\"event_uuid\"," + EVENT_UUID + ",")
        .concat("\"post_to_tax_engine\"," + POST_TO_TAX_ENGINE + ",")
        .concat("\"event_source_system_name\"," + EVENT_SOURCE_SYSTEM_NAME + ",")
        .concat("\"hash_event_uuid\",NULL")
        .concat(") as event_info")

    val stageBookingEventInfoColumns = "named_struct("
        .concat("\"run_id\"," + RUN_ID + ",")
        .concat("\"published_timestamp\"," + PUBLISHED_TIMESTAMP + ",")
        .concat("\"event_uuid\"," + EVENT_UUID)
        .concat(") as event_info")

    val stageBookingPropertyItemCols = "named_struct("
        .concat("\"" + PROPERTY_ID + "\", property_id")
        .concat(") as property_item")

    val propertyItemColumnsWithStacData = "named_struct("
        .concat("\"" + PROPERTY_ID + "\", property_id,")
        .concat("\"" + PROPERTY_NAME + "\",  property_name,")
        .concat("\"" + PROPERTY_ADDRESS_LINE_1 + "\", NULL,")
        .concat("\"" + PROPERTY_ADDRESS_LINE_2 + "\", NULL,")
        .concat("\"" + PROPERTY_CITY_NAME + "\",  NULL,")
        .concat("\"" + PROPERTY_STATE_PROVINCE_NAME + "\",  NULL,")
        .concat("\"" + PROPERTY_POSTAL_CODE + "\", NULL,")
        .concat("\"" + PROPERTY_LONGITUDE + "\",  NULL,")
        .concat("\"" + PROPERTY_LATITUDE + "\",  NULL,")
        .concat("\"" + PROPERTY_TYPE_NAME + "\", property_type,")
        .concat("\"" + PROPERTY_TOTAL_NUMBER_OF_UNITS + "\", CASE WHEN unit_count RLIKE '^(([0-9]*))$' THEN cast(unit_count as int) ELSE NULL END,")
        .concat("\"" + PROPERTY_COUNTRY_CODE + "\",  NULL,")
        .concat("\"" + TAX_AREA_ID + "\",  NULL, ")
        .concat("\"" + PROPERTY_BRAND_ID + "\",  brand_id,")
        .concat("\"" + PROPERTY_BRAND_NAME + "\", brand_name,")
        .concat("\"" + PROPERTY_PARENT_CHAIN_ID + "\",  parent_chain_id,")
        .concat("\"" + PROPERTY_PARENT_CHAIN_NAME + "\", parent_chain_name")
        .concat(") as property_item")

    val propertyItemColumnsVrbo = "named_struct("
        .concat("\"" + PROPERTY_ID + "\", property_id,")
        .concat("\"" + PROPERTY_NAME + "\",  property_name,")
        .concat("\"" + PROPERTY_ADDRESS_LINE_1 + "\", street_address1,")
        .concat("\"" + PROPERTY_ADDRESS_LINE_2 + "\", street_address2,")
        .concat("\"" + PROPERTY_CITY_NAME + "\",  city_name,")
        .concat("\"" + PROPERTY_STATE_PROVINCE_NAME + "\",  state,")
        .concat("\"" + PROPERTY_POSTAL_CODE + "\", postal_code,")
        .concat("\"" + PROPERTY_LONGITUDE + "\",  longitude,")
        .concat("\"" + PROPERTY_LATITUDE + "\",  latitude,")
        .concat("\"" + PROPERTY_TYPE_NAME + "\", NULL,")
        .concat("\"" + PROPERTY_TOTAL_NUMBER_OF_UNITS + "\", NULL,")
        .concat("\"" + PROPERTY_COUNTRY_CODE + "\",  country_code,")
        .concat("\"" + TAX_AREA_ID + "\",  tax_area_id, ")
        .concat("\"" + PROPERTY_BRAND_ID + "\",  NULL,")
        .concat("\"" + PROPERTY_BRAND_NAME + "\", NULL,")
        .concat("\"" + PROPERTY_PARENT_CHAIN_ID + "\",  NULL,")
        .concat("\"" + PROPERTY_PARENT_CHAIN_NAME + "\", NULL")
        .concat(") as property_item")

    val propertyItemColumnsWithoutStacData = "named_struct("
        .concat("\"" + PROPERTY_ID + "\", property_id,")
        .concat("\"" + PROPERTY_NAME + "\",  property_name,")
        .concat("\"" + PROPERTY_ADDRESS_LINE_1 + "\", NULL,")
        .concat("\"" + PROPERTY_ADDRESS_LINE_2 + "\", NULL,")
        .concat("\"" + PROPERTY_CITY_NAME + "\",  NULL,")
        .concat("\"" + PROPERTY_STATE_PROVINCE_NAME + "\",  NULL,")
        .concat("\"" + PROPERTY_POSTAL_CODE + "\",  NULL,")
        .concat("\"" + PROPERTY_LONGITUDE + "\",  NULL,")
        .concat("\"" + PROPERTY_LATITUDE + "\",  NULL,")
        .concat("\"" + PROPERTY_TYPE_NAME + "\", NULL,")
        .concat("\"" + PROPERTY_TOTAL_NUMBER_OF_UNITS + "\", NULL,")
        .concat("\"" + PROPERTY_COUNTRY_CODE + "\",  NULL,")
        .concat("\"" + TAX_AREA_ID + "\",  NULL, ")
        .concat("\"" + PROPERTY_BRAND_ID + "\",  brand_id,")
        .concat("\"" + PROPERTY_BRAND_NAME + "\", brand_name,")
        .concat("\"" + PROPERTY_PARENT_CHAIN_ID + "\",  parent_chain_id,")
        .concat("\"" + PROPERTY_PARENT_CHAIN_NAME + "\", parent_chain_name")
        .concat(") as property_item")

    val tempPropertyItemColumnsWithStacData = "named_struct("
        .concat("\"" + PROPERTY_ID + "\", PROPERTY_ITEM.PROPERTY_ID,")
        .concat("\"" + PROPERTY_NAME + "\",  PROPERTY_ITEM.PROPERTY_NAME,")
        .concat("\"" + PROPERTY_ADDRESS_LINE_1 + "\", PROPERTY_ITEM.PROPERTY_ADDRESS_LINE_1,")
        .concat("\"" + PROPERTY_ADDRESS_LINE_2 + "\", PROPERTY_ITEM.PROPERTY_ADDRESS_LINE_2,")
        .concat("\"" + "PROPERTY_CITY_NAME" + "\",  PROPERTY_ITEM.CITY_NAME,")
        .concat("\"" + "PROPERTY_STATE_PROVINCE_NAME" + "\",  PROPERTY_ITEM.STATE_PROVINCE_NAME,")
        .concat("\"" + "PROPERTY_POSTAL_CODE" + "\",  PROPERTY_ITEM.POSTAL_CODE,")
        .concat("\"" + "PROPERTY_LONGITUDE" + "\",  PROPERTY_ITEM.LONGITUDE,")
        .concat("\"" + "PROPERTY_LATITUDE" + "\",  PROPERTY_ITEM.LATITUDE,")
        .concat("\"" + "PROPERTY_TYPE_NAME" + "\", PROPERTY_ITEM.structure_type_name,")
        .concat("\"" + "PROPERTY_TOTAL_NUMBER_OF_UNITS" + "\", PROPERTY_ITEM.PROPERTY_TOTAL_NUMBER_OF_UNITS,")
        .concat("\"" + "PROPERTY_COUNTRY_CODE" + "\", PROPERTY_ITEM.COUNTRY_CODE,")
        .concat("\"" + "TAX_AREA_ID" + "\",  PROPERTY_ITEM.TAX_AREA_ID, ")
        .concat("\"" + "PROPERTY_BRAND_ID" + "\",  PROPERTY_ITEM.BRAND_ID,")
        .concat("\"" + "PROPERTY_BRAND_NAME" + "\", PROPERTY_ITEM.BRAND_NAME,")
        .concat("\"" + "PROPERTY_PARENT_CHAIN_ID" + "\",  PROPERTY_ITEM.PARENT_CHAIN_ID,")
        .concat("\"" + "PROPERTY_PARENT_CHAIN_NAME" + "\", PROPERTY_ITEM.PARENT_CHAIN_NAME")
        .concat(") as property_item")

    val tempPropertyItemColumnsWithoutStacData = "named_struct("
        .concat("\"" + PROPERTY_ID + "\", PROPERTY_ITEM.PROPERTY_ID,")
        .concat("\"" + PROPERTY_NAME + "\",  PROPERTY_ITEM.PROPERTY_NAME,")
        .concat("\"" + PROPERTY_ADDRESS_LINE_1 + "\", PROPERTY_ITEM.PROPERTY_ADDRESS_LINE_1,")
        .concat("\"" + PROPERTY_ADDRESS_LINE_2 + "\", PROPERTY_ITEM.PROPERTY_ADDRESS_LINE_2,")
        .concat("\"" + "PROPERTY_CITY_NAME" + "\",  PROPERTY_ITEM.CITY_NAME,")
        .concat("\"" + "PROPERTY_STATE_PROVINCE_NAME" + "\",  PROPERTY_ITEM.STATE_PROVINCE_NAME,")
        .concat("\"" + "PROPERTY_POSTAL_CODE" + "\",  PROPERTY_ITEM.POSTAL_CODE,")
        .concat("\"" + "PROPERTY_LONGITUDE" + "\",  PROPERTY_ITEM.LONGITUDE,")
        .concat("\"" + "PROPERTY_LATITUDE" + "\",  PROPERTY_ITEM.LATITUDE,")
        .concat("\"" + "PROPERTY_TYPE_NAME" + "\", NULL,")
        .concat("\"" + "PROPERTY_TOTAL_NUMBER_OF_UNITS" + "\", NULL,")
        .concat("\"" + "PROPERTY_COUNTRY_CODE" + "\", PROPERTY_ITEM.COUNTRY_CODE,")
        .concat("\"" + "TAX_AREA_ID" + "\",  PROPERTY_ITEM.TAX_AREA_ID, ")
        .concat("\"" + "PROPERTY_BRAND_ID" + "\",  PROPERTY_ITEM.BRAND_ID,")
        .concat("\"" + "PROPERTY_BRAND_NAME" + "\", PROPERTY_ITEM.BRAND_NAME,")
        .concat("\"" + "PROPERTY_PARENT_CHAIN_ID" + "\",  PROPERTY_ITEM.PARENT_CHAIN_ID,")
        .concat("\"" + "PROPERTY_PARENT_CHAIN_NAME" + "\", PROPERTY_ITEM.PARENT_CHAIN_NAME")
        .concat(") as property_item")

    val carItemColumns = "named_struct("
        .concat("\"car_vendor_name\"," + CAR_VENDOR_NAME + ", ")
        .concat("\"car_pick_up_location_street_address1\", NULL,")
        .concat("\"car_pick_up_location_street_address2\", NULL,")
        .concat("\"car_pick_up_location_postal_code\", NULL,")
        .concat("\"car_pick_up_location_name\"," + CAR_PICK_UP_LOCATION_NAME + ", ")
        .concat("\"car_pick_up_location_city_name\", NULL,")
        .concat("\"car_pick_up_location_state_province_name\", NULL,")
        .concat("\"car_pick_up_location_country_code\", NULL,")
        .concat("\"car_drop_off_location_name\"," + CAR_DROP_OFF_LOCATION_NAME + ",  ")
        .concat("\"car_drop_off_location_city_name\"," + CAR_DROP_OFF_LOCATION_CITY_NAME + ",  ")
        .concat("\"car_drop_off_location_state_province_name\"," + CAR_DROP_OFF_LOCATION_STATE_PROVINCE_NAME + ",  ")
        .concat("\"car_drop_off_location_country_code\"," + CAR_DROP_OFF_LOCATION_COUNTRY_CODE + ",  ")
        .concat("\"car_tax_area_id\", NULL,")
        .concat("\"car_location_id\"," + CAR_LOCATION_ID + ",  ")
        .concat("\"rental_day_count\"," + RENTAL_DAY_COUNT + ",  ")
        .concat("\"total_rental_day_count\"," + TOTAL_RENTAL_DAY_COUNT + ",  ")
        .concat("\"car_rate_indicator\"," + CAR_RATE_INDICATOR)
        .concat(") as car_item")

    val END_LIABILITY_DATE = "end_liability_date"

    val partnerItemLodgingColumnsWithoutStacData = "named_struct("
        .concat("\"" + PARTNER_ID + "\", property_id,")
        .concat("\"" + PARTNER_NAME + "\",  property_name,")
        .concat("\"" + PARTNER_ADDRESS + "\", named_struct(")
        .concat("\"" + PARTNER_ADDRESS_LINE_1 + "\", street_address1,")
        .concat("\"" + PARTNER_ADDRESS_LINE_2 + "\", street_address2,")
        .concat("\"" + PARTNER_CITY + "\",  city_name,")
        .concat("\"" + PARTNER_STATE + "\",  state,")
        .concat("\"" + PARTNER_POSTAL_CODE + "\",  postal_code,")
        .concat("\"" + PARTNER_COUNTRY_CODE + "\",  country_code,")
        .concat("\"" + PARTNER_DISTRICT + "\", \"\",")
        .concat("\"" + PARTNER_COUNTY + "\", \"\",")
        .concat("\"" + PARTNER_ADDRESS_TYPE + "\", \"Property\",")
        .concat("\"" + PARTNER_LATITUDE + "\", latitude,")
        .concat("\"" + PARTNER_LONGITUDE + "\", longitude")
        .concat("),")
        .concat("\"" + PARTNER_ATTRIBUTES + "\", map(")
        .concat("\"" + PROPERTY_LONGITUDE + "\", longitude,")
        .concat("\"" + PROPERTY_LATITUDE + "\", latitude,")
        .concat("\"" + PROPERTY_TYPE_NAME + "\", structure_type_name,")
        .concat("\"" + TAX_AREA_ID + "\", tax_area_id,")
        .concat("\"" + PROPERTY_BRAND_ID + "\", brand_id,")
        .concat("\"" + PROPERTY_BRAND_NAME + "\", brand_name,")
        .concat("\"" + PROPERTY_PARENT_CHAIN_ID + "\", parent_chain_id,")
        .concat("\"" + PROPERTY_PARENT_CHAIN_NAME + "\", parent_chain_name ")
        .concat(")")
        .concat(") as partner_item")

    val partnerItemStageBookingCols = "named_struct("
        .concat("\"" + PARTNER_ID + "\", property_id,")
        .concat("\"" + PARTNER_NAME + "\",  \"\",")
        .concat("\"" + PARTNER_ADDRESS + "\", named_struct(")
        .concat("\"" + PARTNER_ADDRESS_LINE_1 + "\",  address,")
        .concat("\"" + PARTNER_ADDRESS_LINE_2 + "\",  \"\",")
        .concat("\"" + PARTNER_CITY + "\",  staging_city,")
        .concat("\"" + PARTNER_STATE + "\",  state_province,")
        .concat("\"" + PARTNER_POSTAL_CODE + "\",  staging_postal_code,")
        .concat("\"" + PARTNER_COUNTRY_CODE + "\",  staging_country_code,")
        .concat("\"" + PARTNER_DISTRICT + "\", \"\",")
        .concat("\"" + PARTNER_COUNTY + "\", \"\",")
        .concat("\"" + PARTNER_ADDRESS_TYPE + "\",  \"\",")
        .concat("\"" + PARTNER_LATITUDE + "\", staging_latitude,")
        .concat("\"" + PARTNER_LONGITUDE + "\", staging_longitude")
        .concat("),")
        .concat("\"" + PARTNER_ATTRIBUTES + "\", map(")
        .concat("\"" + LISTING_NUMBER + "\", listing_number")
        .concat(")")
        .concat(") as partner_item")

    val partnerItemLodgingColumnsWithStacData = "named_struct("
        .concat("\"" + PARTNER_ID + "\", property_id,")
        .concat("\"" + PARTNER_NAME + "\",  property_name,")
        .concat("\"" + PARTNER_ADDRESS + "\", named_struct(")
        .concat("\"" + PARTNER_ADDRESS_LINE_1 + "\", street_address1,")
        .concat("\"" + PARTNER_ADDRESS_LINE_2 + "\", street_address2,")
        .concat("\"" + PARTNER_CITY + "\",  city_name,")
        .concat("\"" + PARTNER_STATE + "\", state,")
        .concat("\"" + PARTNER_POSTAL_CODE + "\", postal_code,")
        .concat("\"" + PARTNER_COUNTRY_CODE + "\",  country_code,")
        .concat("\"" + PARTNER_DISTRICT + "\", \"\",")
        .concat("\"" + PARTNER_COUNTY + "\", \"\",")
        .concat("\"" + PARTNER_ADDRESS_TYPE + "\", \"Property\",")
        .concat("\"" + PARTNER_LATITUDE + "\", latitude,")
        .concat("\"" + PARTNER_LONGITUDE + "\", longitude")
        .concat("),")
        .concat("\"" + PARTNER_ATTRIBUTES + "\", map(")
        .concat("\"" + PROPERTY_LONGITUDE + "\", longitude,")
        .concat("\"" + PROPERTY_LATITUDE + "\", latitude,")
        .concat("\"" + PROPERTY_TYPE_NAME + "\", structure_type_name,")
        .concat("\"" + TAX_AREA_ID + "\", tax_area_id,")
        .concat("\"" + PROPERTY_BRAND_ID + "\", brand_id,")
        .concat("\"" + PROPERTY_BRAND_NAME + "\", brand_name,")
        .concat("\"" + PROPERTY_PARENT_CHAIN_ID + "\", parent_chain_id,")
        .concat("\"" + PROPERTY_PARENT_CHAIN_NAME + "\", parent_chain_name ")
        .concat(" stac_replacement_fields ")
        .concat(")")
        .concat(") as partner_item")

    val partnerItemLodgingColumnsVrbo = "named_struct("
        .concat("\"" + PARTNER_ID + "\", property_id,")
        .concat("\"" + PARTNER_NAME + "\",  property_name,")
        .concat("\"" + PARTNER_ADDRESS + "\", named_struct(")
        .concat("\"" + PARTNER_ADDRESS_LINE_1 + "\", street_address1,")
        .concat("\"" + PARTNER_ADDRESS_LINE_2 + "\", street_address2,")
        .concat("\"" + PARTNER_CITY + "\",  city_name,")
        .concat("\"" + PARTNER_STATE + "\", state,")
        .concat("\"" + PARTNER_POSTAL_CODE + "\", postal_code,")
        .concat("\"" + PARTNER_COUNTRY_CODE + "\",  country_code,")
        .concat("\"" + PARTNER_DISTRICT + "\", \"\",")
        .concat("\"" + PARTNER_COUNTY + "\", \"\",")
        .concat("\"" + PARTNER_ADDRESS_TYPE + "\", \"Property\",")
        .concat("\"" + PARTNER_LATITUDE + "\", latitude,")
        .concat("\"" + PARTNER_LONGITUDE + "\", longitude")
        .concat("),")
        .concat("\"" + PARTNER_ATTRIBUTES + "\", partner_attributes")
        .concat(") as partner_item")

    val jurisdictionConfig = "named_struct("
        .concat("\"" + "country" + "\",cfg_country_code, ")
        .concat("\"" + "state" + "\",cfg_state, ")
        .concat("\"" + "city" + "\",cfg_city, ")
        .concat("\"" + "district" + "\",cfg_district, ")
        .concat("\"" + "county" + "\",cfg_county, ")
        .concat("\"" + "business_model_type" + "\",cfg_" + BUSINESS_MODEL_NAME + ", ")
        .concat("\"" + "business_model_subtype" + "\",cfg_" + BUSINESS_MODEL_SUBTYPE_NAME + ", ")
        .concat("\"" + "legal_entity" + "\",cfg_" + LEGAL_ENTITY_NAME + ", ")
        .concat("\"" + "tenant" + "\",cfg_tenant ")
        .concat(") as jurisdiction_config")

    val supplierDim = "named_struct("
        .concat("\"" + "supplier_id" + "\",product_catalog_supplier_id, ")
        .concat("\"" + "country" + "\",country_code, ")
        .concat("\"" + "state" + "\",state, ")
        .concat("\"" + "city" + "\",city_name, ")
        .concat("\"" + "district" + "\",\"\", ")
        .concat("\"" + "county" + "\",\"\", ")
        .concat("\"" + "postal_code" + "\",postal_code, ")
        .concat("\"" + "product_line_name" + "\",product_line_name, ")
        .concat("\"" + "supplier_attributes" + "\",map(")
        .concat("\"" + PROPERTY_LONGITUDE + "\",longitude, ")
        .concat("\"" + PROPERTY_LATITUDE + "\",latitude, ")
        .concat("\"" + PARTNER_ADDRESS_LINE_1 + "\",street_address1, ")
        .concat("\"" + PARTNER_ADDRESS_LINE_2 + "\",street_address2, ")
        .concat("\"" + TAX_AREA_ID + "\",tax_area_id")
        .concat(")")
        .concat(") as supplier_dim")

    val legalEntityDim = "named_struct("
        .concat("\"" + "legal_entity_code" + "\", \"\"")
        .concat(") as legal_entity_dim")

    val eventInfoColumnsUnitedTaxProfile = "named_struct("
        .concat("\"run_id\"," + RUN_ID + ",")
        .concat("\"published_timestamp\"," + PUBLISHED_TIMESTAMP + ",")
        .concat("\"event_uuid\"," + EVENT_UUID + "")
        .concat(") as event_info")


    val partnerItemCarColumns = "named_struct("
        .concat("\"" + PARTNER_ID + "\"," + CAR_LOCATION_ID  + ", ")
        .concat("\"" + PARTNER_NAME + "\"," + CAR_VENDOR_NAME + ", ")
        .concat("\"" + PARTNER_ADDRESS + "\", named_struct(")
        .concat("\"" + PARTNER_ADDRESS_LINE_1 + "\"," + CAR_PICK_UP_LOCATION_STREET_ADDRESS1 + ", ")
        .concat("\"" + PARTNER_ADDRESS_LINE_2 + "\"," + CAR_PICK_UP_LOCATION_STREET_ADDRESS2 + ", ")
        .concat("\"" + PARTNER_CITY + "\"," + CAR_PICK_UP_LOCATION_CITY_NAME + ", ")
        .concat("\"" + PARTNER_STATE + "\"," + CAR_PICK_UP_LOCATION_STATE_PROVINCE_NAME + ", ")
        .concat("\"" + PARTNER_POSTAL_CODE + "\"," + CAR_PICK_UP_LOCATION_POSTAL_CODE + ", ")
        .concat("\"" + PARTNER_COUNTRY_CODE + "\"," + CAR_PICK_UP_LOCATION_COUNTRY_CODE + ", ")
        .concat("\"" + PARTNER_DISTRICT + "\", \"\",")
        .concat("\"" + PARTNER_COUNTY + "\", \"\",")
        .concat("\"" + PARTNER_ADDRESS_TYPE + "\", \"\",")
        .concat("\"" + PARTNER_LATITUDE + "\"," + CAR_PICK_UP_LOCATION_LATITUDE +  ", ")
        .concat("\"" + PARTNER_LONGITUDE + "\"," + CAR_PICK_UP_LOCATION_LONGITUDE)
        .concat("),")
        .concat("\"" + PARTNER_ATTRIBUTES + "\", map(")
        .concat("\"" + TAX_AREA_ID + "\"," + CAR_TAX_AREA_ID)
        .concat(")")
        .concat(") as partner_item")

    val partnerItemLxColumns = "named_struct("
        .concat("\"" + PARTNER_ID + "\"," + ACTIVITY_ID + ",")
        .concat("\"" + PARTNER_NAME + "\"," + OFFERING_VENDOR_NAME + ",")
        .concat("\"" + PARTNER_ADDRESS + "\", named_struct(")
        .concat("\"" + PARTNER_ADDRESS_LINE_1 + "\"," + PARTNER_ADDRESS_LINE_1 + ",")
        .concat("\"" + PARTNER_ADDRESS_LINE_2 + "\"," + PARTNER_ADDRESS_LINE_2 + ",")
        .concat("\"" + PARTNER_CITY + "\"," + PARTNER_CITY + ",")
        .concat("\"" + PARTNER_STATE + "\"," + PARTNER_STATE + ",")
        .concat("\"" + PARTNER_POSTAL_CODE + "\"," + PARTNER_POSTAL_CODE + ",")
        .concat("\"" + PARTNER_COUNTRY_CODE + "\"," + PARTNER_COUNTRY_CODE + ",")
        .concat("\"" + PARTNER_DISTRICT + "\", \"\",")
        .concat("\"" + PARTNER_COUNTY + "\",CASE WHEN " + PC_CLEANSED_COUNTY + " IS NULL THEN " + PC_COUNTY + " ELSE " + PC_CLEANSED_COUNTY + " END, ")
        .concat("\"" + PARTNER_ADDRESS_TYPE + "\", \"Destination Services\", ")
        .concat("\"" + PARTNER_LATITUDE + "\"," + PARTNER_LATITUDE + ",")
        .concat("\"" + PARTNER_LONGITUDE + "\"," + PARTNER_LONGITUDE )
        .concat("),")
        .concat("\"" + PARTNER_ATTRIBUTES + "\", map(")
        .concat("\"" + INTERNAL_CATEGORY_NAME + "\"," + INTERNAL_CATEGORY_NAME + ",")
        .concat("\"" + OFFERING_VENDOR_BRANCH_STATE_PROVINCE_NAME + "\"," + OFFERING_VENDOR_BRANCH_STATE_PROVINCE_NAME + ",")
        .concat("\"" + OFFERING_VENDOR_BRANCH_NAME + "\"," + OFFERING_VENDOR_BRANCH_NAME + ",")
        .concat("\"" + OFFERING_VENDOR_BRANCH_COUNTRY_NAME + "\"," + OFFERING_VENDOR_BRANCH_COUNTRY_NAME + ",")
        .concat("\"" + OFFERING_NAME + "\"," + OFFERING_NAME + ",")
        .concat("\"" + OFFERING_ITEM_NAME + "\"," + OFFERING_ITEM_NAME + ",")
        .concat("\"" + OFFERING_CATEGORY_NAME + "\"," + OFFERING_CATEGORY_NAME + ",")
        .concat("\"" + VERTEX_COUNTY + "\",CASE WHEN " + PC_CLEANSED_COUNTY + " IS NULL THEN " + PC_COUNTY + " ELSE " + PC_CLEANSED_COUNTY + " END, ")
        .concat("\"" + VERTEX_CITY  + "\"," + PARTNER_CITY + ",")
        .concat("\"" + ACTIVITY_REDEMPTION_LATITUDE + "\"," + PARTNER_LATITUDE + ",")
        .concat("\"" + ACTIVITY_REDEMPTION_LONGITUDE + "\"," + PARTNER_LONGITUDE + ",")
        .concat("\"" + TAX_AREA_ID + "\"," + TAX_AREA_ID + ",")
        .concat("\"" + TICKET_COUNT + "\", " + TICKET_COUNT + " ")
        .concat(")")
        .concat(") as partner_item")

    val partnerItemAdvertisingColumns = "named_struct("
        .concat("\"" + PARTNER_ID + "\", \"\", ")
        .concat("\"" + PARTNER_NAME + "\"," + PARTNER_NAME + ", ")
        .concat("\"" + PARTNER_ADDRESS + "\", named_struct(")
        .concat("\"" + PARTNER_ADDRESS_LINE_1 + "\"," + PARTNER_ADDRESS_LINE_1 + ", ")
        .concat("\"" + PARTNER_ADDRESS_LINE_2 + "\"," + PARTNER_ADDRESS_LINE_2 + ", ")
        .concat("\"" + PARTNER_CITY + "\"," + PARTNER_CITY + ", ")
        .concat("\"" + PARTNER_STATE + "\"," + PARTNER_STATE + ", ")
        .concat("\"" + PARTNER_POSTAL_CODE + "\"," + PARTNER_POSTAL_CODE + ", ")
        .concat("\"" + PARTNER_COUNTRY_CODE + "\"," + PARTNER_COUNTRY_CODE + ", ")
        .concat("\"" + PARTNER_DISTRICT + "\", \"\",")
        .concat("\"" + PARTNER_COUNTY + "\", \"\",")
        .concat("\"" + PARTNER_ADDRESS_TYPE + "\", \"\",")
        .concat("\"" + PARTNER_LATITUDE + "\", \"\",")
        .concat("\"" + PARTNER_LONGITUDE + "\", \"\"")
        .concat("),")
        .concat("\"" + PARTNER_ATTRIBUTES + "\", map()")
        .concat(") as partner_item")

    val nonTravelItemColumns = "named_struct("
        .concat("\"" + INVOICE_DATE + "\",  cast(invoice_date as string), ")
        .concat("\"" + INVOICE_NUMBER + "\", cast(invoice_number as string), ")
        .concat("\"" + INVOICE_LINE_NUMBER + "\", cast(invoice_line_number as string), ")
        .concat("\"" + INVOICE_TYPE + "\", cast(invoice_type as string), ")
        .concat("\"" + PRODUCT_TYPE + "\", product_type, ")
        .concat("\"" + INVOICE_LEGAL_ENTITY_CODE + "\", legal_entity_code, ")
        .concat("\"" + INVOICE_LEGAL_ENTITY_NAME + "\", legal_entity_name, ")
        .concat("\"" + ADDITIONAL_ATTRIBUTES + "\", map(")
        .concat("\"" + TRAVEL_SERVICE_PROVIDER_NAME + "\"," + TRAVEL_SERVICE_PROVIDER_NAME + ", ")
        .concat("\"" + MANAGEMENT_UNIT_CODE + "\"," + MANAGEMENT_UNIT_CODE + ", ")
        .concat("\"" + ORACLE_GL_PRODUCT_CODE + "\"," + ORACLE_GL_PRODUCT_CODE + " ")
        .concat(")")
        .concat(") as non_travel_item")

    val DUMMY_BOOKING_TRANSACTION_QUERY =
        s"""
           |   SELECT
           |        dm.booking_history as bk_dummy,
           |        dm.product_line_name as pl_dummy
           |   FROM commerce.tax_compliance_eg_booking_transactions as dm
           |   where dm.transaction_liability_date = '2999-01-01'
           |   and dm.transaction_liability_date_type = 'non-existing'
           |   and dm.product_line_name = 'non-existing'
           |""".stripMargin
}
