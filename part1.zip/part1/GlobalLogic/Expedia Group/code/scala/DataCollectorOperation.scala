package com.expediagroup.platform.taxcompliance

import com.expediagroup.finance.tax.amounts.v1.RuleType
import com.expediagroup.platform.taxcompliance.car_address.CarAddressServiceHelper
import com.expediagroup.platform.taxcompliance.cases.{PreProcessorConfigCase, TableSchemaConfigCase}
import com.expediagroup.platform.taxcompliance.config.{AmountConverter, BookingHistoryCase, ConfigRuleFilter, ConfigurationRunner, TaxBaseModeler}
import com.expediagroup.platform.taxcompliance.constants.AppConstants._
import com.expediagroup.platform.taxcompliance.constants.{AppConstants, LoggingConstant}
import com.expediagroup.platform.taxcompliance.monitor.ApplicationMonitor
import com.expediagroup.platform.taxcompliance.monitor.DataDogMetricNames._
import com.expediagroup.platform.taxcompliance.sql.{SQLBuilder, SQLColumnHelper}
import com.expediagroup.platform.taxcompliance.util.DataUtil
import com.expediagroup.platform.taxcompliance.util.DataUtil.deriveUpdatedPriceCurrencyCodeForHistoryUdf
import com.expediagroup.platform.taxcompliance.validation.DataValidator
import com.expediagroup.platform.taxcompliance.validation.digitalservice.DigitalServiceDataValidator
import org.apache.spark.broadcast.Broadcast
import org.apache.spark.sql.catalyst.expressions.GenericRowWithSchema
import org.apache.spark.sql.functions._
import org.apache.spark.sql.types.DecimalType
import org.apache.spark.sql.{DataFrame, Row, SparkSession}
import org.apache.spark.storage.StorageLevel
import org.slf4j.{LoggerFactory, MDC}
import org.springframework.beans.factory.annotation.{Autowired, Value}
import org.springframework.stereotype.Component

import java.sql.Timestamp
import java.util.Calendar
import java.util.concurrent.TimeUnit
import scala.collection.JavaConversions.asScalaBuffer
import scala.collection.mutable.Map
import scala.sys.process._

@Component("com.expediagroup.platform.taxcompliance.DataCollectorOperation")
class DataCollectorOperation extends Serializable {

    private val logger = LoggerFactory.getLogger(this.getClass)

    @Autowired
    val applicationMonitor: ApplicationMonitor = null

    @Autowired
    val dataValidator: DataValidator = null

    @Autowired
    val digitalServiceDataValidator: DigitalServiceDataValidator = null

    @Autowired
    val configurationRunner: ConfigurationRunner = null

    @Autowired
    val carAddressService: CarAddressServiceHelper = null

    @Value("${configurationService.useCurrencyConversionFeature}")
    var useCurrencyConversionFeature: Boolean = false

    @Value("${configurationService.useConfigRuleCacheFeature}")
    var useConfigRuleCacheFeature: Boolean = false

    @Value("${carAddressService.enabled}")
    var useCarAddressServiceFeature: Boolean = false

    @Value("${com.expediagroup.platform.taxcompliance.federated.daily.exchange.rate.table}")
    val federatedDailyExchangeRate: String = null

    @Value("${com.expediagroup.platform.taxcompliance.supply.eg.lodging.profile.table}")
    val lodgingProfileEg: String = null

    @Value("${com.expediagroup.platform.taxcompliance.staged.booking.transactions.table}")
    var stagedBookingTransactions: String = null

    @Value("${com.expediagroup.platform.taxcompliance.manual.transactions.table}")
    var manualTransactions: String = null

    @Value("${com.expediagroup.platform.taxcompliance.supply.product.catalog.table}")
    var productCatalogTransactions: String = null

    @Value("${com.expediagroup.platform.taxcompliance.vrbo.room.profile.table}")
    val vrboRoomProfileTable: String = null

    @Value("${com.expediagroup.platform.taxcompliance.staged.enriched.transactions.table}")
    val stagedEnrichedTransactions: String = null

    @Value("${com.expediagroup.platform.taxcompliance.staged.enriched.exception.transactions.table}")
    val stagedExceptionTransactions: String = null

    @Value("${com.expediagroup.platform.taxcompliance.staged.enriched.transactions.temp.table}")
    val stagedEnrichedTransactionsTemp: String = null

    @Value("${com.expediagroup.platform.taxcompliance.staged.enriched.exception.transactions.temp.table}")
    val stagedExceptionTransactionsTemp: String = null

    @Value("${com.expediagroup.platform.taxcompliance.job.info.table}")
    val jobInfoTable: String = null

    @Value("${com.expediagroup.platform.taxcompliance.property.detail.table}")
    val propertyDetailTable: String = null

    @Value("${com.expediagroup.platform.taxcompliance.federated.lodg.property.dim.table}")
    val federatedLodgPropertyDim: String = null

    @Value("${com.expediagroup.platform.taxcompliance.federated.trans.typ.dim.table}")
    val federatedTransTypDim: String = null

    @Value("${com.expediagroup.platform.taxcompliance.federated.product.ln.dim.table}")
    val federatedProductLnDim: String = null

    @Value("${com.expediagroup.platform.taxcompliance.federated.currn.dim.table}")
    val federatedCurrnDim: String = null

    @Value("${com.expediagroup.platform.taxcompliance.federated.lgl.entity.dim.table}")
    val federatedLglEntityDim: String = null

    @Value("${com.expediagroup.platform.taxcompliance.federated.pos.entity.dim.table}")
    val federatedPosDim: String = null

    @Value("${com.expediagroup.platform.taxcompliance.federated.mgmt.entity.dim.table}")
    val federatedMgmtUnitDim: String = null

    @Value("${com.expediagroup.platform.taxcompliance.tax.attribute.bussines.table}")
    val stacTable: String = null

    @Value("${com.expediagroup.platform.taxcompliance.hotwire.dwadmin.car.purchase.table}")
    val carPurchase: String = null

    @Value("${com.expediagroup.platform.taxcompliance.hotwire.dwadmin.car.location.table}")
    val carLocation: String = null

    @Value("${com.expediagroup.platform.taxcompliance.united.tax.profile.table}")
    val unitedTaxProfile: String = null

    @Value("${stacConfiguration.useStacAttributesFeature}")
    var useStacAttributesFeature: Boolean = false

    @Value("${taxRateBookDate.zero.legalEntities}")
    val legalEntitiesWithTaxRateBookDateSetToZero: String = null

    @Value("${hotwireCars.enabled}")
    var hotwireCarsEnabled: Boolean = false

    var queryFilterCondition: String = null

    @Autowired
    var sqlBuilder: SQLBuilder = null

    @Autowired
    var configRuleFilter: ConfigRuleFilter = null

    var tableSchemaConfig: Broadcast[TableSchemaConfigCase] = null
    var preProcessorConfig: Broadcast[PreProcessorConfigCase] = null

    def loadEnrichedTransactions(sqlc: SparkSession, startDate: String, endDate: String, runId: String, jobName: String,
                                 criteriaList: String, productLineName: String): Unit = {
        val start = System.currentTimeMillis
        logger.info("Start Processing:  Start date: " + startDate + " End date: " + endDate + " Run Id: " + runId +
            " Job Name: " + jobName + " Product Line Name: " + productLineName)

        //fetch transactions
        var fetchedDataFrames = fetchTransactions(sqlc, startDate, endDate, runId, criteriaList, jobName, productLineName)
        if (productLineName.equalsIgnoreCase(PRODUCT_LINE_NAME_LODGING) || PRODUCT_LINE_NAME_VRBO.equalsIgnoreCase(productLineName)) {
            val start = System.currentTimeMillis()
            logger.info("start time lodging address: " + start)
            fetchedDataFrames("JOINED_DATAFRAME") = transformLodgingAddress(sqlc, fetchedDataFrames("JOINED_DATAFRAME"), productLineName)
            logger.info("end time lodging address: " + (System.currentTimeMillis() - start))
            logger.info("Updated schema for lodging transactions" + fetchedDataFrames("JOINED_DATAFRAME").schema)
            if (useStacAttributesFeature && productLineName.equalsIgnoreCase(PRODUCT_LINE_NAME_LODGING)) {
                val stacDataFrame: DataFrame = getStacData(sqlc, productLineName)

                fetchedDataFrames("JOINED_DATAFRAME") = fetchedDataFrames("JOINED_DATAFRAME").join(
                    stacDataFrame
                    , col("property_id") === col("stac.supplier_id")
                        && col("non_cleansed_country_code") === col("stc_country_code")
                        && col("t.product_line_name") === col("stac.line_of_business")
                        && (col("lodg_rm_typ_id").cast("string") === col("stac.sub_supplier_id")
                        || col("stac.sub_supplier_id").isNull)
                    , "left"
                )
            }
        }

        if (productLineName.equalsIgnoreCase(PRODUCT_LINE_NAME_LX)) {
            val start = System.currentTimeMillis()
            logger.info("start time LX address: " + start)
            fetchedDataFrames("JOINED_DATAFRAME") = transformLXAddress(sqlc, fetchedDataFrames("JOINED_DATAFRAME"))
            logger.info("end time LX address: " + (System.currentTimeMillis() - start))
            logger.info("Updated schema for LX transactions" + fetchedDataFrames("JOINED_DATAFRAME").schema)
        }
        fetchedDataFrames("JOINED_DATAFRAME") = getCriteriaFilteredDF(fetchedDataFrames("JOINED_DATAFRAME"))
        if (useCurrencyConversionFeature) {
            //load configuration from configuration service
            configurationRunner.loadGTPTaxConfiguration(startDate, endDate)

            //fetch query filter condition
            val qualifiedTransactionDf = filterQualifiedTransactions(fetchedDataFrames("JOINED_DATAFRAME"))
            if (PRODUCT_LINE_NAME_VRBO.equalsIgnoreCase(productLineName)) {
                qualifiedTransactionDf.withColumn(SQLColumnHelper.PRODUCT_LINE_NAME, lit(SQLColumnHelper.VRBO_PRODUCT_LINE_NAME))
            }
            if(productLineName.equalsIgnoreCase(PRODUCT_LINE_NAME_ADVERTISING) ||
                productLineName.equalsIgnoreCase(PRODUCT_LINE_NAME_INVOICE_SERVICES)) {
                if (qualifiedTransactionDf.count() == 0) {
                    throw new Exception("No Qualified Transaction")
                }
            }

            val transWithPartnerAttributesDF = if (productLineName.equalsIgnoreCase(PRODUCT_LINE_NAME_VRBO)) {
                val transWithTaxProfileDF = addTaxProfileAttributes(sqlc, qualifiedTransactionDf)
                addPartnerAttributes(transWithTaxProfileDF)
            } else {
                qualifiedTransactionDf
            }

            //convert local amounts
            val convertedAmountsDf = convertLocalAmountsToFilingAmounts(transWithPartnerAttributesDF, sqlc, productLineName)

            val transformedConvertedAmountsDf = transformBkgTransDF(convertedAmountsDf, runId)

            //apply base modeler rules
            val baseModelerDf = applyBaseModelerRules(transformedConvertedAmountsDf, sqlc)

            //build converted amount struct
            var transformedBkgTransDfWithConvAmounts: DataFrame = null
            if (!PRODUCT_LINE_NAME_VRBO.equalsIgnoreCase(productLineName)) {
                transformedBkgTransDfWithConvAmounts = AmountConverter.buildConvertedAmountsStruct(baseModelerDf, sqlc)
            } else {
                transformedBkgTransDfWithConvAmounts = baseModelerDf
            }

            fetchedDataFrames("JOINED_DATAFRAME") = transformedBkgTransDfWithConvAmounts
        }

        val allColumnsExceptMap = fetchedDataFrames("JOINED_DATAFRAME").columns.filter(_ != SQLColumnHelper.PARTNER_ATTRIBUTES)
        fetchedDataFrames("JOINED_DATAFRAME") = fetchedDataFrames("JOINED_DATAFRAME").dropDuplicates(allColumnsExceptMap)
        fetchedDataFrames("JOINED_DATAFRAME") = fetchedDataFrames("JOINED_DATAFRAME").withColumn(SQLColumnHelper.CAR_LOCATION_ID, lit(null).cast("string"))

        if (useCarAddressServiceFeature && productLineName.equalsIgnoreCase(PRODUCT_LINE_NAME_CAR)) {
            val start = System.currentTimeMillis()
            logger.info("start time car address: " + start)
            fetchedDataFrames("JOINED_DATAFRAME") = transformCarAddress(sqlc, fetchedDataFrames("JOINED_DATAFRAME"), productLineName)
            logger.info("end time car address: " + (System.currentTimeMillis() - start))
            logger.info("Updated schema for car transactions" + fetchedDataFrames("JOINED_DATAFRAME").schema)
        }

        //validate transactions
        if (!AppConstants.NON_TRAVEL_PRODUCT_LINES.contains(productLineName.toLowerCase())) {
            val validatedDataFrames = dataValidator.validateJoinedDataFrame(sqlc, fetchedDataFrames("JOINED_DATAFRAME"), useCarAddressServiceFeature, productLineName.toLowerCase())
            val insertedTransactions = insertTransactions(sqlc, validatedDataFrames, runId, jobName, startDate, endDate, productLineName);
            publishMetricsToDataDog(fetchedDataFrames ++ insertedTransactions)
        } else {
            val validatedDataFrames = digitalServiceDataValidator.validateJoinedDataFrame(sqlc, fetchedDataFrames("JOINED_DATAFRAME"), useCarAddressServiceFeature, productLineName.toLowerCase())
            val insertedTransactions = insertTransactions(sqlc, validatedDataFrames, runId, jobName, startDate, endDate, productLineName)
            digitalServiceDataValidator.validateResults(validatedDataFrames, insertedTransactions, runId)
            publishMetricsToDataDog(fetchedDataFrames ++ insertedTransactions)
        }

        logger.info("End Processing:  Start date: " + startDate + " End date: " + endDate)

        applicationMonitor.timer(BOOKING_TO_ENRICHED_TRANSACTIONS_SLA).record(System.currentTimeMillis() - start, TimeUnit.MILLISECONDS)
        logger.info("Get metric for total load time " + (System.currentTimeMillis() - start))
    }

    //responsible for fetching booking transactions and enriching them with dimentional data
    protected def fetchTransactions(sqlc: SparkSession, startDate: String, endDate: String,
                                    runId: String, criteriaList: String, jobName: String, productLineName: String): Map[String, DataFrame] = {
        logger.info("Fetch Transactions. Start date: " + startDate + " End date: " + endDate)

        var transDataFrame = getStagedBookingTransactions(sqlc, startDate, endDate, runId, criteriaList, productLineName)

        val supplyDataFrame = getSupplyPropertyData(sqlc)

        var joinedDataFrame = sqlc.emptyDataFrame

        if (useCurrencyConversionFeature) {
            joinedDataFrame = doJoinFrames(transDataFrame, supplyDataFrame)
        } else {
            val exchRateDataFrame = getExchangeRateData(sqlc)
            joinedDataFrame = doJoinFrames(transDataFrame, supplyDataFrame, exchRateDataFrame)
        }

        val joinedDataFrameWithEventInfo = getDFWithEventInfo(joinedDataFrame, runId)

        Map("JOINED_DATAFRAME" -> joinedDataFrameWithEventInfo,
            "BOOKING_TRANSACTIONS" -> transDataFrame)
    }

    protected def getStagedBookingTransactions(sqlc: SparkSession, startDate: String, endDate: String, runId: String
                                               , criteriaList: String, productLineName: String): DataFrame = {
        logger.info("Get staged booking transactions from " + stagedBookingTransactions)

        var filterCriteria: String = getStagedBkgTransSelectionCriteria(startDate, endDate, runId, criteriaList, productLineName)

        var bookingTransDF: DataFrame = null
        if (!useCurrencyConversionFeature) {
            bookingTransDF = sqlBuilder.selectStagedBookingTransactions(sqlc, filterCriteria, productLineName)
        } else {
            bookingTransDF = sqlBuilder.selectStagedBookingTransactionsWithLocalAmounts(sqlc, filterCriteria, productLineName)
        }

        val manualTransactionsDF = getManualTransactionsDF(sqlc, filterCriteria, productLineName)
        val combinedDF = doAutoAndManualTransactionsUnion(bookingTransDF, manualTransactionsDF)

        val transDataFrameWithEventInfo = getDFWithEventInfo(combinedDF, runId)
        val transDataFrameDeduped = transDataFrameWithEventInfo.dropDuplicates(SQLColumnHelper.EVENT_UUID)

        val bookingTransDFWithTotalRoomNightCount = transDataFrameDeduped.withColumn(SQLColumnHelper.TOTAL_ROOM_NIGHT_COUNT,
            DataUtil.getTotalRoomNightCount(col(SQLColumnHelper.BEGIN_USE_DATE), col(SQLColumnHelper.END_USE_DATE)))

        val bookingTransDFWithNightNumber = bookingTransDFWithTotalRoomNightCount.withColumn(
            SQLColumnHelper.NIGHT_NUMBER, DataUtil.computeNightNumber(col(SQLColumnHelper.BEGIN_USE_DATE),
                col(SQLColumnHelper.END_USE_DATE), col(SQLColumnHelper.STAY_DATE)))

        val bkgTransDFWithCurrencyCode = transformBkgTransDFWithCurrencyCode(bookingTransDFWithNightNumber)

        var transformedBkgTransDF = bkgTransDFWithCurrencyCode

        if (!useCurrencyConversionFeature) {
            transformedBkgTransDF = transformBkgTransDF(bkgTransDFWithCurrencyCode, runId)
        }
        return transformedBkgTransDF
    }

    protected def transformBkgTransDFWithCurrencyCode(bookingTransDF: DataFrame): DataFrame = {
        val bookingDF = bookingTransDF.groupBy(
            SQLColumnHelper.BOOKING_ITEM_ID,
            SQLColumnHelper.SOURCE_SYSTEM_ID,
            SQLColumnHelper.BOOKING_ID,
            SQLColumnHelper.STAY_DATE)

        val bookingDFWithPurchCurrnCode = bookingDF.agg(
                collect_list(struct(SQLColumnHelper.TRANSACTION_TYPE_KEY, SQLColumnHelper.PRICE_CURRENCY_CODE, SQLColumnHelper.COST_CURRENCY_CODE))
                    as SQLColumnHelper.BKG_ATTRIBUTES_STRUCT)
            .withColumn(SQLColumnHelper.PURCHASE_PRICE_CURRENCY_CODE,
                DataUtil.computePurchasePriceCurrencyCodeUdf(col(SQLColumnHelper.BKG_ATTRIBUTES_STRUCT), lit(SQLColumnHelper.PRICE_CURRENCY_CODE)))
            .withColumn(SQLColumnHelper.PURCHASE_COST_CURRENCY_CODE,
                DataUtil.computePurchaseCostCurrencyCodeUdf(col(SQLColumnHelper.BKG_ATTRIBUTES_STRUCT), lit(SQLColumnHelper.COST_CURRENCY_CODE)))

        val bkgTransDFWithCurrencyCode = bookingTransDF.join(bookingDFWithPurchCurrnCode
            , Seq(
                SQLColumnHelper.BOOKING_ITEM_ID,
                SQLColumnHelper.SOURCE_SYSTEM_ID,
                SQLColumnHelper.BOOKING_ID,
                SQLColumnHelper.STAY_DATE
            )
            , "left")

        val bkgTransDFWithUpdatedPriceCurrnCode = getBkgTransDFWithUpdatedCurrCode(bkgTransDFWithCurrencyCode,
            SQLColumnHelper.UPDATED_PRICE_CURRENCY_CODE, SQLColumnHelper.PURCHASE_PRICE_CURRENCY_CODE, SQLColumnHelper.PRICE_CURRENCY_CODE)
        val bkgTransDFWithUpdatedCostCurrnCode = getBkgTransDFWithUpdatedCurrCode(bkgTransDFWithUpdatedPriceCurrnCode,
            SQLColumnHelper.UPDATED_COST_CURRENCY_CODE, SQLColumnHelper.PURCHASE_COST_CURRENCY_CODE, SQLColumnHelper.COST_CURRENCY_CODE)

        bkgTransDFWithUpdatedCostCurrnCode
    }

    protected def transformBkgTransDF(bookingTransDF: DataFrame, runId: String) = {
        val bkgTransDFWithPenaltyAmt = getBkgTransDFWithDerivedAmount(bookingTransDF)
        val bkgTransDFWithPostToTaxEngineCol = getBkgTransDFWithPostToTaxEngineCol(bkgTransDFWithPenaltyAmt)
        bkgTransDFWithPostToTaxEngineCol
    }

    protected def getBkgTransDFWithDerivedAmount(bookingTransDF: DataFrame) = {
        var bkgDFWithNetPrice: DataFrame = null

        if (!useCurrencyConversionFeature) {
            bkgDFWithNetPrice = getBkgDFWithDerivedColumns(bookingTransDF)
            bkgDFWithNetPrice = bookingTransDF.join(bkgDFWithNetPrice
                , Seq(
                    SQLColumnHelper.BOOKING_ITEM_ID,
                    SQLColumnHelper.SOURCE_SYSTEM_ID,
                    SQLColumnHelper.BOOKING_ID,
                    SQLColumnHelper.STAY_DATE
                )
                , "left")
        } else {
            bkgDFWithNetPrice = derivedAmountColumnsUsingConvertedAmounts(bookingTransDF)
        }

        val bookingTransDFWithPenaltyAmt: DataFrame = getBkgTransDFWithPenaltyAmt(bkgDFWithNetPrice)
        bookingTransDFWithPenaltyAmt
    }

    protected def derivedAmountColumnsUsingConvertedAmounts(bookingTransDF: DataFrame) = {
        val bookingDF = bookingTransDF.groupBy(
            SQLColumnHelper.BOOKING_ITEM_ID,
            SQLColumnHelper.SOURCE_SYSTEM_ID,
            SQLColumnHelper.BOOKING_ID,
            SQLColumnHelper.STAY_DATE)

        import org.apache.spark.sql.functions._
        val bookingDFWithTaxRate = bookingDF.agg(
                collect_list(struct(SQLColumnHelper.TRANSACTION_TYPE_KEY,
                    SQLColumnHelper.TRANSACTION_TYPE_NAME,
                    SQLColumnHelper.BASE_PRICE_AMOUNT,
                    SQLColumnHelper.TOTAL_FEE_PRICE_AMOUNT,
                    SQLColumnHelper.TOTAL_PRICE_ADJUSTMENT_AMOUNT,
                    SQLColumnHelper.TOTAL_TAX_PRICE_AMOUNT,
                    SQLColumnHelper.TOTAL_COST_ADJUSTMENT_AMOUNT,
                    SQLColumnHelper.TOTAL_COST_AMOUNT,
                    SQLColumnHelper.TOTAL_TAX_COST_AMOUNT,
                    SQLColumnHelper.BASE_COST_AMOUNT,
                    SQLColumnHelper.LGL_ENTITY_CODE)) as SQLColumnHelper.BKG_ATTRIBUTES_STRUCT)
            .withColumn(SQLColumnHelper.TAX_RATE_BOOK_DATE, DataUtil.computeTaxRateBookDateUdfExt(
                col(SQLColumnHelper.BKG_ATTRIBUTES_STRUCT),
                lit(legalEntitiesWithTaxRateBookDateSetToZero)
            ))
            .withColumn(SQLColumnHelper.TAX_RATE_BOOK_DATE_COST, DataUtil.computeTaxRateBookDateCostUdfExt(
                col(SQLColumnHelper.BKG_ATTRIBUTES_STRUCT),
                lit(legalEntitiesWithTaxRateBookDateSetToZero)
            ))

        val bookingDFWithJoinedTaxRate = bookingTransDF.join(bookingDFWithTaxRate
            , Seq(
                SQLColumnHelper.BOOKING_ITEM_ID,
                SQLColumnHelper.SOURCE_SYSTEM_ID,
                SQLColumnHelper.BOOKING_ID,
                SQLColumnHelper.STAY_DATE
            )
            , "left").drop(SQLColumnHelper.BKG_ATTRIBUTES_STRUCT)

        val bookingTransDfWithTaxExclusiveFields = deriveTaxExclusiveFields(bookingDFWithJoinedTaxRate)
        val groupedBookingDFWithTaxExclusiveFields = bookingTransDfWithTaxExclusiveFields.groupBy(
            SQLColumnHelper.BOOKING_ITEM_ID,
            SQLColumnHelper.SOURCE_SYSTEM_ID,
            SQLColumnHelper.BOOKING_ID,
            SQLColumnHelper.STAY_DATE)
        val bookingDFWithNetPrice = groupedBookingDFWithTaxExclusiveFields.agg(
                collect_list(struct(SQLColumnHelper.TRANSACTION_TYPE_KEY,
                    SQLColumnHelper.TRANSACTION_TYPE_NAME,
                    SQLColumnHelper.BASE_PRICE_AMOUNT,
                    SQLColumnHelper.BASE_COST_AMOUNT,
                    SQLColumnHelper.TOTAL_PRICE_ADJUSTMENT_AMOUNT_TAX_EXCLUSIVE,
                    SQLColumnHelper.TOTAL_FEE_PRICE_AMOUNT_TAX_EXCLUSIVE,
                    SQLColumnHelper.TOTAL_COST_ADJUSTMENT_AMOUNT_TAX_EXCLUSIVE,
                    SQLColumnHelper.TOTAL_FEE_COST_AMOUNT_TAX_EXCLUSIVE)) as SQLColumnHelper.BKG_ATTRIBUTES_STRUCT)
            .withColumn(SQLColumnHelper.NET_PRICE_BOOKING, DataUtil.computeNetPricePerBookingUdfExt(col(SQLColumnHelper.BKG_ATTRIBUTES_STRUCT)))
            .withColumn(SQLColumnHelper.NET_COST_BOOKING, DataUtil.computeNetCostPerBookingUdfExt(col(SQLColumnHelper.BKG_ATTRIBUTES_STRUCT)))
            .withColumn(SQLColumnHelper.IS_CANCEL_PRESENT, DataUtil.checkCancelTransPresentForBkgUdf(col(SQLColumnHelper.BKG_ATTRIBUTES_STRUCT)))
            .withColumn(SQLColumnHelper.PURCHASE_BASE_PRICE_AMOUNT, DataUtil.computePurchaseBasePriceAmountLocalUdf(col(SQLColumnHelper.BKG_ATTRIBUTES_STRUCT), lit(useCurrencyConversionFeature)))
            .withColumn(SQLColumnHelper.PURCHASE_BASE_PRICE_AMOUNT_LOCAL, lit(0))

        val bookingDFWithNetPriceJoined = bookingTransDfWithTaxExclusiveFields.join(bookingDFWithNetPrice
            , Seq(
                SQLColumnHelper.BOOKING_ITEM_ID,
                SQLColumnHelper.SOURCE_SYSTEM_ID,
                SQLColumnHelper.BOOKING_ID,
                SQLColumnHelper.STAY_DATE
            )
            , "left").drop(SQLColumnHelper.BKG_ATTRIBUTES_STRUCT)

        bookingDFWithNetPriceJoined
    }

    protected def deriveTaxExclusiveFields(bookingDFWithTaxRate: DataFrame): DataFrame = {
        bookingDFWithTaxRate.withColumn(SQLColumnHelper.TOTAL_PRICE_ADJUSTMENT_AMOUNT_TAX_EXCLUSIVE,
                DataUtil.computeTotalPriceAdjAmtTaxExclusiveUdf(
                    col(SQLColumnHelper.TOTAL_PRICE_ADJUSTMENT_AMOUNT),
                    col(SQLColumnHelper.OTHER_PRICE_ADJUSTMENT_AMOUNT),
                    col(SQLColumnHelper.EXPEDIA_GOODWILL_PRICE_ADJUSTMENT_AMOUNT),
                    col(SQLColumnHelper.GOODWILL_PRICE_ADJUSTMENT_AMOUNT),
                    col(SQLColumnHelper.EXPEDIA_PENALTY_PRICE_ADJUSTMENT_AMOUNT),
                    col(SQLColumnHelper.PENALTY_PRICE_ADJUSTMENT_AMOUNT),
                    col(SQLColumnHelper.TAX_RATE_BOOK_DATE)))
            .withColumn(SQLColumnHelper.TOTAL_FEE_PRICE_AMOUNT_TAX_EXCLUSIVE,
                DataUtil.computeTotalFeePriceAmtTaxExclusiveUdf(
                    col(SQLColumnHelper.TOTAL_FEE_PRICE_AMOUNT),
                    col(SQLColumnHelper.CANCEL_CHANGE_FEE_PRICE_AMOUNT),
                    col(SQLColumnHelper.TAX_RATE_BOOK_DATE)))
            .withColumn(SQLColumnHelper.TOTAL_COST_ADJUSTMENT_AMOUNT_TAX_EXCLUSIVE,
                DataUtil.computeTotalCostAdjAmtTaxExclusiveUdf(
                    col(SQLColumnHelper.OTHER_COST_ADJUSTMENT_AMOUNT),
                    col(SQLColumnHelper.SUPPLIER_COST_ADJUSTMENT_AMOUNT),
                    col(SQLColumnHelper.ECA_COST_ADJUSTMENT_AMOUNT),
                    col(SQLColumnHelper.VARIABLE_MARGIN_COST_ADJUSTMENT_AMOUNT),
                    col(SQLColumnHelper.SUPPLIER_RECONCILIATION_COST_ADJUSTMENT),
                    col(SQLColumnHelper.VARIABLE_MARGIN_CREDIT),
                    col(SQLColumnHelper.TAX_RATE_BOOK_DATE_COST),
                    col(SQLColumnHelper.TOTAL_COST_ADJUSTMENT_AMOUNT)))
            .withColumn(SQLColumnHelper.TOTAL_FEE_COST_AMOUNT_TAX_EXCLUSIVE,
                DataUtil.computeTotalFeeCostAmtTaxExclusiveUdf(
                    col(SQLColumnHelper.OTHER_FEE_COST_AMOUNT),
                    col(SQLColumnHelper.ECA_FEE_COST_AMOUNT),
                    col(SQLColumnHelper.SERVICE_CHARGE_COST_AMOUNT),
                    col(SQLColumnHelper.TAX_RATE_BOOK_DATE_COST)))
    }

    protected def getBkgDFWithDerivedColumns(bookingTransDF: DataFrame) = {
        val bookingDF = bookingTransDF.groupBy(
            SQLColumnHelper.BOOKING_ITEM_ID,
            SQLColumnHelper.SOURCE_SYSTEM_ID,
            SQLColumnHelper.BOOKING_ID,
            SQLColumnHelper.STAY_DATE)

        import org.apache.spark.sql.functions._
        val bookingDFWithNetPrice = bookingDF.agg(
                collect_list(struct(SQLColumnHelper.TRANSACTION_TYPE_KEY,
                    SQLColumnHelper.TRANSACTION_TYPE_NAME,
                    SQLColumnHelper.PRICE_CURRENCY_CODE,
                    SQLColumnHelper.BASE_PRICE_AMT_LOCAL,
                    SQLColumnHelper.TOTL_FEE_PRICE_AMT_LOCAL,
                    SQLColumnHelper.TOTL_PRICE_ADJ_AMT_LOCAL,
                    SQLColumnHelper.TOTL_TAX_PRICE_AMT_LOCAL,
                    SQLColumnHelper.OTHR_PRICE_ADJ_AMT_LOCAL,
                    SQLColumnHelper.EXPE_GDWLL_PRICE_ADJ_AMT_LOCAL,
                    SQLColumnHelper.GDWLL_PRICE_ADJ_AMT_LOCAL,
                    SQLColumnHelper.EXPE_PNLTY_PRICE_ADJ_AMT_LOCAL,
                    SQLColumnHelper.CNCL_CHG_FEE_PRICE_AMT_LOCAL,
                    SQLColumnHelper.PNLTY_PRICE_ADJ_AMT_LOCAL,
                    SQLColumnHelper.BASE_COST_AMT_LOCAL,
                    SQLColumnHelper.TOTL_COST_ADJ_AMT_LOCAL,
                    SQLColumnHelper.OTHR_COST_ADJ_AMT_LOCAL,
                    SQLColumnHelper.SUPPL_COST_ADJ_AMT_LOCAL,
                    SQLColumnHelper.OTHR_FEE_COST_AMT_LOCAL,
                    SQLColumnHelper.TOTL_COST_AMT_LOCAL,
                    SQLColumnHelper.TOTL_TAX_COST_AMT_LOCAL,
                    SQLColumnHelper.COST_CURRENCY_CODE,
                    SQLColumnHelper.ECA_COST_ADJ_AMT_LOCAL,
                    SQLColumnHelper.VAR_MARGN_COST_ADJ_LOCAL,
                    SQLColumnHelper.SUPPL_RECON_COST_ADJ_AMT_LOCAL,
                    SQLColumnHelper.VAR_MARGN_CREDT_LOCAL,
                    SQLColumnHelper.ECA_FEE_COST_AMT_LOCAL,
                    SQLColumnHelper.SVC_CHRG_COST_AMT_LOCAL,
                    SQLColumnHelper.LGL_ENTITY_CODE
                )) as SQLColumnHelper.BKG_ATTRIBUTES_STRUCT)
            .withColumn(SQLColumnHelper.TAX_RATE_BOOK_DATE, DataUtil.computeTaxRateBookDateUdf(
                col(SQLColumnHelper.BKG_ATTRIBUTES_STRUCT),
                lit(legalEntitiesWithTaxRateBookDateSetToZero)
            ))
            .withColumn(SQLColumnHelper.TAX_RATE_BOOK_DATE_COST, DataUtil.computeTaxRateBookDateCostUdf(
                col(SQLColumnHelper.BKG_ATTRIBUTES_STRUCT),
                lit(legalEntitiesWithTaxRateBookDateSetToZero)
            ))
            .withColumn(SQLColumnHelper.NET_PRICE_BOOKING,
                DataUtil.computeNetPricePerBookingUdf(col(SQLColumnHelper.BKG_ATTRIBUTES_STRUCT),
                    col(SQLColumnHelper.TAX_RATE_BOOK_DATE)))
            .withColumn(SQLColumnHelper.NET_COST_BOOKING,
                DataUtil.computeNetCostPerBookingUdf(col(SQLColumnHelper.BKG_ATTRIBUTES_STRUCT),
                    col(SQLColumnHelper.TAX_RATE_BOOK_DATE_COST)))
            .withColumn(SQLColumnHelper.IS_CANCEL_PRESENT,
                DataUtil.checkCancelTransPresentForBkgUdf(col(SQLColumnHelper.BKG_ATTRIBUTES_STRUCT)))
            .withColumn(SQLColumnHelper.PURCHASE_BASE_PRICE_AMOUNT_LOCAL,
                DataUtil.computePurchaseBasePriceAmountLocalUdf(col(SQLColumnHelper.BKG_ATTRIBUTES_STRUCT),
                    lit(useCurrencyConversionFeature)))
            .withColumn(SQLColumnHelper.CONVERTED_AMOUNTS, lit(null))

        bookingDFWithNetPrice
    }

    private def getBkgTransDFWithPenaltyAmt(bkgTransDF: DataFrame) = {
        var bookingTransDFWithPricePenaltyAmt: DataFrame = null
        if (!useCurrencyConversionFeature) {
            bookingTransDFWithPricePenaltyAmt = bkgTransDF
                .withColumn(SQLColumnHelper.PENALTY_AMOUNT_LOCAL,
                    DataUtil.computePricePenaltyAmountUdf(
                        col(SQLColumnHelper.NET_PRICE_BOOKING),
                        col(SQLColumnHelper.TRANSACTION_TYPE_NAME),
                        col(SQLColumnHelper.BUSINESS_MODEL_NAME)
                    ))
        } else {
            bookingTransDFWithPricePenaltyAmt = bkgTransDF
                .withColumn(SQLColumnHelper.PENALTY_PRICE_AMOUNT,
                    DataUtil.computePricePenaltyAmountUdf(
                        col(SQLColumnHelper.NET_PRICE_BOOKING),
                        col(SQLColumnHelper.TRANSACTION_TYPE_NAME),
                        col(SQLColumnHelper.BUSINESS_MODEL_NAME)
                    ))
                .withColumn(SQLColumnHelper.PENALTY_AMOUNT_LOCAL, lit(0))
        }
        var bookingTransDFWithCostPenaltyAmt: DataFrame = null
        if (!useCurrencyConversionFeature) {
            bookingTransDFWithCostPenaltyAmt = bookingTransDFWithPricePenaltyAmt
                .withColumn(SQLColumnHelper.PENALTY_COST_AMOUNT_LOCAL,
                    DataUtil.computeCostPenaltyAmountUdf(
                        col(SQLColumnHelper.NET_COST_BOOKING),
                        col(SQLColumnHelper.TRANSACTION_TYPE_NAME),
                        col(SQLColumnHelper.BUSINESS_MODEL_NAME)
                    ))
        } else {
            bookingTransDFWithCostPenaltyAmt = bookingTransDFWithPricePenaltyAmt
                .withColumn(SQLColumnHelper.PENALTY_COST_AMOUNT,
                    DataUtil.computeCostPenaltyAmountUdf(
                        col(SQLColumnHelper.NET_COST_BOOKING),
                        col(SQLColumnHelper.TRANSACTION_TYPE_NAME),
                        col(SQLColumnHelper.BUSINESS_MODEL_NAME)
                    ))
                .withColumn(SQLColumnHelper.PENALTY_COST_AMOUNT_LOCAL, lit(0))
        }
        bookingTransDFWithCostPenaltyAmt
    }

    protected def getBkgTransDFWithPostToTaxEngineCol(bkgTransDF: DataFrame): DataFrame = {
        var bkgTransDFWithPostToTaxEngineCol: DataFrame = null
        if (!useCurrencyConversionFeature) {
            bkgTransDFWithPostToTaxEngineCol = bkgTransDF
                .withColumn(SQLColumnHelper.POST_TO_TAX_ENGINE,
                    DataUtil.shouldBePostedToTaxEngineUdf(
                        col(SQLColumnHelper.IS_CANCEL_PRESENT),
                        col(SQLColumnHelper.PENALTY_AMOUNT_LOCAL),
                        col(SQLColumnHelper.PENALTY_COST_AMOUNT_LOCAL),
                        col(SQLColumnHelper.BUSINESS_MODEL_NAME)
                    ))
        } else {
            bkgTransDFWithPostToTaxEngineCol = bkgTransDF
                .withColumn(SQLColumnHelper.POST_TO_TAX_ENGINE,
                    DataUtil.shouldBePostedToTaxEngineUdf(
                        col(SQLColumnHelper.IS_CANCEL_PRESENT),
                        col(SQLColumnHelper.PENALTY_PRICE_AMOUNT),
                        col(SQLColumnHelper.PENALTY_COST_AMOUNT),
                        col(SQLColumnHelper.BUSINESS_MODEL_NAME)
                    ))
        }
        bkgTransDFWithPostToTaxEngineCol
    }

    protected def getBkgTransDFWithUpdatedCurrCode(bkgTransDF: DataFrame, updatedCurrencyCode: String,
                                                   purchaseCurrencyCode: String,
                                                   currencyCode: String): DataFrame = {
        val bkgTransDFWithUpdatedCurrCode = bkgTransDF.withColumn(updatedCurrencyCode,
            when(col(currencyCode) === "Unknown", col(purchaseCurrencyCode))
                .otherwise(col(currencyCode)))
        bkgTransDFWithUpdatedCurrCode
    }

    def getStagedBkgTransSelectionCriteria(startDate: String, endDate: String,
                                           runId: String, criteriaList: String, productLineName: String) = {
        val filterCriteria =
            raw"""cast(transaction_liability_date as date) >= '${startDate}'
                 | and cast(transaction_liability_date as date) <= '${endDate}'
                 | and cast(booking_item.booking_event_date as date) <= cast(transaction_liability_date as date)
                 | and transaction_liability_date_type = '${SQLColumnHelper.TRANSACTION_LIABILITY_DATE_TYPE_STAY_DATE}'
                 | and lower(product_line_name) = lower('${productLineName}')
                 | """.stripMargin
        filterCriteria
    }

    protected def executeInsertIntoEnrichedTransactionQuery(sparkSession: SparkSession,
                                                            startDate: String,
                                                            endDate: String,
                                                            productLineName: String) = {

        var partnerItemLodgingColumns = SQLColumnHelper.partnerItemLodgingColumnsWithoutStacData
        var propertyItemLodgingColumns = SQLColumnHelper.propertyItemColumnsWithoutStacData
        if (useStacAttributesFeature) {
            val replacementString = sqlBuilder.getStacAttributesReplacementString(getDistinctStacAtributes(sparkSession, productLineName))
            partnerItemLodgingColumns = SQLColumnHelper.partnerItemLodgingColumnsWithStacData.replace("stac_replacement_fields", replacementString)
            propertyItemLodgingColumns = SQLColumnHelper.propertyItemColumnsWithStacData
        }

        sparkSession.sql(
            raw"""
                            INSERT OVERWRITE TABLE ${stagedEnrichedTransactions}
                            PARTITION(${SQLColumnHelper.TRANSACTION_LIABILITY_DATE},
                                      ${SQLColumnHelper.TRANSACTION_LIABILITY_DATE_TYPE},
                                      ${SQLColumnHelper.PRODUCT_LINE_NAME})
              SELECT
                                ${SQLColumnHelper.bookingItemColumns},
                                ${SQLColumnHelper.itemAmountColumns},
                                ${propertyItemLodgingColumns},
                                ${SQLColumnHelper.bookingDetailsColumnFileUpload},
                                ${SQLColumnHelper.eventInfoColumns},
                                null as ${SQLColumnHelper.CAR_ITEM},
                                ${SQLColumnHelper.LOCAL_AMOUNTS},
                                ${SQLColumnHelper.CONVERTED_AMOUNTS},
                                ${partnerItemLodgingColumns},
                                null as ${SQLColumnHelper.NON_TRAVEL_ITEM},
                                null as ${SQLColumnHelper.BOOKING_HISTORY},
                                CASE
                                    WHEN ${SQLColumnHelper.EVENT_SOURCE_SYSTEM_NAME} = '${SQLColumnHelper.GTP_LEGACY}'
                                        THEN ${SQLColumnHelper.STAY_DATE}
                                    ELSE ${SQLColumnHelper.TRANSACTION_LIABILITY_DATE}
                                END AS ${SQLColumnHelper.TRANSACTION_LIABILITY_DATE},
                                '${SQLColumnHelper.TRANSACTION_LIABILITY_DATE_TYPE_STAY_DATE}'
                                    as ${SQLColumnHelper.TRANSACTION_LIABILITY_DATE_TYPE},
                                ${SQLColumnHelper.PRODUCT_LINE_NAME}
              FROM tempEnrichedTransView
       """)
    }

    protected def executeInsertIntoExceptionTransactionQuery(sparkSession: SparkSession, startDate: String,
                                                             endDate: String): DataFrame = {
        sparkSession.sql(
            raw"""
                            INSERT OVERWRITE TABLE ${stagedExceptionTransactions}
                            PARTITION(${SQLColumnHelper.TRANSACTION_LIABILITY_DATE},
                                      ${SQLColumnHelper.TRANSACTION_LIABILITY_DATE_TYPE},
                                      ${SQLColumnHelper.PRODUCT_LINE_NAME})
              SELECT
                                ${SQLColumnHelper.BOOKING_ID},
                                ${SQLColumnHelper.BOOKING_ITEM_ID},
                                ${SQLColumnHelper.BOOKING_EVENT_DATE},
                                ${SQLColumnHelper.BOOKING_EVENT_DATETIME},
                                ${SQLColumnHelper.TRANSACTION_TYPE_NAME},
                                ${SQLColumnHelper.TRANSACTION_TYPE_KEY},
                                ${SQLColumnHelper.SOURCE_SYSTEM_ID},
                                ${SQLColumnHelper.COST_CURRENCY_CODE},
                                ${SQLColumnHelper.STAY_DATE},
                                ${SQLColumnHelper.CAR_LOCATION_ID},
                                ${SQLColumnHelper.eventInfoColumns},
                                ${SQLColumnHelper.EXCEPTIONS},
                                null as ${SQLColumnHelper.NON_TRAVEL_ITEM},
                                CASE
                                    WHEN ${SQLColumnHelper.EVENT_SOURCE_SYSTEM_NAME} = '${SQLColumnHelper.GTP_LEGACY}'
                                        THEN ${SQLColumnHelper.STAY_DATE}
                                    ELSE ${SQLColumnHelper.TRANSACTION_LIABILITY_DATE}
                                END AS ${SQLColumnHelper.TRANSACTION_LIABILITY_DATE},
                                '${SQLColumnHelper.TRANSACTION_LIABILITY_DATE_TYPE_STAY_DATE}'
                                    as ${SQLColumnHelper.TRANSACTION_LIABILITY_DATE_TYPE},
                                ${SQLColumnHelper.PRODUCT_LINE_NAME}
              FROM tempEnrichedExceptionTransView
    """)
    }

    protected def getSupplyPropertyData(sqlc: SparkSession): DataFrame = {
        logger.info("Get supply property data from " + lodgingProfileEg)
        return sqlc.sql(
            raw"""
              SELECT
                                 ${SQLColumnHelper.EG_PROPERTY_ID}
                ,${SQLColumnHelper.PROPERTY_NAME}
                ,${SQLColumnHelper.FIRST_ADDRESS_LINE}
                                ,${SQLColumnHelper.SECOND_ADDRESS_LINE}
                ,${SQLColumnHelper.PROPERTY_CITY_NAME}
                ,${SQLColumnHelper.PROPERTY_STATE_PROVINCE_NAME}
                                ,${SQLColumnHelper.PROPERTY_COUNTRY_NAME}
                                ,${SQLColumnHelper.PROPERTY_COUNTRY_CODE}
                ,${SQLColumnHelper.PROPERTY_POSTAL_CODE}
                ,${SQLColumnHelper.PROPERTY_LONGITUDE}
                ,${SQLColumnHelper.PROPERTY_LATITUDE}
                                ,${SQLColumnHelper.PROPERTY_TYPE_NAME}
                                ,${SQLColumnHelper.PROPERTY_BRAND_ID}
                                ,${SQLColumnHelper.PROPERTY_BRAND_NAME}
                                ,${SQLColumnHelper.DEFAULT_PROPERTY_PARENT_CHAIN_ID} as ${SQLColumnHelper.PROPERTY_PARENT_CHAIN_ID}
                                ,"${SQLColumnHelper.DEFAULT_PROPERTY_PARENT_CHAIN_NAME}"  as ${SQLColumnHelper.PROPERTY_PARENT_CHAIN_NAME}
              FROM
                           ${lodgingProfileEg} s
    """)
    }

    protected def getExchangeRateData(sqlc: SparkSession): DataFrame = {
        logger.info("Get exchange rate data from " + federatedDailyExchangeRate)
        return sqlc.sql(
            raw"""
              SELECT
                                 ${SQLColumnHelper.EXCH_RATE}
                                ,${SQLColumnHelper.EXCH_RATE_DATE}
                                ,${SQLColumnHelper.FROM_CURRN_CODE}
              FROM
                           ${federatedDailyExchangeRate} exch
                            where to_currn_code = 'USD'

    """)
    } //only cover US jurisdictions for the current mvp1, add SP

    protected def getAllExchangeRateData(sqlc: SparkSession, filterCondition: String): DataFrame = {
        logger.info("Get exchange rate data from " + federatedDailyExchangeRate)
        val exchangeRateQuery =
            raw"""
              SELECT
                                 ${SQLColumnHelper.EXCH_RATE}
                                ,${SQLColumnHelper.EXCH_RATE_DATE}
                                ,${SQLColumnHelper.FROM_CURRN_CODE}
                                ,${SQLColumnHelper.TO_CURRN_CODE}
							FROM
			  	                 ${federatedDailyExchangeRate} exch
                            where ${SQLColumnHelper.TO_CURRN_CODE} in (${filterCondition})
			  	           """
        logger.info("Exchange rate to_currn_code filter query is: "+ exchangeRateQuery)
        var exchangeRateDf = sqlc.sql(exchangeRateQuery)

        exchangeRateDf.persist(StorageLevel.MEMORY_AND_DISK)
    }

    protected def getStacData(sqlc: SparkSession, productLineName: String): DataFrame = {
        logger.info("Get STAC data")

        sqlBuilder.createSelectStacQuery(sqlc, productLineName, getDistinctStacAtributes(sqlc, productLineName), getDistinctRoomLevelStacAtributes(sqlc, productLineName))
    }

    protected def getDistinctStacAtributes(sqlc: SparkSession, productLineName: String): Array[String] = {
        val distinctStacAttributesQuery = new SQLBuilder().getDistinctStacAttributesQuery(productLineName, stacTable)

        val stacAtributesDF = sqlc.sql(distinctStacAttributesQuery)

        val stacAttributes: Array[String] = stacAtributesDF.collect().map(row => row.getString(0))

        stacAttributes
    }

    protected def getDistinctRoomLevelStacAtributes(sqlc: SparkSession, productLineName: String): Set[String] = {
        val distinctStacRoomLevelAttributesQuery = new SQLBuilder().getDistinctRoomLevelStacAttributesQuery(productLineName, stacTable)

        val stacRoomLevelAtributesDF = sqlc.sql(distinctStacRoomLevelAttributesQuery)

        val stacRoomLevelAttributes: Set[String] = stacRoomLevelAtributesDF.collect().map(row => row.getString(0)).toSet

        stacRoomLevelAttributes
    }

    protected def doJoinFrames(transDataFrame: DataFrame, supplyDataFrame: DataFrame, exchRateDataFrame: DataFrame): DataFrame = {

        logger.info("Join data frames")

        val joinedTransSupplyDataFrame = transDataFrame.alias("t").join(
            supplyDataFrame
            , col("property_id") === col("s.eg_property_id")
            , "left").join(
            exchRateDataFrame.alias("e1").withColumnRenamed("exch_rate", "exch_rate_book_date")
            , col("updated_price_currency_code") === col("e1.from_currn_code")
                && col("t.book_date") === col("e1.exch_rate_date")
            , "left").join(
            exchRateDataFrame.alias("e2").withColumnRenamed("exch_rate", "exch_rate_stay_date")
            , col("updated_price_currency_code") === col("e2.from_currn_code")
                && col("t.stay_date") === col("e2.exch_rate_date")
            , "left").join(
            exchRateDataFrame.alias("e3").withColumnRenamed("exch_rate", "exch_rate_stay_date_cost")
            , col("updated_cost_currency_code") === col("e3.from_currn_code")
                && col("t.stay_date") === col("e3.exch_rate_date")
            , "left")

        joinedTransSupplyDataFrame

    }

    def doJoinFrames(transDataFrame: DataFrame, supplyDataFrame: DataFrame): DataFrame = {

        logger.info("Join data frames")

        val joinedTransSupplyDataFrame = transDataFrame.join(
            supplyDataFrame
            , col("property_id") === col("s.eg_property_id")
            , "left")

        joinedTransSupplyDataFrame //returned dataframe if the feature flag is false, without STAC data

    }

    protected def getCriteriaFilteredDF(joinedDataFrame: DataFrame): DataFrame = joinedDataFrame

    protected def getProductCatalogDataForLX(sqlc: SparkSession): DataFrame = {
        logger.info("Get Product Catalog data for LX transactions")

        val sqlQuery = sqlBuilder.createSelectProductCatalogTableForLX()

        logger.info("LX PRODUCT CATALOG FINAL QUERY: \n" + sqlQuery)

        sqlc.sql(sqlQuery)
    }

    protected def cleanUpPartitionsInExceptionTable(sparkSession: SparkSession, dataFrameMap: Map[String, DataFrame], runId: String,
                                                    startDate: String, endDate: String, productLineName: String): Unit = {
        /*
        spark sql is unable to change preserved properties like EXTERNAL at the moment, hence we need to drop to console
        to achieve this. This is required to clean up the data from S3 location as well, for otherwise dropping the
        partition alone only clears it from metadata not from the actual partition stored on S3.
         */
        Seq("hive", "-e", s"ALTER TABLE ${stagedExceptionTransactions} SET TBLPROPERTIES('EXTERNAL'='FALSE')").!
        sparkSession.sql(
            raw"""alter table ${stagedExceptionTransactions} drop if exists
                 |${
                DataUtil.getPartitionDetailsForGivenDateRange(startDate, endDate, productLineName,
                    SQLColumnHelper.TRANSACTION_LIABILITY_DATE_TYPE_STAY_DATE)
            }""".stripMargin)
        Seq("hive", "-e", s"ALTER TABLE ${stagedExceptionTransactions} SET TBLPROPERTIES('EXTERNAL'='TRUE')").!
    }

    protected def insertTransactions(sqlc: SparkSession, validatedDataFrameMap: Map[String, DataFrame], runId: String,
                                     jobName: String, startDate: String, endDate: String, productLineName: String): Map[String, DataFrame] = {
        insertIntoJobInfo(sqlc, startDate, endDate, runId, jobName)
        var distinctEnrichedTransactionsDf: DataFrame = null
        if (PRODUCT_LINE_NAME_VRBO.equalsIgnoreCase(productLineName)) {
            distinctEnrichedTransactionsDf = validatedDataFrameMap("ENRICHED_TRANSACTIONS")
        } else {
            distinctEnrichedTransactionsDf = getDistinctDF(validatedDataFrameMap("ENRICHED_TRANSACTIONS"))
        }
        insertIntoEnrichedTransactionsTable(sqlc, distinctEnrichedTransactionsDf, runId, jobName, startDate, endDate, productLineName)
        cleanUpPartitionsInExceptionTable(sqlc, validatedDataFrameMap, runId, startDate, endDate, productLineName)
        insertIntoExceptionTable(sqlc, validatedDataFrameMap("EXCEPTION_TRANSACTIONS"), runId, startDate, endDate)
        Map("EXCEPTION_TRANSACTIONS" -> validatedDataFrameMap("EXCEPTION_TRANSACTIONS"),
            "DISTINCT_ENRICHED_TRANSACTIONS" -> distinctEnrichedTransactionsDf)
    }

    protected def insertIntoExceptionTable(sparkSession: SparkSession, exceptionDF: DataFrame, runId: String,
                                           startDate: String, endDate: String): Unit = {

        exceptionDF.createOrReplaceTempView("tempEnrichedExceptionTransView")

        executeInsertIntoExceptionTransactionQuery(sparkSession, startDate, endDate)
    }

    protected def insertIntoEnrichedTransactionsTable(sparkSession: SparkSession, distinctDf: DataFrame,
                                                      runId: String, jobName: String, startDate: String,
                                                      endDate: String, productLineName: String): Unit = {
        distinctDf.createOrReplaceTempView("tempEnrichedTransView")
        executeInsertIntoEnrichedTransactionQuery(sparkSession, startDate, endDate, productLineName)
    }

    protected def getDistinctDF(dataFrame: DataFrame, isNonTravel: Boolean = false): DataFrame = {
        val columnNames = if (isNonTravel) {
            Array(SQLColumnHelper.INVOICE_LINE_NUMBER,
                SQLColumnHelper.INVOICE_NUMBER, SQLColumnHelper.COST_CURRENCY_CODE,
                SQLColumnHelper.STAY_DATE)
        } else {
            Array(SQLColumnHelper.BOOKING_ITEM_ID, SQLColumnHelper.TRANSACTION_TYPE_KEY,
                SQLColumnHelper.BOOKING_EVENT_DATETIME, SQLColumnHelper.SOURCE_SYSTEM_ID,
                SQLColumnHelper.BOOKING_ID, SQLColumnHelper.COST_CURRENCY_CODE,
                SQLColumnHelper.STAY_DATE,
                SQLColumnHelper.LODG_ROOM_TYPE_ID)
        }
        import org.apache.spark.sql.functions._
        dataFrame.orderBy(desc(SQLColumnHelper.PUBLISHED_TIMESTAMP)).dropDuplicates(columnNames)
    }

    private def publishMetricsToDataDog(dataFramesMap: Map[String, DataFrame]): Unit = {

        for ((name, dataFrame) <- dataFramesMap) {
            val metricName = getMetricName(name + "_COUNT")
            val dataFrameCount = dataFrame.count()
            applicationMonitor.counter(metricName).increment(dataFrameCount)
            logger.info(s"The number of ${name}: ${dataFrameCount}")
        }
    }

    private def getMetricName(x: String): String = x match {
        case "BOOKING_TRANSACTIONS_COUNT" => BOOKING_TRANSACTIONS_COUNT
        case "JOINED_DATAFRAME_COUNT" => JOINED_DATAFRAME_COUNT
        case "EXCEPTION_TRANSACTIONS_COUNT" => EXCEPTION_TRANSACTIONS_COUNT
        case "DISTINCT_ENRICHED_TRANSACTIONS_COUNT" => ENRICHED_TRANSACTIONS_COUNT
    }

    private def insertIntoJobInfo(sparkSession: SparkSession, startDate: String, endDate: String, runId: String,
                                  jobName: String): DataFrame = {
        val jobInfoSeq = Seq(JobInfoCase(runId, jobName, startDate, endDate, getCurrentDateTime()))
        val jobInfoDataFrame = sparkSession.createDataFrame(jobInfoSeq).toDF()
        jobInfoDataFrame.createOrReplaceTempView("tempJobInfoView")

        return sparkSession.sql(
            raw"""
                            INSERT OVERWRITE TABLE ${jobInfoTable}
                            PARTITION(run_id)
              SELECT
                                ${SQLColumnHelper.JOB_NAME},
                                ${SQLColumnHelper.START_DATE},
                                ${SQLColumnHelper.END_DATE},
                                ${SQLColumnHelper.PUBLISHED_TIMESTAMP},
                                ${SQLColumnHelper.RUN_ID}
              FROM tempJobInfoView
       """)
    }

    protected def getDFWithEventInfo(dataFrame: DataFrame, runId: String): DataFrame = {
        val dfWithEventInfo = dataFrame
            .withColumn(SQLColumnHelper.RUN_ID, lit(runId))
            .withColumn(SQLColumnHelper.PUBLISHED_TIMESTAMP, lit(getCurrentDateTime()))
            .withColumn(SQLColumnHelper.EVENT_UUID, DataUtil.formEventUUID(concat(
                col(SQLColumnHelper.BOOKING_ITEM_ID), lit("-"),
                col(SQLColumnHelper.TRANSACTION_TYPE_KEY), lit("-"),
                col(SQLColumnHelper.BOOKING_EVENT_DATETIME), lit("-"),
                col(SQLColumnHelper.SOURCE_SYSTEM_ID), lit("-"),
                col(SQLColumnHelper.BOOKING_ID), lit("-"),
                col(SQLColumnHelper.STAY_DATE), lit("-"),
                col(SQLColumnHelper.COST_CURRENCY_CODE)
            )))
            .withColumn(SQLColumnHelper.HASH_EVENT_UUID, col(SQLColumnHelper.HASH_EVENT_UUID))
        dfWithEventInfo
    }

    def getCurrentDateTime(): String = {
        return Calendar.getInstance().getTime().toString
    }

    private def filterQualifiedTransactions(joinedDataFrame: DataFrame): DataFrame = {
        //fetch query filter condition
        queryFilterCondition = configurationRunner.fetchParsedConfigurations(RuleType.RULE_TYPE_QUERY_FILTER)
        logger.info("Preprocessing filter condition: " + queryFilterCondition)
        val filteredJoinedDataFrame = joinedDataFrame.where(queryFilterCondition)
        filteredJoinedDataFrame
    }

    private def convertLocalAmountsToFilingAmounts(qualifiedTransactionDf:DataFrame, sqlc:SparkSession,
                                                   productLineName:String): DataFrame ={
        var qualifiedTransWithFilingCurrnDf:DataFrame = null
        if (productLineName.equalsIgnoreCase(AppConstants.PRODUCT_LINE_NAME_LODGING) ||
            productLineName.equalsIgnoreCase(AppConstants.PRODUCT_LINE_NAME_ADVERTISING) ||
            productLineName.equalsIgnoreCase(AppConstants.PRODUCT_LINE_NAME_INVOICE_SERVICES) ||
            PRODUCT_LINE_NAME_VRBO.equalsIgnoreCase(productLineName)
        ) {
            qualifiedTransWithFilingCurrnDf = applyCurrencyConfigRules(qualifiedTransactionDf, sqlc)
        } else {
            var qualifiedTransactionDfMod: DataFrame = sqlc.emptyDataFrame
            if (productLineName.toLowerCase().equals("car")) {
                qualifiedTransactionDfMod = qualifiedTransactionDf.withColumn("country_code",
                    col("car_pick_up_location_country_code"))
            } else if (productLineName.toLowerCase().equals(AppConstants.PRODUCT_LINE_NAME_LX.toLowerCase())) {
                qualifiedTransactionDfMod = qualifiedTransactionDf
            }

            qualifiedTransWithFilingCurrnDf = applyCurrencyConfigRules(qualifiedTransactionDfMod, sqlc)
        }
        val qualifiedTransactionDfWithExchRate = joinExchangeRateWithFilingCurrency(sqlc, qualifiedTransWithFilingCurrnDf, productLineName)
        var localAmountsDf: DataFrame = null

        if (productLineName.toLowerCase().equals(AppConstants.PRODUCT_LINE_NAME_LODGING.toLowerCase())) {
            localAmountsDf = sqlBuilder.selectLocalAmountsLodging(qualifiedTransactionDfWithExchRate)
        } else if (productLineName.toLowerCase().equals(AppConstants.PRODUCT_LINE_NAME_CAR.toLowerCase())) {
            localAmountsDf = sqlBuilder.selectLocalAmountsCar(qualifiedTransactionDfWithExchRate)
        } else if (productLineName.toLowerCase().equals(AppConstants.PRODUCT_LINE_NAME_LX.toLowerCase())) {
            localAmountsDf = sqlBuilder.selectLocalAmountsLX(qualifiedTransactionDfWithExchRate)
        } else if (productLineName.equalsIgnoreCase(AppConstants.PRODUCT_LINE_NAME_ADVERTISING) ||
            productLineName.equalsIgnoreCase(AppConstants.PRODUCT_LINE_NAME_INVOICE_SERVICES)) {
            localAmountsDf = sqlBuilder.selectLocalAmountsAdvertising(qualifiedTransactionDfWithExchRate)
        }

        var convertedAmountsDf: DataFrame = null
        if (PRODUCT_LINE_NAME_VRBO.equalsIgnoreCase(productLineName)) {
            convertedAmountsDf = qualifiedTransactionDfWithExchRate
        } else {
            convertedAmountsDf = AmountConverter.deriveConvertedAmounts(preProcessorConfig.value.bookingConfiguration.head,
                tableSchemaConfig.value.schema.head, localAmountsDf, sqlc)
            convertedAmountsDf = joinQualifiedTransDfWithConvertedAmountsDf(qualifiedTransactionDfWithExchRate, convertedAmountsDf)
        }
        convertedAmountsDf
    }

    /**
     * Get cleansed address for car pickup and update location-id for car.
     *
     * @param bookingTransDF
     * @return
     */
    protected def transformCarAddress(sqlc: SparkSession, bookingTransDF: DataFrame, productLineName: String): DataFrame = {
        logger.info("Getting details for location id for car")

        val url = carAddressService.getBaseURL() + carAddressService.getPath()
        var start = System.currentTimeMillis()
        logger.info("start time api call in transformCarAddress: " + start)
        var newDf = bookingTransDF.withColumn(SQLColumnHelper.CAR_LOCATION_ID,
            CarAddressServiceHelper.getCarBookingLocationId(lit(url),
                col(SQLColumnHelper.BOOKING_ITEM_ID),
                col(SQLColumnHelper.LEGAL_ENTITY_CODE),
                col(SQLColumnHelper.BUSINESS_MODEL_SUBTYPE_NAME)))

        newDf = newDf.persist(StorageLevel.MEMORY_AND_DISK)
        logger.info("end time api call in transformCarAddress: " + (System.currentTimeMillis() - start))
        logger.info("count after api call in transformCarAddress:" + newDf.count())

        if (hotwireCarsEnabled) {
            logger.info("Getting location id DF for Hotwire cars")
            val hwCarLocationIdDf = getHotwireCarLocationIdDf(sqlc)
            logger.info("Joining the booking DF with HW locationId DF")
            newDf = newDf.join(hwCarLocationIdDf,
                newDf(SQLColumnHelper.ITIN_NBR) === hwCarLocationIdDf(SQLColumnHelper.DISPLAY_NUMBER) &&
                    newDf(SQLColumnHelper.BOOK_DATE) === hwCarLocationIdDf(SQLColumnHelper.DAY_CODE),
                "left").drop(SQLColumnHelper.DISPLAY_NUMBER)

            newDf = newDf.withColumn(SQLColumnHelper.CAR_LOCATION_ID,
                    when((col(SQLColumnHelper.LEGAL_ENTITY_CODE).equalTo(lit(SQLColumnHelper.HOTWIRE_LEGAL_ENTITY_CODE)) ||
                        col(SQLColumnHelper.BUSINESS_MODEL_SUBTYPE_NAME).equalTo(lit(SQLColumnHelper.OPAQUE_MERCHANT))) ||
                        (col(SQLColumnHelper.CAR_LOCATION_ID).isNull &&
                            col(SQLColumnHelper.BUSINESS_MODEL_NAME).equalTo(lit(SQLColumnHelper.AGENCY)) &&
                            col(SQLColumnHelper.LEGAL_ENTITY_CODE).equalTo(lit(SQLColumnHelper.EXPEDIA_LEGAL_ENTITY_CODE))),
                        col(SQLColumnHelper.CAR_LOCAL_LOCATION_PROD_ID))
                        .otherwise(col(SQLColumnHelper.CAR_LOCATION_ID)))
                .drop(SQLColumnHelper.CAR_LOCAL_LOCATION_PROD_ID)
        }

        newDf = newDf.drop(SQLColumnHelper.ITIN_NBR)
        val locationDF = sqlBuilder.selectProductAddressDetails(sqlc, productLineName)

        // extract geocode from locationDF
        val newLocationDF = locationDF.withColumn(SQLColumnHelper.PRODUCT_CATALOG_TAX_AREA_ID, DataUtil.getValidGeocodeFromProductCatalog(col("attributes")))

        start = System.currentTimeMillis()
        logger.info("start time left join in transformCarAddress: " + start)
        val transformedDF = getUpdatedLocation(sqlc, newDf, newLocationDF)
        logger.info("end time left join in transformCarAddress: " + (System.currentTimeMillis() - start))
        //car variance juridiction filter
        val transformedDFwithfilter = filterQualifiedTransactions(transformedDF)
        transformedDFwithfilter

    }

    protected def getHotwireCarLocationIdDf(sqlc: SparkSession): DataFrame = {
        sqlc.sql(
            raw"""
                      SELECT lcll.${SQLColumnHelper.CAR_LOCAL_LOCATION_PROD_ID},
                      fcp.${SQLColumnHelper.DISPLAY_NUMBER},
                      fcp.${SQLColumnHelper.DAY_CODE}
                      FROM
                      ${carLocation} lcll,
                      ${carPurchase} fcp
                      WHERE
                      lcll.car_local_location_id = fcp.car_pickup_local_location_id
            """)
    }

    protected def transformLodgingAddress(sqlc: SparkSession, bookingTransDF: DataFrame, productLineName: String): DataFrame = {
        var locationDF: DataFrame = null
        if (productLineName.equalsIgnoreCase(PRODUCT_LINE_NAME_LODGING)) {
            locationDF = sqlBuilder.selectProductAddressDetails(sqlc, productLineName)
        } else {
            locationDF = sqlBuilder.selectProductCatalogTransactionsForVrbo(sqlc)
        }

        // extract geocode from locationDF
        val newLocationDF = locationDF.withColumn(SQLColumnHelper.PRODUCT_CATALOG_TAX_AREA_ID, DataUtil.getValidGeocodeFromProductCatalog(col(SQLColumnHelper.PRODUCT_CATALOG_ATTRIBUTES)))

        val start = System.currentTimeMillis()
        logger.info("start time left join in transformLodgingAddress: " + start)
        val transformedDF = getUpdatedLocationLodging(sqlc, bookingTransDF, newLocationDF)
        logger.info("end time left join in transformLodgingAddress: " + (System.currentTimeMillis() - start))
        transformedDF
    }

    protected def transformLXAddress(sqlc: SparkSession, bookingTransDF: DataFrame): DataFrame = {

        val start = System.currentTimeMillis()
        logger.info("start time left join in transformLXAddress: " + start)
        val transformedDF = getUpdatedLocationLX(sqlc, bookingTransDF)
        logger.info("end time left join in transformLXAddress: " + (System.currentTimeMillis() - start))
        transformedDF
    }

    private def getUpdatedLocation(sqlc: SparkSession, bookingDF: DataFrame, locationDF: DataFrame) = {
        var updatedDF = bookingDF.alias("updatedDF").toDF()
        var hotwireDF: DataFrame = null

        if (hotwireCarsEnabled) {
            hotwireDF = bookingDF.filter(((bookingDF(SQLColumnHelper.LEGAL_ENTITY_CODE) === SQLColumnHelper.HOTWIRE_LEGAL_ENTITY_CODE) ||
                (bookingDF(SQLColumnHelper.BUSINESS_MODEL_SUBTYPE_NAME) === SQLColumnHelper.OPAQUE_MERCHANT)) ||
                (bookingDF(SQLColumnHelper.LEGAL_ENTITY_CODE).equalTo(lit(SQLColumnHelper.EXPEDIA_LEGAL_ENTITY_CODE)) &&
                    bookingDF(SQLColumnHelper.BUSINESS_MODEL_NAME).equalTo(lit(SQLColumnHelper.AGENCY)) &&
                    bookingDF(SQLColumnHelper.BUSINESS_MODEL_SUBTYPE_NAME).equalTo(lit(SQLColumnHelper.AGENCY)) &&
                    bookingDF(SQLColumnHelper.MANAGEMENT_UNIT_NAME).equalTo(lit(SQLColumnHelper.HOTWIRE)) &&
                    bookingDF(SQLColumnHelper.MANAGEMENT_UNIT_LEVEL_6_NAME).equalTo(lit(SQLColumnHelper.HOTWIRE))))
            logger.info("No of transactions for HW Car: " + hotwireDF.count())
            // Renaming the columns to tackle "Missing attributes(s)" error. Refer func definition for more details.
            hotwireDF = DataUtil.renameColumns(hotwireDF)
            updatedDF = bookingDF.exceptAll(hotwireDF).toDF()
            hotwireDF = hotwireDF.withColumn(
                "car_location_id_vendor_code",
                regexp_replace(concat(col(SQLColumnHelper.CAR_LOCATION_ID), lit("-"), col(SQLColumnHelper.CAR_VENDOR_CODE)), "\\s+", "")
            )
        }

        sqlc.conf.set("spark.sql.crossJoin.enabled", "true")
        updatedDF = updatedDF.join(
            locationDF
            , updatedDF(SQLColumnHelper.CAR_LOCATION_ID) === locationDF(SQLColumnHelper.PRODUCT_CATALOG_SUPPLIER_ID)
            , "left")

        if (hotwireCarsEnabled) {
            hotwireDF = hotwireDF.join(
                locationDF
                , hotwireDF("car_location_id_vendor_code") === locationDF(SQLColumnHelper.PRODUCT_CATALOG_SUPPLIER_ID)
                , "left").drop("car_location_id_vendor_code")
            updatedDF = updatedDF.union(hotwireDF)
        }

        // initially populate everything with cleansed address
        updatedDF = updatedDF.withColumn(SQLColumnHelper.CAR_TAX_AREA_ID, col(SQLColumnHelper.PRODUCT_CATALOG_TAX_AREA_ID))
            .withColumn(SQLColumnHelper.CAR_PICK_UP_LOCATION_STATE_PROVINCE_NAME, col(SQLColumnHelper.CLEANSED_STATE))
            .withColumn(SQLColumnHelper.CAR_PICK_UP_LOCATION_CITY_NAME, col(SQLColumnHelper.CLEANSED_CITY))
            .withColumn(SQLColumnHelper.CAR_PICK_UP_LOCATION_COUNTRY_CODE, col(SQLColumnHelper.CLEANSED_COUNTRY_CODE))
            .withColumn(SQLColumnHelper.CAR_PICK_UP_LOCATION_STREET_ADDRESS1, col(SQLColumnHelper.CLEANSED_STREET_ADDRESS1))
            .withColumn(SQLColumnHelper.CAR_PICK_UP_LOCATION_STREET_ADDRESS2, col(SQLColumnHelper.CLEANSED_STREET_ADDRESS2))
            .withColumn(SQLColumnHelper.CAR_PICK_UP_LOCATION_POSTAL_CODE, col(SQLColumnHelper.CLEANSED_POSTAL_CODE))
            .withColumn(SQLColumnHelper.CAR_PICK_UP_LOCATION_LATITUDE, when(col(SQLColumnHelper.CLEANSED_LATITUDE).isNull, col(SQLColumnHelper.PRODUCT_CATALOG_LATITUDE)).otherwise(col(SQLColumnHelper.CLEANSED_LATITUDE)))
            .withColumn(SQLColumnHelper.CAR_PICK_UP_LOCATION_LONGITUDE, when(col(SQLColumnHelper.CLEANSED_LONGITUDE).isNull, col(SQLColumnHelper.PRODUCT_CATALOG_LONGITUDE)).otherwise(col(SQLColumnHelper.CLEANSED_LONGITUDE)))


        // filter out uncleansed address rows
        var uncleansed = filterAddressTransaction(updatedDF, false)

        // cleansed row = total - uncleansed rows
        val cleansed = filterAddressTransaction(updatedDF, true)

        // update uncleansed rows with non-cleansed address present.
        uncleansed = uncleansed.withColumn(SQLColumnHelper.CAR_PICK_UP_LOCATION_STATE_PROVINCE_NAME, col(SQLColumnHelper.PRODUCT_CATALOG_STATE))
            .withColumn(SQLColumnHelper.CAR_PICK_UP_LOCATION_CITY_NAME, col(SQLColumnHelper.PRODUCT_CATALOG_CITY))
            .withColumn(SQLColumnHelper.CAR_PICK_UP_LOCATION_STREET_ADDRESS1, col(SQLColumnHelper.PRODUCT_CATALOG_STREET_ADDRESS1))
            .withColumn(SQLColumnHelper.CAR_PICK_UP_LOCATION_STREET_ADDRESS2, col(SQLColumnHelper.PRODUCT_CATALOG_STREET_ADDRESS2))
            .withColumn(SQLColumnHelper.CAR_PICK_UP_LOCATION_POSTAL_CODE, col(SQLColumnHelper.PRODUCT_CATALOG_POSTAL_CODE))
            .withColumn(SQLColumnHelper.CAR_PICK_UP_LOCATION_COUNTRY_CODE, col(SQLColumnHelper.PRODUCT_CATALOG_COUNTRY_CODE))

        updatedDF = uncleansed.union(cleansed)
            .drop(SQLColumnHelper.PRODUCT_CATALOG_TAX_AREA_ID)
            .drop(SQLColumnHelper.CLEANSED_STATE)
            .drop(SQLColumnHelper.CLEANSED_CITY)
            .drop(SQLColumnHelper.CLEANSED_STREET_ADDRESS1)
            .drop(SQLColumnHelper.CLEANSED_STREET_ADDRESS2)
            .drop(SQLColumnHelper.CLEANSED_POSTAL_CODE)
            .drop(SQLColumnHelper.CLEANSED_COUNTRY_CODE)
            .drop(SQLColumnHelper.PRODUCT_CATALOG_SUPPLIER_ID)
            .drop(SQLColumnHelper.PRODUCT_CATALOG_STATE)
            .drop(SQLColumnHelper.PRODUCT_CATALOG_CITY)
            .drop(SQLColumnHelper.PRODUCT_CATALOG_STREET_ADDRESS1)
            .drop(SQLColumnHelper.PRODUCT_CATALOG_STREET_ADDRESS2)
            .drop(SQLColumnHelper.PRODUCT_CATALOG_POSTAL_CODE)
            .drop(SQLColumnHelper.PRODUCT_CATALOG_COUNTRY_CODE)
            .drop(SQLColumnHelper.PRODUCT_CATALOG_LATITUDE)
            .drop(SQLColumnHelper.PRODUCT_CATALOG_LONGITUDE)
            .drop(SQLColumnHelper.CLEANSED_LATITUDE)
            .drop(SQLColumnHelper.CLEANSED_LONGITUDE)
            .drop(SQLColumnHelper.CAR_VENDOR_CODE)

        updatedDF = updatedDF.persist(StorageLevel.MEMORY_AND_DISK)
        logger.info("No of transactions after getUpdatedLocation call: " + updatedDF.count())

        updatedDF
    }

    private def getUpdatedLocationLodging(sqlc: SparkSession, bookingDF: DataFrame, locationDF: DataFrame) = {
        //var hotwireDF = bookingDF.filter(bookingDF(SQLColumnHelper.LEGAL_ENTITY_CODE) === SQLColumnHelper.HOTWIRE_LEGAL_ENTITY_CODE)

        // Renaming the columns to tackle "Missing attributes(s)" error. Refer func definition for more details.
        //hotwireDF = DataUtil.renameColumns(hotwireDF)

        //var updatedDF = bookingDF.exceptAll(hotwireDF).toDF()
        var updatedDF = bookingDF
        sqlc.conf.set("spark.sql.crossJoin.enabled", "true")
        updatedDF = updatedDF.join(
            locationDF
            , bookingDF(SQLColumnHelper.PROPERTY_ID) === locationDF(SQLColumnHelper.PRODUCT_CATALOG_SUPPLIER_ID)
            , "left")

        // initially populate everything with cleansed address
        updatedDF = updatedDF.withColumn(SQLColumnHelper.TAX_AREA_ID, col(SQLColumnHelper.PRODUCT_CATALOG_TAX_AREA_ID))
            .withColumn(SQLColumnHelper.PROPERTY_NAME, col(SQLColumnHelper.PRODUCT_CATALOG_SUPPLIER_NAME))
            .withColumn(SQLColumnHelper.STATE, col(SQLColumnHelper.CLEANSED_STATE))
            .withColumn(SQLColumnHelper.PROPERTY_CITY_NAME, col(SQLColumnHelper.CLEANSED_CITY))
            .withColumn(SQLColumnHelper.PROPERTY_COUNTRY_CODE, col(SQLColumnHelper.CLEANSED_COUNTRY_CODE))
            .withColumn(SQLColumnHelper.STREET_ADDRESS1, col(SQLColumnHelper.CLEANSED_STREET_ADDRESS1))
            .withColumn(SQLColumnHelper.STREET_ADDRESS2, col(SQLColumnHelper.CLEANSED_STREET_ADDRESS2))
            .withColumn(SQLColumnHelper.PROPERTY_POSTAL_CODE, col(SQLColumnHelper.CLEANSED_POSTAL_CODE))
            .withColumn(SQLColumnHelper.PROPERTY_LATITUDE, when(col(SQLColumnHelper.CLEANSED_LATITUDE).isNull, col(SQLColumnHelper.PRODUCT_CATALOG_LATITUDE)).otherwise(col(SQLColumnHelper.CLEANSED_LATITUDE)))
            .withColumn(SQLColumnHelper.PROPERTY_LONGITUDE, when(col(SQLColumnHelper.CLEANSED_LONGITUDE).isNull, col(SQLColumnHelper.PRODUCT_CATALOG_LONGITUDE)).otherwise(col(SQLColumnHelper.CLEANSED_LONGITUDE)))
            .withColumn(SQLColumnHelper.NON_CLEANSED_COUNTRY_CODE, col(SQLColumnHelper.PRODUCT_CATALOG_COUNTRY_CODE)) // Specific for STAC

        // filter out uncleansed address rows
        var uncleansed = filterAddressTransactionLodging(updatedDF, false)

        // cleansed row = total - uncleansed rows
        val cleansed = filterAddressTransactionLodging(updatedDF, true)

        // update uncleansed rows with non-cleansed address present.
        uncleansed = uncleansed.withColumn(SQLColumnHelper.STATE, col(SQLColumnHelper.PRODUCT_CATALOG_STATE))
            .withColumn(SQLColumnHelper.PROPERTY_CITY_NAME, col(SQLColumnHelper.PRODUCT_CATALOG_CITY))
            .withColumn(SQLColumnHelper.STREET_ADDRESS1, col(SQLColumnHelper.PRODUCT_CATALOG_STREET_ADDRESS1))
            .withColumn(SQLColumnHelper.STREET_ADDRESS2, col(SQLColumnHelper.PRODUCT_CATALOG_STREET_ADDRESS2))
            .withColumn(SQLColumnHelper.PROPERTY_POSTAL_CODE, col(SQLColumnHelper.PRODUCT_CATALOG_POSTAL_CODE))
            .withColumn(SQLColumnHelper.PROPERTY_COUNTRY_CODE, col(SQLColumnHelper.PRODUCT_CATALOG_COUNTRY_CODE))

        updatedDF = uncleansed.union(cleansed)
            .drop(SQLColumnHelper.PRODUCT_CATALOG_TAX_AREA_ID)
            .drop(SQLColumnHelper.PRODUCT_CATALOG_SUPPLIER_NAME)
            .drop(SQLColumnHelper.CLEANSED_STATE)
            .drop(SQLColumnHelper.CLEANSED_CITY)
            .drop(SQLColumnHelper.CLEANSED_STREET_ADDRESS1)
            .drop(SQLColumnHelper.CLEANSED_STREET_ADDRESS2)
            .drop(SQLColumnHelper.CLEANSED_POSTAL_CODE)
            .drop(SQLColumnHelper.CLEANSED_COUNTRY_CODE)
            .drop(SQLColumnHelper.PRODUCT_CATALOG_SUPPLIER_ID)
            .drop(SQLColumnHelper.PRODUCT_CATALOG_COUNTRY_CODE)
            .drop(SQLColumnHelper.CLEANSED_LONGITUDE)
            .drop(SQLColumnHelper.CLEANSED_LATITUDE)
            .drop(SQLColumnHelper.PRODUCT_CATALOG_LATITUDE)
            .drop(SQLColumnHelper.PRODUCT_CATALOG_LONGITUDE)
            .drop(SQLColumnHelper.PRODUCT_CATALOG_POSTAL_CODE)
            .drop(SQLColumnHelper.PRODUCT_CATALOG_STATE)
            .drop(SQLColumnHelper.PRODUCT_CATALOG_CITY)
            .drop(SQLColumnHelper.PRODUCT_CATALOG_STREET_ADDRESS1)
            .drop(SQLColumnHelper.PRODUCT_CATALOG_STREET_ADDRESS2)

        //updatedDF = updatedDF.union(hotwireDF)

        updatedDF
    }

    private def getUpdatedLocationLX(sqlc: SparkSession, bookingDF: DataFrame) = {
        var updatedDF = bookingDF
        sqlc.conf.set("spark.sql.crossJoin.enabled", "true")

        updatedDF = updatedDF.withColumn(SQLColumnHelper.TAX_AREA_ID, col(SQLColumnHelper.PC_TAX_AREA_ID))
            .withColumn(SQLColumnHelper.PARTNER_CITY, when(col(SQLColumnHelper.PC_CLEANSED_CITY).isNull, col(SQLColumnHelper.PC_CITY)).otherwise(col(SQLColumnHelper.PC_CLEANSED_CITY)))
            .withColumn(SQLColumnHelper.PARTNER_STATE, when(col(SQLColumnHelper.PC_CLEANSED_STATE).isNull, col(SQLColumnHelper.PC_STATE)).otherwise(col(SQLColumnHelper.PC_CLEANSED_STATE)))
            .withColumn(SQLColumnHelper.PARTNER_COUNTRY_CODE, when(col(SQLColumnHelper.PC_CLEANSED_COUNTRY_CODE).isNull, col(SQLColumnHelper.PC_COUNTRY_CODE)).otherwise(col(SQLColumnHelper.PC_CLEANSED_COUNTRY_CODE)))
            .withColumn(SQLColumnHelper.PARTNER_ADDRESS_LINE_1, when(col(SQLColumnHelper.PC_CLEANSED_STREET_ADDRESS_1).isNull, col(SQLColumnHelper.PC_STREET_ADDRESS_1)).otherwise(col(SQLColumnHelper.PC_CLEANSED_STREET_ADDRESS_1)))
            .withColumn(SQLColumnHelper.PARTNER_ADDRESS_LINE_2, when(col(SQLColumnHelper.PC_CLEANSED_STREET_ADDRESS_2).isNull, col(SQLColumnHelper.PC_STREET_ADDRESS_2)).otherwise(col(SQLColumnHelper.PC_CLEANSED_STREET_ADDRESS_2)))
            .withColumn(SQLColumnHelper.PARTNER_POSTAL_CODE, when(col(SQLColumnHelper.PC_CLEANSED_POSTAL_CODE).isNull, col(SQLColumnHelper.PC_POSTAL_CODE)).otherwise(col(SQLColumnHelper.PC_CLEANSED_POSTAL_CODE)))
            .withColumn(SQLColumnHelper.PARTNER_LATITUDE, when(col(SQLColumnHelper.PC_CLEANSED_LATITUDE).isNull, col(SQLColumnHelper.PC_LATITUDE)).otherwise(col(SQLColumnHelper.PC_CLEANSED_LATITUDE)))
            .withColumn(SQLColumnHelper.PARTNER_LONGITUDE, when(col(SQLColumnHelper.PC_CLEANSED_LONGITUDE).isNull, col(SQLColumnHelper.PC_LONGITUDE)).otherwise(col(SQLColumnHelper.PC_CLEANSED_LONGITUDE)))

        updatedDF = updatedDF
            .drop(SQLColumnHelper.PC_TAX_AREA_ID)
            .drop(SQLColumnHelper.PC_CLEANSED_CITY)
            .drop(SQLColumnHelper.PC_CITY)
            .drop(SQLColumnHelper.PC_CLEANSED_STATE)
            .drop(SQLColumnHelper.PC_STATE)
            .drop(SQLColumnHelper.PC_CLEANSED_COUNTRY_CODE)
            .drop(SQLColumnHelper.PC_COUNTRY_CODE)
            .drop(SQLColumnHelper.PC_CLEANSED_STREET_ADDRESS_1)
            .drop(SQLColumnHelper.PC_STREET_ADDRESS_1)
            .drop(SQLColumnHelper.PC_CLEANSED_STREET_ADDRESS_2)
            .drop(SQLColumnHelper.PC_STREET_ADDRESS_2)
            .drop(SQLColumnHelper.PC_CLEANSED_POSTAL_CODE)
            .drop(SQLColumnHelper.PC_POSTAL_CODE)
            .drop(SQLColumnHelper.PC_CLEANSED_LATITUDE)
            .drop(SQLColumnHelper.PC_LATITUDE)
            .drop(SQLColumnHelper.PC_CLEANSED_LONGITUDE)
            .drop(SQLColumnHelper.PC_LONGITUDE)
            .drop(SQLColumnHelper.PC_PUBLISHED_TIMESTAMP)

        updatedDF
    }

    /**
     * Get filtered transactions where cleansed address fields are null.
     *
     * @param updatedDF
     * @return
     */
    private def filterAddressTransaction(updatedDF: DataFrame, cleansed: Boolean): DataFrame = {
        val condition = (col(SQLColumnHelper.CAR_PICK_UP_LOCATION_POSTAL_CODE).isNull ||
            col(SQLColumnHelper.CAR_PICK_UP_LOCATION_COUNTRY_CODE).isNull ||
            col(SQLColumnHelper.CAR_PICK_UP_LOCATION_CITY_NAME).isNull ||
            col(SQLColumnHelper.CAR_PICK_UP_LOCATION_STATE_PROVINCE_NAME).isNull ||
            col(SQLColumnHelper.CAR_PICK_UP_LOCATION_STREET_ADDRESS1).isNull)

        if (cleansed) updatedDF.filter(!condition) else updatedDF.filter(condition)
    }

    private def filterAddressTransactionLodging(updatedDF: DataFrame, cleansed: Boolean): DataFrame = {
        val condition = (col(SQLColumnHelper.PROPERTY_POSTAL_CODE).isNull ||
            col(SQLColumnHelper.PROPERTY_COUNTRY_CODE).isNull ||
            col(SQLColumnHelper.PROPERTY_CITY_NAME).isNull ||
            col(SQLColumnHelper.STATE).isNull ||
            col(SQLColumnHelper.STREET_ADDRESS1).isNull)

        if (cleansed) updatedDF.filter(!condition) else updatedDF.filter(condition)
    }

    def applyBaseModelerRules(convertedAmountsDf: DataFrame, sqlc: SparkSession): DataFrame = {
        val priceColumnCopy = "pre_tax_engine_price_amount_copy"
        val costColumnCopy = "pre_tax_engine_cost_amount_copy"
        val marginColumnCopy = "pre_tax_engine_margin_amount_copy"
        val taxBaseOptionAOrCDF = convertedAmountsDf
            .where(col(SQLColumnHelper.TAX_BASE_OPTION) !== SQLColumnHelper.TAX_BASE_OPTION_B)
            // Reorder the columns to have the pre tax engine price, cost and margin at the end
            .withColumn(priceColumnCopy, col(SQLColumnHelper.PRE_TAX_ENGINE_PRICE_AMOUNT).cast(DecimalType(18, 2)))
            .withColumn(costColumnCopy, col(SQLColumnHelper.PRE_TAX_ENGINE_COST_AMOUNT).cast(DecimalType(18, 2)))
            .withColumn(marginColumnCopy, col(SQLColumnHelper.PRE_TAX_ENGINE_MARGIN_AMOUNT).cast(DecimalType(18, 2)))
            .drop(SQLColumnHelper.PRE_TAX_ENGINE_PRICE_AMOUNT, SQLColumnHelper.PRE_TAX_ENGINE_COST_AMOUNT,
                SQLColumnHelper.PRE_TAX_ENGINE_MARGIN_AMOUNT)
            .withColumnRenamed(priceColumnCopy, SQLColumnHelper.PRE_TAX_ENGINE_PRICE_AMOUNT)
            .withColumnRenamed(costColumnCopy, SQLColumnHelper.PRE_TAX_ENGINE_COST_AMOUNT)
            .withColumnRenamed(marginColumnCopy, SQLColumnHelper.PRE_TAX_ENGINE_MARGIN_AMOUNT)

        val taxBaseOptionBDF = convertedAmountsDf
            .where(col(SQLColumnHelper.TAX_BASE_OPTION) === SQLColumnHelper.TAX_BASE_OPTION_B)
            .drop(SQLColumnHelper.PRE_TAX_ENGINE_PRICE_AMOUNT, SQLColumnHelper.PRE_TAX_ENGINE_COST_AMOUNT,
                SQLColumnHelper.PRE_TAX_ENGINE_MARGIN_AMOUNT)

        logger.info(s"Applying ${RuleType.RULE_TYPE_TAX_BASE_MODELER} rules...")
        val convertedAmountsDfWithTaxBaseAttr = if (useConfigRuleCacheFeature) {
            configurationRunner.configRuleCache._2.flatMap(parent =>
                parent._2.filter(_.getRuleType.equals(RuleType.RULE_TYPE_TAX_BASE_MODELER))
                    .map(rule => s"Parent ID ${parent._1} - Rule ${rule.getRuleId}/${rule.getRank}").toSet
            )
            TaxBaseModeler.deriveTaxBaseAttributes(taxBaseOptionBDF, sqlc, configurationRunner.configRuleCache)
        } else {
            val taxEngineConfigRules = configRuleFilter.filterRules(RuleType.RULE_TYPE_TAX_BASE_MODELER)
            taxEngineConfigRules.foreach(rule => logger.info(rule.toString))
            TaxBaseModeler.deriveTaxBaseAttributes(taxBaseOptionBDF, sqlc, null, taxEngineConfigRules)
        }

        convertedAmountsDfWithTaxBaseAttr.union(taxBaseOptionAOrCDF)
    }

    private def applyCurrencyConfigRules(qualifiedTransactionDf: DataFrame, sqlc: SparkSession): DataFrame = {
        logger.info(s"Applying ${RuleType.RULE_TYPE_CURRENCY_CONFIG} rules...")
        if (useConfigRuleCacheFeature) {
            configurationRunner.configRuleCache._2.flatMap(parent =>
                parent._2.filter(_.getRuleType.equals(RuleType.RULE_TYPE_CURRENCY_CONFIG))
                    .map(rule => s"Parent ID ${parent._1} - Rule ${rule.getRuleId}/${rule.getRank}").toSet
            ).toList.sorted.foreach(logger.info(_))
            AmountConverter.deriveFilingCurrnByMappingConfigRules(
                qualifiedTransactionDf, sqlc, configurationRunner.configRuleCache)
        } else {
            val taxEngineConfigRules = configRuleFilter.filterRules(RuleType.RULE_TYPE_CURRENCY_CONFIG)
            taxEngineConfigRules.foreach(rule => logger.info(rule.toString))
            AmountConverter.deriveFilingCurrnByMappingConfigRules(
                qualifiedTransactionDf, sqlc, null, taxEngineConfigRules)
        }
    }

    private def joinQualifiedTransDfWithConvertedAmountsDf(qualifiedTransactionDfWithExchRate: DataFrame,
                                                           convertedAmountsDf: DataFrame): DataFrame = {
        val columnNames = Seq(SQLColumnHelper.BOOKING_ITEM_ID, SQLColumnHelper.TRANSACTION_TYPE_KEY,
            SQLColumnHelper.BOOKING_EVENT_DATETIME, SQLColumnHelper.SOURCE_SYSTEM_ID,
            SQLColumnHelper.BOOKING_ID, SQLColumnHelper.COST_CURRENCY_CODE,
            SQLColumnHelper.STAY_DATE)
        var joinedConvertedAmountsDf = qualifiedTransactionDfWithExchRate.join(convertedAmountsDf,
            columnNames, "left")
        joinedConvertedAmountsDf
    }

    private def joinExchangeRateWithFilingCurrency(sqlc: SparkSession, qualifiedTransactionDf: DataFrame, productLineName: String): DataFrame = {
        import sqlc.implicits._
        val filterCondition = qualifiedTransactionDf.select(SQLColumnHelper.FILING_CURRENCY_CODE)
            .distinct().where(col(SQLColumnHelper.FILING_CURRENCY_CODE).notEqual(SQLColumnHelper.NOT_AVAILABLE)).map(f => f.getString(0)).collectAsList

        val exchangeRateDataFrame = getAllExchangeRateData(sqlc, filterCondition.mkString("'", "', '", "'"))
        val start = System.currentTimeMillis()
        logger.info("start time join with FXRS: " + start)

        var qualifiedTransactionDfWithExchRate = sqlc.emptyDataFrame
        if (PRODUCT_LINE_NAME_VRBO.equalsIgnoreCase(productLineName)) {
            val updatedQualifiedTransactionDf = qualifiedTransactionDf
                .withColumn(SQLColumnHelper.BOOK_DATE,
                    when(
                        col(SQLColumnHelper.TRANSACTION_LIABILITY_DATE_TYPE) === "bookingEventDate" && col(SQLColumnHelper.BOOK_DATE).isNull && col(SQLColumnHelper.BOOKING_HISTORY).isNotNull,
                        getInitialBookingDateUdf(col(SQLColumnHelper.BOOKING_HISTORY))
                    ).when(
                        col(SQLColumnHelper.TRANSACTION_LIABILITY_DATE_TYPE) === "bookingEventDate" && col(SQLColumnHelper.BOOK_DATE).isNull && col(SQLColumnHelper.BOOKING_HISTORY).isNull,
                        col(SQLColumnHelper.BOOKING_EVENT_DATE)
                    ).otherwise(col(SQLColumnHelper.BOOK_DATE))
                )
                .withColumn(SQLColumnHelper.PRICE_CURRENCY_CODE,
                    when(col(SQLColumnHelper.BOOKING_HISTORY).isNotNull && col(SQLColumnHelper.BOOK_DATE).isNull,
                        getUpdatedPriceCurrencyCodeUdf(col(SQLColumnHelper.BOOKING_HISTORY), col(SQLColumnHelper.PRICE_CURRENCY_CODE))
                    ).otherwise(col(SQLColumnHelper.PRICE_CURRENCY_CODE))
                )

            val updatedTransactionDF = updatedQualifiedTransactionDf.drop(SQLColumnHelper.BOOKING_HISTORY_EVENT)
            // Book Date Cancel handling - converting local amounts from staged booking history
            qualifiedTransactionDfWithExchRate = updatedTransactionDF.join(
                // Changes on Join Condition, if it is giving issues, please return the value of SQLColumnHelper.TRANSACTION_LIABILITY_DATE to "stay_date"
                // Also UTs will fail, need a modification after that
                exchangeRateDataFrame.alias("e1").withColumnRenamed("exch_rate", "exch_rate_stay_date"),
                when(col(SQLColumnHelper.TRANSACTION_LIABILITY_DATE_TYPE) === "bookingEventDate", col(SQLColumnHelper.BOOK_DATE) === col("e1.exch_rate_date"))
                    .otherwise(col(SQLColumnHelper.TRANSACTION_LIABILITY_DATE) === col("e1.exch_rate_date"))
                    && col(SQLColumnHelper.PRICE_CURRENCY_CODE) === col("e1.from_currn_code"),
                "left")
            // Book Date Cancel handling - converting local amounts from staged booking history
            qualifiedTransactionDfWithExchRate = AmountConverter.deriveHistoricConvertedAmountsVrbo(qualifiedTransactionDfWithExchRate, exchangeRateDataFrame)
        } else {
            qualifiedTransactionDfWithExchRate = qualifiedTransactionDf.join(
                exchangeRateDataFrame.alias("e1").withColumnRenamed("exch_rate", "exch_rate_book_date")
                , col("book_date") === col("e1.exch_rate_date")
                    && col("updated_price_currency_code") === col("e1.from_currn_code")
                , "left").join(
                exchangeRateDataFrame.alias("e2").withColumnRenamed("exch_rate", "exch_rate_stay_date")
                , col("stay_date") === col("e2.exch_rate_date")
                    && col("updated_price_currency_code") === col("e2.from_currn_code")
                , "left").join(
                exchangeRateDataFrame.alias("e3").withColumnRenamed("exch_rate", "exch_rate_stay_date_cost")
                , col("stay_date") === col("e3.exch_rate_date")
                    && col("updated_cost_currency_code") === col("e3.from_currn_code")
                , "left")
        }

        qualifiedTransactionDfWithExchRate = qualifiedTransactionDfWithExchRate.persist(StorageLevel.MEMORY_AND_DISK)
        logger.info("end time join with FXRS:" + (System.currentTimeMillis() - start))
        if (PRODUCT_LINE_NAME_VRBO.equalsIgnoreCase(productLineName)) {
            qualifiedTransactionDfWithExchRate = AmountConverter.deriveLocalAmountsConvertedVrbo(qualifiedTransactionDfWithExchRate, exchangeRateDataFrame)
            qualifiedTransactionDfWithExchRate = qualifiedTransactionDfWithExchRate
                .withColumn("exch_rate_stay_date", round(col("exch_rate_stay_date"), 6))
        } else {
            qualifiedTransactionDfWithExchRate = qualifiedTransactionDfWithExchRate
                .withColumn("exch_rate_book_date", round(col("exch_rate_book_date"), 6))
                .withColumn("exch_rate_stay_date", round(col("exch_rate_stay_date"), 6))
                .withColumn("exch_rate_stay_date_cost", round(col("exch_rate_stay_date_cost"), 6))
        }
        return qualifiedTransactionDfWithExchRate
    }

    val getInitialBookingDateUdf = udf((bookingHistory: Seq[Row]) => {
        bookingHistory
            .filter(row => row.getAs[String]("event_type") == "INITIAL_BOOKING")
            .map(row => row.getAs[String]("booking_event_date"))
            .headOption
            .orNull
    })

    val getUpdatedPriceCurrencyCodeUdf = udf((bookingHistory: Seq[Row], priceCurrencyCode: String) => {
        val localAmounts = bookingHistory
            .filter(row => row.getAs[String]("event_type") == "INITIAL_BOOKING")
            .map(row => row.getAs[Seq[GenericRowWithSchema]]("local_amounts"))
            .headOption
            .orNull
        if (localAmounts == null || localAmounts.isEmpty) {
            priceCurrencyCode
        } else {
            val currency = localAmounts
                .map(_.getAs[GenericRowWithSchema](SQLColumnHelper.MONEY))
                .filter(_ != null)
                .find(money => {
                    val currency = money.getAs[String](SQLColumnHelper.CURRENCY_COD)
                    currency != null && currency.nonEmpty && !currency.equals("Unknown")
                })
                .map(_.getAs[String](SQLColumnHelper.CURRENCY_COD))
                .getOrElse("Unknown")
            if (currency != null && currency.nonEmpty && !currency.equals("Unknown"))
                currency else priceCurrencyCode
        }
    })
    def getManualTransactionsDF(spark: SparkSession, filterCriteria: String, productLineName: String,
                                isPostStay: Boolean = false): DataFrame = {
        logger.info(s"Get manual transactions from $manualTransactions")

        val manualTransactionsDF = sqlBuilder.getManualTransactions(spark, filterCriteria, productLineName, isPostStay)
        manualTransactionsDF
    }

    def doAutoAndManualTransactionsUnion(autoTransactionsDF: DataFrame, manualTransactionsDF: DataFrame): DataFrame = {
        var autoTransactionsWithManualFieldsDF: DataFrame = autoTransactionsDF

        autoTransactionsWithManualFieldsDF = autoTransactionsWithManualFieldsDF
            .withColumn(SQLColumnHelper.EVENT_SOURCE_SYSTEM_NAME, lit(SQLColumnHelper.GTP_LEGACY))
            .withColumn(SQLColumnHelper.TAX_BASE_OPTION, lit(SQLColumnHelper.TAX_BASE_OPTION_B))
            .withColumn(SQLColumnHelper.PRE_TAX_ENGINE_PRICE_AMOUNT, lit(null))
            .withColumn(SQLColumnHelper.PRE_TAX_ENGINE_COST_AMOUNT, lit(null))
            .withColumn(SQLColumnHelper.PRE_TAX_ENGINE_MARGIN_AMOUNT, lit(null))
            .withColumn(SQLColumnHelper.ORACLE_GL_PRODUCT_CODE, lit(null))

        autoTransactionsWithManualFieldsDF.union(manualTransactionsDF)
    }

    def addTaxProfileAttributes(spark: SparkSession, qualifiedTransactionsDF: DataFrame): DataFrame = {
        val qualifiedTransactionsView = "qualified_transactions_view"
        qualifiedTransactionsDF.createOrReplaceTempView(qualifiedTransactionsView)
        val transWithTaxProfileAttributes = sqlBuilder.getTransWithTaxProfileAttributeColumns(spark,
            qualifiedTransactionsView)
        transWithTaxProfileAttributes.withColumn(SQLColumnHelper.TAX_PROFILE_ATTRIBUTES,
            DataUtil.createTaxProfileAttributesUdf(
                col(SQLColumnHelper.TRANSACTION_LIABILITY_DATE),
                col(SQLColumnHelper.TAX_DEFINED_ATTRIBUTES_ACCURACY),
                col(SQLColumnHelper.TAX_DEFINED_ATTRIBUTES_FILING),
                col(SQLColumnHelper.SUPPLIER_ATTRIBUTES_ACCURACY),
                col(SQLColumnHelper.SUPPLIER_ATTRIBUTES_FILING)))
    }

    def addPartnerAttributes(transWithTaxProfileAttributes: DataFrame): DataFrame = {
        val partnerAttributesTemp = "partner_attributes_temp"
        transWithTaxProfileAttributes
            .withColumn(partnerAttributesTemp, map(
                lit(SQLColumnHelper.PROPERTY_LONGITUDE),
                col(SQLColumnHelper.PROPERTY_LONGITUDE),
                lit(SQLColumnHelper.PROPERTY_LATITUDE),
                col(SQLColumnHelper.PROPERTY_LATITUDE),
                lit(SQLColumnHelper.PROPERTY_TYPE_NAME),
                lit(null),
                lit(SQLColumnHelper.TAX_AREA_ID),
                col(SQLColumnHelper.TAX_AREA_ID)
            ))
            .withColumn(SQLColumnHelper.PARTNER_ATTRIBUTES, map_concat(
                col(partnerAttributesTemp),
                col(SQLColumnHelper.TAX_PROFILE_ATTRIBUTES)
            ))
            .drop(partnerAttributesTemp)
            .drop(SQLColumnHelper.TAX_PROFILE_ATTRIBUTES)
            .drop(SQLColumnHelper.TAX_DEFINED_ATTRIBUTES_ACCURACY)
            .drop(SQLColumnHelper.TAX_DEFINED_ATTRIBUTES_FILING)
            .drop(SQLColumnHelper.SUPPLIER_ATTRIBUTES_ACCURACY)
            .drop(SQLColumnHelper.SUPPLIER_ATTRIBUTES_FILING)
    }

    def setConfig(spark: SparkSession, preProcessorConfig: PreProcessorConfigCase, schemaConfig: TableSchemaConfigCase): Unit = {
        logger.info("AppName:{} RunID:{} start setting config information", Array(LoggingConstant.APP_NAME, MDC.get("uniqueID")): _*)
        this.preProcessorConfig = spark.sparkContext.broadcast(preProcessorConfig)
        this.tableSchemaConfig = spark.sparkContext.broadcast(schemaConfig)
        logger.info("AppName:{} RunID:{} finish setting config information", Array(LoggingConstant.APP_NAME, MDC.get("uniqueID")): _*)
    }

    case class JobInfoCase(
                              run_id: String,
                              job_name: String,
                              start_date: String,
                              end_date: String,
                              published_timestamp: String
                          )

}
