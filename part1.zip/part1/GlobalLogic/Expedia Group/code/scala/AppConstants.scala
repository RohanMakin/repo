package com.expediagroup.platform.taxcompliance.constants

object AppConstants {

    val PIPELINE_TRIGGER_PRE_CHECK = "first_check"
    val PIPELINE_TRIGGER_POST_CHECK = "second_check"

    val TYPE_BYPASS_BOOLEAN_TRUE = "true"
    val TYPE_BYPASS_BOOLEAN_FALSE = "false"

    val TYPE_JOB_STATUS_FAILED = "Failed"
    val TYPE_JOB_STATUS_COMPLETED = "Succeeded"
    val TYPE_JOB_STATUS_RUNNING = "Running"

    val WORKFLOW_TYPE_NORMAL = "normal"
    val WORKFLOW_TYPE_CATCH_UP = "catch-up"

    val BOOKING_TRANSACTION_TABLE_CONFIG = "classpath:bookingTransactionTableConfig.json"
    val TARGET_TABLE_CONFIG = "classpath:targetTableConfig.json"

    val CHECK_IN_DATE_EVENT_TYPE = "CHECK_IN_DATE"

    val PRODUCT_LINE_NAME_LX = "Destination Services"
    val PRODUCT_LINE_NAME_CAR = "car"
    val PRODUCT_LINE_NAME_LODGING = "lodging"
    val PRODUCT_LINE_NAME_ADVERTISING = "advertising"
    val PRODUCT_LINE_NAME_DIGITAL_SERVICES = "digital services"
    val NEW_LINE = "\n"
    val PRODUCT_LINE_NAME_FRAUD_PREVENTION = "fraud prevention"
    val PRODUCT_LINE_NAME_INVOICE_SERVICES = "invoice services"
    val NON_TRAVEL_PRODUCT_LINES : Set[String] = Set(PRODUCT_LINE_NAME_ADVERTISING, PRODUCT_LINE_NAME_FRAUD_PREVENTION, PRODUCT_LINE_NAME_DIGITAL_SERVICES, PRODUCT_LINE_NAME_INVOICE_SERVICES)
    val PRODUCT_LINE_NAME_VRBO = "vacationrentals"

    val ERROR_MSG = "Parameters missing "
    val RESOURCE_SCRIPT_COMMON_PATH = "classpath:scripts/"

    val BEXG_PROD_DM ="bexg_prod_dm."
    val BEXG_TEST_DM ="bexg_test_dm."

    val GTP_PROD ="gtp-prod"

    val S3_DATA_BUCKET = "compliance-data.files.prod"

    val STAGED_BOOKING_TRANSACTIONS = "load_eg_tax_compliance_staged_booking_transactions"
    val STAGED_BOOKING_TRANSACTIONS_BACKFILL = "load_eg_tax_compliance_staged_booking_transactions_backfill"
    val POST_STAY_TRANSACTIONS = "load_eg_tax_compliance_post_stay_transactions"
    val POST_USE_TRANSACTIONS = "load_eg_tax_compliance_post_use_transactions"

    val STAGED_BOOKING_TRANSACTIONS_DATALAKE_LX = "/load_eg_tax_compliance_staged_booking_transactions_dataLake_lx.hql"
    val STAGED_BOOKING_TRANSACTIONS_POS_DIM_TD_LX = "/load_eg_tax_compliance_staged_booking_transactions_pos_dim_td_lx.hql"
    val STAGED_BOOKING_TRANSACTIONS_TD_LX = "/load_eg_tax_compliance_staged_booking_transactions_td_lx.hql"

    val POST_USE_TRANSACTIONS_DATALAKE_LX = "/load_eg_tax_compliance_post_use_transactions_dataLake_lx.hql"
    val POST_USE_TRANSACTIONS_POS_DIM_TD_LX = "/load_eg_tax_compliance_post_use_transactions_pos_dim_td_lx.hql"
    val POST_USE_TRANSACTIONS_STAGE_BOOKING_TD_LX = "/load_eg_tax_compliance_post_use_transactions_stage_booking_td_lx.hql"
    val POST_USE_TRANSACTIONS_PURCHASE_BOOKING_TD_LX = "/load_eg_tax_compliance_post_use_transactions_purchase_booking_td_lx.hql"

    val STAGED_BOOKING_TRANSACTIONS_BACKFILL_DATALAKE_LX = "/load_eg_tax_compliance_staged_booking_transactions_backfill_dataLake_lx.hql"
    val STAGED_BOOKING_TRANSACTIONS_BACKFILL_POS_DIM_TD_LX = "/load_eg_tax_compliance_staged_booking_transactions_backfill_pos_dim_td_lx.hql"
    val STAGED_BOOKING_TRANSACTIONS_BACKFILL_TD_LX = "/load_eg_tax_compliance_staged_booking_transactions_backfill_td_lx.hql"

    val STAGED_BOOKING_TRANSACTIONS_TD_CARS = "/load_eg_tax_compliance_staged_booking_transactions_td_cars.hql"
    val POST_USE_TRANSACTIONS_STAGED_BOOKING_TD_CARS = "/load_eg_tax_compliance_post_use_transactions_staged_bookings_td_cars.hql"
    val POST_USE_TRANSACTIONS_PURCHASE_BOOKING_TD_CARS = "/load_eg_tax_compliance_post_use_transactions_purchase_bookings_td_cars.hql"
    val POST_USE_TRANSACTIONS_STAGING_PURCHASE_BOOKING_TD_CARS = "/load_eg_tax_compliance_post_use_transactions_staging_purchase_bookings_td_cars.hql"
    val STAGED_BOOKING_TRANSACTIONS_BACKFILL_TD_CARS = "/load_eg_tax_compliance_staged_booking_transactions_backfill_td_cars.hql"


    val STAGED_BOOKING_TRANSACTIONS_TD_LODGING = "/load_eg_tax_compliance_staged_booking_transactions_td_lodging.hql"
    val POST_STAY_TRANSACTIONS_LODGING = "/load_eg_tax_compliance_post_stay_transactions_staged_bookings_td_lodging.hql"
    val POST_STAY_TRANSACTIONS_PURCHASE_LODGING = "/load_eg_tax_compliance_post_stay_transactions_purchase_booking_td_lodging.hql"
    val POST_USE_TRANSACTIONS_STAGING_PURCHASE_BOOKING_TD_LODGING = "/load_eg_tax_compliance_post_use_transactions_staging_purchase_bookings_td_lodging.hql"

    val STAGED_BOOKING_TRANSACTIONS_BACKFILL_TD_LODGING = "/load_eg_tax_compliance_staged_booking_transactions_backfill_td_lodging.hql"

    val TD_SYNC_STATUS_CHECKER_LX = "/td_sync_status_checker_lx.hql"
    val TD_SYNC_STATUS_CHECKER_CARS = "/td_sync_status_checker_cars.hql"
    val TD_SYNC_STATUS_CHECKER_LODGING = "/td_sync_status_checker_lodging.hql"
    val TD_SYNC_STATUS_CHECKER_DAILY_EXCH_RATE = "/td_sync_status_checker_daily_exch_rate.hql"

}
