package com.expediagroup.platform.taxcompliance.converter

import org.apache.spark.sql.types._
import org.apache.spark.sql.{SparkSession, functions}
import org.slf4j.LoggerFactory
import org.springframework.stereotype.Component

import java.util.Calendar

@Component("com.expediagroup.platform.taxcompliance.converter.CsvReaderHiveWriter")
class CsvReaderHiveWriter extends Serializable  {
    private val logger = LoggerFactory.getLogger(this.getClass)

    def writeCsvToHiveTable(sparkSession: SparkSession, csvFileName: String, csvFileLocation: String,
                            hiveFileLocation: String) : Unit = {
        logger.info("Start Processing:  csv filename: "+csvFileName+ " csv file location: "+csvFileLocation+
            " Hive file location: "+hiveFileLocation)

        var tableSchema: StructType = null

        if(csvFileName.equals("tax_compliance_eg_prepayments_info"))
            tableSchema = getPrepaymentsInfoTableSchema()
        else if(csvFileName.equals("tax_compliance_eg_filing_dimension"))
            tableSchema = getFilingDimensionTableSchema()
        else if(csvFileName.equals("tax_compliance_eg_filing_period_dimension"))
            tableSchema = getFilingPeriodDimensionTableSchema()
        else if(csvFileName.equals("tax_compliance_eg_taxareacode_dimension"))
            tableSchema = getTaxAreaCodeDimensionTableSchema()

        var df = sparkSession.read.format("csv")
            .option("delimiter", ",")
            .option("header", "true")
            .option("inferSchema", false)
            .schema(tableSchema)
            .load(csvFileLocation)
        if(csvFileName.equals("tax_compliance_eg_taxareacode_dimension")) {
            df = df.withColumn("last_updated_datetime", functions.lit(getCurrentDateTime()))
        }
        df.createOrReplaceTempView("tempTableView")

        val sqlQuery = sparkSession.sparkContext.textFile(hiveFileLocation).collect().mkString(" ")

        sqlQuery.split(";").foreach(row => {
            sparkSession.sql(row)
        })

        logger.info("End Processing: csv filename and updated table name: "+csvFileName )
    }

    private def getPrepaymentsInfoTableSchema(): StructType = {
        new StructType()
            .add(StructField("legal_entity_code", StringType, true))
            .add(StructField("legal_entity_name", StringType, true))
            .add(StructField("duration", StringType, true))
            .add(StructField("currency_code", StringType, true))
            .add(StructField("pre_payment_amount", DataTypes.createDecimalType(18, 4), true))
            .add(StructField("comments", StringType, true))
            .add(StructField("year", StringType, true))
            .add(StructField("jurisdiction_code", StringType, true))
    }

    private def getFilingDimensionTableSchema(): StructType = {
        new StructType()
            .add(StructField("return_type", StringType, true))
            .add(StructField("filing_jurisdiction", StringType, true))
            .add(StructField("filing_frequency", StringType, true))
            .add(StructField("is_active", BooleanType, true))
            .add(StructField("filing_entity_name", StringType, true))
            .add(StructField("filing_entity_code", StringType, true))
            .add(StructField("legal_entity_code", StringType, true))
            .add(StructField("state_province_name", StringType, true))
            .add(StructField("tax_category_code", IntegerType, true))
            .add(StructField("country_code", StringType, true))
            .add(StructField("state_province_code", StringType, true))
            .add(StructField("product_line_name", StringType, true))
    }

    private def getFilingPeriodDimensionTableSchema(): StructType = {
        new StructType()
            .add(StructField("period", StringType, true))
            .add(StructField("begin_period_month", IntegerType, true))
            .add(StructField("end_period_month", IntegerType, true))
            .add(StructField("country_code", StringType, true))
            .add(StructField("state_province_code", StringType, true))
    }

    private def getTaxAreaCodeDimensionTableSchema(): StructType = {
        new StructType()
            .add(StructField("tax_area_code", StringType, true))
            .add(StructField("description", StringType, true))
            .add(StructField("domain_data_source", StringType, true))
            .add(StructField("last_updated_by", StringType, true))
            .add(StructField("state_province_code", StringType, true))
            .add(StructField("country_code", StringType, true))
            .add(StructField("product_line_name", StringType, true))
    }

    def getCurrentDateTime() : String = {
        return Calendar.getInstance().getTime().toString
    }
}
