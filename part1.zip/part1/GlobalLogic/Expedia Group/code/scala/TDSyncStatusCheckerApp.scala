package com.expediagroup.platform.taxcompliance.trigger

import com.expediagroup.platform.taxcompliance.DataCollectorApp.readHqlFile
import com.expediagroup.platform.taxcompliance.aws.secret.DataCollectorConfigAWS
import com.expediagroup.platform.taxcompliance.util.DataUtil
import com.expediagroup.platform.taxcompliance.constants.AppConstants
import com.expediagroup.platform.taxcompliance.constants.AppConstants.RESOURCE_SCRIPT_COMMON_PATH
import com.expediagroup.platform.taxcompliance.sql.SQLColumnHelper
import org.apache.spark.sql.SparkSession.setActiveSession
import org.apache.spark.sql.functions.{col, to_date, upper}
import org.apache.spark.sql.{DataFrame, SparkSession}
import org.slf4j.LoggerFactory
import org.springframework.beans.factory.annotation.Value
import org.springframework.stereotype.Component

import java.text.SimpleDateFormat
import java.util

import java.time.LocalDate
import java.time.format.DateTimeFormatter

@Component
class TDSyncStatusCheckerApp {

    private val LOGGER = LoggerFactory.getLogger(this.getClass)

    @Value("${com.expediagroup.platform.taxcompliance.upstream.data.sync.status.table}")
    val dataSyncStatusTable : String = null

    @Value("${com.expediagroup.platform.taxcompliance.url.prod}")
    val prodUrl: String = null

    @Value("${com.expediagroup.platform.taxcompliance.url.nonprod}")
    val nonProdUrl: String = null

    def TeradataSparkConnection(args: Array[String]): Unit = {
        LOGGER.info("Starting main....")

        val run_env = args(0)
        val run_id = args(1)
        val replicationDate = args(2)
        val product_line = args(3).toString().toLowerCase().replaceAll("_", " ")
        val s3_bucket = args(4)
        val url = if (s3_bucket == AppConstants.S3_DATA_BUCKET) prodUrl else nonProdUrl
        val script_path = if (s3_bucket == AppConstants.S3_DATA_BUCKET) RESOURCE_SCRIPT_COMMON_PATH + AppConstants.GTP_PROD else RESOURCE_SCRIPT_COMMON_PATH + run_env;

        LOGGER.info("Run Environment: " + run_env)
        LOGGER.info("Run ID: " + run_id)
        LOGGER.info("Replication Date: " + replicationDate)
        LOGGER.info("Product Line Name: " + product_line)
        LOGGER.info("URL: " + url)
        LOGGER.info("s3_bucket: " + s3_bucket)
        LOGGER.info("scriptPath: " + script_path)

        LOGGER.info("Creating TeradataSparkConnection")

        val sparkSession = getSparkSession()
        LOGGER.isInfoEnabled
        LOGGER.trace("Spark Session Created....")
        setActiveSession(sparkSession);

        LOGGER.info("Secret Manager execution started")
        val dataCollectorSecrets = new DataCollectorConfigAWS()
        val userCredentials: java.util.List[String] = new util.ArrayList[String]
        fetchCredentials(userCredentials, dataCollectorSecrets.populateDataCollectorConfigAWS())

        executeReadTDSyncStatusCheckerQuery(sparkSession, url, userCredentials.get(0), userCredentials.get(1), run_id, replicationDate, product_line, script_path)
        //stop spark session
        sparkSession.stop()
    }

    def createTeradataJDBCConnectionWithSpark(spark: SparkSession, url: String, userName: String, userPassword: String, query_args: String): DataFrame = {

        LOGGER.info("Starting Again createTeradataJDBCConnectionWithSpark!!!")
        LOGGER.info("data-collector Script Execution Started...")

        val td_conn_read_df = spark.read.format("jdbc")
            .option("url", url)
            .option("query", query_args)
            .option("user", userName)
            .option("password", userPassword)
            .option("driver", "com.teradata.jdbc.TeraDriver")
            .load()
        LOGGER.info("SPARK-jdbc Connection Created with Teradata Instance!!!")
        td_conn_read_df
    }

    def executeReadTDSyncStatusCheckerQuery(spark: SparkSession, url: String, userName: String, userPassword: String,
                                            run_id: String, replicationDate: String, productLine: String, scriptPath: String): Unit = {
        var end_datetime: String = ""
        var end_datetime_hw: String = ""

        if (productLine.equalsIgnoreCase(AppConstants.PRODUCT_LINE_NAME_LX)) {

            var end_date_lx: String = ""
            var end_date_daily_exch_rate: String = ""
            var replicationDateToCompare: String = ""
            val startTime: Long = System.currentTimeMillis()
            LOGGER.info("executeReadTDSyncStatusCheckerQuery started " + startTime)

            val query_td_sync_status_checker_lx = readHqlFile(scriptPath + AppConstants.TD_SYNC_STATUS_CHECKER_LX)
            LOGGER.info("++++++++++++++++ Read Query Script: query_td_sync_status_checker_lx ++++++++++++++++ \n" + query_td_sync_status_checker_lx)

            val df_td_sync_status_checker_lx = createTeradataJDBCConnectionWithSpark(spark, url, userName, userPassword, query_td_sync_status_checker_lx)
            end_datetime = df_td_sync_status_checker_lx.select("end_datetime").head().getAs[java.sql.Timestamp]("end_datetime").toString
            LOGGER.info("END_DATETIME from TD for LX: " + end_datetime)

            val df_td_sync_status_checker_lx_with_date = df_td_sync_status_checker_lx.withColumn("END_DATE", to_date(col("end_datetime")))

            val col_end_date_lx = df_td_sync_status_checker_lx_with_date.select(col("END_DATE")).collect()(0)(0)
            val dateFormat = get_simple_date_format_obj
            end_date_lx = dateFormat.format(col_end_date_lx)
            LOGGER.info("END_DATE_LX: " + end_date_lx)

            LOGGER.info("Read Query Script: query_td_sync_status_checker_lx execution completed....")


            val query_td_sync_status_checker_daily_exch_rate = readHqlFile(scriptPath + AppConstants.TD_SYNC_STATUS_CHECKER_DAILY_EXCH_RATE)
            LOGGER.info("++++++++++++++++ Read Query Script: query_td_sync_status_checker_daily_exch_rate ++++++++++++++++ \n" + query_td_sync_status_checker_daily_exch_rate)

            val df_td_sync_status_checker_daily_exch_rate = createTeradataJDBCConnectionWithSpark(spark, url, userName, userPassword, query_td_sync_status_checker_daily_exch_rate)

            val df_td_sync_status_checker_daily_exch_rate_with_date = df_td_sync_status_checker_daily_exch_rate.withColumn("END_DATE", to_date(col("end_datetime")))

            val col_end_date_daily_exch_rate = df_td_sync_status_checker_daily_exch_rate_with_date.select(col("END_DATE")).collect()(0)(0)
            end_date_daily_exch_rate = dateFormat.format(col_end_date_daily_exch_rate)
            LOGGER.info("END_DATE_DAILY_EXCH_RATE: " + end_date_daily_exch_rate)

            LOGGER.info("Read Query Script: query_td_sync_status_checker_daily_exch_rate execution completed....")


            replicationDateToCompare = DataUtil.getPreviousDayDate(replicationDate)
            LOGGER.info("replicationDateToCompare: " + replicationDateToCompare)

            val replicationDateToCompareLx=LocalDate.parse(replicationDateToCompare)
            val end_date_daily_exch_rateLx=LocalDate.parse(end_date_daily_exch_rate)
            LOGGER.info("replicationDateToCompareLx: " + replicationDateToCompareLx)
            LOGGER.info("end_date_daily_exch_rateLx: " + end_date_daily_exch_rateLx)

            /*
            The `isAfter` method in Scala is used to compare two `LocalDate`, `LocalDateTime`, or `ZonedDateTime` instances.

            The method checks if the current date/time object is strictly after the provided one. It returns a boolean value:

            - `true` if the current object represents a point in time after the given date/time.
            - `false` if the current object represents a point in time equal to or before the given date/time.

            It’s important to note that:

            1. **Same date comparison**: If both date objects are the same (e.g., January 10, 2023), `isAfter` will return `false` because a date is not considered after itself.
            2. **Chronological order**: The method compares based on the natural chronological order. So, a `LocalDate` of `January 10, 2024` is considered after `January 10, 2023`.
            3. **Edge cases**: The method works correctly even with leap years, so `February 29, 2024` is considered after `February 28, 2024`.
            */



            if (replicationDate == end_date_lx && !replicationDateToCompareLx.isAfter(end_date_daily_exch_rateLx)) {
                LOGGER.info("Safe to proceed. replicationDate matching with end_date. Data rendering in Teradata is completed.")
            }
            else {
                val exceptionMessage = "Cannot proceed. replicationDate not matching with end_date. Data rendering in Teradata is not completed."
                LOGGER.info(exceptionMessage)
                throw new Exception(exceptionMessage)
            }

            LOGGER.info("Total Time taken  == " + (System.currentTimeMillis() - startTime))
        }

        else if (productLine.equalsIgnoreCase(AppConstants.PRODUCT_LINE_NAME_CAR)) {

            var end_date_car_hotwire: String = ""
            var end_date_car_rendering: String = ""
            var end_date_daily_exch_rate: String = ""
            var replicationDateToCompare: String = ""
            val startTime: Long = System.currentTimeMillis()
            LOGGER.info("executeReadTDSyncStatusCheckerQuery started " + startTime)

            val query_td_sync_status_checker_car = readHqlFile(scriptPath + AppConstants.TD_SYNC_STATUS_CHECKER_CARS)
            LOGGER.info("++++++++++++++++ Read Query Script: query_td_sync_status_checker_car ++++++++++++++++ \n" + query_td_sync_status_checker_car)

            val df_td_sync_status_checker_car = createTeradataJDBCConnectionWithSpark(spark, url, userName, userPassword, query_td_sync_status_checker_car)
            end_datetime = df_td_sync_status_checker_car.select("end_datetime").collect()(1).getAs[java.sql.Timestamp](0).toString
            LOGGER.info("END_DATETIME from TD for Car: " + end_datetime)

            val df_td_sync_status_checker_car_with_date = df_td_sync_status_checker_car.withColumn("END_DATE", to_date(col("end_datetime")))

            val col_end_date_car_hotwire = df_td_sync_status_checker_car_with_date.select(col("END_DATE")).collect()(0)(0)
            val dateFormat = get_simple_date_format_obj
            end_date_car_hotwire = dateFormat.format(col_end_date_car_hotwire)
            LOGGER.info("END_DATE_CAR_HOTWIRE: " + end_date_car_hotwire)

            val col_end_date_car_rendering = df_td_sync_status_checker_car_with_date.select(col("END_DATE")).collect()(1)(0)
            end_date_car_rendering = dateFormat.format(col_end_date_car_rendering)
            LOGGER.info("END_DATE_CAR_RENDERING: " + end_date_car_rendering)

            LOGGER.info("Read Query Script: query_td_sync_status_checker_car execution completed....")

            val query_td_sync_status_checker_daily_exch_rate = readHqlFile(scriptPath + AppConstants.TD_SYNC_STATUS_CHECKER_DAILY_EXCH_RATE)
            LOGGER.info("++++++++++++++++ Read Query Script: query_td_sync_status_checker_daily_exch_rate ++++++++++++++++ \n" + query_td_sync_status_checker_daily_exch_rate)

            val df_td_sync_status_checker_daily_exch_rate = createTeradataJDBCConnectionWithSpark(spark, url, userName, userPassword, query_td_sync_status_checker_daily_exch_rate)

            val df_td_sync_status_checker_daily_exch_rate_with_date = df_td_sync_status_checker_daily_exch_rate.withColumn("END_DATE", to_date(col("end_datetime")))

            val col_end_date_daily_exch_rate = df_td_sync_status_checker_daily_exch_rate_with_date.select(col("END_DATE")).collect()(0)(0)
            end_date_daily_exch_rate = dateFormat.format(col_end_date_daily_exch_rate)
            LOGGER.info("END_DATE_DAILY_EXCH_RATE: " + end_date_daily_exch_rate)

            LOGGER.info("Read Query Script: query_td_sync_status_checker_daily_exch_rate execution completed....")


            replicationDateToCompare = DataUtil.getPreviousDayDate(replicationDate)
            LOGGER.info("replicationDateToCompare: " + replicationDateToCompare)

            val replicationDateToCompareCar=LocalDate.parse(replicationDateToCompare)
            val end_date_daily_exch_rateCar=LocalDate.parse(end_date_daily_exch_rate)
            LOGGER.info("replicationDateToCompareCar: " + replicationDateToCompareCar)
            LOGGER.info("end_date_daily_exch_rateCar: " + end_date_daily_exch_rateCar)

            if (replicationDate == end_date_car_hotwire && replicationDate == end_date_car_rendering && !replicationDateToCompareCar.isAfter(end_date_daily_exch_rateCar)) {
                LOGGER.info("Safe to proceed. replicationDate matching with end_date. Data rendering in Teradata is completed.")
            }
            else {
                val exceptionMessage = "Cannot proceed. replicationDate not matching with end_date. Data rendering in Teradata is not completed."
                LOGGER.info(exceptionMessage)
                throw new Exception(exceptionMessage)
            }

            LOGGER.info("Total Time taken  == " + (System.currentTimeMillis() - startTime))

        }

        else if (productLine.equalsIgnoreCase(AppConstants.PRODUCT_LINE_NAME_LODGING)) {

            var end_date_lodging: String = ""
            var end_date_lodging_hw: String = ""
            var end_date_daily_exch_rate: String = ""
            var replicationDateToCompare: String = ""
            val startTime: Long = System.currentTimeMillis()
            LOGGER.info("executeReadTDSyncStatusCheckerQuery started " + startTime)

            val query_td_sync_status_checker_lodging = readHqlFile(scriptPath + AppConstants.TD_SYNC_STATUS_CHECKER_LODGING)
            LOGGER.info("++++++++++++++++ Read Query Script: query_td_sync_status_checker_lodging ++++++++++++++++ \n" + query_td_sync_status_checker_lodging)

            val df_td_sync_status_checker_lodging = createTeradataJDBCConnectionWithSpark(spark, url, userName, userPassword, query_td_sync_status_checker_lodging)
            end_datetime = df_td_sync_status_checker_lodging.select("end_datetime").filter(upper(col("workflow_name"))==="WF_EDWDM_LODG").head().getAs[java.sql.Timestamp]("end_datetime").toString
            end_datetime_hw = df_td_sync_status_checker_lodging.select("end_datetime").filter(upper(col("workflow_name"))==="WF_EDWDM_LODG_HOTWIRE").head().getAs[java.sql.Timestamp]("end_datetime").toString

            LOGGER.info("END_DATETIME from TD for Lodging: " + end_datetime)
            LOGGER.info("END_DATETIME from TD for Lodging Hotwire: " + end_datetime_hw)

            val df_td_sync_status_checker_lodging_with_date = df_td_sync_status_checker_lodging.withColumn("END_DATE", to_date(col("end_datetime")))

            val col_end_date_lodging = df_td_sync_status_checker_lodging_with_date.select(col("END_DATE")).filter(upper(col("workflow_name"))==="WF_EDWDM_LODG").collect()(0)(0)
            val col_end_date_lodging_hw = df_td_sync_status_checker_lodging_with_date.select(col("END_DATE")).filter(upper(col("workflow_name"))==="WF_EDWDM_LODG_HOTWIRE").collect()(0)(0)
            val dateFormat = get_simple_date_format_obj
            end_date_lodging = dateFormat.format(col_end_date_lodging)
            end_date_lodging_hw = dateFormat.format(col_end_date_lodging_hw)

            LOGGER.info("END_DATE_LODGING: " + end_date_lodging)
            LOGGER.info("END_DATE_LODGING_HW: " + end_date_lodging_hw)

            LOGGER.info("Read Query Script: query_td_sync_status_checker_lodging execution completed....")

            val query_td_sync_status_checker_daily_exch_rate = readHqlFile(scriptPath + AppConstants.TD_SYNC_STATUS_CHECKER_DAILY_EXCH_RATE)
            LOGGER.info("++++++++++++++++ Read Query Script: query_td_sync_status_checker_daily_exch_rate ++++++++++++++++ \n" + query_td_sync_status_checker_daily_exch_rate)


            val df_td_sync_status_checker_daily_exch_rate = createTeradataJDBCConnectionWithSpark(spark, url, userName, userPassword, query_td_sync_status_checker_daily_exch_rate)

            val df_td_sync_status_checker_daily_exch_rate_with_date = df_td_sync_status_checker_daily_exch_rate.withColumn("END_DATE", to_date(col("end_datetime")))

            val col_end_date_daily_exch_rate = df_td_sync_status_checker_daily_exch_rate_with_date.select(col("END_DATE")).collect()(0)(0)
            end_date_daily_exch_rate = dateFormat.format(col_end_date_daily_exch_rate)
            LOGGER.info("END_DATE_DAILY_EXCH_RATE: " + end_date_daily_exch_rate)

            LOGGER.info("Read Query Script: query_td_sync_status_checker_daily_exch_rate execution completed....")

            replicationDateToCompare = DataUtil.getPreviousDayDate(replicationDate)
            LOGGER.info("replicationDateToCompare: " + replicationDateToCompare)

            val replicationDateToCompareLodg=LocalDate.parse(replicationDateToCompare)
            val end_date_daily_exch_rateLodg=LocalDate.parse(end_date_daily_exch_rate)

            LOGGER.info("replicationDateToCompareLodg: " + replicationDateToCompareLodg)
            LOGGER.info("end_date_daily_exch_rateLodg: " + end_date_daily_exch_rateLodg)

            if (replicationDate == end_date_lodging && !replicationDateToCompareLodg.isAfter(end_date_daily_exch_rateLodg) && replicationDate == end_date_lodging_hw) {
                LOGGER.info("Safe to proceed. replicationDate matching with end_date. Data rendering in Teradata is completed.")
            }
            else {
                val exceptionMessage = "Cannot proceed. replicationDate not matching with end_date. Data rendering in Teradata is not completed."
                LOGGER.info(exceptionMessage)
                throw new Exception(exceptionMessage)
            }

            LOGGER.info("Total Time taken  == " + (System.currentTimeMillis() - startTime))

        }
        else{
            throw new Exception("Invalid product Line name")
        }
        // insert into upstream data sync status table
        insertIntoUpstreamDataSyncStatusTable(spark: SparkSession, replicationDate, run_id, end_datetime, productLine)
    }

    def get_simple_date_format_obj = {
        new SimpleDateFormat("yyyy-MM-dd")
    }

    def getSparkSession(): SparkSession = {
        val spark = SparkSession
            .builder()
            .config("spark.sql.crossJoin.enabled", true)
            .config("hive.exec.dynamic.partition.mode", "nonstrict")
            .config("hive.enforce.bucketing", "true")
            .appName("Spark SQL TeradataJDBC Connection")
            .enableHiveSupport()
            .getOrCreate()
        spark
    }

    def fetchCredentials(userCredentials: util.List[String], clientApiTokensMap: util.Map[String, String]) = {
        userCredentials.addAll(clientApiTokensMap.values)
        LOGGER.info("Secret Manager execution completed")
    }

    def insertIntoUpstreamDataSyncStatusTable(sqlc: SparkSession, replicationDate: String,
                                                      runId: String, end_datetime: String,
                                                      productLineName: String) = {
        val etlDateTime: String = DataUtil.getCurrentDateTimeInPst
        sqlc.sql(
            raw"""
                            INSERT INTO TABLE ${dataSyncStatusTable}
                            PARTITION(${SQLColumnHelper.REPLICATION_DATE} = '$replicationDate')
                            VALUES (
                                '$runId',
                                '$end_datetime',
                                'FULL',
                                'Normal',
                                '$etlDateTime',
                                '$productLineName'
                            )
	    """)
    }
}
