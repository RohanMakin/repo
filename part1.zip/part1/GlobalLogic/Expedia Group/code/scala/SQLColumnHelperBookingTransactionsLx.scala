
package com.expediagroup.platform.taxcompliance.sql


object SQLColumnHelperBookingTransactionsLx extends Serializable {

    val LODG_ROOM_TYPE_ID = "lodg_rm_typ_id"
    val BOOK_DATE_COLUMN = "book_date"
    val BEGIN_USE_DATE_COLUMN = "begin_use_date"
    val END_USE_DATE_COLUMN = "end_use_date"
    val BUSINESS_MODEL_NAME_COLUMN = "business_model_name"
    val BUSINESS_MODEL_SUBTYPE_NAME_COLUMN = "business_model_subtype_name"
    val ROOM_NIGHT_COUNT_COLUMN = "room_night_count"
    val RENTAL_DAY_COUNT_COLUMN = "rental_day_count"
    val BOOKING_ITEM_ID_COLUMN = "booking_item_id"
    val BOOKING_ID_COLUMN = "booking_id"
    val TRANS_TYPE_NAME_COLUMN = "transaction_type_name"
    val BOOKING_EVENT_DATE_COLUMN = "booking_event_date"
    val BOOKING_EVENT_DATETIME_COLUMN = "booking_event_datetime"
    val SOURCE_SYSTEM_ID_COLUMN = "source_system_id"
    val ITIN_NBR_COLUMN = "itin_nbr"
    val PKG_IND_COLUMN="pkg_ind"
    val RESERVATION_UUID_COLUMN = "reservation_uuid"
    val RESERVATION_STATE_COLUMN = "reservation_state"
    val RESERVATION_STATUS_COLUMN = "reservation_status"
    val SUPPLIER_MASTER_BRAND_COLUMN = "supplier_master_brand"
    val TRAVELER_BOOKING_SITE_COLUMN = "traveler_booking_site"
    val MERCHANT_OF_RECORD_TYPE_COLUMN = "merchant_of_record_type"

    val BASE_PRICE_AMT_LOCAL_COLUMN = "base_price_amount_local"
    val OTHR_PRICE_ADJ_AMT_LOCAL_COLUMN = "other_price_adjustment_amount_local"
    val TOTL_PRICE_ADJ_AMT_LOCAL_COLUMN = "total_price_adjustment_amount_local"
    val TOTL_FEE_PRICE_AMT_LOCAL_COLUMN = "total_fee_price_amount_local"
    val TOTL_TAX_PRICE_AMT_LOCAL_COLUMN = "total_tax_price_amount_local"
    val CNCL_CHG_FEE_PRICE_AMT_LOCAL_COLUMN = "cancel_change_fee_price_amount_local"
    val GROSS_BKG_AMT_LOCAL_COLUMN = "gross_booking_amount_local"
    val OTHER_FEE_PRICE_AMOUNT_LOCAL_COLUMN = "other_fee_price_amount_local"
    val AGENT_ASSISTED_PURCHASE_FEE_AMOUNT_LOCAL_COLUMN = "agent_assisted_purchase_fee_amount_local"

    val MARGN_AMT_USD_COLUMN = "margin_amount_usd"
    val PURE_MARGN_AMT_USD_COLUMN = "pure_margin_amount_usd"
    val BASE_COST_AMT_LOCAL_COLUMN = "base_cost_amount_local"
    val TOTL_COST_ADJ_AMT_LOCAL_COLUMN = "total_cost_adjustment_amount_local"
    val TOTL_FEE_COST_AMT_LOCAL_COLUMN = "total_fee_cost_amount_local"
    val OTHR_FEE_COST_AMT_LOCAL_COLUMN = "other_fee_cost_amount_local"
    val TOTL_TAX_COST_AMT_LOCAL_COLUMN = "total_tax_cost_amount_local"
    val TOTL_COST_AMT_LOCAL_COLUMN = "total_cost_amount_local"
    val LOCAL_AMOUNTS_COLUMN = "local_amounts"

    val CAR_VNDR_NAME_COLUMN = "car_vendor_name"
    val CAR_VNDR_CODE_COLUMN = "car_vendor_code"
    val CAR_PICK_UP_LOC_NAME = "car_pick_up_location_name"
    val CAR_PICK_UP_LOC_CITY_NAME = "car_pick_up_location_city_name"
    val CAR_PICK_UP_LOC_STATE_PROVNC_NAME = "car_pick_up_location_state_province_name"
    val CAR_PICK_UP_LOC_CNTRY_CODE = "car_pick_up_location_country_code"
    val CAR_DROP_OFF_LOC_NAME = "car_drop_off_location_name"
    val CAR_DROP_OFF_LOC_CITY_NAME = "car_drop_off_location_city_name"
    val CAR_DROP_OFF_LOC_STATE_PROVNC_NAME = "car_drop_off_location_state_province_name"
    val CAR_DROP_OFF_LOC_CNTRY_CODE = "car_drop_off_location_country_code"
    val CAR_RATE_IND_COLUMN = "car_rate_indicator"

    //partner_item_columns

    val PARTNER_ID = "partner_id"
    val PARTNER_NAME = "partner_name"
    val PARTNER_ADDRESS = "partner_address"
    val PARTNER_ADDRESS_LINE_1 = "address_line_1"
    val PARTNER_ADDRESS_LINE_2 = "address_line_2"
    val PARTNER_CITY = "city"
    val PARTNER_STATE = "state"
    val PARTNER_POSTAL_CODE = "postal_code"
    val PARTNER_COUNTRY_CODE = "country_code"
    val PARTNER_DISTRICT = "district"
    val PARTNER_COUNTY = "county"
    val PARTNER_ADDRESS_TYPE = "address_type"
    val PARTNER_LATITUDE = "latitude"
    val PARTNER_LONGITUDE = "longitude"
    val PARTNER_ATTRIBUTES = "partner_attributes"

    // lx column names
    val DEST_SERVICES_TCKT_CNT = "ticket_count"
    val ACTIVITY_ID = "activity_id"
    val OFFRNG_NAME = "offering_name"
    val OFFRNG_ITM_NAME = "offering_item_name"
    val OFFRNG_VNDR_NAME = "offering_vendor_name"
    val OFFRNG_VNDR_BRNCH_NAME = "offering_vendor_branch_name"
    val OFFRNG_VNDR_BRNCH_STATE_PROVNC_NAME = "offering_vendor_branch_state_province_name"
    val OFFRNG_VNDR_BRNCH_CNTRY_NAME = "offering_vendor_branch_country_name"
    val OFFRNG_CAT_NAME = "offering_category_name"

    val INTERNAL_CATEGORY_NAME = "internal_category_name"

    val PRICE_CURRENCY_CODE_COLUMN = "price_currency_code"
    val COST_CURRENCY_CODE_COLUMN = "cost_currency_code"
    val PRODUCT_LINE_NAME_COLUMN = "product_line_name"
    val LGL_ENTITY_CODE_COLUMN = "legal_entity_code"
    val LGL_ENTITY_NAME_COLUMN = "legal_entity_name"
    val TRANSACTION_TYPE_KEY_COLUMN = "transaction_type_key"
    val COUPN_PRICE_AMT_LOCAL_COLUMN = "coupon_price_amount_local"
    val TRAVEL_PRODUCT_ID_COLUMN = "travel_product_id"
    val USE_DATE_COLUMN = "use_date"
    val EXCEPTIONS_COLUMN = "exceptions"
    val EVENT_INFO_COLUMN = "event_info"
    val MANAGEMENT_UNIT_KEY_COLUMN = "management_unit_key"
    val MANAGEMENT_UNIT_CODE_COLUMN = "management_unit_code"
    val MANAGEMENT_UNIT_NAME_COLUMN = "management_unit_name"
    val MANAGEMENT_UNIT_LEVEL_6_NAME_COLUMN = "management_unit_level_6_name"
    val ORACLE_GL_PRODUCT_KEY_COLUMN = "oracle_gl_product_key"
    val TRAVEL_RECORD_LOCATOR_COLUMN = "travel_record_locator"

    // purchase column names
    val PURCHASE_BASE_PRICE_AMOUNT_LOCAL_COLUMN = "purchase_base_price_amount_local"
    val PURCHASE_TOTAL_PRICE_ADJUSTMENT_AMOUNT_LOCAL_COLUMN = "purchase_total_price_adjustment_amount_local"
    val PURCHASE_TOTAL_FEE_PRICE_AMOUNT_LOCAL_COLUMN = "purchase_total_fee_price_amount_local"
    val PURCHASE_TOTAL_TAX_PRICE_AMOUNT_LOCAL_COLUMN = "purchase_total_tax_price_amount_local"
    val PURCHASE_TOTAL_COST_AMOUNT_LOCAL_COLUMN = "purchase_total_cost_amount_local"
    val PURCHASE_TOTAL_TAX_COST_AMOUNT_LOCAL_COLUMN = "purchase_total_tax_cost_amount_local"
    val PURCHASE_TOTAL_COST_ADJUSTMENT_AMOUNT_LOCAL_COLUMN = "purchase_total_cost_adjustment_amount_local"
    val PURCHASE_COST_CURRENCY_CODE_COLUMN = "purchase_cost_currency_code"
    val PURCHASE_PRICE_CURRENCY_CODE_COLUMN = "purchase_price_currency_code"

    // lodging column names
    val PNLTY_PRICE_ADJ_AMT_LOCAL_COLUMN = "penalty_price_adjustment_amount_local"
    val EXPE_PNLTY_PRICE_ADJ_AMT_LOCAL_COLUMN = "expedia_penalty_price_adjustment_amount_local"
    val SVC_FEE_PRICE_AMT_LOCAL_COLUMN = "service_fee_price_amount_local"
    val SVC_CHRG_PRICE_AMT_LOCAL_COLUMN = "service_charge_price_amount_local"
    val BASE_COST_AMT_USD_COLUMN = "base_cost_amount_usd"
    val OTHR_COST_ADJ_AMT_USD_COLUMN = "other_cost_adjustment_amount_usd"
    val SUPPL_COST_ADJ_AMT_USD_COLUMN = "supplier_cost_adjustment_amount_usd"
    val TOTL_COST_ADJ_AMT_USD_COLUMN = "total_cost_adjustment_amount_usd"
    val TOTL_COST_AMT_USD_COLUMN = "total_cost_amount_usd"
    val TOTL_FEE_COST_AMT_USD_COLUMN = "total_fee_cost_amount_usd"
    val TOTL_TAX_COST_AMT_USD_COLUMN = "total_tax_cost_amount_usd"
    val EXPE_GDWLL_PRICE_ADJ_AMT_LOCAL_COLUMN = "expedia_goodwill_price_adjustment_amount_local"
    val GDWLL_PRICE_ADJ_AMT_LOCAL_COLUMN = "goodwill_price_adjustment_amount_local"
    val GENRIC_COUPN_PRICE_AMT_LOCAL_COLUMN = "generic_coupon_price_amount_local"
    val REFUND_PRICE_ADJ_AMT_LOCAL_COLUMN = "refund_price_adjustment_amount_local"
    val REBATE_PRICE_AMT_LOCAL_COLUMN = "rebate_price_amount_local"
    val TCM_PRICE_ADJ_AMT_LOCAL_COLUMN = "tcm_price_adjustment_amount_local"
    val CNCL_PNLTY_WAIVR_PRICE_ADJ_AMT_LOCAL_COLUMN = "cancel_penalty_waiver_price_adjustment_amount_local"
    val LOYLTY_POINT_PRICE_ADJ_AMT_LOCAL_COLUMN = "loyalty_point_price_adjustment_amount_local"
    val EMP_DISC_PRICE_ADJ_AMT_LOCAL_COLUMN = "employee_discount_price_adjustment_amount_local"
    val SUPPL_RECON_PRICE_ADJ_AMT_LOCAL_COLUMN = "supplier_reconciliation_price_adjustment_amount_local"
    val SUPPL_COST_ADJ_AMT_LOCAL_COLUMN = "supplier_cost_adjustment_amount_local"
    val ECA_COST_ADJ_AMT_LOCAL_COLUMN = "eca_cost_adjustment_amount_local"
    val OTHR_COST_ADJ_AMT_LOCAL_COLUMN = "other_cost_adjustment_amount_local"
    val VAR_MARGN_COST_ADJ_LOCAL_COLUMN = "variable_margin_cost_adjustment_amount_local"
    val SUPPL_RECON_COST_ADJ_AMT_LOCAL_COLUMN = "supplier_reconciliation_cost_adjustment_local"
    val SVC_CHRG_COST_AMT_LOCAL_COLUMN = "service_charge_cost_amount_local"
    val ECA_FEE_COST_AMT_LOCAL_COLUMN = "eca_fee_cost_amount_local"
    val VAR_MARGN_CREDT_LOCAL_COLUMN = "variable_margin_credit_local"
    val EXTRA_PERSN_COST_AMT_LOCAL_COLUMN = "extra_person_cost_amount_local"
    val RATE_PLN_RESTR_COST_AMT_LOCAL_COLUMN = "rate_plan_restriction_cost_amount_local"
    val SNGL_SUPPLMNT_COST_AMT_LOCAL_COLUMN = "single_supplement_cost_amount_local"
    val DYN_RATE_RULE_COST_AMT_LOCAL_COLUMN = "dynamic_rate_rule_cost_amount_local"
    //val ROOM_NIGHT_COUNT_COLUMN = "room_night_count"
    val TOTAL_TRAVELER_COUNT_COLUMN = "total_traveler_count"
    val PROPERTY_ID_COLUMN = "property_id"
    val POINT_OF_SALE_KEY_COLUMN = "point_of_sale_key"
    val POINT_OF_SALE_BRAND_NAME_COLUMN = "point_of_sale_brand_name"
    val POINT_OF_SALE_NAME_COLUMN = "point_of_sale_name"
    val TRVL_SVC_PROVDR_NAME_COLUMN = "travel_service_provider_name"
    val FRNT_END_CMSN_AMT_USD_COLUMN = "front_end_commission_amount_usd"

    // partition column names
    val TRANSACTION_LIABILITY_DATE_COLUMN = "transaction_liability_date"
    val TRANSACTION_LIABILITY_DATE_TYPE_COLUMN = "transaction_liability_date_type"

    // exception columns
    // primary key exception columns
    val BOOKING_ITEM_ID_EXCEPTION_COLUMN = "booking_item_id_exception"
    val BOOKING_ID_EXCEPTION_COLUMN = "booking_id_exception"
    val BOOK_DATE_EXCEPTION_COLUMN = "book_date_exception"
    val BOOKING_EVENT_DATE_EXCEPTION_COLUMN = "booking_event_date_exception"
    val SOUCE_SYSTEM_ID_EXCEPTION_COLUMN = "source_system_id_exception"
    val COST_CURRENCY_CODE_EXCEPTION_COLUMN = "cost_currency_code_exception"
    val TRANSACTION_TYPE_KEY_EXCEPTION_COLUMN = "transaction_type_key_exception"
    //val USE_DATE_EXCEPTION_COLUMN = "use_date_exception"

    // Few other important exception columns
    val BEGIN_USE_DATE_EXCEPTION_COLUMN = "begin_use_date_exception"
    val END_USE_DATE_EXCEPTION_COLUMN = "end_use_date_exception"
    val BOOKING_EVENT_DATETIME_EXCEPTION_COLUMN = "booking_event_datetime_exception"
    val TRANS_TYPE_NAME_EXCEPTION_COLUMN = "trans_type_name_exception"
    val PRICE_CURRENCY_CODE_EXCEPTION_COLUMN = "price_currency_code_exception"
    val USE_DATE_EXCEPTION_COLUMN_NAME = "use_date_exception_column"

    // Exception Types
    val NULL_COLUMN = "NullColumn"
    val EMPTY_COLUMN = "EmptyColumn"
    val INVALID_COLUMN = "InvalidColumn"

    // Exception Codes
    // Primary Key Column Exception codes
    val BOOKING_ITEM_ID_NULL_EXCEPTION_CODE = "1400"
    val BOOKING_ITEM_ID_EMPTY_EXCEPTION_CODE = "1401"

    val BOOKING_ID_NULL_EXCEPTION_CODE = "1500"
    val BOOKING_ID_EMPTY_EXCEPTION_CODE = "1501"

    val BOOK_DATE_NULL_EXCEPTION_CODE = "1600"
    val BOOK_DATE_EMPTY_EXCEPTION_CODE = "1601"
    val BOOK_DATE_INVALID_EXCEPTION_CODE = "1602"

    val BOOKING_EVENT_DATE_NULL_EXCEPTION_CODE = "1700"
    val BOOKING_EVENT_DATE_EMPTY_EXCEPTION_CODE = "1701"
    val BOOKING_EVENT_DATE_INVALID_EXCEPTION_CODE = "1702"

    val SOURCE_SYSTEM_ID_NULL_EXCEPTION_CODE = "1800"
    val SOURCE_SYSTEM_ID_EMPTY_EXCEPTION_CODE = "1801"
    val SOURCE_SYSTEM_ID_EXCEPTION_COLUMN = "source_system_id_exception_column"

    val COST_CURRENCY_CODE_NULL_EXCEPTION_CODE = "1900"
    val COST_CURRENCY_CODE_EMPTY_EXCEPTION_CODE = "1901"
    val COST_CURRENCY_CODE_INVALID_EXCEPTION_CODE = "1902"

    val TRANSACTION_TYPE_KEY_NULL_EXCEPTION_CODE = "2000"
    val TRANSACTION_TYPE_KEY_EMPTY_EXCEPTION_CODE = "2001"

    val USE_DATE_EXCEPTION_COLUMN = "2100"
    val USE_DATE_EMPTY_EXCEPTION_CODE = "2101"
    val USE_DATE_INVALID_EXCEPTION_CODE = "2102"

    // Other Important Column Exception codes

    val BEGIN_USE_DATE_NULL_EXCEPTION_CODE = "2300"
    val BEGIN_USE_DATE_EMPTY_EXCEPTION_CODE = "2301"
    val BEGIN_USE_DATE_INVALID_EXCEPTION_CODE = "2302"

    val END_USE_DATE_NULL_EXCEPTION_CODE = "2400"
    val END_USE_DATE_EMPTY_EXCEPTION_CODE = "2401"
    val END_USE_DATE_INVALID_EXCEPTION_CODE = "2402"

    val BOOKING_EVENT_DATETIME_NULL_EXCEPTION_CODE = "2500"
    val BOOKING_EVENT_DATETIME_EMPTY_EXCEPTION_CODE = "2501"

    val TRANS_TYPE_NAME_NULL_EXCEPTION_CODE = "2600"
    val TRANS_TYPE_NAME_EMPTY_EXCEPTION_CODE = "2601"

    val PRICE_CURRENCY_CODE_NULL_EXCEPTION_CODE = "2700"
    val PRICE_CURRENCY_CODE_EMPTY_EXCEPTION_CODE = "2701"
    val PRICE_CURRENCY_CODE_INVALID_EXCEPTION_CODE = "2702"

     val EXCEPTION_CODE="exception_code"
    val EXCEPTION_TYPE="exception_type"
    val EXCEPTION_DESCRIPTION="exception_description"
    val IS_CRITICAL_EXCEPTION= "is_critical_exception"
    val PARTNER_ITEM = "partner_item"
    val BOOKING_HISTORY_COLUMN = "booking_history"


    val LX_STAGE_BOOKING_READ_QUERY =
        s"""
           bk_date_key as ${BOOK_DATE_COLUMN},
           |  CASE
           |    WHEN bk_date_key IS NULL THEN
           |      NAMED_STRUCT(
           |        'exception_code', $BOOK_DATE_NULL_EXCEPTION_CODE,
           |        'exception_type', "$NULL_COLUMN",
           |        'exception_description', "${BOOK_DATE_COLUMN} is null",
           |        'is_critical_exception', true
           |      )
           |    WHEN bk_date_key = '' THEN
           |      NAMED_STRUCT(
           |        'exception_code', $BOOK_DATE_EMPTY_EXCEPTION_CODE,
           |        'exception_type', "$EMPTY_COLUMN",
           |        'exception_description', "${BOOK_DATE_COLUMN} is empty",
           |        'is_critical_exception', true
           |      )
           |    WHEN cast(bk_date_key as date) IS NULL THEN
           |      NAMED_STRUCT(
           |        'exception_code', $BOOK_DATE_INVALID_EXCEPTION_CODE,
           |        'exception_type', "$INVALID_COLUMN",
           |        'exception_description', "${BOOK_DATE_COLUMN} is invalid",
           |        'is_critical_exception', true
           |      )
           |  end
             as ${BOOK_DATE_EXCEPTION_COLUMN},
           |begin_use_date_key as ${BEGIN_USE_DATE_COLUMN},
           |  CASE
           |    WHEN begin_use_date_key IS NULL THEN
           |      NAMED_STRUCT(
           |        'exception_code', $BEGIN_USE_DATE_NULL_EXCEPTION_CODE,
           |        'exception_type', "$NULL_COLUMN",
           |        'exception_description', "${BEGIN_USE_DATE_COLUMN} is null",
           |        'is_critical_exception', true
           |      )
           |    WHEN begin_use_date_key = '' THEN
           |      NAMED_STRUCT(
           |        'exception_code', $BEGIN_USE_DATE_EMPTY_EXCEPTION_CODE,
           |        'exception_type', "$EMPTY_COLUMN",
           |        'exception_description', "${BEGIN_USE_DATE_COLUMN} is empty",
           |        'is_critical_exception', true
           |      )
           |    WHEN cast(begin_use_date_key as date) IS NULL THEN
           |      NAMED_STRUCT(
           |        'exception_code', $BEGIN_USE_DATE_INVALID_EXCEPTION_CODE,
           |        'exception_type', "$INVALID_COLUMN",
           |        'exception_description', "${BEGIN_USE_DATE_COLUMN} is invalid",
           |        'is_critical_exception', true
           |      )
           |  end
           |  as ${BEGIN_USE_DATE_EXCEPTION_COLUMN},
           |end_use_date_key as ${END_USE_DATE_COLUMN},
           |  CASE
           |    WHEN end_use_date_key IS NULL THEN
           |      NAMED_STRUCT(
           |        'exception_code', $END_USE_DATE_NULL_EXCEPTION_CODE,
           |        'exception_type', "$NULL_COLUMN",
           |        'exception_description', "${END_USE_DATE_COLUMN} is null",
           |        'is_critical_exception', true
           |      )
           |    WHEN end_use_date_key = '' THEN
           |      NAMED_STRUCT(
           |        'exception_code', $END_USE_DATE_EMPTY_EXCEPTION_CODE,
           |        'exception_type', "$EMPTY_COLUMN",
           |        'exception_description', "${END_USE_DATE_COLUMN} is empty",
           |        'is_critical_exception', true
           |      )
           |    WHEN cast(end_use_date_key as date) IS NULL THEN
           |      NAMED_STRUCT(
           |        'exception_code', $END_USE_DATE_INVALID_EXCEPTION_CODE,
           |        'exception_type', "$INVALID_COLUMN",
           |        'exception_description', "${END_USE_DATE_COLUMN} is invalid",
           |        'is_critical_exception', true
           |      )
           |  end
           |  as ${END_USE_DATE_EXCEPTION_COLUMN},
           |business_model_name as ${BUSINESS_MODEL_NAME_COLUMN},
           |business_model_subtyp_name as ${BUSINESS_MODEL_SUBTYPE_NAME_COLUMN},
           |DEST_SERVICES_TCKT_CNT as ${DEST_SERVICES_TCKT_CNT},
           |bkg_itm_id as ${BOOKING_ITEM_ID_COLUMN},
           |  CASE
           |    WHEN bkg_itm_id IS NULL THEN
           |      NAMED_STRUCT(
           |        'exception_code', $BEGIN_USE_DATE_NULL_EXCEPTION_CODE,
           |        'exception_type', "$NULL_COLUMN",
           |        'exception_description', "${BOOKING_ITEM_ID_COLUMN} is null",
           |        'is_critical_exception', true
           |      )
           |    WHEN bkg_itm_id = '' THEN
           |      NAMED_STRUCT(
           |        'exception_code', $BOOKING_ITEM_ID_EMPTY_EXCEPTION_CODE,
           |        'exception_type', "$EMPTY_COLUMN",
           |        'exception_description', "${BOOKING_ITEM_ID_COLUMN} is empty",
           |        'is_critical_exception', true
           |      )
           |  end
           |  as ${BOOKING_ITEM_ID_EXCEPTION_COLUMN},
           |bkg_id as ${BOOKING_ID_COLUMN},
           |  CASE
           |    WHEN bkg_id IS NULL THEN
           |      NAMED_STRUCT(
           |        'exception_code', $BOOKING_ID_NULL_EXCEPTION_CODE,
           |        'exception_type', "$NULL_COLUMN",
           |        'exception_description', "${BOOKING_ID_COLUMN} is null",
           |        'is_critical_exception', true
           |      )
           |    WHEN bkg_id = '' THEN
           |      NAMED_STRUCT(
           |        'exception_code', $BOOKING_ID_EMPTY_EXCEPTION_CODE,
           |        'exception_type', "$EMPTY_COLUMN",
           |        'exception_description', "${BOOKING_ID_COLUMN} is empty",
           |        'is_critical_exception', true
           |      )
           |  end
           |  as ${BOOKING_ID_EXCEPTION_COLUMN},
           |trans_typ_name as ${TRANS_TYPE_NAME_COLUMN},
           |  CASE
           |    WHEN trans_typ_name IS NULL THEN
           |      NAMED_STRUCT(
           |        'exception_code', $TRANS_TYPE_NAME_NULL_EXCEPTION_CODE,
           |        'exception_type', "$NULL_COLUMN",
           |        'exception_description', "${TRANS_TYPE_NAME_COLUMN} is null",
           |        'is_critical_exception', true
           |      )
           |    WHEN trans_typ_name = '' THEN
           |      NAMED_STRUCT(
           |        'exception_code', $TRANS_TYPE_NAME_EMPTY_EXCEPTION_CODE,
           |        'exception_type', "$EMPTY_COLUMN",
           |        'exception_description', "${TRANS_TYPE_NAME_COLUMN} is empty",
           |        'is_critical_exception', true
           |      )
           |
           | end
           | as ${TRANS_TYPE_NAME_EXCEPTION_COLUMN},
           |  trans_date_key as ${BOOKING_EVENT_DATE_COLUMN},
           |  CASE
           |    WHEN trans_date_key IS NULL THEN
           |      NAMED_STRUCT(
           |        'exception_code', $BOOKING_EVENT_DATE_NULL_EXCEPTION_CODE,
           |        'exception_type', "$NULL_COLUMN",
           |        'exception_description', "${BOOKING_EVENT_DATE_COLUMN} is null",
           |        'is_critical_exception', true
           |      )
           |    WHEN trans_date_key = '' THEN
           |      NAMED_STRUCT(
           |        'exception_code', $BOOKING_EVENT_DATE_EMPTY_EXCEPTION_CODE,
           |        'exception_type', "$EMPTY_COLUMN",
           |        'exception_description', "${BOOKING_EVENT_DATE_COLUMN} is empty",
           |        'is_critical_exception', true
           |      )
           |    WHEN cast(trans_date_key as date) IS NULL THEN
           |      NAMED_STRUCT(
           |        'exception_code', $BOOKING_EVENT_DATE_INVALID_EXCEPTION_CODE,
           |        'exception_type', "$INVALID_COLUMN",
           |        'exception_description', "${BOOKING_EVENT_DATE_COLUMN} is invalid",
           |        'is_critical_exception', true
           |      )
           |  end
           |  as ${BOOKING_EVENT_DATE_EXCEPTION_COLUMN},
           |  trans_datetm as ${BOOKING_EVENT_DATETIME_COLUMN},
           |  CASE
           |    WHEN trans_datetm IS NULL THEN
           |      NAMED_STRUCT(
           |        'exception_code', $BOOKING_EVENT_DATETIME_NULL_EXCEPTION_CODE,
           |        'exception_type', "$NULL_COLUMN",
           |        'exception_description', "${BOOKING_EVENT_DATETIME_COLUMN} is null",
           |        'is_critical_exception', true
           |      )
           |    WHEN trans_datetm = '' THEN
           |      NAMED_STRUCT(
           |        'exception_code', $BOOKING_EVENT_DATETIME_EMPTY_EXCEPTION_CODE,
           |        'exception_type', "$EMPTY_COLUMN",
           |        'exception_description', "${BOOKING_EVENT_DATETIME_COLUMN} is empty",
           |        'is_critical_exception', true
           |      )
           |  end
           |  as ${BOOKING_EVENT_DATETIME_EXCEPTION_COLUMN},
           |  src_sys_id as ${SOURCE_SYSTEM_ID_COLUMN},
           |  CASE
           |    WHEN src_sys_id IS NULL THEN
           |      NAMED_STRUCT(
           |        'exception_code', $SOURCE_SYSTEM_ID_NULL_EXCEPTION_CODE,
           |        'exception_type', "$NULL_COLUMN",
           |        'exception_description', "${SOURCE_SYSTEM_ID_COLUMN} is null",
           |        'is_critical_exception', true
           |      )
           |    WHEN src_sys_id = '' THEN
           |      NAMED_STRUCT(
           |        'exception_code', $SOURCE_SYSTEM_ID_EMPTY_EXCEPTION_CODE,
           |        'exception_type', "$EMPTY_COLUMN",
           |        'exception_description', "${SOURCE_SYSTEM_ID_COLUMN} is empty",
           |        'is_critical_exception', true
           |      )
           |  end
           |  as ${SOURCE_SYSTEM_ID_EXCEPTION_COLUMN},
           |     base_price_amt_local as ${BASE_PRICE_AMT_LOCAL_COLUMN},
           |     totl_price_adj_amt_local as ${TOTL_PRICE_ADJ_AMT_LOCAL_COLUMN},
           |     totl_fee_price_amt_local as ${TOTL_FEE_PRICE_AMT_LOCAL_COLUMN},
           |     totl_tax_price_amt_local as ${TOTL_TAX_PRICE_AMT_LOCAL_COLUMN},
           |     gross_bkg_amt_local as ${GROSS_BKG_AMT_LOCAL_COLUMN},
           |     MARGN_AMT_USD as ${MARGN_AMT_USD_COLUMN},
           |     BASE_COST_AMT_LOCAL as ${BASE_COST_AMT_LOCAL_COLUMN},
           |     TOTL_COST_ADJ_AMT_LOCAL as ${TOTL_COST_ADJ_AMT_LOCAL_COLUMN},
           |     TOTL_FEE_COST_AMT_LOCAL as ${TOTL_FEE_COST_AMT_LOCAL_COLUMN},
           |     TOTL_TAX_COST_AMT_LOCAL as ${TOTL_TAX_COST_AMT_LOCAL_COLUMN},
           |     TOTL_COST_AMT_USD as ${TOTL_COST_AMT_USD_COLUMN},
           |     TOTL_COST_AMT_LOCAL as ${TOTL_COST_AMT_LOCAL_COLUMN},
           |     TOTL_FEE_COST_AMT_USD as ${TOTL_FEE_COST_AMT_USD_COLUMN},
           |     TOTL_TAX_COST_AMT_USD as ${TOTL_TAX_COST_AMT_USD_COLUMN},
           |     TOTL_COST_ADJ_AMT_USD as ${TOTL_COST_ADJ_AMT_USD_COLUMN},
           |    CASE
           |    WHEN trim(currn_code) like '%-' THEN
           |    'Unknown'
           |    ELSE trim(currn_code)
           |    end as ${PRICE_CURRENCY_CODE_COLUMN},
           |    CASE
           |    WHEN currn_code IS NULL THEN
           |    NAMED_STRUCT(
           |        'exception_code', $PRICE_CURRENCY_CODE_NULL_EXCEPTION_CODE,
           |        'exception_type', "$NULL_COLUMN",
           |        'exception_description', "${PRICE_CURRENCY_CODE_COLUMN} is null",
           |        'is_critical_exception', true
           |      )
           |      WHEN currn_code = '' THEN
           |    NAMED_STRUCT(
           |        'exception_code', $PRICE_CURRENCY_CODE_EMPTY_EXCEPTION_CODE,
           |        'exception_type', "$EMPTY_COLUMN",
           |        'exception_description', "${PRICE_CURRENCY_CODE_COLUMN} is empty",
           |        'is_critical_exception', true
           |      )
           |    end
           |    as ${PRICE_CURRENCY_CODE_EXCEPTION_COLUMN},
           |    CASE
           |    WHEN trim(currn_code2) like '%-' THEN
           |    'Unknown'
           |    ELSE trim(currn_code2)
           |    end as ${COST_CURRENCY_CODE_COLUMN},
           |    CASE
           |    WHEN currn_code2 IS NULL THEN
           |    NAMED_STRUCT(
           |        'exception_code', $COST_CURRENCY_CODE_NULL_EXCEPTION_CODE,
           |        'exception_type', "$NULL_COLUMN",
           |        'exception_description', "${COST_CURRENCY_CODE_COLUMN} is null",
           |        'is_critical_exception', true
           |      )
           |      WHEN currn_code = '' THEN
           |    NAMED_STRUCT(
           |        'exception_code', $COST_CURRENCY_CODE_EMPTY_EXCEPTION_CODE,
           |        'exception_type', "$EMPTY_COLUMN",
           |        'exception_description', "${COST_CURRENCY_CODE_COLUMN} is empty",
           |        'is_critical_exception', true
           |      )
           |      end
           |    as ${COST_CURRENCY_CODE_EXCEPTION_COLUMN},
           |    product_ln_name as ${PRODUCT_LINE_NAME_COLUMN},
           |     lgl_entity_code as ${LGL_ENTITY_CODE_COLUMN},
           |     lgl_entity_name as ${LGL_ENTITY_NAME_COLUMN},
           |     trans_typ_key as ${TRANSACTION_TYPE_KEY_COLUMN},
           |     CASE
           |    WHEN trans_typ_key IS NULL THEN
           |    NAMED_STRUCT(
           |        'exception_code', $TRANSACTION_TYPE_KEY_NULL_EXCEPTION_CODE,
           |        'exception_type', "$NULL_COLUMN",
           |        'exception_description', "${TRANSACTION_TYPE_KEY_COLUMN} is null",
           |        'is_critical_exception', true
           |      )
           |      WHEN trans_typ_key = '' THEN
           |    NAMED_STRUCT(
           |        'exception_code', $TRANSACTION_TYPE_KEY_EMPTY_EXCEPTION_CODE,
           |        'exception_type', "$EMPTY_COLUMN",
           |        'exception_description', "${TRANSACTION_TYPE_KEY_COLUMN} is empty",
           |        'is_critical_exception', true
           |      )
           |      end
           |    as ${TRANSACTION_TYPE_KEY_EXCEPTION_COLUMN},
           |    coupn_price_amt_local as ${COUPN_PRICE_AMT_LOCAL_COLUMN},
           |     tpid as ${TRAVEL_PRODUCT_ID_COLUMN},
           |     CASE
           |    WHEN pos_key IS NULL OR pos_key = '' THEN
           |    'Unknown'
           |    ELSE pos_key
           |    end as ${POINT_OF_SALE_KEY_COLUMN},
           |    CASE
           |    WHEN brand_name IS NULL OR brand_name = ''
           |    THEN
           |    'Unknown'
           |    ELSE brand_name
           |    end
           |    as ${POINT_OF_SALE_BRAND_NAME_COLUMN},
           |    CASE
           |    WHEN pos_name IS NULL OR pos_name = '' THEN
           |    'Unknown'
           |    ELSE pos_name
           |    end
           |    as ${POINT_OF_SALE_NAME_COLUMN},
           |    CASE
           |    WHEN mgmt_unit_key IS NULL OR mgmt_unit_key = '' THEN
           |    'Unknown'
           |    ELSE mgmt_unit_key
           |    end
           |    as ${MANAGEMENT_UNIT_KEY_COLUMN},
           |    CASE
           |    WHEN mgmt_unit_code IS NULL OR mgmt_unit_code = '' THEN
           |    'Unknown'
           |    ELSE mgmt_unit_code
           |    end
           |    as ${MANAGEMENT_UNIT_CODE_COLUMN},
           |    CASE
           |    WHEN mgmt_unit_name IS NULL OR mgmt_unit_name = '' THEN
           |    'Unknown'
           |    ELSE mgmt_unit_name
           |    end
           |    as ${MANAGEMENT_UNIT_NAME_COLUMN},
           |    CASE
           |     WHEN mgmt_unit_lvl_6_name IS NULL OR mgmt_unit_lvl_6_name = '' THEN 'Unknown'
           |          ELSE mgmt_unit_lvl_6_name
           |     END AS ${MANAGEMENT_UNIT_LEVEL_6_NAME_COLUMN},
           |     oracle_gl_product_key as ${ORACLE_GL_PRODUCT_KEY_COLUMN}
           |    ,trl as ${TRAVEL_RECORD_LOCATOR_COLUMN}
           |     ,cast(activityid as string) as  ${ACTIVITY_ID}
           |      ,offrng_vndr_name as ${OFFRNG_VNDR_NAME}
           |      ,offrng_vndr_brnch_state_provnc_name  as ${OFFRNG_VNDR_BRNCH_STATE_PROVNC_NAME}
           |      ,offrng_vndr_brnch_name as ${OFFRNG_VNDR_BRNCH_NAME}
           |      ,offrng_vndr_brnch_cntry_name as ${OFFRNG_VNDR_BRNCH_CNTRY_NAME}
           |      ,offrng_name as ${OFFRNG_NAME}
           |      ,offrng_itm_name as ${OFFRNG_ITM_NAME}
           |      ,offrng_cat_name as ${OFFRNG_CAT_NAME}
           |      ,internalcategoryname as  ${INTERNAL_CATEGORY_NAME}
           |    ,begin_use_date_key as ${USE_DATE_COLUMN}
           |    ,begin_use_date_key as ${TRANSACTION_LIABILITY_DATE_COLUMN}
           |    ,'stayDate' as ${TRANSACTION_LIABILITY_DATE_TYPE_COLUMN}
           |    ,NAMED_STRUCT('run_id','',
           |    'published_timestamp',
           |    cast(CURRENT_TIMESTAMP as string),
           |    'event_uuid',cast(md5(concat(bkg_itm_id, trans_typ_key, trans_datetm, src_sys_id, bkg_id, begin_use_date_key, currn_code2)) as string))
           |         as ${EVENT_INFO_COLUMN},
           |	case
           |         when
           |            cast(begin_use_date_key as date) IS NULL
           |         then
           |             NAMED_STRUCT('exception_code',${USE_DATE_EXCEPTION_COLUMN},'exception_type',"${NULL_COLUMN}",'exception_description',"${USE_DATE_COLUMN} is null", 'is_critical_exception',true)
           |         when
           |            begin_use_date_key IS NULL
           |         then
           |             NAMED_STRUCT('exception_code',${USE_DATE_EMPTY_EXCEPTION_CODE},'exception_type',"${EMPTY_COLUMN}",'exception_description',"${USE_DATE_COLUMN} is empty", 'is_critical_exception',true)
           |         when
           |            begin_use_date_key = ''
           |         then
           |            NAMED_STRUCT('exception_code',${USE_DATE_INVALID_EXCEPTION_CODE},'exception_type',"${INVALID_COLUMN}",'exception_description',"${USE_DATE_COLUMN} is invalid", 'is_critical_exception',true)
           |      end
           |      as ${USE_DATE_EXCEPTION_COLUMN_NAME},
           |      itin_nbr as ${ITIN_NBR_COLUMN},
           |      pkg_ind as ${PKG_IND_COLUMN}
              """.stripMargin

    val LX_STAGE_BOOKING_INSERT_STATEMENT =
        s"""
           | INSERT INTO table commerce.tax_compliance_eg_booking_transactions PARTITION(${TRANSACTION_LIABILITY_DATE_COLUMN},${TRANSACTION_LIABILITY_DATE_TYPE_COLUMN},${PRODUCT_LINE_NAME_COLUMN})
        """.stripMargin

    val LX_STAGE_BOOKING_INSERT_QUERY =
        s"""
           |NAMED_STRUCT(
           |         '${USE_DATE_COLUMN}',cast(${USE_DATE_COLUMN} as string),
           |         '${BOOK_DATE_COLUMN}',cast(${BOOK_DATE_COLUMN} as string),
           |         '${BEGIN_USE_DATE_COLUMN}',cast(${BEGIN_USE_DATE_COLUMN} as string),
           |         '${END_USE_DATE_COLUMN}',cast(${END_USE_DATE_COLUMN} as string),
           |         '${ROOM_NIGHT_COUNT_COLUMN}',0,
           |         '${BOOKING_ITEM_ID_COLUMN}',cast(${BOOKING_ITEM_ID_COLUMN} as string),
           |         '${BOOKING_ID_COLUMN}',${BOOKING_ID_COLUMN},
           |         '${SOURCE_SYSTEM_ID_COLUMN}',${SOURCE_SYSTEM_ID_COLUMN},
           |         '${BOOKING_EVENT_DATE_COLUMN}',cast(${BOOKING_EVENT_DATE_COLUMN} as string),
           |         '${BOOKING_EVENT_DATETIME_COLUMN}',cast(${BOOKING_EVENT_DATETIME_COLUMN} as string),
           |         '${TRANS_TYPE_NAME_COLUMN}',${TRANS_TYPE_NAME_COLUMN},
           |         '${BUSINESS_MODEL_NAME_COLUMN}',${BUSINESS_MODEL_NAME_COLUMN},
           |         '${BUSINESS_MODEL_SUBTYPE_NAME_COLUMN}',${BUSINESS_MODEL_SUBTYPE_NAME_COLUMN},
           |         '${PRODUCT_LINE_NAME_COLUMN}',${PRODUCT_LINE_NAME_COLUMN},
           |         '${TRAVEL_PRODUCT_ID_COLUMN}',${TRAVEL_PRODUCT_ID_COLUMN},
           |         '${TOTAL_TRAVELER_COUNT_COLUMN}',0,
           |         '${TRANSACTION_TYPE_KEY_COLUMN}',${TRANSACTION_TYPE_KEY_COLUMN},
           |         '${TRAVEL_RECORD_LOCATOR_COLUMN}',${TRAVEL_RECORD_LOCATOR_COLUMN},
           |         '${LODG_ROOM_TYPE_ID}', 0,
           |         '${ITIN_NBR_COLUMN}',sb.${ITIN_NBR_COLUMN},
           |         '${PKG_IND_COLUMN}',${PKG_IND_COLUMN},
           |         '${RESERVATION_UUID_COLUMN}', "NULL",
           |         '${RESERVATION_STATE_COLUMN}', "NULL",
           |         '${RESERVATION_STATUS_COLUMN}', "NULL",
           |         '${SUPPLIER_MASTER_BRAND_COLUMN}', "NULL",
           |         '${TRAVELER_BOOKING_SITE_COLUMN}', "NULL",
           |         '${MERCHANT_OF_RECORD_TYPE_COLUMN}', cast(' ' as string)
           | ) AS BOOKING_ITEM,
           | NAMED_STRUCT(
           |        '${BASE_PRICE_AMT_LOCAL_COLUMN}',cast(${BASE_PRICE_AMT_LOCAL_COLUMN} as decimal(18,2)),
           |        '${OTHR_PRICE_ADJ_AMT_LOCAL_COLUMN}',cast(0.00 as decimal(18,2)),
           |        '${PNLTY_PRICE_ADJ_AMT_LOCAL_COLUMN}',cast(0.00 as decimal(18,2)),
           |        '${EXPE_PNLTY_PRICE_ADJ_AMT_LOCAL_COLUMN}',cast(0.00 as decimal(18,2)),
           |        '${TOTL_PRICE_ADJ_AMT_LOCAL_COLUMN}',cast(${TOTL_PRICE_ADJ_AMT_LOCAL_COLUMN} as decimal(18,2)),
           |        '${SVC_FEE_PRICE_AMT_LOCAL_COLUMN}',cast(0.00 as decimal(18,2)),
           |        '${TOTL_FEE_PRICE_AMT_LOCAL_COLUMN}',cast(${TOTL_FEE_PRICE_AMT_LOCAL_COLUMN} as decimal(18,2)),
           |        '${TOTL_TAX_PRICE_AMT_LOCAL_COLUMN}',cast(${TOTL_TAX_PRICE_AMT_LOCAL_COLUMN} as decimal(18,2)),
           |        '${SVC_CHRG_PRICE_AMT_LOCAL_COLUMN}',cast(0.00 as decimal(18,2)),
           |        '${CNCL_CHG_FEE_PRICE_AMT_LOCAL_COLUMN}',cast(0.00 as decimal(18,2)),
           |        '${BASE_COST_AMT_USD_COLUMN}',cast(0.00 as decimal(18,2)),
           |        '${OTHR_COST_ADJ_AMT_USD_COLUMN}',cast(0.00 as decimal(18,2)),
           |        '${SUPPL_COST_ADJ_AMT_USD_COLUMN}',cast(0.00 as decimal(18,2)),
           |        '${TOTL_COST_ADJ_AMT_USD_COLUMN}',cast(${TOTL_COST_ADJ_AMT_USD_COLUMN} as decimal(18,2)),
           |        '${TOTL_COST_AMT_USD_COLUMN}',cast(${TOTL_COST_AMT_USD_COLUMN} as decimal(18,2)),
           |        '${TOTL_FEE_COST_AMT_USD_COLUMN}',cast(${TOTL_FEE_COST_AMT_USD_COLUMN} as decimal(18,2)),
           |        '${TOTL_TAX_COST_AMT_USD_COLUMN}',cast(${TOTL_TAX_COST_AMT_USD_COLUMN} as decimal(18,2)),
           |        '${GROSS_BKG_AMT_LOCAL_COLUMN}',cast(${GROSS_BKG_AMT_LOCAL_COLUMN} as decimal(18,2)),
           |        '${OTHER_FEE_PRICE_AMOUNT_LOCAL_COLUMN}',cast(0.00 as decimal(18,2)),
           |        '${AGENT_ASSISTED_PURCHASE_FEE_AMOUNT_LOCAL_COLUMN}',cast(0.00 as decimal(18,2)),
           |        '${PRICE_CURRENCY_CODE_COLUMN}',${PRICE_CURRENCY_CODE_COLUMN},
           |        '${COST_CURRENCY_CODE_COLUMN}',${COST_CURRENCY_CODE_COLUMN},
           |        '${COUPN_PRICE_AMT_LOCAL_COLUMN}',cast(${COUPN_PRICE_AMT_LOCAL_COLUMN} as decimal(18,2)),
           |        '${EXPE_GDWLL_PRICE_ADJ_AMT_LOCAL_COLUMN}',cast(0.00 as decimal(18,2)),
           |        '${GDWLL_PRICE_ADJ_AMT_LOCAL_COLUMN}',cast(0.00 as decimal(18,2)),
           |        '${GENRIC_COUPN_PRICE_AMT_LOCAL_COLUMN}',cast(0.00 as decimal(18,2)),
           |        '${REFUND_PRICE_ADJ_AMT_LOCAL_COLUMN}',cast(0.00 as decimal(18,2)),
           |        '${REBATE_PRICE_AMT_LOCAL_COLUMN}',cast(0.00 as decimal(18,2)),
           |        '${TCM_PRICE_ADJ_AMT_LOCAL_COLUMN}',cast(0.00 as decimal(18,2)),
           |        '${CNCL_PNLTY_WAIVR_PRICE_ADJ_AMT_LOCAL_COLUMN}',cast(0.00 as decimal(18,2)),
           |        '${LOYLTY_POINT_PRICE_ADJ_AMT_LOCAL_COLUMN}',cast(0.00 as decimal(18,2)),
           |        '${EMP_DISC_PRICE_ADJ_AMT_LOCAL_COLUMN}',cast(0.00 as decimal(18,2)),
           |        '${SUPPL_RECON_PRICE_ADJ_AMT_LOCAL_COLUMN}',cast(0.00 as decimal(18,2)),
           |        '${TOTL_COST_AMT_LOCAL_COLUMN}',cast(${TOTL_COST_AMT_LOCAL_COLUMN} as decimal(18,2)),
           |        '${BASE_COST_AMT_LOCAL_COLUMN}',cast(${BASE_COST_AMT_LOCAL_COLUMN} as decimal(18,2)),
           |        '${TOTL_COST_ADJ_AMT_LOCAL_COLUMN}',cast(${TOTL_COST_ADJ_AMT_LOCAL_COLUMN} as decimal(18,2)),
           |        '${SUPPL_COST_ADJ_AMT_LOCAL_COLUMN}',cast(0.00 as decimal(18,2)),
           |        '${ECA_COST_ADJ_AMT_LOCAL_COLUMN}',cast(0.00 as decimal(18,2)),
           |        '${OTHR_COST_ADJ_AMT_LOCAL_COLUMN}',cast(0.00 as decimal(18,2)),
           |        '${VAR_MARGN_COST_ADJ_LOCAL_COLUMN}',cast(0.00 as decimal(18,2)),
           |        '${SUPPL_RECON_COST_ADJ_AMT_LOCAL_COLUMN}',cast(0.00 as decimal(18,2)),
           |        '${TOTL_FEE_COST_AMT_LOCAL_COLUMN}',cast(${TOTL_FEE_COST_AMT_LOCAL_COLUMN} as decimal(18,2)),
           |        '${SVC_CHRG_COST_AMT_LOCAL_COLUMN}',cast(0.00 as decimal(18,2)),
           |        '${OTHR_FEE_COST_AMT_LOCAL_COLUMN}',cast(0.00 as decimal(18,2)),
           |        '${ECA_FEE_COST_AMT_LOCAL_COLUMN}',cast(0.00 as decimal(18,2)),
           |        '${TOTL_TAX_COST_AMT_LOCAL_COLUMN}',cast(${TOTL_TAX_COST_AMT_LOCAL_COLUMN} as decimal(18,2)),
           |        '${VAR_MARGN_CREDT_LOCAL_COLUMN}',cast(0.00 as decimal(18,2)),
           |        '${MARGN_AMT_USD_COLUMN}',cast(${MARGN_AMT_USD_COLUMN} as decimal(18,2)),
           |        '${PURE_MARGN_AMT_USD_COLUMN}',cast(0.00 as decimal(18,2)),
           |        '${EXTRA_PERSN_COST_AMT_LOCAL_COLUMN}',cast(0.00 as decimal(18,2)),
           |        '${RATE_PLN_RESTR_COST_AMT_LOCAL_COLUMN}',cast(0.00 as decimal(18,2)),
           |        '${SNGL_SUPPLMNT_COST_AMT_LOCAL_COLUMN}',cast(0.00 as decimal(18,2)),
           |        '${DYN_RATE_RULE_COST_AMT_LOCAL_COLUMN}',cast(0.00 as decimal(18,2)),
           |        '${PURCHASE_BASE_PRICE_AMOUNT_LOCAL_COLUMN}', cast(0.00 as decimal(18,2)),
           |        '${PURCHASE_TOTAL_PRICE_ADJUSTMENT_AMOUNT_LOCAL_COLUMN}',cast(0.00 as decimal(18,2)),
           |        '${PURCHASE_TOTAL_FEE_PRICE_AMOUNT_LOCAL_COLUMN}',cast(0.00 as decimal(18,2)),
           |        '${PURCHASE_TOTAL_TAX_PRICE_AMOUNT_LOCAL_COLUMN}',cast(0.00 as decimal(18,2)),
           |        '${PURCHASE_TOTAL_COST_AMOUNT_LOCAL_COLUMN}',cast(0.00 as decimal(18,2)),
           |        '${PURCHASE_TOTAL_TAX_COST_AMOUNT_LOCAL_COLUMN}',cast(0.00 as decimal(18,2)),
           |        '${PURCHASE_TOTAL_COST_ADJUSTMENT_AMOUNT_LOCAL_COLUMN}',cast(0.00 as decimal(18,2)),
           |        '${PURCHASE_COST_CURRENCY_CODE_COLUMN}',${COST_CURRENCY_CODE_COLUMN},
           |        '${PURCHASE_PRICE_CURRENCY_CODE_COLUMN}',${PRICE_CURRENCY_CODE_COLUMN},
           |        '${FRNT_END_CMSN_AMT_USD_COLUMN}',cast(0.00 as decimal(18,2))
           |         ) AS ITEM_AMOUNT,
           |NAMED_STRUCT(
           |           '${PROPERTY_ID_COLUMN}',"NULL"
           |           ) AS PROPERTY_ITEM,
           |NAMED_STRUCT(
           |          '${LGL_ENTITY_NAME_COLUMN}',${LGL_ENTITY_NAME_COLUMN},
           |          '${LGL_ENTITY_CODE_COLUMN}',${LGL_ENTITY_CODE_COLUMN},
           |          '${POINT_OF_SALE_KEY_COLUMN}',0,
           |          '${POINT_OF_SALE_BRAND_NAME_COLUMN}',"NULL",
           |          '${POINT_OF_SALE_NAME_COLUMN}',"NULL",
           |          '${MANAGEMENT_UNIT_KEY_COLUMN}',cast(${MANAGEMENT_UNIT_KEY_COLUMN} as int),
           |          '${MANAGEMENT_UNIT_CODE_COLUMN}',${MANAGEMENT_UNIT_CODE_COLUMN},
           |          '${MANAGEMENT_UNIT_NAME_COLUMN}',${MANAGEMENT_UNIT_NAME_COLUMN},
           |          '${MANAGEMENT_UNIT_LEVEL_6_NAME_COLUMN}',${MANAGEMENT_UNIT_LEVEL_6_NAME_COLUMN},
           |          '${ORACLE_GL_PRODUCT_KEY_COLUMN}',cast(${ORACLE_GL_PRODUCT_KEY_COLUMN} as int),
           |          '${TRVL_SVC_PROVDR_NAME_COLUMN}',"NULL"
           |           ) AS BOOKING_DETAIL,
           |         ${EVENT_INFO_COLUMN},
           |NAMED_STRUCT(
           |        '${CAR_VNDR_NAME_COLUMN}',cast(' ' as string),
           |        '${CAR_VNDR_CODE_COLUMN}',cast(' ' as string),
           |        '${CAR_PICK_UP_LOC_NAME}',cast(' ' as string),
           |        '${CAR_PICK_UP_LOC_CITY_NAME}',cast(' ' as string),
           |        '${CAR_PICK_UP_LOC_STATE_PROVNC_NAME}',cast(' ' as string),
           |        '${CAR_PICK_UP_LOC_CNTRY_CODE}',cast(' ' as string),
           |        '${CAR_DROP_OFF_LOC_NAME}',cast(' ' as string),
           |        '${CAR_DROP_OFF_LOC_CITY_NAME}',cast(' ' as string),
           |        '${CAR_DROP_OFF_LOC_STATE_PROVNC_NAME}',cast(' ' as string),
           |        '${CAR_DROP_OFF_LOC_CNTRY_CODE}',cast(' ' as string),
           |        '${RENTAL_DAY_COUNT_COLUMN}',0,
           |        '${CAR_RATE_IND_COLUMN}', cast(' ' as string)
           |        ) AS  CAR_ITEM,
           |NAMED_STRUCT(
           |         '${ACTIVITY_ID}',${ACTIVITY_ID},
           |        '${INTERNAL_CATEGORY_NAME}',${INTERNAL_CATEGORY_NAME},
           |        '${OFFRNG_NAME}',${OFFRNG_NAME},
           |        '${OFFRNG_ITM_NAME}',${OFFRNG_ITM_NAME},
           |        '${OFFRNG_CAT_NAME}',${OFFRNG_CAT_NAME},
           |        '${OFFRNG_VNDR_NAME}',${OFFRNG_VNDR_NAME},
           |        '${OFFRNG_VNDR_BRNCH_NAME}',${OFFRNG_VNDR_BRNCH_NAME},
           |        '${OFFRNG_VNDR_BRNCH_STATE_PROVNC_NAME}',${OFFRNG_VNDR_BRNCH_STATE_PROVNC_NAME},
           |        '${OFFRNG_VNDR_BRNCH_CNTRY_NAME}',${OFFRNG_VNDR_BRNCH_CNTRY_NAME},
           |        '${DEST_SERVICES_TCKT_CNT}',cast(${DEST_SERVICES_TCKT_CNT} as int)
           |        ) AS  LX_ITEM,
           |       array(
           |          NAMED_STRUCT('money',NAMED_STRUCT('currency_code',sb.price_currency_code,'currency_type',"local",'amount',cast(sb.base_price_amount_local as decimal(18,2)),'decimal_places',2),'monetary_classification', NAMED_STRUCT('category',"null",'sub_category_1',"null",'sub_category_2',"null"),'monetary_computational_reference',"base_price_amount_local",'monetary_computational_source',"Teradata",'create_date_time',cast(sb.booking_event_date as string),'apply_date',cast(sb.use_date as string), 'imposition_type', cast(' ' as string), 'jurisdiction_level', cast(' ' as string), 'jurisdiction_name', cast(' ' as string)),
           |          NAMED_STRUCT('money',NAMED_STRUCT('currency_code',sb.price_currency_code,'currency_type',"local",'amount',cast(0.00 as decimal(18,2)),'decimal_places',2),'monetary_classification', NAMED_STRUCT('category',"null",'sub_category_1',"null",'sub_category_2',"null"),'monetary_computational_reference',"other_price_adjustment_amount_local",'monetary_computational_source',"Teradata",'create_date_time',cast(sb.booking_event_date as string),'apply_date',cast(sb.use_date as string), 'imposition_type', cast(' ' as string), 'jurisdiction_level', cast(' ' as string), 'jurisdiction_name', cast(' ' as string)),
           |          NAMED_STRUCT('money',NAMED_STRUCT('currency_code',sb.price_currency_code,'currency_type',"local",'amount',cast(0.00 as decimal(18,2)),'decimal_places',2),'monetary_classification', NAMED_STRUCT('category',"null",'sub_category_1',"null",'sub_category_2',"null"),'monetary_computational_reference',"penalty_price_adjustment_amount_local",'monetary_computational_source',"Teradata",'create_date_time',cast(sb.booking_event_date as string),'apply_date',cast(sb.use_date as string), 'imposition_type', cast(' ' as string), 'jurisdiction_level', cast(' ' as string), 'jurisdiction_name', cast(' ' as string)),
           |          NAMED_STRUCT('money',NAMED_STRUCT('currency_code',sb.price_currency_code,'currency_type',"local",'amount',cast(0.00 as decimal(18,2)),'decimal_places',2),'monetary_classification', NAMED_STRUCT('category',"null",'sub_category_1',"null",'sub_category_2',"null"),'monetary_computational_reference',"expedia_penalty_price_adjustment_amount_local",'monetary_computational_source',"Teradata",'create_date_time',cast(sb.booking_event_date as string),'apply_date',cast(sb.use_date as string), 'imposition_type', cast(' ' as string), 'jurisdiction_level', cast(' ' as string), 'jurisdiction_name', cast(' ' as string)),
           |          NAMED_STRUCT('money',NAMED_STRUCT('currency_code',sb.price_currency_code,'currency_type',"local",'amount',cast(sb.total_price_adjustment_amount_local as decimal(18,2)),'decimal_places',2),'monetary_classification', NAMED_STRUCT('category',"null",'sub_category_1',"null",'sub_category_2',"null"),'monetary_computational_reference',"total_price_adjustment_amount_local",'monetary_computational_source',"Teradata",'create_date_time',cast(sb.booking_event_date as string),'apply_date',cast(sb.use_date as string), 'imposition_type', cast(' ' as string), 'jurisdiction_level', cast(' ' as string), 'jurisdiction_name', cast(' ' as string)),
           |          NAMED_STRUCT('money',NAMED_STRUCT('currency_code',sb.price_currency_code,'currency_type',"local",'amount',cast(0.00 as decimal(18,2)),'decimal_places',2),'monetary_classification', NAMED_STRUCT('category',"null",'sub_category_1',"null",'sub_category_2',"null"),'monetary_computational_reference',"service_fee_price_amount_local",'monetary_computational_source',"Teradata",'create_date_time',cast(sb.booking_event_date as string),'apply_date',cast(sb.use_date as string), 'imposition_type', cast(' ' as string), 'jurisdiction_level', cast(' ' as string), 'jurisdiction_name', cast(' ' as string)),
           |          NAMED_STRUCT('money',NAMED_STRUCT('currency_code',sb.price_currency_code,'currency_type',"local",'amount',cast(sb.total_fee_price_amount_local as decimal(18,2)),'decimal_places',2),'monetary_classification', NAMED_STRUCT('category',"null",'sub_category_1',"null",'sub_category_2',"null"),'monetary_computational_reference',"total_fee_price_amount_local",'monetary_computational_source',"Teradata",'create_date_time',cast(sb.booking_event_date as string),'apply_date',cast(sb.use_date as string), 'imposition_type', cast(' ' as string), 'jurisdiction_level', cast(' ' as string), 'jurisdiction_name', cast(' ' as string)),
           |          NAMED_STRUCT('money',NAMED_STRUCT('currency_code',sb.price_currency_code,'currency_type',"local",'amount',cast(sb.total_tax_price_amount_local as decimal(18,2)),'decimal_places',2),'monetary_classification', NAMED_STRUCT('category',"null",'sub_category_1',"null",'sub_category_2',"null"),'monetary_computational_reference',"total_tax_price_amount_local",'monetary_computational_source',"Teradata",'create_date_time',cast(sb.booking_event_date as string),'apply_date',cast(sb.use_date as string), 'imposition_type', cast(' ' as string), 'jurisdiction_level', cast(' ' as string), 'jurisdiction_name', cast(' ' as string)),
           |          NAMED_STRUCT('money',NAMED_STRUCT('currency_code',sb.price_currency_code,'currency_type',"local",'amount',cast(0.00 as decimal(18,2)),'decimal_places',2),'monetary_classification', NAMED_STRUCT('category',"null",'sub_category_1',"null",'sub_category_2',"null"),'monetary_computational_reference',"service_charge_price_amount_local",'monetary_computational_source',"Teradata",'create_date_time',cast(sb.booking_event_date as string),'apply_date',cast(sb.use_date as string), 'imposition_type', cast(' ' as string), 'jurisdiction_level', cast(' ' as string), 'jurisdiction_name', cast(' ' as string)),
           |          NAMED_STRUCT('money',NAMED_STRUCT('currency_code',sb.price_currency_code,'currency_type',"local",'amount',cast(0.00 as decimal(18,2)),'decimal_places',2),'monetary_classification', NAMED_STRUCT('category',"null",'sub_category_1',"null",'sub_category_2',"null"),'monetary_computational_reference',"cancel_change_fee_price_amount_local",'monetary_computational_source',"Teradata",'create_date_time',cast(sb.booking_event_date as string),'apply_date',cast(sb.use_date as string), 'imposition_type', cast(' ' as string), 'jurisdiction_level', cast(' ' as string), 'jurisdiction_name', cast(' ' as string)),
           |          NAMED_STRUCT('money',NAMED_STRUCT('currency_code',sb.price_currency_code,'currency_type',"local",'amount',cast(sb.gross_booking_amount_local as decimal(18,2)),'decimal_places',2),'monetary_classification', NAMED_STRUCT('category',"null",'sub_category_1',"null",'sub_category_2',"null"),'monetary_computational_reference',"gross_booking_amount_local",'monetary_computational_source',"Teradata",'create_date_time',cast(sb.booking_event_date as string),'apply_date',cast(sb.use_date as string), 'imposition_type', cast(' ' as string), 'jurisdiction_level', cast(' ' as string), 'jurisdiction_name', cast(' ' as string)),
           |          NAMED_STRUCT('money',NAMED_STRUCT('currency_code',sb.price_currency_code,'currency_type',"local",'amount',cast(sb.coupon_price_amount_local as decimal(18,2)),'decimal_places',2),'monetary_classification', NAMED_STRUCT('category',"null",'sub_category_1',"null",'sub_category_2',"null"),'monetary_computational_reference',"coupon_price_amount_local",'monetary_computational_source',"Teradata",'create_date_time',cast(sb.booking_event_date as string),'apply_date',cast(sb.use_date as string), 'imposition_type', cast(' ' as string), 'jurisdiction_level', cast(' ' as string), 'jurisdiction_name', cast(' ' as string)),
           |          NAMED_STRUCT('money',NAMED_STRUCT('currency_code',sb.price_currency_code,'currency_type',"local",'amount',cast(0.00 as decimal(18,2)),'decimal_places',2),'monetary_classification', NAMED_STRUCT('category',"null",'sub_category_1',"null",'sub_category_2',"null"),'monetary_computational_reference',"expedia_goodwill_price_adjustment_amount_local",'monetary_computational_source',"Teradata",'create_date_time',cast(sb.booking_event_date as string),'apply_date',cast(sb.use_date as string), 'imposition_type', cast(' ' as string), 'jurisdiction_level', cast(' ' as string), 'jurisdiction_name', cast(' ' as string)),
           |          NAMED_STRUCT('money',NAMED_STRUCT('currency_code',sb.price_currency_code,'currency_type',"local",'amount',cast(0.00 as decimal(18,2)),'decimal_places',2),'monetary_classification', NAMED_STRUCT('category',"null",'sub_category_1',"null",'sub_category_2',"null"),'monetary_computational_reference',"goodwill_price_adjustment_amount_local",'monetary_computational_source',"Teradata",'create_date_time',cast(sb.booking_event_date as string),'apply_date',cast(sb.use_date as string), 'imposition_type', cast(' ' as string), 'jurisdiction_level', cast(' ' as string), 'jurisdiction_name', cast(' ' as string)),
           |          NAMED_STRUCT('money',NAMED_STRUCT('currency_code',sb.price_currency_code,'currency_type',"local",'amount',cast(0.00 as decimal(18,2)),'decimal_places',2),'monetary_classification', NAMED_STRUCT('category',"null",'sub_category_1',"null",'sub_category_2',"null"),'monetary_computational_reference',"generic_coupon_price_amount_local",'monetary_computational_source',"Teradata",'create_date_time',cast(sb.booking_event_date as string),'apply_date',cast(sb.use_date as string), 'imposition_type', cast(' ' as string), 'jurisdiction_level', cast(' ' as string), 'jurisdiction_name', cast(' ' as string)),
           |          NAMED_STRUCT('money',NAMED_STRUCT('currency_code',sb.price_currency_code,'currency_type',"local",'amount',cast(0.00 as decimal(18,2)),'decimal_places',2),'monetary_classification', NAMED_STRUCT('category',"null",'sub_category_1',"null",'sub_category_2',"null"),'monetary_computational_reference',"refund_price_adjustment_amount_local",'monetary_computational_source',"Teradata",'create_date_time',cast(sb.booking_event_date as string),'apply_date',cast(sb.use_date as string), 'imposition_type', cast(' ' as string), 'jurisdiction_level', cast(' ' as string), 'jurisdiction_name', cast(' ' as string)),
           |          NAMED_STRUCT('money',NAMED_STRUCT('currency_code',sb.price_currency_code,'currency_type',"local",'amount',cast(0.00 as decimal(18,2)),'decimal_places',2),'monetary_classification', NAMED_STRUCT('category',"null",'sub_category_1',"null",'sub_category_2',"null"),'monetary_computational_reference',"rebate_price_amount_local",'monetary_computational_source',"Teradata",'create_date_time',cast(sb.booking_event_date as string),'apply_date',cast(sb.use_date as string), 'imposition_type', cast(' ' as string), 'jurisdiction_level', cast(' ' as string), 'jurisdiction_name', cast(' ' as string)),
           |          NAMED_STRUCT('money',NAMED_STRUCT('currency_code',sb.price_currency_code,'currency_type',"local",'amount',cast(0.00 as decimal(18,2)),'decimal_places',2),'monetary_classification', NAMED_STRUCT('category',"null",'sub_category_1',"null",'sub_category_2',"null"),'monetary_computational_reference',"tcm_price_adjustment_amount_local",'monetary_computational_source',"Teradata",'create_date_time',cast(sb.booking_event_date as string),'apply_date',cast(sb.use_date as string), 'imposition_type', cast(' ' as string), 'jurisdiction_level', cast(' ' as string), 'jurisdiction_name', cast(' ' as string)),
           |          NAMED_STRUCT('money',NAMED_STRUCT('currency_code',sb.price_currency_code,'currency_type',"local",'amount',cast(0.00 as decimal(18,2)),'decimal_places',2),'monetary_classification', NAMED_STRUCT('category',"null",'sub_category_1',"null",'sub_category_2',"null"),'monetary_computational_reference',"cancel_penalty_waiver_price_adjustment_amount_local",'monetary_computational_source',"Teradata",'create_date_time',cast(sb.booking_event_date as string),'apply_date',cast(sb.use_date as string), 'imposition_type', cast(' ' as string), 'jurisdiction_level', cast(' ' as string), 'jurisdiction_name', cast(' ' as string)),
           |          NAMED_STRUCT('money',NAMED_STRUCT('currency_code',sb.price_currency_code,'currency_type',"local",'amount',cast(0.00 as decimal(18,2)),'decimal_places',2),'monetary_classification', NAMED_STRUCT('category',"null",'sub_category_1',"null",'sub_category_2',"null"),'monetary_computational_reference',"loyalty_point_price_adjustment_amount_local",'monetary_computational_source',"Teradata",'create_date_time',cast(sb.booking_event_date as string),'apply_date',cast(sb.use_date as string), 'imposition_type', cast(' ' as string), 'jurisdiction_level', cast(' ' as string), 'jurisdiction_name', cast(' ' as string)),
           |          NAMED_STRUCT('money',NAMED_STRUCT('currency_code',sb.price_currency_code,'currency_type',"local",'amount',cast(0.00 as decimal(18,2)),'decimal_places',2),'monetary_classification', NAMED_STRUCT('category',"null",'sub_category_1',"null",'sub_category_2',"null"),'monetary_computational_reference',"employee_discount_price_adjustment_amount_local",'monetary_computational_source',"Teradata",'create_date_time',cast(sb.booking_event_date as string),'apply_date',cast(sb.use_date as string), 'imposition_type', cast(' ' as string), 'jurisdiction_level', cast(' ' as string), 'jurisdiction_name', cast(' ' as string)),
           |          NAMED_STRUCT('money',NAMED_STRUCT('currency_code',sb.price_currency_code,'currency_type',"local",'amount',cast(0.00 as decimal(18,2)),'decimal_places',2),'monetary_classification', NAMED_STRUCT('category',"null",'sub_category_1',"null",'sub_category_2',"null"),'monetary_computational_reference',"supplier_reconciliation_price_adjustment_amount_local",'monetary_computational_source',"Teradata",'create_date_time',cast(sb.booking_event_date as string),'apply_date',cast(sb.use_date as string), 'imposition_type', cast(' ' as string), 'jurisdiction_level', cast(' ' as string), 'jurisdiction_name', cast(' ' as string)),
           |          NAMED_STRUCT('money',NAMED_STRUCT('currency_code',sb.price_currency_code,'currency_type',"local",'amount',cast(0.00 as decimal(18,2)),'decimal_places',2),'monetary_classification', NAMED_STRUCT('category',"null",'sub_category_1',"null",'sub_category_2',"null"),'monetary_computational_reference',"other_fee_price_amount_local",'monetary_computational_source',"Teradata",'create_date_time',cast(sb.booking_event_date as string),'apply_date',cast(sb.use_date as string), 'imposition_type', cast(' ' as string), 'jurisdiction_level', cast(' ' as string), 'jurisdiction_name', cast(' ' as string)),
           |          NAMED_STRUCT('money',NAMED_STRUCT('currency_code',sb.price_currency_code,'currency_type',"local",'amount',cast(0.00 as decimal(18,2)),'decimal_places',2),'monetary_classification', NAMED_STRUCT('category',"null",'sub_category_1',"null",'sub_category_2',"null"),'monetary_computational_reference',"agent_assisted_purchase_fee_amount_local",'monetary_computational_source',"Teradata",'create_date_time',cast(sb.booking_event_date as string),'apply_date',cast(sb.use_date as string), 'imposition_type', cast(' ' as string), 'jurisdiction_level', cast(' ' as string), 'jurisdiction_name', cast(' ' as string)),
           |          NAMED_STRUCT('money',NAMED_STRUCT('currency_code',sb.cost_currency_code,'currency_type',"local",'amount',cast(sb.total_cost_amount_local as decimal(18,2)),'decimal_places',2),'monetary_classification', NAMED_STRUCT('category',"null",'sub_category_1',"null",'sub_category_2',"null"),'monetary_computational_reference',"total_cost_amount_local",'monetary_computational_source',"Teradata",'create_date_time',cast(sb.booking_event_date as string),'apply_date',cast(sb.use_date as string), 'imposition_type', cast(' ' as string), 'jurisdiction_level', cast(' ' as string), 'jurisdiction_name', cast(' ' as string)),
           |          NAMED_STRUCT('money',NAMED_STRUCT('currency_code',sb.cost_currency_code,'currency_type',"local",'amount',cast(sb.base_cost_amount_local as decimal(18,2)),'decimal_places',2),'monetary_classification', NAMED_STRUCT('category',"null",'sub_category_1',"null",'sub_category_2',"null"),'monetary_computational_reference',"base_cost_amount_local",'monetary_computational_source',"Teradata",'create_date_time',cast(sb.booking_event_date as string),'apply_date',cast(sb.use_date as string), 'imposition_type', cast(' ' as string), 'jurisdiction_level', cast(' ' as string), 'jurisdiction_name', cast(' ' as string)),
           |          NAMED_STRUCT('money',NAMED_STRUCT('currency_code',sb.cost_currency_code,'currency_type',"local",'amount',cast(sb.total_cost_adjustment_amount_local as decimal(18,2)),'decimal_places',2),'monetary_classification', NAMED_STRUCT('category',"null",'sub_category_1',"null",'sub_category_2',"null"),'monetary_computational_reference',"total_cost_adjustment_amount_local",'monetary_computational_source',"Teradata",'create_date_time',cast(sb.booking_event_date as string),'apply_date',cast(sb.use_date as string), 'imposition_type', cast(' ' as string), 'jurisdiction_level', cast(' ' as string), 'jurisdiction_name', cast(' ' as string)),
           |          NAMED_STRUCT('money',NAMED_STRUCT('currency_code',sb.cost_currency_code,'currency_type',"local",'amount',cast(0.00 as decimal(18,2)),'decimal_places',2),'monetary_classification', NAMED_STRUCT('category',"null",'sub_category_1',"null",'sub_category_2',"null"),'monetary_computational_reference',"supplier_cost_adjustment_amount_local",'monetary_computational_source',"Teradata",'create_date_time',cast(sb.booking_event_date as string),'apply_date',cast(sb.use_date as string), 'imposition_type', cast(' ' as string), 'jurisdiction_level', cast(' ' as string), 'jurisdiction_name', cast(' ' as string)),
           |          NAMED_STRUCT('money',NAMED_STRUCT('currency_code',sb.cost_currency_code,'currency_type',"local",'amount',cast(0.00 as decimal(18,2)),'decimal_places',2),'monetary_classification', NAMED_STRUCT('category',"null",'sub_category_1',"null",'sub_category_2',"null"),'monetary_computational_reference',"eca_cost_adjustment_amount_local",'monetary_computational_source',"Teradata",'create_date_time',cast(sb.booking_event_date as string),'apply_date',cast(sb.use_date as string), 'imposition_type', cast(' ' as string), 'jurisdiction_level', cast(' ' as string), 'jurisdiction_name', cast(' ' as string)),
           |          NAMED_STRUCT('money',NAMED_STRUCT('currency_code',sb.cost_currency_code,'currency_type',"local",'amount',cast(0.00 as decimal(18,2)),'decimal_places',2),'monetary_classification', NAMED_STRUCT('category',"null",'sub_category_1',"null",'sub_category_2',"null"),'monetary_computational_reference',"other_cost_adjustment_amount_local",'monetary_computational_source',"Teradata",'create_date_time',cast(sb.booking_event_date as string),'apply_date',cast(sb.use_date as string), 'imposition_type', cast(' ' as string), 'jurisdiction_level', cast(' ' as string), 'jurisdiction_name', cast(' ' as string)),
           |          NAMED_STRUCT('money',NAMED_STRUCT('currency_code',sb.cost_currency_code,'currency_type',"local",'amount',cast(0.00 as decimal(18,2)),'decimal_places',2),'monetary_classification', NAMED_STRUCT('category',"null",'sub_category_1',"null",'sub_category_2',"null"),'monetary_computational_reference',"variable_margin_cost_adjustment_amount_local",'monetary_computational_source',"Teradata",'create_date_time',cast(sb.booking_event_date as string),'apply_date',cast(sb.use_date as string), 'imposition_type', cast(' ' as string), 'jurisdiction_level', cast(' ' as string), 'jurisdiction_name', cast(' ' as string)),
           |          NAMED_STRUCT('money',NAMED_STRUCT('currency_code',sb.cost_currency_code,'currency_type',"local",'amount',cast(0.00 as decimal(18,2)),'decimal_places',2),'monetary_classification', NAMED_STRUCT('category',"null",'sub_category_1',"null",'sub_category_2',"null"),'monetary_computational_reference',"supplier_reconciliation_cost_adjustment_local",'monetary_computational_source',"Teradata",'create_date_time',cast(sb.booking_event_date as string),'apply_date',cast(sb.use_date as string), 'imposition_type', cast(' ' as string), 'jurisdiction_level', cast(' ' as string), 'jurisdiction_name', cast(' ' as string)),
           |          NAMED_STRUCT('money',NAMED_STRUCT('currency_code',sb.cost_currency_code,'currency_type',"local",'amount',cast(sb.total_fee_cost_amount_local as decimal(18,2)),'decimal_places',2),'monetary_classification', NAMED_STRUCT('category',"null",'sub_category_1',"null",'sub_category_2',"null"),'monetary_computational_reference',"total_fee_cost_amount_local",'monetary_computational_source',"Teradata",'create_date_time',cast(sb.booking_event_date as string),'apply_date',cast(sb.use_date as string), 'imposition_type', cast(' ' as string), 'jurisdiction_level', cast(' ' as string), 'jurisdiction_name', cast(' ' as string)),
           |          NAMED_STRUCT('money',NAMED_STRUCT('currency_code',sb.cost_currency_code,'currency_type',"local",'amount',cast(0.00 as decimal(18,2)),'decimal_places',2),'monetary_classification', NAMED_STRUCT('category',"null",'sub_category_1',"null",'sub_category_2',"null"),'monetary_computational_reference',"service_charge_cost_amount_local",'monetary_computational_source',"Teradata",'create_date_time',cast(sb.booking_event_date as string),'apply_date',cast(sb.use_date as string), 'imposition_type', cast(' ' as string), 'jurisdiction_level', cast(' ' as string), 'jurisdiction_name', cast(' ' as string)),
           |          NAMED_STRUCT('money',NAMED_STRUCT('currency_code',sb.cost_currency_code,'currency_type',"local",'amount',cast(0.00 as decimal(18,2)),'decimal_places',2),'monetary_classification', NAMED_STRUCT('category',"null",'sub_category_1',"null",'sub_category_2',"null"),'monetary_computational_reference',"other_fee_cost_amount_local",'monetary_computational_source',"Teradata",'create_date_time',cast(sb.booking_event_date as string),'apply_date',cast(sb.use_date as string), 'imposition_type', cast(' ' as string), 'jurisdiction_level', cast(' ' as string), 'jurisdiction_name', cast(' ' as string)),
           |          NAMED_STRUCT('money',NAMED_STRUCT('currency_code',sb.cost_currency_code,'currency_type',"local",'amount',cast(0.00 as decimal(18,2)),'decimal_places',2),'monetary_classification', NAMED_STRUCT('category',"null",'sub_category_1',"null",'sub_category_2',"null"),'monetary_computational_reference',"eca_fee_cost_amount_local",'monetary_computational_source',"Teradata",'create_date_time',cast(sb.booking_event_date as string),'apply_date',cast(sb.use_date as string), 'imposition_type', cast(' ' as string), 'jurisdiction_level', cast(' ' as string), 'jurisdiction_name', cast(' ' as string)),
           |          NAMED_STRUCT('money',NAMED_STRUCT('currency_code',sb.cost_currency_code,'currency_type',"local",'amount',cast(sb.total_tax_cost_amount_local as decimal(18,2)),'decimal_places',2),'monetary_classification', NAMED_STRUCT('category',"null",'sub_category_1',"null",'sub_category_2',"null"),'monetary_computational_reference',"total_tax_cost_amount_local",'monetary_computational_source',"Teradata",'create_date_time',cast(sb.booking_event_date as string),'apply_date',cast(sb.use_date as string), 'imposition_type', cast(' ' as string), 'jurisdiction_level', cast(' ' as string), 'jurisdiction_name', cast(' ' as string)),
           |          NAMED_STRUCT('money',NAMED_STRUCT('currency_code',sb.cost_currency_code,'currency_type',"local",'amount',cast(0.00 as decimal(18,2)),'decimal_places',2),'monetary_classification', NAMED_STRUCT('category',"null",'sub_category_1',"null",'sub_category_2',"null"),'monetary_computational_reference',"variable_margin_credit_local",'monetary_computational_source',"Teradata",'create_date_time',cast(sb.booking_event_date as string),'apply_date',cast(sb.use_date as string), 'imposition_type', cast(' ' as string), 'jurisdiction_level', cast(' ' as string), 'jurisdiction_name', cast(' ' as string)),
           |          NAMED_STRUCT('money',NAMED_STRUCT('currency_code',sb.cost_currency_code,'currency_type',"local",'amount',cast(0.00 as decimal(18,2)),'decimal_places',2),'monetary_classification', NAMED_STRUCT('category',"null",'sub_category_1',"null",'sub_category_2',"null"),'monetary_computational_reference',"extra_person_cost_amount_local",'monetary_computational_source',"Teradata",'create_date_time',cast(sb.booking_event_date as string),'apply_date',cast(sb.use_date as string), 'imposition_type', cast(' ' as string), 'jurisdiction_level', cast(' ' as string), 'jurisdiction_name', cast(' ' as string)),
           |          NAMED_STRUCT('money',NAMED_STRUCT('currency_code',sb.cost_currency_code,'currency_type',"local",'amount',cast(0.00 as decimal(18,2)),'decimal_places',2),'monetary_classification', NAMED_STRUCT('category',"null",'sub_category_1',"null",'sub_category_2',"null"),'monetary_computational_reference',"rate_plan_restriction_cost_amount_local",'monetary_computational_source',"Teradata",'create_date_time',cast(sb.booking_event_date as string),'apply_date',cast(sb.use_date as string), 'imposition_type', cast(' ' as string), 'jurisdiction_level', cast(' ' as string), 'jurisdiction_name', cast(' ' as string)),
           |          NAMED_STRUCT('money',NAMED_STRUCT('currency_code',sb.cost_currency_code,'currency_type',"local",'amount',cast(0.00 as decimal(18,2)),'decimal_places',2),'monetary_classification', NAMED_STRUCT('category',"null",'sub_category_1',"null",'sub_category_2',"null"),'monetary_computational_reference',"single_supplement_cost_amount_local",'monetary_computational_source',"Teradata",'create_date_time',cast(sb.booking_event_date as string),'apply_date',cast(sb.use_date as string), 'imposition_type', cast(' ' as string), 'jurisdiction_level', cast(' ' as string), 'jurisdiction_name', cast(' ' as string)),
           |          NAMED_STRUCT('money',NAMED_STRUCT('currency_code',sb.cost_currency_code,'currency_type',"local",'amount',cast(0.00 as decimal(18,2)),'decimal_places',2),'monetary_classification', NAMED_STRUCT('category',"null",'sub_category_1',"null",'sub_category_2',"null"),'monetary_computational_reference',"dynamic_rate_rule_cost_amount_local",'monetary_computational_source',"Teradata",'create_date_time',cast(sb.booking_event_date as string),'apply_date',cast(sb.use_date as string), 'imposition_type', cast(' ' as string), 'jurisdiction_level', cast(' ' as string), 'jurisdiction_name', cast(' ' as string)),
           |          NAMED_STRUCT('money',NAMED_STRUCT('currency_code',sb.cost_currency_code,'currency_type',"local",'amount',cast(0.00 as decimal(18,2)),'decimal_places',2),'monetary_classification', NAMED_STRUCT('category',"null",'sub_category_1',"null",'sub_category_2',"null"),'monetary_computational_reference',"tax_due_amount",'monetary_computational_source',"Teradata",'create_date_time',cast(sb.booking_event_date as string),'apply_date',cast(sb.use_date as string), 'imposition_type', cast(' ' as string), 'jurisdiction_level', cast(' ' as string), 'jurisdiction_name', cast(' ' as string))
           |       ) as ${LOCAL_AMOUNTS_COLUMN},
           |		case
           |             when
           |                ${BOOKING_ITEM_ID_EXCEPTION_COLUMN} is null
           |                and ${BOOKING_ID_EXCEPTION_COLUMN} is null
           |                and ${BOOK_DATE_EXCEPTION_COLUMN} is null
           |                and ${BOOKING_EVENT_DATE_EXCEPTION_COLUMN} is null
           |                and ${SOURCE_SYSTEM_ID_EXCEPTION_COLUMN} is null
           |                and ${COST_CURRENCY_CODE_EXCEPTION_COLUMN} is null
           |                and ${TRANSACTION_TYPE_KEY_EXCEPTION_COLUMN} is null
           |                and ${USE_DATE_EXCEPTION_COLUMN_NAME} is null
           |                and ${BEGIN_USE_DATE_EXCEPTION_COLUMN} is null
           |                and ${END_USE_DATE_EXCEPTION_COLUMN} is null
           |                and ${BOOKING_EVENT_DATETIME_EXCEPTION_COLUMN} is null
           |                and ${TRANS_TYPE_NAME_EXCEPTION_COLUMN} is null
           |            then
           |                 null
           |            else
           |                 ARRAY( ${BOOK_DATE_EXCEPTION_COLUMN}
           |                    ,${BOOKING_ITEM_ID_EXCEPTION_COLUMN}
           |                    ,${BOOKING_ID_EXCEPTION_COLUMN}
           |                    ,${BOOKING_EVENT_DATE_EXCEPTION_COLUMN}
           |                    ,${SOURCE_SYSTEM_ID_EXCEPTION_COLUMN}
           |                    ,${COST_CURRENCY_CODE_EXCEPTION_COLUMN}
           |                    ,${TRANSACTION_TYPE_KEY_EXCEPTION_COLUMN}
           |                    ,${USE_DATE_EXCEPTION_COLUMN_NAME}
           |                    ,${BEGIN_USE_DATE_EXCEPTION_COLUMN}
           |                    ,${END_USE_DATE_EXCEPTION_COLUMN}
           |                    ,${BOOKING_EVENT_DATETIME_EXCEPTION_COLUMN}
           |                    ,${TRANS_TYPE_NAME_EXCEPTION_COLUMN})
           |          end
           |            as ${EXCEPTIONS_COLUMN},
           NAMED_STRUCT(
           |          '${PARTNER_ID}', cast(' ' as string),
           |          '${PARTNER_NAME}', cast(' ' as string),
           |          '${PARTNER_ADDRESS}', NAMED_STRUCT(
           |            '${PARTNER_ADDRESS_LINE_1}', cast(' ' as string),
           |            '${PARTNER_ADDRESS_LINE_2}', cast(' ' as string),
           |            '${PARTNER_CITY}', cast(' ' as string),
           |            '${PARTNER_STATE}', cast(' ' as string),
           |            '${PARTNER_POSTAL_CODE}', cast(' ' as string),
           |            '${PARTNER_COUNTRY_CODE}', cast(' ' as string),
           |            '${PARTNER_DISTRICT}', cast(' ' as string),
           |            '${PARTNER_COUNTY}', cast(' ' as string),
           |            '${PARTNER_ADDRESS_TYPE}', cast(' ' as string),
           |            '${PARTNER_LATITUDE}', cast(' ' as string),
           |            '${PARTNER_LONGITUDE}', cast(' ' as string)
           |          ),
           |          '${PARTNER_ATTRIBUTES}', MAP()
           |        ) AS ${PARTNER_ITEM},
           |        CASE
           |            WHEN dbt.pl_dummy is null
           |            THEN dbt.bk_dummy -- it should be always null
           |        END AS ${BOOKING_HISTORY_COLUMN},
           |        ${TRANSACTION_LIABILITY_DATE_COLUMN},
           |        ${TRANSACTION_LIABILITY_DATE_TYPE_COLUMN},
           |        ${PRODUCT_LINE_NAME_COLUMN}
           """.stripMargin
}
