package com.expediagroup.platform.taxcompliance.util

import com.expediagroup.finance.tax.amounts.v1.TaxEngineConfigRule
import com.expediagroup.platform.taxcompliance.cases.VrboLegalEntityMapping
import com.expediagroup.platform.taxcompliance.config.{AmountCase, MonetaryClassificationCase, MoneyCase, BookingHistoryCase}
import com.expediagroup.platform.taxcompliance.constants.{BusinessConstants, ExcludedMonetaryCategoryConstants}
import com.expediagroup.platform.taxcompliance.fileupload.TransactionTypeNameHelper.transactionTypeNameMap
import com.expediagroup.platform.taxcompliance.sql.SQLColumnHelper
import com.fasterxml.jackson.databind.ObjectMapper
import com.fasterxml.jackson.module.scala.DefaultScalaModule
import com.fasterxml.jackson.module.scala.experimental.ScalaObjectMapper
import org.apache.commons.io.IOUtils
import org.apache.spark.sql.catalyst.expressions.GenericRowWithSchema
import org.apache.spark.sql.functions.{col, lit, udf, when}
import org.apache.spark.sql.types._
import org.apache.spark.sql.{DataFrame, SparkSession}
import org.slf4j.LoggerFactory

import java.math.{BigDecimal, RoundingMode}
import java.sql.{Date => SqlDate}
import java.text.SimpleDateFormat
import java.time.{Instant, LocalDate, ZoneId}
import java.time.format.DateTimeFormatter
import java.time.temporal.ChronoUnit
import java.util.{Calendar, Date, TimeZone}
import scala.collection.mutable
import scala.math.BigDecimal.javaBigDecimal2bigDecimal
import scala.util.Try

object DataUtil {

    private val logger = LoggerFactory.getLogger(this.getClass)
    val ZERO_AMOUNT: BigDecimal = BigDecimal.valueOf(0.0000).setScale(4)

    val formEventUUID = udf{ (eventUUID : String) =>
        import java.math.BigInteger
        import java.security.MessageDigest
        val md = MessageDigest.getInstance("MD5")
        val digest = md.digest(eventUUID.getBytes)
        val bigInt = new BigInteger(1,digest)
        val hashedString = bigInt.toString(16)
        stringToUUID(hashedString)
    }

    val formUUID4 = udf{ () =>
        java.util.UUID.randomUUID().toString
    }

    def buildMapFromAmountArray=udf((list1:Seq[String],list2:Seq[java.math.BigDecimal]) => {
        val zipList = (list1 zip list2).toMap
        zipList
    })

    def stringToUUID(uuid: String): String = {
        java.util.UUID.fromString(
            uuid
                .replaceFirst(
                    "(\\p{XDigit}{8})(\\p{XDigit}{4})(\\p{XDigit}{4})(\\p{XDigit}{4})(\\p{XDigit}+)", "$1-$2-$3-$4-$5"
                )
        ).toString
    }

    def getCurrentDateTimeInPst = {
        val date = new Date()
        val format = new SimpleDateFormat("yyyy-MM-dd HH:mm:ss.SS")
        format.setTimeZone(TimeZone.getTimeZone("PST"))
        val etlDateTime = format.format(date)
        etlDateTime
    }

    def convertUtcDateTimeToPstDate(datetimeUtc: String) = {
        val format = new SimpleDateFormat("yyyy-MM-dd HH:mm:ss.SS")
        format.setTimeZone(TimeZone.getTimeZone("UTC"))
        val dateUtc = format.parse(datetimeUtc)
        val dateFormat = new SimpleDateFormat("yyyy-MM-dd")
        dateFormat.setTimeZone(TimeZone.getTimeZone("PST"))
        val dateStringInPst = dateFormat.format(dateUtc)
        dateStringInPst
    }

    def convertDateTimeToPstDate(dateTime: String): String =  {
        val format = new SimpleDateFormat("yyyy-MM-dd HH:mm:ss.SS")
        format.setTimeZone(TimeZone.getTimeZone("PST"))
        val date = format.parse(dateTime)
        val dateFormat = new SimpleDateFormat("yyyy-MM-dd")
        dateFormat.setTimeZone(TimeZone.getTimeZone("PST"))
        val dateStringInPst = dateFormat.format(date)
        dateStringInPst
    }

    def getPreviousDayDate(date: String): String =  {
        val format = new SimpleDateFormat("yyyy-MM-dd")
        val calender = Calendar.getInstance()
        calender.setTime(format.parse(date))
        calender.add(Calendar.DATE, -1)
        val previousDate = format.format(calender.getTime())
        previousDate
    }

    def getPartitionDetailsForGivenDateRange(startDate: String, endDate:String, productLineName:String,
                                             transactionLiabilityDateType:String): String ={
        import java.time.format.DateTimeFormatter
        val builder = new StringBuilder
        val start: LocalDate = LocalDate.parse(startDate)
        val end = LocalDate.parse(endDate)
        var processedDate = start
        while (processedDate.isBefore(end) || processedDate.equals(end)) {
            builder.append("PARTITION (")
                .append(SQLColumnHelper.TRANSACTION_LIABILITY_DATE)
                .append("=")
                .append("'"+processedDate.format(DateTimeFormatter.ISO_DATE)+"', ")
                .append(SQLColumnHelper.TRANSACTION_LIABILITY_DATE_TYPE)
                .append("='")
                .append(transactionLiabilityDateType)
                .append("', ")
                .append(SQLColumnHelper.PRODUCT_LINE_NAME)
                .append("='")
                .append(productLineName.split(' ').map(_.capitalize).mkString(" "))
                .append("')")
            if(!processedDate.equals(end)){
                builder.append(",")
            }
            processedDate = processedDate.plusDays(1)
        }
        builder.toString()
    }

    def getPartitionDetailsForGivenDateArray(transLiabDates: Array[String], productLineName: String,
                                             transactionLiabilityDateType:String) : String ={
        import java.time.format.DateTimeFormatter
        val builder = new StringBuilder

        var i = 1
        for(transLiabDate:String <- transLiabDates){
            val processedDate = LocalDate.parse(transLiabDate)
            builder.append("PARTITION (")
                .append(SQLColumnHelper.TRANSACTION_LIABILITY_DATE)
                .append("=")
                .append("'"+processedDate.format(DateTimeFormatter.ISO_DATE)+"', ")
                .append(SQLColumnHelper.TRANSACTION_LIABILITY_DATE_TYPE)
                .append("='")
                .append(transactionLiabilityDateType)
                .append("', ")
                .append(SQLColumnHelper.PRODUCT_LINE_NAME)
                .append("='")
                .append(productLineName.split(' ').map(_.capitalize).mkString(" "))
                .append("')")
            if(i < transLiabDates.length){
                builder.append(",")
            }
            i = i + 1
        }
        builder.toString()
    }

    private def calculateRoomNightCount(beginUseDate: String, endUseDate: String) : Long = {
        try{
            val dateFormat = DateTimeFormatter.ofPattern("uuuu-MM-dd")
            val beginUseDateDF = LocalDate.parse(beginUseDate, dateFormat)
            val endUseDateDF = LocalDate.parse(endUseDate, dateFormat)
            val totalRoomNightCount = ChronoUnit.DAYS.between(beginUseDateDF, endUseDateDF)
            totalRoomNightCount
        }catch{
            case e: Exception => {
                logger.info("Invalid date format: "+e.getMessage())
                0
            }
        }
    }

    val getTotalRentalDayCount = udf ((beginUseDate: String, endUseDate: String) => {
        calculateTotalRentalDayCount(beginUseDate, endUseDate)
    })

    private def calculateTotalRentalDayCount(beginUseDate: String, endUseDate: String) : Long = {
        try{
            val dateFormat = DateTimeFormatter.ofPattern("uuuu-MM-dd")
            val beginUseDateDF = LocalDate.parse(beginUseDate, dateFormat)
            val endUseDateDF = LocalDate.parse(endUseDate, dateFormat)
            val totalRentalDayCount = ChronoUnit.DAYS.between(beginUseDateDF, endUseDateDF)
            if(totalRentalDayCount == 0L) return 1L
            totalRentalDayCount
        }catch{
            case e: Exception => {
                logger.info("Invalid date format: "+e.getMessage())
                0
            }
        }
    }

    val getValidGeocodeFromProductCatalog = udf((attrib: Seq[GenericRowWithSchema]) => {
        getValidGeocode(attrib)
    })

    protected[util] def getValidGeocode(attributes: Seq[GenericRowWithSchema]): String = {
        var geocode: String = null
        if (attributes != null) {
            val activeOverridenGeocode = attributes.filter(att => {
                att.getAs[String]("name") == "geocode" &&
                    att.getAs[Boolean]("isoverride") &&
                    att.getAs[String]("end_date") == null
            })
            if (activeOverridenGeocode.nonEmpty) {
                geocode = activeOverridenGeocode.head.getAs[Seq[String]]("values").head
            } else {
                val nonOverridenGeocode = attributes.filter(att => {
                    att.getAs[String]("name") == "geocode" &&
                        !att.getAs[Boolean]("isoverride")
                })
                if (nonOverridenGeocode.nonEmpty) {
                    geocode = nonOverridenGeocode.head.getAs[Seq[String]]("values").head
                }
            }
        }
        geocode
    }

    val getTotalRoomNightCount = udf ((beginUseDate: String, endUseDate: String) => {
        calculateRoomNightCount(beginUseDate, endUseDate)
    })

    private def calculateNightNumber(beginUseDate: String, endUseDate: String, stayDate: String) : Long = {
        try {
            var nightNumber: Long = 0
            val dateFormat = DateTimeFormatter.ofPattern("uuuu-MM-dd")
            val beginUseDateDF = LocalDate.parse(beginUseDate, dateFormat)
            val endUseDateDF = LocalDate.parse(endUseDate, dateFormat)
            val stayDateDF = LocalDate.parse(stayDate, dateFormat)
            val numOfDaysBetween: Long = ChronoUnit.DAYS.between(beginUseDateDF, endUseDateDF)
            for( a <- 0 to numOfDaysBetween.toInt-1){
                if(stayDateDF.equals(beginUseDateDF.plusDays(a))) {
                    nightNumber = a+1
                }
            }
            nightNumber
        } catch {
            case e: Exception => {
                logger.info("Invalid date format: "+e.getMessage())
                0
            }
        }
    }

    val computeNightNumber = udf((beginUseDate: String, endUseDate: String, stayDate: String) => {
        calculateNightNumber(beginUseDate, endUseDate, stayDate)
    })

    private def calculateRentalNightNumber(beginUseDate: String, endUseDate: String, stayDate: String) : Long = {
        try{
            var nightNumber: Long = 0
            val dateFormat = DateTimeFormatter.ofPattern("uuuu-MM-dd")
            val beginUseDateDF = LocalDate.parse(beginUseDate, dateFormat)
            val endUseDateDF = LocalDate.parse(endUseDate, dateFormat)
            val stayDateDF = LocalDate.parse(stayDate, dateFormat)
            val numOfDaysBetween: Long = ChronoUnit.DAYS.between(beginUseDateDF, endUseDateDF)
            if(numOfDaysBetween == 0L) return 1L
            for( a <- 0 to numOfDaysBetween.toInt-1){
                if(stayDateDF.equals(beginUseDateDF.plusDays(a))) {
                    nightNumber = a+1
                }
            }
            nightNumber
        }catch{
            case e: Exception => {
                logger.info("Invalid date format: "+e.getMessage())
                0
            }
        }
    }

    val computeRentalNightNumber = udf((beginUseDate: String, endUseDate: String, stayDate: String) => {
        calculateRentalNightNumber(beginUseDate, endUseDate, stayDate)
    })

    val computeTaxRateBookDateUdf = udf[BigDecimal, Seq[GenericRowWithSchema], String](getTaxRateBookDate)

    val computeTaxRateBookDateUdfExt = udf[BigDecimal, Seq[GenericRowWithSchema], String](getTaxRateBookDateExt)

    val computeTaxRateBookDateCostUdf = udf[BigDecimal, Seq[GenericRowWithSchema], String](getTaxRateBookDateCost)

    val computeTaxRateBookDateCostUdfExt = udf[BigDecimal, Seq[GenericRowWithSchema], String](getTaxRateBookDateCostExt)

    val computeTotalPriceAdjAmtTaxExclusiveUdf = udf{(totalPriceAdjAmt: java.math.BigDecimal,
                                                      otherPriceAdjAmt: java.math.BigDecimal,
                                                      expGoodWillPriceAdjAmt: java.math.BigDecimal,
                                                      goodWillPriceAdjAmt: java.math.BigDecimal,
                                                      expePenaltyPriceAdjAmt: java.math.BigDecimal,
                                                      penaltyPriceAdjAmt: java.math.BigDecimal,
                                                      taxRateBookDate: java.math.BigDecimal) =>
        computeTotalPriceAdjAmtTaxExclusive(totalPriceAdjAmt, otherPriceAdjAmt, expGoodWillPriceAdjAmt,
            goodWillPriceAdjAmt, expePenaltyPriceAdjAmt, penaltyPriceAdjAmt, taxRateBookDate)
    }

    val computeTotalFeePriceAmtTaxExclusiveUdf = udf{(totalFeePriceAmount: java.math.BigDecimal,
                                                      cancelChangeFeePrice_Amount: java.math.BigDecimal,
                                                      taxRateBookDate: java.math.BigDecimal) =>
        computeTotalFeeAmtTaxExclusive(totalFeePriceAmount, cancelChangeFeePrice_Amount, taxRateBookDate)
    }

    val computeTotalCostAdjAmtTaxExclusiveUdf = udf{(otherCostAdjustmentAmount: java.math.BigDecimal,
                                                     supplierCostAdjustmentAmount: java.math.BigDecimal,
                                                     ecaCostAdjustmentAmount: java.math.BigDecimal,
                                                     variableMarginCostAdjustmentAmount: java.math.BigDecimal,
                                                     supplierReconciliationCostAdjustment: java.math.BigDecimal,
                                                     variable_margin_credit: java.math.BigDecimal,
                                                     taxRateBookDate: java.math.BigDecimal,
                                                     totalCostAdjAmtLocal: java.math.BigDecimal
                                                    ) =>
        computeTotalCostAdjAmtTaxExclusive(otherCostAdjustmentAmount, supplierCostAdjustmentAmount,
            ecaCostAdjustmentAmount, variableMarginCostAdjustmentAmount, supplierReconciliationCostAdjustment,
            variable_margin_credit, taxRateBookDate, totalCostAdjAmtLocal)
    }

    val computeTotalFeeCostAmtTaxExclusiveUdf = udf{(otherFeeCostAmount: java.math.BigDecimal,
                                                     ecaFeeCostAmount: java.math.BigDecimal,
                                                     serviceChargeCostAmount: java.math.BigDecimal,
                                                     taxRateBookDate: java.math.BigDecimal) =>
        computeTotalFeeCostAmtTaxExclusive(otherFeeCostAmount, ecaFeeCostAmount, serviceChargeCostAmount, taxRateBookDate)
    }

    val computeNetPricePerBookingUdf = udf{ (bkgTransRows: Seq[GenericRowWithSchema],
                                             taxRateBookDate: java.math.BigDecimal) =>
        computeNetPricePerBooking(bkgTransRows, taxRateBookDate)
    }

    val computeNetPricePerBookingUdfExt = udf{ (bkgTransRows: Seq[GenericRowWithSchema]) =>
        computeNetPricePerBookingExt(bkgTransRows)
    }

    val computeNetPricePerBookingCarsUdf = udf{ (bkgTransRows: Seq[GenericRowWithSchema],
                                                 taxRateBookDate: java.math.BigDecimal,
                                                 useCurrencyConversionFeature: Boolean) =>
        if(!useCurrencyConversionFeature){
            computeNetPricePerBookingCars(bkgTransRows, taxRateBookDate)
        }else {
            computeNetPricePerBookingCarsExt(bkgTransRows, taxRateBookDate)
        }
    }

    val computeNetCostPerBookingUdf = udf{ (bkgTransRows: Seq[GenericRowWithSchema],
                                            taxRateBookDateCost: java.math.BigDecimal) =>
        computeNetCostPerBooking(bkgTransRows, taxRateBookDateCost)
    }

    val computeNetCostPerBookingUdfExt = udf{ (bkgTransRows: Seq[GenericRowWithSchema]) =>
        computeNetCostPerBookingExt(bkgTransRows)
    }

    val computeNetCostPerBookingCarsUdf = udf{ (bkgTransRows: Seq[GenericRowWithSchema],
                                                taxRateBookDateCost: java.math.BigDecimal,
                                                useCurrencyConversionFeature: Boolean) =>
        if(!useCurrencyConversionFeature){
            computeNetCostPerBookingCars(bkgTransRows, taxRateBookDateCost)
        }else {
            computeNetCostPerBookingCarsExt(bkgTransRows, taxRateBookDateCost)
        }
    }

    val checkCancelTransPresentForBkgUdf = udf{ (bkgTransRows: Seq[GenericRowWithSchema]) =>
        val (rows, isBookDate) = joinHistoryFromGroupedRows(bkgTransRows, isCancel = true)
        checkCancelTransPercentageForBkg(rows, isBookDate)
    }

    private def joinHistoryFromGroupedRows(bkgTransRows: Seq[GenericRowWithSchema], isLocal: Boolean = false, isCancel: Boolean = false): (Seq[GenericRowWithSchema], Boolean) = {
        val doesBookingHistoryExists = bkgTransRows.find(row =>
            row.schema.fieldNames.toSet.contains(SQLColumnHelper.BOOKING_HISTORY) &&
                row.getAs[mutable.WrappedArray[GenericRowWithSchema]](SQLColumnHelper.BOOKING_HISTORY) != null
        )

        val doesEventExistWithoutHistory= bkgTransRows.find(row =>
            row.schema.fieldNames.toSet.contains(SQLColumnHelper.BOOKING_HISTORY) &&
                row.getAs[mutable.WrappedArray[GenericRowWithSchema]](SQLColumnHelper.BOOKING_HISTORY) == null
        )
        if (isCancel && doesBookingHistoryExists.isDefined && doesEventExistWithoutHistory.isEmpty) {
            val source = if (isLocal) SQLColumnHelper.STAGING_BOOKING_HISTORY else SQLColumnHelper.BOOKING_HISTORY
            //Get the booking history from the least recent event
            val leastRecentEvent = bkgTransRows
                .filter(row => row.schema.fieldNames.toSet.contains(source) &&
                    row.getAs[mutable.WrappedArray[GenericRowWithSchema]](source) != null)
                .minBy(row => row.getAs[String](SQLColumnHelper.BOOKING_EVENT_DATETIME))
                .getAs[mutable.WrappedArray[GenericRowWithSchema]](source)
            (bkgTransRows ++ leastRecentEvent, true)
        } else {
            (bkgTransRows, false)
        }
    }

    val checkCancelOrRefundTransPresentForBkgUdf = udf { (bookingAmountStructRows: Seq[GenericRowWithSchema]) =>
        checkCancelOrRefundTransPresentForBkg(bookingAmountStructRows)
    }

    val computePricePenaltyAmountUdf = udf[BigDecimal, BigDecimal, String, String](computePenaltyAmount)

    val computeCostPenaltyAmountUdf = udf[BigDecimal, BigDecimal, String, String](computePenaltyAmount)

    val shouldBePostedToTaxEngineUdf =
        udf[Boolean, Boolean, BigDecimal, BigDecimal, String](shouldBePostedToTaxEngine)

    val shouldBePostedToTaxEnginePostStayUdf =
        udf[Boolean, String, BigDecimal, BigDecimal, String](shouldBePostedToTaxEnginePostStay)

    val computePurchaseBasePriceAmountLocalUdf = udf((bkgTransRows: Seq[GenericRowWithSchema],
                                                      useCurrencyConversionFeature: Boolean) => {
        if(!useCurrencyConversionFeature) {
            computePurchaseBasePriceAmountLocal(bkgTransRows)
        }else{
            computePurchaseBasePriceAmount(bkgTransRows)
        }
    })

    val computePurchasePriceCurrencyCodeUdf = udf((bkgTransRows: Seq[GenericRowWithSchema], priceCurrencyCode: String) => {
        computePurchaseCurrencyCode(bkgTransRows, priceCurrencyCode)
    })

    val computePurchaseCostCurrencyCodeUdf = udf((bkgTransRows: Seq[GenericRowWithSchema], costCurrencyCode: String) => {
        computePurchaseCurrencyCode(bkgTransRows, costCurrencyCode)
    })

    val getColumnFromAmountStructUdf = udf{ (bkgTransRows: Seq[GenericRowWithSchema],
                                             targetField: String)  =>
        getColumnFromAmountStruct(bkgTransRows, targetField)
    }

    def convertLocalDateToString(date: Date): String = {
        val dateFormat = new SimpleDateFormat("yyyy-MM-dd");
        dateFormat.format(date);
    }

    private def checkAmountZero(amount: BigDecimal) : Boolean = {
        return amount.setScale(4) == ZERO_AMOUNT
    }

    private def computePurchaseCurrencyCode(bkgTransRows: Seq[GenericRowWithSchema], currencyCode: String): String = {
        for (bkgTransRow <- bkgTransRows) {
            val transTypeKey = bkgTransRow.getAs[Integer](SQLColumnHelper.TRANSACTION_TYPE_KEY)
            val purchaseCurrencyCode = bkgTransRow.getAs[String](currencyCode)
            if (isPurchaseOrRebookTransactionType(transTypeKey)) {
                return purchaseCurrencyCode
            }
        }
        return "Unknown"
    }

    private def getTaxRateBookDate(bkgTransRows: Seq[GenericRowWithSchema],
                                   legalEntitiesWithTaxZero: String): BigDecimal = {
        for (bkgTransRow <- bkgTransRows) {
            val transactionTypeKey = bkgTransRow.getAs[Integer](SQLColumnHelper.TRANSACTION_TYPE_KEY)
            val basePriceAmtLocal = bkgTransRow.getAs[BigDecimal](SQLColumnHelper.BASE_PRICE_AMT_LOCAL)
            val totalFeePriceAmtLocal = bkgTransRow.getAs[BigDecimal](SQLColumnHelper.TOTL_FEE_PRICE_AMT_LOCAL)
            val totalPriceAdjAmtLocal = bkgTransRow.getAs[BigDecimal](SQLColumnHelper.TOTL_PRICE_ADJ_AMT_LOCAL)
            val totalTaxPriceAmtLocal = bkgTransRow.getAs[BigDecimal](SQLColumnHelper.TOTL_TAX_PRICE_AMT_LOCAL)
            val legalEntityCode = bkgTransRow.getAs[String](SQLColumnHelper.LGL_ENTITY_CODE)
            val isTaxZero = isTaxZeroForLegalEntity(legalEntityCode, legalEntitiesWithTaxZero)

            if (isPurchaseOrRebookTransactionType(transactionTypeKey)) {
                return computeTaxRateBookDate(basePriceAmtLocal, totalFeePriceAmtLocal, totalPriceAdjAmtLocal,
                    totalTaxPriceAmtLocal, isTaxZero)
            }
        }
        return ZERO_AMOUNT
    }

    private def getTaxRateBookDateExt(bkgTransRows: Seq[GenericRowWithSchema],
                                      legalEntitiesWithTaxZero: String): BigDecimal = {
        for (bkgTransRow <- bkgTransRows) {
            val transactionTypeKey = bkgTransRow.getAs[Integer](SQLColumnHelper.TRANSACTION_TYPE_KEY)
            val basePriceAmt = bkgTransRow.getAs[BigDecimal](SQLColumnHelper.BASE_PRICE_AMOUNT)
            val totalFeePriceAmt = bkgTransRow.getAs[BigDecimal](SQLColumnHelper.TOTAL_FEE_PRICE_AMOUNT)
            val totalPriceAdjAmt = bkgTransRow.getAs[BigDecimal](SQLColumnHelper.TOTAL_PRICE_ADJUSTMENT_AMOUNT)
            val totalTaxPriceAmt = bkgTransRow.getAs[BigDecimal](SQLColumnHelper.TOTAL_TAX_PRICE_AMOUNT)
            val legalEntityCode = bkgTransRow.getAs[String](SQLColumnHelper.LGL_ENTITY_CODE)
            val isTaxZero = isTaxZeroForLegalEntity(legalEntityCode, legalEntitiesWithTaxZero)

            if (isPurchaseOrRebookTransactionType(transactionTypeKey)) {
                return computeTaxRateBookDate(basePriceAmt, totalFeePriceAmt, totalPriceAdjAmt, totalTaxPriceAmt,
                    isTaxZero)
            }
        }
        return ZERO_AMOUNT
    }

    private def getTaxRateBookDateCost(bkgTransRows: Seq[GenericRowWithSchema],
                                       legalEntitiesWithTaxZero: String): BigDecimal = {
        for (bkgTransRow <- bkgTransRows) {
            val transactionTypeKey = bkgTransRow.getAs[Integer](SQLColumnHelper.TRANSACTION_TYPE_KEY)
            val totalTaxCostAmtLocal = bkgTransRow.getAs[BigDecimal](SQLColumnHelper.TOTL_TAX_COST_AMT_LOCAL)
            val totalCostAmtLocal = bkgTransRow.getAs[BigDecimal](SQLColumnHelper.TOTL_COST_AMT_LOCAL)
            val totalCostAdjAmtLocal = bkgTransRow.getAs[BigDecimal](SQLColumnHelper.TOTL_COST_ADJ_AMT_LOCAL)
            val legalEntityCode = bkgTransRow.getAs[String](SQLColumnHelper.LGL_ENTITY_CODE)
            val isTaxZero = isTaxZeroForLegalEntity(legalEntityCode, legalEntitiesWithTaxZero)

            if (isPurchaseOrRebookTransactionType(transactionTypeKey)) {
                return computeTaxRateBookDateCost(totalTaxCostAmtLocal, totalCostAmtLocal, totalCostAdjAmtLocal,
                    isTaxZero)
            }
        }
        return ZERO_AMOUNT
    }

    private def getTaxRateBookDateCostExt(bkgTransRows: Seq[GenericRowWithSchema],
                                          legalEntitiesWithTaxZero: String): BigDecimal = {
        for (bkgTransRow <- bkgTransRows) {
            val transactionTypeKey = bkgTransRow.getAs[Integer](SQLColumnHelper.TRANSACTION_TYPE_KEY)
            val totalTaxCostAmt = bkgTransRow.getAs[BigDecimal](SQLColumnHelper.TOTAL_TAX_COST_AMOUNT)
            val totalCostAmt = bkgTransRow.getAs[BigDecimal](SQLColumnHelper.TOTAL_COST_AMOUNT)
            val totalCostAdjAmt = bkgTransRow.getAs[BigDecimal](SQLColumnHelper.TOTAL_COST_ADJUSTMENT_AMOUNT)
            val legalEntityCode = bkgTransRow.getAs[String](SQLColumnHelper.LGL_ENTITY_CODE)
            val isTaxZero = isTaxZeroForLegalEntity(legalEntityCode, legalEntitiesWithTaxZero)

            if (isPurchaseOrRebookTransactionType(transactionTypeKey)) {
                return computeTaxRateBookDateCost(totalTaxCostAmt, totalCostAmt, totalCostAdjAmt,
                    isTaxZero)
            }
        }
        return ZERO_AMOUNT
    }

    val computeTaxRateBookDatePostStayUdf =
        udf[BigDecimal, BigDecimal, BigDecimal, BigDecimal, BigDecimal, String, String](computeTaxRateBookDatePostStay)

    val calculateLocalToFilingAmountsUdf = udf{ (amount: BigDecimal, exchangeRateStayDate: BigDecimal) =>
        calculateLocalToFilingAmounts(amount, exchangeRateStayDate)
    }

    private def calculateLocalToFilingAmounts(amount: BigDecimal, exchangeRateStayDate: BigDecimal): BigDecimal ={
        if(amount != null && exchangeRateStayDate != null) {
            return amount.multiply(exchangeRateStayDate).setScale(2, RoundingMode.HALF_UP)
        }
        return ZERO_AMOUNT
    }

    val computeTaxRateBookDateCostPostStayUdf =
        udf[BigDecimal, BigDecimal, BigDecimal, BigDecimal, String, String](computeTaxRateBookDateCostPostStay)

    private def computeTaxRateBookDatePostStay(basePrice: BigDecimal,
                                               fees: BigDecimal,
                                               adjustment: BigDecimal,
                                               totalTax: BigDecimal,
                                               legalEntityCode: String,
                                               legalEntitiesWithTaxZero: String): BigDecimal = {
        val isTaxZero = isTaxZeroForLegalEntity(legalEntityCode, legalEntitiesWithTaxZero)
        return computeTaxRateBookDate(basePrice, fees, adjustment, totalTax, isTaxZero)
    }

    private def computeTaxRateBookDateCostPostStay(totalTaxCostAmtLocal: BigDecimal,
                                                   totalCostAmtLocal: BigDecimal,
                                                   totalCostAdjAmtLocal: BigDecimal,
                                                   legalEntityCode: String,
                                                   legalEntitiesWithTaxZero: String): BigDecimal = {
        val isTaxZero = isTaxZeroForLegalEntity(legalEntityCode, legalEntitiesWithTaxZero)
        return computeTaxRateBookDateCost(totalTaxCostAmtLocal, totalCostAmtLocal, totalCostAdjAmtLocal, isTaxZero)
    }

    private def computeTaxRateBookDate(basePrice: BigDecimal,
                                       fees: BigDecimal,
                                       adjustment: BigDecimal,
                                       totalTax: BigDecimal,
                                       isTaxZeroForLegalEntity: Boolean): BigDecimal = {
        if (checkIfInValidAmountFields(basePrice, fees, adjustment, totalTax) || adjustment.setScale(4) != ZERO_AMOUNT
            || isTaxZeroForLegalEntity) {
            return ZERO_AMOUNT
        }

        val taxRateBookDate = totalTax.divide(basePrice.add(fees).add(adjustment), 6, RoundingMode.HALF_UP)

        if(taxRateBookDate.setScale(6) <= ZERO_AMOUNT){
            return ZERO_AMOUNT
        }

        return taxRateBookDate
    }

    private def computeTaxRateBookDateCost(totalTaxCostAmtLocal: BigDecimal,
                                           totalCostAmtLocal: BigDecimal,
                                           totalCostAdjAmtLocal: BigDecimal,
                                           isTaxZeroForLegalEntity: Boolean): BigDecimal = {
        if (checkIfInValidAmountFields(totalTaxCostAmtLocal, totalCostAmtLocal) || totalCostAdjAmtLocal == null ||
            totalCostAdjAmtLocal.setScale(4) != ZERO_AMOUNT || isTaxZeroForLegalEntity) {
            return ZERO_AMOUNT
        }

        val taxRateBookDateCost = totalTaxCostAmtLocal.divide(totalCostAmtLocal.subtract(totalTaxCostAmtLocal),6, RoundingMode.HALF_UP)

        if(taxRateBookDateCost.setScale(6) <= ZERO_AMOUNT){
            return ZERO_AMOUNT
        }

        return taxRateBookDateCost
    }

    private def computeTotalPriceAdjAmtTaxExclusive(totalPriceAdjustmentAmountLocal: java.math.BigDecimal,
                                                    otherPriceAdjustmentAmountLocal: java.math.BigDecimal,
                                                    expediaGoodwillPriceAdjustmentLocal: java.math.BigDecimal,
                                                    goodwillPriceAdjustmentLocal: java.math.BigDecimal,
                                                    expediaPenaltyPriceAdjustmentLocal: java.math.BigDecimal,
                                                    penaltyPriceAdjustmentLocal: java.math.BigDecimal,
                                                    taxRateBookDate: java.math.BigDecimal): BigDecimal = {

        val sumOfAdjustmentAmounts = otherPriceAdjustmentAmountLocal.add(expediaGoodwillPriceAdjustmentLocal)
            .add(goodwillPriceAdjustmentLocal).add(expediaPenaltyPriceAdjustmentLocal).add(penaltyPriceAdjustmentLocal)

        if (checkIfInValidAmountFields(otherPriceAdjustmentAmountLocal, expediaGoodwillPriceAdjustmentLocal,
            goodwillPriceAdjustmentLocal, expediaPenaltyPriceAdjustmentLocal, penaltyPriceAdjustmentLocal, taxRateBookDate)) {
            return ZERO_AMOUNT
        }else if(taxRateBookDate.setScale(6) <= ZERO_AMOUNT || sumOfAdjustmentAmounts.setScale(4) == ZERO_AMOUNT){
            return totalPriceAdjustmentAmountLocal
        }

        val taxRatePlusOne = taxRateBookDate.add(BigDecimal.ONE)
        val taxRateMultiplier = taxRateBookDate.divide(taxRatePlusOne, RoundingMode.HALF_UP)
        val sumOfAdjustmentAmountsWithMultiplier =sumOfAdjustmentAmounts.multiply(taxRateMultiplier)

        return totalPriceAdjustmentAmountLocal.subtract(sumOfAdjustmentAmountsWithMultiplier).setScale(2, RoundingMode.HALF_UP)
    }

    private def computeTotalFeeAmtTaxExclusive(totalFeePriceAmtLocal: java.math.BigDecimal,
                                               cancelChangeFeePriceAmtLocal: java.math.BigDecimal,
                                               taxRateBookDate: java.math.BigDecimal): BigDecimal = {

        if (checkIfInValidAmountFields(cancelChangeFeePriceAmtLocal)) {
            return totalFeePriceAmtLocal
        }else if(taxRateBookDate.setScale(6) <= ZERO_AMOUNT){
            return totalFeePriceAmtLocal
        }
        val taxRatePlusOne = taxRateBookDate.add(BigDecimal.ONE)
        val taxRateMultiplier = taxRateBookDate.divide(taxRatePlusOne, RoundingMode.HALF_UP)
        val cancelChangeFeePriceAmtWithMultiplier =cancelChangeFeePriceAmtLocal.multiply(taxRateMultiplier)

        return totalFeePriceAmtLocal.subtract(cancelChangeFeePriceAmtWithMultiplier).setScale(2, RoundingMode.HALF_UP)
    }

    private def computeTotalCostAdjAmtTaxExclusive(otherCostAdjustmentAmountLocal: java.math.BigDecimal,
                                                   supplCostAdjAmtLocal: java.math.BigDecimal,
                                                   ecaCostAdjAmtLocal: java.math.BigDecimal,
                                                   varMargnCostAdjAmtLocal: java.math.BigDecimal,
                                                   suppReconCostAdjAmtLocal: java.math.BigDecimal,
                                                   varMargnCredtLocal: java.math.BigDecimal,
                                                   taxRateBookDateCost: java.math.BigDecimal,
                                                   totalCostAdjAmtLocal: java.math.BigDecimal): BigDecimal = {

        if (checkIfInValidAmountFields(otherCostAdjustmentAmountLocal, supplCostAdjAmtLocal, ecaCostAdjAmtLocal,
            varMargnCostAdjAmtLocal, suppReconCostAdjAmtLocal, varMargnCredtLocal, taxRateBookDateCost)) {
            return ZERO_AMOUNT
        }

        val sumOfAdjustmentAmounts = otherCostAdjustmentAmountLocal.add(supplCostAdjAmtLocal)

        if(taxRateBookDateCost.setScale(6) < ZERO_AMOUNT ){
            return ecaCostAdjAmtLocal.add(varMargnCostAdjAmtLocal).add(suppReconCostAdjAmtLocal).add(varMargnCredtLocal).setScale(2, RoundingMode.HALF_UP)
        }

        val taxRatePlusOne = taxRateBookDateCost.add(BigDecimal.ONE)

        return totalCostAdjAmtLocal.subtract(
                sumOfAdjustmentAmounts.multiply(taxRateBookDateCost.divide(taxRatePlusOne,6,RoundingMode.HALF_UP)))
            .setScale(2, RoundingMode.HALF_UP)
    }

    private def computeTotalFeeCostAmtTaxExclusive(othrFeeCostAmtLocal: java.math.BigDecimal,
                                                   ecaFeeCostAmtLocal: java.math.BigDecimal,
                                                   svcChgCostAmtLocal: java.math.BigDecimal,
                                                   taxRateBookDateCost: java.math.BigDecimal): BigDecimal = {

        if (checkIfInValidAmountFields(othrFeeCostAmtLocal, ecaFeeCostAmtLocal, svcChgCostAmtLocal) || taxRateBookDateCost == null) {
            return ZERO_AMOUNT
        }

        if(taxRateBookDateCost.setScale(6) < ZERO_AMOUNT  || othrFeeCostAmtLocal.setScale(4) == ZERO_AMOUNT){
            return ecaFeeCostAmtLocal.add(svcChgCostAmtLocal).setScale(2, RoundingMode.HALF_UP)
        }
        val taxRatePlusOne = taxRateBookDateCost.add(BigDecimal.ONE)

        val othrFeeCostAmtLocalTaxExclusive = othrFeeCostAmtLocal.divide(taxRatePlusOne,2, RoundingMode.HALF_UP)


        return othrFeeCostAmtLocalTaxExclusive.add(ecaFeeCostAmtLocal).add(svcChgCostAmtLocal).setScale(2, RoundingMode.HALF_UP)
    }

    private def computeNetPricePerBooking(bkgTransRows: Seq[GenericRowWithSchema],
                                          taxRateBookDate: java.math.BigDecimal): BigDecimal = {
        var netPrice: BigDecimal = ZERO_AMOUNT
        for (bkgTransRow <- bkgTransRows) {
            val basePriceAmtLocal = bkgTransRow.getAs[BigDecimal](SQLColumnHelper.BASE_PRICE_AMT_LOCAL)
            val totalFeePriceAmtLocal = bkgTransRow.getAs[BigDecimal](SQLColumnHelper.TOTL_FEE_PRICE_AMT_LOCAL)
            val totalPriceAdjAmtLocal = bkgTransRow.getAs[BigDecimal](SQLColumnHelper.TOTL_PRICE_ADJ_AMT_LOCAL)
            val otherPriceAdjustmentAmountLocal = bkgTransRow.getAs[BigDecimal](SQLColumnHelper.OTHR_PRICE_ADJ_AMT_LOCAL)
            val expediaGoodwillPriceAdjustmentLocal = bkgTransRow.getAs[BigDecimal](SQLColumnHelper.EXPE_GDWLL_PRICE_ADJ_AMT_LOCAL)
            val goodwillPriceAdjustmentLocal = bkgTransRow.getAs[BigDecimal](SQLColumnHelper.GDWLL_PRICE_ADJ_AMT_LOCAL)
            val expediaPenaltyPriceAdjustmentLocal = bkgTransRow.getAs[BigDecimal](SQLColumnHelper.EXPE_PNLTY_PRICE_ADJ_AMT_LOCAL)
            val penaltyPriceAdjustmentLocal = bkgTransRow.getAs[BigDecimal](SQLColumnHelper.PNLTY_PRICE_ADJ_AMT_LOCAL)
            val cancelChangeFeePriceAmtLocal = bkgTransRow.getAs[BigDecimal](SQLColumnHelper.CNCL_CHG_FEE_PRICE_AMT_LOCAL)
            val totalPriceAdjAmtTaxExclusive = computeTotalPriceAdjAmtTaxExclusive(totalPriceAdjAmtLocal,
                otherPriceAdjustmentAmountLocal, expediaGoodwillPriceAdjustmentLocal, goodwillPriceAdjustmentLocal,
                expediaPenaltyPriceAdjustmentLocal, penaltyPriceAdjustmentLocal, taxRateBookDate)
            val totalFeePriceAmtTaxExclusive = computeTotalFeeAmtTaxExclusive(totalFeePriceAmtLocal, cancelChangeFeePriceAmtLocal, taxRateBookDate)
            netPrice = netPrice.add(basePriceAmtLocal).add(totalFeePriceAmtTaxExclusive).add(totalPriceAdjAmtTaxExclusive)
        }
        netPrice
    }

    private def computeNetPricePerBookingExt(bkgTransRows: Seq[GenericRowWithSchema]): BigDecimal = {
        var netPrice: BigDecimal = ZERO_AMOUNT
        for (bkgTransRow <- bkgTransRows) {
            val basePriceAmt = bkgTransRow.getAs[BigDecimal](SQLColumnHelper.BASE_PRICE_AMOUNT)
            val totalPriceAdjAmtTaxExclusive = bkgTransRow.getAs[BigDecimal](SQLColumnHelper.TOTAL_PRICE_ADJUSTMENT_AMOUNT_TAX_EXCLUSIVE)
            val totalFeePriceAmtTaxExclusive = bkgTransRow.getAs[BigDecimal](SQLColumnHelper.TOTAL_FEE_PRICE_AMOUNT_TAX_EXCLUSIVE)
            netPrice = netPrice.add(basePriceAmt).add(totalFeePriceAmtTaxExclusive).add(totalPriceAdjAmtTaxExclusive)
        }
        netPrice
    }

    private def computeNetPricePerBookingCars(bkgTransRows: Seq[GenericRowWithSchema],
                                              taxRateBookDate: java.math.BigDecimal): BigDecimal = {
        var netPrice: BigDecimal = ZERO_AMOUNT
        for (bkgTransRow <- bkgTransRows) {
            val basePriceAmtLocal = bkgTransRow.getAs[BigDecimal](SQLColumnHelper.BASE_PRICE_AMT_LOCAL)
            val totalFeePriceAmtLocal = bkgTransRow.getAs[BigDecimal](SQLColumnHelper.TOTL_FEE_PRICE_AMT_LOCAL)
            val totalPriceAdjAmtLocal = bkgTransRow.getAs[BigDecimal](SQLColumnHelper.TOTL_PRICE_ADJ_AMT_LOCAL)
            netPrice = netPrice.add(basePriceAmtLocal).add(totalPriceAdjAmtLocal).add(totalFeePriceAmtLocal)
        }
        netPrice
    }

    private def computeNetPricePerBookingCarsExt(bkgTransRows: Seq[GenericRowWithSchema],
                                                 taxRateBookDate: java.math.BigDecimal): BigDecimal = {
        var netPrice: BigDecimal = ZERO_AMOUNT
        for (bkgTransRow <- bkgTransRows) {
            val basePriceAmt = bkgTransRow.getAs[BigDecimal](SQLColumnHelper.BASE_PRICE_AMOUNT)
            val totalFeePriceAmt = bkgTransRow.getAs[BigDecimal](SQLColumnHelper.TOTAL_FEE_PRICE_AMOUNT)
            val totalPriceAdjAmt = bkgTransRow.getAs[BigDecimal](SQLColumnHelper.TOTAL_PRICE_ADJUSTMENT_AMOUNT)
            netPrice = netPrice.add(basePriceAmt).add(totalPriceAdjAmt).add(totalFeePriceAmt)
        }
        netPrice
    }

    private def computeNetCostPerBooking(bkgTransRows: Seq[GenericRowWithSchema],
                                         taxRateBookDateCost: java.math.BigDecimal): BigDecimal = {
        var netCost: BigDecimal = ZERO_AMOUNT
        for (bkgTransRow <- bkgTransRows) {
            val baseCostAmtLocal = bkgTransRow.getAs[BigDecimal](SQLColumnHelper.BASE_COST_AMT_LOCAL)
            val otherCostAdjustmentAmountLocal = bkgTransRow.getAs[BigDecimal](SQLColumnHelper.OTHR_COST_ADJ_AMT_LOCAL)
            val supplCostAdjAmtLocal = bkgTransRow.getAs[BigDecimal](SQLColumnHelper.SUPPL_COST_ADJ_AMT_LOCAL)
            val ecaCostAdjAmtLocal = bkgTransRow.getAs[BigDecimal](SQLColumnHelper.ECA_COST_ADJ_AMT_LOCAL)
            val varMargnCostAdjAmtLocal = bkgTransRow.getAs[BigDecimal](SQLColumnHelper.VAR_MARGN_COST_ADJ_LOCAL)
            val suppReconCostAdjAmtLocal = bkgTransRow.getAs[BigDecimal](SQLColumnHelper.SUPPL_RECON_COST_ADJ_AMT_LOCAL)
            val varMargnCredtLocal = bkgTransRow.getAs[BigDecimal](SQLColumnHelper.VAR_MARGN_CREDT_LOCAL)
            val othrFeeCostAmtLocal = bkgTransRow.getAs[BigDecimal](SQLColumnHelper.OTHR_FEE_COST_AMT_LOCAL)
            val ecaFeeCostAmtLocal = bkgTransRow.getAs[BigDecimal](SQLColumnHelper.ECA_FEE_COST_AMT_LOCAL)
            val svcChgCostAmtLocal = bkgTransRow.getAs[BigDecimal](SQLColumnHelper.SVC_CHRG_COST_AMT_LOCAL)
            val totalCostAdjAmtLocal = bkgTransRow.getAs[BigDecimal](SQLColumnHelper.TOTL_COST_ADJ_AMT_LOCAL)
            val totalCostAdjAmtTaxExclusive = computeTotalCostAdjAmtTaxExclusive(otherCostAdjustmentAmountLocal,
                supplCostAdjAmtLocal, ecaCostAdjAmtLocal, varMargnCostAdjAmtLocal, suppReconCostAdjAmtLocal,
                varMargnCredtLocal, taxRateBookDateCost, totalCostAdjAmtLocal)
            val totalFeeCostAmtTaxExclusive = computeTotalFeeCostAmtTaxExclusive(othrFeeCostAmtLocal,
                ecaFeeCostAmtLocal, svcChgCostAmtLocal, taxRateBookDateCost)
            netCost = netCost.add(baseCostAmtLocal).add(totalFeeCostAmtTaxExclusive).add(totalCostAdjAmtTaxExclusive)
        }
        netCost
    }

    private def computeNetCostPerBookingExt(bkgTransRows: Seq[GenericRowWithSchema]): BigDecimal = {
        var netCost: BigDecimal = ZERO_AMOUNT
        for (bkgTransRow <- bkgTransRows) {
            val baseCostAmt = bkgTransRow.getAs[BigDecimal](SQLColumnHelper.BASE_COST_AMOUNT)
            val totalFeeCostAmtTaxExclusive = bkgTransRow.getAs[BigDecimal](SQLColumnHelper.TOTAL_FEE_COST_AMOUNT_TAX_EXCLUSIVE)
            val totalCostAdjAmtTaxExclusive = bkgTransRow.getAs[BigDecimal](SQLColumnHelper.TOTAL_COST_ADJUSTMENT_AMOUNT_TAX_EXCLUSIVE)
            netCost = netCost.add(baseCostAmt).add(totalFeeCostAmtTaxExclusive).add(totalCostAdjAmtTaxExclusive)
        }
        netCost
    }

    private def computeNetCostPerBookingCars(bkgTransRows: Seq[GenericRowWithSchema],
                                             taxRateBookDateCost: java.math.BigDecimal): BigDecimal = {
        var netCost: BigDecimal = ZERO_AMOUNT
        for (bkgTransRow <- bkgTransRows) {
            val baseCostAmtLocal = bkgTransRow.getAs[BigDecimal](SQLColumnHelper.BASE_COST_AMT_LOCAL)
            val totalCostAdjustmentAmountLocal = bkgTransRow.getAs[BigDecimal](SQLColumnHelper.TOTL_COST_ADJ_AMT_LOCAL)
            val totalFeeCostAmtLocal = bkgTransRow.getAs[BigDecimal](SQLColumnHelper.TOTL_FEE_COST_AMT_LOCAL)
            netCost = netCost.add(baseCostAmtLocal).add(totalFeeCostAmtLocal).add(totalCostAdjustmentAmountLocal)
        }
        netCost
    }

    private def computeNetCostPerBookingCarsExt(bkgTransRows: Seq[GenericRowWithSchema],
                                                taxRateBookDateCost: java.math.BigDecimal): BigDecimal = {
        var netCost: BigDecimal = ZERO_AMOUNT
        for (bkgTransRow <- bkgTransRows) {
            val baseCostAmt = bkgTransRow.getAs[BigDecimal](SQLColumnHelper.BASE_COST_AMOUNT)
            val totalCostAdjustmentAmount = bkgTransRow.getAs[BigDecimal](SQLColumnHelper.TOTAL_COST_ADJUSTMENT_AMOUNT)
            val totalFeeCostAmt = bkgTransRow.getAs[BigDecimal](SQLColumnHelper.TOTAL_FEE_COST_AMOUNT)
            netCost = netCost.add(baseCostAmt).add(totalFeeCostAmt).add(totalCostAdjustmentAmount)
        }
        netCost
    }

    private def checkCancelTransPercentageForBkg(bkgTransRows: Seq[GenericRowWithSchema], isBookDate: Boolean = false): Boolean = {
        for (bkgTransRow <- bkgTransRows) {
            val transactionTypeName: String = isBookDate match {
                case true => {
                    val columns = Seq(SQLColumnHelper.VRBO_EVENT_TYPE, SQLColumnHelper.TRANSACTION_TYPE_NAME)
                    columns.collectFirst(Function.unlift(col => Try(bkgTransRow.getAs[String](col)).toOption)).getOrElse("")
                }
                case false => bkgTransRow.getAs[String] (SQLColumnHelper.TRANSACTION_TYPE_NAME)
            }
            if (transactionTypeName == null || transactionTypeName.isEmpty) {
                return false
            } else if(isCancelTransactionType(transactionTypeName)){
                return true
            }
        }
        return false
    }

    private def checkCancelOrRefundTransPresentForBkg(bkgTransRows: Seq[GenericRowWithSchema]): Boolean = {
        for (bkgTransRow <- bkgTransRows) {
            val transactionTypeName = bkgTransRow.getAs[String](SQLColumnHelper.TRANSACTION_TYPE_NAME)
            if (transactionTypeName == null || transactionTypeName.isEmpty) {
                return false
            } else if (isCancelTransactionType(transactionTypeName) || isRefundTransactionType(transactionTypeName)) {
                return true
            }
        }
        return false
    }

    private def deriveFieldFromSeq(structRows: Seq[GenericRowWithSchema], fetchField:String, preferredFieldName: String, preferredFieldValue: String): String = {
        val preferredField = structRows
            .find(_.getAs[String](preferredFieldName) == preferredFieldValue)
            .flatMap(row => Try(row.getAs[String](fetchField)).toOption)
            .filterNot(_ == null)
            .filterNot(_.isEmpty)
            .orElse(None)

        val defaultField = structRows
            .flatMap(row => Try(row.getAs[String](fetchField)).toOption)
            .filterNot(_ == null)
            .filterNot(_.isEmpty)
            .lastOption
            .getOrElse("Unknown")

        preferredField.getOrElse(defaultField)
    }

    private def deriveCurrencyCodeFromAmounts(localAmounts: Seq[GenericRowWithSchema]): String = {
        localAmounts
            .map(_.getAs[GenericRowWithSchema](SQLColumnHelper.MONEY))
            .filter(_ != null)
            .find(money => {
                val currency = money.getAs[String](SQLColumnHelper.CURRENCY_COD)
                currency != null && currency.nonEmpty && !currency.equals("Unknown")
            })
            .map(_.getAs[String](SQLColumnHelper.CURRENCY_COD))
            .getOrElse("Unknown")
    }

    private def deriveUpdatedPriceCurrencyCode(bkgTransRows: Seq[GenericRowWithSchema]): String = {
        deriveFieldFromSeq(bkgTransRows, SQLColumnHelper.PRICE_CURRENCY_CODE, SQLColumnHelper.TRANSACTION_TYPE_NAME, "INITIAL_BOOKING")
    }

    private def deriveUpdatedCostCurrencyCode(bkgTransRows: Seq[GenericRowWithSchema]): String = {
        deriveFieldFromSeq(bkgTransRows, SQLColumnHelper.COST_CURRENCY_CODE, SQLColumnHelper.TRANSACTION_TYPE_NAME, "INITIAL_BOOKING")
    }

    private def deriveUpdatedExchRateStayDate(bkgTransRows: Seq[GenericRowWithSchema]): BigDecimal = {
        val exchRateStayDateInitialBooking = bkgTransRows
            .find(_.getAs[String](SQLColumnHelper.TRANSACTION_TYPE_NAME) == "INITIAL_BOOKING")
            .flatMap(row => Try(row.getAs[Double](SQLColumnHelper.EXCH_RATE_STAY_DATE)).toOption.orElse(None))
            .filterNot(_ == null)
            .filter(_ > 0)
            .map(BigDecimal.valueOf)

        val exchRateStayDate = bkgTransRows
            .flatMap(row => Try(row.getAs[Double](SQLColumnHelper.EXCH_RATE_STAY_DATE)).toOption.orElse(None))
            .filterNot(_ == null)
            .filter(_ > 0)
            .map(BigDecimal.valueOf)
            .lastOption

        exchRateStayDateInitialBooking.getOrElse(exchRateStayDate.orNull)
    }

    private def generateBookingHistory(bkgTransRows: Seq[GenericRowWithSchema]): Seq[BookingHistoryCase] = {
        val bookingHistoryList = bkgTransRows.map(bkgTransRow => {
            val liabilityType = bkgTransRow.getAs[String](SQLColumnHelper.TRANSACTION_LIABILITY_TYPE)
            if(liabilityType.equals(SQLColumnHelper.BOOK_DATE)){
                BookingHistoryCase(
                    event_type = bkgTransRow.getAs[String](SQLColumnHelper.VRBO_EVENT_TYPE),
                    event_uuid = bkgTransRow.getAs[String](SQLColumnHelper.EVENT_UUID),
                    booking_event_date = bkgTransRow.getAs[String](SQLColumnHelper.VRBO_TRANSACTION_DATETIME),
                    booking_item_id = bkgTransRow.getAs[String](SQLColumnHelper.VRBO_RESERVATION_REFERENCE_NUMBER),
                    liability_date = bkgTransRow.getAs[String](SQLColumnHelper.VRBO_TRANSACTION_DATETIME),
                    reservation_uuid = bkgTransRow.getAs[String](SQLColumnHelper.RESERVATION_UUID),
                    run_id = bkgTransRow.getAs[String](SQLColumnHelper.RUN_ID),
                    local_amounts = bkgTransRow.getSeq[AmountCase](bkgTransRow.fieldIndex(SQLColumnHelper.LOCAL_AMOUNTS)))
            }else{
                return null
            }
        })
        if(bookingHistoryList.forall(_ == null)){
            return null
        }
        bookingHistoryList
    }

    private def deriveUpdatedBookDate(bkgTransRows: Seq[GenericRowWithSchema]): String = {
        for (bkgTransRow <- bkgTransRows) {
            val bookDate =  bkgTransRow.getAs[String](SQLColumnHelper.BOOK_DATE)
            if (bookDate != null) {
                return bookDate
            }
        }
        return null
    }

    private def computePurchaseBasePriceAmountLocal(bkgTransRows : Seq[GenericRowWithSchema]): BigDecimal = {
        for (bkgTransBaseAmtRow <- bkgTransRows) {
            val transTypeKey =  bkgTransBaseAmtRow.getAs[Integer](SQLColumnHelper.TRANSACTION_TYPE_KEY)
            val basePriceAmt = bkgTransBaseAmtRow.getAs[BigDecimal](SQLColumnHelper.BASE_PRICE_AMT_LOCAL)
            if (isPurchaseOrRebookTransactionType(transTypeKey)) {
                return basePriceAmt
            }
        }
        return ZERO_AMOUNT
    }

    private def computePurchaseBasePriceAmount(bkgTransRows : Seq[GenericRowWithSchema]): BigDecimal = {
        for (bkgTransBaseAmtRow <- bkgTransRows) {
            val transTypeKey =  bkgTransBaseAmtRow.getAs[Integer](SQLColumnHelper.TRANSACTION_TYPE_KEY)
            val basePriceAmt = bkgTransBaseAmtRow.getAs[BigDecimal](SQLColumnHelper.BASE_PRICE_AMOUNT)
            if (isPurchaseOrRebookTransactionType(transTypeKey)) {
                return basePriceAmt
            }
        }
        return ZERO_AMOUNT
    }

    private def computePenaltyAmount(totalNetAmtPerBkg: java.math.BigDecimal,
                                     transactionType: String,
                                     businessModelName: String): BigDecimal = {
        var penaltyAmt: BigDecimal = ZERO_AMOUNT
        if (businessModelName == BusinessConstants.BUSINESS_MODEL_AGENCY) {
            return ZERO_AMOUNT
        }
        if (isCancelTransactionType(transactionType)) {
            penaltyAmt = penaltyAmt.add(totalNetAmtPerBkg)
        }
        return penaltyAmt
    }

    private def shouldBePostedToTaxEngine(withCancel: Boolean,
                                          penaltyPrice: BigDecimal,
                                          penaltyCost: BigDecimal,
                                          businessModelName: String): Boolean = {
        if (!withCancel
            || ZERO_AMOUNT.compareTo(penaltyPrice.setScale(2, RoundingMode.HALF_UP)) != 0
            || ZERO_AMOUNT.compareTo(penaltyCost.setScale(2, RoundingMode.HALF_UP)) != 0
            || businessModelName == BusinessConstants.BUSINESS_MODEL_AGENCY) {
            return true
        }
        return false
    }

    private def shouldBePostedToTaxEnginePostStay(transactionType: String,
                                                  grossBkgAmtLcl: BigDecimal,
                                                  totlCostAmtLcl:BigDecimal,
                                                  businessModelName: String): Boolean = {
        if (businessModelName == BusinessConstants.BUSINESS_MODEL_AGENCY) {
            return true
        }
        if ((isAdjustmentTransactionType(transactionType) || isCancelTransactionType(transactionType))
            && checkAmountZero(grossBkgAmtLcl)
            && checkAmountZero(totlCostAmtLcl)) {
            return false
        }
        return true
    }

    private def isAdjustmentTransactionType(transactionType: String) = {
        transactionType != null && (transactionType.contains("Adjustment") ||
            transactionType.contains("adjustment"))
    }

    private def isCancelTransactionType(transactionType: String) = {
        transactionType != null && transactionType.toLowerCase().contains("cancel")
    }

    private def isRefundTransactionType(transactionType: String) = {
        transactionType != null && transactionType.toLowerCase().contains("refund")
    }

    private def isPurchaseOrRebookTransactionType(transactionTypeKey: Int) = {
        transactionTypeKey == 101 || transactionTypeKey == 112 || transactionTypeKey == 113 || transactionTypeKey == 114 || transactionTypeKey == 121
    }

    private def checkIfInValidAmountFields(cancelChangeFeePriceAmtLocal: BigDecimal) = {
        cancelChangeFeePriceAmtLocal == null || cancelChangeFeePriceAmtLocal.setScale(4) == ZERO_AMOUNT
    }

    private def checkIfInValidAmountFields(basePrice: BigDecimal,
                                           fees: BigDecimal,
                                           adjustment: BigDecimal,
                                           totalTax: BigDecimal) = {
        basePrice == null || fees == null || adjustment == null || totalTax == null ||
            totalTax.setScale(4) == ZERO_AMOUNT || (basePrice.setScale(4) == ZERO_AMOUNT &&
            fees.setScale(4) == ZERO_AMOUNT && adjustment.setScale(4) == ZERO_AMOUNT) ||
            basePrice.add(fees).add(adjustment).setScale(4) == ZERO_AMOUNT
    }

    private def checkIfInValidAmountFields(totalTaxCostAmtLocal: BigDecimal, totalCostAmtLocal: BigDecimal) = {
        totalTaxCostAmtLocal == null || totalCostAmtLocal == null || totalTaxCostAmtLocal.setScale(4) == ZERO_AMOUNT ||
            (totalTaxCostAmtLocal.setScale(4) == ZERO_AMOUNT && totalTaxCostAmtLocal.setScale(4) == ZERO_AMOUNT) ||
            totalCostAmtLocal.subtract(totalTaxCostAmtLocal).setScale(4) == ZERO_AMOUNT
    }

    private def checkIfInValidAmountFields(otherPriceAdjustmentAmountLocal: BigDecimal,
                                           expediaGoodwillPriceAdjustmentLocal: BigDecimal,
                                           goodwillPriceAdjustmentLocal: BigDecimal,
                                           expediaPenaltyPriceAdjustmentLocal: BigDecimal,
                                           penaltyPriceAdjustmentLocal: BigDecimal,
                                           taxRateBookDate: BigDecimal) = {
        otherPriceAdjustmentAmountLocal == null || expediaGoodwillPriceAdjustmentLocal == null ||
            goodwillPriceAdjustmentLocal == null || expediaPenaltyPriceAdjustmentLocal == null ||
            penaltyPriceAdjustmentLocal == null || taxRateBookDate == null
    }

    private def checkIfInValidAmountFields(otherCostAdjustmentAmountLocal: java.math.BigDecimal,
                                           supplCostAdjAmtLocal: java.math.BigDecimal,
                                           ecaCostAdjAmtLocal: java.math.BigDecimal,
                                           varMargnCostAdjAmtLocal: java.math.BigDecimal,
                                           suppReconCostAdjAmtLocal: java.math.BigDecimal,
                                           varMargnCredtLocal: java.math.BigDecimal,
                                           taxRateBookDateCost: java.math.BigDecimal) = {
        otherCostAdjustmentAmountLocal == null || supplCostAdjAmtLocal == null || ecaCostAdjAmtLocal == null ||
            varMargnCostAdjAmtLocal == null || suppReconCostAdjAmtLocal == null || varMargnCredtLocal == null ||
            taxRateBookDateCost == null
    }

    private def checkIfInValidAmountFields(othrFeeCostAmtLocal: java.math.BigDecimal,
                                           ecaFeeCostAmtLocal: java.math.BigDecimal,
                                           svcChgCostAmtLocal: java.math.BigDecimal) = {
        othrFeeCostAmtLocal == null || ecaFeeCostAmtLocal == null || svcChgCostAmtLocal == null
    }

    //parse JSON into criteria object
    def readCriteriaFromJson(criteriaList: String): CriteriaSectionCase = {
        logger.info("Reading the criteria from the input criteria json: " + criteriaList)
        try {
            val jsonStream = IOUtils.toInputStream(criteriaList, "UTF-8")
            val mapper = new ObjectMapper() with ScalaObjectMapper
            mapper.registerModule(DefaultScalaModule)
            mapper.readValue[CriteriaSectionCase](jsonStream)
        } catch {
            case e:
                Exception => throw new Exception(s"Unable to parse the criteria json: ${e.getMessage}")
        }
    }

    def getDifferentialTransactionsDF(newEnrichedDF:DataFrame, allEnrichedDF: DataFrame):DataFrame = {
        val qualifiedEnrichedTransactionsDF = allEnrichedDF.join(newEnrichedDF, allEnrichedDF(
            SQLColumnHelper.EVENT_UUID) ===  newEnrichedDF(SQLColumnHelper.EVENT_UUID), "left_anti")
        qualifiedEnrichedTransactionsDF
    }

    def cleanUpTempTables(spark: SparkSession, tableName:String): Unit = {
        val partitions = spark.sql(raw"""show partitions ${tableName}""").collect()
        if(!partitions.isEmpty){
            val partitionValues =partitions.map(f=>f(0).toString)
                .toArray.mkString("partition(", "," , "\")")
                .replace("," , "\") ,partition(")
                .replace("=", "=\"")
                .replace("/", "\",")

            spark.sql(raw"""alter table ${tableName} drop ${partitionValues}""")
        }
    }

    def getDefaultDerivedCols(transDataFrame: DataFrame):DataFrame = {
        transDataFrame.withColumn(SQLColumnHelper.TOTAL_ROOM_NIGHT_COUNT, lit(0))
            .withColumn(SQLColumnHelper.ROOM_NIGHT_COUNT, lit(0))
            .withColumn(SQLColumnHelper.TOTAL_TRAVELER_COUNT, lit(0))
            .withColumn(SQLColumnHelper.POINT_OF_SALE_KEY, lit(0))
            .withColumn(SQLColumnHelper.POINT_OF_SALE_BRAND_NAME, lit("Not Available"))
            .withColumn(SQLColumnHelper.POINT_OF_SALE_NAME, lit("Not Available"))
            .withColumn(SQLColumnHelper.PNLTY_PRICE_ADJ_AMT_LOCAL, lit(0))
            .withColumn(SQLColumnHelper.EXPE_PNLTY_PRICE_ADJ_AMT_LOCAL, lit(0))
            .withColumn(SQLColumnHelper.SVC_FEE_PRICE_AMT_LOCAL, lit(0))
            .withColumn(SQLColumnHelper.SVC_CHRG_PRICE_AMT_LOCAL, lit(0))
            .withColumn(SQLColumnHelper.BASE_COST_AMT_USD, lit(0))
            .withColumn(SQLColumnHelper.OTHR_COST_ADJ_AMT_USD, lit(0))
            .withColumn(SQLColumnHelper.SUPPL_COST_ADJ_AMT_USD, lit(0))
            .withColumn(SQLColumnHelper.TOTL_COST_ADJ_AMT_USD, lit(0))
            .withColumn(SQLColumnHelper.TOTL_COST_AMT_USD, lit(0))
            .withColumn(SQLColumnHelper.TOTL_FEE_COST_AMT_USD, lit(0))
            .withColumn(SQLColumnHelper.TOTL_TAX_COST_AMT_USD, lit(0))
            .withColumn(SQLColumnHelper.EXPE_GDWLL_PRICE_ADJ_AMT_LOCAL, lit(0))
            .withColumn(SQLColumnHelper.GDWLL_PRICE_ADJ_AMT_LOCAL, lit(0))
            .withColumn(SQLColumnHelper.GENRIC_COUPN_PRICE_AMT_LOCAL, lit(0))
            .withColumn(SQLColumnHelper.REFUND_PRICE_ADJ_AMT_LOCAL, lit(0))
            .withColumn(SQLColumnHelper.REBATE_PRICE_AMT_LOCAL, lit(0))
            .withColumn(SQLColumnHelper.TCM_PRICE_ADJ_AMT_LOCAL, lit(0))
            .withColumn(SQLColumnHelper.CNCL_PNLTY_WAIVR_PRICE_ADJ_AMT_LOCAL, lit(0))
            .withColumn(SQLColumnHelper.LOYLTY_POINT_PRICE_ADJ_AMT_LOCAL, lit(0))
            .withColumn(SQLColumnHelper.EMP_DISC_PRICE_ADJ_AMT_LOCAL, lit(0))
            .withColumn(SQLColumnHelper.SUPPL_RECON_PRICE_ADJ_AMT_LOCAL, lit(0))
            .withColumn(SQLColumnHelper.SUPPL_COST_ADJ_AMT_LOCAL, lit(0))
            .withColumn(SQLColumnHelper.ECA_COST_ADJ_AMT_LOCAL, lit(0))
            .withColumn(SQLColumnHelper.OTHR_COST_ADJ_AMT_LOCAL, lit(0))
            .withColumn(SQLColumnHelper.VAR_MARGN_COST_ADJ_LOCAL, lit(0))
            .withColumn(SQLColumnHelper.SUPPL_RECON_COST_ADJ_AMT_LOCAL, lit(0))
            .withColumn(SQLColumnHelper.SVC_CHRG_COST_AMT_LOCAL, lit(0))
            .withColumn(SQLColumnHelper.ECA_FEE_COST_AMT_LOCAL, lit(0))
            .withColumn(SQLColumnHelper.VAR_MARGN_CREDT_LOCAL, lit(0))
            .withColumn(SQLColumnHelper.EXTRA_PERSN_COST_AMT_LOCAL, lit(0))
            .withColumn(SQLColumnHelper.RATE_PLN_RESTR_COST_AMT_LOCAL, lit(0))
            .withColumn(SQLColumnHelper.SNGL_SUPPLMNT_COST_AMT_LOCAL, lit(0))
            .withColumn(SQLColumnHelper.DYN_RATE_RULE_COST_AMT_LOCAL, lit(0))
    }

    val deriveAggregatedAmountUDF = udf((bookingAmountStructRows: Seq[GenericRowWithSchema], referenceField: String, isCancel: Boolean) => {
        val isBookDateLiable:Boolean = isBookDateLiability(bookingAmountStructRows)
        deriveAggregatedAmount(bookingAmountStructRows, referenceField, isBookDateLiable, isCancel)
    })

    private def isBookDateLiability(bkgTransRows: Seq[GenericRowWithSchema]):Boolean = {
        for(bkgTransRow <- bkgTransRows) {
            val transactionLiabilityDate: String = bkgTransRow.getAs[String] (SQLColumnHelper.TRANSACTION_LIABILITY_DATE_TYPE)
            if(SQLColumnHelper.TRANSACTION_LIABILITY_DATE_TYPE_BKG_EVENT_DATE.equals(transactionLiabilityDate)){
                return true
            }
        }
        return false
    }

    val deriveAggregatedAmountWithHistoryUDF = udf((bookingAmountStructRows: Seq[GenericRowWithSchema], referenceField: String, isCancel: Boolean) => {
        val (finalStructRows, isBookDate) = joinHistoryFromGroupedRows(bookingAmountStructRows, isCancel = isCancel)
        val isBookDateLiable:Boolean = isBookDateLiability(bookingAmountStructRows)
        deriveAggregatedAmount(finalStructRows, referenceField, isBookDateLiable, isCancel)
    })

    val deriveUpdatedPriceCurrencyCodeUdf = udf{ (bkgTransRows: Seq[GenericRowWithSchema]) =>
        deriveUpdatedPriceCurrencyCode(bkgTransRows)
    }

    val deriveUpdatedPriceCurrencyCodeForHistoryUdf = udf{ (bkgTransRows: Seq[GenericRowWithSchema]) =>
        deriveCurrencyCodeFromAmounts(bkgTransRows)
    }

    val deriveUpdatedCostCurrencyCodeUdf = udf{ (bkgTransRows: Seq[GenericRowWithSchema]) =>
        deriveUpdatedCostCurrencyCode(bkgTransRows)
    }

    val deriveUpdatedExchRateStayDateUdf = udf{ (bkgTransRows: Seq[GenericRowWithSchema]) =>
        deriveUpdatedExchRateStayDate(bkgTransRows)
    }

    val deriveUpdatedBookDateUdf = udf{ (bkgTransRows: Seq[GenericRowWithSchema]) =>
        deriveUpdatedBookDate(bkgTransRows)
    }

    val combineAmountsUDF = udf((bookingAmountStructRows: Seq[GenericRowWithSchema], amounts: String, isCancel: Boolean) => {
        val (finalStructRows, _) = joinHistoryFromGroupedRows(bookingAmountStructRows, SQLColumnHelper.LOCAL_AMOUNTS.equals(amounts), isCancel)
        combineAmounts(finalStructRows, amounts)
    })

    val generateBookingHistoryUdf = udf{ (bkgTransRows: Seq[GenericRowWithSchema]) =>
        generateBookingHistory(bkgTransRows)
    }

    val deriveAggregatedPartnerFeeAmountsUDF = udf((convertedAmounts: Seq[GenericRowWithSchema], amounts: String) => {
        deriveAggregatedPartnerFeeAmounts(convertedAmounts, amounts)
    })

    private def combineAmounts(bookingAmountStructRows: Seq[GenericRowWithSchema], amounts: String): Seq[AmountCase] = {
        var amountCase: Seq[AmountCase] = Seq()
        if (bookingAmountStructRows != null || bookingAmountStructRows.nonEmpty) {
            for (bookingAmountStructRow <- bookingAmountStructRows) {
                if (bookingAmountStructRow != null) {
                    val localAmounts = bookingAmountStructRow.getAs[mutable.WrappedArray[GenericRowWithSchema]](amounts)
                    if (localAmounts != null) {
                        for (localAmount <- localAmounts) {
                            val monetaryClassification = localAmount.getAs[GenericRowWithSchema](SQLColumnHelper.MONETARY_CLASSIFICATION)
                            val monetaryCategory = monetaryClassification.getAs[String](SQLColumnHelper.CATEGORY)
                            val money = localAmount.getAs[GenericRowWithSchema](SQLColumnHelper.MONEY)
                            val currencyCode = money.getAs[String](SQLColumnHelper.CURRENCY_COD)
                            val currencyType = money.getAs[String](SQLColumnHelper.CURRENCY_TYPE)
                            val amount = money.getAs[BigDecimal](SQLColumnHelper.AMOUNT)
                            val decimalPlaces = money.getAs[Int](SQLColumnHelper.DECIMAL_PLACES)
                            val monetaryComputationalReference = localAmount.getAs[String](SQLColumnHelper.MONETARY_COMPUTATIONAL_REFERENCE)
                            val monetaryComputationalSource: String = localAmount.getAs[String](SQLColumnHelper.MONETARY_COMPUTATIONAL_SOURCE)
                            val createDateTime: String = localAmount.getAs[String](SQLColumnHelper.CREATE_DATE_TIME)
                            val applyDate: String = localAmount.getAs[String](SQLColumnHelper.APPLY_DATE)
                            val impositionType = localAmount.getAs[String](SQLColumnHelper.AMOUNT_IMPOSITION_TYPE)
                            val jurisdictionLevel = localAmount.getAs[String](SQLColumnHelper.AMOUNT_JURISDICTION_LEVEL)
                            val jurisdictionName = localAmount.getAs[String](SQLColumnHelper.AMOUNT_JURISDICTION_NAME)
                            amountCase = amountCase :+ AmountCase(MoneyCase(currencyCode, currencyType, amount, decimalPlaces),
                                MonetaryClassificationCase(monetaryCategory, null, null), monetaryComputationalReference,
                                monetaryComputationalSource, createDateTime, applyDate, impositionType, jurisdictionLevel, jurisdictionName)
                        }
                    }
                }
            }
        }
        amountCase
    }

    private def deriveAggregatedPartnerFeeAmounts(row: Seq[GenericRowWithSchema],
                                                  amounts:String): Seq[AmountCase]=  {

        val combinedAmounts = combineAmounts(row, amounts)
        var partnerFeeMap: Map[String, AmountCase] = Map.empty[String, AmountCase]
        var partnerFeeAggregatedAmounts: Seq[AmountCase] = Seq()

        if (combinedAmounts != null || combinedAmounts.nonEmpty) {
            for (amountInp <- combinedAmounts) {
                if (amountInp != null) {
                    val monetaryCategory = amountInp.monetary_classification.category
                    val monetaryClassification = amountInp.monetary_computational_reference
                    val currencyType = amountInp.money.currency_type
                    if(SQLColumnHelper.PARTNER_FEE.equals(monetaryCategory)) {
                        var absoluteAmount: scala.math.BigDecimal = DataUtil.ZERO_AMOUNT
                        if (currencyType.equals(SQLColumnHelper.CREDIT) || currencyType.toLowerCase().equals(SQLColumnHelper.UNKNOWN)) {
                            absoluteAmount =  absoluteAmount.+(amountInp.money.amount)
                        }
                        else {
                            absoluteAmount =  absoluteAmount.-(amountInp.money.amount)
                        }

                        if (partnerFeeMap.contains(monetaryCategory + '.' + monetaryClassification)) {
                            val amountCase = partnerFeeMap.get(monetaryCategory + '.' + monetaryClassification).get;
                            amountCase.money.amount =
                                amountCase.money.amount.+(absoluteAmount)
                        }
                        else {
                            amountInp.money.amount =  absoluteAmount
                            amountInp.money.currency_type =  SQLColumnHelper.UNKNOWN
                            partnerFeeMap = partnerFeeMap + (monetaryCategory + '.' + monetaryClassification -> amountInp)
                        }
                    }
                }
            }
        }
        for( partnerFeeAmount  <- partnerFeeMap){
            partnerFeeAggregatedAmounts = partnerFeeAggregatedAmounts :+  partnerFeeAmount._2
        }
        partnerFeeAggregatedAmounts
    }

    private def deriveAggregatedAmount(bookingAmountStructRows: Seq[GenericRowWithSchema], referenceField: String,
                                       isBookDateLiability:Boolean, isCancel:Boolean): BigDecimal = {
        var aggregatedAmount: BigDecimal = DataUtil.ZERO_AMOUNT
        // TACOS-15703: Excluded monetary categories for stay date/book date liable events
        val excludedCategoryList = (isBookDateLiability, isCancel) match {
            case (true, false) => ExcludedMonetaryCategoryConstants.EXCLUDED_MONETARY_CATEGORY_LIST_BOOK_DATE
            case _ => ExcludedMonetaryCategoryConstants.EXCLUDED_MONETARY_CATEGORY_LIST
        }
        if (bookingAmountStructRows != null || bookingAmountStructRows.nonEmpty) {
            for (bookingAmountStructRow <- bookingAmountStructRows) {
                if (bookingAmountStructRow != null) {
                    val convertedAmounts = bookingAmountStructRow.getAs[mutable.WrappedArray[GenericRowWithSchema]](SQLColumnHelper.CONVERTED_AMOUNTS)
                    if (convertedAmounts != null) {
                        for (convertedAmount <- convertedAmounts) {
                            if (convertedAmount != null) {
                                val monetaryComputationalReference = convertedAmount.getAs[String](SQLColumnHelper.MONETARY_COMPUTATIONAL_REFERENCE)
                                val monetaryClassification = convertedAmount.getAs[GenericRowWithSchema](SQLColumnHelper.MONETARY_CLASSIFICATION)
                                val monetaryCategory = monetaryClassification.getAs[String](SQLColumnHelper.CATEGORY)
                                if (!excludedCategoryList.contains(monetaryCategory)) {
                                    if (monetaryComputationalReference != null
                                        && ((monetaryComputationalReference.equals(referenceField))
                                            || (monetaryComputationalReference.contains(referenceField) && referenceField.contains(SQLColumnHelper.TAX))
                                            || (monetaryComputationalReference.contains(referenceField) && referenceField.contains(SQLColumnHelper.VAT))
                                            || (monetaryCategory.equals(referenceField) && SQLColumnHelper.PARTNER_FEE.equals(referenceField)))
                                           )
                                    {
                                        val moneyCase = convertedAmount.getAs[GenericRowWithSchema](SQLColumnHelper.MONEY)
                                        val amount = moneyCase.getAs[BigDecimal](SQLColumnHelper.AMOUNT)
                                        val currencyType = moneyCase.getAs[String](SQLColumnHelper.CURRENCY_TYPE)
                                        if (currencyType.equals(SQLColumnHelper.CREDIT) || currencyType.toLowerCase().equals(SQLColumnHelper.UNKNOWN)) {
                                            aggregatedAmount = aggregatedAmount.add(amount)
                                        } else {
                                            aggregatedAmount = aggregatedAmount.subtract(amount)
                                        }
                                    }
                                }
                            }
                        }
                    }
                }
            }
        }
        return aggregatedAmount
    }

    val deriveCancelPenaltyAmountTravelerFeeUDF = udf((netTravelerFee: java.math.BigDecimal,
                                                       netEdnPartnerTravelerFee: java.math.BigDecimal,
                                                       isCancelOrRefundPresent: Boolean) => {
        deriveCancelPenaltyAmountTravelerFee(netTravelerFee, netEdnPartnerTravelerFee, isCancelOrRefundPresent)
    })

    val deriveCancelPenaltyAmountRentUDF = udf((bookingAmountStructRows: Seq[GenericRowWithSchema], referenceField: String,
                                                sumOfTaxes:BigDecimal, sumOfVAT:BigDecimal, isCancelPresent: Boolean) => {
        val (finalStructRows, _) = joinHistoryFromGroupedRows(bookingAmountStructRows, isCancel = isCancelPresent)
        deriveCancelPenaltyAmountRent(finalStructRows, referenceField, sumOfTaxes, sumOfVAT, isCancelPresent)
    })


    private def deriveCancelPenaltyAmountTravelerFee(netTravelerFee: BigDecimal,
                                                     netEdnPartnerTravelerFee: BigDecimal,
                                                     isCancelOrRefundPresent: Boolean): BigDecimal = {
        if (!isCancelOrRefundPresent) return DataUtil.ZERO_AMOUNT
        netTravelerFee.add(netEdnPartnerTravelerFee)
    }

    private def deriveCancelPenaltyAmountRent(bookingAmountStructRows: Seq[GenericRowWithSchema], referenceField: String,
                                              sumOfTaxes:BigDecimal, sumOfVAT:BigDecimal, isCancelOrRefundPresent: Boolean): BigDecimal = {
        //Cancellation Penalty Rent = ABS (initial_booking (Owner_rent+Owner_rent_projected) - refund (Owner_rent))
        var aggregatedAmount: BigDecimal = DataUtil.ZERO_AMOUNT
        if (!isCancelOrRefundPresent) return aggregatedAmount
        for (bookingAmountStructRow <- bookingAmountStructRows) {
            val convertedAmounts = bookingAmountStructRow.getAs[mutable.WrappedArray[GenericRowWithSchema]](SQLColumnHelper.CONVERTED_AMOUNTS)
            if (convertedAmounts != null) {
                for (convertedAmount <- convertedAmounts) {
                    val monetaryComputationalReference = convertedAmount.getAs[String](SQLColumnHelper.MONETARY_COMPUTATIONAL_REFERENCE)
                    if (monetaryComputationalReference != null &&
                        monetaryComputationalReference.equals(referenceField)
                    ) {
                        val moneyCase = convertedAmount.getAs[GenericRowWithSchema](SQLColumnHelper.MONEY)
                        val amount = moneyCase.getAs[BigDecimal](SQLColumnHelper.AMOUNT)
                        val currencyType = moneyCase.getAs[String](SQLColumnHelper.CURRENCY_TYPE)
                        if (currencyType.equals(SQLColumnHelper.CREDIT) || currencyType.toLowerCase().equals(SQLColumnHelper.UNKNOWN)) {
                            aggregatedAmount = aggregatedAmount.add(amount)
                        } else {
                            aggregatedAmount = aggregatedAmount.subtract(amount)
                        }
                    }
                }
            }
        }
        aggregatedAmount = aggregatedAmount.subtract(sumOfVAT)
        return aggregatedAmount.subtract(sumOfTaxes)
    }

    val sumDerivedVrboAmountsUdf = udf {(supplierServiceFee: java.math.BigDecimal,
                                         morProcessingFee: java.math.BigDecimal,
                                         brandServiceFee: java.math.BigDecimal,
                                         ednServiceFee: java.math.BigDecimal,
                                         partnerFee: java.math.BigDecimal) =>
        sumDerivedVrboAmounts(supplierServiceFee, morProcessingFee, brandServiceFee, ednServiceFee, partnerFee)
    }

    val sumTravelerFeeEdnPartnerTravelerFeeUdf = udf {(travelerFee: java.math.BigDecimal,
                                                   ednPartnerTravelerFee: java.math.BigDecimal) =>
        sumTravelerFeeEdnPartnerTravelerFee(travelerFee, ednPartnerTravelerFee)
    }

    val sumBrandServiceFeeEdnServiceFeeUdf = udf {(brandServiceFee: java.math.BigDecimal,
                                                   ednServiceFee: java.math.BigDecimal) =>
        sumBrandServiceFeeEdnServiceFee(brandServiceFee, ednServiceFee)
    }
    private def sumTravelerFeeEdnPartnerTravelerFee(travelerFee: BigDecimal,
                                                    ednPartnerTravelerFee: BigDecimal): BigDecimal = {
        travelerFee.add(ednPartnerTravelerFee)
    }

    def sumDerivedVrboAmounts(supplierServiceFee: java.math.BigDecimal,
                              morProcessingFee: java.math.BigDecimal,
                              brandServiceFee: java.math.BigDecimal,
                              ednServiceFee: java.math.BigDecimal,
                              partnerFee:java.math.BigDecimal): BigDecimal = {
        supplierServiceFee.add(morProcessingFee).add(brandServiceFee).add(ednServiceFee).subtract(partnerFee)
    }

    def sumBrandServiceFeeEdnServiceFee(brandServiceFee: java.math.BigDecimal,
                                        ednServiceFee: java.math.BigDecimal): BigDecimal = {
        brandServiceFee.add(ednServiceFee)
    }

    def deriveVrboLegalEntityInfo(dataframe: DataFrame): DataFrame = {
        val existingColumns = dataframe.columns.map(colName => col(colName))

        // as per TACOS-15986 Changing traveler booking site for SUPPLIER_MASTER_BRAND
        val dataframeWithLegalEntityMap = dataframe
            .withColumn(SQLColumnHelper.LEGAL_ENTITY_INFO, DataUtil.getLegalEntityInfo(col(SQLColumnHelper.SUPPLIER_MASTER_BRAND)))
            .select(
                existingColumns ++ Seq(
                    col(SQLColumnHelper.LEGAL_ENTITY_INFO_1).alias(SQLColumnHelper.LEGAL_ENTITY_NAME),
                    col(SQLColumnHelper.LEGAL_ENTITY_INFO_2).alias(SQLColumnHelper.LEGAL_ENTITY_CODE)
                ): _*
            )
        dataframeWithLegalEntityMap
    }

    val getLegalEntityInfo = org.apache.spark.sql.functions.udf { (brandCode: String) =>
        val (legalEntityId, legalEntityName, legalEntityCode) = VrboLegalEntityMapping.combinedMap.getOrElse(brandCode, ("", "", ""))
        (legalEntityName, legalEntityCode)
    }

    def getColumnFromAmountStruct(bkgTransRows: Seq[GenericRowWithSchema],
                                  targetField: String) : BigDecimal =
    {
        var target : BigDecimal = ZERO_AMOUNT
        for (bkgTransRow <- bkgTransRows) {
            target = bkgTransRow.getAs[BigDecimal](targetField)
        }
        target
    }

    private def isTaxZeroForLegalEntity(legalEntityCode: String, zeroTaxLegalEntities: String): Boolean = {
        if (zeroTaxLegalEntities == null || zeroTaxLegalEntities.trim.isEmpty) {
            return false
        }
        zeroTaxLegalEntities.split(",").toList.contains(legalEntityCode)
    }

    /* Renaming the columns with same column names to remove "Missing attributes(s)" error (https://issues.apache.org/jira/browse/SPARK-10925)
        which commonly arises when two DFs are used in any operation and they originally rooted from same DF.
    */
    def renameColumns (dataframe: DataFrame): DataFrame = {
        var df = dataframe.alias("df")
        for (col <- df.columns) {
            df = df.withColumnRenamed(col, col)
        }
        df
    }

    val computeTransactionTypeName = udf((transactionTypeName: String) => {
        getTransactionTypeName(transactionTypeName)
    })

    def getTransactionTypeName(transactionValue: String): String = {
        transactionTypeNameMap.getOrElse(transactionValue.toUpperCase(), "")
    }

    val computeTransactionLiabilityDateType = udf((bookingEventDate: String, useDate: String) => {
        getTransactionLiabilityDateType(bookingEventDate, useDate)
    })

    def getTransactionLiabilityDateType(bookingEventDateVal: String, useDateVal: String): String = {
        var transactionLiabilityDateType = ""
        val dateFormat = new SimpleDateFormat("yyyy-MM-dd");
        try {
            val bookingEventDateParse: Date = dateFormat.parse(bookingEventDateVal)
            val useDateParse: Date = dateFormat.parse(useDateVal)

            if (bookingEventDateParse.after(useDateParse)) {
                transactionLiabilityDateType = "bookingEventDate"
            } else {
                transactionLiabilityDateType = "stayDate"
            }
        } catch {
            case e: Exception =>
                logger.error("Error comparing dates: ", e.getMessage)
        }

        transactionLiabilityDateType
    }

    def createExceptionSchema(originalSchema: StructType): StructType = {
        originalSchema
            .add(SQLColumnHelper.EXCEPTIONS,ArrayType(StructType(Array(
                StructField(SQLColumnHelper.EXCEPTION_CODE, IntegerType, true),
                StructField(SQLColumnHelper.EXCEPTION_TYPE, StringType, true),
                StructField(SQLColumnHelper.EXCEPTION_DESCRIPTION, StringType, true),
                StructField(SQLColumnHelper.IS_CRITICAL_EXCEPTION, BooleanType, true)
            ))), true)
            .add(
                StructField(SQLColumnHelper.NON_TRAVEL_ITEM, StructType(Array(
                    StructField(SQLColumnHelper.INVOICE_DATE, StringType, true),
                    StructField(SQLColumnHelper.INVOICE_NUMBER, StringType, true),
                    StructField(SQLColumnHelper.INVOICE_LINE_NUMBER, StringType, true),
                    StructField(SQLColumnHelper.INVOICE_TYPE, StringType, true),
                    StructField(SQLColumnHelper.PRODUCT_TYPE, StringType, true),
                    StructField(SQLColumnHelper.INVOICE_LEGAL_ENTITY_CODE, StringType, true),
                    StructField(SQLColumnHelper.INVOICE_LEGAL_ENTITY_NAME, StringType, true),
                    StructField(SQLColumnHelper.ADDITIONAL_ATTRIBUTES, DataTypes.createMapType(DataTypes.StringType, DataTypes.StringType), true)
                )), true)
            )
    }

    def createRuleAttributeSchema(): StructType = {
        new StructType()
            .add("key", DataTypes.StringType, true)
            .add("values", DataTypes.createArrayType(DataTypes.StringType))
            .add("start_effective_date", DataTypes.StringType)
            .add("end_effective_date", DataTypes.StringType)
    }

    val createTaxProfileAttributesUdf = udf[Map[String, String], SqlDate, Seq[GenericRowWithSchema],
        Seq[GenericRowWithSchema], Seq[GenericRowWithSchema], Seq[GenericRowWithSchema]](createTaxProfileAttributesMap)

    def createTaxProfileAttributesMap(transLiabilityDate: SqlDate,
                                      taxDefinedAttributesAccuracy: Seq[GenericRowWithSchema],
                                      taxDefinedAttributesFiling: Seq[GenericRowWithSchema],
                                      supplierAttributesAccuracy: Seq[GenericRowWithSchema],
                                      supplierAttributesFiling: Seq[GenericRowWithSchema]): Map[String, String] = {
        if (taxDefinedAttributesAccuracy == null ||
            taxDefinedAttributesFiling == null ||
            supplierAttributesAccuracy == null ||
            supplierAttributesFiling == null) {
            return Map()
        }
        val taxProfileAttributesMap = mutable.Map[String, String]()
        putAttributesIntoMap(taxDefinedAttributesAccuracy, transLiabilityDate, taxProfileAttributesMap)
        putAttributesIntoMap(taxDefinedAttributesFiling, transLiabilityDate, taxProfileAttributesMap)
        putAttributesIntoMap(supplierAttributesAccuracy, transLiabilityDate, taxProfileAttributesMap)
        putAttributesIntoMap(supplierAttributesFiling, transLiabilityDate, taxProfileAttributesMap)
        taxProfileAttributesMap.toMap
    }

    private def putAttributesIntoMap(attributes: Seq[GenericRowWithSchema],
                                     transLiabilityDate: SqlDate,
                                     attributesMap: mutable.Map[String, String]): Unit = {
        for (attribute <- attributes) {
            val key = attribute.getAs[String](SQLColumnHelper.TAX_PROFILE_KEY)
            val values = attribute.getAs[Seq[String]](SQLColumnHelper.TAX_PROFILE_VALUES)
            val startDate = attribute.getAs[String](SQLColumnHelper.TAX_PROFILE_START_DATE)
            val endDate = attribute.getAs[String](SQLColumnHelper.TAX_PROFILE_END_DATE)

            val isActive = transLiabilityDate.compareTo(SqlDate.valueOf(startDate)) >= 0 &&
                transLiabilityDate.compareTo(SqlDate.valueOf(endDate)) <= 0

            if (isActive) {
                attributesMap.put(key, values.head)
            }
        }
    }

    def isRuleUpdatedWithinDateRange(rule: TaxEngineConfigRule, startDate: String, endDate: String): Boolean = {
        val ruleUpdateDate: LocalDate = getDateFromTimestamp(rule)
        val startDateObj = LocalDate.parse(startDate)
        val endDateObj = LocalDate.parse(endDate)
        !(ruleUpdateDate.isBefore(startDateObj) || ruleUpdateDate.isAfter(endDateObj))
    }

    def getDateFromTimestamp(rule: TaxEngineConfigRule): LocalDate = {
        val lastModifiedTimestamp = rule.getAuditTrail.getActionTime
        val ruleUpdateDate = Instant
            .ofEpochSecond(lastModifiedTimestamp.getSeconds(), lastModifiedTimestamp.getNanos())
            .atZone(ZoneId.of("America/Los_Angeles"))
            .toLocalDate
        ruleUpdateDate
    }

    def getEffectiveDate(effectiveDate: com.expediagroup.time.v1.Date): String = {
        s"${effectiveDate.getYear}-${effectiveDate.getMonth}-${effectiveDate.getDay}"
    }

    def createSTACSchema(): StructType = {
        new StructType()
            .add("event_header", createEventHeaderSchema, true)
            .add("supplier_id", DataTypes.StringType, false)
            .add("sub_supplier_id", DataTypes.StringType, true)
            .add("line_of_business", DataTypes.StringType, true)
            .add("seller", DataTypes.StringType, true)
            .add("state", DataTypes.StringType, true)
            .add("city", DataTypes.StringType, true)
            .add("sub_supplier_type", DataTypes.StringType, true)
            .add("attributes", DataTypes.createArrayType(createSTACAttributeSchema()), true)
            .add("country_code", DataTypes.StringType, false)
    }

    def createEventHeaderSchema(): StructType = {
        new StructType()
            .add("event_uuid", DataTypes.StringType, true)
            .add("published_timestamp", DataTypes.StringType, true)
            .add("event_context_ids",
                new ArrayType(new StructType()
                    .add("type", DataTypes.StringType, true)
                    .add("id", DataTypes.StringType, true)
                    , true), true)
    }

    def createHierarchyContextSchema(): StructType = {
        new StructType()
            .add("type", DataTypes.StringType, true)
            .add("value", DataTypes.StringType, true)
            .add("value_map", DataTypes.createMapType(DataTypes.StringType, DataTypes.StringType), true)
    }

    def createSTACAttributeSchema(): StructType = {
        new StructType()
            .add("key", DataTypes.StringType, false)
            .add("values", DataTypes.createArrayType(DataTypes.StringType), true)
            .add("start_date", DataTypes.DateType, true)
            .add("end_date", DataTypes.DateType, true)
            .add("heirarchy_contexts", DataTypes.createArrayType(createHierarchyContextSchema()), true)
            .add("version", DataTypes.LongType, true)
            .add("isoverride", DataTypes.BooleanType, true)
    }

    def createVRBORoomProfileSchema(): StructType = {
        new StructType()
            .add("unit_uri", DataTypes.StringType, false)
            .add("listing_identifier", DataTypes.StringType, false)
    }

    def deriveVrboBusinessModel(dataFrame: DataFrame): DataFrame = {
        val dataframeWithBusinessModelName = dataFrame.withColumn(SQLColumnHelper.ORIGINAL_BUSINESS_MODEL_NAME,
            when(col(SQLColumnHelper.RESERVATION_STATE) === SQLColumnHelper.EXTERNAL_SOR && (col(SQLColumnHelper.MERCHANT_OF_RECORD_TYPE) === SQLColumnHelper.SUPPLIER || col(SQLColumnHelper.MERCHANT_OF_RECORD_TYPE).isNull),
                SQLColumnHelper.AGENCY)
            .otherwise(SQLColumnHelper.VRBO_MOR))

        // Get all the bookings with at least one event related to EXTERNAL_SOR/AGENCY derivations
        val bookingIdsWithAgencyEvents = dataframeWithBusinessModelName
            .select(col(SQLColumnHelper.RESERVATION_UUID).alias("tmpBkngItemId"))
            .filter(col(SQLColumnHelper.ORIGINAL_BUSINESS_MODEL_NAME) === SQLColumnHelper.AGENCY)
            .distinct()

        val bookingIdsWithHamorEvents = dataframeWithBusinessModelName
            .select(col(SQLColumnHelper.RESERVATION_UUID).alias("tmpHamorBkngItemId"))
            .filter(col(SQLColumnHelper.RESERVATION_STATE) === SQLColumnHelper.EXTERNAL_SOR && col(SQLColumnHelper.MERCHANT_OF_RECORD_TYPE) === SQLColumnHelper.HAMOR)
            .distinct()

        // Join with the bookingIdsWithAgencyEvents and, if there's a match, assign AGENCY to all the txns with the same business model name
        // if not, keep them as Vrbo MOR
        var bookingDFWithBussinessModel = dataframeWithBusinessModelName
            .join(bookingIdsWithAgencyEvents,
                col(SQLColumnHelper.RESERVATION_UUID) === col("tmpBkngItemId"),
                "left")
            .join(bookingIdsWithHamorEvents,
                col(SQLColumnHelper.RESERVATION_UUID) === col("tmpHamorBkngItemId"),
                "left")
            .withColumn(SQLColumnHelper.ORIGINAL_BUSINESS_MODEL_NAME,
                when(col("tmpBkngItemId").isNotNull && col("tmpHamorBkngItemId").isNull, SQLColumnHelper.AGENCY)
                    .otherwise(SQLColumnHelper.VRBO_MOR))
            .drop(col("tmpHamorBkngItemId"))

        bookingDFWithBussinessModel = bookingDFWithBussinessModel.withColumn(SQLColumnHelper.BUSINESS_MODEL_NAME,
            lit(SQLColumnHelper.VRBO_MOR))
        bookingDFWithBussinessModel
    }
}
