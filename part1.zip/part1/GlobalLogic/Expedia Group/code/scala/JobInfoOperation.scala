package com.expediagroup.platform.taxcompliance.jobinfo

import com.expediagroup.platform.taxcompliance.constants.AppConstants
import com.expediagroup.platform.taxcompliance.sql.SQLColumnHelper
import org.apache.spark.sql.SparkSession
import org.springframework.beans.factory.annotation.Value
import org.springframework.stereotype.Component

@Component("com.expediagroup.platform.taxcompliance.jobinfo.JobInfoOperation")
class JobInfoOperation {

    @Value("${com.expediagroup.platform.taxcompliance.eg.job.info.table}")
    val egJobInfoTable : String = null

    def checkJobInfoStatus(sqlc: SparkSession, jobInfoData: JobInfoDataCase, checkType: String): Boolean ={

        val failedJobRecordsDF = sqlc.sql(
            raw"""
                SELECT *
                FROM ${egJobInfoTable} fr
                WHERE lower(run_status) == lower('${AppConstants.TYPE_JOB_STATUS_FAILED}')
                    and start_liability_date <= cast('${jobInfoData.endLiabilityDate}' as date)
                    and end_liability_date >= cast('${jobInfoData.startLiabilityDate}' as date)
                    and job_name = '${jobInfoData.jobName}'
                    and lower(workflow_type) in ('${AppConstants.WORKFLOW_TYPE_NORMAL}', '${AppConstants.WORKFLOW_TYPE_CATCH_UP}')
        """)

        val nonFailedJobRecordsDF = sqlc.sql(
            raw"""
                SELECT *
                FROM ${egJobInfoTable} nfr
                WHERE start_liability_date <= cast('${jobInfoData.endLiabilityDate}' as date)
                    and end_liability_date >= cast('${jobInfoData.startLiabilityDate}' as date)
                    and job_name = '${jobInfoData.jobName}' and lower(run_status) != lower('${AppConstants.TYPE_JOB_STATUS_FAILED}')
                    and lower(workflow_type) in ('${AppConstants.WORKFLOW_TYPE_NORMAL}', '${AppConstants.WORKFLOW_TYPE_CATCH_UP}')
        """)

        val succeededRecordsDF = sqlc.sql(
            raw"""
                SELECT *
                FROM ${egJobInfoTable} sr
                WHERE start_liability_date <= cast('${jobInfoData.endLiabilityDate}' as date)
                    and end_liability_date >= cast('${jobInfoData.startLiabilityDate}' as date)
                    and job_name = '${jobInfoData.jobName}' and lower(run_status) == lower('${AppConstants.TYPE_JOB_STATUS_COMPLETED}')
                    and lower(workflow_type) in ('${AppConstants.WORKFLOW_TYPE_NORMAL}', '${AppConstants.WORKFLOW_TYPE_CATCH_UP}')
        """)

        val jobRecordsCount = nonFailedJobRecordsDF.count() - failedJobRecordsDF.count()

        if( (checkType == AppConstants.PIPELINE_TRIGGER_PRE_CHECK && jobRecordsCount > 0) ||
            (checkType == AppConstants.PIPELINE_TRIGGER_POST_CHECK && succeededRecordsDF.count() != 1) ) {
            throw new Exception("Job: " + jobInfoData.jobName + " has been already executed for this date(s).")
        }

        true
    }

    def persistJobInfo(sqlc: SparkSession, jobInfoData: JobInfoDataCase): Unit ={

        sqlc.sql(
            raw"""
                            INSERT INTO TABLE ${egJobInfoTable}
							PARTITION(${SQLColumnHelper.END_LIABILITY_DATE})
                            VALUES(
                                '${jobInfoData.jobRunId}',
                                '${jobInfoData.tableName}',
                                '${jobInfoData.jobName}',
                                '${jobInfoData.jobDescription}',
                                '${jobInfoData.pipelineProcessType}',
                                '${jobInfoData.workflowType}',
                                '${jobInfoData.jobUpdateDateTime}',
                                '${jobInfoData.runStatus}',
                                '${jobInfoData.isActive}',
                                '${jobInfoData.triggeredBy}',
                                '${jobInfoData.startLiabilityDate}',
                                '${jobInfoData.product_line_name}',
                                '${jobInfoData.endLiabilityDate}'
                                )
	           """)
    }

}
