package com.expediagroup.platform.taxcompliance.sql

import com.expediagroup.platform.taxcompliance.DataCollectorOperation
import com.expediagroup.platform.taxcompliance.constants.AppConstants.NON_TRAVEL_PRODUCT_LINES
import com.expediagroup.platform.taxcompliance.constants.{AppConstants, DigitalServiceConstant, StacConstants}
import com.expediagroup.platform.taxcompliance.sql.SQLColumnHelper.partnerItemCarColumns
import com.expediagroup.platform.taxcompliance.sql.SQLColumnHelperBookingTransactionsBackfillLx.PRODUCT_LINE_NAME_COLUMN
import com.expediagroup.platform.taxcompliance.util.DataUtil
import com.expediagrouplatform.taxcompliance.sql.SQLColumnHelperPostStayTransactionsLodging
import org.apache.spark.sql.functions._
import org.apache.spark.sql.types.DataTypes
import org.apache.spark.sql.{DataFrame, SparkSession}
import org.slf4j.LoggerFactory
import org.springframework.context.annotation.ComponentScan
import org.springframework.stereotype.Component

@Component
class SQLBuilder extends DataCollectorOperation {
    private val logger = LoggerFactory.getLogger(this.getClass)

    def getSelectAllEnrichedTransactionQuery(sparkSession: SparkSession, startDate: String,
                                             endDate: String, dateType: String) = {
        createSelectAllEnrichedTransactionQuery(sparkSession, startDate, endDate, dateType)
    }

    private def createSelectAllEnrichedTransactionQuery(sparkSession: SparkSession, startDate: String,
                                                        endDate: String, dateType: String) = {
        val stayDateRange =
            s"""(date_format(${SQLColumnHelper.TRANSACTION_LIABILITY_DATE}, "yyyy-MM-dd") >= '${startDate}'
               | and date_format(${SQLColumnHelper.TRANSACTION_LIABILITY_DATE}, "yyyy-MM-dd") <= '${endDate}')
               | and ${SQLColumnHelper.TRANSACTION_LIABILITY_DATE_TYPE} = '${dateType}'""".stripMargin
        sparkSession.sql(
            raw"""
              SELECT
                               ${SQLColumnHelper.EVENT_INFO}.${SQLColumnHelper.EVENT_UUID},
                               ${SQLColumnHelper.EVENT_INFO}.${SQLColumnHelper.PUBLISHED_TIMESTAMP},
                               ${SQLColumnHelper.BOOKING_ITEM},
                               ${SQLColumnHelper.ITEM_AMOUNT},
                               ${SQLColumnHelper.PROPERTY_ITEM},
                               ${SQLColumnHelper.BOOKING_DETAIL},
                               ${SQLColumnHelper.EVENT_INFO},
                               ${SQLColumnHelper.CAR_ITEM},
                               ${SQLColumnHelper.LOCAL_AMOUNTS},
                               ${SQLColumnHelper.CONVERTED_AMOUNTS},
                               ${SQLColumnHelper.PARTNER_ITEM},
                               null as ${SQLColumnHelper.NON_TRAVEL_ITEM},
                               null as ${SQLColumnHelper.BOOKING_HISTORY},
                               ${SQLColumnHelper.TRANSACTION_LIABILITY_DATE},
                               ${SQLColumnHelper.TRANSACTION_LIABILITY_DATE_TYPE},
                               ${SQLColumnHelper.PRODUCT_LINE_NAME}
                            FROM ${stagedEnrichedTransactions}
                            WHERE ${stayDateRange}
       """)
    }

    def getSelectFromExceptionViewQuery(sparkSession: SparkSession, tableView: String, transLiabilityDate: String,
                                        dateType: String) = {
        createSelectFromExceptionViewQuery(sparkSession, tableView, transLiabilityDate, dateType)
    }

    private def createSelectFromExceptionViewQuery(sparkSession: SparkSession, tableView: String,
                                                   transLiabilityDate: String, dateType: String): DataFrame = {
        sparkSession.sql(
            raw"""
              SELECT
                                ${SQLColumnHelper.BOOKING_ID},
                                ${SQLColumnHelper.BOOKING_ITEM_ID},
                                ${SQLColumnHelper.BOOKING_EVENT_DATE},
                                ${SQLColumnHelper.BOOKING_EVENT_DATETIME},
                                ${SQLColumnHelper.TRANSACTION_TYPE_NAME},
                                ${SQLColumnHelper.TRANSACTION_TYPE_KEY},
                                ${SQLColumnHelper.SOURCE_SYSTEM_ID},
                                ${SQLColumnHelper.COST_CURRENCY_CODE},
                                ${SQLColumnHelper.STAY_DATE},
                                ${SQLColumnHelper.CAR_LOCATION_ID},
                                ${SQLColumnHelper.EVENT_UUID},
                                ${SQLColumnHelper.eventInfoColumns},
                                ${SQLColumnHelper.EXCEPTIONS},
                                null as ${SQLColumnHelper.NON_TRAVEL_ITEM},
                                ${transLiabilityDate} as ${SQLColumnHelper.TRANSACTION_LIABILITY_DATE},
                                '${dateType}' as ${SQLColumnHelper.TRANSACTION_LIABILITY_DATE_TYPE},
                                ${SQLColumnHelper.PRODUCT_LINE_NAME}
              FROM ${tableView}
    """)
    }

    def getSelectAllFromExceptionTableQuery(sparkSession: SparkSession, startDate: String, endDate: String,
                                            transLiabilityDate: String, dateType: String) = {
        createSelectAllFromExceptionTableQuery(sparkSession, startDate, endDate, transLiabilityDate, dateType)
    }

    private def createSelectAllFromExceptionTableQuery(sparkSession: SparkSession, startDate: String, endDate: String,
                                                       transLiabilityDate: String, dateType: String): DataFrame = {

        sparkSession.sql(
            raw"""
              SELECT
                                ${SQLColumnHelper.BOOKING_ID},
                                ${SQLColumnHelper.BOOKING_ITEM_ID},
                                ${SQLColumnHelper.BOOKING_EVENT_DATE},
                                ${SQLColumnHelper.BOOKING_EVENT_DATETIME},
                                ${SQLColumnHelper.TRANSACTION_TYPE_NAME},
                                ${SQLColumnHelper.TRANSACTION_TYPE_KEY},
                                ${SQLColumnHelper.SOURCE_SYSTEM_ID},
                                ${SQLColumnHelper.COST_CURRENCY_CODE},
                                ${SQLColumnHelper.STAY_DATE},
                                ${SQLColumnHelper.CAR_LOCATION_ID},
                                ${SQLColumnHelper.EVENT_INFO}.${SQLColumnHelper.EVENT_UUID},
                                ${SQLColumnHelper.EVENT_INFO},
                                ${SQLColumnHelper.EXCEPTIONS},
                                null as ${SQLColumnHelper.NON_TRAVEL_ITEM},
                                ${transLiabilityDate} as ${SQLColumnHelper.TRANSACTION_LIABILITY_DATE},
                                '${dateType}' as ${SQLColumnHelper.TRANSACTION_LIABILITY_DATE_TYPE},
                                ${SQLColumnHelper.PRODUCT_LINE_NAME}
              FROM ${stagedExceptionTransactions}
                            WHERE ${SQLColumnHelper.TRANSACTION_LIABILITY_DATE} >= ${startDate}
                            AND ${SQLColumnHelper.TRANSACTION_LIABILITY_DATE} <= ${endDate}
                  """)
    }

    def selectEnrichedTransactionQuery(sparkSession: SparkSession, tableView: String, transLiabilityDate: String,
                                       dateType: String, productLineName: String) = {
        var propertyItemCol: String = SQLColumnHelper.propertyItemColumnsWithoutStacData
        var tempPropertyItemCol: String = SQLColumnHelper.tempPropertyItemColumnsWithoutStacData
        var carItemCol: String = null
        var carItemCol1: String = null
        var partnerItemCols: String = SQLColumnHelper.partnerItemLodgingColumnsWithoutStacData

        if (useStacAttributesFeature) {
            val replacementString = getStacAttributesReplacementString(getDistinctStacAtributes(sparkSession, productLineName))
            partnerItemCols = SQLColumnHelper.partnerItemLodgingColumnsWithStacData.replace("stac_replacement_fields", replacementString)
            propertyItemCol = SQLColumnHelper.propertyItemColumnsWithStacData
            tempPropertyItemCol = SQLColumnHelper.tempPropertyItemColumnsWithStacData
        }

        if (productLineName.equalsIgnoreCase(AppConstants.PRODUCT_LINE_NAME_CAR)) {
            propertyItemCol = null
            tempPropertyItemCol = null
            partnerItemCols = partnerItemCarColumns
            carItemCol = SQLColumnHelper.carItemColumns
            carItemCol1 = SQLColumnHelper.CAR_ITEM
        } else if (productLineName.equalsIgnoreCase(AppConstants.PRODUCT_LINE_NAME_LX)) {
            propertyItemCol = null
            tempPropertyItemCol = null
            partnerItemCols = SQLColumnHelper.partnerItemLxColumns
            carItemCol = "null AS " + SQLColumnHelper.CAR_ITEM
            carItemCol1 = SQLColumnHelper.CAR_ITEM
        }

        val enrichedTransactionDfFromView = sparkSession.sql(
            raw"""
              SELECT
                                ${SQLColumnHelper.EVENT_UUID},
                                ${SQLColumnHelper.PUBLISHED_TIMESTAMP},
                                ${SQLColumnHelper.bookingItemColumns},
                                ${SQLColumnHelper.itemAmountColumns},
                                ${propertyItemCol},
                                ${SQLColumnHelper.bookingDetailsColumn},
                                ${SQLColumnHelper.eventInfoColumns},
                                ${carItemCol},
                                ${SQLColumnHelper.LOCAL_AMOUNTS},
                                ${SQLColumnHelper.CONVERTED_AMOUNTS},
                                ${partnerItemCols},
                                null as  ${SQLColumnHelper.NON_TRAVEL_ITEM},
                                ${transLiabilityDate} as ${SQLColumnHelper.TRANSACTION_LIABILITY_DATE},
                                '${dateType}' as ${SQLColumnHelper.TRANSACTION_LIABILITY_DATE_TYPE},
                                ${SQLColumnHelper.PRODUCT_LINE_NAME}
              FROM ${tableView}
       """)

        enrichedTransactionDfFromView.createOrReplaceTempView("tempEnrichedTransactionView")

        sparkSession.sql(
            raw"""
              SELECT
                                ${SQLColumnHelper.EVENT_UUID},
                                ${SQLColumnHelper.PUBLISHED_TIMESTAMP},
                                ${SQLColumnHelper.BOOKING_ITEM},
                                ${SQLColumnHelper.ITEM_AMOUNT},
                                ${tempPropertyItemCol},
                                ${SQLColumnHelper.BOOKING_DETAIL},
                                ${SQLColumnHelper.EVENT_INFO},
                                ${carItemCol1},
                                ${SQLColumnHelper.LOCAL_AMOUNTS},
                                ${SQLColumnHelper.CONVERTED_AMOUNTS},
                                ${SQLColumnHelper.PARTNER_ITEM},
                                ${SQLColumnHelper.NON_TRAVEL_ITEM},
                                null as  ${SQLColumnHelper.BOOKING_HISTORY},
                                ${SQLColumnHelper.TRANSACTION_LIABILITY_DATE},
                                ${SQLColumnHelper.TRANSACTION_LIABILITY_DATE_TYPE},
                                ${SQLColumnHelper.PRODUCT_LINE_NAME}
              FROM tempEnrichedTransactionView
       """)
    }

    /**
     * select product address details based on product type.
     * lodging - retuns hotel/property address
     * car - returns car pick up location address
     *
     * @param sqlc
     * @param productLineName
     * @return
     */
    def selectProductAddressDetails(sqlc: SparkSession, productLineName: String): DataFrame = {
        val bookingTransDF = sqlc.sql(
            raw"""
            WITH product_catalog AS (
                SELECT
                DISTINCT ${SQLColumnHelper.SUPPLIER_ID} AS ${SQLColumnHelper.PRODUCT_CATALOG_SUPPLIER_ID},
                          ${SQLColumnHelper.SUPPLIER_NAME} AS ${SQLColumnHelper.PRODUCT_CATALOG_SUPPLIER_NAME},
                          ${SQLColumnHelper.CLEANSED_STATE},
                          ${SQLColumnHelper.CLEANSED_CITY},
                          ${SQLColumnHelper.CLEANSED_STREET_ADDRESS1},
                          ${SQLColumnHelper.CLEANSED_STREET_ADDRESS2},
                          ${SQLColumnHelper.CLEANSED_COUNTRY_CODE},
                          ${SQLColumnHelper.CLEANSED_POSTAL_CODE},
                          ${SQLColumnHelper.CLEANSED_LATITUDE},
                          ${SQLColumnHelper.CLEANSED_LONGITUDE},
                          ${SQLColumnHelper.STATE} AS ${SQLColumnHelper.PRODUCT_CATALOG_STATE},
                          ${SQLColumnHelper.CITY} AS ${SQLColumnHelper.PRODUCT_CATALOG_CITY},
                          ${SQLColumnHelper.STREET_ADDRESS1} AS ${SQLColumnHelper.PRODUCT_CATALOG_STREET_ADDRESS1},
                          ${SQLColumnHelper.STREET_ADDRESS2} AS ${SQLColumnHelper.PRODUCT_CATALOG_STREET_ADDRESS2},
                          ${SQLColumnHelper.POSTAL_CODE} AS ${SQLColumnHelper.PRODUCT_CATALOG_POSTAL_CODE},
                          ${SQLColumnHelper.PROPERTY_LATITUDE} AS ${SQLColumnHelper.PRODUCT_CATALOG_LATITUDE},
                          ${SQLColumnHelper.PROPERTY_LONGITUDE} AS ${SQLColumnHelper.PRODUCT_CATALOG_LONGITUDE},
                          ${SQLColumnHelper.COUNTRY_CODE} AS ${SQLColumnHelper.PRODUCT_CATALOG_COUNTRY_CODE},
                          ${SQLColumnHelper.PRODUCT_CATALOG_ATTRIBUTES},
                          ${SQLColumnHelper.EVENT_HEADER_PUBLISHED_TIMESTAMP} AS ${SQLColumnHelper.PC_PUBLISHED_TIMESTAMP}
                FROM
                    $productCatalogTransactions productCatalog
                WHERE
                    (LOWER( productCatalog.line_of_business ) = LOWER( '$productLineName' )
                    OR LOWER( productCatalog.line_of_business ) = LOWER( CONCAT('HOTWIRE','$productLineName') ))
                    AND UPPER( productCatalog.country_code ) IN ('USA', 'PRI')
            ),
            latest AS (
                SELECT
                    ${SQLColumnHelper.SUPPLIER_ID},
                    MAX(${SQLColumnHelper.EVENT_HEADER_PUBLISHED_TIMESTAMP}) AS ${SQLColumnHelper.PC_PUBLISHED_TIMESTAMP}
                FROM $productCatalogTransactions
                WHERE
                    (LOWER( line_of_business ) = LOWER( '$productLineName' )
                    OR LOWER( line_of_business ) = LOWER( CONCAT('HOTWIRE','$productLineName') ))
                GROUP BY ${SQLColumnHelper.SUPPLIER_ID}
            )
            SELECT product_catalog.*
            FROM product_catalog
            INNER JOIN latest
                ON product_catalog.${SQLColumnHelper.PRODUCT_CATALOG_SUPPLIER_ID} = latest.${SQLColumnHelper.SUPPLIER_ID}
                AND product_catalog.${SQLColumnHelper.PC_PUBLISHED_TIMESTAMP} = latest.${SQLColumnHelper.PC_PUBLISHED_TIMESTAMP}
  """)
        bookingTransDF.drop(SQLColumnHelper.PC_PUBLISHED_TIMESTAMP)
    }

    def selectProductCatalogTransactionsForVrbo(sparkSession: SparkSession): DataFrame = {


        val bookingTransDF = sparkSession.sql(
            raw"""
            WITH product_catalog AS (
                SELECT
                DISTINCT ${SQLColumnHelper.SUPPLIER_ID} AS ${SQLColumnHelper.PRODUCT_CATALOG_SUPPLIER_ID},
                    ${SQLColumnHelper.SUPPLIER_NAME} AS ${SQLColumnHelper.PRODUCT_CATALOG_SUPPLIER_NAME},
                    ${SQLColumnHelper.CLEANSED_STATE},
                    ${SQLColumnHelper.CLEANSED_CITY},
                    ${SQLColumnHelper.CLEANSED_STREET_ADDRESS1},
                    ${SQLColumnHelper.CLEANSED_STREET_ADDRESS2},
                    ${SQLColumnHelper.CLEANSED_COUNTRY_CODE},
                    ${SQLColumnHelper.CLEANSED_POSTAL_CODE},
                    ${SQLColumnHelper.CLEANSED_COUNTY},
                    ${SQLColumnHelper.CLEANSED_LATITUDE},
                    ${SQLColumnHelper.CLEANSED_LONGITUDE},
                    ${SQLColumnHelper.STATE} AS ${SQLColumnHelper.PRODUCT_CATALOG_STATE},
                    ${SQLColumnHelper.STATE} AS ${SQLColumnHelper.PROPERTY_STATE_PROVINCE_NAME},
                    ${SQLColumnHelper.CITY} AS ${SQLColumnHelper.PRODUCT_CATALOG_CITY},
                    ${SQLColumnHelper.STREET_ADDRESS1} AS ${SQLColumnHelper.PRODUCT_CATALOG_STREET_ADDRESS1},
                    ${SQLColumnHelper.STREET_ADDRESS2} AS ${SQLColumnHelper.PRODUCT_CATALOG_STREET_ADDRESS2},
                    ${SQLColumnHelper.POSTAL_CODE} AS ${SQLColumnHelper.PRODUCT_CATALOG_POSTAL_CODE},
                    ${SQLColumnHelper.PROPERTY_LATITUDE} AS ${SQLColumnHelper.PRODUCT_CATALOG_LATITUDE},
                    ${SQLColumnHelper.PROPERTY_LONGITUDE} AS ${SQLColumnHelper.PRODUCT_CATALOG_LONGITUDE},
                    ${SQLColumnHelper.COUNTRY_CODE} AS ${SQLColumnHelper.PRODUCT_CATALOG_COUNTRY_CODE},
                    ${SQLColumnHelper.COUNTY} AS ${SQLColumnHelper.PRODUCT_CATALOG_COUNTY},
                    ${SQLColumnHelper.PRODUCT_CATALOG_ATTRIBUTES},
                    ${SQLColumnHelper.EVENT_HEADER_PUBLISHED_TIMESTAMP} AS ${SQLColumnHelper.PC_PUBLISHED_TIMESTAMP}
                FROM $productCatalogTransactions productCatalog
                WHERE UPPER(productCatalog.country_code) IN ('USA', 'PRI')
                AND LOWER(productCatalog.line_of_business) = LOWER('Lodging')
                AND UPPER(seller) = 'HOMEAWAY'
            ),
            latest AS (
                SELECT
                    ${SQLColumnHelper.SUPPLIER_ID},
                    MAX(${SQLColumnHelper.EVENT_HEADER_PUBLISHED_TIMESTAMP}) AS ${SQLColumnHelper.PC_PUBLISHED_TIMESTAMP}
                FROM $productCatalogTransactions
                WHERE
                    (LOWER( line_of_business ) = LOWER( 'Lodging' ))
                GROUP BY ${SQLColumnHelper.SUPPLIER_ID}
            )
            SELECT product_catalog.*
            FROM product_catalog
            INNER JOIN latest
                ON product_catalog.${SQLColumnHelper.PRODUCT_CATALOG_SUPPLIER_ID} = latest.${SQLColumnHelper.SUPPLIER_ID}
                AND product_catalog.${SQLColumnHelper.PC_PUBLISHED_TIMESTAMP} = latest.${SQLColumnHelper.PC_PUBLISHED_TIMESTAMP}
  """)
        bookingTransDF.drop(SQLColumnHelper.PC_PUBLISHED_TIMESTAMP)

    }

    def selectRoomProfileForVrbo(sparkSession: SparkSession): DataFrame = {
        sparkSession.sql(
            raw"""
                 |SELECT DISTINCT
                 |split(${SQLColumnHelper.LISTING_IDENTIFIER},'\\.')[1] AS ${SQLColumnHelper.LISTING_ID.toLowerCase},
                 |${SQLColumnHelper.UNIT_URI} AS vrp_${SQLColumnHelper.SUPPLIER_ID}
                 |FROM $vrboRoomProfileTable
                 |""".stripMargin)
    }

    def selectStagedBookingTransactions(sqlc: SparkSession, filterCriteria: String, productLineName: String): DataFrame = {

        var propertyId: String = null
        if (productLineName.toLowerCase() == "lodging") {
            propertyId = SQLColumnHelper.PROPERTY_ITEM + "." + SQLColumnHelper.PROPERTY_ID
        }

        var bookingTransDF = sqlc.sql(
            raw"""
    SELECT
            ${SQLColumnHelper.TRANSACTION_LIABILITY_DATE}
            ,${SQLColumnHelper.PRODUCT_LINE_NAME}
            ,${SQLColumnHelper.BOOKING_ITEM}.${SQLColumnHelper.USE_DATE} as ${SQLColumnHelper.STAY_DATE}
            ,${SQLColumnHelper.BOOKING_ITEM}.${SQLColumnHelper.BOOK_DATE}
            ,${SQLColumnHelper.BOOKING_ITEM}.${SQLColumnHelper.BEGIN_USE_DATE}
            ,${SQLColumnHelper.BOOKING_ITEM}.${SQLColumnHelper.END_USE_DATE}
            ,${SQLColumnHelper.BOOKING_ITEM}.${SQLColumnHelper.BUSINESS_MODEL_NAME}
            ,${SQLColumnHelper.BOOKING_ITEM}.${SQLColumnHelper.BUSINESS_MODEL_SUBTYPE_NAME}
            ,${SQLColumnHelper.BOOKING_ITEM}.${SQLColumnHelper.ROOM_NIGHT_COUNT}
            ,${SQLColumnHelper.BOOKING_ITEM}.${SQLColumnHelper.BOOKING_ITEM_ID}
            ,${SQLColumnHelper.BOOKING_ITEM}.${SQLColumnHelper.BOOKING_ID}
            ,${SQLColumnHelper.BOOKING_ITEM}.${SQLColumnHelper.TRANSACTION_TYPE_NAME}
            ,${SQLColumnHelper.BOOKING_ITEM}.${SQLColumnHelper.BOOKING_EVENT_DATE}
            ,${SQLColumnHelper.BOOKING_ITEM}.${SQLColumnHelper.BOOKING_EVENT_DATETIME}
            ,${SQLColumnHelper.BOOKING_ITEM}.${SQLColumnHelper.SOURCE_SYSTEM_ID}
            ,${SQLColumnHelper.BOOKING_ITEM}.${SQLColumnHelper.TRAVEL_PRODUCT_ID}
            ,${SQLColumnHelper.BOOKING_ITEM}.${SQLColumnHelper.TOTAL_TRAVELER_COUNT}
            ,${SQLColumnHelper.BOOKING_ITEM}.${SQLColumnHelper.TRANSACTION_TYPE_KEY}
            ,${SQLColumnHelper.BOOKING_ITEM}.${SQLColumnHelper.TRAVEL_RECORD_LOCATOR}
            ,${SQLColumnHelper.BOOKING_ITEM}.${SQLColumnHelper.LODG_ROOM_TYPE_ID}
            ,${SQLColumnHelper.BOOKING_ITEM}.${SQLColumnHelper.ITIN_NBR}
            ,${SQLColumnHelper.BOOKING_ITEM}.${SQLColumnHelper.PKG_IND}
            ,${SQLColumnHelper.ITEM_AMOUNT}.${SQLColumnHelper.BASE_PRICE_AMT_LOCAL}
            ,${SQLColumnHelper.ITEM_AMOUNT}.${SQLColumnHelper.OTHR_PRICE_ADJ_AMT_LOCAL}
            ,${SQLColumnHelper.ITEM_AMOUNT}.${SQLColumnHelper.PNLTY_PRICE_ADJ_AMT_LOCAL}
            ,${SQLColumnHelper.ITEM_AMOUNT}.${SQLColumnHelper.EXPE_PNLTY_PRICE_ADJ_AMT_LOCAL}
            ,${SQLColumnHelper.ITEM_AMOUNT}.${SQLColumnHelper.TOTL_PRICE_ADJ_AMT_LOCAL}
            ,${SQLColumnHelper.ITEM_AMOUNT}.${SQLColumnHelper.SVC_FEE_PRICE_AMT_LOCAL}
            ,${SQLColumnHelper.ITEM_AMOUNT}.${SQLColumnHelper.TOTL_FEE_PRICE_AMT_LOCAL}
            ,${SQLColumnHelper.ITEM_AMOUNT}.${SQLColumnHelper.TOTL_TAX_PRICE_AMT_LOCAL}
            ,${SQLColumnHelper.ITEM_AMOUNT}.${SQLColumnHelper.SVC_CHRG_PRICE_AMT_LOCAL}
            ,${SQLColumnHelper.ITEM_AMOUNT}.${SQLColumnHelper.CNCL_CHG_FEE_PRICE_AMT_LOCAL}
            ,${SQLColumnHelper.ITEM_AMOUNT}.${SQLColumnHelper.BASE_COST_AMT_USD}
            ,${SQLColumnHelper.ITEM_AMOUNT}.${SQLColumnHelper.OTHR_COST_ADJ_AMT_USD}
            ,${SQLColumnHelper.ITEM_AMOUNT}.${SQLColumnHelper.SUPPL_COST_ADJ_AMT_USD}
            ,${SQLColumnHelper.ITEM_AMOUNT}.${SQLColumnHelper.TOTL_COST_ADJ_AMT_USD}
            ,${SQLColumnHelper.ITEM_AMOUNT}.${SQLColumnHelper.TOTL_COST_AMT_USD}
            ,${SQLColumnHelper.ITEM_AMOUNT}.${SQLColumnHelper.TOTL_FEE_COST_AMT_USD}
            ,${SQLColumnHelper.ITEM_AMOUNT}.${SQLColumnHelper.TOTL_TAX_COST_AMT_USD}
            ,${SQLColumnHelper.ITEM_AMOUNT}.${SQLColumnHelper.GROSS_BKG_AMT_LOCAL}
            ,${SQLColumnHelper.ITEM_AMOUNT}.${SQLColumnHelper.PRICE_CURRENCY_CODE}
            ,${SQLColumnHelper.ITEM_AMOUNT}.${SQLColumnHelper.COST_CURRENCY_CODE}
            ,${SQLColumnHelper.ITEM_AMOUNT}.${SQLColumnHelper.COUPN_PRICE_AMT_LOCAL}
            ,${SQLColumnHelper.ITEM_AMOUNT}.${SQLColumnHelper.EXPE_GDWLL_PRICE_ADJ_AMT_LOCAL}
            ,${SQLColumnHelper.ITEM_AMOUNT}.${SQLColumnHelper.GDWLL_PRICE_ADJ_AMT_LOCAL}
            ,${SQLColumnHelper.ITEM_AMOUNT}.${SQLColumnHelper.GENRIC_COUPN_PRICE_AMT_LOCAL}
            ,${SQLColumnHelper.ITEM_AMOUNT}.${SQLColumnHelper.REFUND_PRICE_ADJ_AMT_LOCAL}
            ,${SQLColumnHelper.ITEM_AMOUNT}.${SQLColumnHelper.REBATE_PRICE_AMT_LOCAL}
            ,${SQLColumnHelper.ITEM_AMOUNT}.${SQLColumnHelper.TCM_PRICE_ADJ_AMT_LOCAL}
            ,${SQLColumnHelper.ITEM_AMOUNT}.${SQLColumnHelper.CNCL_PNLTY_WAIVR_PRICE_ADJ_AMT_LOCAL}
            ,${SQLColumnHelper.ITEM_AMOUNT}.${SQLColumnHelper.LOYLTY_POINT_PRICE_ADJ_AMT_LOCAL}
            ,${SQLColumnHelper.ITEM_AMOUNT}.${SQLColumnHelper.EMP_DISC_PRICE_ADJ_AMT_LOCAL}
            ,${SQLColumnHelper.ITEM_AMOUNT}.${SQLColumnHelper.SUPPL_RECON_PRICE_ADJ_AMT_LOCAL}
            ,${SQLColumnHelper.ITEM_AMOUNT}.${SQLColumnHelper.OTHER_FEE_PRICE_AMOUNT_LOCAL}
            ,${SQLColumnHelper.ITEM_AMOUNT}.${SQLColumnHelper.AGENT_ASSISTED_PURCHASE_FEE_AMOUNT_LOCAL}
            ,${SQLColumnHelper.ITEM_AMOUNT}.${SQLColumnHelper.TOTL_COST_AMT_LOCAL}
            ,${SQLColumnHelper.ITEM_AMOUNT}.${SQLColumnHelper.BASE_COST_AMT_LOCAL}
            ,${SQLColumnHelper.ITEM_AMOUNT}.${SQLColumnHelper.TOTL_COST_ADJ_AMT_LOCAL}
            ,${SQLColumnHelper.ITEM_AMOUNT}.${SQLColumnHelper.SUPPL_COST_ADJ_AMT_LOCAL}
            ,${SQLColumnHelper.ITEM_AMOUNT}.${SQLColumnHelper.ECA_COST_ADJ_AMT_LOCAL}
            ,${SQLColumnHelper.ITEM_AMOUNT}.${SQLColumnHelper.OTHR_COST_ADJ_AMT_LOCAL}
            ,${SQLColumnHelper.ITEM_AMOUNT}.${SQLColumnHelper.VAR_MARGN_COST_ADJ_LOCAL}
            ,${SQLColumnHelper.ITEM_AMOUNT}.${SQLColumnHelper.SUPPL_RECON_COST_ADJ_AMT_LOCAL}
            ,${SQLColumnHelper.ITEM_AMOUNT}.${SQLColumnHelper.TOTL_FEE_COST_AMT_LOCAL}
            ,${SQLColumnHelper.ITEM_AMOUNT}.${SQLColumnHelper.SVC_CHRG_COST_AMT_LOCAL}
            ,${SQLColumnHelper.ITEM_AMOUNT}.${SQLColumnHelper.OTHR_FEE_COST_AMT_LOCAL}
            ,${SQLColumnHelper.ITEM_AMOUNT}.${SQLColumnHelper.ECA_FEE_COST_AMT_LOCAL}
            ,${SQLColumnHelper.ITEM_AMOUNT}.${SQLColumnHelper.TOTL_TAX_COST_AMT_LOCAL}
            ,${SQLColumnHelper.ITEM_AMOUNT}.${SQLColumnHelper.VAR_MARGN_CREDT_LOCAL}
            ,${SQLColumnHelper.ITEM_AMOUNT}.${SQLColumnHelper.MARGN_AMT_USD}
            ,${SQLColumnHelper.ITEM_AMOUNT}.${SQLColumnHelper.PURE_MARGN_AMT_USD}
            ,${SQLColumnHelper.ITEM_AMOUNT}.${SQLColumnHelper.EXTRA_PERSN_COST_AMT_LOCAL}
            ,${SQLColumnHelper.ITEM_AMOUNT}.${SQLColumnHelper.RATE_PLN_RESTR_COST_AMT_LOCAL}
            ,${SQLColumnHelper.ITEM_AMOUNT}.${SQLColumnHelper.SNGL_SUPPLMNT_COST_AMT_LOCAL}
            ,${SQLColumnHelper.ITEM_AMOUNT}.${SQLColumnHelper.DYN_RATE_RULE_COST_AMT_LOCAL}
            ,${SQLColumnHelper.ITEM_AMOUNT}.${SQLColumnHelper.FRONT_END_COMMISSION_AMOUNT_USD}
            ,null AS ${SQLColumnHelper.TAX_DUE_AMOUNT}
            ,${propertyId}
            ,${SQLColumnHelper.BOOKING_DETAIL}.${SQLColumnHelper.LGL_ENTITY_NAME}
            ,${SQLColumnHelper.BOOKING_DETAIL}.${SQLColumnHelper.LGL_ENTITY_CODE}
            ,${SQLColumnHelper.BOOKING_DETAIL}.${SQLColumnHelper.POINT_OF_SALE_KEY}
            ,${SQLColumnHelper.BOOKING_DETAIL}.${SQLColumnHelper.POINT_OF_SALE_BRAND_NAME}
            ,${SQLColumnHelper.BOOKING_DETAIL}.${SQLColumnHelper.POINT_OF_SALE_NAME}
            ,${SQLColumnHelper.BOOKING_DETAIL}.${SQLColumnHelper.MANAGEMENT_UNIT_KEY}
            ,${SQLColumnHelper.BOOKING_DETAIL}.${SQLColumnHelper.MANAGEMENT_UNIT_CODE}
            ,${SQLColumnHelper.BOOKING_DETAIL}.${SQLColumnHelper.MANAGEMENT_UNIT_NAME}
            ,${SQLColumnHelper.BOOKING_DETAIL}.${SQLColumnHelper.MANAGEMENT_UNIT_LEVEL_6_NAME}
            ,${SQLColumnHelper.BOOKING_DETAIL}.${SQLColumnHelper.ORACLE_GL_PRODUCT_KEY}
            ,${SQLColumnHelper.BOOKING_DETAIL}.${SQLColumnHelper.TRAVEL_SERVICE_PROVIDER_NAME}
            ,${SQLColumnHelper.CAR_ITEM}.${SQLColumnHelper.RENTAL_DAY_COUNT}
            ,${SQLColumnHelper.CAR_ITEM}.${SQLColumnHelper.CAR_VENDOR_NAME}
            ,${SQLColumnHelper.CAR_ITEM}.${SQLColumnHelper.CAR_VENDOR_CODE}
            ,${SQLColumnHelper.CAR_ITEM}.${SQLColumnHelper.CAR_PICK_UP_LOCATION_NAME}
            ,${SQLColumnHelper.CAR_ITEM}.${SQLColumnHelper.CAR_PICK_UP_LOCATION_CITY_NAME}
            ,${SQLColumnHelper.CAR_ITEM}.${SQLColumnHelper.CAR_PICK_UP_LOCATION_STATE_PROVINCE_NAME}
            ,${SQLColumnHelper.CAR_ITEM}.${SQLColumnHelper.CAR_PICK_UP_LOCATION_COUNTRY_CODE}
            ,${SQLColumnHelper.CAR_ITEM}.${SQLColumnHelper.CAR_DROP_OFF_LOCATION_NAME}
            ,${SQLColumnHelper.CAR_ITEM}.${SQLColumnHelper.CAR_DROP_OFF_LOCATION_CITY_NAME}
            ,${SQLColumnHelper.CAR_ITEM}.${SQLColumnHelper.CAR_DROP_OFF_LOCATION_STATE_PROVINCE_NAME}
            ,${SQLColumnHelper.CAR_ITEM}.${SQLColumnHelper.CAR_DROP_OFF_LOCATION_COUNTRY_CODE}
            ,${SQLColumnHelper.CAR_ITEM}.${SQLColumnHelper.CAR_RATE_INDICATOR}
            ,cast(${SQLColumnHelper.LX_ITEM}.${SQLColumnHelper.ACTIVITY_ID} as string) as ${SQLColumnHelper.ACTIVITY_ID}
            ,${SQLColumnHelper.LX_ITEM}.${SQLColumnHelper.INTERNAL_CATEGORY_NAME}
            ,${SQLColumnHelper.LX_ITEM}.${SQLColumnHelper.OFFERING_NAME}
            ,${SQLColumnHelper.LX_ITEM}.${SQLColumnHelper.OFFERING_ITEM_NAME}
            ,${SQLColumnHelper.LX_ITEM}.${SQLColumnHelper.OFFERING_CATEGORY_NAME}
            ,${SQLColumnHelper.LX_ITEM}.${SQLColumnHelper.OFFERING_VENDOR_NAME}
            ,${SQLColumnHelper.LX_ITEM}.${SQLColumnHelper.OFFERING_VENDOR_BRANCH_NAME}
            ,${SQLColumnHelper.LX_ITEM}.${SQLColumnHelper.OFFERING_VENDOR_BRANCH_STATE_PROVINCE_NAME}
            ,${SQLColumnHelper.LX_ITEM}.${SQLColumnHelper.OFFERING_VENDOR_BRANCH_COUNTRY_NAME}
            ,${SQLColumnHelper.LX_ITEM}.${SQLColumnHelper.TICKET_COUNT}
            ,${SQLColumnHelper.EXCEPTIONS} as stg_bkg_exceptions
            ,${SQLColumnHelper.EVENT_INFO_PUBLISHED_TIMESTAMP} as published_timestamp
            ,${SQLColumnHelper.EVENT_INFO_HASH_EVENT_UUID} as hash_event_uuid
            ,${SQLColumnHelper.LOCAL_AMOUNTS}
        FROM ${stagedBookingTransactions} t
        WHERE $filterCriteria
    """)

        if (productLineName.toLowerCase() == "car") {
            bookingTransDF = bookingTransDF.withColumn(SQLColumnHelper.CAR_TAX_AREA_ID, lit(null))
                .withColumn(SQLColumnHelper.CAR_LOCATION_ID, lit(null))
                .withColumn(SQLColumnHelper.CAR_PICK_UP_LOCATION_STREET_ADDRESS1, lit(""))
                .withColumn(SQLColumnHelper.CAR_PICK_UP_LOCATION_STREET_ADDRESS2, lit(""))
                .withColumn(SQLColumnHelper.CAR_PICK_UP_LOCATION_POSTAL_CODE, lit(""))
                .withColumn(SQLColumnHelper.CAR_PICK_UP_LOCATION_LATITUDE, lit(""))
                .withColumn(SQLColumnHelper.CAR_PICK_UP_LOCATION_LONGITUDE, lit(""))
        }

        bookingTransDF
    }

    def selectVrboBookingEvents(sparkSession: SparkSession, vrboBookingTransactions: String, filterCriteria: String): DataFrame = {
        sparkSession.sql(
            raw"""
              SELECT
                  body.entity.tag_2.header.eventtype as event_type,
                  body.entity.tag_2.header.eventcategory as event_category,
                  body.entity.tag_2.header.createdate as create_date,
                  body.entity.tag_2.header.eventid as event_uuid,
                  body.entity.tag_2.header.transactiondate as transaction_date_time,
                  body.entity.tag_2.traveler.bookingdate as booking_date,
                  COALESCE(to_date(body.entity.tag_2.traveler.bookingdate), to_date(body.entity.tag_2.bookingattributes.originationdate)) as book_date,
                  to_date(body.entity.tag_2.header.transactiondate) as transaction_date,
                  to_date(body.entity.tag_2.bookingattributes.reservationdates.startdate) as begin_use_date,
                  to_date(body.entity.tag_2.bookingattributes.reservationdates.enddate) as end_use_date,
                  body.entity.tag_2.bookingattributes.reservationuuid as reservation_uuid,
                  body.entity.tag_2.bookingattributes.suppliermasterbrand as supplier_master_brand,
                  body.entity.tag_2.bookingattributes.travelerbookingsite as traveler_booking_site,
                  body.entity.tag_2.bookingattributes.reservationreferencenumber as reservation_reference_number,
                  body.entity.tag_2.bookingattributes.reservationstate as reservation_state,
                  body.entity.tag_2.bookingattributes.merchantofrecordtype as merchant_of_record_type,
                  body.entity.tag_2.bookingattributes.reservationstatus as reservation_status,
                  body.entity.tag_2.bookingattributes.property.listingnumber as listing_number,
                  body.entity.tag_2.bookingattributes.property.listingproducttype as listing_product_type,
                  body.entity.tag_2.bookingattributes.property.uniturl as property_id,
                  body.entity.tag_2.bookingattributes.property.physicalpropertyaddress.address as address,
                  body.entity.tag_2.bookingattributes.property.physicalpropertyaddress.city as staging_city,
                  body.entity.tag_2.bookingattributes.property.physicalpropertyaddress.countrycode as staging_country_code,
                  body.entity.tag_2.bookingattributes.property.physicalpropertyaddress.stateprovince as state_province,
                  body.entity.tag_2.bookingattributes.property.physicalpropertyaddress.postalcode as staging_postal_code,
                  body.entity.tag_2.bookingattributes.property.propertylocation.lon as staging_longitude,
                  body.entity.tag_2.bookingattributes.property.propertylocation.lat as staging_latitude,
                  body.entity.tag_2.bookingattributes.property.numberofbedrooms as number_of_bedrooms,
                  body.entity.tag_2.bookingattributes.numberofadults as adult_count,
                  body.entity.tag_2.bookingattributes.numberofchildren as child_count,
                  body.entity.tag_2.financialamounts[0].amount.currency as price_currency_code,
                  body.entity.tag_2.financialamounts[0].supplieramount.currency as cost_currency_code,
                  body.entity.tag_2.financialamounts as financial_amounts,
                  body.entity.tag_2.offerpricedetailattributes as offer_price_detail_attributes,
                  acquisition_date
              FROM ${vrboBookingTransactions}
              WHERE ${filterCriteria}
            """)
    }

    def getManualTransactionsVrbo(sqlc: SparkSession, filterCriteria: String, productLineName: String): DataFrame = {
        sqlc.sql(
            raw"""
                        SELECT
                            DISTINCT
                            ${SQLColumnHelper.TRANSACTION_LIABILITY_DATE}
                            ,'Lodging' as ${SQLColumnHelper.PRODUCT_LINE_NAME}
                            ,${SQLColumnHelper.BOOKING_ITEM}.${SQLColumnHelper.USE_DATE} as ${SQLColumnHelper.STAY_DATE}
                            ,${SQLColumnHelper.BOOKING_ITEM}.${SQLColumnHelper.BOOK_DATE}
                            ,${SQLColumnHelper.BOOKING_ITEM}.${SQLColumnHelper.BEGIN_USE_DATE}
                            ,${SQLColumnHelper.BOOKING_ITEM}.${SQLColumnHelper.END_USE_DATE}
                            ,${SQLColumnHelper.BOOKING_ITEM}.${SQLColumnHelper.BUSINESS_MODEL_NAME}
                            ,${SQLColumnHelper.BOOKING_ITEM}.${SQLColumnHelper.BUSINESS_MODEL_SUBTYPE_NAME}
                            ,${SQLColumnHelper.BOOKING_ITEM}.${SQLColumnHelper.BOOKING_ITEM_ID}
                            ,${SQLColumnHelper.BOOKING_ITEM}.${SQLColumnHelper.BOOKING_ID}
                            ,${SQLColumnHelper.BOOKING_ITEM}.${SQLColumnHelper.TRANSACTION_TYPE_NAME}
                            ,${SQLColumnHelper.BOOKING_ITEM}.${SQLColumnHelper.BOOKING_EVENT_DATE}
                            ,${SQLColumnHelper.BOOKING_ITEM}.${SQLColumnHelper.BOOKING_EVENT_DATETIME}
                            ,${SQLColumnHelper.BOOKING_ITEM}.${SQLColumnHelper.RESERVATION_UUID}
                            ,${SQLColumnHelper.BOOKING_ITEM}.${SQLColumnHelper.RESERVATION_STATE}
                            ,${SQLColumnHelper.BOOKING_ITEM}.${SQLColumnHelper.RESERVATION_STATUS}
                            ,${SQLColumnHelper.BOOKING_ITEM}.${SQLColumnHelper.SUPPLIER_MASTER_BRAND}
                            ,${SQLColumnHelper.BOOKING_ITEM}.${SQLColumnHelper.TRAVELER_BOOKING_SITE}
                            ,${SQLColumnHelper.BOOKING_ITEM}.${SQLColumnHelper.MERCHANT_OF_RECORD_TYPE}
                            ,${SQLColumnHelper.PROPERTY_ITEM}.${SQLColumnHelper.PROPERTY_ID}
                            ,${SQLColumnHelper.ITEM_AMOUNT}.${SQLColumnHelper.PRICE_CURRENCY_CODE}
                            ,${SQLColumnHelper.ITEM_AMOUNT}.${SQLColumnHelper.COST_CURRENCY_CODE}
                            ,${SQLColumnHelper.EVENT_INFO}.${SQLColumnHelper.EVENT_UUID} as ${SQLColumnHelper.STAGE_EVENT_UUID}
                            ,${SQLColumnHelper.LOCAL_AMOUNTS}
                            ,${SQLColumnHelper.TRANSACTION_LIABILITY_DATE_TYPE}
                            ,'${SQLColumnHelper.GTP_FILE_UPLOAD}' AS ${SQLColumnHelper.EVENT_SOURCE_SYSTEM_NAME}
                            ,${SQLColumnHelper.BOOKING_HISTORY}
                        FROM ${manualTransactions}
                        WHERE $filterCriteria
            """)
    }

    def selectStagedBookingTransactionsVrbo(sqlc: SparkSession, filterCriteria: String, productLineName: String): DataFrame = {
        val bookingTransDF = sqlc.sql(
            raw"""
                        SELECT
                            DISTINCT
                            ${SQLColumnHelper.TRANSACTION_LIABILITY_DATE}
                            ,'Lodging' as ${SQLColumnHelper.PRODUCT_LINE_NAME}
                            ,${SQLColumnHelper.BOOKING_ITEM}.${SQLColumnHelper.USE_DATE} as ${SQLColumnHelper.STAY_DATE}
                            ,${SQLColumnHelper.BOOKING_ITEM}.${SQLColumnHelper.BOOK_DATE}
                            ,${SQLColumnHelper.BOOKING_ITEM}.${SQLColumnHelper.BEGIN_USE_DATE}
                            ,${SQLColumnHelper.BOOKING_ITEM}.${SQLColumnHelper.END_USE_DATE}
                            ,${SQLColumnHelper.BOOKING_ITEM}.${SQLColumnHelper.BUSINESS_MODEL_NAME}
                            ,${SQLColumnHelper.BOOKING_ITEM}.${SQLColumnHelper.BUSINESS_MODEL_SUBTYPE_NAME}
                            ,${SQLColumnHelper.BOOKING_ITEM}.${SQLColumnHelper.BOOKING_ITEM_ID}
                            ,${SQLColumnHelper.BOOKING_ITEM}.${SQLColumnHelper.BOOKING_ID}
                            ,${SQLColumnHelper.BOOKING_ITEM}.${SQLColumnHelper.TRANSACTION_TYPE_NAME}
                            ,${SQLColumnHelper.BOOKING_ITEM}.${SQLColumnHelper.BOOKING_EVENT_DATE}
                            ,${SQLColumnHelper.BOOKING_ITEM}.${SQLColumnHelper.BOOKING_EVENT_DATETIME}
                            ,${SQLColumnHelper.BOOKING_ITEM}.${SQLColumnHelper.RESERVATION_UUID}
                            ,${SQLColumnHelper.BOOKING_ITEM}.${SQLColumnHelper.RESERVATION_STATE}
                            ,${SQLColumnHelper.BOOKING_ITEM}.${SQLColumnHelper.RESERVATION_STATUS}
                            ,${SQLColumnHelper.BOOKING_ITEM}.${SQLColumnHelper.SUPPLIER_MASTER_BRAND}
                            ,${SQLColumnHelper.BOOKING_ITEM}.${SQLColumnHelper.TRAVELER_BOOKING_SITE}
                            ,${SQLColumnHelper.BOOKING_ITEM}.${SQLColumnHelper.MERCHANT_OF_RECORD_TYPE}
                            ,${SQLColumnHelper.PROPERTY_ITEM}.${SQLColumnHelper.PROPERTY_ID}
                            ,${SQLColumnHelper.ITEM_AMOUNT}.${SQLColumnHelper.PRICE_CURRENCY_CODE}
                            ,${SQLColumnHelper.ITEM_AMOUNT}.${SQLColumnHelper.COST_CURRENCY_CODE}
                            ,${SQLColumnHelper.EVENT_INFO}.${SQLColumnHelper.EVENT_UUID} as ${SQLColumnHelper.STAGE_EVENT_UUID}
                            ,${SQLColumnHelper.LOCAL_AMOUNTS}
                            ,${SQLColumnHelper.TRANSACTION_LIABILITY_DATE_TYPE}
                            ,'${SQLColumnHelper.VRBO_BOOKING_EVENT_STREAM}' AS ${SQLColumnHelper.EVENT_SOURCE_SYSTEM_NAME}
                            ,${SQLColumnHelper.BOOKING_HISTORY}
                        FROM ${stagedBookingTransactions}
                        WHERE $filterCriteria
                       """)
        return bookingTransDF

    }

    def selectStagedBookingTransactionsWithLocalAmounts(sqlc: SparkSession, filterCriteria: String, productLineName: String): DataFrame = {

        var propertyId: String = null
        if (productLineName.toLowerCase() == "lodging") {
            propertyId = SQLColumnHelper.PROPERTY_ITEM + "." + SQLColumnHelper.PROPERTY_ID
        }

        var bookingTransDF = sqlc.sql(
            raw"""
                        SELECT * FROM ${stagedBookingTransactions} t
                        WHERE $filterCriteria
                       """)

        bookingTransDF = bookingTransDF.withColumn("local_amount",
            DataUtil.buildMapFromAmountArray(col("local_amounts.monetary_computational_reference"),
                col("local_amounts.money.amount")))

        bookingTransDF.createOrReplaceTempView("bookingTransDfView")

        var bookingTransDFMod = sqlc.sql(
            raw"""
                        SELECT
                            ${SQLColumnHelper.TRANSACTION_LIABILITY_DATE}
                            ,${SQLColumnHelper.PRODUCT_LINE_NAME}
                            ,${SQLColumnHelper.BOOKING_ITEM}.${SQLColumnHelper.USE_DATE} as ${SQLColumnHelper.STAY_DATE}
                            ,${SQLColumnHelper.BOOKING_ITEM}.${SQLColumnHelper.BOOK_DATE}
                            ,${SQLColumnHelper.BOOKING_ITEM}.${SQLColumnHelper.BEGIN_USE_DATE}
                            ,${SQLColumnHelper.BOOKING_ITEM}.${SQLColumnHelper.END_USE_DATE}
                            ,${SQLColumnHelper.BOOKING_ITEM}.${SQLColumnHelper.BUSINESS_MODEL_NAME}
                            ,${SQLColumnHelper.BOOKING_ITEM}.${SQLColumnHelper.BUSINESS_MODEL_SUBTYPE_NAME}
                            ,${SQLColumnHelper.BOOKING_ITEM}.${SQLColumnHelper.ROOM_NIGHT_COUNT}
                            ,${SQLColumnHelper.BOOKING_ITEM}.${SQLColumnHelper.BOOKING_ITEM_ID}
                            ,${SQLColumnHelper.BOOKING_ITEM}.${SQLColumnHelper.BOOKING_ID}
                            ,${SQLColumnHelper.BOOKING_ITEM}.${SQLColumnHelper.TRANSACTION_TYPE_NAME}
                            ,${SQLColumnHelper.BOOKING_ITEM}.${SQLColumnHelper.BOOKING_EVENT_DATE}
                            ,${SQLColumnHelper.BOOKING_ITEM}.${SQLColumnHelper.BOOKING_EVENT_DATETIME}
                            ,${SQLColumnHelper.BOOKING_ITEM}.${SQLColumnHelper.SOURCE_SYSTEM_ID}
                            ,${SQLColumnHelper.BOOKING_ITEM}.${SQLColumnHelper.TRAVEL_PRODUCT_ID}
                            ,${SQLColumnHelper.BOOKING_ITEM}.${SQLColumnHelper.TOTAL_TRAVELER_COUNT}
                            ,${SQLColumnHelper.BOOKING_ITEM}.${SQLColumnHelper.TRANSACTION_TYPE_KEY}
                            ,${SQLColumnHelper.BOOKING_ITEM}.${SQLColumnHelper.TRAVEL_RECORD_LOCATOR}
                            ,${SQLColumnHelper.BOOKING_ITEM}.${SQLColumnHelper.LODG_ROOM_TYPE_ID}
                            ,${SQLColumnHelper.BOOKING_ITEM}.${SQLColumnHelper.ITIN_NBR}
                            ,${SQLColumnHelper.BOOKING_ITEM}.${SQLColumnHelper.PKG_IND}
                            ,${SQLColumnHelper.LOCAL_AMOUNT}.${SQLColumnHelper.BASE_PRICE_AMOUNT_LOCAL}
                            ,${SQLColumnHelper.LOCAL_AMOUNT}.${SQLColumnHelper.OTHER_PRICE_ADJUSTMENT_AMOUNT_LOCAL}
                            ,${SQLColumnHelper.LOCAL_AMOUNT}.${SQLColumnHelper.PENALTY_PRICE_ADJUSTMENT_AMOUNT_LOCAL}
                            ,${SQLColumnHelper.LOCAL_AMOUNT}.${SQLColumnHelper.EXPEDIA_PENALTY_PRICE_ADJUSTMENT_AMOUNT_LOCAL}
                            ,${SQLColumnHelper.LOCAL_AMOUNT}.${SQLColumnHelper.TOTAL_PRICE_ADJUSTMENT_AMOUNT_LOCAL}
                            ,${SQLColumnHelper.LOCAL_AMOUNT}.${SQLColumnHelper.SERVICE_FEE_PRICE_AMOUNT_LOCAL}
                            ,${SQLColumnHelper.LOCAL_AMOUNT}.${SQLColumnHelper.TOTAL_FEE_PRICE_AMOUNT_LOCAL}
                            ,${SQLColumnHelper.LOCAL_AMOUNT}.${SQLColumnHelper.TOTAL_TAX_PRICE_AMOUNT_LOCAL}
                            ,${SQLColumnHelper.LOCAL_AMOUNT}.${SQLColumnHelper.SERVICE_CHARGE_PRICE_AMOUNT_LOCAL}
                            ,${SQLColumnHelper.LOCAL_AMOUNT}.${SQLColumnHelper.CANCEL_CHANGE_FEE_PRICE_AMOUNT_LOCAL}
                            ,${SQLColumnHelper.ITEM_AMOUNT}.${SQLColumnHelper.BASE_COST_AMT_USD}
                            ,${SQLColumnHelper.ITEM_AMOUNT}.${SQLColumnHelper.OTHR_COST_ADJ_AMT_USD}
                            ,${SQLColumnHelper.ITEM_AMOUNT}.${SQLColumnHelper.SUPPL_COST_ADJ_AMT_USD}
                            ,${SQLColumnHelper.ITEM_AMOUNT}.${SQLColumnHelper.TOTL_COST_ADJ_AMT_USD}
                            ,${SQLColumnHelper.ITEM_AMOUNT}.${SQLColumnHelper.TOTL_COST_AMT_USD}
                            ,${SQLColumnHelper.ITEM_AMOUNT}.${SQLColumnHelper.TOTL_FEE_COST_AMT_USD}
                            ,${SQLColumnHelper.ITEM_AMOUNT}.${SQLColumnHelper.TOTL_TAX_COST_AMT_USD}
                            ,${SQLColumnHelper.LOCAL_AMOUNT}.${SQLColumnHelper.GROSS_BOOKING_AMOUNT_LOCAL}
                            ,${SQLColumnHelper.ITEM_AMOUNT}.${SQLColumnHelper.PRICE_CURRENCY_CODE}
                            ,${SQLColumnHelper.ITEM_AMOUNT}.${SQLColumnHelper.COST_CURRENCY_CODE}
                            ,${SQLColumnHelper.LOCAL_AMOUNT}.${SQLColumnHelper.COUPON_PRICE_AMOUNT_LOCAL}
                            ,${SQLColumnHelper.LOCAL_AMOUNT}.${SQLColumnHelper.EXPEDIA_GOODWILL_PRICE_ADJUSTMENT_AMOUNT_LOCAL}
                            ,${SQLColumnHelper.LOCAL_AMOUNT}.${SQLColumnHelper.GOODWILL_PRICE_ADJUSTMENT_AMOUNT_LOCAL}
                            ,${SQLColumnHelper.LOCAL_AMOUNT}.${SQLColumnHelper.GENERIC_COUPON_PRICE_AMOUNT_LOCAL}
                            ,${SQLColumnHelper.LOCAL_AMOUNT}.${SQLColumnHelper.REFUND_PRICE_ADJUSTMENT_AMOUNT_LOCAL}
                            ,${SQLColumnHelper.LOCAL_AMOUNT}.${SQLColumnHelper.REBATE_PRICE_AMOUNT_LOCAL}
                            ,${SQLColumnHelper.LOCAL_AMOUNT}.${SQLColumnHelper.TCM_PRICE_ADJUSTMENT_AMOUNT_LOCAL}
                            ,${SQLColumnHelper.LOCAL_AMOUNT}.${SQLColumnHelper.CANCEL_PENALTY_WAIVER_PRICE_ADJUSTMENT_AMOUNT_LOCAL}
                            ,${SQLColumnHelper.LOCAL_AMOUNT}.${SQLColumnHelper.LOYALTY_POINT_PRICE_ADJUSTMENT_AMOUNT_LOCAL}
                            ,${SQLColumnHelper.LOCAL_AMOUNT}.${SQLColumnHelper.EMPLOYEE_DISCOUNT_PRICE_ADJUSTMENT_AMOUNT_LOCAL}
                            ,${SQLColumnHelper.LOCAL_AMOUNT}.${SQLColumnHelper.SUPPLIER_RECONCILIATION_PRICE_ADJUSTMENT_AMOUNT_LOCAL}
                            ,${SQLColumnHelper.LOCAL_AMOUNT}.${SQLColumnHelper.OTHER_FEE_PRICE_AMOUNT_LOCAL}
                            ,${SQLColumnHelper.LOCAL_AMOUNT}.${SQLColumnHelper.AGENT_ASSISTED_PURCHASE_FEE_AMOUNT_LOCAL}
                            ,${SQLColumnHelper.LOCAL_AMOUNT}.${SQLColumnHelper.TOTAL_COST_AMOUNT_LOCAL}
                            ,${SQLColumnHelper.LOCAL_AMOUNT}.${SQLColumnHelper.BASE_COST_AMOUNT_LOCAL}
                            ,${SQLColumnHelper.LOCAL_AMOUNT}.${SQLColumnHelper.TOTAL_COST_ADJUSTMENT_AMOUNT_LOCAL}
                            ,${SQLColumnHelper.LOCAL_AMOUNT}.${SQLColumnHelper.SUPPLIER_COST_ADJUSTMENT_AMOUNT_LOCAL}
                            ,${SQLColumnHelper.LOCAL_AMOUNT}.${SQLColumnHelper.ECA_COST_ADJUSTMENT_AMOUNT_LOCAL}
                            ,${SQLColumnHelper.LOCAL_AMOUNT}.${SQLColumnHelper.OTHER_COST_ADJUSTMENT_AMOUNT_LOCAL}
                            ,${SQLColumnHelper.LOCAL_AMOUNT}.${SQLColumnHelper.VARIABLE_MARGIN_COST_ADJUSTMENT_AMOUNT_LOCAL}
                            ,${SQLColumnHelper.LOCAL_AMOUNT}.${SQLColumnHelper.SUPPLIER_RECONCILIATION_COST_ADJUSTMENT_LOCAL}
                            ,${SQLColumnHelper.LOCAL_AMOUNT}.${SQLColumnHelper.TOTAL_FEE_COST_AMOUNT_LOCAL}
                            ,${SQLColumnHelper.LOCAL_AMOUNT}.${SQLColumnHelper.SERVICE_CHARGE_COST_AMOUNT_LOCAL}
                            ,${SQLColumnHelper.LOCAL_AMOUNT}.${SQLColumnHelper.OTHER_FEE_COST_AMOUNT_LOCAL}
                            ,${SQLColumnHelper.LOCAL_AMOUNT}.${SQLColumnHelper.ECA_FEE_COST_AMOUNT_LOCAL}
                            ,${SQLColumnHelper.LOCAL_AMOUNT}.${SQLColumnHelper.TOTAL_TAX_COST_AMOUNT_LOCAL}
                            ,${SQLColumnHelper.LOCAL_AMOUNT}.${SQLColumnHelper.VARIABLE_MARGIN_CREDIT_LOCAL}
                            ,${SQLColumnHelper.ITEM_AMOUNT}.${SQLColumnHelper.MARGN_AMT_USD}
                            ,${SQLColumnHelper.ITEM_AMOUNT}.${SQLColumnHelper.PURE_MARGN_AMT_USD}
                            ,${SQLColumnHelper.LOCAL_AMOUNT}.${SQLColumnHelper.EXTRA_PERSON_COST_AMOUNT_LOCAL}
                            ,${SQLColumnHelper.LOCAL_AMOUNT}.${SQLColumnHelper.RATE_PLAN_RESTRICTION_COST_AMOUNT_LOCAL}
                            ,${SQLColumnHelper.LOCAL_AMOUNT}.${SQLColumnHelper.SINGLE_SUPPLEMENT_COST_AMOUNT_LOCAL}
                            ,${SQLColumnHelper.LOCAL_AMOUNT}.${SQLColumnHelper.DYNAMIC_RATE_RULE_COST_AMOUNT_LOCAL}
                            ,${SQLColumnHelper.ITEM_AMOUNT}.${SQLColumnHelper.FRONT_END_COMMISSION_AMOUNT_USD}
                            ,${SQLColumnHelper.LOCAL_AMOUNT}.${SQLColumnHelper.TAX_DUE_AMOUNT}
                            ,${propertyId}
                            ,${SQLColumnHelper.BOOKING_DETAIL}.${SQLColumnHelper.LGL_ENTITY_NAME}
                            ,${SQLColumnHelper.BOOKING_DETAIL}.${SQLColumnHelper.LGL_ENTITY_CODE}
                            ,${SQLColumnHelper.BOOKING_DETAIL}.${SQLColumnHelper.POINT_OF_SALE_KEY}
                            ,${SQLColumnHelper.BOOKING_DETAIL}.${SQLColumnHelper.POINT_OF_SALE_BRAND_NAME}
                            ,${SQLColumnHelper.BOOKING_DETAIL}.${SQLColumnHelper.POINT_OF_SALE_NAME}
                            ,${SQLColumnHelper.BOOKING_DETAIL}.${SQLColumnHelper.MANAGEMENT_UNIT_KEY}
                            ,${SQLColumnHelper.BOOKING_DETAIL}.${SQLColumnHelper.MANAGEMENT_UNIT_CODE}
                            ,${SQLColumnHelper.BOOKING_DETAIL}.${SQLColumnHelper.MANAGEMENT_UNIT_NAME}
                            ,${SQLColumnHelper.BOOKING_DETAIL}.${SQLColumnHelper.MANAGEMENT_UNIT_LEVEL_6_NAME}
                            ,${SQLColumnHelper.BOOKING_DETAIL}.${SQLColumnHelper.ORACLE_GL_PRODUCT_KEY}
                            ,${SQLColumnHelper.BOOKING_DETAIL}.${SQLColumnHelper.TRAVEL_SERVICE_PROVIDER_NAME}
                            ,${SQLColumnHelper.CAR_ITEM}.${SQLColumnHelper.RENTAL_DAY_COUNT}
                            ,${SQLColumnHelper.CAR_ITEM}.${SQLColumnHelper.CAR_VENDOR_NAME}
                            ,${SQLColumnHelper.CAR_ITEM}.${SQLColumnHelper.CAR_VENDOR_CODE}
                            ,${SQLColumnHelper.CAR_ITEM}.${SQLColumnHelper.CAR_PICK_UP_LOCATION_NAME}
                            ,${SQLColumnHelper.CAR_ITEM}.${SQLColumnHelper.CAR_PICK_UP_LOCATION_CITY_NAME}
                            ,${SQLColumnHelper.CAR_ITEM}.${SQLColumnHelper.CAR_PICK_UP_LOCATION_STATE_PROVINCE_NAME}
                            ,${SQLColumnHelper.CAR_ITEM}.${SQLColumnHelper.CAR_PICK_UP_LOCATION_COUNTRY_CODE}
                            ,${SQLColumnHelper.CAR_ITEM}.${SQLColumnHelper.CAR_DROP_OFF_LOCATION_NAME}
                            ,${SQLColumnHelper.CAR_ITEM}.${SQLColumnHelper.CAR_DROP_OFF_LOCATION_CITY_NAME}
                            ,${SQLColumnHelper.CAR_ITEM}.${SQLColumnHelper.CAR_DROP_OFF_LOCATION_STATE_PROVINCE_NAME}
                            ,${SQLColumnHelper.CAR_ITEM}.${SQLColumnHelper.CAR_DROP_OFF_LOCATION_COUNTRY_CODE}
                            ,${SQLColumnHelper.CAR_ITEM}.${SQLColumnHelper.CAR_RATE_INDICATOR}
                            ,cast(${SQLColumnHelper.LX_ITEM}.${SQLColumnHelper.ACTIVITY_ID} as string) as ${SQLColumnHelper.ACTIVITY_ID}
                            ,${SQLColumnHelper.LX_ITEM}.${SQLColumnHelper.INTERNAL_CATEGORY_NAME}
                            ,${SQLColumnHelper.LX_ITEM}.${SQLColumnHelper.OFFERING_NAME}
                            ,${SQLColumnHelper.LX_ITEM}.${SQLColumnHelper.OFFERING_ITEM_NAME}
                            ,${SQLColumnHelper.LX_ITEM}.${SQLColumnHelper.OFFERING_CATEGORY_NAME}
                            ,${SQLColumnHelper.LX_ITEM}.${SQLColumnHelper.OFFERING_VENDOR_NAME}
                            ,${SQLColumnHelper.LX_ITEM}.${SQLColumnHelper.OFFERING_VENDOR_BRANCH_NAME}
                            ,${SQLColumnHelper.LX_ITEM}.${SQLColumnHelper.OFFERING_VENDOR_BRANCH_STATE_PROVINCE_NAME}
                            ,${SQLColumnHelper.LX_ITEM}.${SQLColumnHelper.OFFERING_VENDOR_BRANCH_COUNTRY_NAME}
                            ,${SQLColumnHelper.LX_ITEM}.${SQLColumnHelper.TICKET_COUNT}
                            ,${SQLColumnHelper.EXCEPTIONS} as stg_bkg_exceptions
                            ,${SQLColumnHelper.EVENT_INFO_PUBLISHED_TIMESTAMP} as published_timestamp
                            ,${SQLColumnHelper.EVENT_INFO_HASH_EVENT_UUID} as hash_event_uuid
                            ,${SQLColumnHelper.LOCAL_AMOUNTS}
                        FROM bookingTransDfView t
	                """)

        if (productLineName.toLowerCase() == "car") {
            bookingTransDFMod = bookingTransDFMod.withColumn(SQLColumnHelper.CAR_TAX_AREA_ID, lit(null: String))
                .withColumn(SQLColumnHelper.CAR_LOCATION_ID, lit(null: String))
                .withColumn(SQLColumnHelper.CAR_PICK_UP_LOCATION_STREET_ADDRESS1, lit(""))
                .withColumn(SQLColumnHelper.CAR_PICK_UP_LOCATION_STREET_ADDRESS2, lit(""))
                .withColumn(SQLColumnHelper.CAR_PICK_UP_LOCATION_POSTAL_CODE, lit(""))
                .withColumn(SQLColumnHelper.CAR_PICK_UP_LOCATION_LATITUDE, lit(""))
                .withColumn(SQLColumnHelper.CAR_PICK_UP_LOCATION_LONGITUDE, lit(""))
        }

        bookingTransDFMod
    }

    def selectPostStagedBookingTransactions(sqlc: SparkSession, filterCriteria: String, productLineName: String): DataFrame = {

        var propertyId: String = null
        if (productLineName.toLowerCase() == "lodging") {
            propertyId = SQLColumnHelper.PROPERTY_ITEM + "." + SQLColumnHelper.PROPERTY_ID
        }

        var postStayBookingTransDf = sqlc.sql(
            raw"""
    SELECT
            ${SQLColumnHelper.TRANSACTION_LIABILITY_DATE}
            ,${SQLColumnHelper.PRODUCT_LINE_NAME}
            ,${SQLColumnHelper.BOOKING_ITEM}.${SQLColumnHelper.USE_DATE} as ${SQLColumnHelper.STAY_DATE}
            ,${SQLColumnHelper.BOOKING_ITEM}.${SQLColumnHelper.BOOK_DATE}
            ,${SQLColumnHelper.BOOKING_ITEM}.${SQLColumnHelper.BEGIN_USE_DATE}
            ,${SQLColumnHelper.BOOKING_ITEM}.${SQLColumnHelper.END_USE_DATE}
            ,${SQLColumnHelper.BOOKING_ITEM}.${SQLColumnHelper.BUSINESS_MODEL_NAME}
            ,${SQLColumnHelper.BOOKING_ITEM}.${SQLColumnHelper.BUSINESS_MODEL_SUBTYPE_NAME}
            ,${SQLColumnHelper.BOOKING_ITEM}.${SQLColumnHelper.ROOM_NIGHT_COUNT}
            ,${SQLColumnHelper.BOOKING_ITEM}.${SQLColumnHelper.BOOKING_ITEM_ID}
            ,${SQLColumnHelper.BOOKING_ITEM}.${SQLColumnHelper.BOOKING_ID}
            ,${SQLColumnHelper.BOOKING_ITEM}.${SQLColumnHelper.TRANSACTION_TYPE_NAME}
            ,${SQLColumnHelper.BOOKING_ITEM}.${SQLColumnHelper.BOOKING_EVENT_DATE}
            ,${SQLColumnHelper.BOOKING_ITEM}.${SQLColumnHelper.BOOKING_EVENT_DATETIME}
            ,${SQLColumnHelper.BOOKING_ITEM}.${SQLColumnHelper.SOURCE_SYSTEM_ID}
            ,${SQLColumnHelper.BOOKING_ITEM}.${SQLColumnHelper.TRAVEL_PRODUCT_ID}
            ,${SQLColumnHelper.BOOKING_ITEM}.${SQLColumnHelper.TOTAL_TRAVELER_COUNT}
            ,${SQLColumnHelper.BOOKING_ITEM}.${SQLColumnHelper.TRANSACTION_TYPE_KEY}
            ,${SQLColumnHelper.BOOKING_ITEM}.${SQLColumnHelper.TRAVEL_RECORD_LOCATOR}
            ,${SQLColumnHelper.BOOKING_ITEM}.${SQLColumnHelper.LODG_ROOM_TYPE_ID}
            ,${SQLColumnHelper.BOOKING_ITEM}.${SQLColumnHelper.ITIN_NBR}
            ,${SQLColumnHelper.BOOKING_ITEM}.${SQLColumnHelper.PKG_IND}
            ,${SQLColumnHelper.ITEM_AMOUNT}.${SQLColumnHelper.BASE_PRICE_AMT_LOCAL}
            ,${SQLColumnHelper.ITEM_AMOUNT}.${SQLColumnHelper.OTHR_PRICE_ADJ_AMT_LOCAL}
            ,${SQLColumnHelper.ITEM_AMOUNT}.${SQLColumnHelper.PNLTY_PRICE_ADJ_AMT_LOCAL}
            ,${SQLColumnHelper.ITEM_AMOUNT}.${SQLColumnHelper.EXPE_PNLTY_PRICE_ADJ_AMT_LOCAL}
            ,${SQLColumnHelper.ITEM_AMOUNT}.${SQLColumnHelper.TOTL_PRICE_ADJ_AMT_LOCAL}
            ,${SQLColumnHelper.ITEM_AMOUNT}.${SQLColumnHelper.SVC_FEE_PRICE_AMT_LOCAL}
            ,${SQLColumnHelper.ITEM_AMOUNT}.${SQLColumnHelper.TOTL_FEE_PRICE_AMT_LOCAL}
            ,${SQLColumnHelper.ITEM_AMOUNT}.${SQLColumnHelper.TOTL_TAX_PRICE_AMT_LOCAL}
            ,${SQLColumnHelper.ITEM_AMOUNT}.${SQLColumnHelper.SVC_CHRG_PRICE_AMT_LOCAL}
            ,${SQLColumnHelper.ITEM_AMOUNT}.${SQLColumnHelper.CNCL_CHG_FEE_PRICE_AMT_LOCAL}
            ,${SQLColumnHelper.ITEM_AMOUNT}.${SQLColumnHelper.BASE_COST_AMT_USD}
            ,${SQLColumnHelper.ITEM_AMOUNT}.${SQLColumnHelper.OTHR_COST_ADJ_AMT_USD}
            ,${SQLColumnHelper.ITEM_AMOUNT}.${SQLColumnHelper.SUPPL_COST_ADJ_AMT_USD}
            ,${SQLColumnHelper.ITEM_AMOUNT}.${SQLColumnHelper.TOTL_COST_ADJ_AMT_USD}
            ,${SQLColumnHelper.ITEM_AMOUNT}.${SQLColumnHelper.TOTL_COST_AMT_USD}
            ,${SQLColumnHelper.ITEM_AMOUNT}.${SQLColumnHelper.TOTL_FEE_COST_AMT_USD}
            ,${SQLColumnHelper.ITEM_AMOUNT}.${SQLColumnHelper.TOTL_TAX_COST_AMT_USD}
            ,${SQLColumnHelper.ITEM_AMOUNT}.${SQLColumnHelper.GROSS_BKG_AMT_LOCAL}
            ,${SQLColumnHelper.ITEM_AMOUNT}.${SQLColumnHelper.PRICE_CURRENCY_CODE}
            ,${SQLColumnHelper.ITEM_AMOUNT}.${SQLColumnHelper.COST_CURRENCY_CODE}
            ,${SQLColumnHelper.ITEM_AMOUNT}.${SQLColumnHelper.COUPN_PRICE_AMT_LOCAL}
            ,${SQLColumnHelper.ITEM_AMOUNT}.${SQLColumnHelper.EXPE_GDWLL_PRICE_ADJ_AMT_LOCAL}
            ,${SQLColumnHelper.ITEM_AMOUNT}.${SQLColumnHelper.GDWLL_PRICE_ADJ_AMT_LOCAL}
            ,${SQLColumnHelper.ITEM_AMOUNT}.${SQLColumnHelper.GENRIC_COUPN_PRICE_AMT_LOCAL}
            ,${SQLColumnHelper.ITEM_AMOUNT}.${SQLColumnHelper.REFUND_PRICE_ADJ_AMT_LOCAL}
            ,${SQLColumnHelper.ITEM_AMOUNT}.${SQLColumnHelper.REBATE_PRICE_AMT_LOCAL}
            ,${SQLColumnHelper.ITEM_AMOUNT}.${SQLColumnHelper.TCM_PRICE_ADJ_AMT_LOCAL}
            ,${SQLColumnHelper.ITEM_AMOUNT}.${SQLColumnHelper.CNCL_PNLTY_WAIVR_PRICE_ADJ_AMT_LOCAL}
            ,${SQLColumnHelper.ITEM_AMOUNT}.${SQLColumnHelper.LOYLTY_POINT_PRICE_ADJ_AMT_LOCAL}
            ,${SQLColumnHelper.ITEM_AMOUNT}.${SQLColumnHelper.EMP_DISC_PRICE_ADJ_AMT_LOCAL}
            ,${SQLColumnHelper.ITEM_AMOUNT}.${SQLColumnHelper.SUPPL_RECON_PRICE_ADJ_AMT_LOCAL}
            ,${SQLColumnHelper.ITEM_AMOUNT}.${SQLColumnHelper.OTHER_FEE_PRICE_AMOUNT_LOCAL}
            ,${SQLColumnHelper.ITEM_AMOUNT}.${SQLColumnHelper.AGENT_ASSISTED_PURCHASE_FEE_AMOUNT_LOCAL}
            ,${SQLColumnHelper.ITEM_AMOUNT}.${SQLColumnHelper.TOTL_COST_AMT_LOCAL}
            ,${SQLColumnHelper.ITEM_AMOUNT}.${SQLColumnHelper.BASE_COST_AMT_LOCAL}
            ,${SQLColumnHelper.ITEM_AMOUNT}.${SQLColumnHelper.TOTL_COST_ADJ_AMT_LOCAL}
            ,${SQLColumnHelper.ITEM_AMOUNT}.${SQLColumnHelper.SUPPL_COST_ADJ_AMT_LOCAL}
            ,${SQLColumnHelper.ITEM_AMOUNT}.${SQLColumnHelper.ECA_COST_ADJ_AMT_LOCAL}
            ,${SQLColumnHelper.ITEM_AMOUNT}.${SQLColumnHelper.OTHR_COST_ADJ_AMT_LOCAL}
            ,${SQLColumnHelper.ITEM_AMOUNT}.${SQLColumnHelper.VAR_MARGN_COST_ADJ_LOCAL}
            ,${SQLColumnHelper.ITEM_AMOUNT}.${SQLColumnHelper.SUPPL_RECON_COST_ADJ_AMT_LOCAL}
            ,${SQLColumnHelper.ITEM_AMOUNT}.${SQLColumnHelper.TOTL_FEE_COST_AMT_LOCAL}
            ,${SQLColumnHelper.ITEM_AMOUNT}.${SQLColumnHelper.SVC_CHRG_COST_AMT_LOCAL}
            ,${SQLColumnHelper.ITEM_AMOUNT}.${SQLColumnHelper.OTHR_FEE_COST_AMT_LOCAL}
            ,${SQLColumnHelper.ITEM_AMOUNT}.${SQLColumnHelper.ECA_FEE_COST_AMT_LOCAL}
            ,${SQLColumnHelper.ITEM_AMOUNT}.${SQLColumnHelper.TOTL_TAX_COST_AMT_LOCAL}
            ,${SQLColumnHelper.ITEM_AMOUNT}.${SQLColumnHelper.VAR_MARGN_CREDT_LOCAL}
            ,${SQLColumnHelper.ITEM_AMOUNT}.${SQLColumnHelper.MARGN_AMT_USD}
            ,${SQLColumnHelper.ITEM_AMOUNT}.${SQLColumnHelper.PURE_MARGN_AMT_USD}
            ,${SQLColumnHelper.ITEM_AMOUNT}.${SQLColumnHelper.EXTRA_PERSN_COST_AMT_LOCAL}
            ,${SQLColumnHelper.ITEM_AMOUNT}.${SQLColumnHelper.RATE_PLN_RESTR_COST_AMT_LOCAL}
            ,${SQLColumnHelper.ITEM_AMOUNT}.${SQLColumnHelper.SNGL_SUPPLMNT_COST_AMT_LOCAL}
            ,${SQLColumnHelper.ITEM_AMOUNT}.${SQLColumnHelper.DYN_RATE_RULE_COST_AMT_LOCAL}
            ,${SQLColumnHelper.ITEM_AMOUNT}.${SQLColumnHelper.PURCHASE_BASE_PRICE_AMOUNT_LOCAL}
            ,${SQLColumnHelper.ITEM_AMOUNT}.${SQLColumnHelper.PURCHASE_TOTL_PRICE_ADJ_AMT_LOCAL}
            ,${SQLColumnHelper.ITEM_AMOUNT}.${SQLColumnHelper.PURCHASE_TOTL_FEE_PRICE_AMT_LOCAL}
            ,${SQLColumnHelper.ITEM_AMOUNT}.${SQLColumnHelper.PURCHASE_TOTL_TAX_PRICE_AMT_LOCAL}
            ,${SQLColumnHelper.ITEM_AMOUNT}.${SQLColumnHelper.PURCHASE_TOTL_COST_AMT_LOCAL}
            ,${SQLColumnHelper.ITEM_AMOUNT}.${SQLColumnHelper.PURCHASE_TOTL_TAX_COST_AMT_LOCAL}
            ,${SQLColumnHelper.ITEM_AMOUNT}.${SQLColumnHelper.PURCHASE_TOTL_COST_ADJ_AMT_LOCAL}
            ,${SQLColumnHelper.ITEM_AMOUNT}.${SQLColumnHelper.PURCHASE_COST_CURRENCY_CODE}
            ,${SQLColumnHelper.ITEM_AMOUNT}.${SQLColumnHelper.PURCHASE_PRICE_CURRENCY_CODE}
            ,${SQLColumnHelper.ITEM_AMOUNT}.${SQLColumnHelper.FRONT_END_COMMISSION_AMOUNT_USD}
            ,null AS ${SQLColumnHelper.TAX_DUE_AMOUNT}
            ,${propertyId}
            ,${SQLColumnHelper.BOOKING_DETAIL}.${SQLColumnHelper.LGL_ENTITY_NAME}
            ,${SQLColumnHelper.BOOKING_DETAIL}.${SQLColumnHelper.LGL_ENTITY_CODE}
            ,${SQLColumnHelper.BOOKING_DETAIL}.${SQLColumnHelper.POINT_OF_SALE_KEY}
            ,${SQLColumnHelper.BOOKING_DETAIL}.${SQLColumnHelper.POINT_OF_SALE_BRAND_NAME}
            ,${SQLColumnHelper.BOOKING_DETAIL}.${SQLColumnHelper.POINT_OF_SALE_NAME}
            ,${SQLColumnHelper.BOOKING_DETAIL}.${SQLColumnHelper.MANAGEMENT_UNIT_KEY}
            ,${SQLColumnHelper.BOOKING_DETAIL}.${SQLColumnHelper.MANAGEMENT_UNIT_CODE}
            ,${SQLColumnHelper.BOOKING_DETAIL}.${SQLColumnHelper.MANAGEMENT_UNIT_NAME}
            ,${SQLColumnHelper.BOOKING_DETAIL}.${SQLColumnHelper.MANAGEMENT_UNIT_LEVEL_6_NAME}
            ,${SQLColumnHelper.BOOKING_DETAIL}.${SQLColumnHelper.ORACLE_GL_PRODUCT_KEY}
            ,${SQLColumnHelper.BOOKING_DETAIL}.${SQLColumnHelper.TRAVEL_SERVICE_PROVIDER_NAME}
            ,${SQLColumnHelper.CAR_ITEM}.${SQLColumnHelper.RENTAL_DAY_COUNT}
            ,${SQLColumnHelper.CAR_ITEM}.${SQLColumnHelper.CAR_VENDOR_NAME}
            ,${SQLColumnHelper.CAR_ITEM}.${SQLColumnHelper.CAR_VENDOR_CODE}
            ,${SQLColumnHelper.CAR_ITEM}.${SQLColumnHelper.CAR_PICK_UP_LOCATION_NAME}
            ,${SQLColumnHelper.CAR_ITEM}.${SQLColumnHelper.CAR_PICK_UP_LOCATION_CITY_NAME}
            ,${SQLColumnHelper.CAR_ITEM}.${SQLColumnHelper.CAR_PICK_UP_LOCATION_STATE_PROVINCE_NAME}
            ,${SQLColumnHelper.CAR_ITEM}.${SQLColumnHelper.CAR_PICK_UP_LOCATION_COUNTRY_CODE}
            ,${SQLColumnHelper.CAR_ITEM}.${SQLColumnHelper.CAR_DROP_OFF_LOCATION_NAME}
            ,${SQLColumnHelper.CAR_ITEM}.${SQLColumnHelper.CAR_DROP_OFF_LOCATION_CITY_NAME}
            ,${SQLColumnHelper.CAR_ITEM}.${SQLColumnHelper.CAR_DROP_OFF_LOCATION_STATE_PROVINCE_NAME}
            ,${SQLColumnHelper.CAR_ITEM}.${SQLColumnHelper.CAR_DROP_OFF_LOCATION_COUNTRY_CODE}
            ,${SQLColumnHelper.CAR_ITEM}.${SQLColumnHelper.CAR_RATE_INDICATOR}
            ,cast(${SQLColumnHelper.LX_ITEM}.${SQLColumnHelper.ACTIVITY_ID} as string) as ${SQLColumnHelper.ACTIVITY_ID}
            ,${SQLColumnHelper.LX_ITEM}.${SQLColumnHelper.INTERNAL_CATEGORY_NAME}
            ,${SQLColumnHelper.LX_ITEM}.${SQLColumnHelper.OFFERING_NAME}
            ,${SQLColumnHelper.LX_ITEM}.${SQLColumnHelper.OFFERING_ITEM_NAME}
            ,${SQLColumnHelper.LX_ITEM}.${SQLColumnHelper.OFFERING_CATEGORY_NAME}
            ,${SQLColumnHelper.LX_ITEM}.${SQLColumnHelper.OFFERING_VENDOR_NAME}
            ,${SQLColumnHelper.LX_ITEM}.${SQLColumnHelper.OFFERING_VENDOR_BRANCH_NAME}
            ,${SQLColumnHelper.LX_ITEM}.${SQLColumnHelper.OFFERING_VENDOR_BRANCH_STATE_PROVINCE_NAME}
            ,${SQLColumnHelper.LX_ITEM}.${SQLColumnHelper.OFFERING_VENDOR_BRANCH_COUNTRY_NAME}
            ,${SQLColumnHelper.LX_ITEM}.${SQLColumnHelper.TICKET_COUNT}
            ,${SQLColumnHelper.EXCEPTIONS} as stg_bkg_exceptions
            ,${SQLColumnHelper.EVENT_INFO_PUBLISHED_TIMESTAMP} as published_timestamp
            ,${SQLColumnHelper.EVENT_INFO_HASH_EVENT_UUID} as hash_event_uuid
            ,${SQLColumnHelper.LOCAL_AMOUNTS}
        FROM ${stagedBookingTransactions} t
        WHERE $filterCriteria
    """)

        if (productLineName.toLowerCase() == "car") {
            postStayBookingTransDf = postStayBookingTransDf.withColumn(SQLColumnHelper.CAR_TAX_AREA_ID, lit(null))
                .withColumn(SQLColumnHelper.CAR_LOCATION_ID, lit(null))
                .withColumn(SQLColumnHelper.CAR_PICK_UP_LOCATION_STREET_ADDRESS1, lit(""))
                .withColumn(SQLColumnHelper.CAR_PICK_UP_LOCATION_STREET_ADDRESS2, lit(""))
                .withColumn(SQLColumnHelper.CAR_PICK_UP_LOCATION_POSTAL_CODE, lit(""))
                .withColumn(SQLColumnHelper.CAR_PICK_UP_LOCATION_LATITUDE, lit(""))
                .withColumn(SQLColumnHelper.CAR_PICK_UP_LOCATION_LONGITUDE, lit(""))
        }

        postStayBookingTransDf
    }

    def selectPostStagedBookingTransactionsWithLocalAmounts(sqlc: SparkSession, filterCriteria: String, productLineName: String): DataFrame = {

        var propertyId: String = null
        if (productLineName.toLowerCase() == "lodging") {
            propertyId = SQLColumnHelper.PROPERTY_ITEM + "." + SQLColumnHelper.PROPERTY_ID
        }

        var bookingTransDF = sqlc.sql(
            raw"""
                    SELECT * FROM ${stagedBookingTransactions} t
                    WHERE $filterCriteria
                   """)

        bookingTransDF = bookingTransDF.withColumn("local_amount",
            DataUtil.buildMapFromAmountArray(col("local_amounts.monetary_computational_reference"),
                col("local_amounts.money.amount")))

        bookingTransDF.createOrReplaceTempView("bookingTransDfView")

        var postStayBookingTransDf = bookingTransDF

        postStayBookingTransDf = sqlc.sql(
            raw"""
    SELECT
            ${SQLColumnHelper.TRANSACTION_LIABILITY_DATE}
            ,${SQLColumnHelper.PRODUCT_LINE_NAME}
            ,${SQLColumnHelper.BOOKING_ITEM}.${SQLColumnHelper.USE_DATE} as ${SQLColumnHelper.STAY_DATE}
            ,${SQLColumnHelper.BOOKING_ITEM}.${SQLColumnHelper.BOOK_DATE}
            ,${SQLColumnHelper.BOOKING_ITEM}.${SQLColumnHelper.BEGIN_USE_DATE}
            ,${SQLColumnHelper.BOOKING_ITEM}.${SQLColumnHelper.END_USE_DATE}
            ,${SQLColumnHelper.BOOKING_ITEM}.${SQLColumnHelper.BUSINESS_MODEL_NAME}
            ,${SQLColumnHelper.BOOKING_ITEM}.${SQLColumnHelper.BUSINESS_MODEL_SUBTYPE_NAME}
            ,${SQLColumnHelper.BOOKING_ITEM}.${SQLColumnHelper.ROOM_NIGHT_COUNT}
            ,${SQLColumnHelper.BOOKING_ITEM}.${SQLColumnHelper.BOOKING_ITEM_ID}
            ,${SQLColumnHelper.BOOKING_ITEM}.${SQLColumnHelper.BOOKING_ID}
            ,${SQLColumnHelper.BOOKING_ITEM}.${SQLColumnHelper.TRANSACTION_TYPE_NAME}
            ,${SQLColumnHelper.BOOKING_ITEM}.${SQLColumnHelper.BOOKING_EVENT_DATE}
            ,${SQLColumnHelper.BOOKING_ITEM}.${SQLColumnHelper.BOOKING_EVENT_DATETIME}
            ,${SQLColumnHelper.BOOKING_ITEM}.${SQLColumnHelper.SOURCE_SYSTEM_ID}
            ,${SQLColumnHelper.BOOKING_ITEM}.${SQLColumnHelper.TRAVEL_PRODUCT_ID}
            ,${SQLColumnHelper.BOOKING_ITEM}.${SQLColumnHelper.TOTAL_TRAVELER_COUNT}
            ,${SQLColumnHelper.BOOKING_ITEM}.${SQLColumnHelper.TRANSACTION_TYPE_KEY}
            ,${SQLColumnHelper.BOOKING_ITEM}.${SQLColumnHelper.TRAVEL_RECORD_LOCATOR}
            ,${SQLColumnHelper.BOOKING_ITEM}.${SQLColumnHelper.LODG_ROOM_TYPE_ID}
            ,${SQLColumnHelper.BOOKING_ITEM}.${SQLColumnHelper.ITIN_NBR}
            ,${SQLColumnHelper.BOOKING_ITEM}.${SQLColumnHelper.PKG_IND}
            ,${SQLColumnHelper.LOCAL_AMOUNT}.${SQLColumnHelper.BASE_PRICE_AMT_LOCAL}
            ,${SQLColumnHelper.LOCAL_AMOUNT}.${SQLColumnHelper.OTHR_PRICE_ADJ_AMT_LOCAL}
            ,${SQLColumnHelper.LOCAL_AMOUNT}.${SQLColumnHelper.PNLTY_PRICE_ADJ_AMT_LOCAL}
            ,${SQLColumnHelper.LOCAL_AMOUNT}.${SQLColumnHelper.EXPE_PNLTY_PRICE_ADJ_AMT_LOCAL}
            ,${SQLColumnHelper.LOCAL_AMOUNT}.${SQLColumnHelper.TOTL_PRICE_ADJ_AMT_LOCAL}
            ,${SQLColumnHelper.LOCAL_AMOUNT}.${SQLColumnHelper.SVC_FEE_PRICE_AMT_LOCAL}
            ,${SQLColumnHelper.LOCAL_AMOUNT}.${SQLColumnHelper.TOTL_FEE_PRICE_AMT_LOCAL}
            ,${SQLColumnHelper.LOCAL_AMOUNT}.${SQLColumnHelper.TOTL_TAX_PRICE_AMT_LOCAL}
            ,${SQLColumnHelper.LOCAL_AMOUNT}.${SQLColumnHelper.SVC_CHRG_PRICE_AMT_LOCAL}
            ,${SQLColumnHelper.LOCAL_AMOUNT}.${SQLColumnHelper.CNCL_CHG_FEE_PRICE_AMT_LOCAL}
            ,${SQLColumnHelper.ITEM_AMOUNT}.${SQLColumnHelper.BASE_COST_AMT_USD}
            ,${SQLColumnHelper.ITEM_AMOUNT}.${SQLColumnHelper.OTHR_COST_ADJ_AMT_USD}
            ,${SQLColumnHelper.ITEM_AMOUNT}.${SQLColumnHelper.SUPPL_COST_ADJ_AMT_USD}
            ,${SQLColumnHelper.ITEM_AMOUNT}.${SQLColumnHelper.TOTL_COST_ADJ_AMT_USD}
            ,${SQLColumnHelper.ITEM_AMOUNT}.${SQLColumnHelper.TOTL_COST_AMT_USD}
            ,${SQLColumnHelper.ITEM_AMOUNT}.${SQLColumnHelper.TOTL_FEE_COST_AMT_USD}
            ,${SQLColumnHelper.ITEM_AMOUNT}.${SQLColumnHelper.TOTL_TAX_COST_AMT_USD}
            ,${SQLColumnHelper.LOCAL_AMOUNT}.${SQLColumnHelper.GROSS_BKG_AMT_LOCAL}
            ,${SQLColumnHelper.ITEM_AMOUNT}.${SQLColumnHelper.PRICE_CURRENCY_CODE}
            ,${SQLColumnHelper.ITEM_AMOUNT}.${SQLColumnHelper.COST_CURRENCY_CODE}
            ,${SQLColumnHelper.LOCAL_AMOUNT}.${SQLColumnHelper.COUPN_PRICE_AMT_LOCAL}
            ,${SQLColumnHelper.LOCAL_AMOUNT}.${SQLColumnHelper.EXPE_GDWLL_PRICE_ADJ_AMT_LOCAL}
            ,${SQLColumnHelper.LOCAL_AMOUNT}.${SQLColumnHelper.GDWLL_PRICE_ADJ_AMT_LOCAL}
            ,${SQLColumnHelper.LOCAL_AMOUNT}.${SQLColumnHelper.GENRIC_COUPN_PRICE_AMT_LOCAL}
            ,${SQLColumnHelper.LOCAL_AMOUNT}.${SQLColumnHelper.REFUND_PRICE_ADJ_AMT_LOCAL}
            ,${SQLColumnHelper.LOCAL_AMOUNT}.${SQLColumnHelper.REBATE_PRICE_AMT_LOCAL}
            ,${SQLColumnHelper.LOCAL_AMOUNT}.${SQLColumnHelper.TCM_PRICE_ADJ_AMT_LOCAL}
            ,${SQLColumnHelper.LOCAL_AMOUNT}.${SQLColumnHelper.CNCL_PNLTY_WAIVR_PRICE_ADJ_AMT_LOCAL}
            ,${SQLColumnHelper.LOCAL_AMOUNT}.${SQLColumnHelper.LOYLTY_POINT_PRICE_ADJ_AMT_LOCAL}
            ,${SQLColumnHelper.LOCAL_AMOUNT}.${SQLColumnHelper.EMP_DISC_PRICE_ADJ_AMT_LOCAL}
            ,${SQLColumnHelper.LOCAL_AMOUNT}.${SQLColumnHelper.SUPPL_RECON_PRICE_ADJ_AMT_LOCAL}
            ,${SQLColumnHelper.LOCAL_AMOUNT}.${SQLColumnHelper.OTHER_FEE_PRICE_AMOUNT_LOCAL}
            ,${SQLColumnHelper.LOCAL_AMOUNT}.${SQLColumnHelper.AGENT_ASSISTED_PURCHASE_FEE_AMOUNT_LOCAL}
            ,${SQLColumnHelper.LOCAL_AMOUNT}.${SQLColumnHelper.TOTL_COST_AMT_LOCAL}
            ,${SQLColumnHelper.LOCAL_AMOUNT}.${SQLColumnHelper.BASE_COST_AMT_LOCAL}
            ,${SQLColumnHelper.LOCAL_AMOUNT}.${SQLColumnHelper.TOTL_COST_ADJ_AMT_LOCAL}
            ,${SQLColumnHelper.LOCAL_AMOUNT}.${SQLColumnHelper.SUPPL_COST_ADJ_AMT_LOCAL}
            ,${SQLColumnHelper.LOCAL_AMOUNT}.${SQLColumnHelper.ECA_COST_ADJ_AMT_LOCAL}
            ,${SQLColumnHelper.LOCAL_AMOUNT}.${SQLColumnHelper.OTHR_COST_ADJ_AMT_LOCAL}
            ,${SQLColumnHelper.LOCAL_AMOUNT}.${SQLColumnHelper.VAR_MARGN_COST_ADJ_LOCAL}
            ,${SQLColumnHelper.LOCAL_AMOUNT}.${SQLColumnHelper.SUPPL_RECON_COST_ADJ_AMT_LOCAL}
            ,${SQLColumnHelper.LOCAL_AMOUNT}.${SQLColumnHelper.TOTL_FEE_COST_AMT_LOCAL}
            ,${SQLColumnHelper.LOCAL_AMOUNT}.${SQLColumnHelper.SVC_CHRG_COST_AMT_LOCAL}
            ,${SQLColumnHelper.LOCAL_AMOUNT}.${SQLColumnHelper.OTHR_FEE_COST_AMT_LOCAL}
            ,${SQLColumnHelper.LOCAL_AMOUNT}.${SQLColumnHelper.ECA_FEE_COST_AMT_LOCAL}
            ,${SQLColumnHelper.LOCAL_AMOUNT}.${SQLColumnHelper.TOTL_TAX_COST_AMT_LOCAL}
            ,${SQLColumnHelper.LOCAL_AMOUNT}.${SQLColumnHelper.VAR_MARGN_CREDT_LOCAL}
            ,${SQLColumnHelper.ITEM_AMOUNT}.${SQLColumnHelper.MARGN_AMT_USD}
            ,${SQLColumnHelper.ITEM_AMOUNT}.${SQLColumnHelper.PURE_MARGN_AMT_USD}
            ,${SQLColumnHelper.LOCAL_AMOUNT}.${SQLColumnHelper.EXTRA_PERSN_COST_AMT_LOCAL}
            ,${SQLColumnHelper.LOCAL_AMOUNT}.${SQLColumnHelper.RATE_PLN_RESTR_COST_AMT_LOCAL}
            ,${SQLColumnHelper.LOCAL_AMOUNT}.${SQLColumnHelper.SNGL_SUPPLMNT_COST_AMT_LOCAL}
            ,${SQLColumnHelper.LOCAL_AMOUNT}.${SQLColumnHelper.DYN_RATE_RULE_COST_AMT_LOCAL}
            ,${SQLColumnHelper.ITEM_AMOUNT}.${SQLColumnHelper.FRONT_END_COMMISSION_AMOUNT_USD}
            ,${SQLColumnHelper.ITEM_AMOUNT}.${SQLColumnHelper.PURCHASE_BASE_PRICE_AMOUNT_LOCAL}
            ,${SQLColumnHelper.ITEM_AMOUNT}.${SQLColumnHelper.PURCHASE_TOTL_PRICE_ADJ_AMT_LOCAL}
            ,${SQLColumnHelper.ITEM_AMOUNT}.${SQLColumnHelper.PURCHASE_TOTL_FEE_PRICE_AMT_LOCAL}
            ,${SQLColumnHelper.ITEM_AMOUNT}.${SQLColumnHelper.PURCHASE_TOTL_TAX_PRICE_AMT_LOCAL}
            ,${SQLColumnHelper.ITEM_AMOUNT}.${SQLColumnHelper.PURCHASE_TOTL_COST_AMT_LOCAL}
            ,${SQLColumnHelper.ITEM_AMOUNT}.${SQLColumnHelper.PURCHASE_TOTL_TAX_COST_AMT_LOCAL}
            ,${SQLColumnHelper.ITEM_AMOUNT}.${SQLColumnHelper.PURCHASE_TOTL_COST_ADJ_AMT_LOCAL}
            ,${SQLColumnHelper.ITEM_AMOUNT}.${SQLColumnHelper.PURCHASE_COST_CURRENCY_CODE}
            ,${SQLColumnHelper.ITEM_AMOUNT}.${SQLColumnHelper.PURCHASE_PRICE_CURRENCY_CODE}
            ,${SQLColumnHelper.LOCAL_AMOUNT}.${SQLColumnHelper.TAX_DUE_AMOUNT}
            ,${propertyId}
            ,${SQLColumnHelper.BOOKING_DETAIL}.${SQLColumnHelper.LGL_ENTITY_NAME}
            ,${SQLColumnHelper.BOOKING_DETAIL}.${SQLColumnHelper.LGL_ENTITY_CODE}
            ,${SQLColumnHelper.BOOKING_DETAIL}.${SQLColumnHelper.POINT_OF_SALE_KEY}
            ,${SQLColumnHelper.BOOKING_DETAIL}.${SQLColumnHelper.POINT_OF_SALE_BRAND_NAME}
            ,${SQLColumnHelper.BOOKING_DETAIL}.${SQLColumnHelper.POINT_OF_SALE_NAME}
            ,${SQLColumnHelper.BOOKING_DETAIL}.${SQLColumnHelper.MANAGEMENT_UNIT_KEY}
            ,${SQLColumnHelper.BOOKING_DETAIL}.${SQLColumnHelper.MANAGEMENT_UNIT_CODE}
            ,${SQLColumnHelper.BOOKING_DETAIL}.${SQLColumnHelper.MANAGEMENT_UNIT_NAME}
            ,${SQLColumnHelper.BOOKING_DETAIL}.${SQLColumnHelper.MANAGEMENT_UNIT_LEVEL_6_NAME}
            ,${SQLColumnHelper.BOOKING_DETAIL}.${SQLColumnHelper.ORACLE_GL_PRODUCT_KEY}
            ,${SQLColumnHelper.BOOKING_DETAIL}.${SQLColumnHelper.TRAVEL_SERVICE_PROVIDER_NAME}
            ,${SQLColumnHelper.CAR_ITEM}.${SQLColumnHelper.RENTAL_DAY_COUNT}
            ,${SQLColumnHelper.CAR_ITEM}.${SQLColumnHelper.CAR_VENDOR_NAME}
            ,${SQLColumnHelper.CAR_ITEM}.${SQLColumnHelper.CAR_VENDOR_CODE}
            ,${SQLColumnHelper.CAR_ITEM}.${SQLColumnHelper.CAR_PICK_UP_LOCATION_NAME}
            ,${SQLColumnHelper.CAR_ITEM}.${SQLColumnHelper.CAR_PICK_UP_LOCATION_CITY_NAME}
            ,${SQLColumnHelper.CAR_ITEM}.${SQLColumnHelper.CAR_PICK_UP_LOCATION_STATE_PROVINCE_NAME}
            ,${SQLColumnHelper.CAR_ITEM}.${SQLColumnHelper.CAR_PICK_UP_LOCATION_COUNTRY_CODE}
            ,${SQLColumnHelper.CAR_ITEM}.${SQLColumnHelper.CAR_DROP_OFF_LOCATION_NAME}
            ,${SQLColumnHelper.CAR_ITEM}.${SQLColumnHelper.CAR_DROP_OFF_LOCATION_CITY_NAME}
            ,${SQLColumnHelper.CAR_ITEM}.${SQLColumnHelper.CAR_DROP_OFF_LOCATION_STATE_PROVINCE_NAME}
            ,${SQLColumnHelper.CAR_ITEM}.${SQLColumnHelper.CAR_DROP_OFF_LOCATION_COUNTRY_CODE}
            ,${SQLColumnHelper.CAR_ITEM}.${SQLColumnHelper.CAR_RATE_INDICATOR}
            ,cast(${SQLColumnHelper.LX_ITEM}.${SQLColumnHelper.ACTIVITY_ID} as string) as ${SQLColumnHelper.ACTIVITY_ID}
            ,${SQLColumnHelper.LX_ITEM}.${SQLColumnHelper.INTERNAL_CATEGORY_NAME}
            ,${SQLColumnHelper.LX_ITEM}.${SQLColumnHelper.OFFERING_NAME}
            ,${SQLColumnHelper.LX_ITEM}.${SQLColumnHelper.OFFERING_ITEM_NAME}
            ,${SQLColumnHelper.LX_ITEM}.${SQLColumnHelper.OFFERING_CATEGORY_NAME}
            ,${SQLColumnHelper.LX_ITEM}.${SQLColumnHelper.OFFERING_VENDOR_NAME}
            ,${SQLColumnHelper.LX_ITEM}.${SQLColumnHelper.OFFERING_VENDOR_BRANCH_NAME}
            ,${SQLColumnHelper.LX_ITEM}.${SQLColumnHelper.OFFERING_VENDOR_BRANCH_STATE_PROVINCE_NAME}
            ,${SQLColumnHelper.LX_ITEM}.${SQLColumnHelper.OFFERING_VENDOR_BRANCH_COUNTRY_NAME}
            ,${SQLColumnHelper.LX_ITEM}.${SQLColumnHelper.TICKET_COUNT}
            ,${SQLColumnHelper.EXCEPTIONS} as stg_bkg_exceptions
            ,${SQLColumnHelper.EVENT_INFO_PUBLISHED_TIMESTAMP} as published_timestamp
            ,${SQLColumnHelper.EVENT_INFO_HASH_EVENT_UUID} as hash_event_uuid
            ,${SQLColumnHelper.LOCAL_AMOUNTS}
        FROM bookingTransDfView t
        WHERE $filterCriteria
    """)

        if (productLineName.toLowerCase() == "car") {
            postStayBookingTransDf = postStayBookingTransDf.withColumn(SQLColumnHelper.CAR_TAX_AREA_ID, lit(null))
                .withColumn(SQLColumnHelper.CAR_LOCATION_ID, lit(null))
                .withColumn(SQLColumnHelper.CAR_PICK_UP_LOCATION_STREET_ADDRESS1, lit(""))
                .withColumn(SQLColumnHelper.CAR_PICK_UP_LOCATION_STREET_ADDRESS2, lit(""))
                .withColumn(SQLColumnHelper.CAR_PICK_UP_LOCATION_POSTAL_CODE, lit(""))
                .withColumn(SQLColumnHelper.CAR_PICK_UP_LOCATION_LATITUDE, lit(""))
                .withColumn(SQLColumnHelper.CAR_PICK_UP_LOCATION_LONGITUDE, lit(""))
        }

        postStayBookingTransDf
    }

    def getManualTransactions(spark: SparkSession, filterCriteria: String, productLineName: String,
                              isPostStay: Boolean): DataFrame = {

        val filterQuery =
            s"""
               |SELECT *
               |FROM $manualTransactions
               |WHERE $filterCriteria""".stripMargin
        var manualTransactionsDF = spark.sql(filterQuery)

        manualTransactionsDF = manualTransactionsDF.withColumn(
            "local_amount",
            DataUtil.buildMapFromAmountArray(
                col("local_amounts.monetary_computational_reference"),
                col("local_amounts.money.amount")
            )
        )

        val manualTransactionsView = "manual_transactions_view"
        manualTransactionsDF.createOrReplaceTempView(manualTransactionsView)

        val extraAddressFields = if (NON_TRAVEL_PRODUCT_LINES.contains(productLineName.toLowerCase())) {
            s"""${SQLColumnHelper.BOOKING_DETAIL}.${SQLColumnHelper.TRAVEL_SERVICE_PROVIDER_NAME} AS ${SQLColumnHelper.PARTNER_NAME},
               |${SQLColumnHelper.PARTNER_ITEM}.${SQLColumnHelper.PARTNER_ADDRESS}.${SQLColumnHelper.PARTNER_ADDRESS_LINE_1},
               |${SQLColumnHelper.PARTNER_ITEM}.${SQLColumnHelper.PARTNER_ADDRESS}.${SQLColumnHelper.PARTNER_ADDRESS_LINE_2},
               |${SQLColumnHelper.PARTNER_ITEM}.${SQLColumnHelper.PARTNER_ADDRESS}.${SQLColumnHelper.CITY},
               |${SQLColumnHelper.PARTNER_ITEM}.${SQLColumnHelper.PARTNER_ADDRESS}.${SQLColumnHelper.STATE},
               |${SQLColumnHelper.PARTNER_ITEM}.${SQLColumnHelper.PARTNER_ADDRESS}.${SQLColumnHelper.POSTAL_CODE},
               |${SQLColumnHelper.PARTNER_ITEM}.${SQLColumnHelper.PARTNER_ADDRESS}.${SQLColumnHelper.COUNTRY_CODE},
               |${SQLColumnHelper.BOOKING_ITEM}.${SQLColumnHelper.USE_DATE} AS ${DigitalServiceConstant.INVOICE_DATE},
               |${SQLColumnHelper.BOOKING_ITEM}.${SQLColumnHelper.BOOKING_ITEM_ID} AS ${DigitalServiceConstant.INVOICE_LINE_NUMBER},
               |cast(${SQLColumnHelper.BOOKING_ITEM}.${SQLColumnHelper.BOOKING_ID} AS string) AS ${DigitalServiceConstant.INVOICE_NUMBER},
               |${SQLColumnHelper.BOOKING_ITEM}.${SQLColumnHelper.TRANSACTION_TYPE_NAME} AS ${DigitalServiceConstant.INVOICE_TYPE},
               |${SQLColumnHelper.PRODUCT_LINE_NAME} AS ${DigitalServiceConstant.PRODUCT_TYPE},
               |null AS ${DigitalServiceConstant.ADDITIONAL_ATTRIBUTES},""".stripMargin
        } else if (productLineName.toLowerCase == AppConstants.PRODUCT_LINE_NAME_CAR) {
            s"""null AS ${SQLColumnHelper.CAR_TAX_AREA_ID},
               |${SQLColumnHelper.CAR_ITEM}.${SQLColumnHelper.LOCATION_ID} AS ${SQLColumnHelper.CAR_LOCATION_ID},
               |'' AS ${SQLColumnHelper.CAR_PICK_UP_LOCATION_STREET_ADDRESS1},
               |'' AS ${SQLColumnHelper.CAR_PICK_UP_LOCATION_STREET_ADDRESS2},
               |'' AS ${SQLColumnHelper.CAR_PICK_UP_LOCATION_POSTAL_CODE},
               |'' AS ${SQLColumnHelper.CAR_PICK_UP_LOCATION_LATITUDE},
               |'' AS ${SQLColumnHelper.CAR_PICK_UP_LOCATION_LONGITUDE},""".stripMargin
        } else {
            ""
        }

        val postStayFields = if (isPostStay) {
            s"""${SQLColumnHelper.ITEM_AMOUNT}.${SQLColumnHelper.PURCHASE_BASE_PRICE_AMOUNT_LOCAL},
               |${SQLColumnHelper.ITEM_AMOUNT}.${SQLColumnHelper.PURCHASE_TOTL_PRICE_ADJ_AMT_LOCAL},
               |${SQLColumnHelper.ITEM_AMOUNT}.${SQLColumnHelper.PURCHASE_TOTL_FEE_PRICE_AMT_LOCAL},
               |${SQLColumnHelper.ITEM_AMOUNT}.${SQLColumnHelper.PURCHASE_TOTL_TAX_PRICE_AMT_LOCAL},
               |${SQLColumnHelper.ITEM_AMOUNT}.${SQLColumnHelper.PURCHASE_TOTL_COST_AMT_LOCAL},
               |${SQLColumnHelper.ITEM_AMOUNT}.${SQLColumnHelper.PURCHASE_TOTL_TAX_COST_AMT_LOCAL},
               |${SQLColumnHelper.ITEM_AMOUNT}.${SQLColumnHelper.PURCHASE_TOTL_COST_ADJ_AMT_LOCAL},
               |${SQLColumnHelper.ITEM_AMOUNT}.${SQLColumnHelper.PURCHASE_COST_CURRENCY_CODE},
               |${SQLColumnHelper.ITEM_AMOUNT}.${SQLColumnHelper.PURCHASE_PRICE_CURRENCY_CODE},""".stripMargin
        } else {
            ""
        }

        val manualTransactionsQuery = s"""
                                         |SELECT
                                         |  ${SQLColumnHelper.TRANSACTION_LIABILITY_DATE},
                                         |  ${SQLColumnHelper.PRODUCT_LINE_NAME},
                                         |  ${SQLColumnHelper.BOOKING_ITEM}.${SQLColumnHelper.USE_DATE} AS ${SQLColumnHelper.STAY_DATE},
                                         |  ${SQLColumnHelper.BOOKING_ITEM}.${SQLColumnHelper.BOOK_DATE},
                                         |  ${SQLColumnHelper.BOOKING_ITEM}.${SQLColumnHelper.BEGIN_USE_DATE},
                                         |  ${SQLColumnHelper.BOOKING_ITEM}.${SQLColumnHelper.END_USE_DATE},
                                         |  ${SQLColumnHelper.BOOKING_ITEM}.${SQLColumnHelper.BUSINESS_MODEL_NAME},
                                         |  ${SQLColumnHelper.BOOKING_ITEM}.${SQLColumnHelper.BUSINESS_MODEL_SUBTYPE_NAME},
                                         |  ${SQLColumnHelper.BOOKING_ITEM}.${SQLColumnHelper.ROOM_NIGHT_COUNT},
                                         |  ${SQLColumnHelper.BOOKING_ITEM}.${SQLColumnHelper.BOOKING_ITEM_ID},
                                         |  ${SQLColumnHelper.BOOKING_ITEM}.${SQLColumnHelper.BOOKING_ID},
                                         |  ${SQLColumnHelper.BOOKING_ITEM}.${SQLColumnHelper.TRANSACTION_TYPE_NAME},
                                         |  ${SQLColumnHelper.BOOKING_ITEM}.${SQLColumnHelper.BOOKING_EVENT_DATE},
                                         |  ${SQLColumnHelper.BOOKING_ITEM}.${SQLColumnHelper.BOOKING_EVENT_DATETIME},
                                         |  ${SQLColumnHelper.BOOKING_ITEM}.${SQLColumnHelper.SOURCE_SYSTEM_ID},
                                         |  ${SQLColumnHelper.BOOKING_ITEM}.${SQLColumnHelper.TRAVEL_PRODUCT_ID},
                                         |  ${SQLColumnHelper.BOOKING_ITEM}.${SQLColumnHelper.TOTAL_TRAVELER_COUNT},
                                         |  ${SQLColumnHelper.BOOKING_ITEM}.${SQLColumnHelper.TRANSACTION_TYPE_KEY},
                                         |  ${SQLColumnHelper.BOOKING_ITEM}.${SQLColumnHelper.TRAVEL_RECORD_LOCATOR},
                                         |  ${SQLColumnHelper.BOOKING_ITEM}.${SQLColumnHelper.LODG_ROOM_TYPE_ID},
                                         |  ${SQLColumnHelper.BOOKING_ITEM}.${SQLColumnHelper.ITIN_NBR},
                                         |  ${SQLColumnHelper.BOOKING_ITEM}.${SQLColumnHelper.PKG_IND},
                                         |  ${SQLColumnHelper.LOCAL_AMOUNT}.${SQLColumnHelper.BASE_PRICE_AMOUNT_LOCAL},
                                         |  ${SQLColumnHelper.LOCAL_AMOUNT}.${SQLColumnHelper.OTHER_PRICE_ADJUSTMENT_AMOUNT_LOCAL},
                                         |  ${SQLColumnHelper.LOCAL_AMOUNT}.${SQLColumnHelper.PENALTY_PRICE_ADJUSTMENT_AMOUNT_LOCAL},
                                         |  ${SQLColumnHelper.LOCAL_AMOUNT}.${SQLColumnHelper.EXPEDIA_PENALTY_PRICE_ADJUSTMENT_AMOUNT_LOCAL},
                                         |  ${SQLColumnHelper.LOCAL_AMOUNT}.${SQLColumnHelper.TOTAL_PRICE_ADJUSTMENT_AMOUNT_LOCAL},
                                         |  ${SQLColumnHelper.LOCAL_AMOUNT}.${SQLColumnHelper.SERVICE_FEE_PRICE_AMOUNT_LOCAL},
                                         |  ${SQLColumnHelper.LOCAL_AMOUNT}.${SQLColumnHelper.TOTAL_FEE_PRICE_AMOUNT_LOCAL},
                                         |  ${SQLColumnHelper.LOCAL_AMOUNT}.${SQLColumnHelper.TOTAL_TAX_PRICE_AMOUNT_LOCAL},
                                         |  ${SQLColumnHelper.LOCAL_AMOUNT}.${SQLColumnHelper.SERVICE_CHARGE_PRICE_AMOUNT_LOCAL},
                                         |  ${SQLColumnHelper.LOCAL_AMOUNT}.${SQLColumnHelper.CANCEL_CHANGE_FEE_PRICE_AMOUNT_LOCAL},
                                         |  ${SQLColumnHelper.ITEM_AMOUNT}.${SQLColumnHelper.BASE_COST_AMT_USD},
                                         |  ${SQLColumnHelper.ITEM_AMOUNT}.${SQLColumnHelper.OTHR_COST_ADJ_AMT_USD},
                                         |  ${SQLColumnHelper.ITEM_AMOUNT}.${SQLColumnHelper.SUPPL_COST_ADJ_AMT_USD},
                                         |  ${SQLColumnHelper.ITEM_AMOUNT}.${SQLColumnHelper.TOTL_COST_ADJ_AMT_USD},
                                         |  ${SQLColumnHelper.ITEM_AMOUNT}.${SQLColumnHelper.TOTL_COST_AMT_USD},
                                         |  ${SQLColumnHelper.ITEM_AMOUNT}.${SQLColumnHelper.TOTL_FEE_COST_AMT_USD},
                                         |  ${SQLColumnHelper.ITEM_AMOUNT}.${SQLColumnHelper.TOTL_TAX_COST_AMT_USD},
                                         |  ${SQLColumnHelper.LOCAL_AMOUNT}.${SQLColumnHelper.GROSS_BOOKING_AMOUNT_LOCAL},
                                         |  ${SQLColumnHelper.ITEM_AMOUNT}.${SQLColumnHelper.PRICE_CURRENCY_CODE},
                                         |  ${SQLColumnHelper.ITEM_AMOUNT}.${SQLColumnHelper.COST_CURRENCY_CODE},
                                         |  ${SQLColumnHelper.LOCAL_AMOUNT}.${SQLColumnHelper.COUPON_PRICE_AMOUNT_LOCAL},
                                         |  ${SQLColumnHelper.LOCAL_AMOUNT}.${SQLColumnHelper.EXPEDIA_GOODWILL_PRICE_ADJUSTMENT_AMOUNT_LOCAL},
                                         |  ${SQLColumnHelper.LOCAL_AMOUNT}.${SQLColumnHelper.GOODWILL_PRICE_ADJUSTMENT_AMOUNT_LOCAL},
                                         |  ${SQLColumnHelper.LOCAL_AMOUNT}.${SQLColumnHelper.GENERIC_COUPON_PRICE_AMOUNT_LOCAL},
                                         |  ${SQLColumnHelper.LOCAL_AMOUNT}.${SQLColumnHelper.REFUND_PRICE_ADJUSTMENT_AMOUNT_LOCAL},
                                         |  ${SQLColumnHelper.LOCAL_AMOUNT}.${SQLColumnHelper.REBATE_PRICE_AMOUNT_LOCAL},
                                         |  ${SQLColumnHelper.LOCAL_AMOUNT}.${SQLColumnHelper.TCM_PRICE_ADJUSTMENT_AMOUNT_LOCAL},
                                         |  ${SQLColumnHelper.LOCAL_AMOUNT}.${SQLColumnHelper.CANCEL_PENALTY_WAIVER_PRICE_ADJUSTMENT_AMOUNT_LOCAL},
                                         |  ${SQLColumnHelper.LOCAL_AMOUNT}.${SQLColumnHelper.LOYALTY_POINT_PRICE_ADJUSTMENT_AMOUNT_LOCAL},
                                         |  ${SQLColumnHelper.LOCAL_AMOUNT}.${SQLColumnHelper.EMPLOYEE_DISCOUNT_PRICE_ADJUSTMENT_AMOUNT_LOCAL},
                                         |  ${SQLColumnHelper.LOCAL_AMOUNT}.${SQLColumnHelper.SUPPLIER_RECONCILIATION_PRICE_ADJUSTMENT_AMOUNT_LOCAL},
                                         |  ${SQLColumnHelper.LOCAL_AMOUNT}.${SQLColumnHelper.OTHER_FEE_PRICE_AMOUNT_LOCAL},
                                         |  ${SQLColumnHelper.LOCAL_AMOUNT}.${SQLColumnHelper.AGENT_ASSISTED_PURCHASE_FEE_AMOUNT_LOCAL},
                                         |  ${SQLColumnHelper.LOCAL_AMOUNT}.${SQLColumnHelper.TOTAL_COST_AMOUNT_LOCAL},
                                         |  ${SQLColumnHelper.LOCAL_AMOUNT}.${SQLColumnHelper.BASE_COST_AMOUNT_LOCAL},
                                         |  ${SQLColumnHelper.LOCAL_AMOUNT}.${SQLColumnHelper.TOTAL_COST_ADJUSTMENT_AMOUNT_LOCAL},
                                         |  ${SQLColumnHelper.LOCAL_AMOUNT}.${SQLColumnHelper.SUPPLIER_COST_ADJUSTMENT_AMOUNT_LOCAL},
                                         |  ${SQLColumnHelper.LOCAL_AMOUNT}.${SQLColumnHelper.ECA_COST_ADJUSTMENT_AMOUNT_LOCAL},
                                         |  ${SQLColumnHelper.LOCAL_AMOUNT}.${SQLColumnHelper.OTHER_COST_ADJUSTMENT_AMOUNT_LOCAL},
                                         |  ${SQLColumnHelper.LOCAL_AMOUNT}.${SQLColumnHelper.VARIABLE_MARGIN_COST_ADJUSTMENT_AMOUNT_LOCAL},
                                         |  ${SQLColumnHelper.LOCAL_AMOUNT}.${SQLColumnHelper.SUPPLIER_RECONCILIATION_COST_ADJUSTMENT_LOCAL},
                                         |  ${SQLColumnHelper.LOCAL_AMOUNT}.${SQLColumnHelper.TOTAL_FEE_COST_AMOUNT_LOCAL},
                                         |  ${SQLColumnHelper.LOCAL_AMOUNT}.${SQLColumnHelper.SERVICE_CHARGE_COST_AMOUNT_LOCAL},
                                         |  ${SQLColumnHelper.LOCAL_AMOUNT}.${SQLColumnHelper.OTHER_FEE_COST_AMOUNT_LOCAL},
                                         |  ${SQLColumnHelper.LOCAL_AMOUNT}.${SQLColumnHelper.ECA_FEE_COST_AMOUNT_LOCAL},
                                         |  ${SQLColumnHelper.LOCAL_AMOUNT}.${SQLColumnHelper.TOTAL_TAX_COST_AMOUNT_LOCAL},
                                         |  ${SQLColumnHelper.LOCAL_AMOUNT}.${SQLColumnHelper.VARIABLE_MARGIN_CREDIT_LOCAL},
                                         |  ${SQLColumnHelper.ITEM_AMOUNT}.${SQLColumnHelper.MARGN_AMT_USD},
                                         |  ${SQLColumnHelper.ITEM_AMOUNT}.${SQLColumnHelper.PURE_MARGN_AMT_USD},
                                         |  ${SQLColumnHelper.LOCAL_AMOUNT}.${SQLColumnHelper.EXTRA_PERSON_COST_AMOUNT_LOCAL},
                                         |  ${SQLColumnHelper.LOCAL_AMOUNT}.${SQLColumnHelper.RATE_PLAN_RESTRICTION_COST_AMOUNT_LOCAL},
                                         |  ${SQLColumnHelper.LOCAL_AMOUNT}.${SQLColumnHelper.SINGLE_SUPPLEMENT_COST_AMOUNT_LOCAL},
                                         |  ${SQLColumnHelper.LOCAL_AMOUNT}.${SQLColumnHelper.DYNAMIC_RATE_RULE_COST_AMOUNT_LOCAL},
                                         |  ${SQLColumnHelper.ITEM_AMOUNT}.${SQLColumnHelper.FRONT_END_COMMISSION_AMOUNT_USD},
                                         |  ${SQLColumnHelper.LOCAL_AMOUNT}.${SQLColumnHelper.TAX_DUE_AMOUNT},
                                         |  $postStayFields
                                         |  ${SQLColumnHelper.PROPERTY_ITEM}.${SQLColumnHelper.PROPERTY_ID},
                                         |  ${SQLColumnHelper.BOOKING_DETAIL}.${SQLColumnHelper.LGL_ENTITY_NAME},
                                         |  ${SQLColumnHelper.BOOKING_DETAIL}.${SQLColumnHelper.LGL_ENTITY_CODE},
                                         |  ${SQLColumnHelper.BOOKING_DETAIL}.${SQLColumnHelper.POINT_OF_SALE_KEY},
                                         |  ${SQLColumnHelper.BOOKING_DETAIL}.${SQLColumnHelper.POINT_OF_SALE_BRAND_NAME},
                                         |  ${SQLColumnHelper.BOOKING_DETAIL}.${SQLColumnHelper.POINT_OF_SALE_NAME},
                                         |  ${SQLColumnHelper.BOOKING_DETAIL}.${SQLColumnHelper.MANAGEMENT_UNIT_KEY},
                                         |  ${SQLColumnHelper.BOOKING_DETAIL}.${SQLColumnHelper.MANAGEMENT_UNIT_CODE},
                                         |  ${SQLColumnHelper.BOOKING_DETAIL}.${SQLColumnHelper.MANAGEMENT_UNIT_NAME},
                                         |  ${SQLColumnHelper.BOOKING_DETAIL}.${SQLColumnHelper.MANAGEMENT_UNIT_LEVEL_6_NAME},
                                         |  ${SQLColumnHelper.BOOKING_DETAIL}.${SQLColumnHelper.ORACLE_GL_PRODUCT_KEY},
                                         |  ${SQLColumnHelper.BOOKING_DETAIL}.${SQLColumnHelper.TRAVEL_SERVICE_PROVIDER_NAME},
                                         |  ${SQLColumnHelper.CAR_ITEM}.${SQLColumnHelper.RENTAL_DAY_COUNT},
                                         |  ${SQLColumnHelper.CAR_ITEM}.${SQLColumnHelper.CAR_VENDOR_NAME},
                                         |  ${SQLColumnHelper.CAR_ITEM}.${SQLColumnHelper.CAR_VENDOR_CODE},
                                         |  ${SQLColumnHelper.CAR_ITEM}.${SQLColumnHelper.CAR_PICK_UP_LOCATION_NAME},
                                         |  ${SQLColumnHelper.CAR_ITEM}.${SQLColumnHelper.CAR_PICK_UP_LOCATION_CITY_NAME},
                                         |  ${SQLColumnHelper.CAR_ITEM}.${SQLColumnHelper.CAR_PICK_UP_LOCATION_STATE_PROVINCE_NAME},
                                         |  ${SQLColumnHelper.CAR_ITEM}.${SQLColumnHelper.CAR_PICK_UP_LOCATION_COUNTRY_CODE},
                                         |  ${SQLColumnHelper.CAR_ITEM}.${SQLColumnHelper.CAR_DROP_OFF_LOCATION_NAME},
                                         |  ${SQLColumnHelper.CAR_ITEM}.${SQLColumnHelper.CAR_DROP_OFF_LOCATION_CITY_NAME},
                                         |  ${SQLColumnHelper.CAR_ITEM}.${SQLColumnHelper.CAR_DROP_OFF_LOCATION_STATE_PROVINCE_NAME},
                                         |  ${SQLColumnHelper.CAR_ITEM}.${SQLColumnHelper.CAR_DROP_OFF_LOCATION_COUNTRY_CODE},
                                         |  ${SQLColumnHelper.CAR_ITEM}.${SQLColumnHelper.CAR_RATE_INDICATOR},
                                         |  ${SQLColumnHelper.LX_ITEM}.${SQLColumnHelper.ACTIVITY_ID},
                                         |  ${SQLColumnHelper.LX_ITEM}.${SQLColumnHelper.INTERNAL_CATEGORY_NAME},
                                         |  ${SQLColumnHelper.LX_ITEM}.${SQLColumnHelper.OFFERING_NAME},
                                         |  ${SQLColumnHelper.LX_ITEM}.${SQLColumnHelper.OFFERING_ITEM_NAME},
                                         |  ${SQLColumnHelper.LX_ITEM}.${SQLColumnHelper.OFFERING_CATEGORY_NAME},
                                         |  ${SQLColumnHelper.LX_ITEM}.${SQLColumnHelper.OFFERING_VENDOR_NAME},
                                         |  ${SQLColumnHelper.LX_ITEM}.${SQLColumnHelper.OFFERING_VENDOR_BRANCH_NAME},
                                         |  ${SQLColumnHelper.LX_ITEM}.${SQLColumnHelper.OFFERING_VENDOR_BRANCH_STATE_PROVINCE_NAME},
                                         |  ${SQLColumnHelper.LX_ITEM}.${SQLColumnHelper.OFFERING_VENDOR_BRANCH_COUNTRY_NAME},
                                         |  ${SQLColumnHelper.LX_ITEM}.${SQLColumnHelper.TICKET_COUNT},
                                         |  null AS ${SQLColumnHelper.STG_BKG_EXCEPTIONS},
                                         |  ${SQLColumnHelper.EVENT_INFO_PUBLISHED_TIMESTAMP} AS ${SQLColumnHelper.PUBLISHED_TIMESTAMP},
                                         |  ${SQLColumnHelper.EVENT_INFO_HASH_EVENT_UUID} AS ${SQLColumnHelper.HASH_EVENT_UUID},
                                         |  ${SQLColumnHelper.LOCAL_AMOUNTS},
                                         |  $extraAddressFields
                                         |  '${SQLColumnHelper.GTP_FILE_UPLOAD}' AS ${SQLColumnHelper.EVENT_SOURCE_SYSTEM_NAME},
                                         |  ${SQLColumnHelper.ITEM_AMOUNT}.${SQLColumnHelper.TAX_BASE_OPTION},
                                         |  ${SQLColumnHelper.ITEM_AMOUNT}.${SQLColumnHelper.PRE_TAX_ENGINE_PRICE_AMOUNT_USD} AS ${SQLColumnHelper.PRE_TAX_ENGINE_PRICE_AMOUNT},
                                         |  ${SQLColumnHelper.ITEM_AMOUNT}.${SQLColumnHelper.PRE_TAX_ENGINE_COST_AMOUNT_USD} AS ${SQLColumnHelper.PRE_TAX_ENGINE_COST_AMOUNT},
                                         |  ${SQLColumnHelper.ITEM_AMOUNT}.${SQLColumnHelper.PRE_TAX_ENGINE_MARGIN_AMOUNT_USD} AS ${SQLColumnHelper.PRE_TAX_ENGINE_MARGIN_AMOUNT},
                                         |  ${SQLColumnHelper.BOOKING_DETAIL}.${SQLColumnHelper.ORACLE_GL_PRODUCT_CODE}
                                         |FROM $manualTransactionsView
                                         |""".stripMargin

        logger.info(s"Query to get Manual Transactions: $manualTransactionsQuery")
        spark.sql(manualTransactionsQuery)
    }

    def getDistinctStacAttributesQuery(productLineName: String, stacTbl: String): String = {
        val distinctStacAttributesQuery =
            raw"""
                 |SELECT DISTINCT
                 |keys_lv AS `key`
                 |FROM ${stacTbl} ${StacConstants.STAC_ALIAS}
                 |LATERAL VIEW outer explode(stac.attributes.key) keysVals as keys_lv
                 |LATERAL VIEW outer explode(stac.attributes) completeAttrib as attribs
                 |WHERE lower(stac.line_of_business) = lower('${productLineName}')
                 |AND keys_lv = attribs.key
                 |""".stripMargin

        distinctStacAttributesQuery
    }

    def getDistinctStacAttributesAllLobQuery(stacTbl: String): String = {
        val distinctStacAttributesQuery =
            raw"""
                 |SELECT DISTINCT
                 |keys_lv AS `key`
                 |FROM ${stacTbl} ${StacConstants.STAC_ALIAS}
                 |LATERAL VIEW outer explode(stac.attributes.key) keysVals as keys_lv
                 |LATERAL VIEW outer explode(stac.attributes) completeAttrib as attribs
                 |WHERE keys_lv = attribs.key
                 |""".stripMargin

        distinctStacAttributesQuery
    }

    def getDistinctRoomLevelStacAttributesQuery(productLineName: String, stacTbl: String): String = {
        val distinctStacRoomLevelAttributesQuery =
            raw"""
                 |SELECT DISTINCT
                 |keys_lv AS `key`
                 |FROM ${stacTbl} ${StacConstants.STAC_ALIAS}
                 |LATERAL VIEW outer explode(stac.attributes.key) keysVals as keys_lv
                 |WHERE lower(stac.line_of_business) = lower('${productLineName}')
                 |AND stac.sub_supplier_id IS NOT NULL
                 |""".stripMargin

        distinctStacRoomLevelAttributesQuery
    }

    def getDistinctRoomLevelStacAttributesAllLobQuery(stacTbl: String): String = {
        val distinctStacRoomLevelAttributesQuery =
            raw"""
                 |SELECT DISTINCT
                 |keys_lv AS `key`
                 |FROM ${stacTbl} ${StacConstants.STAC_ALIAS}
                 |LATERAL VIEW outer explode(stac.attributes.key) keysVals as keys_lv
                 |WHERE stac.sub_supplier_id IS NOT NULL
                 |""".stripMargin

        distinctStacRoomLevelAttributesQuery
    }

    def createSelectStacQuery(spark: SparkSession, productLineName: String, stacAttributes: Array[String], stacRoomLevelAttributes: Set[String]): DataFrame = {

        val attributesViewName = "attributes_view"
        val mappedViewName = "mapped_view"
        val groupedViewName = "grouped_view"
        val listViewName = "list_view"
        val propertyLevelAttributesViewName = "property_level_attributes_view"
        val roomLevelAttributeViewName = "room_level_attribute_view"
        val joinedAttributeViewName = "joined_attribute_view"


        val stacAlias = StacConstants.STAC_ALIAS

        val stacGroupedViewColumns = getStacGroupedViewColumns(mappedViewName, stacAttributes)
        val stacSelectColumns = getStacSelectColumns(stacAlias, stacAttributes)

        val attributeList = getStacAttributes(stacAttributes, stacRoomLevelAttributes)
        val propertyLevelAttributes = attributeList._1
        val roomLevelAttributes = attributeList._2
        val allAttributes = attributeList._3

        val attributesViewNameDF = spark.sql(
            raw"""
                 |	SELECT DISTINCT ${stacAlias}.supplier_id,
                 |    ${stacAlias}.sub_supplier_id,
                 |	  ${stacAlias}.line_of_business,
                 |    ${stacAlias}.country_code,
                 |	  keys_lv AS `key`,
                 |	  attribs.`values`[0] AS `value`
                 |	FROM ${stacTable} ${stacAlias}
                 |	LATERAL VIEW outer explode(${stacAlias}.attributes.key) keysVals AS keys_lv
                 |	LATERAL VIEW outer explode(${stacAlias}.attributes) completeAttrib AS attribs
                 |  WHERE lower(${stacAlias}.line_of_business) = lower('${productLineName}')
                 |	AND keys_lv = attribs.key
                 |""".stripMargin
        )
        attributesViewNameDF.createOrReplaceTempView(s"$attributesViewName")
        val mappedViewNameDF = spark.sql(
            raw"""
                 | SELECT
                 | supplier_id,
                 | sub_supplier_id,
                 | line_of_business,
                 | country_code,
                 | map(lower(`key`), `value`) as values_map
                 | FROM ${attributesViewName}
                 |""".stripMargin
        )
        mappedViewNameDF.createOrReplaceTempView(s"$mappedViewName")
        val groupedViewNameDF = spark.sql(
            raw"""
                 | SELECT
                 | supplier_id,
                 | sub_supplier_id,
                 | line_of_business,
                 | country_code
                 | ${stacGroupedViewColumns}
                 | FROM ${mappedViewName}
                 | GROUP BY ${mappedViewName}.supplier_id, ${mappedViewName}.sub_supplier_id, ${mappedViewName}.line_of_business, ${mappedViewName}.country_code
                 |""".stripMargin
        )
        groupedViewNameDF.createOrReplaceTempView(s"$groupedViewName")
        val listViewNameDF = spark.sql(
            raw"""
                 | SELECT
                 | stac.supplier_id,
                 | stac.sub_supplier_id,
                 | stac.line_of_business,
                 | stac.country_code
                 | ${stacSelectColumns}
                 | FROM ${groupedViewName} AS stac
                 |""".stripMargin
        )
        listViewNameDF.createOrReplaceTempView(s"$listViewName")
        val propertyLevelAttributesViewNameDF = spark.sql(
            raw"""
                 | SELECT
                 | supplier_id,
                 | line_of_business,
                 | country_code
                 | ${propertyLevelAttributes}
                 | FROM ${listViewName}
                 | where sub_supplier_id IS NULL
                 |""".stripMargin
        )
        propertyLevelAttributesViewNameDF.createOrReplaceTempView(s"$propertyLevelAttributesViewName")
        val roomLevelAttributeViewNameDF = spark.sql(
            raw"""
                 | SELECT
                 | supplier_id,
                 | sub_supplier_id,
                 | line_of_business,
                 | country_code
                 | ${roomLevelAttributes}
                 | FROM ${listViewName}
                 | where sub_supplier_id IS NOT NULL
                 |""".stripMargin
        )
        roomLevelAttributeViewNameDF.createOrReplaceTempView(s"$roomLevelAttributeViewName")
        val joinedAttributeViewNameDF = spark.sql(
            raw"""
                 | SELECT
                 | ${propertyLevelAttributesViewName}.supplier_id,
                 | ${propertyLevelAttributesViewName}.line_of_business,
                 | ${propertyLevelAttributesViewName}.country_code,
                 | sub_supplier_id
                 | ${allAttributes}
                 | FROM ${propertyLevelAttributesViewName} LEFT JOIN ${roomLevelAttributeViewName}
                 | ON
                 | ${roomLevelAttributeViewName}.supplier_id = ${propertyLevelAttributesViewName}.supplier_id
                 | and ${roomLevelAttributeViewName}.line_of_business = ${propertyLevelAttributesViewName}.line_of_business
                 | and ${roomLevelAttributeViewName}.country_code = ${propertyLevelAttributesViewName}.country_code
                 |""".stripMargin
        )
        val propertyLevelDataOnlyDF = listViewNameDF.filter(col("sub_supplier_id").isNull)
        var finalResultDF = joinedAttributeViewNameDF.unionByName(propertyLevelDataOnlyDF).distinct().orderBy(col("supplier_id"), col("sub_supplier_id").desc)
        finalResultDF = finalResultDF.withColumnRenamed("country_code", "stc_country_code").alias(s"$stacAlias")
        finalResultDF
    }

    def createSelectStacAllLobQuery(spark: SparkSession, stacAttributes: Array[String], stacRoomLevelAttributes: Set[String], splitRoomFromProperty: Boolean = true): DataFrame = {

        val attributesViewName = "attributes_view"
        val mappedViewName = "mapped_view"
        val groupedViewName = "grouped_view"
        val listViewName = "list_view"
        val propertyLevelAttributesViewName = "property_level_attributes_view"
        val roomLevelAttributeViewName = "room_level_attribute_view"
        val joinedAttributeViewName = "joined_attribute_view"


        val stacAlias = StacConstants.STAC_ALIAS

        val stacGroupedViewColumns = getStacGroupedViewColumns(mappedViewName, stacAttributes)
        val stacSelectColumns = getStacSelectColumns(stacAlias, stacAttributes)

        val attributeList = getStacAttributes(stacAttributes, stacRoomLevelAttributes)
        val propertyLevelAttributes = attributeList._1
        val roomLevelAttributes = attributeList._2
        val allAttributes = attributeList._3

        val attributesViewNameDF = spark.sql(
            raw"""
                 |	SELECT DISTINCT ${stacAlias}.supplier_id,
                 |    ${stacAlias}.sub_supplier_id,
                 |	  ${stacAlias}.line_of_business,
                 |    ${stacAlias}.country_code,
                 |	  keys_lv AS `key`,
                 |	  attribs.`values`[0] AS `value`
                 |	FROM ${stacTable} ${stacAlias}
                 |	LATERAL VIEW outer explode(${stacAlias}.attributes.key) keysVals AS keys_lv
                 |	LATERAL VIEW outer explode(${stacAlias}.attributes) completeAttrib AS attribs
                 |  WHERE keys_lv = attribs.key
                 |""".stripMargin
        )
        attributesViewNameDF.createOrReplaceTempView(s"$attributesViewName")
        val mappedViewNameDF = spark.sql(
            raw"""
                 | SELECT
                 | supplier_id,
                 | sub_supplier_id,
                 | line_of_business,
                 | country_code,
                 | map(lower(`key`), `value`) as values_map
                 | FROM ${attributesViewName}
                 |""".stripMargin
        )
        mappedViewNameDF.createOrReplaceTempView(s"$mappedViewName")
        val groupedViewNameDF = spark.sql(
            raw"""
                 | SELECT
                 | supplier_id,
                 | sub_supplier_id,
                 | line_of_business,
                 | country_code
                 | ${stacGroupedViewColumns}
                 | FROM ${mappedViewName}
                 | GROUP BY ${mappedViewName}.supplier_id, ${mappedViewName}.sub_supplier_id, ${mappedViewName}.line_of_business, ${mappedViewName}.country_code
                 |""".stripMargin
        )
        groupedViewNameDF.createOrReplaceTempView(s"$groupedViewName")
        val listViewNameDF = spark.sql(
            raw"""
                 | SELECT
                 | stac.supplier_id,
                 | stac.sub_supplier_id,
                 | stac.line_of_business,
                 | stac.country_code
                 | ${stacSelectColumns}
                 | FROM ${groupedViewName} AS stac
                 |""".stripMargin
        )

        if (splitRoomFromProperty) {
            listViewNameDF.createOrReplaceTempView(s"$listViewName")
            val propertyLevelAttributesViewNameDF = spark.sql(
                raw"""
                     | SELECT
                     | supplier_id,
                     | line_of_business,
                     | country_code
                     | ${propertyLevelAttributes}
                     | FROM ${listViewName}
                     | where sub_supplier_id IS NULL
                     |""".stripMargin
            )
            propertyLevelAttributesViewNameDF.createOrReplaceTempView(s"$propertyLevelAttributesViewName")
            val roomLevelAttributeViewNameDF = spark.sql(
                raw"""
                     | SELECT
                     | supplier_id,
                     | sub_supplier_id,
                     | line_of_business,
                     | country_code
                     | ${roomLevelAttributes}
                     | FROM ${listViewName}
                     | where sub_supplier_id IS NOT NULL
                     |""".stripMargin
            )
            roomLevelAttributeViewNameDF.createOrReplaceTempView(s"$roomLevelAttributeViewName")
            val joinedAttributeViewNameDF = spark.sql(
                raw"""
                     | SELECT
                     | ${propertyLevelAttributesViewName}.supplier_id,
                     | ${propertyLevelAttributesViewName}.line_of_business,
                     | ${propertyLevelAttributesViewName}.country_code,
                     | sub_supplier_id
                     | ${allAttributes}
                     | FROM ${propertyLevelAttributesViewName} LEFT JOIN ${roomLevelAttributeViewName}
                     | ON
                     | ${roomLevelAttributeViewName}.supplier_id = ${propertyLevelAttributesViewName}.supplier_id
                     | and ${roomLevelAttributeViewName}.line_of_business = ${propertyLevelAttributesViewName}.line_of_business
                     | and ${roomLevelAttributeViewName}.country_code = ${propertyLevelAttributesViewName}.country_code
                     |""".stripMargin
            )
            val propertyLevelDataOnlyDF = listViewNameDF.filter(col("sub_supplier_id").isNull)
            var finalResultDF = joinedAttributeViewNameDF.unionByName(propertyLevelDataOnlyDF).distinct().orderBy(col("supplier_id"), col("sub_supplier_id").desc)
            finalResultDF = finalResultDF.withColumnRenamed("country_code", "stc_country_code").alias(s"$stacAlias")
            finalResultDF
        } else {
            listViewNameDF.withColumnRenamed("country_code", "stc_country_code").alias(s"$stacAlias")
        }
    }

    protected def getStacGroupedViewColumns(mappedViewName: String, stacAttributes: Array[String]): String = {

        var groupedViewColumns = ""
        var formattedAttribute = ""

        for (attribute <- stacAttributes) {
            formattedAttribute = attribute.toLowerCase().replace(' ', '_')

            groupedViewColumns +=
                raw"""
                     |      ,collect_list(${mappedViewName}.values_map['${attribute.toLowerCase()}']) AS ${formattedAttribute}""".stripMargin
        }

        groupedViewColumns
    }

    protected def getStacSelectColumns(stacAlias: String, stacAttributes: Array[String]): String = {
        var selectColumns = ""

        var formattedAttribute = ""

        for (attribute <- stacAttributes) {
            formattedAttribute = attribute.toLowerCase().replace(' ', '_')
            selectColumns +=
                raw"""
                     |  ,CASE WHEN size(${stacAlias}.${formattedAttribute}) = 0 THEN NULL
                     |		  ELSE concat_ws('_',${stacAlias}.${formattedAttribute}) END AS ${formattedAttribute}""".stripMargin
        }

        selectColumns
    }

    def createSelectProductCatalogTableForLX(): String = {
        raw"""
             |with attributes_vw as (
             |   SELECT DISTINCT
             |    pc.supplier_id,
             |    attribs.name,
             |	 attribs.`values`[0] AS `value`
             |	FROM ${productCatalogTransactions} as pc
             |	LATERAL VIEW outer explode(pc.attributes) completeAttrib AS attribs
             |  WHERE country_code = 'USA'
             |  AND lower(pc.line_of_business) = lower('LX')
             |),
             |product_catalog as (
             |select
             |  pc.supplier_id as pc_supplier_id,
             |  pc.state as pc_state,
             |  pc.city as pc_city,
             |  pc.postal_code as pc_postal_code,
             |  pc.street_address1 as pc_street_address1,
             |  pc.street_address2 as pc_street_address2,
             |  pc.county as pc_county,
             |  pc.country_code as pc_country_code,
             |  pc.cleansed_country_code as pc_cleansed_country_code,
             |  pc.cleansed_state as pc_cleansed_state,
             |  pc.cleansed_city as pc_cleansed_city,
             |  pc.cleansed_county as pc_cleansed_county,
             |  pc.cleansed_postal_code as pc_cleansed_postal_code,
             |  pc.cleansed_street_address1 as pc_cleansed_street_address1,
             |  pc.cleansed_street_address2 as pc_cleansed_street_address2,
             |  pc.latitude as pc_latitude,
             |  pc.longitude as pc_longitude,
             |  pc.cleansed_latitude as pc_cleansed_latitude,
             |  pc.cleansed_longitude as pc_cleansed_longitude,
             |  tax_area_id.value as pc_tax_area_id,
             |  pc.${SQLColumnHelper.EVENT_HEADER_PUBLISHED_TIMESTAMP} AS ${SQLColumnHelper.PC_PUBLISHED_TIMESTAMP}
             |  FROM $productCatalogTransactions as pc
             |  LEFT JOIN attributes_vw as tax_area_id
             |    ON tax_area_id.supplier_id = pc.supplier_id
             |    AND lower(tax_area_id.name) = lower('geocode')
             |  WHERE country_code = 'USA'
             |  AND lower(pc.line_of_business) = lower('LX')
             |),
             |latest AS (
             |  SELECT
             |    ${SQLColumnHelper.SUPPLIER_ID},
             |    MAX(${SQLColumnHelper.EVENT_HEADER_PUBLISHED_TIMESTAMP}) AS ${SQLColumnHelper.PC_PUBLISHED_TIMESTAMP}
             |  FROM $productCatalogTransactions
             |  WHERE
             |    (LOWER( line_of_business ) = LOWER( 'LX' )
             |    OR LOWER( line_of_business ) = LOWER( CONCAT('HOTWIRE','LX') ))
             |  GROUP BY ${SQLColumnHelper.SUPPLIER_ID}
             |)
             |SELECT product_catalog.*
             |FROM product_catalog
             |INNER JOIN latest
             |  ON product_catalog.${SQLColumnHelper.PC_SUPPLIER_ID} = latest.${SQLColumnHelper.SUPPLIER_ID}
             |  AND product_catalog.${SQLColumnHelper.PC_PUBLISHED_TIMESTAMP} = latest.${SQLColumnHelper.PC_PUBLISHED_TIMESTAMP}
             |""".stripMargin
    }

    def getStacAttributesReplacementString(stacAttributes: Array[String]): String = {

        var replacementString = ""

        if (stacAttributes.length > 0) {
            var formattedAttribute = ""
            for (attribute <- stacAttributes) {

                formattedAttribute = attribute.toLowerCase().replace(' ', '_')
                if (formattedAttribute.equalsIgnoreCase("unit_count")) {
                    replacementString += ",\"" + formattedAttribute + "\",  CASE WHEN "
                    replacementString += formattedAttribute + " RLIKE '^(([0-9]*))$' THEN " + formattedAttribute + " ELSE '' END "
                } else {
                    replacementString += ",\"" + formattedAttribute + "\", " + formattedAttribute + " "
                }

            }
        }

        replacementString
    }

    def getStacAttributes(stacAttributes: Array[String], roomLevelAttr: Set[String]) = {
        var selectPropertyLevelAttributes = ""
        var selectRoomLevelAttributes = ""
        var selectAllAttributes = ""

        var formattedAttribute = ""

        for (attribute <- stacAttributes) {
            formattedAttribute = attribute.toLowerCase().replace(' ', '_')
            if (roomLevelAttr.contains(attribute)) {
                selectRoomLevelAttributes +=
                    raw"""
                         | ,${formattedAttribute}""".stripMargin
            }
            else {
                selectPropertyLevelAttributes +=
                    raw"""
                         | ,${formattedAttribute}""".stripMargin
            }
            selectAllAttributes +=
                raw"""
                     | ,${formattedAttribute}""".stripMargin
        }
        (selectPropertyLevelAttributes, selectRoomLevelAttributes, selectAllAttributes)
    }

    def getTransWithTaxProfileAttributeColumns(spark: SparkSession, qualifiedTransactionsView: String): DataFrame = {
        spark.sql(
            s"""
              |with tax_profile as (
              |  SELECT
              |  distinct
              |  ${SQLColumnHelper.SUPPLIER_DIM}.${SQLColumnHelper.TAX_PROFILE_SUPPLIER_ID},
              |  ${SQLColumnHelper.TAX_PROFILE_STATE},
              |  ${SQLColumnHelper.TAX_PROFILE_COUNTRY},
              |  max(${SQLColumnHelper.TAX_DEFINED_ATTRIBUTES_ACCURACY}) as ${SQLColumnHelper.TAX_DEFINED_ATTRIBUTES_ACCURACY},
              |  max(${SQLColumnHelper.TAX_DEFINED_ATTRIBUTES_FILING}) as ${SQLColumnHelper.TAX_DEFINED_ATTRIBUTES_FILING},
              |  max(${SQLColumnHelper.SUPPLIER_ATTRIBUTES_ACCURACY}) as ${SQLColumnHelper.SUPPLIER_ATTRIBUTES_ACCURACY},
              |  max(${SQLColumnHelper.SUPPLIER_ATTRIBUTES_FILING}) as ${SQLColumnHelper.SUPPLIER_ATTRIBUTES_FILING}
              |  FROM $unitedTaxProfile
              |  GROUP BY ${SQLColumnHelper.TAX_PROFILE_SUPPLIER_ID}, ${SQLColumnHelper.TAX_PROFILE_STATE}, ${SQLColumnHelper.TAX_PROFILE_COUNTRY}
              |) SELECT
              |  distinct
              |  qt.*,
              |  ${SQLColumnHelper.TAX_DEFINED_ATTRIBUTES_ACCURACY},
              |  ${SQLColumnHelper.TAX_DEFINED_ATTRIBUTES_FILING},
              |  ${SQLColumnHelper.SUPPLIER_ATTRIBUTES_ACCURACY},
              |  ${SQLColumnHelper.SUPPLIER_ATTRIBUTES_FILING}
              |FROM $qualifiedTransactionsView AS qt
              |LEFT JOIN tax_profile
              |  ON qt.${SQLColumnHelper.PROPERTY_ID} = tax_profile.${SQLColumnHelper.TAX_PROFILE_SUPPLIER_ID}
              |  AND qt.${SQLColumnHelper.PROPERTY_COUNTRY_CODE} = tax_profile.${SQLColumnHelper.TAX_PROFILE_COUNTRY}
              |  AND qt.${SQLColumnHelper.STATE} = tax_profile.${SQLColumnHelper.TAX_PROFILE_STATE}
              |""".stripMargin
        )
    }

    def selectLocalAmountsLodging(qualifiedTransactionDf: DataFrame): DataFrame = {
        qualifiedTransactionDf.select(
            col(SQLColumnHelper.BOOKING_ITEM_ID),
            col(SQLColumnHelper.TRANSACTION_TYPE_KEY),
            col(SQLColumnHelper.SOURCE_SYSTEM_ID),
            col(SQLColumnHelper.BOOKING_ID),
            col(SQLColumnHelper.STAY_DATE),
            col(SQLColumnHelper.BOOKING_EVENT_DATETIME),
            col(SQLColumnHelper.COST_CURRENCY_CODE),
            col(SQLColumnHelper.BASE_PRICE_AMT_LOCAL).alias(SQLColumnHelper.BASE_PRICE_AMOUNT_LOCAL),
            col(SQLColumnHelper.OTHR_PRICE_ADJ_AMT_LOCAL).alias(SQLColumnHelper.OTHER_PRICE_ADJUSTMENT_AMOUNT_LOCAL),
            col(SQLColumnHelper.GROSS_BKG_AMT_LOCAL).alias(SQLColumnHelper.GROSS_BOOKING_AMOUNT_LOCAL),
            col(SQLColumnHelper.AGENT_ASSISTED_PURCHASE_FEE_AMOUNT_LOCAL),
            col(SQLColumnHelper.CNCL_CHG_FEE_PRICE_AMT_LOCAL).alias(SQLColumnHelper.CANCEL_CHANGE_FEE_PRICE_AMOUNT_LOCAL),
            col(SQLColumnHelper.CNCL_PNLTY_WAIVR_PRICE_ADJ_AMT_LOCAL).alias(SQLColumnHelper.CANCEL_PENALTY_WAIVER_PRICE_ADJUSTMENT_AMOUNT_LOCAL),
            col(SQLColumnHelper.COUPN_PRICE_AMT_LOCAL).alias(SQLColumnHelper.COUPON_PRICE_AMOUNT_LOCAL),
            col(SQLColumnHelper.EMP_DISC_PRICE_ADJ_AMT_LOCAL).alias(SQLColumnHelper.EMPLOYEE_DISCOUNT_PRICE_ADJUSTMENT_AMOUNT_LOCAL),
            col(SQLColumnHelper.EXPE_GDWLL_PRICE_ADJ_AMT_LOCAL).alias(SQLColumnHelper.EXPEDIA_GOODWILL_PRICE_ADJUSTMENT_AMOUNT_LOCAL),
            col(SQLColumnHelper.EXPE_PNLTY_PRICE_ADJ_AMT_LOCAL).alias(SQLColumnHelper.EXPEDIA_PENALTY_PRICE_ADJUSTMENT_AMOUNT_LOCAL),
            col(SQLColumnHelper.GDWLL_PRICE_ADJ_AMT_LOCAL).alias(SQLColumnHelper.GOODWILL_PRICE_ADJUSTMENT_AMOUNT_LOCAL),
            col(SQLColumnHelper.GENRIC_COUPN_PRICE_AMT_LOCAL).alias(SQLColumnHelper.GENERIC_COUPON_PRICE_AMOUNT_LOCAL),
            col(SQLColumnHelper.LOYLTY_POINT_PRICE_ADJ_AMT_LOCAL).alias(SQLColumnHelper.LOYALTY_POINT_PRICE_ADJUSTMENT_AMOUNT_LOCAL),
            col(SQLColumnHelper.OTHER_FEE_PRICE_AMOUNT_LOCAL),
            col(SQLColumnHelper.PNLTY_PRICE_ADJ_AMT_LOCAL).alias(SQLColumnHelper.PENALTY_PRICE_ADJUSTMENT_AMOUNT_LOCAL),
            col(SQLColumnHelper.REBATE_PRICE_AMT_LOCAL).alias(SQLColumnHelper.REBATE_PRICE_AMOUNT_LOCAL),
            col(SQLColumnHelper.REFUND_PRICE_ADJ_AMT_LOCAL).alias(SQLColumnHelper.REFUND_PRICE_ADJUSTMENT_AMOUNT_LOCAL),
            col(SQLColumnHelper.SVC_CHRG_PRICE_AMT_LOCAL).alias(SQLColumnHelper.SERVICE_CHARGE_PRICE_AMOUNT_LOCAL),
            col(SQLColumnHelper.SVC_FEE_PRICE_AMT_LOCAL).alias(SQLColumnHelper.SERVICE_FEE_PRICE_AMOUNT_LOCAL),
            col(SQLColumnHelper.SUPPL_RECON_PRICE_ADJ_AMT_LOCAL).alias(SQLColumnHelper.SUPPLIER_RECONCILIATION_PRICE_ADJUSTMENT_AMOUNT_LOCAL),
            col(SQLColumnHelper.SUPPL_RECON_COST_ADJ_AMT_LOCAL).alias(SQLColumnHelper.SUPPLIER_RECONCILIATION_COST_ADJUSTMENT_LOCAL),
            col(SQLColumnHelper.TOTL_TAX_PRICE_AMT_LOCAL).alias(SQLColumnHelper.TOTAL_TAX_PRICE_AMOUNT_LOCAL),
            col(SQLColumnHelper.TCM_PRICE_ADJ_AMT_LOCAL).alias(SQLColumnHelper.TCM_PRICE_ADJUSTMENT_AMOUNT_LOCAL),
            col(SQLColumnHelper.TOTL_PRICE_ADJ_AMT_LOCAL).alias(SQLColumnHelper.TOTAL_PRICE_ADJUSTMENT_AMOUNT_LOCAL),
            col(SQLColumnHelper.BASE_COST_AMT_LOCAL).alias(SQLColumnHelper.BASE_COST_AMOUNT_LOCAL),
            col(SQLColumnHelper.TOTL_COST_AMT_LOCAL).alias(SQLColumnHelper.TOTAL_COST_AMOUNT_LOCAL),
            col(SQLColumnHelper.TOTL_FEE_PRICE_AMT_LOCAL).alias(SQLColumnHelper.TOTAL_FEE_PRICE_AMOUNT_LOCAL),
            col(SQLColumnHelper.TOTL_COST_ADJ_AMT_LOCAL).alias(SQLColumnHelper.TOTAL_COST_ADJUSTMENT_AMOUNT_LOCAL),
            col(SQLColumnHelper.SUPPL_COST_ADJ_AMT_LOCAL).alias(SQLColumnHelper.SUPPLIER_COST_ADJUSTMENT_AMOUNT_LOCAL),
            col(SQLColumnHelper.ECA_COST_ADJ_AMT_LOCAL).alias(SQLColumnHelper.ECA_COST_ADJUSTMENT_AMOUNT_LOCAL),
            col(SQLColumnHelper.OTHR_COST_ADJ_AMT_LOCAL).alias(SQLColumnHelper.OTHER_COST_ADJUSTMENT_AMOUNT_LOCAL),
            col(SQLColumnHelper.VAR_MARGN_COST_ADJ_LOCAL).alias(SQLColumnHelper.VARIABLE_MARGIN_COST_ADJUSTMENT_AMOUNT_LOCAL),
            col(SQLColumnHelper.TOTL_FEE_COST_AMT_LOCAL).alias(SQLColumnHelper.TOTAL_FEE_COST_AMOUNT_LOCAL),
            col(SQLColumnHelper.SVC_CHRG_COST_AMT_LOCAL).alias(SQLColumnHelper.SERVICE_CHARGE_COST_AMOUNT_LOCAL),
            col(SQLColumnHelper.OTHR_FEE_COST_AMT_LOCAL).alias(SQLColumnHelper.OTHER_FEE_COST_AMOUNT_LOCAL),
            col(SQLColumnHelper.ECA_FEE_COST_AMT_LOCAL).alias(SQLColumnHelper.ECA_FEE_COST_AMOUNT_LOCAL),
            col(SQLColumnHelper.TOTL_TAX_COST_AMT_LOCAL).alias(SQLColumnHelper.TOTAL_TAX_COST_AMOUNT_LOCAL),
            col(SQLColumnHelper.VAR_MARGN_CREDT_LOCAL).alias(SQLColumnHelper.VARIABLE_MARGIN_CREDIT_LOCAL),
            col(SQLColumnHelper.EXCH_RATE_STAY_DATE).cast(DataTypes.createDecimalType(24, 15)).alias(SQLColumnHelper.EXCHANGE_RATE_STAY_DATE),
            col(SQLColumnHelper.EXCH_RATE_STAY_DATE_COST).cast(DataTypes.createDecimalType(24, 15)).alias(SQLColumnHelper.EXCHANGE_RATE_STAY_DATE_COST),
            col(SQLColumnHelper.LODG_ROOM_TYPE_ID),
            col(SQLColumnHelper.TAX_DUE_AMOUNT).cast(DataTypes.createDecimalType(18, 2)))
    }

    def selectLocalAmountsCar(qualifiedTransactionDf: DataFrame): DataFrame = {
        qualifiedTransactionDf.select(
                col(SQLColumnHelper.BOOKING_ITEM_ID),
                col(SQLColumnHelper.TRANSACTION_TYPE_KEY),
                col(SQLColumnHelper.SOURCE_SYSTEM_ID),
                col(SQLColumnHelper.BOOKING_ID),
                col(SQLColumnHelper.STAY_DATE),
                col(SQLColumnHelper.BOOKING_EVENT_DATETIME),
                col(SQLColumnHelper.COST_CURRENCY_CODE),
                col(SQLColumnHelper.BASE_PRICE_AMT_LOCAL).alias(SQLColumnHelper.BASE_PRICE_AMOUNT_LOCAL),
                col(SQLColumnHelper.OTHR_PRICE_ADJ_AMT_LOCAL).alias(SQLColumnHelper.OTHER_PRICE_ADJUSTMENT_AMOUNT_LOCAL),
                col(SQLColumnHelper.TOTL_PRICE_ADJ_AMT_LOCAL).alias(SQLColumnHelper.TOTAL_PRICE_ADJUSTMENT_AMOUNT_LOCAL),
                col(SQLColumnHelper.TOTL_FEE_PRICE_AMT_LOCAL).alias(SQLColumnHelper.TOTAL_FEE_PRICE_AMOUNT_LOCAL),
                col(SQLColumnHelper.TOTL_TAX_PRICE_AMT_LOCAL).alias(SQLColumnHelper.TOTAL_TAX_PRICE_AMOUNT_LOCAL),
                col(SQLColumnHelper.CNCL_CHG_FEE_PRICE_AMT_LOCAL).alias(SQLColumnHelper.CANCEL_CHANGE_FEE_PRICE_AMOUNT_LOCAL),
                col(SQLColumnHelper.GROSS_BKG_AMT_LOCAL).alias(SQLColumnHelper.GROSS_BOOKING_AMOUNT_LOCAL),
                col(SQLColumnHelper.COUPN_PRICE_AMT_LOCAL).alias(SQLColumnHelper.COUPON_PRICE_AMOUNT_LOCAL),
                col(SQLColumnHelper.OTHER_FEE_PRICE_AMOUNT_LOCAL),
                col(SQLColumnHelper.AGENT_ASSISTED_PURCHASE_FEE_AMOUNT_LOCAL),
                col(SQLColumnHelper.BASE_COST_AMT_LOCAL).alias(SQLColumnHelper.BASE_COST_AMOUNT_LOCAL),
                col(SQLColumnHelper.TOTL_COST_ADJ_AMT_LOCAL).alias(SQLColumnHelper.TOTAL_COST_ADJUSTMENT_AMOUNT_LOCAL),
                col(SQLColumnHelper.TOTL_FEE_COST_AMT_LOCAL).alias(SQLColumnHelper.TOTAL_FEE_COST_AMOUNT_LOCAL),
                col(SQLColumnHelper.OTHR_FEE_COST_AMT_LOCAL).alias(SQLColumnHelper.OTHER_FEE_COST_AMOUNT_LOCAL),
                col(SQLColumnHelper.TOTL_TAX_COST_AMT_LOCAL).alias(SQLColumnHelper.TOTAL_TAX_COST_AMOUNT_LOCAL),
                col(SQLColumnHelper.TOTL_COST_AMT_LOCAL).alias(SQLColumnHelper.TOTAL_COST_AMOUNT_LOCAL),
                col(SQLColumnHelper.EXCH_RATE_STAY_DATE).cast(DataTypes.createDecimalType(24, 15)).alias(SQLColumnHelper.EXCHANGE_RATE_STAY_DATE),
                col(SQLColumnHelper.EXCH_RATE_STAY_DATE_COST).cast(DataTypes.createDecimalType(24, 15)).alias(SQLColumnHelper.EXCHANGE_RATE_STAY_DATE_COST),
                col(SQLColumnHelper.TAX_DUE_AMOUNT).cast(DataTypes.createDecimalType(18, 2)))
            .withColumn(SQLColumnHelper.SERVICE_FEE_PRICE_AMOUNT_LOCAL, lit(BigDecimal(0)))
            .withColumn(SQLColumnHelper.SERVICE_CHARGE_PRICE_AMOUNT_LOCAL, lit(BigDecimal(0)))
            .withColumn(SQLColumnHelper.EXPEDIA_GOODWILL_PRICE_ADJUSTMENT_AMOUNT_LOCAL, lit(BigDecimal(0)))
            .withColumn(SQLColumnHelper.PENALTY_PRICE_ADJUSTMENT_AMOUNT_LOCAL, lit(BigDecimal(0)))
            .withColumn(SQLColumnHelper.EXPEDIA_PENALTY_PRICE_ADJUSTMENT_AMOUNT_LOCAL, lit(BigDecimal(0)))
            .withColumn(SQLColumnHelper.GOODWILL_PRICE_ADJUSTMENT_AMOUNT_LOCAL, lit(BigDecimal(0)))
            .withColumn(SQLColumnHelper.GENERIC_COUPON_PRICE_AMOUNT_LOCAL, lit(BigDecimal(0)))
            .withColumn(SQLColumnHelper.REFUND_PRICE_ADJUSTMENT_AMOUNT_LOCAL, lit(BigDecimal(0)))
            .withColumn(SQLColumnHelper.REBATE_PRICE_AMOUNT_LOCAL, lit(BigDecimal(0)))
            .withColumn(SQLColumnHelper.TCM_PRICE_ADJUSTMENT_AMOUNT_LOCAL, lit(BigDecimal(0)))
            .withColumn(SQLColumnHelper.CANCEL_PENALTY_WAIVER_PRICE_ADJUSTMENT_AMOUNT_LOCAL, lit(BigDecimal(0)))
            .withColumn(SQLColumnHelper.LOYALTY_POINT_PRICE_ADJUSTMENT_AMOUNT_LOCAL, lit(BigDecimal(0)))
            .withColumn(SQLColumnHelper.EMPLOYEE_DISCOUNT_PRICE_ADJUSTMENT_AMOUNT_LOCAL, lit(BigDecimal(0)))
            .withColumn(SQLColumnHelper.SUPPLIER_RECONCILIATION_PRICE_ADJUSTMENT_AMOUNT_LOCAL, lit(BigDecimal(0)))
            .withColumn(SQLColumnHelper.OTHER_COST_ADJUSTMENT_AMOUNT_LOCAL, lit(BigDecimal(0)))
            .withColumn(SQLColumnHelper.SUPPLIER_COST_ADJUSTMENT_AMOUNT_LOCAL, lit(BigDecimal(0)))
            .withColumn(SQLColumnHelper.ECA_FEE_COST_AMOUNT_LOCAL, lit(BigDecimal(0)))
            .withColumn(SQLColumnHelper.VARIABLE_MARGIN_CREDIT_LOCAL, lit(BigDecimal(0)))
            .withColumn(SQLColumnHelper.SERVICE_CHARGE_COST_AMOUNT_LOCAL, lit(BigDecimal(0)))
            .withColumn(SQLColumnHelper.SUPPLIER_RECONCILIATION_COST_ADJUSTMENT_LOCAL, lit(BigDecimal(0)))
            .withColumn(SQLColumnHelper.VARIABLE_MARGIN_COST_ADJUSTMENT_AMOUNT_LOCAL, lit(BigDecimal(0)))
            .withColumn(SQLColumnHelper.ECA_COST_ADJUSTMENT_AMOUNT_LOCAL, lit(BigDecimal(0)))
    }

    def selectLocalAmountsLX(qualifiedTransactionDf: DataFrame): DataFrame = {
        qualifiedTransactionDf.select(
                col(SQLColumnHelper.BOOKING_ITEM_ID),
                col(SQLColumnHelper.TRANSACTION_TYPE_KEY),
                col(SQLColumnHelper.SOURCE_SYSTEM_ID),
                col(SQLColumnHelper.BOOKING_ID),
                col(SQLColumnHelper.STAY_DATE),
                col(SQLColumnHelper.BOOKING_EVENT_DATETIME),
                col(SQLColumnHelper.COST_CURRENCY_CODE),
                col(SQLColumnHelper.BASE_PRICE_AMT_LOCAL).alias(SQLColumnHelper.BASE_PRICE_AMOUNT_LOCAL),
                col(SQLColumnHelper.OTHR_PRICE_ADJ_AMT_LOCAL).alias(SQLColumnHelper.OTHER_PRICE_ADJUSTMENT_AMOUNT_LOCAL),
                col(SQLColumnHelper.TOTL_PRICE_ADJ_AMT_LOCAL).alias(SQLColumnHelper.TOTAL_PRICE_ADJUSTMENT_AMOUNT_LOCAL),
                col(SQLColumnHelper.TOTL_FEE_PRICE_AMT_LOCAL).alias(SQLColumnHelper.TOTAL_FEE_PRICE_AMOUNT_LOCAL),
                col(SQLColumnHelper.TOTL_TAX_PRICE_AMT_LOCAL).alias(SQLColumnHelper.TOTAL_TAX_PRICE_AMOUNT_LOCAL),
                col(SQLColumnHelper.CNCL_CHG_FEE_PRICE_AMT_LOCAL).alias(SQLColumnHelper.CANCEL_CHANGE_FEE_PRICE_AMOUNT_LOCAL),
                col(SQLColumnHelper.GROSS_BKG_AMT_LOCAL).alias(SQLColumnHelper.GROSS_BOOKING_AMOUNT_LOCAL),
                col(SQLColumnHelper.COUPN_PRICE_AMT_LOCAL).alias(SQLColumnHelper.COUPON_PRICE_AMOUNT_LOCAL),
                col(SQLColumnHelper.OTHER_FEE_PRICE_AMOUNT_LOCAL),
                col(SQLColumnHelper.AGENT_ASSISTED_PURCHASE_FEE_AMOUNT_LOCAL),
                col(SQLColumnHelper.BASE_COST_AMT_LOCAL).alias(SQLColumnHelper.BASE_COST_AMOUNT_LOCAL),
                col(SQLColumnHelper.TOTL_COST_ADJ_AMT_LOCAL).alias(SQLColumnHelper.TOTAL_COST_ADJUSTMENT_AMOUNT_LOCAL),
                col(SQLColumnHelper.TOTL_FEE_COST_AMT_LOCAL).alias(SQLColumnHelper.TOTAL_FEE_COST_AMOUNT_LOCAL),
                col(SQLColumnHelper.OTHR_FEE_COST_AMT_LOCAL).alias(SQLColumnHelper.OTHER_FEE_COST_AMOUNT_LOCAL),
                col(SQLColumnHelper.TOTL_TAX_COST_AMT_LOCAL).alias(SQLColumnHelper.TOTAL_TAX_COST_AMOUNT_LOCAL),
                col(SQLColumnHelper.TOTL_COST_AMT_LOCAL).alias(SQLColumnHelper.TOTAL_COST_AMOUNT_LOCAL),
                col(SQLColumnHelper.EXCH_RATE_STAY_DATE).cast(DataTypes.createDecimalType(24, 15)).alias(SQLColumnHelper.EXCHANGE_RATE_STAY_DATE),
                col(SQLColumnHelper.EXCH_RATE_STAY_DATE_COST).cast(DataTypes.createDecimalType(24, 15)).alias(SQLColumnHelper.EXCHANGE_RATE_STAY_DATE_COST),
                col(SQLColumnHelper.TAX_DUE_AMOUNT).cast(DataTypes.createDecimalType(18, 2)))
            .withColumn(SQLColumnHelper.SERVICE_FEE_PRICE_AMOUNT_LOCAL, lit(BigDecimal(0)))
            .withColumn(SQLColumnHelper.SERVICE_CHARGE_PRICE_AMOUNT_LOCAL, lit(BigDecimal(0)))
            .withColumn(SQLColumnHelper.EXPEDIA_GOODWILL_PRICE_ADJUSTMENT_AMOUNT_LOCAL, lit(BigDecimal(0)))
            .withColumn(SQLColumnHelper.PENALTY_PRICE_ADJUSTMENT_AMOUNT_LOCAL, lit(BigDecimal(0)))
            .withColumn(SQLColumnHelper.EXPEDIA_PENALTY_PRICE_ADJUSTMENT_AMOUNT_LOCAL, lit(BigDecimal(0)))
            .withColumn(SQLColumnHelper.GOODWILL_PRICE_ADJUSTMENT_AMOUNT_LOCAL, lit(BigDecimal(0)))
            .withColumn(SQLColumnHelper.GENERIC_COUPON_PRICE_AMOUNT_LOCAL, lit(BigDecimal(0)))
            .withColumn(SQLColumnHelper.REFUND_PRICE_ADJUSTMENT_AMOUNT_LOCAL, lit(BigDecimal(0)))
            .withColumn(SQLColumnHelper.REBATE_PRICE_AMOUNT_LOCAL, lit(BigDecimal(0)))
            .withColumn(SQLColumnHelper.TCM_PRICE_ADJUSTMENT_AMOUNT_LOCAL, lit(BigDecimal(0)))
            .withColumn(SQLColumnHelper.CANCEL_PENALTY_WAIVER_PRICE_ADJUSTMENT_AMOUNT_LOCAL, lit(BigDecimal(0)))
            .withColumn(SQLColumnHelper.LOYALTY_POINT_PRICE_ADJUSTMENT_AMOUNT_LOCAL, lit(BigDecimal(0)))
            .withColumn(SQLColumnHelper.EMPLOYEE_DISCOUNT_PRICE_ADJUSTMENT_AMOUNT_LOCAL, lit(BigDecimal(0)))
            .withColumn(SQLColumnHelper.SUPPLIER_RECONCILIATION_PRICE_ADJUSTMENT_AMOUNT_LOCAL, lit(BigDecimal(0)))
            .withColumn(SQLColumnHelper.OTHER_COST_ADJUSTMENT_AMOUNT_LOCAL, lit(BigDecimal(0)))
            .withColumn(SQLColumnHelper.SUPPLIER_COST_ADJUSTMENT_AMOUNT_LOCAL, lit(BigDecimal(0)))
            .withColumn(SQLColumnHelper.ECA_FEE_COST_AMOUNT_LOCAL, lit(BigDecimal(0)))
            .withColumn(SQLColumnHelper.VARIABLE_MARGIN_CREDIT_LOCAL, lit(BigDecimal(0)))
            .withColumn(SQLColumnHelper.SERVICE_CHARGE_COST_AMOUNT_LOCAL, lit(BigDecimal(0)))
            .withColumn(SQLColumnHelper.SUPPLIER_RECONCILIATION_COST_ADJUSTMENT_LOCAL, lit(BigDecimal(0)))
            .withColumn(SQLColumnHelper.VARIABLE_MARGIN_COST_ADJUSTMENT_AMOUNT_LOCAL, lit(BigDecimal(0)))
            .withColumn(SQLColumnHelper.ECA_COST_ADJUSTMENT_AMOUNT_LOCAL, lit(BigDecimal(0)))
    }

    def selectLocalAmountsAdvertising(qualifiedTransactionDf: DataFrame): DataFrame = {
        qualifiedTransactionDf.select(
                col(SQLColumnHelper.BOOKING_ITEM_ID),
                col(SQLColumnHelper.TRANSACTION_TYPE_KEY),
                col(SQLColumnHelper.SOURCE_SYSTEM_ID),
                col(SQLColumnHelper.BOOKING_ID),
                col(SQLColumnHelper.STAY_DATE),
                col(SQLColumnHelper.BOOKING_EVENT_DATETIME),
                col(SQLColumnHelper.COST_CURRENCY_CODE),
                col(SQLColumnHelper.BASE_PRICE_AMT_LOCAL).alias(SQLColumnHelper.BASE_PRICE_AMOUNT_LOCAL),
                col(SQLColumnHelper.TOTL_TAX_PRICE_AMT_LOCAL).alias(SQLColumnHelper.TOTAL_TAX_PRICE_AMOUNT_LOCAL),
                col(SQLColumnHelper.GROSS_BKG_AMT_LOCAL).alias(SQLColumnHelper.GROSS_BOOKING_AMOUNT_LOCAL),
                col(SQLColumnHelper.EXCH_RATE_STAY_DATE).cast(DataTypes.createDecimalType(24, 15)).alias(SQLColumnHelper.EXCHANGE_RATE_STAY_DATE),
                col(SQLColumnHelper.EXCH_RATE_STAY_DATE_COST).cast(DataTypes.createDecimalType(24, 15)).alias(SQLColumnHelper.EXCHANGE_RATE_STAY_DATE_COST),
                col(SQLColumnHelper.TAX_DUE_AMOUNT).cast(DataTypes.createDecimalType(18, 2)))
            .withColumn(SQLColumnHelper.OTHER_PRICE_ADJUSTMENT_AMOUNT_LOCAL, lit(BigDecimal(0)))
            .withColumn(SQLColumnHelper.TOTAL_PRICE_ADJUSTMENT_AMOUNT_LOCAL, lit(BigDecimal(0)))
            .withColumn(SQLColumnHelper.TOTAL_FEE_PRICE_AMOUNT_LOCAL, lit(BigDecimal(0)))
            .withColumn(SQLColumnHelper.COUPON_PRICE_AMOUNT_LOCAL, lit(BigDecimal(0)))
            .withColumn(SQLColumnHelper.OTHER_FEE_PRICE_AMOUNT_LOCAL, lit(BigDecimal(0)))
            .withColumn(SQLColumnHelper.AGENT_ASSISTED_PURCHASE_FEE_AMOUNT_LOCAL, lit(BigDecimal(0)))
            .withColumn(SQLColumnHelper.BASE_COST_AMOUNT_LOCAL, lit(BigDecimal(0)))
            .withColumn(SQLColumnHelper.TOTAL_COST_ADJUSTMENT_AMOUNT_LOCAL, lit(BigDecimal(0)))
            .withColumn(SQLColumnHelper.TOTAL_FEE_COST_AMOUNT_LOCAL, lit(BigDecimal(0)))
            .withColumn(SQLColumnHelper.OTHER_FEE_COST_AMOUNT_LOCAL, lit(BigDecimal(0)))
            .withColumn(SQLColumnHelper.TOTAL_TAX_COST_AMOUNT_LOCAL, lit(BigDecimal(0)))
            .withColumn(SQLColumnHelper.TOTAL_COST_AMOUNT_LOCAL, lit(BigDecimal(0)))
            .withColumn(SQLColumnHelper.CANCEL_CHANGE_FEE_PRICE_AMOUNT_LOCAL, lit(BigDecimal(0)))
            .withColumn(SQLColumnHelper.SERVICE_FEE_PRICE_AMOUNT_LOCAL, lit(BigDecimal(0)))
            .withColumn(SQLColumnHelper.SERVICE_CHARGE_PRICE_AMOUNT_LOCAL, lit(BigDecimal(0)))
            .withColumn(SQLColumnHelper.EXPEDIA_GOODWILL_PRICE_ADJUSTMENT_AMOUNT_LOCAL, lit(BigDecimal(0)))
            .withColumn(SQLColumnHelper.PENALTY_PRICE_ADJUSTMENT_AMOUNT_LOCAL, lit(BigDecimal(0)))
            .withColumn(SQLColumnHelper.EXPEDIA_PENALTY_PRICE_ADJUSTMENT_AMOUNT_LOCAL, lit(BigDecimal(0)))
            .withColumn(SQLColumnHelper.GOODWILL_PRICE_ADJUSTMENT_AMOUNT_LOCAL, lit(BigDecimal(0)))
            .withColumn(SQLColumnHelper.GENERIC_COUPON_PRICE_AMOUNT_LOCAL, lit(BigDecimal(0)))
            .withColumn(SQLColumnHelper.REFUND_PRICE_ADJUSTMENT_AMOUNT_LOCAL, lit(BigDecimal(0)))
            .withColumn(SQLColumnHelper.REBATE_PRICE_AMOUNT_LOCAL, lit(BigDecimal(0)))
            .withColumn(SQLColumnHelper.TCM_PRICE_ADJUSTMENT_AMOUNT_LOCAL, lit(BigDecimal(0)))
            .withColumn(SQLColumnHelper.CANCEL_PENALTY_WAIVER_PRICE_ADJUSTMENT_AMOUNT_LOCAL, lit(BigDecimal(0)))
            .withColumn(SQLColumnHelper.LOYALTY_POINT_PRICE_ADJUSTMENT_AMOUNT_LOCAL, lit(BigDecimal(0)))
            .withColumn(SQLColumnHelper.EMPLOYEE_DISCOUNT_PRICE_ADJUSTMENT_AMOUNT_LOCAL, lit(BigDecimal(0)))
            .withColumn(SQLColumnHelper.SUPPLIER_RECONCILIATION_PRICE_ADJUSTMENT_AMOUNT_LOCAL, lit(BigDecimal(0)))
            .withColumn(SQLColumnHelper.OTHER_COST_ADJUSTMENT_AMOUNT_LOCAL, lit(BigDecimal(0)))
            .withColumn(SQLColumnHelper.SUPPLIER_COST_ADJUSTMENT_AMOUNT_LOCAL, lit(BigDecimal(0)))
            .withColumn(SQLColumnHelper.ECA_FEE_COST_AMOUNT_LOCAL, lit(BigDecimal(0)))
            .withColumn(SQLColumnHelper.VARIABLE_MARGIN_CREDIT_LOCAL, lit(BigDecimal(0)))
            .withColumn(SQLColumnHelper.SERVICE_CHARGE_COST_AMOUNT_LOCAL, lit(BigDecimal(0)))
            .withColumn(SQLColumnHelper.SUPPLIER_RECONCILIATION_COST_ADJUSTMENT_LOCAL, lit(BigDecimal(0)))
            .withColumn(SQLColumnHelper.VARIABLE_MARGIN_COST_ADJUSTMENT_AMOUNT_LOCAL, lit(BigDecimal(0)))
            .withColumn(SQLColumnHelper.ECA_COST_ADJUSTMENT_AMOUNT_LOCAL, lit(BigDecimal(0)))
    }

    def get_apiary_datalake_view_data(spark: SparkSession): DataFrame = {
        spark.sql("select * from temp_egdp_apiary_datalake_tbl_view ap " +
            "left join temp_pos_dim_tbl_view pos ON pos.pos_id = ap.eapid")
    }

    def fetch_bkg_lx_apiary_datalake_view_data(spark: SparkSession): DataFrame = {
        spark.sql("select * from temp_stg_bkg_fact_lx_view fact " +
            "left join temp_apiary_datalake_pos_view datalake " +
            " ON CAST(fact.bkg_itm_id AS string) = datalake.legacy_voucher")
    }

    def get_df_lx_view_data(spark: SparkSession): DataFrame = {
        spark.sql(
            raw""" SELECT
                 | ${SQLColumnHelperBookingTransactionsLx.LX_STAGE_BOOKING_READ_QUERY}
                 |  from temp_df_lx_view""".stripMargin)
    }

    def get_post_use_lx_join_view_data(spark: SparkSession): DataFrame = {
        spark.sql("select * from temp_post_use_fact_lx_view fact " +
            "left join temp_apiary_datalake_pos_view datalake " +
            " ON CAST(fact.bkg_itm_id AS string) = datalake.legacy_voucher")
    }

    def get_lx_stage_booking_post_use_data(spark: SparkSession): DataFrame = {
        spark.sql(
            raw""" SELECT
                 | ${SQLColumnHelperPostUseTransactionsLx.LX_STAGE_BOOKING_POST_USE_READ_QUERY}
                 |  from temp_df_lx_view""".stripMargin)
    }

    def insert_lx_stage_booking_data(spark: SparkSession): DataFrame = {
        spark.sql(
            raw""" ${SQLColumnHelperBookingTransactionsLx.LX_STAGE_BOOKING_INSERT_STATEMENT}
                 | SELECT ${SQLColumnHelperBookingTransactionsLx.LX_STAGE_BOOKING_INSERT_QUERY}
                 |  from temp_df_updated_run_id_struct sb LEFT JOIN temp_df_dummy_booking_transaction dbt
                 |            on sb.product_line_name = dbt.pl_dummy""".stripMargin)
    }

    def get_lx_post_use_purchase_view_data(spark: SparkSession): DataFrame = {
        spark.sql(
            raw""" SELECT
                 | ${SQLColumnHelperPostUseTransactionsLx.LX_PURCHASE_BOOKING_POST_USE_READ_QUERY}
                 |  from temp_post_use_purchase_fact_lx_view""".stripMargin)
    }

    def get_lx_stg_bkg_join_view_data(spark: SparkSession): DataFrame = {
        spark.sql("select * from temp_stg_bkg_backfill_fact_lx_view fact " +
            "left join temp_apiary_datalake_pos_view datalake " +
            " ON CAST(fact.bkg_itm_id AS string) = datalake.legacy_voucher")
    }

    def get_lx_stg_bkg_backfill_data(spark: SparkSession): DataFrame = {
        spark.sql(
            raw""" SELECT
                 | ${SQLColumnHelperBookingTransactionsBackfillLx.LX_STAGE_BOOKING_BACKFILL_READ_QUERY}
                 |  from temp_df_lx_view""".stripMargin)
    }

    def get_car_stg_bkg_data(spark: SparkSession): DataFrame = {
        spark.sql(
            raw""" SELECT
                 | ${SQLColumnHelperBookingTransactionsCar.Car_STAGE_BOOKING_READ_QUERY}
                 |  from temp_stg_bkg_fact_car_view""".stripMargin)
    }

    def insert_post_use_lx_data(spark: SparkSession) = {
        System.out.println("Insert query debug check 4 Start")
        val tmp = spark.sql(
            raw"""
                 | ${SQLColumnHelperPostUseTransactionsLx.LX_POST_USE_INSERT_STATEMENT}
                 | SELECT ${SQLColumnHelperPostUseTransactionsLx.LX_POST_USE_INSERT_QUERY}
                 | FROM temp_df_post_use_stage_updated_run_id_struct sb
                 | LEFT JOIN temp_post_use_purchase_lx_view pb
                 | ON ${SQLColumnHelperPostUseTransactionsLx.LX_POST_USE_INSERT_JOIN_CONDITION}
                 | """.stripMargin)
        System.out.println("Insert query debug check 4: Insertion done. ")
        spark.sql(
        raw"""
             | SELECT ${SQLColumnHelperPostUseTransactionsLx.LX_POST_USE_INSERT_QUERY}
             | FROM temp_df_post_use_stage_updated_run_id_struct sb
             | LEFT JOIN temp_post_use_purchase_lx_view pb
             | ON ${SQLColumnHelperPostUseTransactionsLx.LX_POST_USE_INSERT_JOIN_CONDITION}
             | """.stripMargin
        ).filter("booking_item.booking_item_id IN (93192116, 93192117, 93269003, 93269004, 93337563, 93337564)")
            .show(truncate = false)
        System.out.println("Insert query debug check 4 End")
        tmp
    }

    def get_car_post_use_stg_bkg_view_data(spark: SparkSession): DataFrame = {
        spark.sql(
            raw""" SELECT
                 | ${SQLColumnHelperPostUseTransactionsCar.Car_POST_USE_STAGE_BOOKING_READ_QUERY}
                 |  from temp_post_use_transaction_staged_booking_cars_view""".stripMargin)
    }

    def insert_stg_bkg_backfill_lx_data(spark: SparkSession): DataFrame = {
        spark.sql(
            raw""" ${SQLColumnHelperBookingTransactionsBackfillLx.LX_STAGE_BOOKING_BACKFILL_INSERT_STATEMENT}
                 | SELECT ${SQLColumnHelperBookingTransactionsBackfillLx.LX_STAGE_BOOKING_BACKFILL_INSERT_QUERY}
                 |  from temp_df_updated_run_id_struct sb LEFT JOIN temp_df_dummy_booking_transaction dbt
                 |           on sb.${PRODUCT_LINE_NAME_COLUMN} = dbt.pl_dummy""".stripMargin)
    }

    def get_cars_post_use_purchase_booking(spark: SparkSession): DataFrame = {
        spark.sql(
            raw""" SELECT
                 | ${SQLColumnHelperPostUseTransactionsCar.Car_POST_USE_PURCHASE_BOOKING_READ_QUERY}
                 |  from temp_post_use_transaction_purchase_booking_cars_view""".stripMargin)
    }

    def insert_car_stage_booking_data(spark: SparkSession): DataFrame = {
        spark.sql(
            raw""" ${SQLColumnHelperBookingTransactionsCar.Car_STAGE_BOOKING_INSERT_STATEMENT}
                 | SELECT ${SQLColumnHelperBookingTransactionsCar.Car_STAGE_BOOKING_INSERT_QUERY}
                 |  from temp_df_updated_run_id_struct sb LEFT JOIN temp_df_dummy_booking_transaction dbt
                 |           on sb.${PRODUCT_LINE_NAME_COLUMN} = dbt.pl_dummy""".stripMargin)
    }

    def get_cars_stage_booking_backfill_data(spark: SparkSession): DataFrame = {
        spark.sql(
            raw""" SELECT
                 | ${SQLColumnHelperBookingTransactionsBackfillCars.CARS_STAGE_BOOKING_BACKFILL_READ_QUERY}
                 |  from temp_stg_bkg_backfill_fact_car_view""".stripMargin)
    }

    def insert_lodging_stage_booking_data(spark: SparkSession): DataFrame = {
        spark.sql(
            raw""" ${SQLColumnHelperBookingTransactionsLodging.LODGING_STAGE_BOOKING_INSERT_STATEMENT}
                            """.stripMargin)
    }

    def get_lodging_joined_data(spark: SparkSession, lodg_rate_pln_dim_legacy: String): DataFrame = {
        spark.sql("select f.*, m.expe_lodg_property_id_mapped," +
            " m.expe_lodg_property_id_mapped ,lrp.lodg_rm_typ_id " +
            "from temp_stg_bkg_fact_lodging_view f " +
            "left join commerce.expe_property_id_mapping m on f.lodg_property_key  = m.lodg_property_key_original " +
            "left join " + lodg_rate_pln_dim_legacy + " lrp on lrp.lodg_rate_pln_key = f.lodg_rate_pln_key "
        )
    }

    def get_loging_stg_bkg_backfill_data(spark: SparkSession): DataFrame = {
        spark.sql(
            raw""" SELECT
                 | ${SQLColumnHelperBookingTransactionsBackfillLodging.LODGING_STAGE_BOOKING_BACKFILL_READ_QUERY}
                 |  from temp_df_lodging_view f""".stripMargin)
    }

    def insert_car_post_use_data(spark: SparkSession): Unit = {
        spark.sql(
            raw""" ${SQLColumnHelperPostUseTransactionsCar.Car_POST_USE_INSERT_STATEMENT}
                 | SELECT ${SQLColumnHelperPostUseTransactionsCar.Car_POST_USE_INSERT_QUERY}
                 | FROM temp_df_post_use_stage_booking_cars_updated_run_id_struct sb
                 | LEFT JOIN temp_df_post_use_purchase_booking_cars_view pb
                 | ON ${SQLColumnHelperPostUseTransactionsCar.Car_POST_USE_INSERT_JOIN_CONDITION}
                 | """.stripMargin)
    }

    def get_lodging_stage_booking_data(spark: SparkSession): DataFrame = {
        spark.sql(
            raw""" SELECT
                 | ${SQLColumnHelperBookingTransactionsLodging.LODGING_STAGE_BOOKING_READ_QUERY}
                 |  from temp_df_lodging_view f""".stripMargin)
    }

    def get_lodging_post_bkg_data(spark: SparkSession, lodg_rate_pln_dim_legacy: String): DataFrame = {
        spark.sql("select f.*, lrp.lodg_rm_typ_id " +
            "from temp_post_bkg_fact_lodging_view f " +
            "left join " + lodg_rate_pln_dim_legacy + " lrp on lrp.lodg_rate_pln_key = f.lodg_rate_pln_key "
        )
    }

    def insert_cars_stg_booking_backfill_data(spark: SparkSession): DataFrame = {
        spark.sql(
            raw""" ${SQLColumnHelperBookingTransactionsBackfillCars.CARS_STAGE_BOOKING_BACKFILL_INSERT_STATEMENT}
                 | SELECT ${SQLColumnHelperBookingTransactionsBackfillCars.CARS_STAGE_BOOKING_BACKFILL_INSERT_QUERY}
                 |  from temp_df_updated_run_id_struct sb LEFT JOIN temp_df_dummy_booking_transaction dbt
                 |           on sb.${PRODUCT_LINE_NAME_COLUMN} = dbt.pl_dummy""".stripMargin)
    }

    def get_lodging_post_stay_data(spark: SparkSession): DataFrame = {
        spark.sql(
            raw""" SELECT
                 | ${SQLColumnHelperPostStayTransactionsLodging.LODGING_BOOKING_POST_STAY_READ_QUERY}
                 |  from temp_df_post_lodging_view f""".stripMargin)
    }

    def insert_lodging_post_stay_data(spark: SparkSession): DataFrame = {
        // Construct the SQL query
        val sqlQuery = s"""
                          | ${SQLColumnHelperPostStayTransactionsLodging.LODGING_POST_STAY_INSERT_STATEMENT}
                          | SELECT ${SQLColumnHelperPostStayTransactionsLodging.LODGING_POST_USE_INSERT_QUERY}
                          | FROM temp_df_updated_post_stay_run_id_struct sb
                          | LEFT JOIN temp_post_stay_purchase_lodging_view pb
                          |      ON ${SQLColumnHelperPostStayTransactionsLodging.LODGING_POST_USE_INSERT_JOIN_CONDITION}
                          | LEFT JOIN temp_df_dummy_booking_transaction dbt
                          |      ON sb.product_line_name = dbt.pl_dummy
                          | """.stripMargin

        try {
            // Print the SQL query
            println("Executing the following query:")
            println(sqlQuery)

            // Execute the query
            spark.sql(sqlQuery)
        } catch {
            case e: Exception =>
                // Log the error
                println("An error occurred during SQL execution:")
                println(sqlQuery)
                e.printStackTrace()
                throw e // Re-throw the exception after logging it
        }
    }


    def get_lodging_purchase_booking_post_stay_data(spark: SparkSession): DataFrame = {
        spark.sql(
            raw""" SELECT
                 | ${SQLColumnHelperPostStayTransactionsLodging.LODGING_PURCHASE_BOOKING_POST_STAY_READ_QUERY}
                 |  from temp_post_stay_purchase_fact_lodging_view""".stripMargin)
    }

    def insert_lodging_stage_booking_backfill_data(spark: SparkSession): DataFrame = {
        spark.sql(
            raw""" ${SQLColumnHelperBookingTransactionsBackfillLodging.LODGING_STAGE_BOOKING_BACK_FILL_INSERT_STATEMENT}
                                    """.stripMargin)
    }

    def run_query(spark: SparkSession, query: String): DataFrame = {
        spark.sql(query)
    }

    def get_dummy_booking_data(spark: SparkSession): DataFrame = {
        spark.sql(
            raw""" ${SQLColumnHelper.DUMMY_BOOKING_TRANSACTION_QUERY}
                 """.stripMargin)
    }
}
