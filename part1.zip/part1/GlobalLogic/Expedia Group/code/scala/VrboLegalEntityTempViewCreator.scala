package com.expediagroup.platform.vrbo

import com.expediagroup.platform.constant.VrboConstant._
import org.apache.spark.sql.SparkSession
import org.springframework.stereotype.Component

@Component
class VrboLegalEntityTempViewCreator {

    def createTempView(spark: SparkSession): Unit = {
        val fields = Seq(VRBO_FIELD_BRAND_CODE, VRBO_FIELD_LEGAL_ENTITY_ID, VRBO_FIELD_LEGAL_ENTITY_CODE)
        val legalEntities = Seq(
            (VRBO_BRAND_CODE_HAUS, VRBO_LEGAL_ENTITY_ID_13, VRBO_LEGAL_ENTITY_CODE_41101),
            (VRBO_BRAND_CODE_HACA, VRBO_LEGAL_ENTITY_ID_13, VRBO_LEGAL_ENTITY_CODE_41101),
            (VRBO_BRAND_CODE_HAMX, VRBO_LEGAL_ENTITY_ID_13, VRBO_LEGAL_ENTITY_CODE_41101),
            (VRBO_BRAND_CODE_HACF, VRBO_LEGAL_ENTITY_ID_13, VRBO_LEGAL_ENTITY_CODE_41101),
            (VRBO_BRAND_CODE_VRUS, VRBO_LEGAL_ENTITY_ID_13, VRBO_LEGAL_ENTITY_CODE_41101),
            (VRBO_BRAND_CODE_MVUS, VRBO_LEGAL_ENTITY_ID_13, VRBO_LEGAL_ENTITY_CODE_41101),
            (VRBO_BRAND_CODE_VRBO, VRBO_LEGAL_ENTITY_ID_13, VRBO_LEGAL_ENTITY_CODE_41101),
            (VRBO_BRAND_CODE_LXUS, VRBO_LEGAL_ENTITY_ID_13, VRBO_LEGAL_ENTITY_CODE_41101)
        )
        val legalEntityRDD = spark.sparkContext.parallelize(legalEntities)
        val legalEntityDF = spark.createDataFrame(legalEntityRDD).toDF(fields: _*)
        legalEntityDF.createOrReplaceTempView(VRBO_LEGAL_ENTITY_VIEW)
    }
}
