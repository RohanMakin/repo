package com.expediagroup.platform.taxcompliance

import com.expediagroup.platform.taxcompliance.cases.{JobRunCase, PreProcessorConfigCase, TableSchemaConfigCase}
import com.expediagroup.platform.taxcompliance.constants.AppConstants
import com.expediagroup.platform.taxcompliance.sql.SQLColumnHelper
import com.expediagroup.platform.taxcompliance.util.SparkUtil
import com.fasterxml.jackson.databind.{DeserializationFeature, ObjectMapper}
import com.fasterxml.jackson.module.scala.DefaultScalaModule
import com.fasterxml.jackson.module.scala.experimental.ScalaObjectMapper
import io.micrometer.core.instrument.{ImmutableTag, Tag}
import org.apache.spark.sql._
import org.slf4j.{LoggerFactory, MDC}
import org.springframework.boot.autoconfigure.SpringBootApplication
import org.springframework.boot.autoconfigure.gson.GsonAutoConfiguration
import org.springframework.boot.autoconfigure.solr.SolrAutoConfiguration
import org.springframework.boot.{ApplicationArguments, SpringApplication}
import org.springframework.context.ConfigurableApplicationContext
import org.springframework.context.annotation.{Bean, Configuration, Lazy}
import org.springframework.core.io.DefaultResourceLoader

import java.util.{ArrayList, List}

import java.io.{BufferedReader, InputStreamReader}

@Configuration
@SpringBootApplication(exclude = Array(classOf[GsonAutoConfiguration],
    classOf[SolrAutoConfiguration]))
class DataCollectorApp

object DataCollectorApp extends Serializable {
    private val LOGGER = LoggerFactory.getLogger(this.getClass)

    def main(args: Array[String]): Unit = {
        var sparkSession: SparkSession = null
        var applicationContext: ConfigurableApplicationContext = null

        try {
            sparkSession = SparkUtil.initSpark(args)
            val startDate = args(0).toString()
            val endDate = args(1).toString()
            val runId = args(2).toString()
            val jobName = args(3).toString()
            val workFlowName = args(4).toString()
            val productLineName = args(5).toString().toLowerCase().replaceAll("_"," ")
            var criteriaList = ""
            if (checkIfWorkflowNameIsCriteriaType(workFlowName)) {
                criteriaList = args(6).replaceAll("'","\"").replaceAll("_"," ")
            }
            
            sparkSession.sparkContext.setLogLevel("WARN")
            sparkSession.sparkContext.setLogLevel("ERROR")

            sparkSession.sparkContext.setLogLevel("WARN")
            sparkSession.sparkContext.setLogLevel("ERROR")

            applicationContext = SpringApplication.run(classOf[DataCollectorApp], args: _ *)
            val factory: DataCollectorOperationFactory = applicationContext.getBean(classOf[DataCollectorOperationFactory])
            val operation:DataCollectorOperation = factory.getDataCollectorOperation(workFlowName, productLineName)
            if(operation == null){
                throw new Exception("DataCollector Operation cannot be Identified due to Invalid WorkFlow Name:" + workFlowName)
            }
            val preProcessorConfig = retrievePreProcessorConfig(AppConstants.TARGET_TABLE_CONFIG)
            val schemaConfig = retrieveSchemaConfig(AppConstants.BOOKING_TRANSACTION_TABLE_CONFIG)
            operation.setConfig(sparkSession, preProcessorConfig, schemaConfig)
            sparkSession.sparkContext.setLogLevel("ERROR")
            operation.loadEnrichedTransactions(sparkSession, startDate, endDate, runId, jobName, criteriaList, productLineName)
        }
        catch {
            case e:Exception => LOGGER.error("Data Collector Workflow Failed", e)
                throw e
        }
        finally {
            Thread.sleep(30000)
            sparkSession.close()
            applicationContext.close();
        }
    }

    @Bean def tags(ctx: ConfigurableApplicationContext, args:ApplicationArguments): List[Tag] = {
        val startDate = args.getNonOptionArgs.get(0)
        val endDate = args.getNonOptionArgs.get(1)
        val runId = if (args.getNonOptionArgs.size() > 2) args.getNonOptionArgs.get(2) else "None"
        val workFlowName = if (args.getNonOptionArgs.size() > 4) args.getNonOptionArgs.get(4) else "PartnerAttributes"

        val tags: List[Tag]= new ArrayList[Tag](6)
        tags.add(new ImmutableTag("tax_compliance_app_id", ctx.getEnvironment.getProperty("applicationId")))
        tags.add(new ImmutableTag("tax_compliance_env", ctx.getEnvironment.getProperty("dc_env")))
        tags.add(new ImmutableTag("tax_compliance_start_date", startDate))
        tags.add(new ImmutableTag("tax_compliance_end_date", endDate))
        tags.add(new ImmutableTag("tax_compliance_run_id", runId))
        tags.add(new ImmutableTag("tax_compliance_workflow_name", workFlowName))

        LOGGER.info("Print Tags from DataCollectorApp: " +tags)
        return tags
    }

    @Bean def jobRunCase(ctx: ConfigurableApplicationContext, args:ApplicationArguments): JobRunCase = {
        LOGGER.info("Initializing JobRunCase")
        val startDate = java.sql.Date.valueOf(args.getNonOptionArgs.get(0))
        val endDate = java.sql.Date.valueOf(args.getNonOptionArgs.get(1))
        val runId = args.getNonOptionArgs.get(2)
        if (args.getNonOptionArgs.size() > 5) {
            val jobName = args.getNonOptionArgs.get(3)
            val productLineName = args.getNonOptionArgs.get(5).replaceAll("_", " ")
            LOGGER.info("Initializing JobRunCase in DataCollectorApp: " + jobName)
            return JobRunCase(startDate, endDate, runId, jobName, productLineName)
        } else {
            LOGGER.info("Initializing JobRunCase in Partner Attributes App")
            return JobRunCase(startDate, endDate, runId, "PartnerAttributes", "Lodging")
        }
    }

    private def checkIfWorkflowNameIsCriteriaType(workFlowName: String) = {
        workFlowName == SQLColumnHelper.CRITERIA_REPROCESS ||
            workFlowName == SQLColumnHelper.POST_STAY_CRITERIA_REPROCESS
    }

    def retrievePreProcessorConfig(configFilePath:String): PreProcessorConfigCase = {
        LOGGER.info("AppName:{} RunID:{} start reading Post Processor Config information", Array(MDC.get("appName"), MDC.get("uniqueID")): _*)
        val resourceLoader = new DefaultResourceLoader()
        val resource = resourceLoader.getResource(configFilePath)
        val mapper = new ObjectMapper() with ScalaObjectMapper
        mapper.registerModule(DefaultScalaModule)
        mapper.configure(DeserializationFeature.FAIL_ON_UNKNOWN_PROPERTIES, false)
        val preProcessorConfig = mapper.readValue(resource.getInputStream, classOf[PreProcessorConfigCase])
        LOGGER.info("AppName:{} RunID:{} finish reading post processing config information", Array(MDC.get("appName"), MDC.get("uniqueID")): _*)
        preProcessorConfig
    }

    def retrieveSchemaConfig(schemaFilePath:String): TableSchemaConfigCase = {
        LOGGER.info("AppName:{} RunID:{} start reading Table Schema Config information", Array(MDC.get("appName"), MDC.get("uniqueID")): _*)
        val resourceLoader = new DefaultResourceLoader()
        val resource = resourceLoader.getResource(schemaFilePath)
        val mapper = new ObjectMapper() with ScalaObjectMapper
        mapper.registerModule(DefaultScalaModule)
        mapper.configure(DeserializationFeature.FAIL_ON_UNKNOWN_PROPERTIES, false)
        val tableSchemaConfig = mapper.readValue(resource.getInputStream, classOf[TableSchemaConfigCase])
        LOGGER.info("AppName:{} RunID:{} finish reading Table Schema config information", Array(MDC.get("appName"), MDC.get("uniqueID")): _*)
        tableSchemaConfig
    }

    def readHqlFile(hqlFilePath: String): String = {
        LOGGER.info("AppName:{} RunID:{} start reading HQL file", Array(MDC.get("appName"), MDC.get("uniqueID")): _*)
        // Load the resource from the specified HQL file path
        val resourceLoader = new DefaultResourceLoader()
        val resource = resourceLoader.getResource(hqlFilePath)
        // Read the content of the HQL file
        val contentBuilder = new StringBuilder
        val reader = new BufferedReader(new InputStreamReader(resource.getInputStream))
        try {
            var line: String = null
            while ( {
                line = reader.readLine(); line
            } != null) {
                contentBuilder.append(line).append("\n")
            }
        } finally {
            reader.close()
        }
        val hqlContent = contentBuilder.toString()
        LOGGER.info("AppName:{} RunID:{} finish reading HQL file", Array(MDC.get("appName"), MDC.get("uniqueID")): _*)
        hqlContent
    }

}
