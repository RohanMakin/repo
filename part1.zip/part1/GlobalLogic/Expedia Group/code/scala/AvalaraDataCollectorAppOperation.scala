package com.expediagroup.platform.taxcompliance.avalaravertexcomparison

import org.apache.spark.sql.SparkSession
import org.slf4j.LoggerFactory
import org.apache.spark.sql.DataFrame
import org.springframework.stereotype.Component
import org.springframework.beans.factory.annotation.{Autowired, Value}
@Component("com.expediagroup.platform.taxcompliance.avalaravertexcomparison.AvalaraDataCollectorAppOperation")
class AvalaraDataCollectorAppOperation {
    private val LOGGER = LoggerFactory.getLogger(this.getClass)

    @Value("${com.expediagroup.platform.taxcompliance.avalara.detail.extract.table}")
    val avalaraTable: String = null
    def loadAvalaraData(spark: SparkSession, s3Path: String, fileNames: String): Unit = {
        val fileNamesArray = fileNames.split(",")
        // if no file names are provided, then keep the paths list empty
        val filePaths = if (fileNames.nonEmpty) {fileNames.split(",").map(file => s3Path + file + ".csv")} else {Array.empty[String]}

        LOGGER.info("File paths to get avalara data: " + filePaths.mkString(", "))

        LOGGER.info("Reading data from CSV files...")
        val avalaraDf = readCSVFile(filePaths, s3Path, spark)
        LOGGER.info("Data read from CSV files")

        print("Size of dataframe: " + avalaraDf.count)
        avalaraDf.show(1, false)

        LOGGER.info("Writing Avalara Data to S3...")
        writeToGTP(avalaraDf, spark)
        LOGGER.info("Avalara Data written to S3")

    }

    def readCSVFile(filePaths: Array[String], folderPath: String, spark: SparkSession): DataFrame = {
        val df = if (filePaths.isEmpty) {
            // Load all CSV files from the folder
            spark.read
                .option("header", "true")
                .option("inferSchema", "true")
                .csv(folderPath)
        } else {
            // Load specific CSV files listed in filePaths
            spark.read
                .option("header", "true")
                .option("inferSchema", "true")
                .csv(filePaths: _*)
        }

        df
    }

    def writeToGTP(avalaraDf: DataFrame, spark: SparkSession) = {
        avalaraDf.createOrReplaceTempView("temp_tax_compliance_eg_avalara_detail_extract")

        spark.sql(
            raw"""
                    INSERT OVERWRITE TABLE ${avalaraTable} PARTITION(DOCUMENTDATE, STATEPROVINCE)
                    SELECT
                        COUNTRY,
                        COMPANYID,
                        COMPANYCODE,
                        DOCUMENTID,
                        DOCUMENTCODE,
                        DOCUMENTSTATUS,
                        LOCKEDSTATUS,
                        DOCTYPE,
                        MODIFIEDDATETIME,
                        TAXCALCDATE,
                        REPORTINGDATE,
                        PAYMENTDATE,
                        EXCHANGERATEEFFDATE,
                        EXCHANGERATE,
                        CURRENCYCODE,
                        CUSTOMERVENDORCODE,
                        ENTITYUSECODEDOCUMENTHEADER,
                        PURCHASEORDERNO,
                        REFERENCECODE,
                        SALESPERSONCODE,
                        LOCATIONCODE,
                        LINENO,
                        ITEMCODE,
                        ITEMCODEDESCRIPTION,
                        TAXCODE,
                        TAXCODEDESCRIPTION,
                        RATETYPE,
                        QUANTITY,
                        LINEAMOUNT,
                        DISCOUNTAMOUNT,
                        LINETAXABLEAMOUNT,
                        REF1,
                        REF2,
                        REVENUEACCOUNT,
                        LINEEXEMPTAMOUNT,
                        ENTITYUSECODEDOCUMENTLINE,
                        EXEMPTIONNO,
                        ISSSTP,
                        ISTAXABLE,
                        ORIGINSTREET,
                        ORIGINCOUNTY,
                        ORIGINCITY,
                        ORIGINSTATEPROVINCE,
                        ORIGINCOUNTRY,
                        ORIGINPOSTALCODE,
                        BUSINESSIDENTIFICATIONID,
                        DESTSTREET,
                        DESTCOUNTY,
                        DESTCITY,
                        DESTSTATEPROVINCE,
                        DESTCOUNTRY,
                        DESTPOSTALCODE,
                        LINETAXDETAILID,
                        JURISDICTIONTYPEDESCRIPTION,
                        TAXTYPEDESCRIPTION,
                        TAXSUBTYPE,
                        STATEASSIGNEDNO,
                        SOURCING,
                        JURISDICTIONDESCRIPTION,
                        INSTATE,
                        JURISDICTIONTYPETAXABLEAMOUNT,
                        JURISDICTIONTYPEEXEMPTAMOUNT,
                        EXEMPTREASON,
                        NONTAXABLEAMOUNT,
                        NONTAXABLEREASON,
                        NONTAXABLERULEDESCRIPTION,
                        OVERRIDEAMOUNT,
                        TAXAMOUNT,
                        TAXCALCULATED,
                        TAXVARIANCE,
                        RATE,
                        ECMSCERTID,
                        EXEMPTION_DESCRIPTION,
                        EXCHANGERATECURRENCYCODE,
                        TAXAUTHORITYNAME,
                        TAXAUTHORITYID,
                        TAXLIABILITY,
                        DATE_FORMAT(DOCUMENTDATE, 'yyyy-MM') AS DOCUMENTMONTH,
                        DATE_FORMAT(DOCUMENTDATE, 'yyyy-MM-dd') AS DOCUMENTDATE,
                        STATEPROVINCE
                     FROM temp_tax_compliance_eg_avalara_detail_extract
                     """)
    }
}
