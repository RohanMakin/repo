#!/bin/bash

# Define the kernel version
KERNEL_VERSION="kernel-5.15"

echo "Starting kernel upgrade process to $KERNEL_VERSION using amazon-linux-extras..."

# Attempt to install kernel-5.15 using amazon-linux-extras
echo "Installing $KERNEL_VERSION..."
if sudo amazon-linux-extras install -y "$KERNEL_VERSION"; then
    echo "$KERNEL_VERSION installation completed successfully."
else
    echo "Failed to install $KERNEL_VERSION. Exiting with error."
    exit 1
fi

# Get the running and latest installed kernel versions
CURRENT_KERNEL=$(uname -r)
LATEST_KERNEL=$(rpm -q kernel | sort -V | tail -n 1 | sed 's/kernel-//')

echo "Current running kernel: $CURRENT_KERNEL"
echo "Latest installed kernel: $LATEST_KERNEL"

# Condition check: if the running kernel differs from the latest installed kernel, reboot is needed
if [[ "$CURRENT_KERNEL" != "$LATEST_KERNEL" ]]; then
    echo "New kernel installed. Rebooting to apply changes..."
    sudo reboot
else
    echo "No reboot required; the running kernel is up-to-date."
fi

# Exit gracefully
exit 0
