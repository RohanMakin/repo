import os
import json
import boto3
import logging
import time
import uuid
import requests
import certifi

from datetime import datetime
from airflow.models import Variable
from botocore.exceptions import ClientError
from airflow.operators.bash import BashOperator


SPARK_RECON_FLAG = Variable.get("UseSparkEngine", False)

RECON_BUCKET = Variable.get("ReconScriptBucket")   # Location of hive scripts and also an output for results
RECON_PREFIX = Variable.get("ReconScriptPrefix") if not SPARK_RECON_FLAG else Variable.get("ReconScriptPrefixSpark")

RECON_RESULT_TABLE_MAPPING = {
    "job_run_id": 0,
    "rule_name": 1,
    "job_run_datetime": 2,
    "source_name": 3,
    "target_name": 4,
    "src_metric_value": 5,
    "tgt_metric_value": 6,
    "match_percentage": 7,
    "threshold_percentage": 8,
    "run_status": 9,
    "start_date": 10,
    "end_date": 11,
    "run_id": 12
}

#  --------------------------------
# |         AWS Utilities          |
#  --------------------------------

s3_client = boto3.client('s3')
s3_resource = boto3.resource('s3')


def list_s3_objects(bucket, prefix):
    response = s3_client.list_objects_v2(Bucket=bucket, Prefix=prefix)
    object_list = response.get('Contents', [])
    return [obj['Key'] for obj in object_list]


def get_all_files(bucket, folder_prefixes):
    all_files = []
    archived_folder = "archived"
    for folder in folder_prefixes:
        response = s3_client.list_objects_v2(Bucket=bucket, Prefix=folder)
        for item in response.get('Contents', []):
            if not item['Key'].endswith('/') and archived_folder not in item['Key']:
                all_files.append(item['Key'])

    return all_files


def get_s3_object_content(bucket, key):
    """Download a file from an S3 bucket

    :param bucket: S3 Bucket Name
    :param key: The S3 prefix+file name that should be downloaded
    :return: The plain-text contents of the file
    """

    print("Getting key: {} from bucket: {}".format(key, bucket))

    s3_object = s3_resource.Object(bucket, key)
    object_content = s3_object.get()['Body'].read().decode('utf-8')
    return object_content

def download_s3_file_as_json(bucket_name, file_name):
    """Download a JSON file from an S3 bucket as a Python Dictionary

    :param bucket: S3 Bucket Name
    :param key: The S3 prefix+file name that should be downloaded
    :return: A dictionary containing the json contents of the file
    """
    contents = get_s3_object_content(bucket_name, file_name)
    result = json.loads(contents)

    return result

def upload_file_to_s3(file_name, bucket, key = None):
    """Upload a file to an S3 bucket

    :param file_name: File to upload
    :param bucket: Bucket to upload to
    :param key: S3 object name. If not specified then file_name is used
    :return: True if file was uploaded, else False
    """

    # If S3 key was not specified, use file_name
    if key is None:
        key = os.path.basename(file_name)

    # Upload the file
    s3_client = boto3.client('s3')
    try:
        response = s3_client.upload_file(file_name, bucket, key)
    except ClientError as e:
        logging.error(e)
        return False
    return True

def upload_content_to_s3(content, bucket, key):
    """Uploads a given text (string) to a file in S3

    :param content: A string with the content to upload
    :param bucket: Bucket to upload to
    :param object_name: S3 object name. If not specified then file_name is used
    """
    print(f"Putting contents into S3 at {bucket}/{key}")
    s3_object = s3_resource.Object(bucket, key)
    s3_object.put(Body=content.encode())

def get_secret_value(secret_name):
    """Decode a secret from AWS Secrets Manager

    If the secret value is a key-value pair collection,
    make sure to parse the result with json.loads() to get each value

    :param secret_name: The identifier name of the secret (not arn)
    :return: The secret value as plain-text
    """
    session = boto3.session.Session()
    client = session.client(service_name='secretsmanager', region_name='us-east-1')

    response = client.get_secret_value(SecretId = secret_name)
    return response['SecretString']


#  --------------------------------
# |     Compliance Utilities       |
#  --------------------------------

def check_recon(branch_success, branch_fail, job_to_check, **kwargs):
    try:
        recon_output = get_s3_object_content(RECON_BUCKET, f'{RECON_PREFIX}/failed_rule_output_{job_to_check}')
        recon_results = list(set(filter(None, recon_output.split("\n"))))

        split_results_list = [row.split("	") for row in recon_results]
        failed_rules_list = []

        if (len(split_results_list) == 0):
            raise Exception("No records inserted in recon result table")

        for record in split_results_list:
            run_status = record[RECON_RESULT_TABLE_MAPPING.get("run_status")]

            if run_status == "FAILED":
                failed_rules_list.append(record[RECON_RESULT_TABLE_MAPPING.get("rule_name")])

        logging.error("Failed Rules list is: %s", failed_rules_list)
        if (len(failed_rules_list) > 0):
            if branch_fail is not None:
                print(f'Following branch `{branch_fail}`')
                return branch_fail
            else:
                raise Exception("Reconciliation failed, cannot proceed")

        print(f'Following branch `{branch_success}`')
        return branch_success
    except ClientError as ex:
        if ex.response['Error']['Code'] == 'NoSuchKey':
            raise Exception(f'Failed to insert expected rule in {job_to_check}. Cannot proceed.')
        else:
            raise

def wait_function(**kwargs):
    print('wait_time_sec - ', kwargs['wait_time'])
    print('going to sleep at - ', datetime.now())
    time.sleep(int(kwargs['wait_time']))
    print('back from sleep at - ', datetime.now())

def validate_date(date, date_type):
    if date is None:
        exception_string = "{} parameter was not provided".format(date_type)
        raise Exception(exception_string)
    try:
        datetime.strptime(date, "%Y-%m-%d")
    except ValueError:
        exception_value_string = "Incorrect date format for {}. Expected format is 'YYYY-MM-DD' ".format(date_type)
        raise ValueError(exception_value_string)

def generate_uuid():
    return str(uuid.uuid4())

def convert_seconds(seconds):
    hours = seconds // 3600
    minutes = (seconds % 3600) // 60
    remaining_seconds = seconds % 60
    return hours, minutes, remaining_seconds

#  -----------------------------------------------------
# |     Long-Running Cluster Management Utilities       |
#  -----------------------------------------------------

def compliance_container_request_body(secret_key: str, branch_name: str) -> str:
        body = {
            'secret-key': str(secret_key),
            'parameters': {
                'branch': branch_name,
                'version': 'HEAD',
                'vertex': 'false',
                'container_name': ''
            }
        }

        return json.dumps(body)

def generate_spinnaker_webhook_request(webhook_endpoint: str, parameters: str) -> BashOperator:
    return BashOperator(
        task_id = 'trigger_compliance_container_create',
        bash_command = (
            'curl '
            f'https://spinnaker.expedia.biz/api/v1/{webhook_endpoint} '
            '-X POST '
            '-H "content-type: application/json" '
            f"-d '{parameters}' "
            '-kvvv'
        )
    )