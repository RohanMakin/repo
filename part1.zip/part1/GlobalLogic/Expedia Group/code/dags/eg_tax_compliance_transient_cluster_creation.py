import uuid
import logging
from datetime import timedelta, datetime

from airflow import DAG
from airflow.providers.amazon.aws.sensors.emr import EmrJobFlowSensor
from airflow.providers.amazon.aws.operators.emr import EmrCreateJobFlowOperator
from airflow.operators.python import PythonOperator

from eg_tax_compliance_vardata import *
from eg_tax_compliance_utils import *
from eg_tax_compliance_transient_cluster_utils import *

RUN_ENV = Variable.get("ENV")
CONTAINER_NAME = Variable.get('BRANCH_NAME')
CLUSTER_IDS_PREFIX = Variable.get('TRANSIENT_CLUSTER_IDS')

DATA_BUCKET = data_s3_GTP_bucket[RUN_ENV]

JOB_DESCRIPTION = 'This DAG creates a transient EMR cluster'

default_args = {
    'owner': OWNER,
    'depends_on_past': False,
    'email_on_failure': False,
    'email_on_retry': False,
    'retries': 1,
    'retry_delay': timedelta(minutes=5),
    "start_date": datetime(2018, 1, 1),
}


logging.basicConfig(level=logging.INFO)
logger = logging.getLogger('TransientClusters')


def get_dag_conf(conf, name, default):
    return conf.get(name, default) if conf else default

def get_conf_vars(**kwargs):
    logger.info(f'Retrieving details of new transient cluster for {CONTAINER_NAME}')

    ti = kwargs['ti']
    dag_run = kwargs['dag_run']

    # Transient cluster parameters
    workflow_name = get_dag_conf(dag_run.conf, WORKFLOW_NAME, UNKNOWN)
    workflow_id = get_dag_conf(dag_run.conf, WORKFLOW_ID, None)
    is_compliance = get_dag_conf(dag_run.conf, IS_COMPLIANCE, "true")
    owner_name =  "compliance" if is_compliance == "true" else "tax"

    cluster_name = f'{owner_name}-emr-transient-{CONTAINER_NAME}-{workflow_name}'

    if workflow_id is None:
        workflow_id = str(uuid.uuid4())
        logger.info(f'Workflow ID not provided; will use: {workflow_id}')

    if workflow_id != '':
        short_id = workflow_id[0:8]
        cluster_name += f'-{short_id}'

    # Workflow parameters (for tagging only)
    start_date = get_dag_conf(dag_run.conf, START_DATE, NA)
    end_date = get_dag_conf(dag_run.conf, END_DATE, NA)
    product_line_name = get_dag_conf(dag_run.conf, PRODUCT_LINE_NAME, NA)

    ti.xcom_push(key = WORKFLOW_NAME, value = workflow_name)
    ti.xcom_push(key = WORKFLOW_ID, value = workflow_id)
    ti.xcom_push(key = CLUSTER_NAME, value = cluster_name)
    ti.xcom_push(key = START_DATE, value = start_date)
    ti.xcom_push(key = END_DATE, value = end_date)
    ti.xcom_push(key = PRODUCT_LINE_NAME, value = product_line_name)


    logger.info(f'{WORKFLOW_NAME} is: {workflow_name}')
    logger.info(f'{WORKFLOW_ID} is: {workflow_id}')
    logger.info(f'{CLUSTER_NAME} is: {cluster_name}')
    logger.info(f'{START_DATE} is: {start_date}')
    logger.info(f'{END_DATE} is: {end_date}')
    logger.info(f'{PRODUCT_LINE_NAME} is: {product_line_name}')


def create_emr_cluster_callable(**kwargs):
    ti = kwargs['ti']

    job_flow_overrides = ti.xcom_pull(task_ids = DOWNLOAD_TEMPLATE_TASK_ID)

    cluster_name = ti.xcom_pull(key = CLUSTER_NAME)
    workflow_name = ti.xcom_pull(key = WORKFLOW_NAME)
    workflow_id = ti.xcom_pull(key = WORKFLOW_ID)
    start_date = ti.xcom_pull(key = START_DATE)
    end_date = ti.xcom_pull(key = END_DATE)
    product_line_name = ti.xcom_pull(key = PRODUCT_LINE_NAME)

    logger.info(f'Creating Cluster: `{cluster_name}`')

    job_flow_overrides['Name'] = cluster_name

    # Get Hive Metastore credentials from AWS Secrets Manager
    metastore_credentials_response = get_secret_value(HMS_SECRET_NAME)
    metastore_credentials = json.loads(metastore_credentials_response)
    logger.info(f'HMS Keys Retrieved: {metastore_credentials.keys()}')

    for configuration in job_flow_overrides[CONFIGURATIONS]:
        if configuration[CLASSIFICATION] == HIVE_SITE:
            configuration[PROPERTIES][JAVAX_USER] = metastore_credentials[HMS_USER]
            configuration[PROPERTIES][JAVAX_PASSWORD] = metastore_credentials[HMS_PASSWORD]
            break

    # Get DataDog crendentials from AWS Secrets Manager
    datadog_credentials_response = get_secret_value(DD_SECRET_NAME)
    datadog_credentials = json.loads(datadog_credentials_response)
    logger.info(f'DD Keys Retrieved: {datadog_credentials.keys()}')

    for bootstrap_action in job_flow_overrides[BOOTSTRAP_ACTIONS]:
        if bootstrap_action[NAME] == DD_INSTALLATION:
            script_object = bootstrap_action[SCRIPT_BOOTSTRAP_ACTION]
            script_object[ARGS][0] = datadog_credentials[DD_API_KEY]
            break

    # Set custom tags
    job_flow_overrides[TAGS] = job_flow_overrides[TAGS] + [
        {
            'Key': 'Name',
            'Value': f'{CONTAINER_NAME}-transient'
        },
        {
            'Key': 'ContainerName',
            'Value': CONTAINER_NAME
        },
        {
            'Key': 'WorkflowName',
            'Value': workflow_name
        },
        {
            'Key': 'WorkflowId',
            'Value': workflow_id
        },
        {
            'Key': 'StartDate',
            'Value': start_date
        },
        {
            'Key': 'EndDate',
            'Value': end_date
        },
        {
            'Key': 'ProductLineName',
            'Value': product_line_name
        }
    ]

    splunk_script_location = shared_s3_locations['splunk_forwarder_setup']
    flink_script_location = shared_s3_locations['flink_env_setup']

    # transient overrides for EMR 6.6.0
    if "Download-Batch" in workflow_name or "Upload-Batch" in workflow_name:
        for configuration in job_flow_overrides[CONFIGURATIONS]:
            if configuration[CLASSIFICATION] == HIVE_SITE:
                configuration[PROPERTIES][HIVE_METASTORE_URI] = "thrift://127.0.0.1:9083"
                break

        job_flow_overrides[RELEASE_LABEL] = "emr-6.6.0"

        job_flow_overrides[BOOTSTRAP_ACTIONS] = job_flow_overrides[BOOTSTRAP_ACTIONS][2:]

    logger.info('Transient cluster template:')
    logger.info(job_flow_overrides)

    emr_create_job_flow_operator = EmrCreateJobFlowOperator(
        task_id=CREATE_CLUSTER_TASK_ID,
        job_flow_overrides=job_flow_overrides,
        region_name='us-east-1'
    )

    return emr_create_job_flow_operator.execute(context=kwargs)

def publish_cluster_id_callable(**kwargs):
    ti = kwargs['ti']
    run_id = kwargs['run_id']

    cluster_id = ti.xcom_pull(task_ids=CREATE_CLUSTER_TASK_ID, key='return_value')
    ti.xcom_push(key=CLUSTER_ID, value=cluster_id)

    file_name = f'{CLUSTER_IDS_PREFIX}/tc_id_{run_id}'

    logger.info(f'Run ID: {run_id}')
    logger.info(f'Cluster ID: {cluster_id}')

    upload_content_to_s3(cluster_id, DATA_BUCKET, file_name)
    ti.xcom_push(key=CLUSTER_ID, value=cluster_id)

    return cluster_id

def trigger_transient_cluster_sensor_callable(context, dag_run_obj):
    ti = context['ti']
    cluster_id = ti.xcom_pull(key=CLUSTER_ID)

    dag_run_obj.payload = {
        CLUSTER_ID: cluster_id
    }

    return dag_run_obj

with DAG(
    dag_id=TRANSIENT_CLUSTER_CREATION_DAG_ID,
    description=JOB_DESCRIPTION,
    default_args=default_args,
    schedule_interval=None,
    catchup=False,
    tags=tags[TRANSIENT_CLUSTER_CREATION_DAG_ID]
) as dag:

    get_conf_vars_task = PythonOperator(
        task_id=DEFAULT_CONF_VARS_TASK_ID,
        python_callable=get_conf_vars,
        provide_context=True,
        dag=dag
    )

    download_job_flow_overrides = PythonOperator(
        task_id=DOWNLOAD_TEMPLATE_TASK_ID,
        python_callable=download_s3_file_as_json,
        op_kwargs={
            'bucket_name': DATA_BUCKET,
            'file_name': TRANSIENT_CLUSTER_TEMPLATE
        },
        dag=dag
    )

    create_emr_cluster = PythonOperator(
        task_id=CREATE_CLUSTER_TASK_ID,
        python_callable=create_emr_cluster_callable,
        provide_context=True,
        dag=dag
    )

    wait_for_emr_cluster = EmrJobFlowSensor(
        task_id='wait_for_' + CREATE_CLUSTER_TASK_ID,
        job_flow_id="{{ task_instance.xcom_pull(task_ids='" + CREATE_CLUSTER_TASK_ID + "', key='return_value') }}",
        target_states=['WAITING'],
        failed_states=['TERMINATING', 'TERMINATED_WITH_ERRORS'],
        dag=dag,
    )

    publish_emr_cluster_id = PythonOperator(
        task_id=PUBLISH_CLUSTER_TASK_ID,
        python_callable=publish_cluster_id_callable,
        provide_context=True,
        dag=dag
    )

    trigger_transient_cluster_idle_sensor = TriggerDagRunOperator(
        task_id='trigger_for_idle_sensor',
        trigger_dag_id=TRANSIENT_CLUSTER_SENSOR_DAG_ID,
        conf={
            CLUSTER_ID: CLUSTER_ID_XCOM
        },
        dag=dag
    )

    get_conf_vars_task >> download_job_flow_overrides >> \
        create_emr_cluster >> wait_for_emr_cluster >> \
        publish_emr_cluster_id >> trigger_transient_cluster_idle_sensor
