from datetime import timedelta, datetime

from airflow import DAG
from airflow.operators.python import PythonOperator

from eg_tax_compliance_vardata import *
from eg_tax_compliance_utils import *
from eg_tax_compliance_transient_cluster_utils import *
from eg_tax_compliance_job_flow_idle_sensor import EgJobFlowIdleSensor


JOB_DESCRIPTION = "Continously check for a cluster's status. If it has been idle for so long, it terminates it."

POLLING_INTERVAL = 600 # How often (seconds) will we check the EMR status 

MAX_IDLE_TIME_DEFAULT = 21600
try:
    TRANSIENT_CLUSTER_MAX_IDLE_TIME = Variable.get('TRANSIENT_CLUSTER_MAX_IDLE_TIME', default_var=MAX_IDLE_TIME_DEFAULT)
    MAX_IDLE_TIME = int(TRANSIENT_CLUSTER_MAX_IDLE_TIME)
except:
    MAX_IDLE_TIME = MAX_IDLE_TIME_DEFAULT

default_args = {
    'owner': OWNER,
    'depends_on_past': False,
    'email_on_failure': False,
    'email_on_retry': False,
    'retries': 1,
    'retry_delay': timedelta(minutes=5),
    "start_date": datetime(2018, 1, 1),
}


logging.basicConfig(level=logging.INFO)
logger = logging.getLogger('TransientClusters')

def get_conf_vars(**kwargs):
    logger.info(f'Retrieving cluster details...')

    ti = kwargs['ti']
    dag_run = kwargs['dag_run']

    get_and_set_transient_cluster_id(ti, dag_run.conf, logger)

    h, m, s = convert_seconds(MAX_IDLE_TIME)
    logger.info(f'This cluster will be autoterminated after {h} hours, {m} minutes and {s} seconds')


with DAG(
    dag_id=TRANSIENT_CLUSTER_SENSOR_DAG_ID,
    description=JOB_DESCRIPTION,
    default_args=default_args,
    schedule_interval=None,
    catchup=False,
    tags=tags[TRANSIENT_CLUSTER_SENSOR_DAG_ID]
) as dag:
    
    get_conf_vars_task = PythonOperator(
        task_id=DEFAULT_CONF_VARS_TASK_ID,
        python_callable=get_conf_vars,
        provide_context=True,
        dag=dag
    )
    
    check_emr_idle_status = EgJobFlowIdleSensor(
        task_id=CHECK_IDLE_CLUSTER_TASK_ID,
        job_flow_id=CLUSTER_ID_XCOM,
        polling_interval=POLLING_INTERVAL,
        max_idle_time=MAX_IDLE_TIME,
        dag=dag
    )

    terminate_cluster_task = TriggerDagRunOperator(
        task_id=TERMINATE_CLUSTER_TASK_ID,
        trigger_dag_id=TRANSIENT_CLUSTER_TERMINATION_DAG_ID,
        wait_for_completion=True,
        conf={
            CLUSTER_ID: CLUSTER_ID_XCOM
        },
        dag=dag
    )

    get_conf_vars_task >> check_emr_idle_status >> terminate_cluster_task
