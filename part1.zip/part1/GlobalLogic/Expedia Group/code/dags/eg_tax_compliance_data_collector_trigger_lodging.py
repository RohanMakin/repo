from airflow.models import DAG
from datetime import date, timedelta, datetime
from pytz import timezone
from airflow.models import Variable
from airflow.operators.python import PythonOperator
from airflow.utils.email import send_email
from airflow.operators.dagrun_operator import TriggerDagRunOperator
from eg_tax_compliance_vardata import *
from eg_tax_compliance_emr_utils import *

import logging
import uuid
import pytz

RUN_ENV         = Variable.get("ENV")
EMR_CLUSTER_ID  = Variable.get("CLUSTER_ID")
BRANCH_NAME     = Variable.get("BRANCH_NAME")
BUCKET_NAME = Variable.get("S3_DATA_BUCKET")

cluster_label = "spark_tax_compliance_events"
support_email = "g3v0c3q6v9r5n1i9@expedia.slack.com"

job_name = "eg_tax_compliance_data_collector_trigger_lodging"
job_interval = "01 17 * * *"

check_upstream_data_sync_status_task_name = "check_upstream_data_sync_status"
spark_class_name = "com.expediagroup.platform.taxcompliance.trigger.TDTriggerApplication"
spark_class_name_job_info= "com.expediagroup.platform.taxcompliance.jobinfo.JobInfoApp"

run_id = str(uuid.uuid4())
product_line_name = "lodging"

def getCurrentDate():
    currentDateTimeUTC = datetime.now(tz=pytz.utc)
    currentDateTimePST = currentDateTimeUTC.astimezone(timezone('US/Pacific'))
    currentDateString = currentDateTimePST.strftime("%Y-%m-%d")
    return currentDateString

def getTransactionDate():
    currentDateTimeUTC = datetime.now(tz=pytz.utc)
    currentDateTimePST = currentDateTimeUTC.astimezone(timezone('US/Pacific'))
    dayBeforeCurrentDateString = (currentDateTimePST - timedelta(days=1)).strftime("%Y-%m-%d")
    return dayBeforeCurrentDateString

replication_date = getCurrentDate()
transaction_date = getTransactionDate()

FORMAT = '[%(levelname)s] [%(asctime)s] %(appName)s %(dagName)s runId=%(job_run_id)s replicationDate=%(replication_date)s - %(message)s'
logging.basicConfig(format=FORMAT, level=logging.INFO)
params = {'job_run_id': run_id, 'appName': 'DataCollector', 'dagName': job_name, 'replication_date': replication_date}

logger = logging.getLogger('DataCollector')
logger.info('Start Processing', extra=params)

jar_path = dc_jar_paths[RUN_ENV]
environment = environments[RUN_ENV]
support_email = support_emails[RUN_ENV]
teradata_jar_location= dc_terajdbc_jar_paths[RUN_ENV]

def generate_failure_trigger(context):
    ti = context['task_instance']
    task_id = ti.task_id
    failure_run_id = ""
    failure_transaction_date = ""
    print("task on failure" + task_id)
    if ti.xcom_pull(key='run_id') is not None:
        failure_run_id = ti.xcom_pull(key='run_id')

    if task_id == check_upstream_data_sync_status_task_name:
        dag_operator = generateJobLogInfoCommand("trigger_log_end_failure_upstream_data_sync",
                                                 "end_failure",  "tax_compliance_eg_upstream_data_sync_status", "Check Upstream Data Sync", "Upstream Datasync Status Check",  task_id, failure_run_id)
        dag_operator.execute(context)
    else:
        dag_operator = generateJobLogInfoCommand("trigger_log_end_failure_trigger",
                                                 "end_failure",  "", "Generic task failure job name", "Upstream Datasync Status Check",  task_id, failure_run_id)
        dag_operator.execute(context)

def send_failure_email_alert(context, exception):
    execution_date_ts = context['ts']
    ti = context['ti']
    dag = context['dag']

    run_id = "Run id doesn't exists"
    if ti.xcom_pull(key='run_id') is not None:
        run_id = ti.xcom_pull(key='run_id')

    attempted_tries = ti.prev_attempted_tries if hasattr(ti, 'prev_attempted_tries') else 'N/A'


    html_body = f"""<html>
            <header><title>The below DAG has failed!</title></header>
            <body>
            <br/>
            <b>Container</b>: {BRANCH_NAME}<br/>
            <b>DAG Name </b>: {dag.dag_id}<br/>
            <b>Run ID </b>: {run_id}<br/>
            <b>Task Id </b>: {ti.task_id}<br/>
            <b>Try number </b>: {attempted_tries}<br/>
            <b>Execution Time </b>: {execution_date_ts}<br/>
            <b>Exception </b>: {exception}<br/>
            <b>Hostname </b>: {ti.hostname}<br/>
            <b>Log </b>: <a href="{ti.log_url}">Link</a><br>
            <b>Log file name </b>: {ti.log_filepath}<br>
            </body>
            </html>
            """

    send_email(
        to=failure_emails,
        subject=RUN_ENV +": "+ job_name + ":  Job failed - " + execution_date_ts + " [failed]",
        html_content=html_body
    )


def failure_callback(context):
    ti = context['task_instance']

    try:
        exception = context['exception']
    except KeyError:
        exception = f"Task {ti.task_id } failed in dag { ti.dag_id }. A detailed reason could not be provided, please, refer to log file"

    if RUN_ENV == GTP_PROD:
        send_failure_email_alert(context, exception)

    generate_failure_trigger(context)

    raise Exception(exception)


default_args = {
    "owner": "os-team-taxmanians@expedia.com",
    "depends_on_past": False,
    "start_date": datetime(2018, 1, 1),
    "email": [support_email],
    "email_on_failure": True,
    "on_failure_callback": failure_callback,
    "email_on_retry": True,
    "retries": 20,
    "retry_delay": timedelta(minutes=30),
    "catchup": False
}

dag = DAG(
    dag_id = job_name,
    catchup=False,
    default_args=default_args,
    schedule_interval=job_interval,
    tags=tags[job_name]
)

def generate_correlation_id():
    return str(uuid.uuid4().hex)

def get_conf_vars(**kwargs):
    logger.info(f'''
        Run Environment: {RUN_ENV}
        JAR Path: {jar_path}
        Environment: {environment}
        Support Email: {support_email}
    ''')

    global run_id
    ti = kwargs['ti']
    dag_run = kwargs['dag_run']

    byPassExecution = dag_run.conf.get('bypass_execution', "false") if dag_run.conf else "false"

    ti.xcom_push(key='run_id', value=run_id)
    ti.xcom_push(key='bypass_execution', value=byPassExecution)

    logger.info("run_id is: %s", run_id)
    logger.info("bypass_execution is: %s", byPassExecution)

    transactionDate = getTransactionDate()
    ti.xcom_push(key='transaction_date', value=transactionDate)

get_conf_vars_operation = PythonOperator(
    task_id='get_conf_vars_task',
    python_callable=get_conf_vars,
    provide_context=True,
    dag=dag
)

def check_upstream_data_sync_status():
    run_id = "{{ task_instance.xcom_pull(key='run_id') }}"

    command = f'/usr/lib/spark/bin/spark-submit --jars {teradata_jar_location} --conf spark.master=yarn \
    --conf spark.sql.parquet.writeLegacyFormat=true --conf spark.driver.maxResultSize=0 --class {spark_class_name} \
    "{jar_path}" "{RUN_ENV}" "{run_id}" "{replication_date}" "{product_line_name}" "{BUCKET_NAME}" ; ' \

    return command_task_pair(dag, check_upstream_data_sync_status_task_name, command, enable_emr_retries=True)

def success_email_callback(**kwargs):
    ti = kwargs['ti']
    dagRun = kwargs["dag_run"]
    run_id = ti.xcom_pull(key='run_id')
    replication_date = getCurrentDate()
    transaction_date = getTransactionDate()

    html = f'''
        <p><b>Container:</b> <em>{BRANCH_NAME}</em></p>
        <p>run_id: <em>{run_id}</em></p>
        Upstream Data Sync Status is Green. Check results in EMR or logs at s3://compliance-log.files.&lt;prod\|test&gt;/{BRANCH_NAME}/&lt;step-id&gt;/<br><br>
        <h3>Triggering Tax Compliance Pipeline for date: {transaction_date} and product line: {product_line_name}</h3>
    '''
    send_email(
        to=support_email,
        subject=RUN_ENV +":"+ job_name + ":  Upstream Data Sync Status is Green For Replication Date: " + replication_date+ " and product line: "+ product_line_name,
        html_content=html,
    )

send_success_email = PythonOperator(
    task_id=job_name+"-succeed-email",
    python_callable=success_email_callback,
    provide_context=True,
    dag=dag,
)

trigger_eg_tax_compliance_data_collector_stage_booking_transactions_dag = TriggerDagRunOperator(
    task_id='trigger_eg_tax_compliance_data_collector_stage_booking_transactions_dag',
    trigger_dag_id='eg_tax_compliance_data_collector_stage_booking_transactions',
    conf={
        TRANSACTION_DATE: TRANSACTION_DATE_XCOM,
        BYPASS_EXECUTION: BYPASS_EXECUTION_XCOM
    },
    dag=dag
)

def getCurrentDateTime():
    currentDateTimeUTC = datetime.now(tz=pytz.utc)
    currentDateTimePST = currentDateTimeUTC.astimezone(timezone('US/Pacific'))
    currentDateString = currentDateTimePST.strftime("%Y-%m-%d %H:%M:%S")
    return currentDateString

def generateJobLogInfoCommand(task_id, payloadtype, tableName, jobDesc, pipelineProcessType, jobName, failure_run_id):

    operation = "Null"
    jobRunId = "{{ task_instance.xcom_pull(key='run_id') }}"
    jobUpdateDateTime = getCurrentDateTime()
    workflowType = "normal"
    runStatus = "Null"
    isActive = "Null"
    triggeredBy = "Tax Compliance Pipeline"
    checkType = "Null"
    transactionDateForCommand = getTransactionDate()

    if payloadtype == "start":
        isActive = "true"
        runStatus = "running"
        operation = "insert"
    elif payloadtype == "end_success":
        isActive = "false"
        runStatus = "succeeded"
        operation = "insert"
    elif payloadtype == "end_failure":
        isActive = "false"
        runStatus = "failed"
        operation = "insert"
        jobRunId = failure_run_id
    elif payloadtype == "first_check":
        checkType = "first_check"
        operation = "check"
    elif payloadtype == "second_check":
        operation = "check"
        checkType = "second_check"

    var_value_list ="'"+operation + "' '" + jobRunId + "' '" + tableName + "' '" + jobName + "' '" + jobDesc + "' '" + pipelineProcessType + "' '" + workflowType + "' '" + jobUpdateDateTime + "' '" + transactionDateForCommand + "' '" + transactionDateForCommand + "' '" + runStatus + "' '" + isActive + "' '" + triggeredBy + "' '" + product_line_name + "' '" + checkType + "' "

    print("jar_path: "+jar_path)
    print("spark_class_name: "+spark_class_name_job_info)
    logger.info('Job Info Table call', extra=params)
    run_id = "{{ task_instance.xcom_pull(key='run_id') }}"
    logger.info("run_id is: %s", run_id)

    command = f'/usr/lib/spark/bin/spark-submit --driver-java-options -Dspring.profiles.active={environment} --conf spark.master=yarn --conf spark.sql.parquet.writeLegacyFormat=true --class {spark_class_name_job_info} {jar_path} {var_value_list} --environment {environment}'

    return command_task_pair(dag, task_id, command)


execute_trigger_log_start_trigger_lodging, execute_trigger_log_start_trigger_lodging_listener = generateJobLogInfoCommand(
    "trigger_log_start_trigger_lodging",
    "start",
    "tax_compliance_eg_upstream_data_sync_status",
    "Check Upstream Data Sync",
    "Upstream Datasync Status Check",
    check_upstream_data_sync_status_task_name,
    ""
)

execute_trigger_log_end_success_trigger_lodging, execute_trigger_log_end_success_trigger_lodging_listener = generateJobLogInfoCommand(
    "trigger_log_end_trigger_lodging",
    "end_success",
    "tax_compliance_eg_upstream_data_sync_status",
    "Check Upstream Data Sync",
    "Upstream Datasync Status Check",
    check_upstream_data_sync_status_task_name,
    ""
)

execute_check_upstream_data_sync_status, execute_check_upstream_data_sync_status_listener = check_upstream_data_sync_status()

get_conf_vars_operation >> \
    execute_trigger_log_start_trigger_lodging >> execute_trigger_log_start_trigger_lodging_listener >> \
    execute_check_upstream_data_sync_status >> execute_check_upstream_data_sync_status_listener >> \
    execute_trigger_log_end_success_trigger_lodging >> execute_trigger_log_end_success_trigger_lodging_listener >> \
    trigger_eg_tax_compliance_data_collector_stage_booking_transactions_dag >> \
    send_success_email

logger.info('End Processing', extra=params)
