from airflow import settings
from airflow.models import Variable
from airflow.models.taskinstance import clear_task_instances

from airflow.operators.python import PythonOperator
from airflow.operators.dummy_operator import DummyOperator
from airflow.operators.dagrun_operator import TriggerDagRunOperator

from airflow.utils.trigger_rule import TriggerRule
from airflow.sensors.external_task import ExternalTaskSensor
from airflow.providers.amazon.aws.sensors.emr import EmrStepSensor
from airflow.providers.amazon.aws.operators.emr import EmrAddStepsOperator

from airflow.decorators import task_group

from eg_tax_compliance_vardata import *
from eg_tax_compliance_utils import get_s3_object_content

# Parameters
WORKFLOW_NAME = 'workflow_name'
WORKFLOW_ID = 'workflow_id'
WORKFLOW_TYPE = 'workflow_type'
IS_COMPLIANCE = 'is_compliance'

EXECUTION_PARAMS = 'execution_parameters'

CLUSTER_ID = 'cluster_id'
CLUSTER_NAME = 'cluster_name'

SKIP_CREATION = 'skip_cluster_creation'
SKIP_TERMINATION = 'skip_termination'
ENABLE_EMR_RETRIES = 'enable_emr_retries'

UNKNOWN = 'unknown-workflow'
OWNER = 'os-team-taxmanians@expedia.com'
NA = 'N/A'

# DAG IDs
TRANSIENT_CLUSTER_CREATION_DAG_ID = 'eg_tax_compliance_transient_cluster_creation'
TRANSIENT_CLUSTER_TERMINATION_DAG_ID = 'eg_tax_compliance_transient_cluster_termination'
TRANSIENT_CLUSTER_SENSOR_DAG_ID = 'eg_tax_compliance_transient_cluster_idle_sensor'
TRANSIENT_CLUSTER_COMBINED_WORKFLOWS_DAG_ID = 'eg_tax_compliance_transient_cluster_combine_workflows'

# Task IDs
DEFAULT_CONF_VARS_TASK_ID = 'get_conf_vars_task'
DOWNLOAD_TEMPLATE_TASK_ID = 'download_emr_template'
CREATE_CLUSTER_TASK_ID = 'create_emr_transient_cluster'
CREATE_OR_SKIP_CLUSTER_TASK_ID = 'create_emr_transient_cluster_or_skip'
PUBLISH_CLUSTER_TASK_ID = 'publish_cluster_id_to_s3'
PUSH_CLUSTER_TASK_ID = 'push_cluster_id_to_xcom'
TRIGGER_CLUSTER_CREATION_TASK_ID = 'trigger_transient_cluster_creation'

TERMINATE_CLUSTER_TASK_ID = 'terminate_emr_cluster'
CHECK_IDLE_CLUSTER_TASK_ID = 'check_for_emr_idle_status'

SKIP_CREATION_TASK_ID = 'skip_cluster_creation'
SKIP_CREATION_UNION_TASK_ID = 'union_for_transient_cluster_creation'

TG_TRIGGER_CLUSTER_CREATION_TASK_ID = f'{CREATE_OR_SKIP_CLUSTER_TASK_ID}.{TRIGGER_CLUSTER_CREATION_TASK_ID}'
TG_SKIP_CREATION_TASK_ID = f'{CREATE_OR_SKIP_CLUSTER_TASK_ID}.{SKIP_CREATION}'

# AWS Secrets Manager
HMS_SECRET_NAME = 'tax-compliance-hive-metastore-credentials'
HMS_USER = 'username'
HMS_PASSWORD = 'password'

DD_SECRET_NAME = 'tax-compliance-datadog-api-key'
DD_API_KEY = 'api-key'

# Job Flow Overrides keys
CONFIGURATIONS = 'Configurations'
CLASSIFICATION = 'Classification'
HIVE_SITE = 'hive-site'
PROPERTIES = 'Properties'
JAVAX_USER = 'javax.jdo.option.ConnectionUserName'
JAVAX_PASSWORD = 'javax.jdo.option.ConnectionPassword'
JAVAX_CONNECTION_URL = "javax.jdo.option.ConnectionURL"
HIVE_METASTORE_URI = "hive.metastore.uris"
HIVE = 'hive'
HIVE3 = "hive3"
TAGS = 'Tags'
RELEASE_LABEL = 'ReleaseLabel'
BOOTSTRAP_ACTIONS = 'BootstrapActions'
NAME = 'Name'
DD_INSTALLATION = 'DataDog Agent Installation'
SCRIPT_BOOTSTRAP_ACTION = 'ScriptBootstrapAction'
ARGS = 'Args'


def push_cluster_id_callable(**context):
    """Downloads a given transient cluster id from S3 and pushes it to XCom"""
    ti = context['ti']
    env = Variable.get('ENV')
    prefix = Variable.get('TRANSIENT_CLUSTER_IDS')

    run_id = ti.xcom_pull(key='trigger_run_id')

    bucket = data_s3_GTP_bucket[env]
    file_name = f'{prefix}/tc_id_{run_id}'

    cluster_id = get_s3_object_content(bucket, file_name)
    ti.xcom_push(key=CLUSTER_ID, value=cluster_id)

    return cluster_id

def transient_cluster_creation_pair(dag):
    trigger_transient_cluster_creation = TriggerDagRunOperator(
        task_id=TRIGGER_CLUSTER_CREATION_TASK_ID,
        trigger_dag_id=TRANSIENT_CLUSTER_CREATION_DAG_ID,
        wait_for_completion=True,
        conf={
            WORKFLOW_NAME: WORKFLOW_NAME_XCOM,
            WORKFLOW_ID: WORKFLOW_ID_XCOM,
            START_DATE: START_DATE_XCOM,
            END_DATE: END_DATE_XCOM,
            PRODUCT_LINE_NAME: PRODUCT_LINE_NAME_XCOM,
            IS_COMPLIANCE: IS_COMPLIANCE_XCOM
        },
        dag=dag
    )

    push_emr_cluster_id = PythonOperator(
        task_id=PUSH_CLUSTER_TASK_ID,
        python_callable=push_cluster_id_callable,
        provide_context=True,
        dag=dag
    )

    return trigger_transient_cluster_creation, push_emr_cluster_id

@task_group(group_id=CREATE_CLUSTER_TASK_ID)
def transient_cluster_creation_group(dag):
    """Creates 2 operators required to spin up a new Transient Cluster

    The first operator triggers the dag 'eg_tax_compliance_transient_cluster_creation'
    The second operator retrieves the Cluster ID from the triggered DAG and pushes it to the caller's XComs

    :param dag: The Airflow DAG object
    """

    trigger_transient_cluster_creation, push_emr_cluster_id = transient_cluster_creation_pair(dag)

    trigger_transient_cluster_creation >> push_emr_cluster_id

@task_group(group_id=CREATE_OR_SKIP_CLUSTER_TASK_ID)
def transient_cluster_creation_skippable_group(dag):
    trigger_transient_cluster_creation, push_emr_cluster_id = transient_cluster_creation_pair(dag)

    skip_transient_cluster_creation = DummyOperator(
        dag=dag,
        task_id=SKIP_CREATION_TASK_ID
    )

    union_for_transient_creation = DummyOperator(
        dag=dag,
        task_id=SKIP_CREATION_UNION_TASK_ID,
        trigger_rule=TriggerRule.ONE_SUCCESS
    )

    [trigger_transient_cluster_creation, skip_transient_cluster_creation]
    trigger_transient_cluster_creation >> push_emr_cluster_id >> union_for_transient_creation
    skip_transient_cluster_creation >> union_for_transient_creation

def transient_cluster_termination_pair(dag):
    trigger_transient_cluster_termination = TriggerDagRunOperator(
        task_id=TERMINATE_CLUSTER_TASK_ID,
        trigger_dag_id=TRANSIENT_CLUSTER_TERMINATION_DAG_ID,
        execution_date='{{ execution_date }}',
        conf={
            CLUSTER_ID: CLUSTER_ID_XCOM,
            SKIP_TERMINATION: SKIP_TERMINATION_XCOM
        },
        dag=dag
    )

    wait_for_termination = ExternalTaskSensor(
        task_id = f'wait_for_{TERMINATE_CLUSTER_TASK_ID}',
        external_dag_id = TRANSIENT_CLUSTER_TERMINATION_DAG_ID,
        allowed_states=['success'],
        dag = dag
    )

    return trigger_transient_cluster_termination, wait_for_termination

def get_and_set_transient_cluster_id(ti, conf, logger=None, use_default_id=False):
    """Get a transient cluster ID from DAG configuration variables and set it to XComs

    :param ti: A valid task_instance
    :param conf: A valid dag_run.conf instance
    :param logger: Optional. A valid logger instance
    :use_default_id: If set to False and 'cluster_id' is not set in conf, this task will raise an exception
    If use_default_id is set to True and 'cluster_id' is not set in conf, this task will push the cluster id found in Airflow Variables under CLUSTER_ID
    """
    cluster_id = conf.get(CLUSTER_ID, None) if conf else None

    if logger:
        logger.info(f'Transient Cluster ID found: {cluster_id}')
    else:
        print(f'Transient Cluster ID found: {cluster_id}')

    # Choose a behaviour
    if cluster_id is None:
        if use_default_id:
            cluster_id = Variable.get("CLUSTER_ID")
            ti.xcom_push(key = SKIP_TERMINATION, value = True)
        else:
            raise Exception('Transient Cluster ID NOT found in conf.\nSet `use_default_id` parameter to True to use default EMR cluster')

    ti.xcom_push(key = CLUSTER_ID, value = cluster_id)

def step_config(name, command):
    "Creates a standard object that represents an EMR step to run a command"

    return {
        'Name': name,
        'ActionOnFailure': 'CONTINUE',
        'HadoopJarStep': {
            'Jar': 'command-runner.jar',
            'Args': [
                "bash",
                "-c",
                command
            ]
        }
    }

def retry_callback(context):
    enable_emr_retries = context['params'].get(ENABLE_EMR_RETRIES, False)

    if enable_emr_retries == False or enable_emr_retries == 'False':
        return

    tasks = context["dag_run"].get_task_instances()
    to_retry_task_id = context["params"].get("to_retry",[])
    task_to_retry = [ti for ti in tasks if ti.task_id in to_retry_task_id]
    dag = context['dag']
    session = settings.Session()
    print("Will retry the following tasks: ")
    for ti in task_to_retry:
        print(ti.task_id)
    clear_task_instances(task_to_retry,session,None,dag)


def create_step_and_listener_pair(dag, task_id, step, t_rule, cluster_id,  enable_emr_retries=False):
    """Create a pair of operators to perform an AWS EMR Step.

    The implicit task dependency is not recorded here, that is the responsibility of the caller.
    The AWS api supports adding multiple steps at once but in practice our DAGs do one at a time.


    :param dag: The Airflow DAG object
    :param task_id: The task identifier, it will be shown in Airflow UI and EMR Steps
    :param command: The CLI command to perform. It will be automatically surrounded by 'bash -c {command}'
    :param t_rule: TriggerRule for EmrAddStepsOperator step. Defaults to ALL_SUCCESS
    :param cluster_id: The EMR Cluster ID that should perform the operation. Defaults to the value found on XComs under 'cluster_id'

    :return: A tuple of operators: One operator instructs AWS EMR to perform the operation. The other listens for the operation.
    """
    add_step = EmrAddStepsOperator(
        task_id=task_id,
        job_flow_id=cluster_id,
        aws_conn_id='aws_default',
        steps=[ step ], # API expects a list of steps
        trigger_rule=t_rule,
        dag=dag
    )

    listen_for_step = EmrStepSensor(
        task_id=f'listen_for_{task_id}',
        job_flow_id=cluster_id,
        step_id=f'{{{{ task_instance.xcom_pull( task_ids="{task_id}" )[0] }}}}',   # Get first result of returned value from AddSteps
        on_retry_callback=retry_callback,
        params={
            ENABLE_EMR_RETRIES: enable_emr_retries,
            'to_retry': [task_id]
        },
        dag=dag
    )
    return add_step, listen_for_step

def command_task_pair(dag, task_id, command, trigger_rule = TriggerRule.ALL_SUCCESS, cluster_id = CLUSTER_ID_XCOM, enable_emr_retries=False):
    """Create a pair of operators to perform an AWS EMR Step from a CLI command"""
    step = step_config(task_id, command)
    return create_step_and_listener_pair(dag, task_id, step, trigger_rule, cluster_id, enable_emr_retries)


def nohup_step_config(name, command):
    "Creates a standard object that represents an EMR step to run a command"

    return {
        'Name': name,
        'ActionOnFailure': 'CONTINUE',
        'HadoopJarStep': {
            'Jar': 'command-runner.jar',
            'Args': [
                "nohup",
                "bash",
                "-c",
                command
            ]
        }
    }

def nohup_command_task_pair(dag, task_id, command, trigger_rule = TriggerRule.ALL_SUCCESS, cluster_id = CLUSTER_ID_XCOM, enable_emr_retries=False):
    """Create a pair of operators to perform an AWS EMR Step from a CLI command  """
    step = nohup_step_config(task_id, command)
    return create_step_and_listener_pair(dag, task_id, step, trigger_rule, cluster_id, enable_emr_retries)
