from airflow.models import DAG
from datetime import date, timedelta, datetime
from pytz import timezone
from airflow.models import Variable, DagBag, DagRun
from airflow.operators.python import PythonOperator
from airflow.operators.python_operator import  BranchPythonOperator
from airflow.utils.email import send_email
from airflow.utils.trigger_rule import TriggerRule
from airflow.operators.dagrun_operator import TriggerDagRunOperator
from airflow.operators.dummy_operator import DummyOperator
from airflow.sensors.external_task import ExternalTaskSensor
from botocore.exceptions import ClientError

from eg_tax_compliance_vardata import *
from eg_tax_compliance_utils import *
from eg_tax_compliance_transient_cluster_utils import *

import boto3
import logging
import uuid
import pytz

RUN_ENV         = Variable.get("ENV")
EMR_CLUSTER_ID  = Variable.get("CLUSTER_ID")
BRANCH_NAME     = Variable.get("BRANCH_NAME")
BUCKET_NAME = Variable.get("S3_DATA_BUCKET")

RUN_ID_BACKFILL_XCOM = "{{ task_instance.xcom_pull(key='run_id_backfill') }}"

support_email = "g3v0c3q6v9r5n1i9@expedia.slack.com"


job_name = "eg_tax_compliance_data_collector_stage_booking_transactions"
job_interval = None
product_line_name = "Lodging"

load_eg_tax_compliance_staged_booking_transactions_task_name = "load_eg_tax_compliance_staged_booking_transactions"
load_eg_tax_compliance_post_stay_transactions_task_name = "load_eg_tax_compliance_post_stay_transactions"
check_job_info_table_stay_date_task_name = "check_job_info_table_stay_date"
spark_class_name = "com.expediagroup.platform.taxcompliance.jobinfo.JobInfoApp"
run_id = str(uuid.uuid4())
run_id_backfill = str(uuid.uuid4())

def getTransactionDate():
    transaction_date = "{{ dag_run.conf.get('transaction_date') }}"
    return transaction_date

transaction_date = getTransactionDate()

FORMAT = '[%(levelname)s] [%(asctime)s] %(appName)s %(dagName)s runId=%(job_run_id)s transactionDate=%(transaction_date)s - %(message)s'
logging.basicConfig(format=FORMAT, level=logging.INFO)
params = {'job_run_id': run_id, 'appName': 'DataCollector', 'dagName': job_name, 'transaction_date':transaction_date, 'product_line_name': product_line_name}

logger = logging.getLogger('DataCollector')
logger.info('Start Processing', extra=params)

database = databases[RUN_ENV]
jar_path = dc_jar_paths[RUN_ENV]
environment = environments[RUN_ENV]
support_email = support_emails[RUN_ENV]
artifacts_location = artifacts_s3[RUN_ENV]
teradata_jar_location= dc_terajdbc_jar_paths[RUN_ENV]

teradataConnectivity_class_name = "com.expediagroup.platform.taxcompliance.td_connect.Application"

script_name = "load_eg_tax_compliance_staged_booking_transactions"
script_name_post_stay = "load_eg_tax_compliance_post_stay_transactions"

RECON_RESULT_TABLE = "{}.tax_compliance_eg_recon_result".format(database)

def generate_failure_trigger(context):
    ti = context['task_instance']
    task_id = ti.task_id
    failure_run_id = ""
    failure_transaction_date = ""
    failure_product_line_name = ""
    if ti.xcom_pull(key='run_id') is not None:
        failure_run_id = ti.xcom_pull(key='run_id')
    if ti.xcom_pull(key='transaction_date') is not None:
        failure_transaction_date = ti.xcom_pull(key='transaction_date')
    if ti.xcom_pull(key='product_line_name') is not None:
        failure_product_line_name = ti.xcom_pull(key='product_line_name')

    if task_id == load_eg_tax_compliance_staged_booking_transactions_task_name:

        dag_operator = generateJobLogInfoCommand("trigger_log_job_tables_dag_booking_failure",
                                                 "end_failure",  "tax_compliance_eg_booking_transactions", "Loads Staged Booking Transactions to tax_compliance_eg_booking_transactions", "Data Sourcing", load_eg_tax_compliance_staged_booking_transactions_task_name, failure_run_id, failure_transaction_date,failure_product_line_name)
        dag_operator.execute(context)
    elif task_id == load_eg_tax_compliance_post_stay_transactions_task_name:
        dag_operator = generateJobLogInfoCommand("trigger_log_job_tables_dag_post_stay_failure",
                                                 "end_failure",  "tax_compliance_eg_booking_transactions_trans_date_liability", "Loads Post Stay Transactions to tax_compliance_eg_booking_transactions_trans_date_liability", "Data Sourcing", load_eg_tax_compliance_post_stay_transactions_task_name, failure_run_id, failure_transaction_date, failure_product_line_name)
        dag_operator.execute(context)
    else:
        dag_operator = generateJobLogInfoCommand("trigger_log_end_failure_stage_booking_transactions",
                                                 "end_failure",  "", "Generic task failure job name", "Generic task failure pipeline",  task_id, failure_run_id, failure_transaction_date, failure_product_line_name)
        dag_operator.execute(context)

def send_failure_email_alert(context, exception):
    execution_date_ts = context['ts']
    ti = context['ti']
    dag = context['dag']

    run_id = "Run id doesn't exists"
    if ti.xcom_pull(key='run_id') is not None:
        run_id = ti.xcom_pull(key='run_id')

    attempted_tries = ti.prev_attempted_tries if hasattr(ti, 'prev_attempted_tries') else 'N/A'

    html_body = f"""<html>
            <header><title>The below DAG has failed!</title></header>
            <body>
            <br/>
            <b>Container</b>: {BRANCH_NAME}<br/>
            <b>DAG Name </b>: {dag.dag_id}<br/>
            <b>Run ID </b>: {run_id}<br/>
            <b>Task Id </b>: {ti.task_id}<br/>
            <b>Try number </b>: {attempted_tries}<br/>
            <b>Execution Time </b>: {execution_date_ts}<br/>
            <b>Exception </b>: {exception}<br/>
            <b>Hostname </b>: {ti.hostname}<br/>
            <b>Log </b>: <a href="{ti.log_url}">Link</a><br>
            <b>Log file name </b>: {ti.log_filepath}<br>
            </body>
            </html>
            """

    send_email(
        to=failure_emails,
        subject=RUN_ENV +": "+ job_name + ":  Job failed - " + execution_date_ts + " [failed]",
        html_content=html_body
    )


def failure_callback(context):
    ti = context['task_instance']

    try:
        exception = context['exception']
    except KeyError:
        exception = f"Task {ti.task_id } failed in dag { ti.dag_id }. A detailed reason could not be provided, please, refer to log file"

    if RUN_ENV == GTP_PROD:
        send_failure_email_alert(context, exception)

    generate_failure_trigger(context)

    raise Exception(exception)


default_args = {
    "owner": "os-team-taxmanians@expedia.com",
    "depends_on_past": False,
    "start_date": datetime(2018, 1, 1),
    "email": [support_email],
    "email_on_failure": True,
    "on_failure_callback": failure_callback,
    "email_on_retry": False,
    "retries": 0,
    "retry_delay": timedelta(minutes=1)
}

with DAG(
    dag_id = job_name,
    catchup=False,
    default_args=default_args,
    schedule_interval=job_interval,
    tags=tags[job_name]
) as dag:

    def generateCorrelationId():
        return str(uuid.uuid4().hex)


    def getConfVars(**kwargs):
        logger.info(f'''
            Run Environment: {RUN_ENV}
            Database: {database}
            JAR Path: {jar_path}
            Environment: {environment}
            Support Email: {support_email}
            Script Name: {script_name}
            Script Name (Post Stay): {script_name_post_stay}
        ''')

        global run_id
        global run_id_backfill
        ti = kwargs['ti']
        ti.xcom_push(key='run_id', value=run_id)
        ti.xcom_push(key='run_id_backfill', value=run_id_backfill)
        dag_run = kwargs['dag_run']

        transactionDate = dag_run.conf.get('transaction_date', None) if dag_run.conf else None
        validate_date(transactionDate, 'transaction_date')
        byPassExecution = dag_run.conf.get('bypass_execution', "false") if dag_run.conf else "false"

        source_table = (dag_run.conf.get('source_table', 'egdp_classic_booking.lodg_rm_night_trans_fact')
                        if dag_run.conf
                        else 'egdp_classic_booking.lodg_rm_night_trans_fact')

        ti.xcom_push(key='transaction_date', value=transactionDate)
        ti.xcom_push(key='bypass_execution', value=byPassExecution)
        ti.xcom_push(key='product_line_name', value=product_line_name)
        ti.xcom_push(key='source_table', value=source_table)

        logger.info("run_id is: %s", run_id)
        logger.info("transaction_date is: %s", transactionDate)
        logger.info("bypass_execution is: %s", byPassExecution)
        logger.info("product_line_name is: %s", product_line_name)
        logger.info("source_table is: %s", source_table)
        logger.info("run_id_backfill is: %s", run_id_backfill)

        ti.xcom_push(key=WORKFLOW_NAME, value='daily-lodg')
        ti.xcom_push(key=WORKFLOW_ID, value=run_id)
        ti.xcom_push(key=START_DATE, value=transactionDate)
        ti.xcom_push(key=END_DATE, value=transactionDate)
        # ti.xcom_push(key=PRODUCT_LINE_NAME, value='Lodging')

        skip_termination = dag_run.conf.get(SKIP_TERMINATION, False) if dag_run.conf else False
        ti.xcom_push(key = SKIP_TERMINATION, value = skip_termination)
        logger.info(f'Should skip transient cluster termination: {skip_termination}')


        cluster_id = dag_run.conf.get(CLUSTER_ID, None) if dag_run.conf else None

        if cluster_id is None:
            return TG_TRIGGER_CLUSTER_CREATION_TASK_ID
        else:
            ti.xcom_push(key=CLUSTER_ID, value=cluster_id)
            ti.xcom_push(key=SKIP_CREATION, value=True)
            return TG_SKIP_CREATION_TASK_ID

    get_conf_vars_operation = BranchPythonOperator(
        task_id='get_conf_vars_task',
        python_callable=getConfVars,
        provide_context=True,
        dag=dag
    )

    def loadStagedBookingTransactions(task_id, script_name):

        logger.info('Start Loading Staged Booking Transactions', extra=params)
        dc_run_id = "{{ task_instance.xcom_pull(key='run_id') }}"

        logger.info("script_name: ", script_name)

        command = f'/usr/lib/spark/bin/spark-submit --jars {teradata_jar_location} --conf spark.master=yarn \
        --conf spark.sql.parquet.writeLegacyFormat=true --conf spark.executor.extraJavaOptions=-XX:-UseGCOverheadLimit --conf spark.driver.maxResultSize=0 --class {teradataConnectivity_class_name} \
        "{jar_path}" "{RUN_ENV}" "{dc_run_id}" "{transaction_date}" "{transaction_date}" "{product_line_name}" "{script_name}" "{BUCKET_NAME}" ; ' \

        return command_task_pair(dag, task_id, command)


    def loadPostStayTransactions(task_id, script_name_post_stay):

        logger.info('Start Post Stay Transactions', extra=params)
        dc_run_id = "{{ task_instance.xcom_pull(key='run_id') }}"

        logger.info("script_name: ", script_name_post_stay)

        command = f'/usr/lib/spark/bin/spark-submit --jars {teradata_jar_location} --conf spark.master=yarn \
        --conf spark.sql.parquet.writeLegacyFormat=true --conf spark.executor.extraJavaOptions=-XX:-UseGCOverheadLimit --conf spark.driver.maxResultSize=0 --class {teradataConnectivity_class_name} \
        "{jar_path}" "{RUN_ENV}" "{dc_run_id}" "{transaction_date}" "{transaction_date}" "{product_line_name}" "{script_name_post_stay}" "{BUCKET_NAME}" ; ' \

        return command_task_pair(dag, task_id, command)


    def successEmailCallback(**kwargs):
        ti = kwargs['ti']
        dagRun = kwargs["dag_run"]
        dc_run_id = ti.xcom_pull(key='run_id')
        dc_transaction_date = dagRun.conf.get('transaction_date')

        html = f'''
            <p>run_id: <em>{dc_run_id}</em></p>
            <p><b>Container:</b> <em>{BRANCH_NAME}</em></p>
            <p>Check logs at s3://compliance-log.files.&lt;prod\|test&gt;/{BRANCH_NAME}/&lt;step-id&gt;/</p>
            <h3>Job Successfully Completed</h3>
        '''

        send_email(
            to=support_email,
            subject=RUN_ENV +":"+ job_name + ":  Job is Successful for transaction date:"+dc_transaction_date,
            html_content=html
        )

    send_success_email = PythonOperator(
        task_id=job_name+"-succeed-email",
        python_callable=successEmailCallback,
        provide_context=True,
        dag=dag,
    )

    trigger_stage_enriched_transactions_dag = TriggerDagRunOperator(
        task_id='trigger_stage_enriched_transactions_dag',
        trigger_dag_id='eg_tax_compliance_data_collector_stage_enriched_transactions',
        conf={
            STAY_DATE: TRANSACTION_DATE_XCOM,
            PRODUCT_LINE_NAME: PRODUCT_LINE_NAME_XCOM,
            RUN_ID: RUN_ID_XCOM,
            CLUSTER_ID: CLUSTER_ID_XCOM
        },
        dag=dag
    )

    trigger_backfill_booking_transactions_dag = TriggerDagRunOperator(
        task_id='trigger_backfill_booking_transactions_dag',
        trigger_dag_id='eg_tax_compliance_data_collector_backfill_booking_transactions',
        execution_date='{{ execution_date }}',
        conf={
            START_DATE: TRANSACTION_DATE_XCOM,
            PRODUCT_LINE_NAME: PRODUCT_LINE_NAME_XCOM,
            RUN_ID: RUN_ID_BACKFILL_XCOM,
            CLUSTER_ID: CLUSTER_ID_XCOM,
            SKIP_TERMINATION: SKIP_TERMINATION_XCOM
        },
        dag=dag
    )

    def wait_for_dag_task(task_id, parent_dag_id, parent_task_id):
        return ExternalTaskSensor(
            task_id=task_id,
            external_dag_id=parent_dag_id,
            external_task_id=parent_task_id,
            allowed_states=['failed', 'success'],
            dag=dag
        )

    trigger_for_eg_tax_compliance_recon_lodg_trans_dims_compare_to_staged_bookings = TriggerDagRunOperator(
        task_id='trigger_lodge_rm_trans_recon_with_staged_transactions_dag',
        trigger_dag_id='eg_tax_compliance_recon_lodg_trans_dims_compare_to_staged_bookings',
        execution_date='{{ execution_date }}',
        conf={
            RUN_ID: RUN_ID_XCOM,
            START_DATE: TRANSACTION_DATE_XCOM,
            END_DATE: TRANSACTION_DATE_XCOM,
            PRODUCT_LINE_NAME: PRODUCT_LINE_NAME_XCOM,
            CLUSTER_ID: CLUSTER_ID_XCOM
        },
        dag=dag
    )
    wait_for_recon_lodg_trans_dim_compare_to_stage_bookings = wait_for_dag_task(
        'wait_for_recon_replication_result_task',
        'eg_tax_compliance_recon_lodg_trans_dims_compare_to_staged_bookings',
        None
    )


    trigger_for_eg_tax_compliance_recon_lodg_trans_dims_compare_to_staged_bookings_backfill = TriggerDagRunOperator(
        task_id='trigger_lodg_rm_trans_recon_with_staged_transactions_dag_backfill',
        trigger_dag_id='eg_tax_compliance_recon_lodg_trans_dims_compare_to_staged_bookings',
        reset_dag_run=True,
        conf={
            RUN_ID: RUN_ID_BACKFILL_XCOM,
            START_DATE: TRANSACTION_DATE_XCOM,
            END_DATE: TRANSACTION_DATE_XCOM,
            PRODUCT_LINE_NAME: PRODUCT_LINE_NAME_XCOM,
            CLUSTER_ID: CLUSTER_ID_XCOM
        },
        dag=dag
    )

    wait_for_recon_lodg_trans_dim_compare_to_stage_bookings_backfill = wait_for_dag_task(
        'wait_for_recon_result_backfill_task',
        'eg_tax_compliance_recon_lodg_trans_dims_compare_to_staged_bookings',
        None
    )


    trigger_recon_lodg_trans_dims_compare_to_staged_bookings_replication = TriggerDagRunOperator(
        task_id='trigger_lodg_rm_trans_recon_with_staged_transactions_replication_dag',
        trigger_dag_id='eg_tax_compliance_recon_lodg_trans_dims_compare_to_staged_bookings_replication',
        execution_date='{{ execution_date }}',
        conf={
            RUN_ID: RUN_ID_XCOM,
            START_DATE: TRANSACTION_DATE_XCOM,
            END_DATE: TRANSACTION_DATE_XCOM,
            PRODUCT_LINE_NAME: PRODUCT_LINE_NAME_XCOM,
            CLUSTER_ID: CLUSTER_ID_XCOM
        },
        dag=dag
    )
    wait_for_recon_lodg_trans_dim_compare_to_stage_bookings_replication = wait_for_dag_task(
        'wait_for_recon_result_replication_task',
        'eg_tax_compliance_recon_lodg_trans_dims_compare_to_staged_bookings_replication',
        None
    )



    def getCurrentDate():
        currentDateTimeUTC = datetime.now(tz=pytz.utc)
        currentDateTimePST = currentDateTimeUTC.astimezone(timezone('US/Pacific'))
        currentDateString = currentDateTimePST.strftime("%Y-%m-%d %H:%M:%S")
        return currentDateString

    def generateJobLogInfoCommand(task_id, payloadtype, tableName, jobDesc, pipelineProcessType, jobName, failure_run_id, failure_transaction_date,failure_product_line_name):

        operation = "Null"
        jobRunId = "{{ task_instance.xcom_pull(key='run_id') }}"
        jobUpdateDateTime = getCurrentDate()
        workflowType = "normal"
        runStatus = "Null"
        isActive = "Null"
        triggeredBy = "Tax Compliance Pipeline"
        checkType = "Null"
        transactionDateForCommand = transaction_date
        bypassExecution = "{{ dag_run.conf.get('bypass_execution', 'false') }}"
        product_line_name= "{{ task_instance.xcom_pull(key='product_line_name') }}"

        if payloadtype == "start":
            isActive = "true"
            runStatus = "running"
            operation = "insert"
        elif payloadtype == "end_success":
            isActive = "false"
            runStatus = "succeeded"
            operation = "insert"
        elif payloadtype == "end_failure":
            isActive = "false"
            runStatus = "failed"
            operation = "insert"
            jobRunId = failure_run_id
            transactionDateForCommand = failure_transaction_date
            product_line_name = failure_product_line_name
        elif payloadtype == "first_check":
            checkType = "first_check"
            operation = "check"
        elif payloadtype == "second_check":
            operation = "check"
            checkType = "second_check"


        var_value_list ="'"+operation + "' '" + jobRunId + "' '" + tableName + "' '" + jobName + "' '" + jobDesc + "' '" + pipelineProcessType + "' '" + workflowType + "' '" + jobUpdateDateTime + "' '" + transactionDateForCommand + "' '" + transactionDateForCommand + "' '" + runStatus + "' '" + isActive + "' '" + triggeredBy + "' '" + product_line_name + "' '" + checkType + "' '" + bypassExecution + "' "

        print("jar_path: "+jar_path)
        print("spark_class_name: "+spark_class_name)
        logger.info('Job Info Table call', extra=params)
        run_id = "{{ task_instance.xcom_pull(key='run_id') }}"
        logger.info("run_id is: %s", run_id)

        command = f'/usr/lib/spark/bin/spark-submit --driver-java-options -Dspring.profiles.active={environment} --conf spark.master=yarn --class {spark_class_name} {jar_path} {var_value_list} --environment {environment}'

        return command_task_pair(dag, task_id, command)


    wait_for_backfill_booking_transactions_dag = wait_for_dag_task(
        'wait_for_backfill_dag',
        'eg_tax_compliance_data_collector_backfill_booking_transactions',
        None
    )

    check_recon_lodg_rm_to_staged_transactions = BranchPythonOperator(
        task_id='check_recon_lodg_rm_recon_with_staged_transactions',
        python_callable=check_recon,
        provide_context=True,
        op_kwargs={
            'job_to_check': 'eg_tax_compliance_recon_lodg_trans_dims_compare_to_staged_bookings',
            'branch_success': 'check_recon_lodg_rm_with_staged_transactions_replication',
            'branch_fail': None
        },
        dag=dag
    )

    check_recon_lodg_rm_to_staged_transactions_replication = BranchPythonOperator(
        task_id='check_recon_lodg_rm_with_staged_transactions_replication',
        python_callable=check_recon,
        provide_context=True,
        op_kwargs={
            'job_to_check': 'eg_tax_compliance_recon_lodg_trans_dims_compare_to_staged_bookings_replication',
            'branch_success': 'union_operator_for_enrich_task',
            'branch_fail': 'trigger_backfill_booking_transactions_dag'
        },
        dag=dag
    )

    check_recon_lodg_rm_to_staged_transactions_backfill = BranchPythonOperator(
        task_id='check_recon_lodg_rm_with_staged_transactions_backfill',
        python_callable=check_recon,
        provide_context=True,
        op_kwargs={
            'job_to_check': 'eg_tax_compliance_recon_lodg_trans_dims_compare_to_staged_bookings',
            'branch_success': 'union_operator_task',
            'branch_fail': None,
        },
        dag=dag
    )

    trigger_union_for_enrich_dag = DummyOperator(
        task_id='union_operator_for_enrich_task',
        dag=dag
    )

    trigger_union_task = DummyOperator(
        task_id='union_operator_task',
        dag=dag,
        trigger_rule=TriggerRule.ONE_SUCCESS,
    )

    execute_trigger_log_start_staged_booking_transactions, listen_for_execute_trigger_log_start_staged_booking_transactions = generateJobLogInfoCommand("trigger_log_job_tables_dag_start_staged_booking_transactions",
                                                                                                                                                        "start",  "tax_compliance_eg_booking_transactions", "Loads Staged Booking Transactions to tax_compliance_eg_booking_transactions", "Data Sourcing", load_eg_tax_compliance_staged_booking_transactions_task_name, "", "", "")
    execute_trigger_log_end_success_staged_booking_transactions, listen_for_execute_trigger_log_end_success_staged_booking_transactions = generateJobLogInfoCommand("trigger_log_job_tables_dag_end_success_staged_booking_transactions",
                                                                                                                                                                    "end_success", "tax_compliance_eg_booking_transactions", "Loads Staged Booking Transactions to tax_compliance_eg_booking_transactions", "Data Sourcing", load_eg_tax_compliance_staged_booking_transactions_task_name, "", "", "")
    execute_trigger_log_start_post_stay_transactions, listen_for_execute_trigger_log_start_post_stay_transactions = generateJobLogInfoCommand("trigger_log_job_tables_dag_start_post_stay_transactions",
                                                                                                                                              "start",  "tax_compliance_eg_booking_transactions_trans_date_liability", "Loads Post Stay Transactions to tax_compliance_eg_booking_transactions_trans_date_liability", "Data Sourcing", load_eg_tax_compliance_post_stay_transactions_task_name, "", "", "")
    execute_trigger_log_end_success_post_stay_transactions, listen_for_execute_trigger_log_end_success_post_stay_transactions = generateJobLogInfoCommand("trigger_log_job_tables_dag_end_success_post_stay_transactions",
                                                                                                                                                          "end_success", "tax_compliance_eg_booking_transactions_trans_date_liability", "Loads Post Stay Transactions to tax_compliance_eg_booking_transactions_trans_date_liability", "Data Sourcing", load_eg_tax_compliance_post_stay_transactions_task_name, "", "", "")


    trigger_load_staged_booking_trans_check_simultaneous_execution, listen_for_trigger_load_staged_booking_trans_check_simultaneous_execution = generateJobLogInfoCommand("trigger_log_job_tables_dag_booking_second_check",
                                                                                                                                                                          "second_check", "tax_compliance_eg_booking_transactions",  "Loads Staged Booking Transactions to tax_compliance_eg_booking_transactions", "Data Sourcing", load_eg_tax_compliance_staged_booking_transactions_task_name, "", "", "")

    trigger_load_staged_booking_trans_execution_check_liability_date, listen_for_trigger_load_staged_booking_trans_execution_check_liability_date = generateJobLogInfoCommand("trigger_log_job_tables_dag_booking_first_check",
                                                                                                                                                                              "first_check", "tax_compliance_eg_booking_transactions", "Loads Staged Booking Transactions to tax_compliance_eg_booking_transactions", "Data Sourcing", load_eg_tax_compliance_staged_booking_transactions_task_name, "", "", "")

    trigger_load_post_stay_booking_trans_check_liability_date, listen_for_trigger_load_post_stay_booking_trans_check_liability_date = generateJobLogInfoCommand("trigger_log_job_tables_dag_post_stay_first_check",
                                                                                                                                                                "first_check",  "tax_compliance_eg_booking_transactions_trans_date_liability", "Loads Post Stay Transactions to tax_compliance_eg_booking_transactions_trans_date_liability", "Data Sourcing", load_eg_tax_compliance_post_stay_transactions_task_name, "", "", "")


    trigger_load_post_stay_booking_trans_check_simultaneous_execution, listen_for_trigger_load_post_stay_booking_trans_check_simultaneous_execution = generateJobLogInfoCommand("trigger_log_job_tables_dag_post_stay_second_check",
                                                                                                                                                                                "second_check", "tax_compliance_eg_booking_transactions_trans_date_liability", "Loads Post Stay Transactions to tax_compliance_eg_booking_transactions_trans_date_liability", "Data Sourcing", load_eg_tax_compliance_post_stay_transactions_task_name, "", "", "")

    load_eg_tax_compliance_staged_booking_transactions, listen_for_load_eg_tax_compliance_staged_booking_transactions = loadStagedBookingTransactions(load_eg_tax_compliance_staged_booking_transactions_task_name, script_name)
    load_eg_tax_compliance_post_stay_transactions, listen_for_load_eg_tax_compliance_post_stay_transactions = loadPostStayTransactions(load_eg_tax_compliance_post_stay_transactions_task_name, script_name_post_stay)

    transient_cluster_creation_skippable = transient_cluster_creation_skippable_group(dag)

    get_conf_vars_operation >> transient_cluster_creation_skippable

    transient_cluster_creation_skippable >> trigger_load_staged_booking_trans_execution_check_liability_date >> listen_for_trigger_load_staged_booking_trans_execution_check_liability_date >> \
    execute_trigger_log_start_staged_booking_transactions >> listen_for_execute_trigger_log_start_staged_booking_transactions >> \
    load_eg_tax_compliance_staged_booking_transactions >> listen_for_load_eg_tax_compliance_staged_booking_transactions >> \
    execute_trigger_log_end_success_staged_booking_transactions >> listen_for_execute_trigger_log_end_success_staged_booking_transactions >> \
    trigger_load_staged_booking_trans_check_simultaneous_execution >> listen_for_trigger_load_staged_booking_trans_check_simultaneous_execution >> \
    trigger_for_eg_tax_compliance_recon_lodg_trans_dims_compare_to_staged_bookings >> \
    trigger_recon_lodg_trans_dims_compare_to_staged_bookings_replication >> \
    wait_for_recon_lodg_trans_dim_compare_to_stage_bookings >> \
    wait_for_recon_lodg_trans_dim_compare_to_stage_bookings_replication >> \
    check_recon_lodg_rm_to_staged_transactions >> \
    check_recon_lodg_rm_to_staged_transactions_replication >> \
    [trigger_backfill_booking_transactions_dag, trigger_union_for_enrich_dag]

    trigger_backfill_booking_transactions_dag >> wait_for_backfill_booking_transactions_dag >> \
    trigger_for_eg_tax_compliance_recon_lodg_trans_dims_compare_to_staged_bookings_backfill >> wait_for_recon_lodg_trans_dim_compare_to_stage_bookings_backfill >> check_recon_lodg_rm_to_staged_transactions_backfill >> \
    trigger_union_task

    trigger_union_for_enrich_dag >> trigger_union_task
    trigger_union_task >> trigger_stage_enriched_transactions_dag

    transient_cluster_creation_skippable >> \
    trigger_load_post_stay_booking_trans_check_liability_date >> listen_for_trigger_load_post_stay_booking_trans_check_liability_date >> \
    execute_trigger_log_start_post_stay_transactions >> listen_for_execute_trigger_log_start_post_stay_transactions >> \
    load_eg_tax_compliance_post_stay_transactions >> listen_for_load_eg_tax_compliance_post_stay_transactions >> \
    execute_trigger_log_end_success_post_stay_transactions >> listen_for_execute_trigger_log_end_success_post_stay_transactions >> \
    trigger_load_post_stay_booking_trans_check_simultaneous_execution >> listen_for_trigger_load_post_stay_booking_trans_check_simultaneous_execution >> \
    trigger_stage_enriched_transactions_dag

    trigger_stage_enriched_transactions_dag >> send_success_email

    # verbal check

    """
    1. stage booking transactions
    2. Recon lodg_trans_dim_compare_to_staged_bookings
    3. Recon lodg_trans_dim_compare_to_staged_bookings_replication
    4. wait for (2)
    5. wait for (3)
    6. check results (3), proceed if good. Fail DAG if bad.
    7. check results (2), proceed to enrichment if good (step: 13). trigger backfill dag if bad (step: 8)
        8. Trigger backfill DAG
        9. Wait for backfill DAG
        10. Recon lodg_trans_dim_compare_to_staged_bookings (same dag as step 2)
        11. Wait for (10)
        12. Check results (10), proceed if good. Fail DAG if bad.
    13. Trigger enrichment dag
    14. success email (staged booking transactions)
    """
