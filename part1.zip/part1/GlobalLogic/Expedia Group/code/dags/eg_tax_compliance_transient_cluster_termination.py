from airflow import DAG
from datetime import timedelta, datetime
from airflow.providers.amazon.aws.sensors.emr import EmrJobFlowSensor
from airflow.providers.amazon.aws.operators.emr import EmrTerminateJobFlowOperator
from airflow.operators.python import PythonOperator

from eg_tax_compliance_vardata import *
from eg_tax_compliance_emr_utils import *
from eg_tax_compliance_transient_cluster_utils import *

RUN_ENV = Variable.get("ENV")
CONTAINER_NAME = Variable.get('BRANCH_NAME')

JOB_DESCRIPTION = 'This DAG terminates a transient EMR cluster'

default_args = {
    'owner': OWNER,
    'depends_on_past': False,
    'email_on_failure': False,
    'email_on_retry': False,
    'retries': 1,
    'retry_delay': timedelta(minutes=5),
    "start_date": datetime(2018, 1, 1),
}


logging.basicConfig(level=logging.INFO)
logger = logging.getLogger('TransientClusters')


def get_dag_conf(conf, name, default):
    return conf.get(name, default) if conf else default

def get_conf_vars(**kwargs):
    logger.info(f'Retrieving details to terminate transient cluster of {CONTAINER_NAME}')

    ti = kwargs['ti']
    dag_run = kwargs['dag_run']

    cluster_id = get_dag_conf(dag_run.conf, CLUSTER_ID, None)

    if cluster_id is None:
        logger.error("'cluster_id' parameter is required! Aborting...")
        raise Exception('Required parameter not provided')

    ti.xcom_push(key = CLUSTER_ID, value = cluster_id)

    logger.info(f'Cluster to terminate: {cluster_id}')

    skip_termination = get_dag_conf(dag_run.conf, SKIP_TERMINATION, False)
    logger.info(f'Should skip this cluster termination?: {skip_termination}')

    if skip_termination == True or skip_termination == 'True':
        raise Exception('This exception is expected, as the cluster is not expected to be terminated right now.')


with DAG(
    dag_id=TRANSIENT_CLUSTER_TERMINATION_DAG_ID,
    description=JOB_DESCRIPTION,
    default_args=default_args,
    schedule_interval=None,
    catchup=False,
    tags=tags[TRANSIENT_CLUSTER_TERMINATION_DAG_ID]
) as dag:
    
    get_conf_vars_task = PythonOperator(
        task_id=DEFAULT_CONF_VARS_TASK_ID,
        python_callable=get_conf_vars,
        provide_context=True,
        dag=dag
    )
    
    terminate_emr_cluster = EmrTerminateJobFlowOperator(
        task_id=TERMINATE_CLUSTER_TASK_ID,
        job_flow_id=CLUSTER_ID_XCOM,
        aws_conn_id='aws_default',
        dag=dag,
    )

    wait_for_emr_termination = EmrJobFlowSensor(
        task_id='wait_for_' + TERMINATE_CLUSTER_TASK_ID,
        job_flow_id=CLUSTER_ID_XCOM,
        target_states=['TERMINATED'],
        failed_states=['TERMINATED_WITH_ERRORS'],
        dag=dag
    )

    get_conf_vars_task >> terminate_emr_cluster >> wait_for_emr_termination
