import time
from airflow.models import BaseOperator
from airflow.utils.decorators import apply_defaults
from airflow.exceptions import AirflowException, AirflowFailException
from airflow.contrib.hooks.emr_hook import EmrHook

from eg_tax_compliance_utils import *

class EgJobFlowIdleSensor(BaseOperator):
    """
    Asks for the state of the JobFlow (EMR Cluster).
    If the status has been WAITING for longer than `max_idle_time`, the Operator succeds
    The only other way for this Operator to finish is for the cluster to terminate without long idle waits

    :param job_flow_id: The EMR Cluster ID to check
    :type job_flow_id: str

    :param polling_interval: Specifies the time interval (in seconds) between each status check.
    :type polling_interval: int

    :param max_idle_time: Defines the maximum waiting time (in seconds) before the operator finishes with a successful state.
    :type polling_interval: int
    """
    template_fields = ['job_flow_id']
    ui_color = '#9858bf'

    @apply_defaults
    def __init__(self, job_flow_id, polling_interval, max_idle_time, *args, **kwargs):
        super(EgJobFlowIdleSensor, self).__init__(*args, **kwargs)
        self.job_flow_id = job_flow_id
        self.polling_interval = polling_interval
        self.max_idle_time = max_idle_time

    def check_cluster_status(self):
        emr = EmrHook(aws_conn_id='aws_default').get_conn()
        try:
            response = emr.describe_cluster(ClusterId=self.job_flow_id)

            if 'Cluster' in response and 'Status' in response['Cluster'] and 'State' in response['Cluster']['Status']:
                return response['Cluster']['Status']['State']
            else:
                raise AirflowException("Invalid EMR response: %s" % response)
        
        except emr.exceptions.ClusterNotFoundFault: # Cluster has been terminated
            return 'TERMINATED'

    def execute(self, context):
        start_time = time.time()
        current_time = start_time

        while True:
            elapsed_time = current_time - start_time
            h, m, s = convert_seconds(elapsed_time)
            self.log.info(f'Elapsed time: {h} hours; {m} minutes; {s} seconds')

            cluster_status = self.check_cluster_status()
            self.log.info("Cluster status: %s", cluster_status)

            if cluster_status == 'TERMINATED':
                raise AirflowFailException('EMR cluster has already been terminated.')

            if cluster_status != 'WAITING':
                self.log.info("Cluster is not in WAITING state. Resetting the timer.")
                start_time = time.time()

            if elapsed_time >= self.max_idle_time:
                self.log.info("Max waiting time exceeded. Exiting with success.")
                return

            time.sleep(self.polling_interval)
            current_time = time.time()
