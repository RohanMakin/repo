import json
from datetime import datetime, timedelta

from airflow.models import Variable
from airflow.decorators import dag, task

from eg_tax_compliance_utils import *
from eg_tax_compliance_vardata import *


job_interval = '0 4 * * 6' # 4AM Saturday UTC -> 8PM Friday PST

JOB_NAME = 'eg_tax_compliance_long_running_cluster_autotermination'
SECRET_NAME = 'tax-compliance-spinnaker-constraints'
SECRET_KEY = 'secret_key'

ENV = Variable.get('ENV')


support_email = support_emails[ENV]

default_args = {
    "owner": "os-team-taxmanians@expedia.com",
    "depends_on_past": False,
    "email": [support_email],
    "email_on_failure": True,
    "retries": 2,
    "retry_delay": timedelta(minutes=60)
}

@dag(
    dag_id=JOB_NAME,
    default_args=default_args,
    start_date=datetime(2018, 1, 1), 
    schedule=job_interval,
    catchup=False,
    tags=tags[JOB_NAME]
)
def auto_terminate_long_running_cluster():
    logging.basicConfig(level=logging.INFO)
    logger = logging.getLogger(JOB_NAME)

    @task(show_return_value_in_logs=False)
    def get_secret_key():
        payload_constraints_response = get_secret_value(SECRET_NAME)
        secret_keys = json.loads(payload_constraints_response)
        secret_key = secret_keys[SECRET_KEY]
        
        logger.info(f'Secret key retrieved: {secret_key[0:3]}...{secret_key[-3:]}')

        return secret_key

    @task
    def prepare_request_body(secret_key: str, branch: str):
        return compliance_container_request_body(secret_key, branch)


    branch_name = Variable.get('BRANCH_NAME')
    kumo_security_context = Variable.get('KumoSecurityContext')

    webhook_endpoint = f'webhooks/webhook/{kumo_security_context}-compliance-container-delete'

    secret = get_secret_key()
    parameters = prepare_request_body(secret, branch_name)

    trigger_compliance_container_delete_task = generate_spinnaker_webhook_request(webhook_endpoint, parameters)

    parameters >> trigger_compliance_container_delete_task


auto_terminate_long_running_cluster()