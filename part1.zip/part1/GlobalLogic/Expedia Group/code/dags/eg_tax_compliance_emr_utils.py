from airflow.models import Variable
from datetime import timedelta
from airflow.providers.amazon.aws.operators.emr import EmrAddStepsOperator
from airflow.providers.amazon.aws.sensors.emr import EmrStepSensor
from airflow.hooks.S3_hook import S3Hook
from airflow.utils.trigger_rule import TriggerRule
from airflow import settings
from airflow.models.taskinstance import clear_task_instances
from botocore.exceptions import ClientError

import boto3
import json
import logging
import os

# THIS MODULE WILL BE DEPRECATED AS TRANSIENT CLUSTERS ROLL OUT

S3_RESOURCE = boto3.resource('s3')

SPARK_RECON_FLAG = Variable.get("UseSparkEngine", False)

RECON_BUCKET = Variable.get("ReconScriptBucket")   # Location of hive scripts and also an output for results
RECON_PREFIX = Variable.get("ReconScriptPrefix") if not SPARK_RECON_FLAG else Variable.get("ReconScriptPrefixSpark")

RECON_RESULT_TABLE_MAPPING = {
    "job_run_id": 0,
    "rule_name": 1,
    "job_run_datetime": 2,
    "source_name": 3,
    "target_name": 4,
    "src_metric_value": 5,
    "tgt_metric_value": 6,
    "match_percentage": 7,
    "threshold_percentage": 8,
    "run_status": 9,
    "start_date": 10,
    "end_date": 11,
    "run_id": 12
}

ENABLE_EMR_RETRIES = 'enable_emr_retries'

def step_config(name, command):
    return {
        'Name': name,
        'ActionOnFailure': 'CONTINUE',
        'HadoopJarStep': {
            'Jar': 'command-runner.jar',
            'Args': [
                "bash",
                "-c",
                command
            ]
        }
    }
def retry_callback(context):
    enable_emr_retries = context['params'].get(ENABLE_EMR_RETRIES, False)

    if enable_emr_retries == False or enable_emr_retries == 'False':
        return
    
    tasks = context["dag_run"].get_task_instances()
    to_retry_task_id = context["params"].get("to_retry",[])
    task_to_retry = [ti for ti in tasks if ti.task_id in to_retry_task_id]
    dag = context['dag']
    session = settings.Session()
    print("Will retry the following tasks: ")
    for ti in task_to_retry:
        print(ti.task_id)
    clear_task_instances(task_to_retry,session,None,dag)

# Create a pair of operators to perform an AWS EMR Step.
#
# One operator instructs AWS EMR to perform the operation.
# The other listens for the operation.
# The implicit task dependency is not recorded here, that is the responsibility of the caller.
# The AWS api supports adding multiple steps at once but in practice our DAGs do one at a time.
def create_step_and_listener_pair(dag, task_id, step, t_rule, enable_emr_retries=False):
    addStep = EmrAddStepsOperator(
        task_id=task_id,
        job_flow_id=Variable.get('CLUSTER_ID'),
        aws_conn_id='aws_default',
        steps=[ step ], # API expects a list of steps
        trigger_rule=t_rule,
        dag=dag
    )

    listenForStep = EmrStepSensor(
        task_id=f'listen_for_{task_id}',
        job_flow_id=Variable.get('CLUSTER_ID'),
        step_id=f'{{{{ task_instance.xcom_pull( task_ids="{task_id}" )[0] }}}}',   # Get first result of returned value from AddSteps
        dag=dag,
        on_retry_callback=retry_callback,
        params={
            ENABLE_EMR_RETRIES: enable_emr_retries,
            'to_retry': [task_id]
        }
    )
    return addStep, listenForStep

# Create a pair of operators from a CLI command
def command_task_pair(dag, task_id, command, trigger_rule = TriggerRule.ALL_SUCCESS, enable_emr_retries=False):
    step = step_config(task_id, command)
    return create_step_and_listener_pair(dag, task_id, step, trigger_rule, enable_emr_retries)

def get_s3_object_content(bucket, key):
    print("Getting key: {} from bucket: {}".format(key, bucket))

    s3_object = S3_RESOURCE.Object(bucket, key)
    object_content = s3_object.get()['Body'].read().decode('utf-8')
    return object_content

def download_s3_file_as_json(bucket_name, file_name):
    s3 = boto3.client('s3')
    response = s3.get_object(Bucket=bucket_name, Key=file_name)
    contents = response['Body'].read().decode('utf-8')
    result = json.loads(contents)
    
    return result

def upload_file_to_s3(file_name, bucket, object_name = None):
    """Upload a file to an S3 bucket

    :param file_name: File to upload
    :param bucket: Bucket to upload to
    :param object_name: S3 object name. If not specified then file_name is used
    :return: True if file was uploaded, else False
    """

    # If S3 object_name was not specified, use file_name
    if object_name is None:
        object_name = os.path.basename(file_name)

    # Upload the file
    s3_client = boto3.client('s3')
    try:
        response = s3_client.upload_file(file_name, bucket, object_name)
    except ClientError as e:
        logging.error(e)
        return False
    return True

def check_recon(branch_success, branch_fail, job_to_check, **kwargs):
    try:
        recon_output = get_s3_object_content(RECON_BUCKET, f'{RECON_PREFIX}/failed_rule_output_{job_to_check}')
        recon_results = list(set(filter(None, recon_output.split("\n"))))

        split_results_list = [row.split("	") for row in recon_results]
        failed_rules_list = []

        if (len(split_results_list) == 0):
            raise Exception("No records inserted in recon result table")

        for record in split_results_list:
            run_status = record[RECON_RESULT_TABLE_MAPPING.get("run_status")]

            if run_status == "FAILED":
                failed_rules_list.append(record[RECON_RESULT_TABLE_MAPPING.get("rule_name")])

        logging.error("Failed Rules list is: %s", failed_rules_list)
        if (len(failed_rules_list) > 0):
            if branch_fail is not None:
                print(f'Following branch `{branch_fail}`')
                return branch_fail
            else:
                raise Exception("Reconciliation failed, cannot proceed")

        print(f'Following branch `{branch_success}`')
        return branch_success
    except ClientError as ex:
        if ex.response['Error']['Code'] == 'NoSuchKey':
            raise Exception(f'Failed to insert expected rule in {job_to_check}. Cannot proceed.')
        else:
            raise

def get_secret_value(secret_name):
    session = boto3.session.Session()
    client = session.client(service_name='secretsmanager', region_name='us-east-1')

    response = client.get_secret_value(SecretId = secret_name)
    return response['SecretString']
    