-- For table: six_sense.linkedin_media

-- Step 1: Add new VARCHAR columns

ALTER TABLE six_sense.linkedin_media
ADD COLUMN utm_term_vc VARCHAR(256);

ALTER TABLE six_sense.linkedin_media
ADD COLUMN utm_source_vc VARCHAR(128);

-- Step 2: Backfill old data

UPDATE six_sense.linkedin_media
SET
  utm_term_vc   = CAST(utm_term AS VARCHAR),
  utm_source_vc = CAST(utm_source AS VARCHAR);

-- Step 3: Validate

SELECT COUNT(*) 
FROM six_sense.linkedin_media
WHERE utm_term IS NOT NULL AND utm_term_vc IS NULL;

-- Should return 0.

-- Step 4: Drop old columns

ALTER TABLE six_sense.linkedin_media
DROP COLUMN utm_term;

ALTER TABLE six_sense.linkedin_media
DROP COLUMN utm_source;

-- Step 5: Rename new columns

ALTER TABLE six_sense.linkedin_media
RENAME COLUMN utm_term_vc TO utm_term;

ALTER TABLE six_sense.linkedin_media
RENAME COLUMN utm_source_vc TO utm_source;

------------------------------------------------------

ALTER TABLE six_sense.linkedin_media
ADD COLUMN linkedin_campaign_name_vc VARCHAR(256);

UPDATE six_sense.linkedin_media
SET linkedin_campaign_name_vc = linkedin_campaign_name;

ALTER TABLE six_sense.linkedin_media
DROP COLUMN linkedin_campaign_name;

ALTER TABLE six_sense.linkedin_media
RENAME COLUMN linkedin_campaign_name_vc TO linkedin_campaign_name;

------------------------------------------------------

ALTER TABLE six_sense.linkedin_media
ADD COLUMN ad_group_vc VARCHAR(256);

UPDATE six_sense.linkedin_media
SET ad_group_vc = ad_group;

ALTER TABLE six_sense.linkedin_media
DROP COLUMN ad_group;

ALTER TABLE six_sense.linkedin_media
RENAME COLUMN ad_group_vc TO ad_group;

------------------------------------------------------

ALTER TABLE six_sense.linkedin_media
ADD COLUMN ad_name_vc VARCHAR(512);

UPDATE six_sense.linkedin_media
SET ad_name_vc = ad_name;

ALTER TABLE six_sense.linkedin_media
DROP COLUMN ad_name;

ALTER TABLE six_sense.linkedin_media
RENAME COLUMN ad_name_vc TO ad_name;

------------------------------------------------------

ALTER TABLE six_sense.linkedin_media
ALTER COLUMN crm_account_domain TYPE VARCHAR(128);

ALTER TABLE six_sense.linkedin_media
ALTER COLUMN "6sense_account_domain" TYPE VARCHAR(128);

ALTER TABLE six_sense.linkedin_media
ALTER COLUMN utm_medium TYPE VARCHAR(64);

ALTER TABLE six_sense.linkedin_media
ALTER COLUMN utm_content TYPE VARCHAR(256);

ALTER TABLE six_sense.linkedin_media
ALTER COLUMN utm_campaign TYPE VARCHAR(512);

ALTER TABLE six_sense.linkedin_media
ALTER COLUMN click_urls TYPE VARCHAR(2048);

-------------------------------------------------------------------------------------------------------------

-- For table: six_sense.external_media

ALTER TABLE six_sense.external_media
ALTER COLUMN "6sense_campaign_name" TYPE VARCHAR(256);

ALTER TABLE six_sense.external_media
ALTER COLUMN ad_group TYPE VARCHAR(256);

ALTER TABLE six_sense.external_media
ALTER COLUMN "6sense_ad_name" TYPE VARCHAR(512);

ALTER TABLE six_sense.external_media
ALTER COLUMN utm_source TYPE VARCHAR(128);

ALTER TABLE six_sense.external_media
ALTER COLUMN utm_medium TYPE VARCHAR(64);

ALTER TABLE six_sense.external_media
ALTER COLUMN utm_content TYPE VARCHAR(256);

ALTER TABLE six_sense.external_media
ALTER COLUMN utm_campaign TYPE VARCHAR(512);

ALTER TABLE six_sense.external_media
ALTER COLUMN utm_term TYPE VARCHAR(256);

ALTER TABLE six_sense.external_media
ALTER COLUMN click_urls TYPE VARCHAR(2048);

-------------------------------------------------------------------------------------------------------------


